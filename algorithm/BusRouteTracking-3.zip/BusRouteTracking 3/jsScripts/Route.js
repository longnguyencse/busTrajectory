"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Route = /** @class */ (function () {
    function Route() {
    }
    return Route;
}());
exports.Route = Route;
//# sourceMappingURL=Route.js.map