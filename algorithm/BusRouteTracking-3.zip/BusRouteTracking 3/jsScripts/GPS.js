"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GPS = /** @class */ (function () {
    function GPS(Lat, Long, ReceivingTime) {
        this.Lat = Lat;
        this.Long = Long;
        this.ReceivingTime = ReceivingTime;
    }
    return GPS;
}());
exports.default = GPS;
//# sourceMappingURL=GPS.js.map