"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Point = /** @class */ (function () {
    function Point(Lat, Long) {
        this.Lat = Lat;
        this.Long = Long;
    }
    Point.prototype.toString = function () {
        return this.Lat + "-" + this.Long; // City is not a part of the key.
    };
    return Point;
}());
exports.default = Point;
//# sourceMappingURL=Point.js.map