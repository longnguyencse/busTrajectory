"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var RPoint = /** @class */ (function () {
    function RPoint(point, length) {
        this.point = point;
        this.length = length;
    }
    return RPoint;
}());
exports.default = RPoint;
//# sourceMappingURL=RPoint.js.map