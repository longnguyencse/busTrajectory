"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _51B02635_1 = require("./Journey/51B02635");
var Point_1 = require("./Point");
var RPoint_1 = require("./RPoint");
var Collections = require("typescript-collections");
var Route1_1 = require("./Routes/Route1");
var Route2_1 = require("./Routes/Route2");
var Route3_1 = require("./Routes/Route3");
var Route4_1 = require("./Routes/Route4");
var Route5_1 = require("./Routes/Route5");
var Route6_1 = require("./Routes/Route6");
var _51B02517_1 = require("./Journey/51B02517");
var Route7_1 = require("./Routes/Route7");
var Route8_1 = require("./Routes/Route8");
var Route9_1 = require("./Routes/Route9");
var Route10_1 = require("./Routes/Route10");
var Route19_1 = require("./Routes/Route19");
var Route24_1 = require("./Routes/Route24");
var Route26_1 = require("./Routes/Route26");
var Route34_1 = require("./Routes/Route34");
var Route39_1 = require("./Routes/Route39");
var Route38_1 = require("./Routes/Route38");
var Route40_1 = require("./Routes/Route40");
var Route41_1 = require("./Routes/Route41");
var Route42_1 = require("./Routes/Route42");
var Route43_1 = require("./Routes/Route43");
var Route44_1 = require("./Routes/Route44");
var Route45_1 = require("./Routes/Route45");
var Route46_1 = require("./Routes/Route46");
var Route48_1 = require("./Routes/Route48");
var Route49_1 = require("./Routes/Route49");
var Route51_1 = require("./Routes/Route51");
var Route52_1 = require("./Routes/Route52");
var Route53_1 = require("./Routes/Route53");
var Route54_1 = require("./Routes/Route54");
var Route55_1 = require("./Routes/Route55");
var Route56_1 = require("./Routes/Route56");
var Route57_1 = require("./Routes/Route57");
var Route58_1 = require("./Routes/Route58");
var Route59_1 = require("./Routes/Route59");
var Route60_1 = require("./Routes/Route60");
var Route61_1 = require("./Routes/Route61");
var Route62_1 = require("./Routes/Route62");
var Route63_1 = require("./Routes/Route63");
var Route11_1 = require("./Routes/Route11");
var Route12_1 = require("./Routes/Route12");
var Route14_1 = require("./Routes/Route14");
var Route13_1 = require("./Routes/Route13");
var Route15_1 = require("./Routes/Route15");
var Route16_1 = require("./Routes/Route16");
var Route17_1 = require("./Routes/Route17");
var Route18_1 = require("./Routes/Route18");
var Route20_1 = require("./Routes/Route20");
var Route23_1 = require("./Routes/Route23");
var Route25_1 = require("./Routes/Route25");
var Route27_1 = require("./Routes/Route27");
var Route28_1 = require("./Routes/Route28");
var Route29_1 = require("./Routes/Route29");
var Route30_1 = require("./Routes/Route30");
var Route31_1 = require("./Routes/Route31");
var Route32_1 = require("./Routes/Route32");
var Route33_1 = require("./Routes/Route33");
var Route35_1 = require("./Routes/Route35");
var Route36_1 = require("./Routes/Route36");
var Route37_1 = require("./Routes/Route37");
var Route65_1 = require("./Routes/Route65");
var Route66_1 = require("./Routes/Route66");
var Route67_1 = require("./Routes/Route67");
var Route68_1 = require("./Routes/Route68");
var Route69_1 = require("./Routes/Route69");
var Route70_1 = require("./Routes/Route70");
var Route71_1 = require("./Routes/Route71");
var Route73_1 = require("./Routes/Route73");
var Route74_1 = require("./Routes/Route74");
var Route72_1 = require("./Routes/Route72");
var Route75_1 = require("./Routes/Route75");
var Route76_1 = require("./Routes/Route76");
var Route77_1 = require("./Routes/Route77");
var Route78_1 = require("./Routes/Route78");
var Route79_1 = require("./Routes/Route79");
var Route80_1 = require("./Routes/Route80");
var Route84_1 = require("./Routes/Route84");
var Route88_1 = require("./Routes/Route88");
var Route91_1 = require("./Routes/Route91");
var Route101_1 = require("./Routes/Route101");
var Route103_1 = require("./Routes/Route103");
var Route102_1 = require("./Routes/Route102");
var Route104_1 = require("./Routes/Route104");
var Route105_1 = require("./Routes/Route105");
var Route106_1 = require("./Routes/Route106");
var Route111_1 = require("./Routes/Route111");
var Route112_1 = require("./Routes/Route112");
var _Route113_1 = require("./Routes/\u001DRoute113");
var Route114_1 = require("./Routes/Route114");
var Route118_1 = require("./Routes/Route118");
var Route119_1 = require("./Routes/Route119");
var Route116_1 = require("./Routes/Route116");
var Route121_1 = require("./Routes/Route121");
var Route124_1 = require("./Routes/Route124");
var Route123_1 = require("./Routes/Route123");
var Route125_1 = require("./Routes/Route125");
var Route126_1 = require("./Routes/Route126");
var Route127_1 = require("./Routes/Route127");
var Route128_1 = require("./Routes/Route128");
var Route129_1 = require("./Routes/Route129");
var Route130_1 = require("./Routes/Route130");
var Route133_1 = require("./Routes/Route133");
var Route134_1 = require("./Routes/Route134");
var Route135_1 = require("./Routes/Route135");
var Route136_1 = require("./Routes/Route136");
var Route137_1 = require("./Routes/Route137");
var Route178_1 = require("./Routes/Route178");
var Route179_1 = require("./Routes/Route179");
var TOPLEFT = new Point_1.default(11.175186, 106.309795);
var BOTTOMRIGHT = new Point_1.default(10.368436, 107.036295);
function RasterizeArray(input, size) {
    var result = [];
    if (input && input.length > 0) {
        input.forEach(function (element) {
            result.push(RasterizePoint(element, size));
        });
    }
    return result;
}
function RasterizePoint(input, size) {
    var x = (TOPLEFT.Lat - input.Lat) / size;
    var y = (input.Long - TOPLEFT.Long) / size;
    return new Point_1.default(Math.ceil(x), Math.ceil(y));
}
function CalculateDistance(a, b) {
    return Math.sqrt((a.Lat - b.Lat) * (a.Lat - b.Lat) + (a.Long - b.Long) * (a.Long - b.Long));
}
function Distinct(points, gps) {
    var result = [];
    var dict = new Collections.Dictionary();
    points.map(function (value, index, number) {
        if (dict.containsKey(value)) {
            var previoustPoint = dict.getValue(value);
            var calculateDistance = CalculateDistance(gps[index], gps[index - 1]);
            previoustPoint.length = previoustPoint.length + calculateDistance;
            dict.setValue(value, previoustPoint);
        }
        else {
            dict.setValue(value, new RPoint_1.default(value, 0));
        }
    });
    var valueReturn = dict.values();
    return dict.keys();
    // return dict.values().filter((value, index, array) => {
    //     value.length > 0
    // })
}
function getRoute(input) {
    var objRoute = [];
    var route1 = input.forEach(function (value, index, array) {
        var actualRoute = value;
        objRoute.push(actualRoute);
    });
    return objRoute;
}
function processRoute(input) {
    var route1Point = [];
    // processRoute 
    input.map(function (value, index, array) {
        route1Point.push(new Point_1.default(value.Lat, value.Long));
        if (value.Polyline && value.Polyline.length > 0) {
            var arrayPoint = value.Polyline.trim().split(';');
            if (arrayPoint && arrayPoint.length > 0) {
                arrayPoint.map(function (pointString, index, aa) {
                    var pointData = pointString.trim().replace('[', '').replace(']', '').split(',');
                    if (pointData && pointData.length == 2) {
                        //console.log(Number(pointData[0]))
                        route1Point.push(new Point_1.default(Number(pointData[0]), Number(pointData[1])));
                    }
                });
            }
        }
    });
    return route1Point;
}
function BasicMatching(left, right) {
    // initalize matrix
    var matrix = [[]];
    for (var i = 0; i < left.length + 1; i++) {
        matrix[i] = [];
        for (var j = 0; j < right.length + 1; j++) {
            matrix[i][j] = 0;
        }
    }
    for (var i = 0; i < left.length + 1; i++) {
        matrix[i][0] = i;
    }
    for (var j = 0; j < right.length + 1; j++) {
        matrix[0][j] = j;
    }
    for (var l = 1; l < left.length + 1; l++) {
        for (var r = 1; r < right.length + 1; r++) {
            if (Match(left[l - 1], right[r - 1])) {
                matrix[l][r] = matrix[l - 1][r - 1];
            }
            else {
                matrix[l][r] = 1 + Min(matrix[l - 1][r - 1], matrix[l - 1][r], matrix[l][r - 1]);
            }
        }
    }
    return matrix;
}
function Match(left, right) {
    return left.toString() === right.toString();
}
function Min(input1, input2, input3) {
    return Math.min(input1, Math.min(input2, input3));
}
function preProcessRoute(data, cellSize) {
    var route1 = getRoute(data);
    var routePoints = processRoute(route1);
    return RasterizeArray(routePoints, cellSize);
}
function preProcessJourney(data, cellSize) {
    var gps2 = data;
    var step1 = RasterizeArray(gps2, cellSize);
    return Distinct(step1, gps2);
}
function handleBasicMatching(journeySet, routeSet, cellSize) {
    console.log('=====================================Find matching with cell size ' + cellSize);
    console.log('=================Preprocess Journey :');
    var preprocessJourney = [];
    journeySet.map(function (value, index, arr) {
        preprocessJourney.push(preProcessJourney(value, cellSize));
    });
    var preprocessRoute = [];
    console.log('=================Preprocess Route :');
    routeSet.map(function (value, index, arr) {
        preprocessRoute.push(preProcessRoute(value, cellSize));
    });
    console.log('=================Find Matching Cost :');
    for (var i = 0; i < preprocessJourney.length; i++) {
        var routeId = 'Route ' + routeSet[0][0].Route_Id;
        var currentCostValue = 100;
        for (var j = 0; j < preprocessRoute.length; j++) {
            console.log('=========Find Matching Cost : Journey' + (i + 1) + ' with Route' + routeSet[j][0].Route_Id);
            var matrix = BasicMatching(preprocessJourney[i], preprocessRoute[j]);
            //var matrix = BasicMatching(preprocessJourney[i],preprocessJourney[i])
            var costValue = matrix[preprocessJourney[i].length][preprocessRoute[j].length];
            //var costValue = matrix[preprocessJourney[i].length][preprocessJourney[i].length]
            var costPercent = 100 * (costValue) / Math.max(preprocessJourney[i].length, preprocessRoute[j].length);
            if (costPercent < currentCostValue) {
                currentCostValue = costPercent;
                routeId = 'Route' + routeSet[j][0].Route_Id;
            }
            console.log(costValue + "   with Journey Lenth " + preprocessJourney[i].length + " route Length " + preprocessRoute[j].length);
            console.log('matching cost ' + 100 * (costValue) / Math.max(preprocessJourney[i].length, preprocessRoute[j].length) + '%');
        }
        console.log('*********The most matching : ' + currentCostValue + ' with ' + routeId);
    }
}
var JourneySet = [_51B02517_1.Journey, _51B02635_1.Journey2];
var RouteSet = [Route1_1.Route1, Route2_1.Route2, Route3_1.Route3, Route4_1.Route4, Route5_1.Route5, Route6_1.Route6,
    Route7_1.Route7, Route8_1.Route8, Route9_1.Route9, Route10_1.Route10, Route11_1.Route11, Route12_1.Route12, Route13_1.Route13, Route14_1.Route14, Route15_1.Route15, Route16_1.Route16, Route17_1.Route17, Route18_1.Route18,
    Route19_1.Route19, Route20_1.Route20, Route23_1.Route23, Route24_1.Route24, Route25_1.Route25,
    Route26_1.Route26, Route27_1.Route27, Route28_1.Route28, Route29_1.Route29, Route30_1.Route30, Route31_1.Route31, Route32_1.Route32, Route33_1.Route33,
    Route34_1.Route34, Route35_1.Route35, Route36_1.Route36, Route37_1.Route37,
    Route38_1.Route38, Route39_1.Route39, Route40_1.Route40, Route41_1.Route41, Route42_1.Route42,
    Route43_1.Route43, Route44_1.Route44, Route45_1.Route45, Route46_1.Route46, Route48_1.Route48, Route49_1.Route49, Route51_1.Route51,
    Route52_1.Route52, Route53_1.Route53, Route54_1.Route54, Route55_1.Route55, Route56_1.Route56, Route57_1.Route57, Route58_1.Route58,
    Route59_1.Route59, Route60_1.Route60, Route61_1.Route61, Route62_1.Route62, Route63_1.Route63, Route65_1.Route65, Route66_1.Route66,
    Route67_1.Route67, Route68_1.Route68, Route69_1.Route69, Route70_1.Route70, Route71_1.Route71, Route72_1.Route72, Route73_1.Route73, Route74_1.Route74, Route75_1.Route75, Route76_1.Route76, Route77_1.Route77, Route78_1.Route78, Route79_1.Route79,
    Route80_1.Route80, Route84_1.Route84, Route88_1.Route88, Route91_1.Route91, Route101_1.Route101, Route102_1.Route102, Route103_1.Route103, Route104_1.Route104, Route105_1.Route105, Route106_1.Route106,
    Route111_1.Route111, Route112_1.Route112, _Route113_1.Route113, Route114_1.Route114, Route116_1.Route116, Route118_1.Route118, Route119_1.Route119, Route121_1.Route121, Route123_1.Route123, Route124_1.Route124, Route125_1.Route125, Route126_1.Route126, Route127_1.Route127,
    Route128_1.Route128, Route129_1.Route129, Route130_1.Route130, Route133_1.Route133, Route134_1.Route134, Route135_1.Route135, Route136_1.Route136, Route137_1.Route137, Route178_1.Route178, Route179_1.Route179
];
handleBasicMatching(JourneySet, RouteSet, 0.0004);
// test bacsc 
var arrayP = [new Point_1.default(1, 1), new Point_1.default(1, 2), new Point_1.default(1, 3)];
BasicMatching(arrayP, arrayP);
//# sourceMappingURL=main.js.map