
import GPS from './GPS';
import { Journey2 } from './Journey/51B02635';
import Point from './Point';
import RPoint from './RPoint'
import * as Collections from 'typescript-collections';
import { Route1 } from './Routes/Route1';
import { Route2 } from './Routes/Route2';
import { Route3 } from './Routes/Route3';
import { Route4 } from './Routes/Route4';
import { Route5 } from './Routes/Route5';
import { Route6 } from './Routes/Route6';
import { Route } from './Route';
import { Journey } from './Journey/51B02517';
import { Route7 } from './Routes/Route7';
import { Route8 } from './Routes/Route8';
import { Route9 } from './Routes/Route9';
import { Route10 } from './Routes/Route10';
import { Route19 } from './Routes/Route19';
import { Route24 } from './Routes/Route24';
import { Route26 } from './Routes/Route26';
import { Route34 } from './Routes/Route34';
import { Route39 } from './Routes/Route39';
import { Route38 } from './Routes/Route38';
import { Route40 } from './Routes/Route40';
import { Route41 } from './Routes/Route41';
import { Route42 } from './Routes/Route42';
import { Route43 } from './Routes/Route43';
import { Route44 } from './Routes/Route44';
import { Route45 } from './Routes/Route45';
import { Route46 } from './Routes/Route46';
import { Route48 } from './Routes/Route48';
import { Route49 } from './Routes/Route49';
import { Route51 } from './Routes/Route51';
import { Route52 } from './Routes/Route52';
import { Route53 } from './Routes/Route53';
import { Route54 } from './Routes/Route54';
import { Route55 } from './Routes/Route55';
import { Route56 } from './Routes/Route56';
import { Route57 } from './Routes/Route57';
import { Route58 } from './Routes/Route58';
import { Route59 } from './Routes/Route59';
import { Route60 } from './Routes/Route60';
import { Route61 } from './Routes/Route61';
import { Route62 } from './Routes/Route62';
import { Route63 } from './Routes/Route63';
import { Route11 } from './Routes/Route11';
import { Route12 } from './Routes/Route12';
import { Route14 } from './Routes/Route14';
import { Route13 } from './Routes/Route13';
import { Route15 } from './Routes/Route15';
import { Route16 } from './Routes/Route16';
import { Route17 } from './Routes/Route17';
import { Route18 } from './Routes/Route18';
import { Route20 } from './Routes/Route20';
import { Route23 } from './Routes/Route23';
import { Route25 } from './Routes/Route25';
import { Route27 } from './Routes/Route27';
import { Route28 } from './Routes/Route28';
import { Route29 } from './Routes/Route29';
import { Route30 } from './Routes/Route30';
import { Route31 } from './Routes/Route31';
import { Route32 } from './Routes/Route32';
import { Route33 } from './Routes/Route33';
import { Route35 } from './Routes/Route35';
import { Route36 } from './Routes/Route36';
import { Route37 } from './Routes/Route37';
import { Route65 } from './Routes/Route65';
import { Route66 } from './Routes/Route66';
import { Route67 } from './Routes/Route67';
import { Route68 } from './Routes/Route68';
import { Route69 } from './Routes/Route69';
import { Route70 } from './Routes/Route70';
import { Route71 } from './Routes/Route71';
import { Route73 } from './Routes/Route73';
import { Route74 } from './Routes/Route74';
import { Route72 } from './Routes/Route72';
import { Route75 } from './Routes/Route75';
import { Route76 } from './Routes/Route76';
import { Route77 } from './Routes/Route77';
import { Route78 } from './Routes/Route78';
import { Route79 } from './Routes/Route79';
import { Route80 } from './Routes/Route80';
import { Route84 } from './Routes/Route84';
import { Route88 } from './Routes/Route88';
import { Route91 } from './Routes/Route91';
import { Route101 } from './Routes/Route101';
import { Route103 } from './Routes/Route103';
import { Route102 } from './Routes/Route102';
import { Route104 } from './Routes/Route104';
import { Route105 } from './Routes/Route105';
import { Route106 } from './Routes/Route106';
import { Route111 } from './Routes/Route111';
import { Route112 } from './Routes/Route112';
import { Route113 } from './Routes/\u001DRoute113';
import { Route114 } from './Routes/Route114';
import { Route118 } from './Routes/Route118';
import { Route119 } from './Routes/Route119';
import { Route116 } from './Routes/Route116';
import { Route121 } from './Routes/Route121';
import { Route124 } from './Routes/Route124';
import { Route123 } from './Routes/Route123';
import { Route125 } from './Routes/Route125';
import { Route126 } from './Routes/Route126';
import { Route127 } from './Routes/Route127';
import { Route128 } from './Routes/Route128';
import { Route129 } from './Routes/Route129';
import { Route130 } from './Routes/Route130';
import { Route133 } from './Routes/Route133';
import { Route134 } from './Routes/Route134';
import { Route135 } from './Routes/Route135';
import { Route136 } from './Routes/Route136';
import { Route137 } from './Routes/Route137';
import { Route178 } from './Routes/Route178';
import { Route179 } from './Routes/Route179';

const TOPLEFT: Point = new Point(11.175186, 106.309795)
const BOTTOMRIGHT = new  Point(10.368436, 107.036295)


function RasterizeArray(input: Point[], size: number): Point[] {
    let result: Point[] = []
    if (input && input.length > 0) {
        input.forEach(element => {
           result.push(RasterizePoint(element, size))
        });
    }
    return result
}

function RasterizePoint(input: Point, size: number): Point {
    let x = (TOPLEFT.Lat - input.Lat)/ size
	let y = (input.Long - TOPLEFT.Long) / size;
	return new Point (Math.ceil(x), Math.ceil(y))
}

function CalculateDistance(a: Point, b: Point): number {
    return Math.sqrt((a.Lat - b.Lat)*(a.Lat - b.Lat) +(a.Long - b.Long)*(a.Long - b.Long))
}

function Distinct(points: Point[], gps: GPS[]) : Point[] {
    let result: RPoint[] = []
    var dict = new Collections.Dictionary<Point, RPoint>();
    points.map((value, index, number) => {
        if (dict.containsKey(value)) {
            var previoustPoint: RPoint = dict.getValue(value)
            var calculateDistance = CalculateDistance(gps[index], gps[index-1])
            previoustPoint.length = previoustPoint.length + calculateDistance
            dict.setValue(value, previoustPoint)

        } else {
            dict.setValue(value, new RPoint(value, 0))
        }
    })
    var valueReturn = dict.values()
    return dict.keys()
    // return dict.values().filter((value, index, array) => {
    //     value.length > 0
    // })
}

function getRoute(input: any): Route[] {
    var objRoute: Route[] = []
    var route1 = input.forEach((value, index, array) => {
        let actualRoute: Route = value
        objRoute.push(actualRoute)
    })
    return objRoute
}

function processRoute(input: Route[]) : Point[] {
    var route1Point: Point[] = [] 
    // processRoute 
    input.map((value, index, array) => {
    route1Point.push(new Point(value.Lat, value.Long))
    if (value.Polyline && value.Polyline.length > 0 ) {
        var arrayPoint: string[] = value.Polyline.trim().split(';')
        if(arrayPoint && arrayPoint.length > 0) {
            arrayPoint.map((pointString, index, aa) => {
                var pointData: string[] = pointString.trim().replace('[','').replace(']','').split(',')
                if (pointData && pointData.length == 2) {
                    //console.log(Number(pointData[0]))
                    route1Point.push(new Point(Number(pointData[0]), Number(pointData[1])))
                }
            })
        }
    }
    })
    return route1Point
}

function BasicMatching(left: Point[], right: Point[]): any[] {
    // initalize matrix
    var matrix  = [[]]

    for(var i=0; i<left.length + 1; i++) {
        matrix[i] = [];
        for(var j=0; j<right.length + 1; j++) {
            matrix[i][j] = 0;
        }
    }
    for(var i = 0; i < left.length + 1; i++) {
        matrix[i][0] = i
    }
    for(var j = 0; j< right.length + 1; j++) {
        matrix[0][j] = j
    }
    for(var l = 1; l < left.length + 1; l ++ ) {
        for(var r = 1; r < right.length + 1 ; r ++ )
         {
            if (Match(left[l-1], right[r-1])) {
                matrix[l][r] = matrix[l -1][r-1]
            } else {
                matrix[l][r] = 1 + Min(matrix[l-1][r-1], matrix[l-1][r], matrix[l][r-1])
            }
        }
    }
    return matrix
}




function Match(left: Point, right: Point) {
    return left.toString() === right.toString()
}

function Min(input1 : number, input2: number, input3: number) {
    return Math.min(input1, Math.min(input2, input3))
}

function preProcessRoute(data: any, cellSize: number) : Point[] {
    var route1 = getRoute(data)
    var routePoints = processRoute(route1)
    return  RasterizeArray(routePoints, cellSize)
}

function preProcessJourney(data : any,cellSize: number): Point[] {
    let gps2: GPS[] = data
    var step1 = RasterizeArray(gps2, cellSize)
    return  Distinct(step1, gps2)
}

function handleBasicMatching( journeySet: any[], routeSet: any[], cellSize: number) {
    console.log('=====================================Find matching with cell size ' + cellSize)
    
    console.log('=================Preprocess Journey :')
    let preprocessJourney = []
    journeySet.map((value, index, arr) => {
        preprocessJourney.push(preProcessJourney(value,cellSize))
    })

    let preprocessRoute = []
    console.log('=================Preprocess Route :')
    routeSet.map((value, index, arr) => {
        preprocessRoute.push(preProcessRoute(value,cellSize))
    })

    console.log('=================Find Matching Cost :')
    for(let i = 0; i < preprocessJourney.length; i ++) {
        let routeId = 'Route ' + routeSet[0][0].Route_Id
        var currentCostValue = 100
        for(let j = 0; j < preprocessRoute.length; j ++) {
            console.log('=========Find Matching Cost : Journey' + (i+1) + ' with Route' +  routeSet[j][0].Route_Id)
            var matrix = BasicMatching(preprocessJourney[i],preprocessRoute[j])
            //var matrix = BasicMatching(preprocessJourney[i],preprocessJourney[i])
            var costValue = matrix[preprocessJourney[i].length][preprocessRoute[j].length]
            //var costValue = matrix[preprocessJourney[i].length][preprocessJourney[i].length]
            let costPercent = 100 * (costValue)/ Math.max( preprocessJourney[i].length , preprocessRoute[j].length )
            if (costPercent < currentCostValue ) {
                currentCostValue = costPercent
                routeId = 'Route'+ routeSet[j][0].Route_Id
            }
            console.log(`${costValue}   with Journey Lenth ${preprocessJourney[i].length} route Length ${preprocessRoute[j].length}`  )
            console.log('matching cost ' + 100 * (costValue)/ Math.max( preprocessJourney[i].length , preprocessRoute[j].length ) + '%')
        }

        console.log('*********The most matching : ' + currentCostValue + ' with ' + routeId)
    }
}

var JourneySet = [Journey, Journey2]
var RouteSet = [Route1, Route2,Route3, Route4, Route5, Route6,
    Route7, Route8, Route9, Route10,Route11, Route12,Route13, Route14, Route15, Route16, Route17,Route18,
    Route19,Route20,Route23, Route24,Route25,
    Route26,Route27,Route28, Route29,Route30,Route31,Route32, Route33,
     Route34,Route35,Route36, Route37,
     Route38, Route39,Route40, Route41,Route42, 
    Route43,Route44,Route45, Route46,Route48, Route49,Route51,
    Route52,Route53, Route54,Route55,Route56,Route57,Route58,
    Route59,Route60, Route61,Route62,Route63,Route65,Route66,
    Route67,Route68,Route69,Route70,Route71, Route72,Route73,Route74,Route75,Route76, Route77,Route78,Route79,
    Route80,Route84, Route88,Route91,Route101,Route102,Route103, Route104,Route105,Route106,
    Route111,Route112, Route113,Route114,Route116,Route118,Route119, Route121,Route123,Route124, Route125,Route126,Route127,
    Route128,Route129, Route130,Route133,Route134,Route135,Route136, Route137,Route178,Route179
]


handleBasicMatching(JourneySet, RouteSet, 0.0004)
// test bacsc 
var arrayP = [new Point(1,1),new Point(1,2),new Point(1,3)]
BasicMatching(arrayP, arrayP)
