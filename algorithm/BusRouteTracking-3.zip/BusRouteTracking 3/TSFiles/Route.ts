export class Route {
    // constructor(public Route_Id: string, public Station_Id: string, public Station_Code: string, public Station_Order: string, public Station_Name: string, public Station_Address: string,
    //     public Lat: number, public Long: number, public Polyline: [string], public Distance: string ) {}
    public Route_Id: string
    public Station_Id: string
    public Station_Code: string
    public Station_Order: string
    public Station_Name: string
    public Station_Address: string
    public Lat: number
    public Long: number
    public Polyline: string
    public Distance: string
}