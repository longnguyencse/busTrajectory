export const Route7 =[
  {
     "Route_Id":"7"
    ,"Station_Id":"468"
    ,"Station_Code":"BX43"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"BÃI HẬU CẦN SỐ 1"
    ,"Station_Address":"BÃI HẬU CẦN SỐ 1, đường Phan Văn Trị, Qu ận Gò Vấp"
    ,"Lat":10.82361125946045
    ,"Long":106.69189453125
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"539"
    ,"Station_Code":"QGV 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bãi hậu cần số 1"
    ,"Station_Address":"Đối diện 439 , đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.82389
    ,"Long":106.69202
    ,"Polyline":"[106.69189453,10.82361126] ; [106.69211578,10.82378483] ; [106.69201660,10.82388973]"
    ,"Distance":"47"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"540"
    ,"Station_Code":"QGV 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"UBND Phường  5, Quận Gò Vấp"
    ,"Station_Address":"247, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.825513
    ,"Long":106.688259
    ,"Polyline":"[106.69201660,10.82388973] ; [106.68930817,10.82637215] ; [106.68871307,10.82579231] ; [106.68825531,10.82551289]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"541"
    ,"Station_Code":"QGV 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"145, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.822636
    ,"Long":106.685164
    ,"Polyline":"[106.68825531,10.82551289] ; [106.68745422,10.82498074] ; [106.68693542,10.82469654] ; [106.68648529,10.82415962] ; [106.68632507,10.82405376] ; [106.68516541,10.82263565]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"543"
    ,"Station_Code":"QGV 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"63, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.820866
    ,"Long":106.683758
    ,"Polyline":"[106.68516541,10.82263565] ; [106.68376160,10.82086563]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"60"
    ,"Station_Code":"QGV 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà Tang Lễ"
    ,"Station_Address":"220 (175), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.822141
    ,"Long":106.682616
    ,"Polyline":"[106.68376160,10.82086563] ; [106.68367767,10.82069778] ; [106.68349457,10.82049179] ; [106.68261719,10.82214069]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"61"
    ,"Station_Code":"QGV 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"72 (45), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.825861
    ,"Long":106.680561
    ,"Polyline":"[106.68261719,10.82214069] ; [106.68055725,10.82586098]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"219"
    ,"Station_Code":"QGV 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Siêu Thị Big C Gò Vấp"
    ,"Station_Address":"Đối diện Big C, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.825682
    ,"Long":106.679606
    ,"Polyline":"[106.68055725,10.82586098] ; [106.68032837,10.82616711] ; [106.68019867,10.82624054] ; [106.68005371,10.82624054] ; [106.67992401,10.82619286] ; [106.67981720,10.82607746] ; [106.67960358,10.82568169]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"222"
    ,"Station_Code":"QGV 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Xóm Cháy"
    ,"Station_Address":"629B, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.821751
    ,"Long":106.678764
    ,"Polyline":"[106.67960358,10.82568169] ; [106.67924500,10.82465458] ; [106.67888641,10.82318974] ; [106.67876434,10.82175064]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"221"
    ,"Station_Code":"QGV 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"151, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.818837
    ,"Long":106.678719
    ,"Polyline":"[106.67876434,10.82175064] ; [106.67871857,10.81883717]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"223"
    ,"Station_Code":"QGV 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Tân Sơn Nhất"
    ,"Station_Address":"37 -  39, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.815118
    ,"Long":106.678619
    ,"Polyline":"[106.67871857,10.81883717] ; [106.67861938,10.81511784]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"224"
    ,"Station_Code":"QPN 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Đầu công  viên Gia Định"
    ,"Station_Address":"Đối diện cây xanh số 7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.813568
    ,"Long":106.677868
    ,"Polyline":"[106.67861938,10.81511784] ; [106.67864227,10.81485367] ; [106.67862701,10.81449032] ; [106.67852020,10.81434822] ; [106.67847443,10.81420612] ; [106.67822266,10.81396389] ; [106.67787170,10.81356812]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"225"
    ,"Station_Code":"QPN 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cuối công viên Gia Định"
    ,"Station_Address":"Đối diện số 5, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.809764
    ,"Long":106.674591
    ,"Polyline":"[106.67787170,10.81356812] ; [106.67459106,10.80976391]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"226"
    ,"Station_Code":"QPN 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đầu Đường Đào Duy Anh"
    ,"Station_Address":"155 , đường Đào Duy Anh, Quận Phú Nhuận"
    ,"Lat":10.807978
    ,"Long":106.674057
    ,"Polyline":"[106.67459106,10.80976391] ; [106.67366028,10.80852604] ; [106.67359924,10.80836201] ; [106.67387390,10.80816174] ; [106.67405701,10.80797768]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"228"
    ,"Station_Code":"QPN 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Cuối Đường  Đào Duy Anh"
    ,"Station_Address":"7-9, đường  Đào Duy Anh, Quận Phú Nhuận"
    ,"Lat":10.805891
    ,"Long":106.677177
    ,"Polyline":"[106.67405701,10.80797768] ; [106.67717743,10.80589104]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"230"
    ,"Station_Code":"QPN 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Đầu đường Hồ Văn Huê"
    ,"Station_Address":"129, đường Hồ Văn Huê, Quận Phú Nhuận"
    ,"Lat":10.804737
    ,"Long":106.677689
    ,"Polyline":"[106.67717743,10.80589104] ; [106.67739105,10.80584908] ; [106.67808533,10.80542183] ; [106.67768860,10.80473709]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"227"
    ,"Station_Code":"QPN 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Tháp Nước"
    ,"Station_Address":"43B, đường H ồ Văn Huê, Quận Phú Nhuận"
    ,"Lat":10.802824
    ,"Long":106.676602
    ,"Polyline":"[106.67768860,10.80473709] ; [106.67660522,10.80282402]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"229"
    ,"Station_Code":"QPN 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trung tâm hội nghị tiệc cưới White  Palace"
    ,"Station_Address":"1B, đường Hồ Văn  Huê, Quận Phú Nhuận"
    ,"Lat":10.800174
    ,"Long":106.675068
    ,"Polyline":"[106.67660522,10.80282402] ; [106.67507172,10.80017376]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"545"
    ,"Station_Code":"QPN 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà thờ Phú Nhuận"
    ,"Station_Address":"223, đường Trần Huy Liệu, Quận Phú Nhuận"
    ,"Lat":10.798715
    ,"Long":106.677528
    ,"Polyline":"[106.67507172,10.80017376] ; [106.67481232,10.79952526] ; [106.67754364,10.79929924] ; [106.67752838,10.79871464]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"549"
    ,"Station_Code":"QPN 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Công an Quận Phú Nhuận"
    ,"Station_Address":"139, đường Trần Huy Liệu, Quận Phú Nhuận"
    ,"Lat":10.796121
    ,"Long":106.677689
    ,"Polyline":"[106.67752838,10.79871464] ; [106.67768860,10.79612064]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"550"
    ,"Station_Code":"QPN 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã Tư Nguy ễn Văn Trỗi"
    ,"Station_Address":"91 - 93, đư ờng Trần Huy Liệu, Quận Phú Nhuận"
    ,"Lat":10.792667
    ,"Long":106.677887
    ,"Polyline":"[106.67768860,10.79612064] ; [106.67788696,10.79266739]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"552"
    ,"Station_Code":"QPN 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bệnh viện  An Sinh"
    ,"Station_Address":"25 - 27, đường Trần Huy Liệu, Quận Phú Nhuận"
    ,"Lat":10.791171
    ,"Long":106.677986
    ,"Polyline":"[106.67788696,10.79266739] ; [106.67797089,10.79200649] ; [106.67798615,10.79117107]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"554"
    ,"Station_Code":"Q3 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Lê Văn Sy ̃"
    ,"Station_Address":"19, đường Trần Quang Di ệu, Quận 3"
    ,"Lat":10.788544
    ,"Long":106.678123
    ,"Polyline":"[106.67798615,10.79117107] ; [106.67812347,10.78854370]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"557"
    ,"Station_Code":"Q3 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Nguyễn Văn Trỗi"
    ,"Station_Address":"217, đường Lê Văn Sỹ, Quận 3"
    ,"Lat":10.786577
    ,"Long":106.679787
    ,"Polyline":"[106.67812347,10.78854370] ; [106.67817688,10.78824329] ; [106.67822266,10.78763771] ; [106.67845917,10.78745365] ; [106.67926025,10.78696823] ; [106.67978668,10.78657722]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"559"
    ,"Station_Code":"Q3 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trần Quốc Thảo"
    ,"Station_Address":"12, đường Kỳ Đồng , Quận 3"
    ,"Lat":10.78456
    ,"Long":106.682868
    ,"Polyline":"[106.67978668,10.78657722] ; [106.68068695,10.78617764] ; [106.68292236,10.78498745] ; [106.68286896,10.78456020]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"561"
    ,"Station_Code":"Q3 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà thờ Dòng chúa Cứu thế"
    ,"Station_Address":"38, đường Kỳ Đồng, Quận 3"
    ,"Lat":10.780704
    ,"Long":106.681061
    ,"Polyline":"[106.68286896,10.78456020] ; [106.68285370,10.78416538] ; [106.68267822,10.78371716] ; [106.68252563,10.78342724] ; [106.68216705,10.78259468] ; [106.68188477,10.78211498] ; [106.68146515,10.78129292] ; [106.68106079,10.78070354]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"565"
    ,"Station_Code":"Q3 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nguyễn Thông"
    ,"Station_Address":"86, đường Nguyễn Thông, Quận 3"
    ,"Lat":10.781328
    ,"Long":106.679573
    ,"Polyline":"[106.68106079,10.78070354] ; [106.68101501,10.78051281] ; [106.68090057,10.78022861] ; [106.67988586,10.78078747] ; [106.67957306,10.78132820]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"560"
    ,"Station_Code":"Q3 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ga Hòa Hưng"
    ,"Station_Address":"Đối diện Trụ sở KP3, đường Nguyễn Phúc Nguy ên, Quận 3"
    ,"Lat":10.781528
    ,"Long":106.678383
    ,"Polyline":"[106.67957306,10.78132820] ; [106.67931366,10.78168869] ; [106.67906189,10.78206253] ; [106.67893219,10.78209972] ; [106.67875671,10.78207302] ; [106.67848206,10.78190422] ; [106.67842102,10.78179359] ; [106.67838287,10.78152847]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"566"
    ,"Station_Code":"Q3 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Rạch Bùng Binh"
    ,"Station_Address":"Đối diện 186 (167), đường Nguyễn Phúc Nguyên, Quận 3"
    ,"Lat":10.780455
    ,"Long":106.679184
    ,"Polyline":"[106.67838287,10.78152847] ; [106.67837524,10.78139877] ; [106.67826080,10.78105068] ; [106.67888641,10.78070259] ; [106.67918396,10.78045464]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"562"
    ,"Station_Code":"Q3 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Vòng xoay Dân Chủ"
    ,"Station_Address":"47 - 49, đường Nguyễn Phúc Nguyên, Quận 3"
    ,"Lat":10.778592
    ,"Long":106.681038
    ,"Polyline":"[106.67918396,10.78045464] ; [106.67950439,10.78034973] ; [106.67982483,10.78014374] ; [106.68050385,10.77951145] ; [106.68090820,10.77892208] ; [106.68103790,10.77859211]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"568"
    ,"Station_Code":"Q10 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Maximark"
    ,"Station_Address":"54, đường Đường 3/2, Quận 10"
    ,"Lat":10.777162
    ,"Long":106.680771
    ,"Polyline":"[106.68103790,10.77859211] ; [106.68146515,10.77811527] ; [106.68139648,10.77799988] ; [106.68134308,10.77788353] ; [106.68110657,10.77766228] ; [106.68061066,10.77689838]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"563"
    ,"Station_Code":"Q10 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"BV Bình Dân"
    ,"Station_Address":"172, đường Đường 3/2, Quận 10"
    ,"Lat":10.774785
    ,"Long":106.678947
    ,"Polyline":"[106.68061066,10.77689838] ; [106.68001556,10.77584934] ; [106.67960358,10.77529621] ; [106.67905426,10.77485275]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"95"
    ,"Station_Code":"Q10 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Học viện hành chính quốc gia"
    ,"Station_Address":"10, đường Đường 3/2, Quận 10"
    ,"Lat":10.773457
    ,"Long":106.676951
    ,"Polyline":"[106.67905426,10.77485275] ; [106.67783356,10.77399921] ; [106.67717743,10.77358341] ; [106.67671967,10.77335644]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"94"
    ,"Station_Code":"Q10 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Học viện hành chính quốc gia"
    ,"Station_Address":"Kế 10A, đường Đường 3/2, Quận 10"
    ,"Lat":10.772661
    ,"Long":106.675701
    ,"Polyline":"[106.67671967,10.77335644] ; [106.67572021,10.77264309]"
    ,"Distance":"135"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"97"
    ,"Station_Code":"Q10 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nhà hát Hòa Bình"
    ,"Station_Address":"240,  đường Đường 3/2, Quận 10"
    ,"Lat":10.771712
    ,"Long":106.674202
    ,"Polyline":"[106.67572021,10.77264309] ; [106.67420197,10.77171230]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"96"
    ,"Station_Code":"Q10 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Nhà thờ Vinh Sơn"
    ,"Station_Address":"270, đường  Đường 3/2, Quận 10"
    ,"Lat":10.770521
    ,"Long":106.67215
    ,"Polyline":"[106.67420197,10.77171230] ; [106.67306519,10.77098560] ; [106.67205811,10.77042961]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"99"
    ,"Station_Code":"Q10 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bệnh viện nhi đồng"
    ,"Station_Address":"356, đường Đường 3/2, Quận 10"
    ,"Lat":10.769578
    ,"Long":106.670364
    ,"Polyline":"[106.67205811,10.77042961] ; [106.67040253,10.76953030]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"564"
    ,"Station_Code":"Q10 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Học viện quân y"
    ,"Station_Address":"527 (257), đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.766769
    ,"Long":106.667259
    ,"Polyline":"[106.67040253,10.76953030] ; [106.66704559,10.76777554] ; [106.66725922,10.76676941]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"567"
    ,"Station_Code":"Q10 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Nhật Tảo"
    ,"Station_Address":"475, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.764991
    ,"Long":106.667664
    ,"Polyline":"[106.66725922,10.76676941] ; [106.66766357,10.76499081]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"570"
    ,"Station_Code":"Q10 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường Hoàng Văn Thụ"
    ,"Station_Address":"399, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.763371
    ,"Long":106.668015
    ,"Polyline":"[106.66766357,10.76499081] ; [106.66801453,10.76337147]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"571"
    ,"Station_Code":"Q10 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Đại học kinh tế"
    ,"Station_Address":"279, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.761049
    ,"Long":106.668488
    ,"Polyline":"[106.66801453,10.76337147] ; [106.66848755,10.76104927]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"569"
    ,"Station_Code":"Q5 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngô Gia Tự"
    ,"Station_Address":"500, đường Ng ô Gia Tự, Quận 5"
    ,"Lat":10.758801
    ,"Long":106.668062
    ,"Polyline":"[106.66848755,10.76104927] ; [106.66879272,10.76001835] ; [106.66874695,10.75994492] ; [106.66872406,10.75987625] ; [106.66874695,10.75970745] ; [106.66806030,10.75880146]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"573"
    ,"Station_Code":"Q5 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trung tâm giáo dục thường xuyên"
    ,"Station_Address":"546, đường Ngô Gia Tự, Qu ận 5"
    ,"Lat":10.757331
    ,"Long":106.667016
    ,"Polyline":"[106.66806030,10.75880146] ; [106.66701508,10.75733089]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Bệnh viện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng B àng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66701508,10.75733089] ; [106.66626740,10.75626087] ; [106.66451263,10.75589657]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66451263,10.75589657] ; [106.66107178,10.75519562]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107178,10.75519562] ; [106.65950012,10.75487518]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"397"
    ,"Station_Code":"Q5 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"81, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752445
    ,"Long":106.658792
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65824890,10.75461102] ; [106.65818787,10.75431633] ; [106.65879059,10.75244522]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.65879059,10.75244522] ; [106.65889740,10.75138092]"
    ,"Distance":"119"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"138"
    ,"Station_Code":"Q5 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Hải Thượng  Lãn Ông"
    ,"Station_Address":"210-212, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750948
    ,"Long":106.658358
    ,"Polyline":"[106.65889740,10.75138092] ; [106.65906525,10.75086403] ; [106.65835571,10.75094795]"
    ,"Distance":"139"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"139"
    ,"Station_Code":"Q5 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Chợ Kim Bi ên"
    ,"Station_Address":"5, đường Trang Tử, Quận 5"
    ,"Lat":10.751128
    ,"Long":106.655086
    ,"Polyline":"[106.65835571,10.75094795] ; [106.65741730,10.75097466] ; [106.65646362,10.75107479] ; [106.65576935,10.75105953] ; [106.65508270,10.75112820]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung,  Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65508270,10.75112820] ; [106.65386963,10.75112724] ; [106.65374756,10.75128078] ; [106.65341949,10.75163364] ; [106.65326691,10.75167561] ; [106.65310669,10.75147057] ; [106.65293884,10.75132751] ; [106.65256500,10.75125313]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27, đường Th áp Mười, Quận 6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65219879,10.75122738] ; [106.65200806,10.75114346] ; [106.65195465,10.75103760] ; [106.65097809,10.75103283] ; [106.64953613,10.75117016] ; [106.64939117,10.74966240] ; [106.65224457,10.75022125] ; [106.65255737,10.75023174] ; [106.65255737,10.75023174]"
    ,"Distance":"863"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"2393"
    ,"Station_Code":"Q6 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tháp Mười"
    ,"Station_Address":"13C-13D, đường Tháp Mười, Quận 6"
    ,"Lat":10.750326
    ,"Long":106.653036
    ,"Polyline":"[106.65255737,10.75023174] ; [106.65303802,10.75032616]"
    ,"Distance":"54"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"2"
    ,"Station_Code":"Q5 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"11-12, đường  Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750732
    ,"Long":106.655075
    ,"Polyline":"[106.65303802,10.75032616] ; [106.65451050,10.75070095] ; [106.65473175,10.75080109] ; [106.65492249,10.75076962] ; [106.65507507,10.75073242]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"14-16, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65507507,10.75073242] ; [106.65576935,10.75073719] ; [106.65645599,10.75083256] ; [106.65742493,10.75075340] ; [106.65830231,10.75073719] ; [106.65900421,10.75069046] ; [106.65909576,10.75061131] ; [106.65919495,10.75057983] ; [106.65930176,10.75059032] ; [106.65936279,10.75066948] ; [106.65936279,10.75079060] ; [106.65926361,10.75089073] ; [106.65921021,10.75112724] ; [106.65920258,10.75136757]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"5"
    ,"Station_Code":"Q5 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"68, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752566
    ,"Long":106.658937
    ,"Polyline":"[106.65920258,10.75136757] ; [106.65893555,10.75256634]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65893555,10.75256634] ; [106.65840912,10.75446892] ; [106.65923309,10.75455284]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"217, đ ường Hồng Bàng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.65923309,10.75455284] ; [106.66319275,10.75535965]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bệnh viện Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66319275,10.75535965] ; [106.66468048,10.75567055]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.66468048,10.75567055] ; [106.66963196,10.75666618] ; [106.66961670,10.75715065]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"441"
    ,"Station_Code":"Q5 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường Trần Khai Nguyên"
    ,"Station_Address":"138G-138F, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.758706
    ,"Long":106.66928
    ,"Polyline":"[106.66961670,10.75715065] ; [106.66928101,10.75870609]"
    ,"Distance":"177"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"442"
    ,"Station_Code":"Q10 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Đại học kinh tế"
    ,"Station_Address":"234-236, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.761386
    ,"Long":106.668564
    ,"Polyline":"[106.66928101,10.75870609] ; [106.66903687,10.75969696] ; [106.66909027,10.75978661] ; [106.66910553,10.75989723] ; [106.66905212,10.75999165] ; [106.66893768,10.76004982] ; [106.66856384,10.76138592]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"444"
    ,"Station_Code":"Q10 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường Hoàng Văn Thụ"
    ,"Station_Address":"336, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.763073
    ,"Long":106.668213
    ,"Polyline":"[106.66856384,10.76138592] ; [106.66821289,10.76307297]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"443"
    ,"Station_Code":"Q10 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Nhật Tảo"
    ,"Station_Address":"426, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.765397
    ,"Long":106.667702
    ,"Polyline":"[106.66821289,10.76307297] ; [106.66770172,10.76539707]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"446"
    ,"Station_Code":"Q10 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Học viện quân y"
    ,"Station_Address":"476,  đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.767052
    ,"Long":106.667313
    ,"Polyline":"[106.66770172,10.76539707] ; [106.66731262,10.76705170]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"158"
    ,"Station_Code":"Q10 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện nhi  đồng"
    ,"Station_Address":"Đối diện 350, đường Đường 3/2, Quận 10"
    ,"Lat":10.769518
    ,"Long":106.670609
    ,"Polyline":"[106.66731262,10.76705170] ; [106.66721344,10.76769161] ; [106.67060852,10.76951790]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"160"
    ,"Station_Code":"Q10 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà thờ Vinh  Sơn"
    ,"Station_Address":"273-275, đường Đường  3/2, Quận 10"
    ,"Lat":10.770269
    ,"Long":106.672166
    ,"Polyline":"[106.67060852,10.76951790] ; [106.67224884,10.77039719]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"159"
    ,"Station_Code":"Q10 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhà hát Hòa Bình"
    ,"Station_Address":"183A-183B, đường Đường 3/2, Quận 10"
    ,"Lat":10.771855
    ,"Long":106.674805
    ,"Polyline":"[106.67224884,10.77039719] ; [106.67311096,10.77085304] ; [106.67380524,10.77131176] ; [106.67476654,10.77188873]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"162"
    ,"Station_Code":"Q10 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Học viện  hành chính quốc gia"
    ,"Station_Address":"113 , đường Đường 3/2, Quận 10"
    ,"Lat":10.77323
    ,"Long":106.677015
    ,"Polyline":"[106.67476654,10.77188873] ; [106.67707062,10.77332211]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"445"
    ,"Station_Code":"Q10 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"BV Bình Dân"
    ,"Station_Address":"51, đường Đường 3 /2, Quận 10"
    ,"Lat":10.774421
    ,"Long":106.67885
    ,"Polyline":"[106.67707062,10.77332211] ; [106.67870331,10.77436829] ; [106.67911530,10.77444744]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"448"
    ,"Station_Code":"Q10 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Maximark"
    ,"Station_Address":"3, đường Đường 3/2, Quận 10"
    ,"Lat":10.776977
    ,"Long":106.68099
    ,"Polyline":"[106.67911530,10.77444744] ; [106.67935944,10.77480030] ; [106.67962646,10.77504826] ; [106.67992401,10.77542782] ; [106.68024445,10.77595520] ; [106.68098450,10.77707481]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"447"
    ,"Station_Code":"Q3 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà thờ Dòng chúa Cứu thế"
    ,"Station_Address":"25, đường Kỳ Đồng, Quận 3"
    ,"Lat":10.780805
    ,"Long":106.681305
    ,"Polyline":"[106.68098450,10.77707481] ; [106.68122864,10.77749920] ; [106.68144226,10.77765656] ; [106.68155670,10.77754116] ; [106.68171692,10.77754116] ; [106.68187714,10.77759933] ; [106.68196869,10.77775192] ; [106.68197632,10.77786255] ; [106.68193817,10.77799416] ; [106.68183136,10.77809429] ; [106.68168640,10.77813625] ; [106.68167877,10.77837849] ; [106.68212891,10.77946472] ; [106.68090820,10.78017044] ; [106.68130493,10.78080463]"
    ,"Distance":"613"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"451"
    ,"Station_Code":"Q3 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trần Quốc Thảo"
    ,"Station_Address":"5, đường Kỳ Đồng, Quận 3"
    ,"Lat":10.784504
    ,"Long":106.683022
    ,"Polyline":"[106.68130493,10.78080463] ; [106.68172455,10.78167248] ; [106.68200684,10.78217793] ; [106.68218994,10.78255749] ; [106.68240356,10.78298950] ; [106.68257141,10.78343773] ; [106.68270111,10.78364372] ; [106.68279266,10.78385448] ; [106.68292999,10.78425503] ; [106.68302155,10.78450394]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"449"
    ,"Station_Code":"Q3 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Nguyễn  Văn Trỗi"
    ,"Station_Address":"332 - 334, đường Lê Văn Sỹ, Quận 3"
    ,"Lat":10.787041
    ,"Long":106.679535
    ,"Polyline":"[106.68302155,10.78450394] ; [106.68299103,10.78496075] ; [106.68287659,10.78508186] ; [106.67953491,10.78704071]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"453"
    ,"Station_Code":"Q3 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trần Quang Diệu"
    ,"Station_Address":"24 - 26, đường  Trần Quang Diệu, Quận 3"
    ,"Lat":10.788373
    ,"Long":106.678299
    ,"Polyline":"[106.67953491,10.78704071] ; [106.67851257,10.78757954] ; [106.67828369,10.78766918] ; [106.67826843,10.78821182] ; [106.67829895,10.78837299]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"450"
    ,"Station_Code":"QPN 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh viện An Sinh"
    ,"Station_Address":"8, đường Trần Huy Liệu, Quận Phú Nhu ận"
    ,"Lat":10.791023
    ,"Long":106.678123
    ,"Polyline":"[106.67829895,10.78837299] ; [106.67812347,10.79102325]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"452"
    ,"Station_Code":"QPN 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã Tư Nguyễn Văn Trỗi"
    ,"Station_Address":"60, đường Trần Huy Liệu, Quận Phú Nhuận"
    ,"Lat":10.792923
    ,"Long":106.678001
    ,"Polyline":"[106.67812347,10.79102325] ; [106.67800140,10.79292297]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"252"
    ,"Station_Code":"QPN 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trung tâm văn hóa Quận Phú Nhuận"
    ,"Station_Address":"68, đường Nguyễn Văn Trỗi , Quận Phú Nhuận"
    ,"Lat":10.795452
    ,"Long":106.676034
    ,"Polyline":"[106.67800140,10.79292297] ; [106.67788696,10.79434586] ; [106.67604065,10.79549980]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"253"
    ,"Station_Code":"QPN 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Học viện Hàng kHông"
    ,"Station_Address":"104, đường Nguy ễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.79677
    ,"Long":106.673797
    ,"Polyline":"[106.67604065,10.79549980] ; [106.67557526,10.79571056] ; [106.67379761,10.79677010]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"254"
    ,"Station_Code":"QPN 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Bệnh viện Quận Phú Nhuận"
    ,"Station_Address":"142, đường Nguyễn Văn Trỗi, Quận Phú  Nhuận"
    ,"Lat":10.798456
    ,"Long":106.670911
    ,"Polyline":"[106.67379761,10.79677010.06.67091370]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"255"
    ,"Station_Code":"QPN 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cây xăng Quân khu 7"
    ,"Station_Address":"180, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.799642
    ,"Long":106.66891
    ,"Polyline":"[106.67091370,10.79845619] ; [106.66890717,10.79964161]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận  động Quân khu 7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66890717,10.79964161] ; [106.66764832,10.80027962] ; [106.66709900,10.80061626] ; [106.66662598,10.80095100]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"455"
    ,"Station_Code":"QTB 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Rạp Tân Sơn Nhất"
    ,"Station_Address":"2B (Hông sân vận động Quân Khu 7), đư ờng Phổ Quang, Quận Tân Bình"
    ,"Lat":10.80244
    ,"Long":106.665924
    ,"Polyline":"[106.66662598,10.80095100] ; [106.66598511,10.80136967] ; [106.66582489,10.80156994] ; [106.66572571,10.80179691] ; [106.66592407,10.80243969]"
    ,"Distance":"215"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"457"
    ,"Station_Code":"QTB 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trung tâm sát hạch lái xe"
    ,"Station_Address":"66 (Công ty Xe khách Sài Gòn), đường  Phổ Quang, Quận Tân Bình"
    ,"Lat":10.805417
    ,"Long":106.6667
    ,"Polyline":"[106.66592407,10.80243969] ; [106.66674805,10.80549812]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"454"
    ,"Station_Code":"QTB 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cây xăng Quân đội"
    ,"Station_Address":"96-100, đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.807221
    ,"Long":106.668495
    ,"Polyline":"[106.66674805,10.80549812] ; [106.66687012,10.80605412] ; [106.66822815,10.80588055] ; [106.66849518,10.80722141]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"456"
    ,"Station_Code":"QPN 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường Đại học Kỹ thuật Công nghệ"
    ,"Station_Address":"140, đường Phổ Quang, Quận Phú Nhuận"
    ,"Lat":10.808344
    ,"Long":106.671997
    ,"Polyline":"[106.66849518,10.80722141] ; [106.66870117,10.80873108] ; [106.67147064,10.80860519] ; [106.67160797,10.80858898] ; [106.67172241,10.80854702] ; [106.67199707,10.80834389]"
    ,"Distance":"539"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"459"
    ,"Station_Code":"QPN 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cuối công viên Gia Định"
    ,"Station_Address":"7, đường Hoàng Minh Giám,  Quận Phú Nhuận"
    ,"Lat":10.809727
    ,"Long":106.674929
    ,"Polyline":"[106.67199707,10.80834389] ; [106.67264557,10.80798340] ; [106.67286682,10.80794621] ; [106.67311096,10.80796719] ; [106.67329407,10.80803013] ; [106.67348480,10.80817223] ; [106.67376709,10.80848312] ; [106.67471313,10.80954838] ; [106.67492676,10.80972672]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"458"
    ,"Station_Code":"QPN 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã ba Đặng Văn Sâm"
    ,"Station_Address":"Ngã ba Đặng  Văn Sâm, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.811382
    ,"Long":106.676399
    ,"Polyline":"[106.67492676,10.80972672] ; [106.67567444,10.81060219] ; [106.67639923,10.81138229]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"461"
    ,"Station_Code":"QPN 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Đầu công  viên Gia Định"
    ,"Station_Address":"Cây xanh  số 7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.8135
    ,"Long":106.678222
    ,"Polyline":"[106.67639923,10.81138229] ; [106.67822266,10.81350040]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"56"
    ,"Station_Code":"QGV 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm đầu  Nguyễn Thái Sơn"
    ,"Station_Address":"36, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.815178
    ,"Long":106.679596
    ,"Polyline":"[106.67822266,10.81350040] ; [106.67861176,10.81402111] ; [106.67878723,10.81396389] ; [106.67891693,10.81398487] ; [106.67906189,10.81400585] ; [106.67918396,10.81410027] ; [106.67922211,10.81418991] ; [106.67919159,10.81432724] ; [106.67914581,10.81442738] ; [106.67904663,10.81452179] ; [106.67959595,10.81517792]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"59"
    ,"Station_Code":"QGV 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"90, đường  Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.81674
    ,"Long":106.680847
    ,"Polyline":"[106.67959595,10.81517792] ; [106.68084717,10.81674004]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"57"
    ,"Station_Code":"QGV 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"182 (148B), đường Nguyễn Thái Sơn, Qu ận Gò Vấp"
    ,"Lat":10.819923
    ,"Long":106.683378
    ,"Polyline":"[106.68084717,10.81674004] ; [106.68338013,10.81992340]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"460"
    ,"Station_Code":"QGV 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"246 (180), đường Nguyễn Thái Sơn, Qu ận Gò Vấp"
    ,"Lat":10.820508
    ,"Long":106.683828
    ,"Polyline":"[106.68338013,10.81992340] ; [106.68383026,10.82050800]"
    ,"Distance":"82"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"463"
    ,"Station_Code":"QGV 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"320, đường Nguyễn Thái Sơn, Quận Gò V ấp"
    ,"Lat":10.822789
    ,"Long":106.685636
    ,"Polyline":"[106.68383026,10.82050800] ; [106.68563843,10.82278919]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"462"
    ,"Station_Code":"QGV 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"UBND Phường 5, Quận Gò Vấp"
    ,"Station_Address":"396, đường Nguyễn  Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.82507
    ,"Long":106.687881
    ,"Polyline":"[106.68563843,10.82278919] ; [106.68699646,10.82462311] ; [106.68788147,10.82507038]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"7"
    ,"Station_Id":"468"
    ,"Station_Code":"BX43"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"BÃI HẬU CẦN SỐ 1"
    ,"Station_Address":"BÃI HẬU CẦN SỐ 1, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.82361125946045
    ,"Long":106.69189453125
    ,"Polyline":"[106.68788147,10.82507038] ; [106.68878937,10.82572937] ; [106.68930817,10.82626629] ; [106.69203186,10.82378006] ; [106.69189453,10.82361126]"
    ,"Distance":"636"
  }]