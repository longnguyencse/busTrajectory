export const Route20 =[
  {
     "Route_Id":"20"
    ,"Station_Id":"1185"
    ,"Station_Code":"BX 62"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Tân Quy"
    ,"Station_Address":"Bến xe Tân Quy, đường Tỉnh lộ 8, Củ Chi , Huyện Củ Chi"
    ,"Lat":10.984251
    ,"Long":106.578176
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1206"
    ,"Station_Code":"QCCT136"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã tư Tân Quy"
    ,"Station_Address":"121 (Kế 113), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.982632637023926
    ,"Long":106.5768814086914
    ,"Polyline":"[106.57740784,10.98397732] ; [106.57737732,10.98365021] ; [106.57649231,10.98371983] ; [106.57673645,10.98313046] ; [106.57688141,10.98263264]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1205"
    ,"Station_Code":"QCCT137"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty Hongwon"
    ,"Station_Address":"33 (37), đường Tỉnh lộ 15 Củ Chi, Huyện  Củ Chi"
    ,"Lat":10.97933292388916
    ,"Long":106.57929992675781
    ,"Polyline":"[106.57688141,10.98263264] ; [106.57744598,10.98128033] ; [106.57929993,10.97933292]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1207"
    ,"Station_Code":"QCCT138"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây xăng Quang Vinh"
    ,"Station_Address":"715, đường Ti ̉nh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.97605037689209
    ,"Long":106.58238220214844
    ,"Polyline":"[106.57929993,10.97933292] ; [106.58065796,10.97797012] ; [106.58238220,10.97605038]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1208"
    ,"Station_Code":"QCCT139"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cửa hàng sữa Việt Xuân"
    ,"Station_Address":"655, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.97331714630127
    ,"Long":106.58495330810547
    ,"Polyline":"[106.58238220,10.97605038] ; [106.58409882,10.97426987] ; [106.58495331,10.97331715]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1211"
    ,"Station_Code":"QCCT140"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường cấp 2 Tân Thạnh Đông"
    ,"Station_Address":"595-597, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.969300270080566
    ,"Long":106.58872985839844
    ,"Polyline":"[106.58618927,10.97208023] ; [106.58878326,10.96932030]"
    ,"Distance":"617"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1209"
    ,"Station_Code":"QCCT141"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Miếu Bà Chúa Xứ"
    ,"Station_Address":"565C (Đối diện 640A ), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.966816902160645
    ,"Long":106.59104919433594
    ,"Polyline":"[106.58872986,10.96930027] ; [106.58878326,10.96932030] ; [106.59104919,10.96681690]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1212"
    ,"Station_Code":"QCCT142"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cây xăng 57"
    ,"Station_Address":"509 (Đối diện 594C), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.963883399963379
    ,"Long":106.59383392333984
    ,"Polyline":"[106.59104919,10.96681690] ; [106.59169769,10.96619987] ; [106.59383392,10.96388340]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1210"
    ,"Station_Code":"HCC 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"455-457, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.961017
    ,"Long":106.596382
    ,"Polyline":"[106.59383392,10.96388340] ; [106.59510803,10.96255016] ; [106.59638214,10.96101665]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1214"
    ,"Station_Code":"QCCT144"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Sân banh"
    ,"Station_Address":"369, đường Ti ̉nh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.9552001953125
    ,"Long":106.60081481933594
    ,"Polyline":"[106.59838867,10.95872974] ; [106.59954071,10.95736980] ; [106.59986877,10.95689964] ; [106.60037231,10.95596981]"
    ,"Distance":"812"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1216"
    ,"Station_Code":"QCCT145"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Quán Hoa Sứ"
    ,"Station_Address":"301 (309) , đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.952767372131348
    ,"Long":106.60238647460938
    ,"Polyline":"[106.60081482,10.95520020] ; [106.60238647,10.95276737]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1213"
    ,"Station_Code":"QCCT146"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Chợ Sáng"
    ,"Station_Address":"195 (Đối diện  giáo xứ Tân Thạnh Đông), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.948100090026855
    ,"Long":106.60545349121094
    ,"Polyline":"[106.60238647,10.95276737] ; [106.60545349,10.94810009]"
    ,"Distance":"618"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1218"
    ,"Station_Code":"QCCT147"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Mẫu giáo Tân Thạnh Đông"
    ,"Station_Address":"163 (165B),  đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.94480037689209
    ,"Long":106.60528564453125
    ,"Polyline":"[106.60545349,10.94810009] ; [106.60604858,10.94727993] ; [106.60577393,10.94598484] ; [106.60528564,10.94480038]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1215"
    ,"Station_Code":"QCCT148"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 3 Bình Mỹ"
    ,"Station_Address":"19/4C, đường  Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.921882629394531
    ,"Long":106.60086822509766
    ,"Polyline":"[106.60485077,10.94367027] ; [106.60455322,10.94316006] ; [106.60430145,10.94281960] ; [106.60418701,10.94262028] ; [106.60414124,10.94235039] ; [106.60414124,10.94219971] ; [106.60424042,10.94161034] ; [106.60433197,10.94124985] ; [106.60436249,10.94099045] ; [106.60437012,10.94027996] ; [106.60436249,10.93947029] ; [106.60433197,10.93879986] ; [106.60420990,10.93795013] ; [106.60381317,10.93537998] ; [106.60360718,10.93424034] ; [106.60331726,10.93288040] ; [106.60244751,10.92881966] ; [106.60156250,10.92483044]"
    ,"Distance":"2622"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1222"
    ,"Station_Code":"HHM 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Cây xăng Tài Lộc 3"
    ,"Station_Address":"22/3A , đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.916642
    ,"Long":106.600326
    ,"Polyline":"[106.60086823,10.92188263] ; [106.60057831,10.92055988] ; [106.60057068,10.92035961] ; [106.60038757,10.91668034] ; [106.60031891,10.91520023] ; [106.59954071,10.91523647]"
    ,"Distance":"833"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1217"
    ,"Station_Code":"HHM 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã 3 Ông  Trác"
    ,"Station_Address":"59 , đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.912686
    ,"Long":106.599956
    ,"Polyline":"[106.59954071,10.91523647] ; [106.60031891,10.91520023] ; [106.60028076,10.91425991] ; [106.60018158,10.91312027] ; [106.59995270,10.91162014] ; [106.59965515,10.91013622] ; [106.59928131,10.91005325]"
    ,"Distance":"696"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1219"
    ,"Station_Code":"HHM 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Công ty  Nam Ho"
    ,"Station_Address":"6/9C, đường Đỗ V ăn Dậy, Huyện Hóc Môn"
    ,"Lat":10.910295
    ,"Long":106.599612
    ,"Polyline":"[106.59928131,10.91005325] ; [106.59964752,10.91006279] ; [106.59961700,10.90631008] ; [106.59963989,10.90445042] ; [106.59963989,10.90373993] ; [106.59939575,10.90374279]"
    ,"Distance":"770"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1220"
    ,"Station_Code":"HHM 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Bến Nọc"
    ,"Station_Address":"146/3, đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.908756
    ,"Long":106.599526
    ,"Polyline":"[106.59939575,10.90374279] ; [106.59960938,10.90356255] ; [106.59950256,10.90316200] ; [106.59965515,10.90198231] ; [106.59993744,10.90124512] ; [106.60008240,10.90067577] ; [106.60012817,10.89987564] ; [106.59982300,10.89909554] ; [106.59942627,10.89850712]"
    ,"Distance":"623"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1224"
    ,"Station_Code":"HHM 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 3 Cây Dông"
    ,"Station_Address":"88/3, đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.906502
    ,"Long":106.599494
    ,"Polyline":"[106.59954834,10.89846039] ; [106.59900665,10.89702034] ; [106.59876251,10.89643955]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1225"
    ,"Station_Code":"HHM 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trung tâm GDTX Hóc Môn"
    ,"Station_Address":"69/1D, đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.903394
    ,"Long":106.599462
    ,"Polyline":"[106.59876251,10.89643955] ; [106.59774017,10.89398003] ; [106.59745789,10.89330006]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1221"
    ,"Station_Code":"HHM 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà trẻ Phước An"
    ,"Station_Address":"49/2, đường Trương  Nữ Vương, Huyện Hóc Môn"
    ,"Lat":10.891174
    ,"Long":106.596535
    ,"Polyline":"[106.59745789,10.89330006] ; [106.59690857,10.89200020] ; [106.59664917,10.89130020] ; [106.59664154,10.89116955]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1223"
    ,"Station_Code":"HHM 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ Hóc Môn"
    ,"Station_Address":"29/2A, đường Trư ơng Nữ Vương, Huyện Hóc Môn"
    ,"Lat":10.889477
    ,"Long":106.596544
    ,"Polyline":"[106.59664154,10.89116955] ; [106.59658813,10.88957977] ; [106.59645844,10.88957977]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"4746"
    ,"Station_Code":"HHM 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Thị trần Hóc Môn"
    ,"Station_Address":"45/4, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.887638
    ,"Long":106.596147
    ,"Polyline":"[106.59646606,10.88956261] ; [106.59657288,10.88956070] ; [106.59651184,10.88841820] ; [106.59627533,10.88841248] ; [106.59622192,10.88801193] ; [106.59614563,10.88763809]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1226"
    ,"Station_Code":"HHM 197"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"36/5, đường Phan Văn Hớn,  Huyện Hóc Môn"
    ,"Lat":10.850861
    ,"Long":106.586051
    ,"Polyline":"[106.59614563,10.88763809] ; [106.59616852,10.88738537] ; [106.59612274,10.88705349] ; [106.59591675,10.88657665]"
    ,"Distance":"123"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1227"
    ,"Station_Code":"HHM 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Mần non 23-11"
    ,"Station_Address":"24, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.883945
    ,"Long":106.594635
    ,"Polyline":"[106.59594727,10.88656044] ; [106.59506226,10.88481998] ; [106.59480286,10.88428020] ; [106.59467316,10.88393021]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"4747"
    ,"Station_Code":"HHM 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh vi ện Hóc Môn"
    ,"Station_Address":"Đối diện 1/11A, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.883161
    ,"Long":106.594318
    ,"Polyline":"[106.59463501,10.88394547] ; [106.59438324,10.88316059] ; [106.59431458,10.88316059]"
    ,"Distance":"99"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1229"
    ,"Station_Code":"HHM 198"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"99A, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.84692
    ,"Long":106.591072
    ,"Polyline":"[106.59431458,10.88316059] ; [106.59436798,10.88313961] ; [106.59403992,10.88230705] ; [106.59397125,10.88235474]"
    ,"Distance":"115"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1228"
    ,"Station_Code":"HHM 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã tư Giếng Nước"
    ,"Station_Address":"106, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.878356
    ,"Long":106.592054
    ,"Polyline":"[106.59403992,10.88232994] ; [106.59369659,10.88142967] ; [106.59336090,10.88068008] ; [106.59259796,10.87884045] ; [106.59250641,10.87868977] ; [106.59236908,10.87856007] ; [106.59219360,10.87841988]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1230"
    ,"Station_Code":"HHM 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cây xăng Thành Công"
    ,"Station_Address":"Cây  xăng Thành Công, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.877018
    ,"Long":106.591635
    ,"Polyline":"[106.59205627,10.87835598] ; [106.59140015,10.87782001] ; [106.59130096,10.87758160] ; [106.59167480,10.87711811] ; [106.59163666,10.87701797]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1232"
    ,"Station_Code":"HHM 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Miểu Con Mèo"
    ,"Station_Address":"42/7B, đ ường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.871902
    ,"Long":106.595306
    ,"Polyline":"[106.59172821,10.87714958] ; [106.59541321,10.87197018]"
    ,"Distance":"735"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1231"
    ,"Station_Code":"HHM 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã 3 Bùi M ôn"
    ,"Station_Address":"43/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.868887
    ,"Long":106.597473
    ,"Polyline":"[106.59541321,10.87197018] ; [106.59622955,10.87077045] ; [106.59658051,10.87028980] ; [106.59755707,10.86894035]"
    ,"Distance":"436"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1235"
    ,"Station_Code":"HHM 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường học Tân Xuân"
    ,"Station_Address":"58 /6, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.865924
    ,"Long":106.599602
    ,"Polyline":"[106.59755707,10.86894035] ; [106.59967804,10.86596966]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1233"
    ,"Station_Code":"HHM 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Xí nghi ệp phân bón Hóc Môn"
    ,"Station_Address":"114, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.861867
    ,"Long":106.602356
    ,"Polyline":"[106.59967804,10.86596966] ; [106.60108948,10.86394024] ; [106.60241699,10.86209011] ; [106.60250854,10.86196041]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1234"
    ,"Station_Code":"HHM 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 3 Củ Cải"
    ,"Station_Address":"13/1, đường Quốc lộ 22, Huy ện Hóc Môn"
    ,"Lat":10.859233
    ,"Long":106.604295
    ,"Polyline":"[106.60235596,10.86186695] ; [106.60250854,10.86196041] ; [106.60305786,10.86112022] ; [106.60429382,10.85923290]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1236"
    ,"Station_Code":"HHM 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã ba Nguyễn Thị Sóc"
    ,"Station_Address":"43/5, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.857373
    ,"Long":106.605669
    ,"Polyline":"[106.60429382,10.85923290] ; [106.60566711,10.85737324]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"3635"
    ,"Station_Code":"HHM 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chùa Linh Sơn"
    ,"Station_Address":"G68A , đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.85554
    ,"Long":106.606779
    ,"Polyline":"[106.60566711,10.85737324] ; [106.60575867,10.85744667] ; [106.60691071,10.85562420] ; [106.60678101,10.85554028]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1393"
    ,"Station_Code":"HHM 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã tư Nguy ễn Ảnh Thủ"
    ,"Station_Address":"30/10B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854628
    ,"Long":106.607476
    ,"Polyline":"[106.60678101,10.85554028] ; [106.60689545,10.85563469] ; [106.60753632,10.85471725] ; [106.60747528,10.85462761]"
    ,"Distance":"152"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1237"
    ,"Station_Code":"QHMT229"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Quán ăn xuyên Á, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854108810424805
    ,"Long":106.60777282714844
    ,"Polyline":"[106.60747528,10.85462761] ; [106.60781860,10.85417461] ; [106.60777283,10.85410881]"
    ,"Distance":"72"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1238"
    ,"Station_Code":"HHM 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"3A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.850092
    ,"Long":106.610395
    ,"Polyline":"[106.60787964,10.85418034] ; [106.61047363,10.85015011]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61047363,10.85015011] ; [106.61290741,10.84638023] ; [106.61396027,10.84473038]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"B ến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61384583,10.84465027] ; [106.61390686,10.84472847] ; [106.61408234,10.84449100] ; [106.61326599,10.84382725] ; [106.61337280,10.84373760]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61337280,10.84373760] ; [106.61406708,10.84424400] ; [106.61536407,10.84227371] ; [106.61569214,10.84249496] ; [106.61401367,10.84493923]"
    ,"Distance":"728"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1151"
    ,"Station_Code":"Q12 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cây xăng  Quân Đội"
    ,"Station_Address":"2, đường Quốc  lộ 22, Quận 12"
    ,"Lat":10.850034
    ,"Long":106.610845
    ,"Polyline":"[106.61401367,10.84493923] ; [106.61078644,10.84997559]"
    ,"Distance":"662"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1152"
    ,"Station_Code":"Q12 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Trung tâm văn hóa Quận 12, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.854892
    ,"Long":106.607718
    ,"Polyline":"[106.61073303,10.84994030] ; [106.60878754,10.85293961] ; [106.60819244,10.85389042] ; [106.60761261,10.85480976]"
    ,"Distance":"652"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1154"
    ,"Station_Code":"HHM 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Liên đoàn lao động Hóc Môn"
    ,"Station_Address":"69/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.855756
    ,"Long":106.607198
    ,"Polyline":"[106.60761261,10.85480976] ; [106.60710144,10.85558987]"
    ,"Distance":"130"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1153"
    ,"Station_Code":"HHM 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cây xăng Củ Cải"
    ,"Station_Address":"33/4, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.859054
    ,"Long":106.604869
    ,"Polyline":"[106.60710144,10.85558987] ; [106.60597229,10.85727978] ; [106.60545349,10.85801029] ; [106.60475159,10.85900974]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1156"
    ,"Station_Code":"HHM 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã 3 Củ Cải"
    ,"Station_Address":"8/6B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.861856
    ,"Long":106.602844
    ,"Polyline":"[106.60475159,10.85900974] ; [106.60276031,10.86180973]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1155"
    ,"Station_Code":"HHM 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường học Tân Xuân"
    ,"Station_Address":"44A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.865945
    ,"Long":106.599972
    ,"Polyline":"[106.60276031,10.86180973] ; [106.60131836,10.86382008] ; [106.59986877,10.86587048]"
    ,"Distance":"576"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1158"
    ,"Station_Code":"HHM 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã 3 Bùi Môn"
    ,"Station_Address":"1/1, đư ờng Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.869901
    ,"Long":106.597206
    ,"Polyline":"[106.59986877,10.86587048] ; [106.59706879,10.86981010]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1160"
    ,"Station_Code":"HHM 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 3 Bùi Môn"
    ,"Station_Address":"3/19, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.872535
    ,"Long":106.595305
    ,"Polyline":"[106.59706879,10.86981010.06.59520721]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1157"
    ,"Station_Code":"HHM 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cây xăng Thành Công - Ngã tư Giếng Nước"
    ,"Station_Address":"3/88C, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.877313
    ,"Long":106.591855
    ,"Polyline":"[106.59520721,10.87244987] ; [106.59176636,10.87730980]"
    ,"Distance":"683"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"4751"
    ,"Station_Code":"HHM 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã tư Giếng nước"
    ,"Station_Address":"2/16A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.87765
    ,"Long":106.591598
    ,"Polyline":"[106.59185791,10.87731266] ; [106.59159851,10.87765026]"
    ,"Distance":"47"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"4586"
    ,"Station_Code":"HHM 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã tư Giếng nước"
    ,"Station_Address":"3/88C, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.87803
    ,"Long":106.591882
    ,"Polyline":"[106.59159851,10.87765026] ; [106.59146118,10.87776089] ; [106.59181976,10.87804508] ; [106.59188080,10.87802982]"
    ,"Distance":"76"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1162"
    ,"Station_Code":"HHM 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Bệnh viện Hóc Môn"
    ,"Station_Address":"77 /4, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.88246
    ,"Long":106.5942
    ,"Polyline":"[106.59188080,10.87802982] ; [106.59265137,10.87871933] ; [106.59294128,10.87920475] ; [106.59420013,10.88245964]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1164"
    ,"Station_Code":"HHM 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường mầm  non 23-11"
    ,"Station_Address":"84/2A, đường  Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.88433
    ,"Long":106.594929
    ,"Polyline":"[106.59420013,10.88245964] ; [106.59493256,10.88432980]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1161"
    ,"Station_Code":"HHM 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Thị trấn Hóc Môn"
    ,"Station_Address":"98/2, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.8867
    ,"Long":106.596077
    ,"Polyline":"[106.59493256,10.88432980] ; [106.59607697,10.88669968]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1166"
    ,"Station_Code":"HHM 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Hóc Môn"
    ,"Station_Address":"8/2, đường Tr ương Nữ Vương, Huyện Hóc Môn"
    ,"Lat":10.889699
    ,"Long":106.596817
    ,"Polyline":"[106.59607697,10.88669968] ; [106.59617615,10.88697433] ; [106.59626007,10.88744831] ; [106.59626770,10.88783360] ; [106.59633636,10.88833904] ; [106.59661102,10.88834953] ; [106.59669495,10.88965607] ; [106.59681702,10.88969898]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1163"
    ,"Station_Code":"HHM 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhà trẻ Phước An"
    ,"Station_Address":"21/1, đường Trương Nữ Vương, Huyện Hóc Môn"
    ,"Lat":10.891384
    ,"Long":106.596817
    ,"Polyline":"[106.59681702,10.88969898] ; [106.59664917,10.88969803] ; [106.59674072,10.89134693] ; [106.59700775,10.89131069]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1165"
    ,"Station_Code":"HHM 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Tung tâm GDTX Hóc Môn"
    ,"Station_Address":"Đối diện 27, đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.894002
    ,"Long":106.597901
    ,"Polyline":"[106.59700775,10.89131069] ; [106.59679413,10.89136314] ; [106.59793091,10.89410210.06.59814453]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1168"
    ,"Station_Code":"HHM 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã 3 Cây Dông"
    ,"Station_Address":"25/2, đường Đỗ V ăn Dậy, Huyện Hóc Môn"
    ,"Lat":10.895914
    ,"Long":106.598861
    ,"Polyline":"[106.59814453,10.89397621] ; [106.59787750,10.89408112] ; [106.59863281,10.89593506] ; [106.59897614,10.89581013]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1167"
    ,"Station_Code":"HHM 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trung tâm dạy nghề Hóc Môn"
    ,"Station_Address":"27/6C, đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.899265
    ,"Long":106.600151
    ,"Polyline":"[106.59897614,10.89581013] ; [106.59867859,10.89594555] ; [106.59996796,10.89926434] ; [106.60015106,10.89926529]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1170"
    ,"Station_Code":"HHM 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty Nam Ho"
    ,"Station_Address":"1/3B, đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.905169
    ,"Long":106.599741
    ,"Polyline":"[106.60015106,10.89926529] ; [106.60021210,10.90006447] ; [106.59997559,10.90135002] ; [106.59980774,10.90223503] ; [106.59980774,10.90373135] ; [106.59971619,10.90505886] ; [106.59996796,10.90512276]"
    ,"Distance":"678"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1169"
    ,"Station_Code":"HHM 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã 3 Ông Trác"
    ,"Station_Address":"10/4, đường Đỗ Văn Dậy, Huyện Hóc Môn"
    ,"Lat":10.912012
    ,"Long":106.600095
    ,"Polyline":"[106.59963226,10.90511990] ; [106.59961700,10.90631008] ; [106.59961700,10.90993977] ; [106.59989929,10.91141987]"
    ,"Distance":"825"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1172"
    ,"Station_Code":"HHM 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cây xăng Tài Lộc 3"
    ,"Station_Address":"98, đường Đỗ Văn Dậy, Huyện H óc Môn"
    ,"Lat":10.917147
    ,"Long":106.600497
    ,"Polyline":"[106.59989929,10.91141987] ; [106.60018158,10.91312027] ; [106.60028076,10.91425991] ; [106.60034180,10.91559029]"
    ,"Distance":"596"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1171"
    ,"Station_Code":"HCC 251"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã 3 Bình Mỹ"
    ,"Station_Address":"Đối diện 19/4C (Cây xăng Đại Phát Tài), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.92135
    ,"Long":106.600777
    ,"Polyline":"[106.60074615,10.91557312] ; [106.60038757,10.91553020] ; [106.60063934,10.92041874] ; [106.60077667,10.92134953]"
    ,"Distance":"689"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1173"
    ,"Station_Code":"QCCT057"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường mẫu giáo Tân Thạnh Đông"
    ,"Station_Address":"218 (Trường mẫu giáo Bông Sen 15), đường Tỉnh lộ 15 Củ Chi, Huy ện Củ Chi"
    ,"Lat":10.943817138671875
    ,"Long":106.60494995117188
    ,"Polyline":"[106.60077667,10.92134953] ; [106.60347748,10.93343925] ; [106.60416412,10.93714714] ; [106.60459137,10.93988514] ; [106.60429382,10.94254017] ; [106.60494995,10.94381714]"
    ,"Distance":"2562"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1174"
    ,"Station_Code":"HCC 253"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chợ Sáng"
    ,"Station_Address":"Gi áo xứ Tân Thạnh Đông, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.9484
    ,"Long":106.605347
    ,"Polyline":"[106.60494995,10.94381714] ; [106.60583496,10.94588947] ; [106.60617828,10.94725895] ; [106.60534668,10.94839954]"
    ,"Distance":"563"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1176"
    ,"Station_Code":"HCC 254"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Quán Hoa Sứ"
    ,"Station_Address":"318, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.952317
    ,"Long":106.602753
    ,"Polyline":"[106.60534668,10.94839954] ; [106.60334015,10.95139027] ; [106.60275269,10.95231724]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1175"
    ,"Station_Code":"HCC 255"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"San banh"
    ,"Station_Address":"422, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.955767
    ,"Long":106.600517
    ,"Polyline":"[106.60275269,10.95231724] ; [106.60112762,10.95475960] ; [106.60063934,10.95553970] ; [106.60051727,10.95576668]"
    ,"Distance":"455"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1177"
    ,"Station_Code":"HCC 256"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"UBND Tân Thạnh Đông"
    ,"Station_Address":"542A (544A),  đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.961517
    ,"Long":106.59608
    ,"Polyline":"[106.60051727,10.95576668] ; [106.60037994,10.95592976] ; [106.60005188,10.95654964] ; [106.59986877,10.95689964] ; [106.59969330,10.95716953] ; [106.59899902,10.95800972] ; [106.59741974,10.95987988] ; [106.59607697,10.96151733]"
    ,"Distance":"805"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1178"
    ,"Station_Code":"QCCT062"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cây xăng  57"
    ,"Station_Address":"604A, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.964282989501953
    ,"Long":106.59353637695312
    ,"Polyline":"[106.59607697,10.96151733] ; [106.59525299,10.96240044] ; [106.59449005,10.96321011] ; [106.59353638,10.96428299]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1179"
    ,"Station_Code":"QCCT063"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Hố Bom"
    ,"Station_Address":"634B, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.966300010681152
    ,"Long":106.5916519165039
    ,"Polyline":"[106.59353638,10.96428299] ; [106.59165192,10.96630001]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1180"
    ,"Station_Code":"QCCT064"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường cấp 2 Tân Thạnh Đông"
    ,"Station_Address":"718 (706), đường Tỉnh lộ 15  Củ Chi, Huyện Củ Chi"
    ,"Lat":10.969499588012695
    ,"Long":106.58865356445312
    ,"Polyline":"[106.59165192,10.96630001] ; [106.59116364,10.96677017] ; [106.58865356,10.96949959]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1181"
    ,"Station_Code":"QCCT065"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Cửa hàng  sữa Việt Xuân"
    ,"Station_Address":"806, đường  Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.973816871643066
    ,"Long":106.58460235595703
    ,"Polyline":"[106.58776855,10.97041035] ; [106.58521271,10.97311020]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1182"
    ,"Station_Code":"QCCT066"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cây xăng Quang Vinh"
    ,"Station_Address":"858, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.976567268371582
    ,"Long":106.58201599121094
    ,"Polyline":"[106.58460236,10.97381687] ; [106.58354187,10.97488976] ; [106.58201599,10.97656727]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1183"
    ,"Station_Code":"QCCT067"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Công ty Hongwon"
    ,"Station_Address":"930, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.980067253112793
    ,"Long":106.57872009277344
    ,"Polyline":"[106.58201599,10.97656727] ; [106.58104706,10.97756004] ; [106.57872009,10.98006725]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1184"
    ,"Station_Code":"QCCT068"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã tư Tân Quy"
    ,"Station_Address":"964 (970), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.982236862182617
    ,"Long":106.57717895507812
    ,"Polyline":"[106.57872009,10.98006725] ; [106.57782745,10.98097992] ; [106.57744598,10.98151207] ; [106.57717896,10.98223686]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"20"
    ,"Station_Id":"1185"
    ,"Station_Code":"BX 62"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Bến xe Tân Quy"
    ,"Station_Address":"Bến xe Tân Quy , đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.984251
    ,"Long":106.578176
    ,"Polyline":"[106.57717896,10.98223686] ; [106.57689667,10.98274040] ; [106.57649231,10.98371983] ; [106.57737732,10.98365021] ; [106.57740784,10.98397732]"
    ,"Distance":"315"
  }]