export const Route111 =[

  {
     "Route_Id":"111"
    ,"Station_Id":"3600"
    ,"Station_Code":"BX 59"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Phật Cô Đơn"
    ,"Station_Address":"ĐẦU BẾN PHẬT CÔ ĐƠN, đường Mai Bá Hư ơng, Huyện Bình Chánh"
    ,"Lat":10.756245
    ,"Long":106.489281
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3602"
    ,"Station_Code":"HBC 337"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Thất Thất Lê Minh Xuân"
    ,"Station_Address":"Đối diện Đại Đạo Tam Kỳ, đường Mai B á Hương, Huyện Bình Chánh"
    ,"Lat":10.761995
    ,"Long":106.494851
    ,"Polyline":"[106.48854828,10.75716019] ; [106.49510193,10.76206017]"
    ,"Distance":"900"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3606"
    ,"Station_Code":"HBC 338"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trần Đại Nghĩa"
    ,"Station_Address":"Đối diện Cột  điện 70P, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.764192
    ,"Long":106.497785
    ,"Polyline":"[106.49510193,10.76206017] ; [106.49745178,10.76381969] ; [106.49793243,10.76414013]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3603"
    ,"Station_Code":"HBC 339"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trần Đại Nghĩa"
    ,"Station_Address":"A12/8, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.765847
    ,"Long":106.499898
    ,"Polyline":"[106.49793243,10.76414013] ; [106.49877930,10.76471043] ; [106.49893951,10.76496029] ; [106.49923706,10.76552963] ; [106.49932098,10.76562977] ; [106.49976349,10.76587963] ; [106.49994659,10.76599026]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3604"
    ,"Station_Code":"HBC 340"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Công ty Thịnh Mỹ"
    ,"Station_Address":"A11/20, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.767871
    ,"Long":106.502704
    ,"Polyline":"[106.49994659,10.76599026] ; [106.50097656,10.76663971] ; [106.50270844,10.76799011]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3607"
    ,"Station_Code":"HBC 341"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Công ty Minh Chương"
    ,"Station_Address":"A11/1, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.771481
    ,"Long":106.507452
    ,"Polyline":"[106.50270844,10.76799011] ; [106.50631714,10.77079010.06.50737000]"
    ,"Distance":"651"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3605"
    ,"Station_Code":"HBC 342"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Học viện Phật giáo Việt Nam"
    ,"Station_Address":"A10/8A, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.775665
    ,"Long":106.511008
    ,"Polyline":"[106.50737000,10.77163029] ; [106.50884247,10.77280998] ; [106.50981903,10.77385044] ; [106.50997162,10.77400970] ; [106.51074982,10.77538967] ; [106.51087952,10.77571964]"
    ,"Distance":"604"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3608"
    ,"Station_Code":"HBC 343"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Phật Cô Đơn"
    ,"Station_Address":"Đối diện bãi giữ xe Phật Cô Đơn, đường Mai Bá Hương, Huyện Bình  Chánh"
    ,"Lat":10.781556
    ,"Long":106.512827
    ,"Polyline":"[106.51087952,10.77571964] ; [106.51159668,10.77777958] ; [106.51264191,10.78160954]"
    ,"Distance":"683"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3609"
    ,"Station_Code":"HBC 344"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty Hoàng Long Anh"
    ,"Station_Address":"A8/27, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.784529
    ,"Long":106.513503
    ,"Polyline":"[106.51264191,10.78160954] ; [106.51336670,10.78458023]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3610"
    ,"Station_Code":"HBC 345"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Tỉnh lộ 10"
    ,"Station_Address":"A8/4, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.787928
    ,"Long":106.514297
    ,"Polyline":"[106.51336670,10.78458023] ; [106.51399994,10.78711033]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3436"
    ,"Station_Code":"HBC 294"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Bãi cát cầu Rau Răm"
    ,"Station_Address":"Đối diện 3A/63 TTH Cầu Xáng, đường Tỉnh  lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.788676
    ,"Long":106.515541
    ,"Polyline":"[106.51399994,10.78711033] ; [106.51454163,10.78925037] ; [106.51548004,10.78878975]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3437"
    ,"Station_Code":"HBC 295"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã 3  Vườn Thơm"
    ,"Station_Address":"Đối diện 3A35 /3, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.787622
    ,"Long":106.517472
    ,"Polyline":"[106.51548004,10.78878975] ; [106.51743317,10.78777027]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3438"
    ,"Station_Code":"HBC 290"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cầu Xáng"
    ,"Station_Address":"Đối diện 3A.11, đường Tỉnh lộ 10 Bình  Chánh, Huyện Bình Chánh"
    ,"Lat":10.786463
    ,"Long":106.519908
    ,"Polyline":"[106.51743317,10.78777027] ; [106.51773071,10.78763008] ; [106.51766205,10.78752995] ; [106.51872253,10.78699970] ; [106.51989746,10.78641033]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3439"
    ,"Station_Code":"HBC 296"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà thờ chợ Cầu Xáng"
    ,"Station_Address":"đối diện 2A/94, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.78465
    ,"Long":106.523491
    ,"Polyline":"[106.51989746,10.78641033] ; [106.52124786,10.78573990] ; [106.52288055,10.78493023] ; [106.52351379,10.78460979]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3440"
    ,"Station_Code":"HBC 297"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Đa khoa Sài Gòn"
    ,"Station_Address":"Đối diện 2A/63, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.783253
    ,"Long":106.526383
    ,"Polyline":"[106.52351379,10.78460979] ; [106.52629852,10.78320980]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3441"
    ,"Station_Code":"HBC 298"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"CTY giống cây trồng TPHCM"
    ,"Station_Address":"đối diện CTY giống cây trồng TPHCM, đường Tỉnh lộ 10  Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.781425
    ,"Long":106.529918
    ,"Polyline":"[106.52629852,10.78320980] ; [106.52935028,10.78168964] ; [106.52992249,10.78139019]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3442"
    ,"Station_Code":"HBC 299"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Kênh A"
    ,"Station_Address":"Đối diện 2A/27/1, đường Tỉnh lộ 10 Bình  Chánh, Huyện Bình Chánh"
    ,"Lat":10.779949
    ,"Long":106.532804
    ,"Polyline":"[106.52992249,10.78139019] ; [106.53099060,10.78085995] ; [106.53231049,10.78024006] ; [106.53237152,10.78036976] ; [106.53259277,10.78026962] ; [106.53292084,10.78013039]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3443"
    ,"Station_Code":"HBC 300"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Xã Lê Minh Xuân"
    ,"Station_Address":"Đối diện 2A/2, đường Tỉnh lộ 10 Bình Ch ánh, Huyện Bình Chánh"
    ,"Lat":10.776566
    ,"Long":106.539595
    ,"Polyline":"[106.53292084,10.78013039] ; [106.53328705,10.77993011] ; [106.53321075,10.77976990] ; [106.53347015,10.77964020] ; [106.53486633,10.77892971] ; [106.53560638,10.77855015] ; [106.53719330,10.77777004] ; [106.53849792,10.77711010.06.53968811] ; [10.77649975,106.53959656]"
    ,"Distance":"887"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3444"
    ,"Station_Code":"HBC 301"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cầu Bà Lát"
    ,"Station_Address":"Đối diện 1A59/1, đường Trần Văn Giàu, Huy ện Bình Chánh"
    ,"Lat":10.769889
    ,"Long":106.552851
    ,"Polyline":"[106.53959656,10.77630043] ; [106.53968811,10.77649975] ; [106.54033661,10.77618027] ; [106.54135895,10.77567005] ; [106.54357147,10.77453995] ; [106.54714966,10.77272987]"
    ,"Distance":"941"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3613"
    ,"Station_Code":"HBC 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Vĩnh Lộc"
    ,"Station_Address":"1A.96/1, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.77216
    ,"Long":106.551971
    ,"Polyline":"[106.54714966,10.77272987] ; [106.54936981,10.77159977] ; [106.55081177,10.77087021] ; [106.55137634,10.77058983] ; [106.55145264,10.77071953] ; [106.55168915,10.77066040] ; [106.55178070,10.77130985] ; [106.55191040,10.77219963]"
    ,"Distance":"736"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3611"
    ,"Station_Code":"HBC 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Công ty  Hùng Tuấn"
    ,"Station_Address":"1A.120, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.775944
    ,"Long":106.552588
    ,"Polyline":"[106.55191040,10.77219963] ; [106.55227661,10.77466011] ; [106.55252838,10.77598000]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3612"
    ,"Station_Code":"HBC 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty Bảo Huy"
    ,"Station_Address":"1A/148 , đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.780213
    ,"Long":106.553307
    ,"Polyline":"[106.55252838,10.77598000] ; [106.55301666,10.77915955]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3615"
    ,"Station_Code":"HBC 157"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu B à Tri"
    ,"Station_Address":"1A/163, đường Vĩnh  Lộc, Huyện Bình Chánh"
    ,"Lat":10.78553
    ,"Long":106.554127
    ,"Polyline":"[106.55301666,10.77915955] ; [106.55341339,10.78174019]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3614"
    ,"Station_Code":"HBC 158"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Kinh Trung Ương"
    ,"Station_Address":"888, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.790151
    ,"Long":106.555291
    ,"Polyline":"[106.55341339,10.78174019] ; [106.55407715,10.78602982]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3617"
    ,"Station_Code":"HBC 159"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Rửa xe Hải Trí"
    ,"Station_Address":"Rửa xe Hải Trí, đường Vĩnh  Lộc, Huyện Bình Chánh"
    ,"Lat":10.792934
    ,"Long":106.556536
    ,"Polyline":"[106.55407715,10.78602982] ; [106.55448151,10.78843975] ; [106.55519867,10.79026985]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3616"
    ,"Station_Code":"HBC 142"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm xăng Hiệp Hòa"
    ,"Station_Address":"F1/11, đường  Hương Lộ 80, Huyện Bình Chánh"
    ,"Lat":10.795379
    ,"Long":106.557888
    ,"Polyline":"[106.55519867,10.79026985] ; [106.55551147,10.79098988] ; [106.55609894,10.79222965] ; [106.55663300,10.79353046] ; [106.55687714,10.79415035] ; [106.55719757,10.79477978] ; [106.55777740,10.79547024]"
    ,"Distance":"647"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3619"
    ,"Station_Code":"HBC 143"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"UB xã Vĩnh  Lộc B"
    ,"Station_Address":"1330, đường Hương Lộ 80, Huyện Bình Chánh"
    ,"Lat":10.799304
    ,"Long":106.561031
    ,"Polyline":"[106.55777740,10.79547024] ; [106.55860138,10.79646015] ; [106.55991364,10.79811001] ; [106.56002045,10.79819965] ; [106.56059265,10.79893017]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3618"
    ,"Station_Code":"HBC 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Công ty Hợp Nhất"
    ,"Station_Address":"1482, đường Hương Lộ 80, Huyện Bình Chánh"
    ,"Lat":10.803794
    ,"Long":106.564599
    ,"Polyline":"[106.56059265,10.79893017] ; [106.56401825,10.80323982]"
    ,"Distance":"608"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3620"
    ,"Station_Code":"HBC 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm xăng Lan Anh"
    ,"Station_Address":"1860, đường H ương Lộ 80, Huyện Bình Chánh"
    ,"Lat":10.806539
    ,"Long":106.568246
    ,"Polyline":"[106.56401825,10.80323982] ; [106.56439209,10.80370045] ; [106.56504059,10.80453014] ; [106.56522369,10.80469990] ; [106.56555176,10.80496025] ; [106.56649780,10.80554962] ; [106.56762695,10.80626011] ; [106.56823730,10.80661964]"
    ,"Distance":"602"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"2367"
    ,"Station_Code":"HBC 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"KDC Vĩnh Lộc A"
    ,"Station_Address":"1998, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.809158
    ,"Long":106.572393
    ,"Polyline":"[106.56823730,10.80661964] ; [106.56934357,10.80733967] ; [106.57025146,10.80790043] ; [106.57112885,10.80842972] ; [106.57176208,10.80885983] ; [106.57238007,10.80924034]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"2366"
    ,"Station_Code":"HBC 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã 5 Vĩnh Lộc"
    ,"Station_Address":"2170, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.811023
    ,"Long":106.575338
    ,"Polyline":"[106.57238007,10.80924034] ; [106.57337952,10.80986023] ; [106.57356262,10.80996990] ; [106.57399750,10.81023979] ; [106.57479095,10.81077003] ; [106.57534790,10.81110954]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3102"
    ,"Station_Code":"QBT 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm giữa Vĩnh Lộc"
    ,"Station_Address":"Đối diện F9/6 (Châu Phú Mỹ), đường Phan  Văn Đối, Quận Bình Tân"
    ,"Lat":10.818697
    ,"Long":106.58548
    ,"Polyline":"[106.57534790,10.81110954] ; [106.57701111,10.81215954] ; [106.57759857,10.81252956] ; [106.57810211,10.81287003] ; [106.57917023,10.81359005] ; [106.57956696,10.81379032] ; [106.57962036,10.81387997] ; [106.58019257,10.81427002] ; [106.58116913,10.81499958] ; [106.58184814,10.81556988] ; [106.58226013,10.81591988] ; [106.58245850,10.81606007] ; [106.58332825,10.81684971] ; [106.58540344,10.81863022] ; [106.58542633,10.81865978]"
    ,"Distance":"1390"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3105"
    ,"Station_Code":"QBT 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Đường liên ấp 5-6"
    ,"Station_Address":"288, đường Nguyễn Cửu Phú, Quận Bình T ân"
    ,"Lat":10.820539
    ,"Long":106.587676
    ,"Polyline":"[106.58542633,10.81865978] ; [106.58706665,10.82017994] ; [106.58728790,10.82040024] ; [106.58738708,10.82040977] ; [106.58748627,10.82044029] ; [106.58757019,10.82052040]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3104"
    ,"Station_Code":"QBT 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chốt 2 KCN Vĩnh Lộc"
    ,"Station_Address":"330, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.822362
    ,"Long":106.58957
    ,"Polyline":"[106.58757019,10.82052040] ; [106.58950043,10.82238960]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3107"
    ,"Station_Code":"QBT 185"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Kho vật tư thiết bị"
    ,"Station_Address":"Kho vật tư thi ết bị, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.824402
    ,"Long":106.591393
    ,"Polyline":"[106.58950043,10.82238960] ; [106.59049225,10.82336044] ; [106.59117126,10.82413006] ; [106.59134674,10.82435989]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3106"
    ,"Station_Code":"QBT 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Công ty  Cholimex"
    ,"Station_Address":"Công ty Cholimex , đường Phan Văn Đối, Quận Bình Tân"
    ,"Lat":10.826073
    ,"Long":106.59269
    ,"Polyline":"[106.59134674,10.82435989] ; [106.59268951,10.82608986]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3109"
    ,"Station_Code":"HHM 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Cây x ăng Quang Trung"
    ,"Station_Address":"43/11C, đường Phan Văn Đối, Huyện Hóc  Môn"
    ,"Lat":10.828746
    ,"Long":106.59462
    ,"Polyline":"[106.59268951,10.82608986] ; [106.59323120,10.82682037] ; [106.59304810,10.82691956] ; [106.59316254,10.82713032] ; [106.59449005,10.82882977]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3108"
    ,"Station_Code":"HHM 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"43/1, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.831306
    ,"Long":106.596176
    ,"Polyline":"[106.59449005,10.82882977] ; [106.59559631,10.83045006] ; [106.59568787,10.83059025] ; [106.59584045,10.83090019] ; [106.59604645,10.83135986]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3110"
    ,"Station_Code":"HHM 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"31/3C, đường Phan  Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.834866
    ,"Long":106.598015
    ,"Polyline":"[106.59604645,10.83135986] ; [106.59783936,10.83495045]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3111"
    ,"Station_Code":"HHM 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"42/1B, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.837942
    ,"Long":106.599861
    ,"Polyline":"[106.59783936,10.83495045] ; [106.59850311,10.83602047] ; [106.59925079,10.83730030] ; [106.59947968,10.83769989] ; [106.59964752,10.83804035]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"2211"
    ,"Station_Code":"HHM 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Bà Điểm"
    ,"Station_Address":"Chợ Bà Điểm, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.839987
    ,"Long":106.599693
    ,"Polyline":"[106.59964752,10.83804035] ; [106.59982300,10.83839989] ; [106.59993744,10.83872986] ; [106.60014343,10.83917999] ; [106.60021973,10.83940983] ; [106.59969330,10.83987045] ; [106.59963226,10.83992004]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3113"
    ,"Station_Code":"HHM 167"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã 3 Nguyễn Thị Sóc - Nguyễn Ảnh Thủ"
    ,"Station_Address":"19/1B , đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.840803
    ,"Long":106.599119
    ,"Polyline":"[106.59963226,10.83992004] ; [106.59900665,10.84041977] ; [106.59880066,10.84058952] ; [106.59919739,10.84099007]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3112"
    ,"Station_Code":"HHM 168"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Công ty  trà Tân Lam"
    ,"Station_Address":"60/8A (Đối diện 135), đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.846567
    ,"Long":106.600464
    ,"Polyline":"[106.59919739,10.84099007] ; [106.59954834,10.84136009] ; [106.59958649,10.84150028] ; [106.59976959,10.84187984] ; [106.59986115,10.84230042] ; [106.59990692,10.84292984] ; [106.59989929,10.84331989] ; [106.59989929,10.84339046]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3115"
    ,"Station_Code":"HHM 169"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Cây xăng Hưng Lân"
    ,"Station_Address":"13/5 , đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.849428
    ,"Long":106.602294
    ,"Polyline":"[106.59989929,10.84339046] ; [106.59985352,10.84385967] ; [106.59983063,10.84418011] ; [106.59983826,10.84436989] ; [106.59992218,10.84480000] ; [106.60005951,10.84552002] ; [106.60030365,10.84638977] ; [106.60050964,10.84692955] ; [106.60096741,10.84766960] ; [106.60150909,10.84850979]"
    ,"Distance":"611"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3114"
    ,"Station_Code":"HHM 170"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Khúc Giao Mùa"
    ,"Station_Address":"32/4 , đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.852083
    ,"Long":106.604569
    ,"Polyline":"[106.60150909,10.84850979] ; [106.60199738,10.84928036] ; [106.60286713,10.85035992] ; [106.60372925,10.85140038] ; [106.60420990,10.85192966] ; [106.60437012,10.85212994]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3117"
    ,"Station_Code":"HHM 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Ngã tư Trung Chánh"
    ,"Station_Address":"26/7C  (27/11B), đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.854383
    ,"Long":106.606552
    ,"Polyline":"[106.60437012,10.85212994] ; [106.60491943,10.85272980] ; [106.60534668,10.85317039] ; [106.60578156,10.85367966] ; [106.60666656,10.85466003]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1237"
    ,"Station_Code":"QHMT229"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Trung  tâm văn hóa Quận 12"
    ,"Station_Address":"Quán ăn xuyên Á, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854108810424805
    ,"Long":106.60777282714844
    ,"Polyline":"[106.60666656,10.85466003] ; [106.60717773,10.85525036] ; [106.60729980,10.85505962] ; [106.60787964,10.85418034]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1238"
    ,"Station_Code":"HHM 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"3A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.850092
    ,"Long":106.610395
    ,"Polyline":"[106.60787964,10.85418034] ; [106.61047363,10.85015011]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Quốc lộ 22, Huy ện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61047363,10.85015011] ; [106.61290741,10.84638023] ; [106.61396027,10.84473038]"
    ,"Distance":"713"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61396030,10.84473038] ; [106.61405180,10.84459972] ; [106.61408930,10.84450118] ; [106.61406240,10.84441844] ; [106.61400330,10.84434624] ; [106.61393350,10.84428457] ; [106.61365630,10.84405216] ; [106.61343970,10.84385818] ; [106.61328200,10.84374541] ; [106.61298540,10.84354619]"
    ,"Distance":"160"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61504364,10.84255981] ; [106.61511993,10.84243011] ; [106.61530304,10.84235001] ; [106.61544800,10.84235001] ; [106.61559296,10.84243965] ; [106.61566162,10.84257984] ; [106.61566162,10.84274006] ; [106.61560822,10.84286976] ; [106.61556244,10.84292984] ; [106.61546326,10.84298992] ; [106.61534119,10.84300995] ; [106.61528015,10.84300041] ; [106.61518097,10.84311962] ; [106.61475372,10.84370995] ; [106.61401367,10.84482956] ; [106.61396027,10.84490967]"
    ,"Distance":"824"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1116"
    ,"Station_Code":"Q12 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm cây xăng"
    ,"Station_Address":"128, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.845487
    ,"Long":106.61371
    ,"Polyline":"[106.61396027,10.84490967] ; [106.61361694,10.84545040]"
    ,"Distance":"70"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1117"
    ,"Station_Code":"Q12 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cư xá B à Điểm"
    ,"Station_Address":"7C, đường Quốc l ộ 22, Quận 12"
    ,"Lat":10.845845
    ,"Long":106.613474
    ,"Polyline":"[106.61361694,10.84545040] ; [106.61338806,10.84578991]"
    ,"Distance":"45"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1151"
    ,"Station_Code":"Q12 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cây xăng Quân Đội"
    ,"Station_Address":"2, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.850034
    ,"Long":106.610845
    ,"Polyline":"[106.61338806,10.84578991] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61106110,10.84941959] ; [106.61073303,10.84994030]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1689"
    ,"Station_Code":"Q12 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cảnh sát giao thông số 5"
    ,"Station_Address":"Kế cảnh sát giao thông số 5, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.851009
    ,"Long":106.610186
    ,"Polyline":"[106.61073303,10.84994030] ; [106.61007690,10.85095024]"
    ,"Distance":"133"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"1152"
    ,"Station_Code":"Q12 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Trung tâm văn hóa Quận 12,  đường Quốc lộ 22, Quận 12"
    ,"Lat":10.854892
    ,"Long":106.607718
    ,"Polyline":"[106.61007690,10.85095024] ; [106.60819244,10.85389042] ; [106.60761261,10.85480976]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3141"
    ,"Station_Code":"HHM 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Xuyên Á"
    ,"Station_Address":"23 /4, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.854733
    ,"Long":106.606667
    ,"Polyline":"[106.60761261,10.85480976] ; [106.60726166,10.85533047] ; [106.60710144,10.85515976] ; [106.60669708,10.85470009]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3140"
    ,"Station_Code":"HHM 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nguyễn  Thị Sóc"
    ,"Station_Address":"15/5B, đường Nguy ễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.851709
    ,"Long":106.603957
    ,"Polyline":"[106.60669708,10.85470009] ; [106.60578156,10.85367966] ; [106.60534668,10.85317039] ; [106.60491943,10.85272980] ; [106.60420990,10.85192966] ; [106.60398865,10.85169983]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3145"
    ,"Station_Code":"HHM 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Hậu Lân, Bà Điểm"
    ,"Station_Address":"11/6A, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.849033
    ,"Long":106.601784
    ,"Polyline":"[106.60398865,10.85169983] ; [106.60372925,10.85140038] ; [106.60286713,10.85035992] ; [106.60199738,10.84928036] ; [106.60182953,10.84901047]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3142"
    ,"Station_Code":"HHM 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"trường Phan Công Hớn"
    ,"Station_Address":"88/2, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.846233
    ,"Long":106.60022
    ,"Polyline":"[106.60182953,10.84901047] ; [106.60075378,10.84733009] ; [106.60057068,10.84704018] ; [106.60044861,10.84681034] ; [106.60025024,10.84619999] ; [106.60021210,10.84620953]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3146"
    ,"Station_Code":"HHM 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"Đ/d T. Phan Công Hớn, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.8411
    ,"Long":106.59922
    ,"Polyline":"[106.60021210,10.84620953] ; [106.60025024,10.84619999] ; [106.60005951,10.84552002] ; [106.59992218,10.84480000] ; [106.59983826,10.84436989] ; [106.59983063,10.84418011] ; [106.59985352,10.84385967] ; [106.59989929,10.84331989] ; [106.59990692,10.84292984] ; [106.59986115,10.84230042] ; [106.59976959,10.84187984] ; [106.59958649,10.84150028] ; [106.59954834,10.84136009] ; [106.59925842,10.84105015]"
    ,"Distance":"601"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"2284"
    ,"Station_Code":"HHM 202"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Bà Điểm"
    ,"Station_Address":"17/7, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.839502
    ,"Long":106.59996
    ,"Polyline":"[106.59925842,10.84105015] ; [106.59880066,10.84058952] ; [106.59900665,10.84041977] ; [106.59969330,10.83987045] ; [106.60002899,10.83957958]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3143"
    ,"Station_Code":"HHM 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"36/2D, đường Phan Văn Đối , Huyện Hóc Môn"
    ,"Lat":10.83751
    ,"Long":106.59928
    ,"Polyline":"[106.60002899,10.83957958] ; [106.60021973,10.83940983] ; [106.60019684,10.83932972] ; [106.59999084,10.83883953] ; [106.59982300,10.83839989] ; [106.59947968,10.83769989] ; [106.59937286,10.83749962]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3144"
    ,"Station_Code":"HHM 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"35/1B, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.834549
    ,"Long":106.597509
    ,"Polyline":"[106.59937286,10.83749962] ; [106.59906769,10.83701038] ; [106.59850311,10.83602047] ; [106.59792328,10.83510971] ; [106.59764862,10.83456993]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3147"
    ,"Station_Code":"HHM 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"26/2M, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.831367
    ,"Long":106.595997
    ,"Polyline":"[106.59764862,10.83456993] ; [106.59607697,10.83143997]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3148"
    ,"Station_Code":"HHM 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Hóc M ôn"
    ,"Station_Address":"Kế 34/11D, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.829154
    ,"Long":106.594634
    ,"Polyline":"[106.59607697,10.83143997] ; [106.59568787,10.83059025] ; [106.59529877,10.83003044] ; [106.59471130,10.82915974]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3150"
    ,"Station_Code":"QBT 191"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"công ty Cholimex"
    ,"Station_Address":"Đối diện công ty Cholimex, đường Phan Văn Đối, Quận Bình Tân"
    ,"Lat":10.826043
    ,"Long":106.592354
    ,"Polyline":"[106.59471130,10.82915974] ; [106.59442139,10.82872963] ; [106.59316254,10.82713032] ; [106.59304810,10.82691956] ; [106.59245300,10.82614040] ; [106.59236908,10.82602978]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3152"
    ,"Station_Code":"QBT 190"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Công ty Jonton"
    ,"Station_Address":"Công ty Jonton, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.824625
    ,"Long":106.591202
    ,"Polyline":"[106.59236908,10.82602978] ; [106.59169006,10.82520008] ; [106.59123230,10.82460976]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3154"
    ,"Station_Code":"QBT 189"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"KCN Vĩnh Lộc"
    ,"Station_Address":"Đối diện 330, đường Nguyễn Cửu Phú, Quận B ình Tân"
    ,"Lat":10.822679
    ,"Long":106.589425
    ,"Polyline":"[106.59123230,10.82460976] ; [106.59030914,10.82355022] ; [106.58944702,10.82269955]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3149"
    ,"Station_Code":"QBT 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Quỳnh Tiên"
    ,"Station_Address":"F9/18B1, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.820919
    ,"Long":106.587616
    ,"Polyline":"[106.58944702,10.82269955] ; [106.58763123,10.82091045]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3151"
    ,"Station_Code":"QBT 187"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"xã Nhị Bình"
    ,"Station_Address":"F9/6B, đường Phan Văn Đối, Quận Bình Tân"
    ,"Lat":10.818777
    ,"Long":106.585533
    ,"Polyline":"[106.58763123,10.82091045] ; [106.58731842,10.82061005] ; [106.58728790,10.82050037] ; [106.58728790,10.82040024] ; [106.58706665,10.82017994] ; [106.58554077,10.81877041]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"2325"
    ,"Station_Code":"HBC 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã 5 Vĩnh Lộc"
    ,"Station_Address":"F1/17, đường Hương Lộ 80, Huyện Bình Chánh"
    ,"Lat":10.811376
    ,"Long":106.575655
    ,"Polyline":"[106.58554077,10.81877041] ; [106.58489227,10.81818008] ; [106.58332825,10.81684971] ; [106.58245850,10.81606007] ; [106.58210754,10.81579018] ; [106.58116913,10.81499958] ; [106.57962036,10.81387997] ; [106.57956696,10.81379032] ; [106.57936859,10.81369019] ; [106.57917023,10.81359005] ; [106.57872009,10.81328964] ; [106.57792664,10.81274033] ; [106.57656860,10.81188011] ; [106.57566833,10.81130981]"
    ,"Distance":"1366"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"2326"
    ,"Station_Code":"HBC 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"KDC Vĩnh Lộc A"
    ,"Station_Address":"A1/2, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.809332
    ,"Long":106.572458
    ,"Polyline":"[106.57566833,10.81130981] ; [106.57479095,10.81077003] ; [106.57399750,10.81023979] ; [106.57350159,10.80994034] ; [106.57256317,10.80935001]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3583"
    ,"Station_Code":"HBC 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ấp 6"
    ,"Station_Address":"Đ/d 1704, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.806845
    ,"Long":106.568504
    ,"Polyline":"[106.57247925,10.80930996] ; [106.57176208,10.80885983] ; [106.57112885,10.80842972] ; [106.56934357,10.80733967] ; [106.56854248,10.80681038]"
    ,"Distance":"512"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3585"
    ,"Station_Code":"HBC 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Công ty Hợp Nhất"
    ,"Station_Address":"Công ty Hợp Nhất, đường Hương Lộ 80, Huyện Bình Chánh"
    ,"Lat":10.804168
    ,"Long":106.564765
    ,"Polyline":"[106.56854248,10.80681038] ; [106.56813049,10.80655003] ; [106.56762695,10.80626011] ; [106.56649017,10.80550957] ; [106.56555176,10.80494976] ; [106.56522369,10.80469990] ; [106.56504059,10.80453014] ; [106.56477356,10.80418015]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3582"
    ,"Station_Code":"HBC 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"UB xã Vĩnh Lộc B"
    ,"Station_Address":"Đ/d 1344, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.799573
    ,"Long":106.561069
    ,"Polyline":"[106.56477356,10.80418015] ; [106.56076050,10.79913998]"
    ,"Distance":"712"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3584"
    ,"Station_Code":"HBC 141"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm xăng Hiệp Hòa"
    ,"Station_Address":"1175, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.795895
    ,"Long":106.558118
    ,"Polyline":"[106.56076050,10.79913998] ; [106.56002045,10.79819965] ; [106.55991364,10.79811001] ; [106.55860138,10.79646015] ; [106.55758667,10.79524994] ; [106.55735779,10.79537964]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3587"
    ,"Station_Code":"HBC 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Mầm non Hoa Thiên Lý"
    ,"Station_Address":"Mầm non Hoa Thiên Lý, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.793176
    ,"Long":106.556418
    ,"Polyline":"[106.55735779,10.79537964] ; [106.55758667,10.79524994] ; [106.55719757,10.79477978] ; [106.55687714,10.79415035] ; [106.55609894,10.79222965] ; [106.55529785,10.79051018]"
    ,"Distance":"615"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3586"
    ,"Station_Code":"HBC 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Kinh Trung Ương"
    ,"Station_Address":"Công ty Sơn Ha ̀, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.789835
    ,"Long":106.555002
    ,"Polyline":"[106.55529785,10.79051018] ; [106.55457306,10.78866959] ; [106.55448151,10.78843975] ; [106.55416870,10.78658962] ; [106.55409241,10.78608036]"
    ,"Distance":"513"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3588"
    ,"Station_Code":"HBC 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu B à Tri"
    ,"Station_Address":"1A/117, đường Vĩnh  Lộc, Huyện Bình Chánh"
    ,"Lat":10.785293
    ,"Long":106.55395
    ,"Polyline":"[106.55409241,10.78608036] ; [106.55342865,10.78182983]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3590"
    ,"Station_Code":"HBC 151"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Công ty Bảo Huy"
    ,"Station_Address":"1A/167/1, đường Vĩnh Lộc, Huyện Bình  Chánh"
    ,"Lat":10.780128
    ,"Long":106.553113
    ,"Polyline":"[106.55342865,10.78182983] ; [106.55300140,10.77906036]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3591"
    ,"Station_Code":"HBC 152"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Công ty Hùng Tuấn"
    ,"Station_Address":"1A.129, đường Vĩnh Lộc, Huy ện Bình Chánh"
    ,"Lat":10.776097
    ,"Long":106.552497
    ,"Polyline":"[106.55249023,10.77871037] ; [106.55178070,10.77884960] ; [106.55171204,10.77849007] ; [106.55155182,10.77737999] ; [106.55137634,10.77628994] ; [106.55178070,10.77622032] ; [106.55207062,10.77618027]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3589"
    ,"Station_Code":"HBC 153"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Bà Lát"
    ,"Station_Address":"Đối diện A1/94, đường Vĩnh Lộc, Huyện Bình Chánh"
    ,"Lat":10.771981
    ,"Long":106.551842
    ,"Polyline":"[106.55207062,10.77618027] ; [106.55255127,10.77610970] ; [106.55227661,10.77466011] ; [106.55193329,10.77231026]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3467"
    ,"Station_Code":"HBC 283"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Bà Lát"
    ,"Station_Address":"1A58/1, đường  Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.770105
    ,"Long":106.552899
    ,"Polyline":"[106.55193329,10.77231026] ; [106.55178070,10.77130985] ; [106.55168915,10.77066040] ; [106.55148315,10.77077961] ; [106.54708099,10.77299976] ; [106.54699707,10.77303982]"
    ,"Distance":"762"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3470"
    ,"Station_Code":"HBC 284"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ B à Lát"
    ,"Station_Address":"2A/2, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Huyện Bình Chánh"
    ,"Lat":10.776661
    ,"Long":106.539992
    ,"Polyline":"[106.54699707,10.77303982] ; [106.54406738,10.77455044] ; [106.54209900,10.77552986] ; [106.53997803,10.77659988]"
    ,"Distance":"863"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3469"
    ,"Station_Code":"HBC 285"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Bình Minh"
    ,"Station_Address":"2A/27/1, đường T ỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Huyện Bình Chánh"
    ,"Lat":10.779907
    ,"Long":106.533539
    ,"Polyline":"[106.53997803,10.77659988] ; [106.53539276,10.77890015] ; [106.53418732,10.77952003] ; [106.53353119,10.77989006]"
    ,"Distance":"794"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3472"
    ,"Station_Code":"HBC 286"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm y tế xã Phạm Văn Hai"
    ,"Station_Address":"Cty cây trồng TPHCMi, đường  Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Huyện Bình Chánh"
    ,"Lat":10.78191
    ,"Long":106.529553
    ,"Polyline":"[106.53353119,10.77989006] ; [106.53298950,10.78017998] ; [106.53240967,10.78044033] ; [106.53140259,10.78089046] ; [106.52954865,10.78182983]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3471"
    ,"Station_Code":"HBC 287"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Xã Lê Minh Xuân"
    ,"Station_Address":"2A/63 , đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.783601
    ,"Long":106.526039
    ,"Polyline":"[106.52954865,10.78182983] ; [106.52603149,10.78357983]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3474"
    ,"Station_Code":"HBC 288"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Kênh A"
    ,"Station_Address":"2A/94, đường T ỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.784905
    ,"Long":106.523438
    ,"Polyline":"[106.52603149,10.78357983] ; [106.52342987,10.78489017]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3473"
    ,"Station_Code":"HBC 291"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Khách  sạn Thu Loan"
    ,"Station_Address":"3A.11, đư ờng Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.786615
    ,"Long":106.520063
    ,"Polyline":"[106.52342987,10.78489017] ; [106.52005768,10.78656960]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3476"
    ,"Station_Code":"HBC 292"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đa khoa  Sài Gòn"
    ,"Station_Address":"3A35/3, đường T ỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.787743
    ,"Long":106.517746
    ,"Polyline":"[106.52005768,10.78656960] ; [106.51773834,10.78773022]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3475"
    ,"Station_Code":"HBC 293"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Nhà th ờ chợ Cầu Xáng"
    ,"Station_Address":"3A63, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.78895
    ,"Long":106.51582
    ,"Polyline":"[106.51773834,10.78773022] ; [106.51658630,10.78833008] ; [106.51615143,10.78857994] ; [106.51570892,10.78886032]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3593"
    ,"Station_Code":"HBC 328"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Mai Bá Hương"
    ,"Station_Address":"Đối diện A8/7, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.787322
    ,"Long":106.514039
    ,"Polyline":"[106.51570892,10.78886032] ; [106.51502991,10.78932953] ; [106.51468658,10.78952980] ; [106.51361084,10.78985023] ; [106.51320648,10.78995991] ; [106.51336670,10.78983974] ; [106.51454163,10.78925037] ; [106.51425934,10.78814983] ; [106.51387024,10.78658962]"
    ,"Distance":"773"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3592"
    ,"Station_Code":"HBC 329"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Công ty Hoàng Long Anh"
    ,"Station_Address":"Đối diện A8/27, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.784908
    ,"Long":106.513481
    ,"Polyline":"[106.51387024,10.78658962] ; [106.51306152,10.78334045]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3595"
    ,"Station_Code":"HBC 330"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bãi giữ xe chùa Phật Cô Đơn"
    ,"Station_Address":"Bãi giữ xe chùa Phật Cô Đơn, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.781831
    ,"Long":106.512784
    ,"Polyline":"[106.51306152,10.78334045] ; [106.51268768,10.78182030]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3594"
    ,"Station_Code":"HBC 331"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Học viện Phật giáo Việt Nam"
    ,"Station_Address":"Đối diện 10/8A, đường Mai  Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.776208
    ,"Long":106.511126
    ,"Polyline":"[106.51268768,10.78182030] ; [106.51159668,10.77777958] ; [106.51120758,10.77665043] ; [106.51103973,10.77618980]"
    ,"Distance":"652"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3596"
    ,"Station_Code":"HBC 332"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Công ty Minh Chương"
    ,"Station_Address":"Đối diện A11/1, đường Mai Bá Hương, Huy ện Bình Chánh"
    ,"Lat":10.771734
    ,"Long":106.507612
    ,"Polyline":"[106.51103973,10.77618980] ; [106.51074982,10.77538967] ; [106.50997162,10.77400970] ; [106.50981903,10.77385044] ; [106.50884247,10.77280998] ; [106.50753021,10.77175045]"
    ,"Distance":"637"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3598"
    ,"Station_Code":"HBC 333"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Công ty Thịnh Mỹ"
    ,"Station_Address":"Đối diện A11 /19, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.767987
    ,"Long":106.502688
    ,"Polyline":"[106.50753021,10.77175045] ; [106.50569916,10.77031994] ; [106.50270844,10.76799011]"
    ,"Distance":"673"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3597"
    ,"Station_Code":"HBC 334"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Trần  Đại Nghĩa"
    ,"Station_Address":"Đối diện A1/27, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.766284
    ,"Long":106.500328
    ,"Polyline":"[106.50270844,10.76799011] ; [106.50097656,10.76663971] ; [106.50032806,10.76622963]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3599"
    ,"Station_Code":"HBC 335"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Trần Đại Nghĩa"
    ,"Station_Address":"B1/27A, đường Mai Bá Hương, Huyện Bình Chánh"
    ,"Lat":10.764356
    ,"Long":106.497855
    ,"Polyline":"[106.50032806,10.76622963] ; [106.49976349,10.76587963] ; [106.49932098,10.76562977] ; [106.49923706,10.76552963] ; [106.49893951,10.76496029] ; [106.49877930,10.76471043] ; [106.49799347,10.76418018]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3601"
    ,"Station_Code":"HBC 336"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Thánh Thất Lê Minh Xuân"
    ,"Station_Address":"B3/24, đường Mai Bá Hương, Huyện Bình  Chánh"
    ,"Lat":10.762121
    ,"Long":106.494856
    ,"Polyline":"[106.49799347,10.76418018] ; [106.49745178,10.76381969] ; [106.49497986,10.76196957]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"111"
    ,"Station_Id":"3600"
    ,"Station_Code":"BX 59"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Phật Cô Đơn"
    ,"Station_Address":"ĐẦU BẾN PHẬT CÔ ĐƠN, đường Mai Bá Hương, Huyện Bình Ch ánh"
    ,"Lat":10.756245
    ,"Long":106.489281
    ,"Polyline":"[106.49497986,10.76196957] ; [106.48854828,10.75716019]"
    ,"Distance":"883"
  }]