export const Route78 =[
  {
     "Route_Id":"78"
    ,"Station_Id":"1294"
    ,"Station_Code":"BX 66"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Bình Mỹ"
    ,"Station_Address":"Chân cầu Phú Cường (Bình Mỹ), đường  Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.979037
    ,"Long":106.64328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"1310"
    ,"Station_Code":"HCC 247"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Cầu Phú C ường"
    ,"Station_Address":"2114, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.977467
    ,"Long":106.643768
    ,"Polyline":"[106.64343262,10.97904968] ; [106.64350891,10.97873974] ; [106.64372253,10.97768021] ; [106.64372253,10.97764969]"
    ,"Distance":"159"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"1313"
    ,"Station_Code":"HCC 248"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã 3 Bến Đò"
    ,"Station_Address":"1976, đường Tỉnh lộ 8, Củ Chi, Huy ện Củ Chi"
    ,"Lat":10.97705
    ,"Long":106.6437
    ,"Polyline":"[106.64372253,10.97764969] ; [106.64376831,10.97729969] ; [106.64383698,10.97607040] ; [106.64382172,10.97513008] ; [106.64382935,10.97476959] ; [106.64378357,10.97467995] ; [106.64351654,10.97457027] ; [106.64222717,10.97404957]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3233"
    ,"Station_Code":"QCCT262"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Áo cưới Sunny"
    ,"Station_Address":"Áo cưới Sunny, đường Tỉnh  lộ 9, Huyện Củ Chi"
    ,"Lat":10.970484733581543
    ,"Long":106.63876342773438
    ,"Polyline":"[106.64222717,10.97404957] ; [106.64099884,10.97354984] ; [106.64038086,10.97340965] ; [106.63951874,10.97336960] ; [106.63928986,10.97192955] ; [106.63906860,10.97064018] ; [106.63906097,10.97047043]"
    ,"Distance":"635"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3235"
    ,"Station_Code":"QCCT263"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến đò B ình Mỹ"
    ,"Station_Address":"Đối diện công ty Thành Lực, đường Tỉnh lộ  9, Huyện Củ Chi"
    ,"Lat":10.966840744018555
    ,"Long":106.63960266113281
    ,"Polyline":"[106.63906097,10.97047043] ; [106.63905334,10.97017956] ; [106.63906860,10.96990013] ; [106.63955688,10.96805954] ; [106.63986969,10.96689987]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3234"
    ,"Station_Code":"QCCT264"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 B ình Mỹ"
    ,"Station_Address":"Đối diện cửa hàng Sáu Kim, đường Tỉnh lộ 9 , Huyện Củ Chi"
    ,"Lat":10.96258544921875
    ,"Long":106.64124298095703
    ,"Polyline":"[106.63986969,10.96689987] ; [106.64005280,10.96617031] ; [106.64070129,10.96442986] ; [106.64109039,10.96350002] ; [106.64144135,10.96265984]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3237"
    ,"Station_Code":"QCCT265"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường ti ểu học Bình Hòa"
    ,"Station_Address":"Cafe Cây Mận, đường Tỉnh lộ 9, Huyện C ủ Chi"
    ,"Lat":10.957571029663086
    ,"Long":106.64305114746094
    ,"Polyline":"[106.64144135,10.96265984] ; [106.64205170,10.96117973] ; [106.64263916,10.95954037] ; [106.64298248,10.95847988] ; [106.64325714,10.95763969]"
    ,"Distance":"593"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3236"
    ,"Station_Code":"QCCT266"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Khách sạn Minh Tú"
    ,"Station_Address":"337, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.951778411865234
    ,"Long":106.64430236816406
    ,"Polyline":"[106.64325714,10.95763969] ; [106.64398956,10.95538998] ; [106.64440918,10.95394993] ; [106.64498901,10.95197010]"
    ,"Distance":"658"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3239"
    ,"Station_Code":"QCCT267"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây Điệp"
    ,"Station_Address":"Đối diện 15, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.947101593017578
    ,"Long":106.64575958251953
    ,"Polyline":"[106.64498901,10.95197010.06.64572144] ; [10.94946957,106.64611816] ; [10.94863987,106.64656830]"
    ,"Distance":"540"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3238"
    ,"Station_Code":"QCCT268"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Bình Mỹ"
    ,"Station_Address":"Đối diện cột điện H14A, đường Tỉnh lộ 9, Huy ện Củ Chi"
    ,"Lat":10.941433906555176
    ,"Long":106.64541625976562
    ,"Polyline":"[106.64656830,10.94738007] ; [106.64685822,10.94657040] ; [106.64697266,10.94624043] ; [106.64698029,10.94581032] ; [106.64694214,10.94556999] ; [106.64659882,10.94447994] ; [106.64589691,10.94136047]"
    ,"Distance":"691"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3241"
    ,"Station_Code":"QCCT269"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Am Dưỡng Bình Mỹ"
    ,"Station_Address":"Đối diện 271, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.936251640319824
    ,"Long":106.64507293701172
    ,"Polyline":"[106.64589691,10.94136047] ; [106.64579010,10.94062996] ; [106.64559937,10.93945980] ; [106.64550018,10.93871021] ; [106.64543915,10.93776989] ; [106.64546204,10.93723965] ; [106.64547729,10.93692017] ; [106.64559937,10.93636036]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3243"
    ,"Station_Code":"QCCT270"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Thi Đua"
    ,"Station_Address":"Đối diện cơ khí Đức Tài, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.931510925292969
    ,"Long":106.6459732055664
    ,"Polyline":"[106.64559937,10.93636036] ; [106.64649200,10.93159962]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3240"
    ,"Station_Code":"QCCT271"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Truốc Bua"
    ,"Station_Address":"Cửa hàng sữa  Thúy Nga, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.926285743713379
    ,"Long":106.64710998535156
    ,"Polyline":"[106.64649200,10.93159962] ; [106.64727783,10.92726994] ; [106.64743042,10.92679024] ; [106.64739990,10.92677975] ; [106.64698029,10.92661953]"
    ,"Distance":"598"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3242"
    ,"Station_Code":"QCCT272"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Bình Mỹ"
    ,"Station_Address":"Internet Thanh Phong, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.921377182006836
    ,"Long":106.64844512939453
    ,"Polyline":"[106.64698029,10.92661953] ; [106.64743042,10.92679024] ; [106.64785767,10.92556953] ; [106.64791107,10.92545986] ; [106.64810181,10.92430019] ; [106.64830780,10.92302036] ; [106.64845276,10.92201996] ; [106.64858246,10.92140007]"
    ,"Distance":"667"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3245"
    ,"Station_Code":"HHM 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"270, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.916606
    ,"Long":106.649452
    ,"Polyline":"[106.64858246,10.92140007] ; [106.64958191,10.91662979]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3244"
    ,"Station_Code":"HHM 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Mầm non"
    ,"Station_Address":"286, đường Đặng Thúc Vịnh, Huyện Hóc M ôn"
    ,"Lat":10.906007
    ,"Long":106.639191
    ,"Polyline":"[106.64958191,10.91662979] ; [106.64968872,10.91598988] ; [106.64965820,10.91563988] ; [106.64954376,10.91518974] ; [106.64940643,10.91485023] ; [106.64910126,10.91446972] ; [106.64864349,10.91392040] ; [106.64472198,10.90933037]"
    ,"Distance":"1003"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3247"
    ,"Station_Code":"QHMT019"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã tư Đất Thánh"
    ,"Station_Address":"50/1, đường Bùi Công Trừng , Huyện Hóc Môn"
    ,"Lat":10.908577919006348
    ,"Long":106.64845275878906
    ,"Polyline":"[106.64472198,10.90933037] ; [106.64431000,10.90886974] ; [106.64457703,10.90894032] ; [106.64565277,10.90911961] ; [106.64591217,10.90913963] ; [106.64620209,10.90909958] ; [106.64848328,10.90870953]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3246"
    ,"Station_Code":"HHM 217"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Bà  Năm"
    ,"Station_Address":"45, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.907536
    ,"Long":106.653885
    ,"Polyline":"[106.64848328,10.90870953] ; [106.64940643,10.90855980] ; [106.65106201,10.90830040] ; [106.65392303,10.90773964]"
    ,"Distance":"604"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3249"
    ,"Station_Code":"HHM 218"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Phà An Sương"
    ,"Station_Address":"381, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.907715
    ,"Long":106.661301
    ,"Polyline":"[106.65392303,10.90773964] ; [106.65518188,10.90748978] ; [106.65621185,10.90725994] ; [106.65711212,10.90711975] ; [106.65759277,10.90715027] ; [106.65843964,10.90725040] ; [106.65886688,10.90732002] ; [106.65965271,10.90756989] ; [106.66101837,10.90793991] ; [106.66120911,10.90799999]"
    ,"Distance":"816"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3248"
    ,"Station_Code":"HHM 224"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Phà Công Nông"
    ,"Station_Address":"83, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.908874
    ,"Long":106.666725
    ,"Polyline":"[106.66120911,10.90799999] ; [106.66204071,10.90824032] ; [106.66306305,10.90849018] ; [106.66442871,10.90880966] ; [106.66477966,10.90892982] ; [106.66535187,10.90904045] ; [106.66587830,10.90909958] ; [106.66663361,10.90927029]"
    ,"Distance":"609"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3251"
    ,"Station_Code":"HHM 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đặng Công Bỉnh"
    ,"Station_Address":"311, đường Bùi Công Trừng, Huyện Hóc M ôn"
    ,"Lat":10.910517
    ,"Long":106.672752
    ,"Polyline":"[106.66663361,10.90927029] ; [106.66886139,10.90979958] ; [106.67088318,10.91030979] ; [106.67269135,10.91079044]"
    ,"Distance":"683"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3250"
    ,"Station_Code":"HHM 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"xã Nhị Bình"
    ,"Station_Address":"29/1, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.912145
    ,"Long":106.678612
    ,"Polyline":"[106.67269135,10.91079044] ; [106.67382813,10.91108036] ; [106.67604828,10.91170025] ; [106.67774200,10.91217995] ; [106.67852783,10.91242027]"
    ,"Distance":"663"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3253"
    ,"Station_Code":"HHM 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường Võ Văn Thặng"
    ,"Station_Address":"143, đường Bùi Công Trừng, Huy ện Hóc Môn"
    ,"Lat":10.912487
    ,"Long":106.682755
    ,"Polyline":"[106.67852783,10.91242027] ; [106.68039703,10.91302013] ; [106.68089294,10.91318035] ; [106.68138123,10.91343021] ; [106.68161011,10.91351032] ; [106.68168640,10.91349983] ; [106.68183136,10.91343021] ; [106.68213654,10.91320992] ; [106.68289948,10.91269016]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3252"
    ,"Station_Code":"HHM 223"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Bùi Công Trừng"
    ,"Station_Address":"14/2, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.909137
    ,"Long":106.684303
    ,"Polyline":"[106.68289948,10.91269016] ; [106.68321228,10.91244984] ; [106.68331909,10.91232967] ; [106.68344879,10.91211033] ; [106.68361664,10.91172028] ; [106.68409729,10.91049004] ; [106.68448639,10.90931034] ; [106.68451691,10.90923023]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3256"
    ,"Station_Code":"HHM 216"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Hương lộ 80"
    ,"Station_Address":"89, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.906356
    ,"Long":106.685547
    ,"Polyline":"[106.68451691,10.90923023] ; [106.68489838,10.90832996] ; [106.68541718,10.90730953] ; [106.68580627,10.90647030]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3254"
    ,"Station_Code":"HHM 225"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bùi Công Trừng"
    ,"Station_Address":"Đối diện 39/1F, đường Bùi Công Trừng , Huyện Hóc Môn"
    ,"Lat":10.902447
    ,"Long":106.687134
    ,"Polyline":"[106.68580627,10.90647030] ; [106.68598175,10.90604019] ; [106.68625641,10.90526962] ; [106.68649292,10.90470028] ; [106.68659973,10.90433979] ; [106.68678284,10.90382957] ; [106.68721008,10.90275955] ; [106.68731689,10.90254021]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3258"
    ,"Station_Code":"Q12T202"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Hà Huy Giáp"
    ,"Station_Address":"79, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.900107383728027
    ,"Long":106.6884765625
    ,"Polyline":"[106.68731689,10.90254021] ; [106.68785858,10.90145969] ; [106.68834686,10.90077019] ; [106.68845367,10.90052986] ; [106.68855286,10.90011978]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3255"
    ,"Station_Code":"Q12T203"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chợ Đường"
    ,"Station_Address":"94/4C, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.89808464050293
    ,"Long":106.68891906738281
    ,"Polyline":"[106.68855286,10.90011978] ; [106.68878174,10.89906025] ; [106.68887329,10.89861012] ; [106.68898773,10.89809990]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3259"
    ,"Station_Code":"Q12 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Phú Cường"
    ,"Station_Address":"856, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.892669
    ,"Long":106.687632
    ,"Polyline":"[106.68898773,10.89809990] ; [106.68904877,10.89789009] ; [106.68910217,10.89756966] ; [106.68914032,10.89723969] ; [106.68910217,10.89661026] ; [106.68914032,10.89640045] ; [106.68910217,10.89624023] ; [106.68900299,10.89597988] ; [106.68878174,10.89546013] ; [106.68865204,10.89509010]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3257"
    ,"Station_Code":"Q12 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu Phú Long"
    ,"Station_Address":"793 (đối diện 487A), đường Hà Huy Giáp, Qu ận 12"
    ,"Lat":10.89289
    ,"Long":106.687396
    ,"Polyline":"[106.68865204,10.89509010.06.68798828] ; [10.89354992,106.68778992]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3261"
    ,"Station_Code":"Q12 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trại cá sấu"
    ,"Station_Address":"22/3, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.889951
    ,"Long":106.685357
    ,"Polyline":"[106.68778992,10.89321041] ; [106.68762970,10.89299011] ; [106.68701935,10.89223003] ; [106.68653107,10.89159012] ; [106.68641663,10.89142990]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3260"
    ,"Station_Code":"Q12 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Nguyễn Văn Thệ"
    ,"Station_Address":"Trường Nguyễn Văn Thệ, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.886516
    ,"Long":106.683125
    ,"Polyline":"[106.68641663,10.89142990] ; [106.68580627,10.89046955] ; [106.68544769,10.88963032] ; [106.68533325,10.88938046]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3262"
    ,"Station_Code":"Q12 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Điện Lực 2"
    ,"Station_Address":"65 /4, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.880816
    ,"Long":106.679075
    ,"Polyline":"[106.68533325,10.88938046] ; [106.68515778,10.88885021] ; [106.68505859,10.88848972] ; [106.68495941,10.88827038] ; [106.68473053,10.88796043] ; [106.68428802,10.88745022] ; [106.68399811,10.88710022] ; [106.68370819,10.88681030]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3263"
    ,"Station_Code":"Q12 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Thạnh  Xuân"
    ,"Station_Address":"59/2 (Chợ Thạnh Xuân), đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.878983
    ,"Long":106.678265
    ,"Polyline":"[106.68370819,10.88681030] ; [106.68341064,10.88656044] ; [106.68289948,10.88624001] ; [106.68203735,10.88566971] ; [106.68193817,10.88560009] ; [106.68180847,10.88545990] ; [106.68161011,10.88514996] ; [106.68115234,10.88440990] ; [106.68060303,10.88356972]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"204"
    ,"Station_Code":"Q12 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Ga ra Thanh Hậu"
    ,"Station_Address":"79C , đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.875074
    ,"Long":106.67672
    ,"Polyline":"[106.68060303,10.88356972] ; [106.67990875,10.88247013] ; [106.67890167,10.88022041] ; [106.67865753,10.87965965]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"205"
    ,"Station_Code":"Q12 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Vườn kiểng Quang Dũng"
    ,"Station_Address":"59/4, đường  Hà Huy Giáp, Quận 12"
    ,"Lat":10.871977
    ,"Long":106.676785
    ,"Polyline":"[106.67865753,10.87965965] ; [106.67797089,10.87812996] ; [106.67727661,10.87652016]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"206"
    ,"Station_Code":"Q12 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Cây xăng Tài Lộc"
    ,"Station_Address":"331, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.868015
    ,"Long":106.678233
    ,"Polyline":"[106.67727661,10.87652016] ; [106.67700195,10.87580013] ; [106.67691040,10.87545013] ; [106.67685699,10.87514973] ; [106.67680359,10.87475967] ; [106.67684937,10.87310982]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"207"
    ,"Station_Code":"Q12 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Đình thần Giao Khẩu"
    ,"Station_Address":"297, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.864886
    ,"Long":106.680341
    ,"Polyline":"[106.67684937,10.87310982] ; [106.67690277,10.87180996] ; [106.67697906,10.87073994] ; [106.67703247,10.87038040] ; [106.67706299,10.87026024] ; [106.67716980,10.86991978]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"208"
    ,"Station_Code":"Q12 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngã tư Ga"
    ,"Station_Address":"187A (396), đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.857984
    ,"Long":106.679649
    ,"Polyline":"[106.67716980,10.86991978] ; [106.67745972,10.86931038] ; [106.67765045,10.86896992] ; [106.67777252,10.86880016] ; [106.67816925,10.86830044] ; [106.67894745,10.86750984] ; [106.67929840,10.86715031]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"211"
    ,"Station_Code":"Q12 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Nhà hàng Bến Xưa"
    ,"Station_Address":"205, đường H à Huy Giáp, Quận 12"
    ,"Lat":10.853474
    ,"Long":106.679006
    ,"Polyline":"[106.67929840,10.86715031] ; [106.67951202,10.86690044] ; [106.67984009,10.86645985] ; [106.68012238,10.86590004] ; [106.68029785,10.86550045] ; [106.68035889,10.86520004] ; [106.68048859,10.86462975] ; [106.68044281,10.86452961] ; [106.68042755,10.86441040]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"2354"
    ,"Station_Code":"Q12 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã tư ga, đường Quốc lộ 1A,  Quận 12"
    ,"Lat":10.861788
    ,"Long":106.678517
    ,"Polyline":"[106.68042755,10.86441040] ; [106.68038177,10.86375999] ; [106.68032837,10.86330032] ; [106.68019104,10.86201954] ; [106.68013000,10.86176968] ; [106.68000793,10.86163998] ; [106.67990875,10.86159039] ; [106.67980957,10.86155987] ; [106.67881775,10.86163044] ; [106.67849731,10.86166000]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":"[106.67849731,10.86166000] ; [106.67832947,10.86166954]"
    ,"Distance":"18"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"68"
    ,"Station_Code":"Q12 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Đình thần Giao Khẩu"
    ,"Station_Address":"332, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.865217
    ,"Long":106.680433
    ,"Polyline":"[106.67832947,10.86166954] ; [106.67665863,10.86178017] ; [106.67565918,10.86182022] ; [106.67433929,10.86184025] ; [106.67260742,10.86182022] ; [106.67125702,10.86178970] ; [106.67125702,10.86166000] ; [106.67429352,10.86170006] ; [106.67534637,10.86168957] ; [106.67703247,10.86161041] ; [106.67836761,10.86151981] ; [106.67899323,10.86147976] ; [106.67910004,10.86141968] ; [106.67917633,10.86133957] ; [106.67922974,10.86122990] ; [106.67925262,10.86098957] ; [106.67916107,10.85962963] ; [106.67913818,10.85900974] ; [106.67917633,10.85890007] ; [106.67925262,10.85879993] ; [106.67945862,10.85869980] ; [106.67958832,10.85865974] ; [106.67976379,10.85851002] ; [106.67980957,10.85840988] ; [106.67986298,10.85826969] ; [106.68002319,10.85958004] ; [106.68022919,10.86139011] ; [106.68035889,10.86260033] ; [106.68045044,10.86343002] ; [106.68049622,10.86390972] ; [106.68048859,10.86413002] ; [106.68048859,10.86425018]"
    ,"Distance":"2711"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"74"
    ,"Station_Code":"Q12 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cây xăng Tài Lộc"
    ,"Station_Address":"408B, đường H à Huy Giáp, Quận 12"
    ,"Lat":10.86831
    ,"Long":106.678319
    ,"Polyline":"[106.68048859,10.86425018] ; [106.68048859,10.86462975] ; [106.68045807,10.86480045] ; [106.68029785,10.86550045] ; [106.67996979,10.86620045] ; [106.67971802,10.86662006] ; [106.67939758,10.86703014] ; [106.67920685,10.86723995]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"69"
    ,"Station_Code":"Q12 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Vườn kiểng Quang Dũng"
    ,"Station_Address":"452, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.871371
    ,"Long":106.676978
    ,"Polyline":"[106.67920685,10.86723995] ; [106.67816925,10.86830044] ; [106.67777252,10.86880016] ; [106.67765045,10.86896992] ; [106.67745972,10.86929989]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"70"
    ,"Station_Code":"Q12 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Ga ra Thanh Hậu"
    ,"Station_Address":"508 (63A), đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.875454
    ,"Long":106.677032
    ,"Polyline":"[106.67745972,10.86929989] ; [106.67720795,10.86981964] ; [106.67706299,10.87026024] ; [106.67703247,10.87038040] ; [106.67697906,10.87073994] ; [106.67690277,10.87180996] ; [106.67684937,10.87310028]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"71"
    ,"Station_Code":"Q12 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ Thạnh Xuân"
    ,"Station_Address":"Nhà văn hóa  P. Thạnh Lộc, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.878493
    ,"Long":106.678201
    ,"Polyline":"[106.67684937,10.87310028] ; [106.67681122,10.87483025] ; [106.67691040,10.87545013] ; [106.67714691,10.87619019] ; [106.67736053,10.87668991]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"77"
    ,"Station_Code":"Q12 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Cao  đẳng điện lực 2"
    ,"Station_Address":"554 (Trường điện lực 2), đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.880395
    ,"Long":106.679027
    ,"Polyline":"[106.67736053,10.87668991] ; [106.67797089,10.87812996] ; [106.67871094,10.87977028]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3204"
    ,"Station_Code":"Q12 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Nguyễn Văn Thệ"
    ,"Station_Address":"628B , đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.884214
    ,"Long":106.681122
    ,"Polyline":"[106.67871094,10.87977028] ; [106.67984009,10.88230991] ; [106.67996216,10.88255024] ; [106.68012238,10.88278961] ; [106.68105316,10.88426018]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3203"
    ,"Station_Code":"Q12 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trại cá sấu"
    ,"Station_Address":"704, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.886719
    ,"Long":106.683708
    ,"Polyline":"[106.68105316,10.88426018] ; [106.68170929,10.88531017] ; [106.68190002,10.88554955] ; [106.68199158,10.88564014] ; [106.68283081,10.88619041] ; [106.68296051,10.88628006] ; [106.68341064,10.88656044] ; [106.68356323,10.88667011] ; [106.68366241,10.88677025]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3206"
    ,"Station_Code":"Q12 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"cầu Rạch Quảng"
    ,"Station_Address":"768, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.889284
    ,"Long":106.685364
    ,"Polyline":"[106.68366241,10.88677025] ; [106.68399811,10.88710022] ; [106.68428802,10.88745022] ; [106.68473053,10.88796043] ; [106.68495941,10.88827038] ; [106.68505859,10.88848972] ; [106.68515778,10.88885021] ; [106.68530273,10.88930988]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3205"
    ,"Station_Code":"Q12 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Đường"
    ,"Station_Address":"936 , đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.895493
    ,"Long":106.68893
    ,"Polyline":"[106.68530273,10.88930988] ; [106.68560028,10.89002037] ; [106.68580627,10.89046955] ; [106.68594360,10.89066029] ; [106.68647766,10.89151955]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3208"
    ,"Station_Code":"Q12 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Chợ Đường"
    ,"Station_Address":"921, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.892996
    ,"Long":106.68746
    ,"Polyline":"[106.68647766,10.89151955] ; [106.68694305,10.89214039] ; [106.68746185,10.89280033] ; [106.68771362,10.89307022] ; [106.68786621,10.89332962]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3207"
    ,"Station_Code":"Q12T117"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chùa Báo Ấn"
    ,"Station_Address":"938, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.895479202270508
    ,"Long":106.68885040283203
    ,"Polyline":"[106.68786621,10.89332962] ; [106.68798828,10.89354992] ; [106.68824005,10.89412022] ; [106.68872070,10.89523029] ; [106.68878174,10.89546013] ; [106.68879700,10.89550018]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3210"
    ,"Station_Code":"Q12T200"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"cầu Võng"
    ,"Station_Address":"18, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.897733688354492
    ,"Long":106.68914031982422
    ,"Polyline":"[106.68879700,10.89550018] ; [106.68900299,10.89597988] ; [106.68910217,10.89624023] ; [106.68914032,10.89640045] ; [106.68910217,10.89661026] ; [106.68914032,10.89723969] ; [106.68910217,10.89756966] ; [106.68907928,10.89772034]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3209"
    ,"Station_Code":"Q12T201"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Trại hòm"
    ,"Station_Address":"55 /5A, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.899701118469238
    ,"Long":106.68870544433594
    ,"Polyline":"[106.68907928,10.89772034] ; [106.68904877,10.89789009] ; [106.68887329,10.89861012] ; [106.68878174,10.89906025] ; [106.68865204,10.89968967]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3214"
    ,"Station_Code":"HHM 205"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"cầu Bà Hồng"
    ,"Station_Address":"16, đường Bùi Công Trừng, Huyện Hóc M ôn"
    ,"Lat":10.902341
    ,"Long":106.687553
    ,"Polyline":"[106.68865204,10.89968967] ; [106.68845367,10.90052986] ; [106.68834686,10.90077019] ; [106.68785858,10.90145969] ; [106.68743896,10.90229034]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3212"
    ,"Station_Code":"HHM 206"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu Bà Thắng"
    ,"Station_Address":"94, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.906356
    ,"Long":106.68605
    ,"Polyline":"[106.68743896,10.90229034] ; [106.68721008,10.90275955] ; [106.68708801,10.90307045] ; [106.68691254,10.90353012] ; [106.68669128,10.90408993] ; [106.68649292,10.90470028] ; [106.68621826,10.90538979] ; [106.68592072,10.90620995] ; [106.68589020,10.90629005]"
    ,"Distance":"476"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3211"
    ,"Station_Code":"HHM 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"xã Nhị Bình"
    ,"Station_Address":"Đối diện 135, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.908863
    ,"Long":106.684898
    ,"Polyline":"[106.68589020,10.90629005] ; [106.68541718,10.90730953] ; [106.68489838,10.90832996] ; [106.68470764,10.90878010]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3213"
    ,"Station_Code":"HHM 208"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Đặng Công Bỉnh"
    ,"Station_Address":"Trường Võ Văn Thặng (Đd 143), đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.911982
    ,"Long":106.683708
    ,"Polyline":"[106.68470764,10.90878010.06.68447113] ; [10.90935993,106.68409729] ; [10.91049004,106.68389893] ; [10.91100979,106.68354034]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3216"
    ,"Station_Code":"HHM 209"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Phà Công Nông"
    ,"Station_Address":"180 (Trường Đặng Công Bỉnh), đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.912666
    ,"Long":106.679008
    ,"Polyline":"[106.68354034,10.91191006] ; [106.68344879,10.91211033] ; [106.68331909,10.91232967] ; [106.68321228,10.91244984] ; [106.68303680,10.91257954] ; [106.68241882,10.91300964] ; [106.68183136,10.91343021] ; [106.68167114,10.91349983] ; [106.68153381,10.91349030] ; [106.68115234,10.91329956] ; [106.68089294,10.91318035] ; [106.68052673,10.91306019] ; [106.67997742,10.91289043] ; [106.67903900,10.91257954]"
    ,"Distance":"582"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3215"
    ,"Station_Code":"HHM 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Phà An Sơn"
    ,"Station_Address":"Café hoa cau, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.911254
    ,"Long":106.673698
    ,"Polyline":"[106.67903900,10.91257954] ; [106.67736816,10.91207027] ; [106.67375183,10.91106033]"
    ,"Distance":"602"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3217"
    ,"Station_Code":"HHM 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"cầu Bà Năm"
    ,"Station_Address":"Đối diện 18/1, đường Bùi  Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.909653
    ,"Long":106.667496
    ,"Polyline":"[106.67375183,10.91106033] ; [106.67220306,10.91065979] ; [106.66947937,10.90995979] ; [106.66754150,10.90948963]"
    ,"Distance":"700"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3218"
    ,"Station_Code":"HHM 219"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã tư Đất Thánh"
    ,"Station_Address":"Đối diện 56/9A , đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.908304
    ,"Long":106.661598
    ,"Polyline":"[106.66754150,10.90948963] ; [106.66587830,10.90909958] ; [106.66535187,10.90904045] ; [106.66477966,10.90892982] ; [106.66442871,10.90880966] ; [106.66306305,10.90849018] ; [106.66165161,10.90812016]"
    ,"Distance":"662"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3219"
    ,"Station_Code":"HHM 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã Đồn"
    ,"Station_Address":"34, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.907682
    ,"Long":106.654594
    ,"Polyline":"[106.66165161,10.90812016] ; [106.66055298,10.90781975] ; [106.65965271,10.90756989] ; [106.65886688,10.90732002] ; [106.65759277,10.90715027] ; [106.65711212,10.90711975] ; [106.65685272,10.90715027] ; [106.65585327,10.90734005] ; [106.65457916,10.90762043]"
    ,"Distance":"792"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3220"
    ,"Station_Code":"HHM 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Cây Điệp"
    ,"Station_Address":"112, đường Bùi Công Trừng, Huyện Hóc Môn"
    ,"Lat":10.908957
    ,"Long":106.647705
    ,"Polyline":"[106.65457916,10.90762043] ; [106.65245819,10.90802956] ; [106.65106201,10.90830040] ; [106.64990997,10.90849018] ; [106.64927673,10.90857983] ; [106.64768219,10.90884972]"
    ,"Distance":"766"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3221"
    ,"Station_Code":"HHM 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Đông Thạnh"
    ,"Station_Address":"32, đường Đặng Thúc Vinh, Huyện Hóc Môn"
    ,"Lat":10.908514
    ,"Long":106.64345
    ,"Polyline":"[106.64768219,10.90884972] ; [106.64591217,10.90913963] ; [106.64565277,10.90911961] ; [106.64457703,10.90894032] ; [106.64431000,10.90886974] ; [106.64453888,10.90913010.06.64483643]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3222"
    ,"Station_Code":"HHM 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Tạp hóa Nguyên Hiền"
    ,"Station_Address":"49B, đường Đặng Thúc Vinh, Huyện Hóc Môn"
    ,"Lat":10.907461
    ,"Long":106.641669
    ,"Polyline":"[106.64483643,10.90948009] ; [106.64778137,10.91289997]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3223"
    ,"Station_Code":"HHM 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cầu Thi Đua"
    ,"Station_Address":"246, đường Đ ặng Thúc Vinh, Huyện Hóc Môn"
    ,"Lat":10.906934
    ,"Long":106.640897
    ,"Polyline":"[106.64778137,10.91289997] ; [106.64940643,10.91485023] ; [106.64962769,10.91504955] ; [106.64980316,10.91528034] ; [106.65000153,10.91553974] ; [106.64984131,10.91633034]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3224"
    ,"Station_Code":"QCCT250"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Am Dưỡng Bình Mỹ"
    ,"Station_Address":"9/1, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.92087173461914
    ,"Long":106.64927673339844
    ,"Polyline":"[106.64984131,10.91633034] ; [106.65000153,10.91553974] ; [106.64994049,10.91557980] ; [106.64983368,10.91561985] ; [106.64978790,10.91571045] ; [106.64975739,10.91594028] ; [106.64964294,10.91629982] ; [106.64962006,10.91646957] ; [106.64938354,10.91759014] ; [106.64871216,10.92076015]"
    ,"Distance":"696"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3226"
    ,"Station_Code":"QCCT251"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường tiểu học Bình Mỹ 2"
    ,"Station_Address":"21A, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.923336029052734
    ,"Long":106.64889526367188
    ,"Polyline":"[106.64871216,10.92076015] ; [106.64845276,10.92201996] ; [106.64836884,10.92249966] ; [106.64827728,10.92323971]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3225"
    ,"Station_Code":"QCCT252"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"cầu Cây Điệp"
    ,"Station_Address":"Đối diện tạp hóa Mỹ Hằng, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.927634239196777
    ,"Long":106.6476058959961
    ,"Polyline":"[106.64827728,10.92323971] ; [106.64810181,10.92430019] ; [106.64791107,10.92545986] ; [106.64785767,10.92556953] ; [106.64743042,10.92679024] ; [106.64727783,10.92726994] ; [106.64721680,10.92755985]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3228"
    ,"Station_Code":"QCCT253"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Đình Thần Cây Dương"
    ,"Station_Address":"Đình Thần Cây Dương, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.932185173034668
    ,"Long":106.64683532714844
    ,"Polyline":"[106.64721680,10.92755985] ; [106.64640045,10.93210983]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3227"
    ,"Station_Code":"QCCT254"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường tiểu học Bình Hòa"
    ,"Station_Address":"260, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.936988830566406
    ,"Long":106.64610290527344
    ,"Polyline":"[106.64640045,10.93210983] ; [106.64549255,10.93686008]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3229"
    ,"Station_Code":"QCCT255"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 3 Bình Mỹ"
    ,"Station_Address":"94, đường Tỉnh l ộ 9, Huyện Củ Chi"
    ,"Lat":10.94200325012207
    ,"Long":106.6463623046875
    ,"Polyline":"[106.64549255,10.93686008] ; [106.64546204,10.93723965] ; [106.64543915,10.93776989] ; [106.64550018,10.93871021] ; [106.64559937,10.93945980] ; [106.64579010,10.94062996] ; [106.64589691,10.94137001] ; [106.64605713,10.94207001]"
    ,"Distance":"585"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3230"
    ,"Station_Code":"QCCT256"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Bến đò  Bình Mỹ"
    ,"Station_Address":"17, đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.947522163391113
    ,"Long":106.64717864990234
    ,"Polyline":"[106.64605713,10.94207001] ; [106.64659882,10.94447994] ; [106.64694214,10.94556999] ; [106.64698029,10.94581032] ; [106.64697266,10.94624043] ; [106.64675140,10.94686985] ; [106.64659119,10.94731998]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3231"
    ,"Station_Code":"QCCT257"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường mẫu giáo Bình Mỹ 2"
    ,"Station_Address":"Trường mẫu giáo Bình Mỹ 2, đường Tỉnh lộ 9, Huyện C ủ Chi"
    ,"Lat":10.952916145324707
    ,"Long":106.64520263671875
    ,"Polyline":"[106.64659119,10.94731998] ; [106.64611816,10.94863987] ; [106.64572144,10.94946957] ; [106.64475250,10.95275974]"
    ,"Distance":"639"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"3232"
    ,"Station_Code":"QCCT259"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"cafe Vô Thường"
    ,"Station_Address":"cafe Vô Thường , đường Tỉnh lộ 9, Huyện Củ Chi"
    ,"Lat":10.962268829345703
    ,"Long":106.64196014404297
    ,"Polyline":"[106.64475250,10.95279026] ; [106.64409637,10.95503998] ; [106.64376068,10.95611954] ; [106.64298248,10.95847988] ; [106.64263916,10.95954037] ; [106.64205170,10.96117973] ; [106.64164734,10.96214008]"
    ,"Distance":"1095"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"1295"
    ,"Station_Code":"HCC 242"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã 3 Bến Đò"
    ,"Station_Address":"KCN Đông Nam  cửa A (2010B), đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.975667
    ,"Long":106.623184
    ,"Polyline":"[106.64164734,10.96214008] ; [106.64070129,10.96442986] ; [106.64005280,10.96617031] ; [106.63995361,10.96658993] ; [106.63977051,10.96732044] ; [106.63955688,10.96805954] ; [106.63906860,10.96990013] ; [106.63905334,10.97017956] ; [106.63906860,10.97064018] ; [106.63951874,10.97336960] ; [106.64038849,10.97340965] ; [106.64099884,10.97354984] ; [106.64147949,10.97373962] ; [106.64167023,10.97381973]"
    ,"Distance":"1543"
  },
  {
     "Route_Id":"78"
    ,"Station_Id":"1294"
    ,"Station_Code":"BX 66"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bến xe Bình Mỹ"
    ,"Station_Address":"Chân cầu Phú  Cường (Bình Mỹ), đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.979037
    ,"Long":106.64328
    ,"Polyline":"[106.64167023,10.97381973] ; [106.64366913,10.97463036] ; [106.64378357,10.97467995] ; [106.64379883,10.97472000] ; [106.64382935,10.97476959] ; [106.64382935,10.97496033] ; [106.64383698,10.97554970] ; [106.64382172,10.97671032] ; [106.64375305,10.97749996] ; [106.64364624,10.97801971] ; [106.64350891,10.97873974] ; [106.64347839,10.97900963] ; [106.64341736,10.97992039] ; [106.64333344,10.98188972] ; [106.64328766,10.98324013] ; [106.64333344,10.98359966] ; [106.64328766,10.98408985] ; [106.64320374,10.98431969] ; [106.64315796,10.98421955] ; [106.64314270,10.98410034] ; [106.64320374,10.98324966] ; [106.64324188,10.98311996] ; [106.64324951,10.98235035] ; [106.64330292,10.98108959] ; [106.64340973,10.97926044] ; [106.64343262,10.97904968]"
    ,"Distance":"1919"
  }]