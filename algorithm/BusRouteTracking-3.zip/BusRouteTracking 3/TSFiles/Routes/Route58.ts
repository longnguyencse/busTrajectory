export const Route58 =[

  {
     "Route_Id":"58"
    ,"Station_Id":"2804"
    ,"Station_Code":"BX 70"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Nhơn Đức"
    ,"Station_Address":"ĐẦU BẾN NHƠN ĐỨC, đường Lê Văn Lương, Huy ện Nhà Bè"
    ,"Lat":10.658767
    ,"Long":106.690582
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"4232"
    ,"Station_Code":"HNB 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Long Thới - Nhơn Đức"
    ,"Station_Address":"803, đường Lê Văn Lương, Huyện Nhà B è"
    ,"Lat":10.664098
    ,"Long":106.694165
    ,"Polyline":"[106.69058228,10.65876675] ; [106.69438934,10.66429806]"
    ,"Distance":"744"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2814"
    ,"Station_Code":"HNB 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Long Kiểng"
    ,"Station_Address":"1431 , đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.689755
    ,"Long":106.702614
    ,"Polyline":"[106.69438934,10.66429806] ; [106.69613647,10.66708183] ; [106.69745636,10.66900063] ; [106.69792938,10.67043495] ; [106.69797516,10.67191029] ; [106.69814301,10.67397690] ; [106.69892120,10.67680264] ; [106.69960785,10.67941761] ; [106.70053101,10.68262196] ; [106.70156097,10.68582726] ; [106.70228577,10.68783092] ; [106.70255280,10.68993282]"
    ,"Distance":"3039"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2817"
    ,"Station_Code":"HNB 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường Nguy ễn Văn Quỳ"
    ,"Station_Address":"1357, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.692606
    ,"Long":106.703736
    ,"Polyline":"[106.70262909,10.68989182] ; [106.70281219,10.69095135] ; [106.70333862,10.69224739] ; [106.70373535,10.69260597]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2816"
    ,"Station_Code":"HNB 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"111, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.6949
    ,"Long":106.704834
    ,"Polyline":"[106.70373535,10.69260597] ; [106.70437622,10.69375515] ; [106.70483398,10.69489956]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2818"
    ,"Station_Code":"HNB 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Công ty Hoàng Gia Phát"
    ,"Station_Address":"1193, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.700297
    ,"Long":106.70431
    ,"Polyline":"[106.70483398,10.69489956] ; [106.70490265,10.69556904] ; [106.70430756,10.70029736]"
    ,"Distance":"605"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2820"
    ,"Station_Code":"HNB 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện huyện Nhà Bè"
    ,"Station_Address":"113, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.704593
    ,"Long":106.703687
    ,"Polyline":"[106.70430756,10.70029736] ; [106.70372772,10.70448208]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2819"
    ,"Station_Code":"HNB 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Tiễu học lê Quang Định"
    ,"Station_Address":"223, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.708631
    ,"Long":106.702759
    ,"Polyline":"[106.70372772,10.70448208] ; [106.70323181,10.70700741] ; [106.70283508,10.70843506]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2822"
    ,"Station_Code":"HNB 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Đào Sư Tích"
    ,"Station_Address":"951, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.713317
    ,"Long":106.701202
    ,"Polyline":"[106.70283508,10.70843506] ; [106.70233154,10.70977974] ; [106.70120239,10.71331692]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2823"
    ,"Station_Code":"HNB 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Mầm non Anh Quốc"
    ,"Station_Address":"126, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.716642
    ,"Long":106.70012
    ,"Polyline":"[106.70120239,10.71331692] ; [106.70021820,10.71639538]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2821"
    ,"Station_Code":"HNB 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trạm xăng"
    ,"Station_Address":"160, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.719836
    ,"Long":106.699026
    ,"Polyline":"[106.70021820,10.71639538] ; [106.69913483,10.71943283]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"3633"
    ,"Station_Code":"HNB 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Hoàng Anh Gia Lai 3"
    ,"Station_Address":"Đối diện Hoàng Anh Gia Lai 3, đường Nguyễn Hữu Thọ, Huy ện Nhà Bè"
    ,"Lat":10.720395
    ,"Long":106.701815
    ,"Polyline":"[106.69913483,10.71943283] ; [106.69877625,10.72042656] ; [106.69932556,10.72054768] ; [106.69938660,10.72036362] ; [106.69953918,10.72032642] ; [106.70117188,10.72101688] ; [106.70132446,10.72095871] ; [106.70144653,10.72097492] ; [106.70154572,10.72104359] ; [106.70158386,10.72115898] ; [106.70136261,10.72262955] ; [106.70159149,10.72265053]"
    ,"Distance":"661"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1244"
    ,"Station_Code":"Q7 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"291/8, đường Nguy ễn Hữu Thọ, Quận 7"
    ,"Lat":10.729324
    ,"Long":106.700522
    ,"Polyline":"[106.70159149,10.72265053] ; [106.70123291,10.72337818] ; [106.70048523,10.72960758]"
    ,"Distance":"788"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2826"
    ,"Station_Code":"Q7 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Tịnh xá Ngọc Quy"
    ,"Station_Address":"621-623, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.731137
    ,"Long":106.700742
    ,"Polyline":"[106.70048523,10.72960758] ; [106.70035553,10.73007202] ; [106.70049286,10.73077869] ; [106.70069122,10.73075199]"
    ,"Distance":"155"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2827"
    ,"Station_Code":"Q7 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Dinh than Tan Quy"
    ,"Station_Address":"537, đường Lê Văn Lương, Quận  7"
    ,"Lat":10.734531
    ,"Long":106.70226
    ,"Polyline":"[106.70069122,10.73075199] ; [106.70072174,10.73109436] ; [106.70149231,10.73303413] ; [106.70246124,10.73510075] ; [106.70262909,10.73530293]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2830"
    ,"Station_Code":"Q7 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Cầu Rạch Bàng"
    ,"Station_Address":"447, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.737346
    ,"Long":106.703194
    ,"Polyline":"[106.70262909,10.73530293] ; [106.70259857,10.73540115] ; [106.70289612,10.73611259] ; [106.70309448,10.73715019] ; [106.70322418,10.73715591]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1380"
    ,"Station_Code":"Q7 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Lotte Mark"
    ,"Station_Address":"359, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.740208
    ,"Long":106.70369
    ,"Polyline":"[106.70322418,10.73715591] ; [106.70310974,10.73721886] ; [106.70336914,10.73876286] ; [106.70362091,10.74015427] ; [106.70368958,10.74020767]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1382"
    ,"Station_Code":"Q7 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Đường số 15"
    ,"Station_Address":"265, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744471
    ,"Long":106.70432
    ,"Polyline":"[106.70368958,10.74020767] ; [106.70431519,10.74416542]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1453"
    ,"Station_Code":"Q7 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"221, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.745957
    ,"Long":106.704519
    ,"Polyline":"[106.70431519,10.74416542] ; [106.70425415,10.74419212] ; [106.70444489,10.74569893] ; [106.70452881,10.74569130]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1445"
    ,"Station_Code":"Q7 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Phan Huy Thục"
    ,"Station_Address":"179, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.748861
    ,"Long":106.704943
    ,"Polyline":"[106.70452881,10.74569130] ; [106.70454407,10.74628448] ; [106.70487976,10.74876118] ; [106.70502472,10.74883747]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1454"
    ,"Station_Code":"Q7 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"23-25, đường Lê V ăn Lương, Quận 7"
    ,"Lat":10.751468
    ,"Long":106.705124
    ,"Polyline":"[106.70502472,10.74883747] ; [106.70490265,10.74889278] ; [106.70496368,10.74959946] ; [106.70501709,10.74981022] ; [106.70512390,10.75035286] ; [106.70516968,10.75083733] ; [106.70507050,10.75142288] ; [106.70512390,10.75146770]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1988"
    ,"Station_Code":"Q7 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ủy ban Phường Tân Kiểng"
    ,"Station_Address":"525-527, đường  Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751728
    ,"Long":106.706874
    ,"Polyline":"[106.70512390,10.75146770] ; [106.70507813,10.75146008] ; [106.70504761,10.75176525] ; [106.70589447,10.75179672] ; [106.70632935,10.75179672] ; [106.70674896,10.75183010.06.70674896]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1990"
    ,"Station_Code":"Q7 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bế Văn Cấm"
    ,"Station_Address":"429-431, đường Tr ần Xuân Soạn, Quận 7"
    ,"Lat":10.751739
    ,"Long":106.709052
    ,"Polyline":"[106.70674896,10.75179195] ; [106.70895386,10.75177574] ; [106.70903778,10.75169182]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1993"
    ,"Station_Code":"Q7 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Miếu Bà Cố"
    ,"Station_Address":"327, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751776
    ,"Long":106.71263
    ,"Polyline":"[106.70903778,10.75169182] ; [106.70914459,10.75178623] ; [106.70949554,10.75182819] ; [106.71081543,10.75184917] ; [106.71251678,10.75182343] ; [106.71263885,10.75175762]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1992"
    ,"Station_Code":"Q7 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Nhà thờ Thuận Phát"
    ,"Station_Address":"253, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751818
    ,"Long":106.715451
    ,"Polyline":"[106.71263123,10.75187016] ; [106.71543884,10.75189018]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2690"
    ,"Station_Code":"Q7 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cư xá Ngân hàng"
    ,"Station_Address":"181-183, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.752925
    ,"Long":106.719299
    ,"Polyline":"[106.71543884,10.75189018] ; [106.71636200,10.75189018] ; [106.71701050,10.75189972] ; [106.71726990,10.75191975] ; [106.71765137,10.75203037] ; [106.71811676,10.75226974] ; [106.71926117,10.75296974]"
    ,"Distance":"466"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"859"
    ,"Station_Code":"Q7 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cầu Tân Thuận 2"
    ,"Station_Address":"46/14 (chân cầu Tân Thuận 2), đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752424
    ,"Long":106.723927
    ,"Polyline":"[106.71929932,10.75292492] ; [106.72036743,10.75414753] ; [106.72073364,10.75374699] ; [106.72107697,10.75274563] ; [106.72152710,10.75224972] ; [106.72195435,10.75202847] ; [106.72216797,10.75207138] ; [106.72279358,10.75286102] ; [106.72301483,10.75298786] ; [106.72336578,10.75297737] ; [106.72393036,10.75242424]"
    ,"Distance":"773"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"843"
    ,"Station_Code":"Q7 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 49/2, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752498
    ,"Long":106.727414
    ,"Polyline":"[106.72412872,10.75242996] ; [106.72467041,10.75203037] ; [106.72476959,10.75199986] ; [106.72483826,10.75189972] ; [106.72545624,10.75220013] ; [106.72573090,10.75230026] ; [106.72602081,10.75240040] ; [106.72646332,10.75251007] ; [106.72691345,10.75257969] ; [106.72730255,10.75261021]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"846"
    ,"Station_Code":"Q7 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Kho 18"
    ,"Station_Address":"267, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.7549
    ,"Long":106.726204
    ,"Polyline":"[106.72730255,10.75254440] ; [106.72857666,10.75261879] ; [106.72848511,10.75343037] ; [106.72821808,10.75416851] ; [106.72787476,10.75440025] ; [106.72747040,10.75457954] ; [106.72620392,10.75489998]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"845"
    ,"Station_Code":"Q7 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Vòng xoay Tân Thuận"
    ,"Station_Address":"135, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.755423
    ,"Long":106.723946
    ,"Polyline":"[106.72620392,10.75489998] ; [106.72394562,10.75542259]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2828"
    ,"Station_Code":"Q4 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Nguyễn Thần Hiến"
    ,"Station_Address":"23, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.753568
    ,"Long":106.716616
    ,"Polyline":"[106.72393799,10.75537014] ; [106.72347260,10.75547028] ; [106.72338867,10.75547028] ; [106.72325897,10.75545025] ; [106.72318268,10.75541973] ; [106.72308350,10.75535965] ; [106.72289276,10.75518990] ; [106.72270966,10.75506020] ; [106.72255707,10.75500965] ; [106.72242737,10.75500965] ; [106.72235107,10.75502968] ; [106.72168732,10.75533962] ; [106.72113800,10.75561047] ; [106.72010803,10.75609016] ; [106.71882629,10.75666046] ; [106.71875763,10.75685978] ; [106.71878052,10.75708961] ; [106.71897125,10.75757027] ; [106.71911621,10.75796986] ; [106.71916199,10.75800991] ; [106.71923828,10.75806999] ; [106.71938324,10.75809002] ; [106.72051239,10.75765038] ; [106.72058868,10.75755024] ; [106.72061157,10.75745010.06.72038269] ; [10.75675011,106.72016144] ; [10.75619984,106.72003937] ; [10.75597954,106.71978760] ; [10.75568008,106.71942902] ; [10.75535011,106.71843719] ; [10.75446033,106.71790314] ; [10.75405025,106.71724701] ; [10.75360966,106.71704865] ; [10.75356960,106.71661377]"
    ,"Distance":"1624"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2829"
    ,"Station_Code":"Q4 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Khu vui  chơi thiếu nhi"
    ,"Station_Address":"78, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.753399
    ,"Long":106.713644
    ,"Polyline":"[106.71661377,10.75356770] ; [106.71479797,10.75334072] ; [106.71364594,10.75339890]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2832"
    ,"Station_Code":"Q4 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Nhà Thờ  Xóm Chiếu"
    ,"Station_Address":"101-102, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.753346
    ,"Long":106.709341
    ,"Polyline":"[106.71364594,10.75339890] ; [106.71149445,10.75331497] ; [106.70934296,10.75334644]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2831"
    ,"Station_Code":"Q4 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Tôn Đản"
    ,"Station_Address":"163-165, đường  Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.753336
    ,"Long":106.706294
    ,"Polyline":"[106.70934296,10.75334644] ; [106.70629120,10.75333595]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2834"
    ,"Station_Code":"Q4 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Công An Phường 4"
    ,"Station_Address":"183B16, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.75323
    ,"Long":106.703601
    ,"Polyline":"[106.70629120,10.75333595] ; [106.70619202,10.75330925] ; [106.70494843,10.75326729] ; [106.70368195,10.75318813] ; [106.70359802,10.75323009]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2783"
    ,"Station_Code":"BX 12"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Cảng Quận 4"
    ,"Station_Address":"BÃI XE BUÝT CẦU MUỐI, đường Tôn Thất Thuy ết, Quận 4"
    ,"Lat":10.752977
    ,"Long":106.701675
    ,"Polyline":"[106.70359802,10.75323009] ; [106.70354462,10.75318813] ; [106.70176697,10.75306702] ; [106.70167542,10.75297737]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2783"
    ,"Station_Code":"BX 12"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Cảng Quận 4"
    ,"Station_Address":"BÃI XE BUÝT CẦU MUỐI, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.752977
    ,"Long":106.701675
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2782"
    ,"Station_Code":"Q4 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"UBND Phường 4"
    ,"Station_Address":"Đối diện 183N, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.753109
    ,"Long":106.703483
    ,"Polyline":"[106.70167542,10.75297737] ; [106.70178986,10.75305653] ; [106.70348358,10.75310898]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2784"
    ,"Station_Code":"Q4 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tôn Đản"
    ,"Station_Address":"Đối diện 168, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.75322
    ,"Long":106.706074
    ,"Polyline":"[106.70348358,10.75310898] ; [106.70530701,10.75327778] ; [106.70607758,10.75321960]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2785"
    ,"Station_Code":"Q4 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường Đại học Nguyễn Tất Thành"
    ,"Station_Address":"Đối diện 125A, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.753236
    ,"Long":106.709009
    ,"Polyline":"[106.70607758,10.75321960] ; [106.70755768,10.75326729] ; [106.70900726,10.75323582]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2786"
    ,"Station_Code":"Q4 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Khu vui chơi thiếu nhi"
    ,"Station_Address":"Đối diện 78, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.753251
    ,"Long":106.713488
    ,"Polyline":"[106.70900726,10.75323582] ; [106.71348572,10.75325108]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2787"
    ,"Station_Code":"Q4 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nguyễn Thần Hiến"
    ,"Station_Address":"25Bis, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.75332
    ,"Long":106.715258
    ,"Polyline":"[106.71348572,10.75325108] ; [106.71357727,10.75331497] ; [106.71518707,10.75334644] ; [106.71525574,10.75331974]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2788"
    ,"Station_Code":"Q7 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Tân Thuận"
    ,"Station_Address":"11-13 , đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.755802
    ,"Long":106.72206
    ,"Polyline":""
    ,"Distance":"793.915264921476"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"845"
    ,"Station_Code":"Q7 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Vòng xoay Tân Thuận"
    ,"Station_Address":"135, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.755423
    ,"Long":106.723946
    ,"Polyline":""
    ,"Distance":"210.378552786225"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"846"
    ,"Station_Code":"Q7 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Kho 18"
    ,"Station_Address":"267, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.7549
    ,"Long":106.726204
    ,"Polyline":""
    ,"Distance":"253.736325000011"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"843"
    ,"Station_Code":"Q7 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 49/2, đường Nguyễn Văn Linh , Quận 7"
    ,"Lat":10.752498
    ,"Long":106.727414
    ,"Polyline":""
    ,"Distance":"298.522851499879"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"859"
    ,"Station_Code":"Q7 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cầu Tân Thuận 2"
    ,"Station_Address":"46/14 (chân cầu Tân Thuận 2), đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752424
    ,"Long":106.723927
    ,"Polyline":""
    ,"Distance":"381.403213535159"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2789"
    ,"Station_Code":"Q7 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Cư xá Ngân hàng"
    ,"Station_Address":"Đối diện 187A, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.752703
    ,"Long":106.718783
    ,"Polyline":""
    ,"Distance":"564.064598911155"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2067"
    ,"Station_Code":"Q7 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nhà thờ Thuận Phát"
    ,"Station_Address":"Đối diện 253 , đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751902
    ,"Long":106.715049
    ,"Polyline":""
    ,"Distance":"417.647838313176"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2069"
    ,"Station_Code":"Q7 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Miếu Bà Cố"
    ,"Station_Address":"Đối diện 331, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751886
    ,"Long":106.712512
    ,"Polyline":""
    ,"Distance":"277.857126757758"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2068"
    ,"Station_Code":"Q7 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bế Văn Cấm"
    ,"Station_Address":"Đối diện 413, đường Trần Xuân Soạn, Qu ận 7"
    ,"Lat":10.751855
    ,"Long":106.709207
    ,"Polyline":""
    ,"Distance":"361.307967471883"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2070"
    ,"Station_Code":"Q7 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ủy ban Phường Tân Kiểng"
    ,"Station_Address":"Đối diện 505, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.75185
    ,"Long":106.706659
    ,"Polyline":""
    ,"Distance":"278.686868781637"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1442"
    ,"Station_Code":"Q7 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 3 T ân Quy"
    ,"Station_Address":"38, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.751333
    ,"Long":106.705018
    ,"Polyline":""
    ,"Distance":"188.396113513567"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1448"
    ,"Station_Code":"Q7 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Phan Huy Thực"
    ,"Station_Address":"148, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.748961
    ,"Long":106.704825
    ,"Polyline":""
    ,"Distance":"264.848989586413"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1443"
    ,"Station_Code":"Q7 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"192, đường Lê Văn  Lương, Quận 7"
    ,"Lat":10.746068
    ,"Long":106.704422
    ,"Polyline":""
    ,"Distance":"325.11885904313"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1346"
    ,"Station_Code":"Q7 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chung cư Minh Thành"
    ,"Station_Address":"222, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744576
    ,"Long":106.704216
    ,"Polyline":""
    ,"Distance":"167.559674925836"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2790"
    ,"Station_Code":"Q7 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Lotte Mark"
    ,"Station_Address":"384A, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.739464
    ,"Long":106.703414
    ,"Polyline":""
    ,"Distance":"575.841587364009"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2791"
    ,"Station_Code":"Q7 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Rạch Bàng"
    ,"Station_Address":"418A, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.73743
    ,"Long":106.703065
    ,"Polyline":""
    ,"Distance":"229.674782500587"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2792"
    ,"Station_Code":"Q7 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Công an P. Tân Phong"
    ,"Station_Address":"492, đường Lê Văn Lương, Qu ận 7"
    ,"Lat":10.73486
    ,"Long":106.702248
    ,"Polyline":""
    ,"Distance":"299.6143875858"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2793"
    ,"Station_Code":"Q7 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nguyễn Hữu Thọ"
    ,"Station_Address":"582, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.731466
    ,"Long":106.700752
    ,"Polyline":""
    ,"Distance":"411.71129047477"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"1204"
    ,"Station_Code":"Q7 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nguyễn V ăn Linh"
    ,"Station_Address":"645, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.729419
    ,"Long":106.700243
    ,"Polyline":""
    ,"Distance":"234.6875477985"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"3621"
    ,"Station_Code":"HNB 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Hoàng Anh Gia Lai 3"
    ,"Station_Address":"Chung cư HAGL 3, đường Nguy ễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.720084
    ,"Long":106.701332
    ,"Polyline":""
    ,"Distance":"1045.94811305284"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2797"
    ,"Station_Code":"HNB 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm xăng"
    ,"Station_Address":"166E, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.719557
    ,"Long":106.698972
    ,"Polyline":""
    ,"Distance":"264.452770994914"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2796"
    ,"Station_Code":"HNB 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Mầm non  Anh Quốc"
    ,"Station_Address":"134B, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.716853
    ,"Long":106.699857
    ,"Polyline":""
    ,"Distance":"316.154506456068"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2799"
    ,"Station_Code":"HNB 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đào Sư Tích"
    ,"Station_Address":"304A, đường Lê Văn Lương, Huyện Nh à Bè"
    ,"Lat":10.712937
    ,"Long":106.701193
    ,"Polyline":""
    ,"Distance":"459.715479176072"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2798"
    ,"Station_Code":"HNB 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường tiểu học Lê Quang Định"
    ,"Station_Address":"1054, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.708715
    ,"Long":106.70255
    ,"Polyline":""
    ,"Distance":"492.896829226275"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2801"
    ,"Station_Code":"HNB 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bệnh viện huyện Nhà Bè"
    ,"Station_Address":"506-508, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.70505
    ,"Long":106.703484
    ,"Polyline":""
    ,"Distance":"420.4940709317"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2800"
    ,"Station_Code":"HNB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Công ty Hoàng Gia Phát"
    ,"Station_Address":"162,  đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.700583
    ,"Long":106.704117
    ,"Polyline":""
    ,"Distance":"502.066269751201"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2803"
    ,"Station_Code":"HNB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Phạm H ữu Lầu"
    ,"Station_Address":"1358, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.695667
    ,"Long":106.704834
    ,"Polyline":""
    ,"Distance":"552.861660545546"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2802"
    ,"Station_Code":"HNB 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trường Nguyễn Văn Quỳ"
    ,"Station_Address":"137, đường Lê Văn Lương,  Huyện Nhà Bè"
    ,"Lat":10.692474
    ,"Long":106.703382
    ,"Polyline":""
    ,"Distance":"389.197528848337"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2805"
    ,"Station_Code":"HNB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Long Kiểng"
    ,"Station_Address":"1466, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.689981
    ,"Long":106.702502
    ,"Polyline":""
    ,"Distance":"293.91001265958"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"4234"
    ,"Station_Code":"HNB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"KDC Anh Tuấn"
    ,"Station_Address":"1862, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.667677
    ,"Long":106.696413
    ,"Polyline":""
    ,"Distance":"2570.70032497124"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"4233"
    ,"Station_Code":"HNB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Long Thới - Nhơn Đức"
    ,"Station_Address":"Đối diện 817A, đường Lê V ăn Lương, Huyện Nhà Bè"
    ,"Lat":10.663792
    ,"Long":106.693742
    ,"Polyline":""
    ,"Distance":"521.915201787279"
  },
  {
     "Route_Id":"58"
    ,"Station_Id":"2804"
    ,"Station_Code":"BX 70"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Nhơn Đức"
    ,"Station_Address":"ĐẦU BẾN NHƠN ĐỨC, đường Lê Văn Lương, Huyện Nhà Bè"
    ,"Lat":10.658767
    ,"Long":106.690582
    ,"Polyline":""
    ,"Distance":"657.490490002156"
  }]