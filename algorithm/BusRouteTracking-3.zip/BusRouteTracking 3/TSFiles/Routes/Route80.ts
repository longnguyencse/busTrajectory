export const Route80 =[
  {
     "Route_Id":"80"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"KCN LÊ MINH XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường  Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3304"
    ,"Station_Code":"HBC 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường m ầm non Thiên Ân"
    ,"Station_Address":"G15/25, đường  Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.748498
    ,"Long":106.540749
    ,"Polyline":"[106.54013062,10.74388981] ; [106.53942108,10.74427032] ; [106.53952026,10.74442005] ; [106.53961182,10.74468994] ; [106.53958893,10.74483967] ; [106.53954315,10.74493027] ; [106.53946686,10.74497986] ; [106.53928375,10.74507046] ; [106.53909302,10.74518967] ; [106.53904724,10.74528027] ; [106.53909302,10.74542046] ; [106.53955841,10.74633980] ; [106.53997803,10.74728966] ; [106.54055786,10.74857044]"
    ,"Distance":"638"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3306"
    ,"Station_Code":"HBC 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty  Đại Vĩnh Lợi"
    ,"Station_Address":"G15/2A, đ ường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.75206
    ,"Long":106.542326
    ,"Polyline":"[106.54055786,10.74857044] ; [106.54183960,10.75146008]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3305"
    ,"Station_Code":"HBC 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cổng 4"
    ,"Station_Address":"G14/11, đường Láng Le b àu Cò, Huyện Bình Chánh"
    ,"Lat":10.755866
    ,"Long":106.544015
    ,"Polyline":"[106.54183960,10.75146008] ; [106.54360962,10.75543022]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3308"
    ,"Station_Code":"HBC 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cổng 3"
    ,"Station_Address":"G13 /27B, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.759123
    ,"Long":106.54567
    ,"Polyline":"[106.54360962,10.75543022] ; [106.54418182,10.75667953] ; [106.54547119,10.75905991] ; [106.54548645,10.75911045]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3307"
    ,"Station_Code":"HBC 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Cổng 2"
    ,"Station_Address":"G12/28B, đường Láng Le b àu Cò, Huyện Bình Chánh"
    ,"Lat":10.761736
    ,"Long":106.547073
    ,"Polyline":"[106.54548645,10.75911045] ; [106.54689789,10.76171017]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3309"
    ,"Station_Code":"HBC 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cổng 1 - Ngã tư Bà Lát"
    ,"Station_Address":"G12/8, đường  Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.765779
    ,"Long":106.549305
    ,"Polyline":"[106.54689789,10.76171017] ; [106.54840088,10.76449966] ; [106.54895020,10.76546955]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3310"
    ,"Station_Code":"HBC 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Sập"
    ,"Station_Address":"G111/11, đường Láng Le b àu Cò, Huyện Bình Chánh"
    ,"Lat":10.768651
    ,"Long":106.550785
    ,"Polyline":"[106.54895020,10.76546955] ; [106.55052948,10.76834965]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3311"
    ,"Station_Code":"HBC 302"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty Thịnh Uy"
    ,"Station_Address":"Đối diện 1A/38/1, đường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.767349
    ,"Long":106.557877
    ,"Polyline":"[106.55052948,10.76834965] ; [106.55119324,10.76959038] ; [106.55166626,10.77054024] ; [106.55168915,10.77066040] ; [106.55320740,10.76986980] ; [106.55328369,10.76980019] ; [106.55320740,10.76966000] ; [106.55377197,10.76937008] ; [106.55429840,10.76908970]"
    ,"Distance":"638"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3313"
    ,"Station_Code":"HBC 303"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Coop Mart Vĩnh Lộc B"
    ,"Station_Address":"Đối diện 1A/24 /2, đường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.764925
    ,"Long":106.563097
    ,"Polyline":"[106.55429840,10.76908970] ; [106.55754852,10.76743031] ; [106.55966949,10.76642990] ; [106.56004333,10.76626015]"
    ,"Distance":"702"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3312"
    ,"Station_Code":"HBC 304"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Võ Văn  Vân"
    ,"Station_Address":"Đối diện 1A/7, đường Trần  Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.763033
    ,"Long":106.567174
    ,"Polyline":"[106.56004333,10.76626015] ; [106.56133270,10.76566982] ; [106.56208801,10.76527977] ; [106.56282043,10.76492977] ; [106.56455994,10.76414013] ; [106.56539154,10.76375008]"
    ,"Distance":"648"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3315"
    ,"Station_Code":"QBT 192"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Dapha"
    ,"Station_Address":"24/2, đường Võ Văn Vân, Quận Bình Tân"
    ,"Lat":10.766785
    ,"Long":106.569464
    ,"Polyline":"[106.56539154,10.76375008] ; [106.56566620,10.76362038] ; [106.56574249,10.76377010.06.56719208] ; [10.76309967,106.56764984] ; [10.76290989,106.56775665] ; [10.76292992,106.56829071] ; [10.76412964,106.56873322] ; [10.76529980,106.56938171]"
    ,"Distance":"763"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3314"
    ,"Station_Code":"HBC 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 3 Dapha"
    ,"Station_Address":"24, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.76893
    ,"Long":106.570306
    ,"Polyline":"[106.56938171,10.76683044] ; [106.56990814,10.76809978] ; [106.57025146,10.76898956]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3318"
    ,"Station_Code":"HBC 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Doanh trại Quân Đội"
    ,"Station_Address":"A7/3A, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.77372
    ,"Long":106.572018
    ,"Polyline":"[106.57025146,10.76898956] ; [106.57058716,10.76988983] ; [106.57102203,10.77093029] ; [106.57156372,10.77221012] ; [106.57173920,10.77272987] ; [106.57186890,10.77357960] ; [106.57196045,10.77381992]"
    ,"Distance":"571"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3316"
    ,"Station_Code":"HBC 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm xăng Hồng Lý"
    ,"Station_Address":"A7/8A , đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.777003
    ,"Long":106.573498
    ,"Polyline":"[106.57196045,10.77381992] ; [106.57234192,10.77482033] ; [106.57263184,10.77530956] ; [106.57285309,10.77585983] ; [106.57344818,10.77707005] ; [106.57379150,10.77690983]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3317"
    ,"Station_Code":"HBC 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Ấp  1"
    ,"Station_Address":"A8/24A, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.780508
    ,"Long":106.573488
    ,"Polyline":"[106.57379150,10.77690983] ; [106.57344818,10.77707005] ; [106.57377625,10.77781010.06.57379150] ; [10.77808952,106.57369232] ; [10.77855015,106.57324219] ; [10.77943039,106.57324219] ; [10.77954960,106.57341003]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3319"
    ,"Station_Code":"HBC 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Hai Sang"
    ,"Station_Address":"A9/7C, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.783512
    ,"Long":106.574244
    ,"Polyline":"[106.57341003,10.78055954] ; [106.57380676,10.78269958] ; [106.57386017,10.78291035] ; [106.57396698,10.78314972] ; [106.57407379,10.78332043] ; [106.57424927,10.78376961] ; [106.57457733,10.78370953]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3322"
    ,"Station_Code":"HBC 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Đình Thần"
    ,"Station_Address":"B5/32, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.786974
    ,"Long":106.575413
    ,"Polyline":"[106.57457733,10.78370953] ; [106.57424927,10.78376961] ; [106.57440948,10.78411007] ; [106.57479095,10.78528023] ; [106.57508087,10.78616047] ; [106.57540131,10.78699970]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3320"
    ,"Station_Code":"HBC 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Vĩnh Lộc B"
    ,"Station_Address":"Đối diện C9/23, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.790457
    ,"Long":106.576202
    ,"Polyline":"[106.57540131,10.78699970] ; [106.57569122,10.78781986] ; [106.57585907,10.78837013] ; [106.57592773,10.78884029] ; [106.57605743,10.78942966] ; [106.57610321,10.78985023] ; [106.57614899,10.79036999] ; [106.57615662,10.79045963]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3323"
    ,"Station_Code":"HBC 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Liên Ấp"
    ,"Station_Address":"C2/14B, đường Võ Văn Vân,  Huyện Bình Chánh"
    ,"Lat":10.793355
    ,"Long":106.576476
    ,"Polyline":"[106.57615662,10.79045963] ; [106.57621002,10.79133987] ; [106.57624817,10.79176044] ; [106.57640839,10.79337978]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2322"
    ,"Station_Code":"HBC 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Minh Nhật"
    ,"Station_Address":"C6/16A, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.799663
    ,"Long":106.577682
    ,"Polyline":"[106.57640839,10.79337978] ; [106.57644653,10.79376030] ; [106.57646179,10.79393959] ; [106.57656097,10.79434967] ; [106.57669830,10.79487038] ; [106.57691956,10.79568005] ; [106.57718658,10.79652977] ; [106.57742310,10.79755974] ; [106.57759094,10.79907036] ; [106.57760620,10.79973030]"
    ,"Distance":"721"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2323"
    ,"Station_Code":"HBC 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ống Cống"
    ,"Station_Address":"D15/22, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.805064
    ,"Long":106.578037
    ,"Polyline":"[106.57760620,10.79973030] ; [106.57763672,10.80198956] ; [106.57778168,10.80288029] ; [106.57794189,10.80416012] ; [106.57807159,10.80506039]"
    ,"Distance":"596"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2324"
    ,"Station_Code":"HBC 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Rạng Đông"
    ,"Station_Address":"Đối diện D20 /4/2B, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.811145
    ,"Long":106.578932
    ,"Polyline":"[106.57807159,10.80506039] ; [106.57824707,10.80622959] ; [106.57849121,10.80803967] ; [106.57868195,10.80930996] ; [106.57884216,10.81033993] ; [106.57939911,10.81042004]"
    ,"Distance":"655"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2439"
    ,"Station_Code":"HBC 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Nguyễn  Thị Tú"
    ,"Station_Address":"D7/15, đường Nguy ễn Thị Tú, Huyện Bình Chánh"
    ,"Lat":10.813832
    ,"Long":106.580488
    ,"Polyline":"[106.57939911,10.81042004] ; [106.57884216,10.81033993] ; [106.57901764,10.81173992] ; [106.57916260,10.81295013] ; [106.58049774,10.81332016] ; [106.58109283,10.81348038] ; [106.58106995,10.81371975] ; [106.58103943,10.81404018] ; [106.58164215,10.81416035] ; [106.58287048,10.81443024]"
    ,"Distance":"840"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2441"
    ,"Station_Code":"QBT 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Thép Quốc Thái"
    ,"Station_Address":"507, đường Nguyễn Thị Tú, Quận Bình T ân"
    ,"Lat":10.814548
    ,"Long":106.584091
    ,"Polyline":"[106.58287048,10.81443024] ; [106.58405304,10.81470966]"
    ,"Distance":"132"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2443"
    ,"Station_Code":"QBT 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Công ty Thịnh Khang"
    ,"Station_Address":"415-419, đường Nguyễn Thị  Tú, Quận Bình Tân"
    ,"Lat":10.81497
    ,"Long":106.586288
    ,"Polyline":"[106.58405304,10.81470966] ; [106.58603668,10.81515980] ; [106.58630371,10.81517029]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2442"
    ,"Station_Code":"QBT 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cafe Gia Nguyễn"
    ,"Station_Address":"355, đường Nguy ễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.81516
    ,"Long":106.589607
    ,"Polyline":"[106.58630371,10.81517029] ; [106.58895874,10.81525040] ; [106.58959961,10.81529999]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2445"
    ,"Station_Code":"QBT 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Nhà hàng tiệc cưới Thịnh Phư ớc"
    ,"Station_Address":"255B, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815407
    ,"Long":106.592563
    ,"Polyline":"[106.58959961,10.81529999] ; [106.59126282,10.81538963] ; [106.59249878,10.81550980]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2444"
    ,"Station_Code":"QBT 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Công ty  Bảo Ngọc Châu"
    ,"Station_Address":"117, đường  Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.81555
    ,"Long":106.594913
    ,"Polyline":"[106.59249878,10.81550980] ; [106.59487152,10.81567001]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1904"
    ,"Station_Code":"QBT 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Hội quán"
    ,"Station_Address":"197 (Hội quán), đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.817604
    ,"Long":106.601593
    ,"Polyline":"[106.59487152,10.81567001] ; [106.59867096,10.81595993] ; [106.59950256,10.81604958] ; [106.60008240,10.81630993] ; [106.60030365,10.81636047] ; [106.60061646,10.81632042] ; [106.60106659,10.81622982] ; [106.60124969,10.81624031] ; [106.60140228,10.81698990] ; [106.60153198,10.81762028]"
    ,"Distance":"864"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1897"
    ,"Station_Code":"QBT 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Nồi Hơi"
    ,"Station_Address":"117, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.820871
    ,"Long":106.602333
    ,"Polyline":"[106.60153198,10.81762028] ; [106.60221863,10.82089043]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1906"
    ,"Station_Code":"QBT 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Quang Châu"
    ,"Station_Address":"19-21, đường  Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.823305
    ,"Long":106.602783
    ,"Polyline":"[106.60221863,10.82089043] ; [106.60273743,10.82332039]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1899"
    ,"Station_Code":"Q12 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Lộc Ích"
    ,"Station_Address":"168, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.827779
    ,"Long":106.603855
    ,"Polyline":"[106.60273743,10.82332039] ; [106.60291290,10.82415009] ; [106.60311127,10.82499027] ; [106.60346985,10.82670021] ; [106.60372925,10.82791042]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1908"
    ,"Station_Code":"Q12 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã tư Bà Điểm"
    ,"Station_Address":"2945, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.833269
    ,"Long":106.606559
    ,"Polyline":"[106.60372925,10.82791042] ; [106.60398102,10.82874966] ; [106.60415649,10.82923985] ; [106.60439301,10.82979012] ; [106.60476685,10.83047009] ; [106.60540009,10.83152008] ; [106.60629272,10.83300972]"
    ,"Distance":"635"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1901"
    ,"Station_Code":"Q12 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Qua ng ã tư Bà Điểm"
    ,"Station_Address":"2879, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.834887
    ,"Long":106.607616
    ,"Polyline":"[106.60629272,10.83300972] ; [106.60753632,10.83504963]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1910"
    ,"Station_Code":"Q12 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm Rác"
    ,"Station_Address":"88 /1, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.837358
    ,"Long":106.609543
    ,"Polyline":"[106.60753632,10.83504963] ; [106.60825348,10.83611965] ; [106.60880280,10.83673954] ; [106.60949707,10.83740044]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1903"
    ,"Station_Code":"Q12 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Trạm măng"
    ,"Station_Address":"2797, đường Quốc lộ 1A,  Quận 12"
    ,"Lat":10.839368
    ,"Long":107.611801
    ,"Polyline":"[106.60949707,10.83740044] ; [106.61177063,10.83940983]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1905"
    ,"Station_Code":"Q12 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Cầu vượt ngã tư An Sương"
    ,"Station_Address":"10P, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.841183
    ,"Long":106.61408
    ,"Polyline":"[106.61177063,10.83940983] ; [106.61296082,10.84047031] ; [106.61347198,10.84080029] ; [106.61395264,10.84123039]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bến xe An  Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61395264,10.84123039] ; [106.61499023,10.84216022] ; [106.61524200,10.84237003] ; [106.61517334,10.84239960] ; [106.61511993,10.84243011] ; [106.61506653,10.84249973] ; [106.61502075,10.84265041] ; [106.61504364,10.84278965] ; [106.61508179,10.84286976] ; [106.61486053,10.84325981] ; [106.61412048,10.84449005] ; [106.61405182,10.84459972] ; [106.61386108,10.84449005] ; [106.61338806,10.84424973] ; [106.61322784,10.84414005] ; [106.61312103,10.84407997] ; [106.61319733,10.84385967]"
    ,"Distance":"623"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1926"
    ,"Station_Code":"HHM 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Trạm măng"
    ,"Station_Address":"45/9C, đường Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.840398
    ,"Long":106.612535
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61486816,10.84304047] ; [106.61483765,10.84269047] ; [106.61469269,10.84237957] ; [106.61463928,10.84230042] ; [106.61327362,10.84103966] ; [106.61298370,10.84064960] ; [106.61258698,10.84031010]"
    ,"Distance":"744"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1921"
    ,"Station_Code":"HHM 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Hồng Mộc"
    ,"Station_Address":"41/1A, đường Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.836957
    ,"Long":106.608651
    ,"Polyline":"[106.61258698,10.84031010.06.60903931] ; [10.83714008,106.60874939]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1928"
    ,"Station_Code":"HHM 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã tư Bà Điểm"
    ,"Station_Address":"57/7B, đường Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.832674
    ,"Long":106.605804
    ,"Polyline":"[106.60874939,10.83685970] ; [106.60842133,10.83652020] ; [106.60807037,10.83613014] ; [106.60778046,10.83572006] ; [106.60697937,10.83444023] ; [106.60595703,10.83273029] ; [106.60588837,10.83263016]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1922"
    ,"Station_Code":"HHM 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Kiềm Nghĩa"
    ,"Station_Address":"59/2, đường Qu ốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.829117
    ,"Long":106.603888
    ,"Polyline":"[106.60588837,10.83263016] ; [106.60469818,10.83061028] ; [106.60431671,10.82991028] ; [106.60402679,10.82925034] ; [106.60395813,10.82907009]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1930"
    ,"Station_Code":"QBT 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Quang Châu"
    ,"Station_Address":"5/30K, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.823311
    ,"Long":106.602554
    ,"Polyline":"[106.60395813,10.82907009] ; [106.60388184,10.82884979] ; [106.60368347,10.82820988] ; [106.60340118,10.82701015] ; [106.60260773,10.82330036]"
    ,"Distance":"659"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1923"
    ,"Station_Code":"QBT 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Vĩ Phong"
    ,"Station_Address":"136, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.821082
    ,"Long":106.60202
    ,"Polyline":"[106.60260773,10.82330036] ; [106.60211945,10.82106018]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"1932"
    ,"Station_Code":"QBT 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Gò Mây"
    ,"Station_Address":"230, đường Quốc  lộ 1A, Quận Bình Tân"
    ,"Lat":10.818021
    ,"Long":106.601379
    ,"Polyline":"[106.60211945,10.82106018] ; [106.60144806,10.81801033]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2520"
    ,"Station_Code":"QBT 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty Bảo Châu"
    ,"Station_Address":"88, đường Nguy ễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815697
    ,"Long":106.594925
    ,"Polyline":"[106.60144806,10.81801033] ; [106.60117340,10.81669998] ; [106.60105896,10.81653023] ; [106.60092926,10.81639004] ; [106.60061646,10.81632042] ; [106.60030365,10.81636047] ; [106.60008240,10.81630993] ; [106.59950256,10.81604958] ; [106.59867096,10.81595993] ; [106.59764862,10.81587982] ; [106.59493256,10.81567955]"
    ,"Distance":"858"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2511"
    ,"Station_Code":"QBT 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà hàng Thịnh Phước"
    ,"Station_Address":"Đối diện 255B , đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815518
    ,"Long":106.592453
    ,"Polyline":"[106.59493256,10.81567955] ; [106.59304810,10.81556034] ; [106.59245300,10.81550026]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2518"
    ,"Station_Code":"QBT 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Công ty  Gia Nguyễn"
    ,"Station_Address":"210, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815318
    ,"Long":106.589088
    ,"Polyline":"[106.59245300,10.81550026] ; [106.59126282,10.81538963] ; [106.59046936,10.81534958] ; [106.58908844,10.81525993]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2513"
    ,"Station_Code":"QBT 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Công ty Thịnh Khang"
    ,"Station_Address":"264, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815228
    ,"Long":106.586555
    ,"Polyline":"[106.58908844,10.81525993] ; [106.58656311,10.81517982]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2516"
    ,"Station_Code":"QBT 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Thép Quốc Thái"
    ,"Station_Address":"D1/1B, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.814812
    ,"Long":106.58387
    ,"Polyline":"[106.58656311,10.81517982] ; [106.58603668,10.81515980] ; [106.58390045,10.81466961]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2517"
    ,"Station_Code":"HBC 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 5 Vĩnh Lộc"
    ,"Station_Address":"1, đường  Nguyễn Thị Tú, Huyện Bình Chánh"
    ,"Lat":10.8139
    ,"Long":106.580215
    ,"Polyline":"[106.58390045,10.81466961] ; [106.58206177,10.81424999]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2369"
    ,"Station_Code":"HBC 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Ống Cống"
    ,"Station_Address":"D20/4/3B, đường Võ Văn Vân , Huyện Bình Chánh"
    ,"Lat":10.81144
    ,"Long":106.578895
    ,"Polyline":"[106.58206177,10.81424999] ; [106.58103943,10.81406403] ; [106.57966614,10.81378937] ; [106.57916260,10.81355762] ; [106.57921600,10.81329441] ; [106.57894135,10.81110001]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2370"
    ,"Station_Code":"HBC 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Minh Nhật"
    ,"Station_Address":"D10/25F, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.805859
    ,"Long":106.578053
    ,"Polyline":"[106.57894135,10.81110001] ; [106.57849121,10.80803967] ; [106.57824707,10.80622959] ; [106.57819366,10.80583000]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2371"
    ,"Station_Code":"HBC 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ li ên ấp 123"
    ,"Station_Address":"C6/13A, đường Võ  Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.800158
    ,"Long":106.577575
    ,"Polyline":"[106.57819366,10.80583000] ; [106.57798767,10.80453968] ; [106.57791138,10.80393028] ; [106.57765961,10.80218029] ; [106.57762909,10.80134964] ; [106.57760620,10.80016041]"
    ,"Distance":"635"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2373"
    ,"Station_Code":"HBC 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Phòng Khám"
    ,"Station_Address":"C8/28B, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.794868
    ,"Long":106.576658
    ,"Polyline":"[106.57760620,10.80016041] ; [106.57759094,10.79907036] ; [106.57742310,10.79755974] ; [106.57718658,10.79652977] ; [106.57691956,10.79568005] ; [106.57669067,10.79483986]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3281"
    ,"Station_Code":"HBC 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Vĩnh Lộc B"
    ,"Station_Address":"B11b/13A, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.790141
    ,"Long":106.576068
    ,"Polyline":"[106.57669067,10.79483986] ; [106.57656097,10.79434967] ; [106.57646179,10.79393959] ; [106.57644653,10.79376030] ; [106.57633209,10.79265022] ; [106.57624817,10.79176044] ; [106.57621002,10.79133987] ; [106.57614899,10.79036999] ; [106.57614136,10.79018021]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3280"
    ,"Station_Code":"HBC 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đình Thần"
    ,"Station_Address":"B10/9N, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.786663
    ,"Long":106.575209
    ,"Polyline":"[106.57614136,10.79018021] ; [106.57610321,10.78985023] ; [106.57605743,10.78942966] ; [106.57592773,10.78884029] ; [106.57585907,10.78837013] ; [106.57569122,10.78781986] ; [106.57524109,10.78658962]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3283"
    ,"Station_Code":"HBC 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Hai Sang"
    ,"Station_Address":"B7/21C, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.783585
    ,"Long":106.574185
    ,"Polyline":"[106.57524109,10.78658962] ; [106.57492065,10.78571033] ; [106.57457733,10.78462029] ; [106.57440948,10.78411007] ; [106.57424927,10.78376961] ; [106.57382965,10.78384972] ; [106.57370758,10.78390026]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3282"
    ,"Station_Code":"HBC 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ Ấp 1"
    ,"Station_Address":"A19/17G, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.780255
    ,"Long":106.573359
    ,"Polyline":"[106.57370758,10.78390026] ; [106.57382965,10.78384972] ; [106.57424927,10.78376961] ; [106.57407379,10.78332043] ; [106.57396698,10.78314972] ; [106.57386017,10.78291035] ; [106.57380676,10.78269958] ; [106.57334900,10.78024960]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3285"
    ,"Station_Code":"HBC 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm xăng Hồng Lý"
    ,"Station_Address":"A7/7, đường Võ Văn Vân, Huy ện Bình Chánh"
    ,"Lat":10.776645
    ,"Long":106.57323
    ,"Polyline":"[106.57334900,10.78024960] ; [106.57324219,10.77954960] ; [106.57324219,10.77943039] ; [106.57369232,10.77855015] ; [106.57379150,10.77808952] ; [106.57377625,10.77781010.06.57318878]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3284"
    ,"Station_Code":"HBC 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Doanh trại Quân Đội"
    ,"Station_Address":"A7/11A, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.773784
    ,"Long":106.571943
    ,"Polyline":"[106.57318878,10.77653980] ; [106.57285309,10.77585983] ; [106.57270813,10.77548981] ; [106.57234192,10.77482033] ; [106.57192230,10.77373028]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3287"
    ,"Station_Code":"HBC 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã 3 Dapha"
    ,"Station_Address":"17, đường Võ Văn Vân, Huyện Bình Chánh"
    ,"Lat":10.76884
    ,"Long":106.570183
    ,"Polyline":"[106.57192230,10.77373028] ; [106.57186890,10.77357960] ; [106.57176971,10.77293968] ; [106.57167816,10.77254009] ; [106.57128143,10.77153969] ; [106.57058716,10.76988983] ; [106.57019043,10.76881981]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3286"
    ,"Station_Code":"QBT 193"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Dapha"
    ,"Station_Address":"17, đường Võ Văn Vân, Quận Bình Tân"
    ,"Lat":10.766248
    ,"Long":106.569142
    ,"Polyline":"[106.57019043,10.76881981] ; [106.56973267,10.76764965] ; [106.56913757,10.76626015]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3289"
    ,"Station_Code":"HBC 280"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Võ Văn Vân"
    ,"Station_Address":"1A7, đường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.763138
    ,"Long":106.567447
    ,"Polyline":"[106.56913757,10.76626015] ; [106.56873322,10.76529980] ; [106.56829071,10.76412964] ; [106.56775665,10.76292992] ; [106.56665802,10.76344013] ; [106.56456757,10.76441956]"
    ,"Distance":"786"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3288"
    ,"Station_Code":"HBC 281"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Coop mart Vĩnh Lộc B"
    ,"Station_Address":"1A24 /2, đường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.765099
    ,"Long":106.563247
    ,"Polyline":"[106.56452942,10.76443005] ; [106.55883789,10.76706982]"
    ,"Distance":"688"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3290"
    ,"Station_Code":"HBC 282"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Công ty  Thịnh Uy"
    ,"Station_Address":"1A38/1, đường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.767576
    ,"Long":106.557931
    ,"Polyline":"[106.55883789,10.76706982] ; [106.55764771,10.76762009] ; [106.55570221,10.76861000] ; [106.55341339,10.76980972]"
    ,"Distance":"667"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3292"
    ,"Station_Code":"HBC 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã tư Bà Lát"
    ,"Station_Address":"Đối diện G11/10, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.768487
    ,"Long":106.550608
    ,"Polyline":"[106.55341339,10.76980972] ; [106.55332184,10.76986027] ; [106.55320740,10.76986980] ; [106.55168915,10.77066040] ; [106.55145264,10.77071953] ; [106.55110168,10.77000046] ; [106.55005646,10.76809978]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3293"
    ,"Station_Code":"HBC 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cổng 1"
    ,"Station_Address":"Đối diện G12/7, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.765947
    ,"Long":106.549283
    ,"Polyline":"[106.55005646,10.76809978] ; [106.54882813,10.76583004]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3291"
    ,"Station_Code":"HBC 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cổng 2"
    ,"Station_Address":"Đối diện G12/31, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.762274
    ,"Long":106.547234
    ,"Polyline":"[106.54882813,10.76583004] ; [106.54711151,10.76268005]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3294"
    ,"Station_Code":"HBC 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cổng 3"
    ,"Station_Address":"Đối diện D17/38 , đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.759449
    ,"Long":106.5457
    ,"Polyline":"[106.54711151,10.76268005] ; [106.54550171,10.75973034]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3296"
    ,"Station_Code":"HBC 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Cổng 4"
    ,"Station_Address":"Đối diện G14/18, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.756271
    ,"Long":106.544096
    ,"Polyline":"[106.54550171,10.75973034] ; [106.54398346,10.75691986] ; [106.54370117,10.75629997]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3295"
    ,"Station_Code":"HBC 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Công ty Đại Vĩnh Lợi"
    ,"Station_Address":"Đối diện G14/40, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.752825
    ,"Long":106.542556
    ,"Polyline":"[106.54370117,10.75629997] ; [106.54212189,10.75277042]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"3297"
    ,"Station_Code":"HBC 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường mầm non Thiên Ân"
    ,"Station_Address":"Đối diện G15/37, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.748856
    ,"Long":106.540791
    ,"Polyline":"[106.54212189,10.75277042] ; [106.54023743,10.74857044]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"80"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"KCN LÊ MINH XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường Trần  Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":"[106.54023743,10.74857044] ; [106.53881073,10.74536991] ; [106.53840637,10.74555016] ; [106.53820801,10.74549961] ; [106.53791046,10.74503994] ; [106.53885651,10.74456978] ; [106.53910065,10.74446011] ; [106.53942108,10.74427032] ; [106.54013062,10.74388981]"
    ,"Distance":"795"
  }]