export const Route34 =[

  {
     "Route_Id":"34"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"BÃI XE BUÝT ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT ĐẦM SEN, đường Hòa Bình,  Quận 11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1043"
    ,"Station_Code":"Q11 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"3  (79), đường Hòa Bình, Quận 11"
    ,"Lat":10.76698
    ,"Long":106.641571
    ,"Polyline":"[106.63967133,10.76786041] ; [106.63986969,10.76781273] ; [106.64046478,10.76749134] ; [106.64096832,10.76729012] ; [106.64115143,10.76718998] ; [106.64140320,10.76710033] ; [106.64158630,10.76704025] ; [106.64157104,10.76698017]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1029"
    ,"Station_Code":"Q11 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"40A, đường Hòa Bình, Quận 11"
    ,"Lat":10.767302
    ,"Long":106.641181
    ,"Polyline":"[106.64157104,10.76698017] ; [106.64158630,10.76704025] ; [106.64187622,10.76690102] ; [106.64200592,10.76688004] ; [106.64218903,10.76684475] ; [106.64220428,10.76681805] ; [106.64220428,10.76677418] ; [106.64221954,10.76671886] ; [106.64225006,10.76667976] ; [106.64228821,10.76665592] ; [106.64231873,10.76664925] ; [106.64238739,10.76664448] ; [106.64244080,10.76665592] ; [106.64248657,10.76668930] ; [106.64251709,10.76674271] ; [106.64253235,10.76681137] ; [106.64251709,10.76687336] ; [106.64248657,10.76691532] ; [106.64244080,10.76693821] ; [106.64238739,10.76695633] ; [106.64233398,10.76694679] ; [106.64226532,10.76692486] ; [106.64205933,10.76695919] ; [106.64180756,10.76706409] ; [106.64160919,10.76703644] ; [106.64150238,10.76716423] ; [106.64128113,10.76722240] ; [106.64110565,10.76728535]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1616"
    ,"Station_Code":"Q11 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường H òa Bình"
    ,"Station_Address":"72, đường Hòa Bình, Quận 11"
    ,"Lat":10.768496
    ,"Long":106.639137
    ,"Polyline":"[106.64108276,10.76723003] ; [106.63979340,10.76797962] ; [106.63909912,10.76842022]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1604"
    ,"Station_Code":"QTP 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Đầm Sen"
    ,"Station_Address":"45 (Đối diện công viên nư ớc Đầm Sen), đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769367
    ,"Long":106.63707
    ,"Polyline":"[106.63909912,10.76842022] ; [106.63761139,10.76900005] ; [106.63701630,10.76924038]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1617"
    ,"Station_Code":"QTP 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Chùa Huệ  Quang"
    ,"Station_Address":"116, đường Hòa B ình, Quận Tân Phú"
    ,"Lat":10.769747
    ,"Long":106.635246
    ,"Polyline":"[106.63701630,10.76924038] ; [106.63658905,10.76939964] ; [106.63613892,10.76953030] ; [106.63587189,10.76957989] ; [106.63551331,10.76959038] ; [106.63526917,10.76955986]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1619"
    ,"Station_Code":"QTP 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"126, đường Hòa B ình, Quận Tân Phú"
    ,"Lat":10.77
    ,"Long":106.633362
    ,"Polyline":"[106.63526917,10.76955986] ; [106.63452911,10.76947975] ; [106.63440704,10.76947975] ; [106.63432312,10.76947021] ; [106.63411713,10.76951981] ; [106.63390350,10.76963043] ; [106.63336182,10.76982975]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1621"
    ,"Station_Code":"QTP 143"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trung Tâm Mua Sắm"
    ,"Station_Address":"214, đường H òa Bình, Quận Tân Phú"
    ,"Lat":10.771277
    ,"Long":106.629044
    ,"Polyline":"[106.63330841,10.76984024] ; [106.63278961,10.77000999] ; [106.63179779,10.77029037] ; [106.63123322,10.77048969] ; [106.63047791,10.77079010.06.62935638] ; [10.77114964,106.62904358]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1605"
    ,"Station_Code":"QTP 142"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"278, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.772361
    ,"Long":106.626106
    ,"Polyline":"[106.62904358,10.77126026] ; [106.62606049,10.77223015]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1606"
    ,"Station_Code":"QTP 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"314-316, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.773267
    ,"Long":106.6231
    ,"Polyline":"[106.62606049,10.77223015] ; [106.62306213,10.77313995]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1781"
    ,"Station_Code":"QBT 248"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã tư 4 xã"
    ,"Station_Address":"426, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.77323
    ,"Long":106.620297
    ,"Polyline":"[106.62310028,10.77326679] ; [106.62276459,10.77347279] ; [106.62217712,10.77364159] ; [106.62159729,10.77373123] ; [106.62132263,10.77367306] ; [106.62083435,10.77345181] ; [106.62044525,10.77329350] ; [106.62024689,10.77341461]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1782"
    ,"Station_Code":"QBT 247"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cửa hàng điện thoại di động"
    ,"Station_Address":"482 trạm cân, đường Hương  lộ 2, Quận Bình Tân"
    ,"Lat":10.771939
    ,"Long":106.617696
    ,"Polyline":"[106.62024689,10.77341461] ; [106.62001801,10.77315617] ; [106.61825562,10.77227592] ; [106.61776733,10.77215004]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1780"
    ,"Station_Code":"QBT 246"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Đình Tân Khai"
    ,"Station_Address":"550, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.770811
    ,"Long":106.615008
    ,"Polyline":"[106.61776733,10.77215004] ; [106.61764526,10.77189732] ; [106.61643982,10.77144909] ; [106.61528015,10.77090073] ; [106.61500549,10.77074814]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1783"
    ,"Station_Code":"QBT 245"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"620, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.767813
    ,"Long":106.609231
    ,"Polyline":"[106.61500549,10.77074814] ; [106.61462402,10.77057934] ; [106.61402130,10.77031612] ; [106.61354828,10.77005291] ; [106.61318207,10.76990509] ; [106.61265564,10.76956749] ; [106.61096191,10.76863956] ; [106.61018372,10.76823044] ; [106.60961914,10.76799011] ; [106.60938263,10.76788616] ; [106.60919952,10.76786518]"
    ,"Distance":"714"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1784"
    ,"Station_Code":"QBT 244"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"964, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.766664
    ,"Long":106.606607
    ,"Polyline":"[106.60919952,10.76786518] ; [106.60913086,10.76775455] ; [106.60893250,10.76764011] ; [106.60769653,10.76710033] ; [106.60692596,10.76680660] ; [106.60664368,10.76685905]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1785"
    ,"Station_Code":"QBT 235"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"816"
    ,"Station_Address":"816, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.766933
    ,"Long":106.599559
    ,"Polyline":"[106.60664368,10.76685905] ; [106.60646057,10.76653194] ; [106.60524750,10.76595974] ; [106.60444641,10.76556015] ; [106.60386658,10.76529026] ; [106.60325623,10.76498985] ; [106.60308838,10.76494026] ; [106.60295868,10.76486015] ; [106.60269928,10.76484013] ; [106.60253906,10.76484013] ; [106.60231781,10.76486969] ; [106.60218811,10.76490974] ; [106.60199738,10.76500988] ; [106.60182190,10.76513958] ; [106.60137939,10.76554012] ; [106.60076141,10.76605034] ; [106.60027313,10.76642036] ; [106.59993744,10.76673222] ; [106.59973907,10.76683807] ; [106.59955597,10.76701736]"
    ,"Distance":"925"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1787"
    ,"Station_Code":"QBT 234"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"912"
    ,"Station_Address":"912, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.768334
    ,"Long":106.595213
    ,"Polyline":"[106.59955597,10.76701736] ; [106.59928131,10.76706982] ; [106.59824371,10.76735973] ; [106.59799957,10.76737976] ; [106.59783936,10.76735973] ; [106.59751892,10.76733971] ; [106.59748077,10.76731014] ; [106.59732819,10.76733017] ; [106.59703064,10.76739025] ; [106.59702301,10.76741982] ; [106.59665680,10.76751041] ; [106.59622955,10.76770973] ; [106.59593964,10.76788044] ; [106.59574127,10.76799011] ; [106.59535217,10.76824474] ; [106.59526062,10.76842976]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1786"
    ,"Station_Code":"QBT 233"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"990"
    ,"Station_Address":"990 , đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.769178
    ,"Long":106.593288
    ,"Polyline":"[106.59526062,10.76842976] ; [106.59498596,10.76842403] ; [106.59480286,10.76847649] ; [106.59432983,10.76873016] ; [106.59389496,10.76894569] ; [106.59344482,10.76910877] ; [106.59328461,10.76931477]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1789"
    ,"Station_Code":"QBT 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nghĩa trang  Bình TÂn"
    ,"Station_Address":"950, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.768545
    ,"Long":106.590935
    ,"Polyline":"[106.59328461,10.76931477] ; [106.59320831,10.76914024] ; [106.59293365,10.76926041] ; [106.59266663,10.76939011] ; [106.59229279,10.76963043] ; [106.59179688,10.76982021] ; [106.59149933,10.76998901] ; [106.59139252,10.77019501] ; [106.59124756,10.77017403] ; [106.59098053,10.76854038] ; [106.59093475,10.76854515]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1788"
    ,"Station_Code":"QBT 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Bà Hom"
    ,"Station_Address":"978A, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.762401
    ,"Long":106.590683
    ,"Polyline":"[106.59098053,10.76854038] ; [106.59059906,10.76671982] ; [106.59052277,10.76624012] ; [106.59043884,10.76539993] ; [106.59044647,10.76469994] ; [106.59050751,10.76410007] ; [106.59056854,10.76379013] ; [106.59079742,10.76241970]"
    ,"Distance":"707"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1791"
    ,"Station_Code":"QBT 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà sách Tân Tạo"
    ,"Station_Address":"1024, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.758026
    ,"Long":106.591492
    ,"Polyline":"[106.59079742,10.76241970] ; [106.59136963,10.75918007] ; [106.59134674,10.75897026] ; [106.59145355,10.75819016] ; [106.59147644,10.75802040]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1790"
    ,"Station_Code":"QBT 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Khu Công nghiệp Tân Tạo"
    ,"Station_Address":"666, đường Quốc l ộ 1A, Quận Bình Tân"
    ,"Lat":10.752793
    ,"Long":106.592392
    ,"Polyline":"[106.59149170,10.75802612] ; [106.59147644,10.75802040] ; [106.59175873,10.75644970] ; [106.59213257,10.75438023] ; [106.59218597,10.75390530] ; [106.59217072,10.75279999] ; [106.59212494,10.75279331]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1792"
    ,"Station_Code":"QBT 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Công ty Pouyuen"
    ,"Station_Address":"Đối diện Pouyen, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.746899
    ,"Long":106.595367
    ,"Polyline":"[106.59212494,10.75279331] ; [106.59217072,10.75279999] ; [106.59230042,10.75205994] ; [106.59243774,10.75156021] ; [106.59264374,10.75092030] ; [106.59278107,10.75061035] ; [106.59298706,10.75016975] ; [106.59329224,10.75028992] ; [106.59352112,10.74989033] ; [106.59375763,10.74950027] ; [106.59417725,10.74882030] ; [106.59510803,10.74729633] ; [106.59536743,10.74689865]"
    ,"Distance":"789"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1793"
    ,"Station_Code":"QBT 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Công ty Hai Thành"
    ,"Station_Address":"A5/13Q, đường  Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.743526
    ,"Long":106.597519
    ,"Polyline":"[106.59549713,10.74672985] ; [106.59661102,10.74499989] ; [106.59738159,10.74376965] ; [106.59741211,10.74372959]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1794"
    ,"Station_Code":"QBT 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Điện Quốc lộ 1A"
    ,"Station_Address":"A5/3Q, đường Quốc lộ 1A, Quận Bình T ân"
    ,"Lat":10.740001
    ,"Long":106.599724
    ,"Polyline":"[106.59741211,10.74372959] ; [106.59976959,10.73997021]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1795"
    ,"Station_Code":"QBT 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Công an Quận Bình Tân"
    ,"Station_Address":"1054  (Quán ăn Xa lộ), đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.736204
    ,"Long":106.602081
    ,"Polyline":"[106.59976959,10.73997021] ; [106.60070801,10.73845959] ; [106.60172272,10.73686028] ; [106.60208893,10.73622036]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1797"
    ,"Station_Code":"QBT 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Siêu thị Big C"
    ,"Station_Address":"Siêu thị Big C, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.731232
    ,"Long":106.60508
    ,"Polyline":"[106.60208893,10.73622036] ; [106.60225677,10.73591042] ; [106.60249329,10.73536015] ; [106.60265350,10.73474026] ; [106.60266113,10.73458004] ; [106.60281372,10.73458958] ; [106.60292816,10.73449039] ; [106.60321045,10.73437023] ; [106.60356903,10.73412037] ; [106.60431671,10.73291969] ; [106.60529327,10.73136044]"
    ,"Distance":"700"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1796"
    ,"Station_Code":"QBT 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã tư An Lạc"
    ,"Station_Address":"551, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.728676
    ,"Long":106.606819
    ,"Polyline":"[106.60507965,10.73123169] ; [106.60530090,10.73115826] ; [106.60678864,10.72884941] ; [106.60681915,10.72867584]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1799"
    ,"Station_Code":"QBT 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Khu phố 2"
    ,"Station_Address":"515, đường H ồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.726019
    ,"Long":106.608459
    ,"Polyline":"[106.60681915,10.72867584] ; [106.60694122,10.72875023] ; [106.60816193,10.72679996] ; [106.60841370,10.72635078] ; [106.60845947,10.72601891]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1798"
    ,"Station_Code":"QBT 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Sùng Quang"
    ,"Station_Address":"76, đường H ồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.723284
    ,"Long":106.610566
    ,"Polyline":"[106.60858917,10.72609043] ; [106.60949707,10.72463989] ; [106.61033630,10.72331047]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1801"
    ,"Station_Code":"QBT 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Khu dân cư Hương lộ 5"
    ,"Station_Address":"297, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.72068
    ,"Long":106.611877
    ,"Polyline":"[106.61033630,10.72331047] ; [106.61196899,10.72072983]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1800"
    ,"Station_Code":"QBT 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Nhựa Long Thành"
    ,"Station_Address":"215, đường Hồ Học Lãm, Qu ận Bình Tân"
    ,"Lat":10.718161
    ,"Long":106.613464
    ,"Polyline":"[106.61196899,10.72072983] ; [106.61260986,10.71967983] ; [106.61354065,10.71819973]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1803"
    ,"Station_Code":"Q8 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chùa Viên Giác"
    ,"Station_Address":"3, đường Hồ Học Lãm, Quận 8"
    ,"Lat":10.712624
    ,"Long":106.616989
    ,"Polyline":"[106.61354065,10.71819973] ; [106.61486816,10.71607018] ; [106.61599731,10.71428967] ; [106.61704254,10.71265984]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"765"
    ,"Station_Code":"Q8 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bến Phú Định"
    ,"Station_Address":"Đ/d 21, đường Bến  Phú Định, Quận 8"
    ,"Lat":10.710881
    ,"Long":106.620415
    ,"Polyline":"[106.61704254,10.71265984] ; [106.61788940,10.71129990] ; [106.61823273,10.71078968] ; [106.61830902,10.71070004] ; [106.61837769,10.71065998] ; [106.61856079,10.71068001] ; [106.61924744,10.71065044] ; [106.61955261,10.71068954] ; [106.61998749,10.71080971] ; [106.62023163,10.71090984] ; [106.62039185,10.71096039]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"764"
    ,"Station_Code":"Q8 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"UBND Phường 16, Quận 8"
    ,"Station_Address":"6B, đường Bến Phú Định, Quận 8"
    ,"Lat":10.712199
    ,"Long":106.623752
    ,"Polyline":"[106.62041473,10.71088123] ; [106.62039185,10.71096039] ; [106.62084961,10.71109009] ; [106.62120819,10.71113968] ; [106.62332916,10.71146965] ; [106.62344360,10.71152020] ; [106.62351990,10.71162033] ; [106.62367249,10.71199322] ; [106.62374878,10.71219921] ; [106.62384796,10.71225739]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"766"
    ,"Station_Code":"Q8 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Cầu Nhà Thương"
    ,"Station_Address":"Đối diện 63A, đường Bến Phú Định, Quận 8"
    ,"Lat":10.716279
    ,"Long":106.626053
    ,"Polyline":"[106.62364197,10.71228981] ; [106.62374878,10.71286011] ; [106.62384796,10.71313953] ; [106.62391663,10.71323013] ; [106.62402344,10.71327019] ; [106.62439728,10.71329975] ; [106.62449646,10.71331978] ; [106.62458801,10.71339035] ; [106.62490082,10.71409988] ; [106.62593079,10.71630955] ; [106.62593079,10.71632004]"
    ,"Distance":"582"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1802"
    ,"Station_Code":"Q8 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Đường 44"
    ,"Station_Address":"32, đường Đư ờng 44 Trương Đình Hội, Quận 8"
    ,"Lat":10.719521
    ,"Long":106.622421
    ,"Polyline":"[106.62593079,10.71632004] ; [106.62609100,10.71673012] ; [106.62550354,10.71704006] ; [106.62499237,10.71728039] ; [106.62409973,10.71755028] ; [106.62222290,10.71813965] ; [106.62232208,10.71918011] ; [106.62235260,10.71953011]"
    ,"Distance":"679"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1805"
    ,"Station_Code":"BX 76"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Đường 44"
    ,"Station_Address":"44, đường Đường 44 Trư ơng Đình Hội, Quận 8"
    ,"Lat":10.723932
    ,"Long":106.622685
    ,"Polyline":"[106.62235260,10.71953011] ; [106.62268829,10.72311020]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1805"
    ,"Station_Code":"BX 76"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Đường 44"
    ,"Station_Address":"44, đường Đường 44 Trương Đình Hội, Quận 8"
    ,"Lat":10.723932
    ,"Long":106.622685
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1846"
    ,"Station_Code":"Q8 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Đường 44"
    ,"Station_Address":"Đối diện 40 , đường Đường 44 Trương Đình Hội, Quận 8"
    ,"Lat":10.718898
    ,"Long":106.62225
    ,"Polyline":"[106.62268829,10.72311020] ; [106.62230682,10.71905041]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"793"
    ,"Station_Code":"Q8 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Nhà Th ương"
    ,"Station_Address":"68Bis, đường Bến Phú Định, Quận 8"
    ,"Lat":10.716215
    ,"Long":106.625855
    ,"Polyline":"[106.62230682,10.71905041] ; [106.62222290,10.71813965] ; [106.62409973,10.71755028] ; [106.62499237,10.71728039] ; [106.62550354,10.71704006] ; [106.62609100,10.71673012] ; [106.62593079,10.71630955] ; [106.62583923,10.71611023]"
    ,"Distance":"628"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"795"
    ,"Station_Code":"Q8 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"UBND Phường 16, Quận 8"
    ,"Station_Address":"450, đường Bến Phú Định, Quận 8"
    ,"Lat":10.71212
    ,"Long":106.623554
    ,"Polyline":"[106.62583923,10.71611023] ; [106.62490082,10.71409988] ; [106.62458801,10.71339035] ; [106.62449646,10.71331978] ; [106.62439728,10.71329975] ; [106.62402344,10.71327019] ; [106.62391663,10.71323013] ; [106.62384796,10.71313953] ; [106.62374878,10.71286011] ; [106.62361908,10.71218014] ; [106.62361908,10.71214008]"
    ,"Distance":"536"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"804"
    ,"Station_Code":"Q8 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Phú Định"
    ,"Station_Address":"31-33, đường Bến Phú Định, Quận 8"
    ,"Lat":10.710755
    ,"Long":106.619418
    ,"Polyline":"[106.62361908,10.71214008] ; [106.62351990,10.71162033] ; [106.62344360,10.71152020] ; [106.62332916,10.71146965] ; [106.62254333,10.71133995] ; [106.62120819,10.71113968] ; [106.62084961,10.71109009] ; [106.62023163,10.71090984] ; [106.61985779,10.71076965]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1847"
    ,"Station_Code":"Q8 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chùa Viên Giác"
    ,"Station_Address":"Đối diện Chùa Giác Viên, đường Hồ Học Lãm, Quận 8"
    ,"Lat":10.713359
    ,"Long":106.616848
    ,"Polyline":"[106.61985779,10.71076965] ; [106.61930847,10.71065044] ; [106.61908722,10.71065044] ; [106.61859894,10.71067047] ; [106.61844635,10.71065998] ; [106.61837769,10.71065998] ; [106.61830902,10.71070004] ; [106.61808777,10.71098042] ; [106.61669922,10.71319008] ; [106.61637878,10.71370029]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1849"
    ,"Station_Code":"QBT 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhựa Long Thành"
    ,"Station_Address":"Đối diện 201, đư ờng Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.718234
    ,"Long":106.613817
    ,"Polyline":"[106.61637878,10.71370029] ; [106.61554718,10.71500015] ; [106.61421204,10.71716022] ; [106.61358643,10.71811962]"
    ,"Distance":"579"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1848"
    ,"Station_Code":"QBT 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Võ Văn Kiệt"
    ,"Station_Address":"109-258, đường H ồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.72069
    ,"Long":106.612229
    ,"Polyline":"[106.61358643,10.71811962] ; [106.61260986,10.71967983] ; [106.61205292,10.72058964]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1850"
    ,"Station_Code":"QBT 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chùa Sùng Quang"
    ,"Station_Address":"324, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.72283
    ,"Long":106.610577
    ,"Polyline":"[106.61205292,10.72058964] ; [106.61122894,10.72189999] ; [106.61090851,10.72241974] ; [106.61064148,10.72284985]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1851"
    ,"Station_Code":"QBT 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Khu phố 2"
    ,"Station_Address":"35, đường  Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.725845
    ,"Long":106.608775
    ,"Polyline":"[106.61064148,10.72284985] ; [106.60874939,10.72581959]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1852"
    ,"Station_Code":"QBT 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã tư An Lạc"
    ,"Station_Address":"488, đường Hồ Học  Lãm, Quận Bình Tân"
    ,"Lat":10.729012
    ,"Long":106.606857
    ,"Polyline":"[106.60874939,10.72581959] ; [106.60768890,10.72754002] ; [106.60679626,10.72896957]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1853"
    ,"Station_Code":"QBT 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Siêu thị Big C"
    ,"Station_Address":"588, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.731232
    ,"Long":106.605507
    ,"Polyline":"[106.60679626,10.72896957] ; [106.60540009,10.73116970]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1855"
    ,"Station_Code":"QBT 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Hẻm Sinco Hồ Ngọc Lãm"
    ,"Station_Address":"E4/39, đường  Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.734642
    ,"Long":106.603302
    ,"Polyline":"[106.60540009,10.73116970] ; [106.60356903,10.73412037] ; [106.60339355,10.73447037] ; [106.60327911,10.73466015]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1856"
    ,"Station_Code":"QBT 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Điện Quốc lộ 1A"
    ,"Station_Address":"1229C, đường  Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.737657
    ,"Long":106.601364
    ,"Polyline":"[106.60327911,10.73466015] ; [106.60289764,10.73526955] ; [106.60257721,10.73575020] ; [106.60221100,10.73637962] ; [106.60208130,10.73649979] ; [106.60183716,10.73688030] ; [106.60137177,10.73762035]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1854"
    ,"Station_Code":"QBT 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Công ty Hai Thành"
    ,"Station_Address":"E4/48, đường  Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.742307
    ,"Long":106.598442
    ,"Polyline":"[106.60137177,10.73762035] ; [106.59906769,10.74131012] ; [106.59851837,10.74215984]"
    ,"Distance":"593"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1857"
    ,"Station_Code":"QBT 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Công ty Pouyuen"
    ,"Station_Address":"Công ty Pouyuen, đường Quốc lộ 1A, Qu ận Bình Tân"
    ,"Lat":10.747634
    ,"Long":106.595078
    ,"Polyline":"[106.59851837,10.74215984] ; [106.59500885,10.74771023]"
    ,"Distance":"727"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1858"
    ,"Station_Code":"QBT 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"KCN Tân Tạo"
    ,"Station_Address":"56, đường Quốc l ộ 1A, Quận Bình Tân"
    ,"Lat":10.752967
    ,"Long":106.592692
    ,"Polyline":"[106.59500885,10.74771023] ; [106.59382629,10.74958992] ; [106.59361267,10.74993992] ; [106.59340668,10.75030041] ; [106.59303284,10.75115013] ; [106.59285736,10.75172997] ; [106.59259796,10.75288963]"
    ,"Distance":"640"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1859"
    ,"Station_Code":"QBT 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhà sách Tân Tạo"
    ,"Station_Address":"1167-1169, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.755164
    ,"Long":106.592369
    ,"Polyline":"[106.59259796,10.75288963] ; [106.59249878,10.75333977] ; [106.59248352,10.75360012] ; [106.59220886,10.75514030]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1861"
    ,"Station_Code":"QBT 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm xăng số 5"
    ,"Station_Address":"1137 (D11/89A), đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.757884
    ,"Long":106.591858
    ,"Polyline":"[106.59220886,10.75514030] ; [106.59201050,10.75638008] ; [106.59188080,10.75714970] ; [106.59175110,10.75786018]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1863"
    ,"Station_Code":"QBT 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chung cư Tân Mai"
    ,"Station_Address":"Đối diện 952, đường Quốc lộ 1A, Quận Bình  Tân"
    ,"Lat":10.763075
    ,"Long":106.590927
    ,"Polyline":"[106.59175110,10.75786018] ; [106.59133148,10.76006031] ; [106.59081268,10.76305962]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1865"
    ,"Station_Code":"QBT 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"1087 , đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.768476
    ,"Long":106.591148
    ,"Polyline":"[106.59081268,10.76305962] ; [106.59063721,10.76408958] ; [106.59056854,10.76484013] ; [106.59056854,10.76541042] ; [106.59062958,10.76622963] ; [106.59071350,10.76669025] ; [106.59089661,10.76753044] ; [106.59108734,10.76848984]"
    ,"Distance":"611"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1860"
    ,"Station_Code":"QBT 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Quốc lộ  1A"
    ,"Station_Address":"1013 , đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.769257
    ,"Long":106.59288
    ,"Polyline":"[106.59108734,10.76848984] ; [106.59140015,10.76996040] ; [106.59159088,10.76988983] ; [106.59210968,10.76970959] ; [106.59237671,10.76957035] ; [106.59266663,10.76939011] ; [106.59290314,10.76926994]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1862"
    ,"Station_Code":"QBT 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh vi ện Bình Tân"
    ,"Station_Address":"927, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.768387
    ,"Long":106.594838
    ,"Polyline":"[106.59293365,10.76926041] ; [106.59398651,10.76879025] ; [106.59483337,10.76838017]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1864"
    ,"Station_Code":"QBT 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bệnh viện Bình Tân"
    ,"Station_Address":"863 , đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.767349
    ,"Long":106.597477
    ,"Polyline":"[106.59483337,10.76838017] ; [106.59526062,10.76821041] ; [106.59552002,10.76807976] ; [106.59584808,10.76793003] ; [106.59609222,10.76778030] ; [106.59651184,10.76756954] ; [106.59673309,10.76749039] ; [106.59702301,10.76741982] ; [106.59703064,10.76739025] ; [106.59741211,10.76731968]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1866"
    ,"Station_Code":"QBT 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Thạch cao  Thanh Tài"
    ,"Station_Address":"737, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.766184
    ,"Long":106.605835
    ,"Polyline":"[106.59748077,10.76731014] ; [106.59751892,10.76733971] ; [106.59774017,10.76735020] ; [106.59787750,10.76737022] ; [106.59812164,10.76737976] ; [106.59825134,10.76735973] ; [106.59979248,10.76667976] ; [106.60027313,10.76642036] ; [106.60076141,10.76605034] ; [106.60137939,10.76554012] ; [106.60182190,10.76513958] ; [106.60199738,10.76500988] ; [106.60218811,10.76490974] ; [106.60231781,10.76486969] ; [106.60253906,10.76484013] ; [106.60269928,10.76484013] ; [106.60295868,10.76486015] ; [106.60308838,10.76494026] ; [106.60325623,10.76498985] ; [106.60386658,10.76529026] ; [106.60444641,10.76556015] ; [106.60524750,10.76595974] ; [106.60575104,10.76618958]"
    ,"Distance":"1024"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1868"
    ,"Station_Code":"QBT 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Bình Trị"
    ,"Station_Address":"637, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.768187
    ,"Long":106.610207
    ,"Polyline":"[106.60575104,10.76618958] ; [106.60685730,10.76671982] ; [106.60756683,10.76704979] ; [106.60784149,10.76716995] ; [106.60903931,10.76768017] ; [106.60961914,10.76799011] ; [106.61009216,10.76819038]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1867"
    ,"Station_Code":"QBT 249"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"589"
    ,"Station_Address":"589, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.77049
    ,"Long":106.6146
    ,"Polyline":"[106.61009216,10.76819038] ; [106.61036682,10.76832008] ; [106.61096191,10.76863956] ; [106.61154175,10.76891041] ; [106.61327362,10.76972008] ; [106.61374664,10.76998043] ; [106.61412811,10.77013969] ; [106.61464691,10.77040958]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1869"
    ,"Station_Code":"QBT 250"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"497"
    ,"Station_Address":"497, đường Hương l ộ 2, Quận Bình Tân"
    ,"Lat":10.771697
    ,"Long":106.617358
    ,"Polyline":"[106.61464691,10.77040958] ; [106.61746979,10.77178001]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1870"
    ,"Station_Code":"QBT 232"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã tư 4, 4 xã"
    ,"Station_Address":"Đ/d 418-145, đường Hương lộ 2, Quận Bình T ân"
    ,"Lat":10.772983
    ,"Long":106.620773
    ,"Polyline":"[106.61746979,10.77178001] ; [106.62058258,10.77332020]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1568"
    ,"Station_Code":"QTP 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"257, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.772962
    ,"Long":106.62294
    ,"Polyline":"[106.62058258,10.77332020] ; [106.62133789,10.77367973] ; [106.62148285,10.77363968] ; [106.62158966,10.77357960] ; [106.62300110,10.77315998]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1563"
    ,"Station_Code":"QTP 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"245, đường  Hòa Bình, Quận Tân Phú"
    ,"Lat":10.772165
    ,"Long":106.6259
    ,"Polyline":"[106.62300110,10.77315998] ; [106.62593079,10.77227020]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1565"
    ,"Station_Code":"QTP 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trâm Tâm Mua Sắm"
    ,"Station_Address":"165, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.771252
    ,"Long":106.628975
    ,"Polyline":"[106.62593079,10.77227020] ; [106.62898254,10.77128029]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1570"
    ,"Station_Code":"QTP 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"69, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769694
    ,"Long":106.633057
    ,"Polyline":"[106.62897491,10.77125168] ; [106.63305664,10.76969433]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1567"
    ,"Station_Code":"QTP 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Cây Xăng Hòa Bình"
    ,"Station_Address":"176/26, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769394
    ,"Long":106.63533
    ,"Polyline":"[106.63305664,10.76969433] ; [106.63336182,10.76974201] ; [106.63388824,10.76953030] ; [106.63421631,10.76949978] ; [106.63432312,10.76947021] ; [106.63439941,10.76947975] ; [106.63446045,10.76947975] ; [106.63478851,10.76944637] ; [106.63509369,10.76947308] ; [106.63533020,10.76939392]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1571"
    ,"Station_Code":"Q11 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Thuỷ Tạ"
    ,"Station_Address":"đd 90 (nhà hàng Thủy Tạ Đầm Sen), đường H òa Bình, Quận 11"
    ,"Lat":10.768719
    ,"Long":106.637909
    ,"Polyline":"[106.63533020,10.76939392] ; [106.63544464,10.76954174] ; [106.63571167,10.76959038] ; [106.63597870,10.76955986] ; [106.63630676,10.76949024] ; [106.63687134,10.76930046] ; [106.63793182,10.76887035] ; [106.63796234,10.76885033] ; [106.63790894,10.76871872]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1569"
    ,"Station_Code":"Q11 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"7B (Bến xe buýt Đầm Sen), đường Hòa B ình, Quận 11"
    ,"Lat":10.767916
    ,"Long":106.639511
    ,"Polyline":"[106.63790894,10.76871872] ; [106.63796234,10.76885033] ; [106.63870239,10.76849747] ; [106.63908386,10.76835060] ; [106.63943481,10.76813412] ; [106.63951111,10.76791573]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"34"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"BÃI XE BUÝT ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT ĐẦM SEN, đường Hòa Bình, Quận 11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":"[106.63951111,10.76791573] ; [106.63957977,10.76799202] ; [106.63964844,10.76797581] ; [106.63967133,10.76786041]"
    ,"Distance":"32"
  }]