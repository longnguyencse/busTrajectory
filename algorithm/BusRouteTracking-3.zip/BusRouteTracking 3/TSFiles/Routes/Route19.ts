export const Route19 =[
  {
     "Route_Id":"19"
    ,"Station_Id":"1186"
    ,"Station_Code":"Q9 230"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Công ty TNHH Thuận Thành Tâm"
    ,"Station_Address":"Công ty TNHH Thuận Thành  Tâm, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.892685
    ,"Long":106.822804
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1188"
    ,"Station_Code":"Q9 231"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Công ty Dosan"
    ,"Station_Address":"Công ty Dosan, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.888961
    ,"Long":106.820047
    ,"Polyline":"[106.82362366,10.89361954] ; [106.81923676,10.88766003]"
    ,"Distance":"818"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1187"
    ,"Station_Code":"Q9 232"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty Cp Đức Khải"
    ,"Station_Address":"Công ty Cp Đức Khải, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.879241
    ,"Long":106.812918
    ,"Polyline":"[106.81923676,10.88766003] ; [106.81300354,10.87917042]"
    ,"Distance":"1165"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"572"
    ,"Station_Code":"QTD 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"621-Ngã 3 Lâm Viên"
    ,"Station_Address":"Nhà máy Tiến Thành, đường Qu ốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871128
    ,"Long":106.806979
    ,"Polyline":"[106.81300354,10.87917042] ; [106.81025696,10.87545967] ; [106.80934906,10.87423992] ; [106.80892181,10.87368011] ; [106.80873871,10.87341022] ; [106.80798340,10.87234020] ; [106.80744171,10.87158012] ; [106.80683899,10.87077999]"
    ,"Distance":"1151"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo dục Quốc phòng, đường Quốc  lộ 1, Quận Thủ Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80683899,10.87077999] ; [106.80651855,10.87038040] ; [106.80586243,10.86958027] ; [106.80507660,10.86878967] ; [106.80455017,10.86830044] ; [106.80441284,10.86816978]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"574"
    ,"Station_Code":"QTD 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Khu DL Suối Tiên"
    ,"Station_Address":"9/29, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86605
    ,"Long":106.801116
    ,"Polyline":"[106.80441284,10.86816978] ; [106.80362701,10.86754036] ; [106.80291748,10.86703968] ; [106.80229950,10.86666012] ; [106.80117798,10.86598015]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"398"
    ,"Station_Code":"QTD 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Khu Công nghệ cao Q9"
    ,"Station_Address":"Đối diện Khu  công nghệ cao, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.860545
    ,"Long":106.791723
    ,"Polyline":"[106.80117798,10.86598015] ; [106.79895020,10.86468029] ; [106.79505920,10.86238003] ; [106.79054260,10.85970020] ; [106.78871155,10.85859013]"
    ,"Distance":"1592"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"401"
    ,"Station_Code":"QTD 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Công ty Cocacola"
    ,"Station_Address":"Công ty Cocacola, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.856483
    ,"Long":106.784964
    ,"Polyline":"[106.78871155,10.85859013] ; [106.78813934,10.85824966] ; [106.78781128,10.85799980] ; [106.78724670,10.85772991] ; [106.78677368,10.85744953] ; [106.78600311,10.85698032] ; [106.78494263,10.85636997]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1113"
    ,"Station_Code":"QTD 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã tư Thủ Đức"
    ,"Station_Address":"Đối diện Coopmart , đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.84828
    ,"Long":106.77299
    ,"Polyline":"[106.78494263,10.85636997] ; [106.78103638,10.85406017] ; [106.77652740,10.85136986] ; [106.77603149,10.85103989] ; [106.77538300,10.85056973] ; [106.77496338,10.85021973] ; [106.77391052,10.84926033] ; [106.77340698,10.84871006] ; [106.77314758,10.84836006] ; [106.77310181,10.84827042]"
    ,"Distance":"1587"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1111"
    ,"Station_Code":"QTD 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Betong H ải Âu"
    ,"Station_Address":"Đối diện Betong Hải Âu, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.844297
    ,"Long":106.77063
    ,"Polyline":"[106.77310181,10.84827042] ; [106.77133942,10.84535027] ; [106.77044678,10.84377003]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1112"
    ,"Station_Code":"QTD 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"UBND Quận 9"
    ,"Station_Address":"126, đường  Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.840745
    ,"Long":106.768607
    ,"Polyline":"[106.77044678,10.84377003] ; [106.76873016,10.84070969]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"410"
    ,"Station_Code":"QTD 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Đối diện 592C, đường Xa Lộ Hà Nội, Qu ận Thủ Đức"
    ,"Lat":10.834945
    ,"Long":106.765244
    ,"Polyline":"[106.76873016,10.84070969] ; [106.76544952,10.83495045]"
    ,"Distance":"734"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"413"
    ,"Station_Code":"QTD 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Công ty truyền tải điện 4"
    ,"Station_Address":"Công ty truyền tải điện 4, đường Xa L ộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.831214
    ,"Long":106.763195
    ,"Polyline":"[106.76544952,10.83495045] ; [106.76335144,10.83117008]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"412"
    ,"Station_Code":"QTD 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"Nhà máy thép Thủ Đức, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.825366
    ,"Long":106.759998
    ,"Polyline":"[106.76335144,10.83117008] ; [106.76077271,10.82660961] ; [106.76042175,10.82596970] ; [106.76006317,10.82534027]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"414"
    ,"Station_Code":"QTD 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Xi măng Hà Tiên"
    ,"Station_Address":"Xi măng Hà Tiên 1, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.820576
    ,"Long":106.758142
    ,"Polyline":"[106.76006317,10.82534027] ; [106.75936127,10.82404041] ; [106.75901031,10.82326984] ; [106.75881958,10.82271957] ; [106.75849915,10.82153034] ; [106.75832367,10.82067966] ; [106.75824738,10.82028961]"
    ,"Distance":"599"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"415"
    ,"Station_Code":"Q2 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Đối diện Esstella, đường Xa  Lộ Hà Nội, Quận 2"
    ,"Lat":10.802925
    ,"Long":106.747948
    ,"Polyline":"[106.75824738,10.82028961] ; [106.75800323,10.81882000] ; [106.75762177,10.81719971] ; [106.75750732,10.81649971] ; [106.75665283,10.81186962] ; [106.75646210,10.81079006] ; [106.75637054,10.81039047] ; [106.75617981,10.80984020] ; [106.75598145,10.80965996] ; [106.75581360,10.80947018] ; [106.75559235,10.80926037] ; [106.75546265,10.80908012] ; [106.75527191,10.80881023] ; [106.75486755,10.80805969] ; [106.75475311,10.80792999] ; [106.75462341,10.80772018] ; [106.75428772,10.80725002] ; [106.75395203,10.80685043] ; [106.75332642,10.80630016] ; [106.75301361,10.80597019] ; [106.75257111,10.80548954] ; [106.75234985,10.80527973] ; [106.75190735,10.80494022] ; [106.75112152,10.80440998] ; [106.75038910,10.80405998] ; [106.74987030,10.80385017] ; [106.74957275,10.80370998] ; [106.74935913,10.80356026] ; [106.74886322,10.80315018] ; [106.74861145,10.80301952] ; [106.74826050,10.80294991] ; [106.74796295,10.80286980]"
    ,"Distance":"2404"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"416"
    ,"Station_Code":"Q2 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"655, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802134
    ,"Long":106.7434
    ,"Polyline":"[106.74796295,10.80286980] ; [106.74703217,10.80266953] ; [106.74620819,10.80251026] ; [106.74530792,10.80233955] ; [106.74463654,10.80222988] ; [106.74340820,10.80202007]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"417"
    ,"Station_Code":"Q2 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Ng ã ba Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801309
    ,"Long":106.738762
    ,"Polyline":"[106.74340820,10.80202007] ; [106.74149323,10.80167007] ; [106.74060822,10.80146980] ; [106.73986816,10.80136013] ; [106.73879242,10.80115986]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"418"
    ,"Station_Code":"Q2 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"Đối diện Cầu Đen, đường  Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800451
    ,"Long":106.73436
    ,"Polyline":"[106.73879242,10.80115986] ; [106.73438263,10.80035019]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"419"
    ,"Station_Code":"QBTH 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"24(597), đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.79882
    ,"Long":106.719641
    ,"Polyline":"[106.73438263,10.80035019] ; [106.73294067,10.80004978] ; [106.73187256,10.79979992] ; [106.72416687,10.79837036] ; [106.72223663,10.79802990] ; [106.72196960,10.79800987] ; [106.72158051,10.79800034] ; [106.72128296,10.79804993] ; [106.72090149,10.79813957] ; [106.72048950,10.79827976] ; [106.72003937,10.79848003] ; [106.71987915,10.79856968] ; [106.71972656,10.79868984] ; [106.71945953,10.79881954]"
    ,"Distance":"1676"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"420"
    ,"Station_Code":"QBTH 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"152/72c(559), đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.800153
    ,"Long":106.717442
    ,"Polyline":"[106.71945953,10.79881954] ; [106.71913147,10.79899025] ; [106.71864319,10.79930019] ; [106.71785736,10.79975033] ; [106.71719360,10.80008030]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"483, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71719360,10.80008030] ; [106.71645355,10.80043030] ; [106.71571350,10.80074024] ; [106.71513367,10.80097008] ; [106.71481323,10.80107975]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"422"
    ,"Station_Code":"QBTHT056"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cửa nh ôm Bá Thịnh"
    ,"Station_Address":"459, đường  Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801496505737305
    ,"Long":106.71380615234375
    ,"Polyline":"[106.71481323,10.80107975] ; [106.71379089,10.80140972]"
    ,"Distance":"117"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Cây xăng  dầu"
    ,"Station_Address":"419, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71379089,10.80140972] ; [106.71334839,10.80150986] ; [106.71280670,10.80154037]"
    ,"Distance":"108"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Vòng xoay  Hàng Xanh"
    ,"Station_Address":"221, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71280670,10.80154037] ; [106.71147156,10.80156803] ; [106.71139526,10.80160141] ; [106.71131897,10.80160809] ; [106.71124268,10.80158234] ; [106.71119690,10.80155468] ; [106.71116638,10.80150604] ; [106.71114349,10.80144215] ; [106.71115875,10.80136108] ; [106.71118164,10.80131817] ; [106.71123505,10.80127239] ; [106.71130371,10.80124378] ; [106.71125031,10.80085850] ; [106.71121979,10.80050564] ; [106.71115875,10.79997730] ; [106.71114349,10.79971981]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường TH Hồng Hà"
    ,"Station_Address":"153, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71114349,10.79971981] ; [106.71102905,10.79864025] ; [106.71092987,10.79813004] ; [106.71070862,10.79736042] ; [106.71057892,10.79699993] ; [106.71044922,10.79668045]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"369"
    ,"Station_Code":"QBTH 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Siêu Thị Điện máy tự do"
    ,"Station_Address":"151, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.794978
    ,"Long":106.709368
    ,"Polyline":"[106.71044922,10.79668045] ; [106.70999146,10.79553986] ; [106.70974731,10.79522038] ; [106.70935822,10.79479980]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"373"
    ,"Station_Code":"QBTH 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Nhà Th ờ Thị Nghè"
    ,"Station_Address":"79, đường Xô  Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793534
    ,"Long":106.707979
    ,"Polyline":"[106.70935822,10.79479980] ; [106.70805359,10.79343033]"
    ,"Distance":"209"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"370"
    ,"Station_Code":"Q1 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Thảo Cầm Vi ên"
    ,"Station_Address":"2A, đường Nguyễn Thị  Minh Khai, Quận 1"
    ,"Lat":10.790694
    ,"Long":106.705259
    ,"Polyline":"[106.70805359,10.79343033] ; [106.70539093,10.79061031]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Đài truyền hình"
    ,"Station_Address":"Đối diện 9, đường  Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70539093,10.79061031] ; [106.70334625,10.78841972] ; [106.70207977,10.78709984]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1190"
    ,"Station_Code":"Q1 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Đại học Y D ược"
    ,"Station_Address":"43, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785716
    ,"Long":106.702385
    ,"Polyline":"[106.70207977,10.78709984] ; [106.70159149,10.78658009] ; [106.70243835,10.78577995]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1189"
    ,"Station_Code":"Q1 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"TTTM Sài  Gòn"
    ,"Station_Address":"35, đường Tôn Đức Th ắng, Quận 1"
    ,"Lat":10.783902
    ,"Long":106.704417
    ,"Polyline":"[106.70243835,10.78577995] ; [106.70446777,10.78390980]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1192"
    ,"Station_Code":"Q1 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngô Văn Năm"
    ,"Station_Address":"3C, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.779807
    ,"Long":106.707609
    ,"Polyline":"[106.70446777,10.78390980] ; [106.70507813,10.78335953] ; [106.70616913,10.78238964] ; [106.70635223,10.78205967] ; [106.70781708,10.78071022] ; [106.70790863,10.78063011] ; [106.70790863,10.78057003] ; [106.70787811,10.78044987] ; [106.70781708,10.78024960] ; [106.70762634,10.77964020]"
    ,"Distance":"641"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70762634,10.77964020] ; [106.70726013,10.77820969] ; [106.70687866,10.77655983] ; [106.70671844,10.77598000] ; [106.70674896,10.77591038] ; [106.70671844,10.77563953] ; [106.70671082,10.77530003] ; [106.70667267,10.77488041] ; [106.70658112,10.77460003] ; [106.70646667,10.77322006]"
    ,"Distance":"729"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Cục Hải Quan Thành Phố"
    ,"Station_Address":"2-4, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70646667,10.77322006] ; [106.70635223,10.77178955] ; [106.70632935,10.77157021] ; [106.70632172,10.77140045] ; [106.70620728,10.77097988] ; [106.70613861,10.77089977] ; [106.70597839,10.77083969] ; [106.70564270,10.77085972]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84, đường Hàm Nghi, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70564270,10.77085972] ; [106.70468140,10.77091026] ; [106.70339203,10.77093983] ; [106.70317078,10.77095032]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70317078,10.77095032] ; [106.70172119,10.77103043]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136 , đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70172119,10.77103043] ; [106.69934845,10.77112007]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"118"
    ,"Station_Code":"Q1TC1B"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bến Thành B"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77084
    ,"Long":106.698532
    ,"Polyline":"[106.69934845,10.77112007] ; [106.70108795,10.77105999] ; [106.70117950,10.77085972] ; [106.69899750,10.77095032] ; [106.69856262,10.77077961]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận  1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69856262,10.77077961] ; [106.69744873,10.77035046] ; [106.69615173,10.76978970] ; [106.69580841,10.76966000]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69580841,10.76966000] ; [106.69412994,10.76898003]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69412994,10.76898003] ; [106.69238281,10.76828003] ; [106.69052124,10.76753998] ; [106.68988800,10.76844978] ; [106.68920898,10.76819992] ; [106.68904877,10.76807022]"
    ,"Distance":"650"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204 , đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68904877,10.76807022] ; [106.68920898,10.76819992] ; [106.68988800,10.76844978] ; [106.69026184,10.76860046]"
    ,"Distance":"145"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76860046] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai , Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69329834,10.76982975] ; [106.69458008,10.77031040] ; [106.69673157,10.77118969]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão , Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69673157,10.77118969] ; [106.69793701,10.77165699] ; [106.69805908,10.77159405] ; [106.69804382,10.77152443] ; [106.69803619,10.77146721] ; [106.69804382,10.77139378] ; [106.69805908,10.77133942] ; [106.69808197,10.77130032] ; [106.69810486,10.77126217] ; [106.69815063,10.77122784] ; [106.69820404,10.77119827] ; [106.69808197,10.77099037] ; [106.69743347,10.77033997] ; [106.69615173,10.76979733] ; [106.69643402,10.76923275] ; [106.69745636,10.77033615] ; [106.69747162,10.77034855] ; [106.69775391,10.77034187] ; [106.69840240,10.77060032]"
    ,"Distance":"834"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường H àm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69840240,10.77060032] ; [106.69895935,10.77081966] ; [106.69899750,10.77095032] ; [106.69956970,10.77091980]"
    ,"Distance":"143"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956970,10.77091980] ; [106.70192719,10.77081966]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70192719,10.77081966] ; [106.70416260,10.77068996]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến Bạch  Đằng"
    ,"Station_Address":"Bến thủy nội địa Thủ Thiêm , đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70416260,10.77068996] ; [106.70452881,10.77066612] ; [106.70513153,10.76945210.06.70520020] ; [10.76938820,106.70546722] ; [10.76945972,106.70578003] ; [10.76951408,106.70596313] ; [10.76955032,106.70601654] ; [10.76956463,106.70609283] ; [10.76961613,106.70619965] ; [10.76979733,106.70642090] ; [10.77052402,106.70635986] ; [10.77072144,106.70631409] ; [10.77137661,106.70652008]"
    ,"Distance":"786"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1092"
    ,"Station_Code":"Q1 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bảo tàng Tôn Đức Thắng"
    ,"Station_Address":"Đối diện số 5, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.777367
    ,"Long":106.707115
    ,"Polyline":"[106.70652008,10.77388954] ; [106.70658112,10.77460003] ; [106.70667267,10.77488041] ; [106.70671082,10.77530003] ; [106.70671844,10.77563953] ; [106.70674896,10.77591038] ; [106.70671844,10.77598000] ; [106.70687866,10.77655983] ; [106.70702362,10.77717018]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1093"
    ,"Station_Code":"Q1 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngô Văn Năm"
    ,"Station_Address":"Đối diện số 3C, đường Tôn Đức Thắng, Qu ận 1"
    ,"Lat":10.779949
    ,"Long":106.707818
    ,"Polyline":"[106.70702362,10.77717018] ; [106.70726013,10.77820969] ; [106.70755005,10.77939034] ; [106.70771790,10.77991962]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1094"
    ,"Station_Code":"Q1 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ba Son"
    ,"Station_Address":"2, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.781804
    ,"Long":106.706922
    ,"Polyline":"[106.70771790,10.77991962] ; [106.70787811,10.78044987] ; [106.70790863,10.78067017] ; [106.70783997,10.78085995] ; [106.70681000,10.78180981]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1095"
    ,"Station_Code":"Q1 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"TTTM Sài  Gòn"
    ,"Station_Address":"6, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.784184
    ,"Long":106.7043
    ,"Polyline":"[106.70681000,10.78180981] ; [106.70555878,10.78291035] ; [106.70504761,10.78337955] ; [106.70423889,10.78411961]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1096"
    ,"Station_Code":"Q1 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại học Khoa học xã hội nhân văn"
    ,"Station_Address":"10, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785778
    ,"Long":106.702663
    ,"Polyline":"[106.70423889,10.78411961] ; [106.70259857,10.78563023]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"293"
    ,"Station_Code":"Q1 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Thảo Cầm  Viên"
    ,"Station_Address":"3, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.789598
    ,"Long":106.70459
    ,"Polyline":"[106.70259857,10.78563023] ; [106.70159149,10.78658009] ; [106.70285034,10.78791046] ; [106.70352936,10.78861046] ; [106.70446777,10.78962994]"
    ,"Distance":"616"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"295"
    ,"Station_Code":"Q1 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Cầu Thị Nghè"
    ,"Station_Address":"1A, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.790669
    ,"Long":106.705597
    ,"Polyline":"[106.70451355,10.78966999] ; [106.70525360,10.79045963] ; [106.70556641,10.79080009] ; [106.70564270,10.79069042]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"298"
    ,"Station_Code":"QBTH 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"22 B, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793445
    ,"Long":106.70814
    ,"Polyline":"[106.70564270,10.79069042] ; [106.70556641,10.79080009] ; [106.70565033,10.79088020] ; [106.70761871,10.79298019] ; [106.70806122,10.79343987]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trung tâm Dưỡng Lão"
    ,"Station_Address":"138, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70806122,10.79343987] ; [106.70974731,10.79522038] ; [106.70999146,10.79553986] ; [106.71012878,10.79586029] ; [106.71057892,10.79699993] ; [106.71074677,10.79747963]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"246, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71074677,10.79747963] ; [106.71092987,10.79813004] ; [106.71101379,10.79852962] ; [106.71112061,10.79951000] ; [106.71114349,10.79971027]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"476"
    ,"Station_Code":"QBTH 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"500-502, đường  Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.800864
    ,"Long":106.714287
    ,"Polyline":"[106.71114349,10.79971027] ; [106.71121979,10.80049992] ; [106.71138000,10.80074978] ; [106.71163177,10.80105019] ; [106.71204376,10.80128002] ; [106.71266937,10.80128002] ; [106.71298981,10.80125046] ; [106.71325684,10.80121994] ; [106.71372986,10.80111980] ; [106.71414185,10.80101013]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"473"
    ,"Station_Code":"QBTH 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Khu Du lịch  Văn Thánh"
    ,"Station_Address":"600, đường Đi ện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799547
    ,"Long":106.717409
    ,"Polyline":"[106.71414185,10.80101013] ; [106.71469879,10.80084991] ; [106.71527863,10.80066013] ; [106.71617889,10.80035019] ; [106.71685791,10.80000973] ; [106.71720886,10.79983044]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"475"
    ,"Station_Code":"QBTH 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"658, đường Điện Bi ên Phủ, Quận Bình Thạnh"
    ,"Lat":10.798525
    ,"Long":106.719496
    ,"Polyline":"[106.71720886,10.79983044] ; [106.71833801,10.79920959] ; [106.71943665,10.79856968]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"477"
    ,"Station_Code":"Q2 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"794, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.799978
    ,"Long":106.7342
    ,"Polyline":"[106.71943665,10.79856968] ; [106.72039795,10.79808044] ; [106.72083282,10.79792976] ; [106.72122955,10.79782009] ; [106.72203064,10.79780960] ; [106.72254944,10.79782963] ; [106.72306824,10.79790020] ; [106.72541046,10.79833031] ; [106.72850037,10.79891968] ; [106.73149872,10.79944992] ; [106.73317719,10.79986954] ; [106.73404694,10.80006981] ; [106.73417664,10.80008984]"
    ,"Distance":"1654"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"478"
    ,"Station_Code":"Q2 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Đối diện ng ã 3 Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800838
    ,"Long":106.738899
    ,"Polyline":"[106.73417664,10.80008984] ; [106.73886871,10.80097961]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"480"
    ,"Station_Code":"Q2 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Metro Qu ận 2"
    ,"Station_Address":"170, đường Xa Lộ H à Nội, Quận 2"
    ,"Lat":10.801584
    ,"Long":106.742928
    ,"Polyline":"[106.73886871,10.80097961] ; [106.74289703,10.80173016]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"479"
    ,"Station_Code":"Q2 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Khu dân cư Estella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802592
    ,"Long":106.748089
    ,"Polyline":"[106.74289703,10.80173016] ; [106.74376678,10.80189037] ; [106.74430084,10.80200958] ; [106.74456787,10.80204010.06.74524689] ; [10.80206966,106.74575806] ; [10.80202961,106.74610901] ; [10.80202007,106.74642181] ; [10.80206966,106.74662781] ; [10.80214024,106.74687958] ; [10.80226040,106.74725342] ; [10.80241966,106.74761963] ; [10.80255032,106.74806213]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"482"
    ,"Station_Code":"Q9 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Xi măng hà tiên - trạm thu phí"
    ,"Station_Address":"249B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.819206
    ,"Long":106.758394
    ,"Polyline":"[106.74806213,10.80266953] ; [106.74839020,10.80274010.06.74857330] ; [10.80282021,106.74897003] ; [10.80292034,106.74938202] ; [10.80301952,106.74983215] ; [10.80315971,106.75074005] ; [10.80352020,106.75142670] ; [10.80387974,106.75209045] ; [10.80432034,106.75256348] ; [10.80461979,106.75302124] ; [10.80500984,106.75366974] ; [10.80558968,106.75424194] ; [10.80618000,106.75460052] ; [10.80661964,106.75485229] ; [10.80694962,106.75514221] ; [10.80733013,106.75559235] ; [10.80803967,106.75594330] ; [10.80877018,106.75621796] ; [10.80947018,106.75650787] ; [10.81050968,106.75662994] ; [10.81101990,106.75669098] ; [10.81138992,106.75772858] ; [10.81686020,106.75784302] ; [10.81725025,106.75820160] ; [10.81894970,106.75823975]"
    ,"Distance":"2327"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"481"
    ,"Station_Code":"Q9 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"185A , đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.825972
    ,"Long":106.760775
    ,"Polyline":"[106.75823975,10.81917953] ; [106.75846863,10.82038021] ; [106.75865936,10.82139015] ; [106.75891876,10.82240963] ; [106.75916290,10.82306004] ; [106.75942230,10.82365990] ; [106.75946045,10.82380962] ; [106.75950623,10.82392025] ; [106.75980377,10.82448006] ; [106.76068115,10.82600975]"
    ,"Distance":"813"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"485"
    ,"Station_Code":"Q9 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm xây dựng"
    ,"Station_Address":"354A, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.829955
    ,"Long":106.76312
    ,"Polyline":"[106.76068115,10.82600975] ; [106.76112366,10.82678032] ; [106.76235962,10.82892036] ; [106.76296234,10.82999039]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"483"
    ,"Station_Code":"Q9 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Khu QLGTDT  số 2"
    ,"Station_Address":"Khu QLGTĐT số 2,  đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.833249
    ,"Long":106.764778
    ,"Polyline":"[106.76296234,10.82999039] ; [106.76477814,10.83325005]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1025"
    ,"Station_Code":"Q9 214"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Kho 71, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.836162
    ,"Long":106.76666
    ,"Polyline":"[106.76477814,10.83325005] ; [106.76647186,10.83621979]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1030"
    ,"Station_Code":"Q9 215"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"UBND quận 9"
    ,"Station_Address":"1B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.840466
    ,"Long":106.769074
    ,"Polyline":"[106.76647186,10.83621979] ; [106.76822662,10.83934021] ; [106.76892090,10.84057045]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1026"
    ,"Station_Code":"Q9 216"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Bê tông Hải Âu"
    ,"Station_Address":"Bê tông Hải Âu, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.843834
    ,"Long":106.77079
    ,"Polyline":"[106.76892090,10.84057045] ; [106.77076721,10.84383011]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1028"
    ,"Station_Code":"Q9 217"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 4 Thủ Đức"
    ,"Station_Address":"712, đường Xa  Lộ Hà Nội, Quận 9"
    ,"Lat":10.847142
    ,"Long":106.772974
    ,"Polyline":"[106.77076721,10.84383011] ; [106.77150726,10.84517956] ; [106.77175903,10.84545994] ; [106.77204132,10.84582996] ; [106.77229309,10.84620953] ; [106.77281189,10.84710979]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"494"
    ,"Station_Code":"Q9 218"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Công an Quận 9"
    ,"Station_Address":"Công an Quận 9, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.849966
    ,"Long":106.775066
    ,"Polyline":"[106.77281189,10.84710979] ; [106.77333069,10.84799957] ; [106.77368927,10.84848976] ; [106.77414703,10.84902954] ; [106.77458191,10.84947968] ; [106.77507019,10.84990025]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"498"
    ,"Station_Code":"Q9 219"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ chiều"
    ,"Station_Address":"Kế 830 (Chợ Chiều), đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.853511
    ,"Long":106.780474
    ,"Polyline":"[106.77507019,10.84990025] ; [106.77549744,10.85027981] ; [106.77593994,10.85058975] ; [106.77648926,10.85103989] ; [106.77693939,10.85134983] ; [106.77751923,10.85171032] ; [106.77758026,10.85181999] ; [106.77851105,10.85239029] ; [106.78000641,10.85330963] ; [106.78044128,10.85358047]"
    ,"Distance":"718"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"495"
    ,"Station_Code":"Q9 220"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Khu Công nghệ cao quận 9"
    ,"Station_Address":"Khu công nghệ cao, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.858511
    ,"Long":106.788869
    ,"Polyline":"[106.78044128,10.85358047] ; [106.78164673,10.85431957] ; [106.78484344,10.85618973] ; [106.78681946,10.85729027] ; [106.78800201,10.85803032] ; [106.78878784,10.85851002]"
    ,"Distance":"1065"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"536"
    ,"Station_Code":"Q9 221"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cầu Vượt Trạm 2"
    ,"Station_Address":"Tiệm vàng Kim Lợi, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.863595
    ,"Long":106.797538
    ,"Polyline":"[106.78878784,10.85851002] ; [106.79067230,10.85966969] ; [106.79197693,10.86044979] ; [106.79512024,10.86227989] ; [106.79592896,10.86273956] ; [106.79680634,10.86328030] ; [106.79727936,10.86357021]"
    ,"Distance":"1085"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"537"
    ,"Station_Code":"Q9 223"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"Suối Tiên, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.866498
    ,"Long":106.802377
    ,"Polyline":"[106.79730988,10.86359024] ; [106.80146790,10.86606026] ; [106.80248260,10.86666965]"
    ,"Distance":"661"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo dục Quốc phòng, đường Quốc lộ 1, Quận Thủ  Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80248260,10.86666965] ; [106.80357361,10.86740971] ; [106.80407715,10.86781025] ; [106.80403900,10.86787033] ; [106.80433655,10.86810970] ; [106.80441284,10.86816978]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1097"
    ,"Station_Code":"Q9 227"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Công ty Nam Hàn"
    ,"Station_Address":"C ông ty TNHH Nam Hàn, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.884067
    ,"Long":106.816818
    ,"Polyline":"[106.80441284,10.86816978] ; [106.80467224,10.86839962] ; [106.80548096,10.86917973] ; [106.80622101,10.86999989] ; [106.80673981,10.87065983] ; [106.80744171,10.87158012] ; [106.80798340,10.87234020] ; [106.80850983,10.87308979] ; [106.80860138,10.87300968] ; [106.80989075,10.87479973] ; [106.81198120,10.87765980] ; [106.81282806,10.87882042]"
    ,"Distance":"1518"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1098"
    ,"Station_Code":"Q9 228"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Khu tưởng  niệm các Vua Hùng"
    ,"Station_Address":"Kho 190C - 19/11 Hiệp Thắng, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.887623
    ,"Long":106.81943
    ,"Polyline":"[106.81282806,10.87882042] ; [106.81690979,10.88436985] ; [106.81897736,10.88716984] ; [106.81941223,10.88776970]"
    ,"Distance":"1228"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1100"
    ,"Station_Code":"Q9 229"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm xăng Hiệp Phú"
    ,"Station_Address":"Trạm xăng Hiệp Phú, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.893459
    ,"Long":106.823743
    ,"Polyline":"[106.81941223,10.88776970] ; [106.82103729,10.88998032] ; [106.82296753,10.89260960] ; [106.82341003,10.89315033] ; [106.82372284,10.89356995]"
    ,"Distance":"799"
  },
  {
     "Route_Id":"19"
    ,"Station_Id":"1099"
    ,"Station_Code":"BD004"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngã 3 Tân Vạn"
    ,"Station_Address":"Ngã 3 Tân Vạn, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.896781
    ,"Long":106.827225
    ,"Polyline":"[106.82372284,10.89356995] ; [106.82411194,10.89410973] ; [106.82453918,10.89461994] ; [106.82511139,10.89523029] ; [106.82543182,10.89552975] ; [106.82601166,10.89601040] ; [106.82652283,10.89638042] ; [106.82720947,10.89680958]"
    ,"Distance":"529"
  }]