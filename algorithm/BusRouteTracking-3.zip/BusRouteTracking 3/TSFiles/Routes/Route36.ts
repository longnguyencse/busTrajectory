export const Route36 =[
  {
     "Route_Id":"36"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1926"
    ,"Station_Code":"HHM 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trạm măng"
    ,"Station_Address":"45 /9C, đường Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.840398
    ,"Long":106.612535
    ,"Polyline":"[106.61337280,10.84373760] ; [106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61486816,10.84304047] ; [106.61483765,10.84269047] ; [106.61469269,10.84237957] ; [106.61463928,10.84230042] ; [106.61327362,10.84103966] ; [106.61298370,10.84064960] ; [106.61257172,10.84033489]"
    ,"Distance":"768"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1921"
    ,"Station_Code":"HHM 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Hồng Mộc"
    ,"Station_Address":"41/1A, đường Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.836957
    ,"Long":106.608651
    ,"Polyline":"[106.61257172,10.84033489] ; [106.61258698,10.84031010.06.60903931] ; [10.83714008,106.60871887]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1928"
    ,"Station_Code":"HHM 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã tư Bà Điểm"
    ,"Station_Address":"57/7B, đường  Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.832674
    ,"Long":106.605804
    ,"Polyline":"[106.60871887,10.83689404] ; [106.60842133,10.83652020] ; [106.60807037,10.83613014] ; [106.60778046,10.83572006] ; [106.60697937,10.83444023] ; [106.60580444,10.83267403]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1922"
    ,"Station_Code":"HHM 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Kiềm Nghĩa"
    ,"Station_Address":"59 /2, đường Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.829117
    ,"Long":106.603888
    ,"Polyline":"[106.60580444,10.83267403] ; [106.60469818,10.83061028] ; [106.60431671,10.82991028] ; [106.60379791,10.82912254]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"4750"
    ,"Station_Code":"HHM 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Công ty L ộc Ích"
    ,"Station_Address":"Đối diện Công ty  Lộc Ích, đường Quốc lộ 1A, Huyện Hóc Môn"
    ,"Lat":10.827568
    ,"Long":106.6034
    ,"Polyline":"[106.60388947,10.82911682] ; [106.60340118,10.82756805]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1930"
    ,"Station_Code":"QBT 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Quang Châu"
    ,"Station_Address":"5/30K, đường Quốc lộ 1A , Quận Bình Tân"
    ,"Lat":10.823311
    ,"Long":106.602554
    ,"Polyline":"[106.60340118,10.82756805] ; [106.60255432,10.82331085]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1923"
    ,"Station_Code":"QBT 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Vĩ Phong"
    ,"Station_Address":"136, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.821082
    ,"Long":106.60202
    ,"Polyline":"[106.60255432,10.82331085] ; [106.60202026,10.82108212]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1932"
    ,"Station_Code":"QBT 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Gò Mây"
    ,"Station_Address":"230, đường Quốc lộ 1A, Quận B ình Tân"
    ,"Lat":10.818021
    ,"Long":106.601379
    ,"Polyline":"[106.60202026,10.82108212] ; [106.60141754,10.81801605] ; [106.60140228,10.81801701] ; [106.60140228,10.81801796] ; [106.60140228,10.81801796] ; [106.60139465,10.81801796] ; [106.60139465,10.81801796] ; [106.60139465,10.81801796] ; [106.60139465,10.81801796] ; [106.60139465,10.81801891] ; [106.60138702,10.81801987] ; [106.60137939,10.81802082]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1927"
    ,"Station_Code":"QBT 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Gò Mây"
    ,"Station_Address":"230, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.804263
    ,"Long":106.598412
    ,"Polyline":"[106.60137939,10.81802082] ; [106.59970093,10.80978012] ; [106.59851074,10.80424023] ; [106.59850311,10.80424213] ; [106.59850311,10.80424213] ; [106.59850311,10.80424309] ; [106.59849548,10.80424309] ; [106.59849548,10.80424309] ; [106.59849548,10.80424309] ; [106.59849548,10.80424213] ; [106.59849548,10.80424309] ; [106.59848785,10.80424595] ; [106.59846497,10.80422783] ; [106.59843445,10.80420971] ; [106.59843445,10.80421162] ; [106.59844208,10.80421257] ; [106.59844208,10.80421352] ; [106.59844208,10.80421638] ; [106.59844208,10.80422306] ; [106.59844971,10.80423641] ; [106.59846497,10.80425167] ; [106.59841156,10.80426311]"
    ,"Distance":"1588"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1934"
    ,"Station_Code":"QBT 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Hương Quê"
    ,"Station_Address":"320, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.799784
    ,"Long":106.597427
    ,"Polyline":"[106.59841156,10.80426311] ; [106.59742737,10.79978371]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1929"
    ,"Station_Code":"QBT 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Phát Đạt"
    ,"Station_Address":"576, đường Qu ốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.791742
    ,"Long":106.595779
    ,"Polyline":"[106.59742737,10.79978371] ; [106.59743500,10.79914665] ; [106.59703064,10.79714966] ; [106.59692383,10.79659557] ; [106.59669495,10.79593754] ; [106.59651947,10.79506779] ; [106.59631348,10.79421902] ; [106.59623718,10.79359722] ; [106.59600830,10.79244900] ; [106.59577942,10.79174232]"
    ,"Distance":"916"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1937"
    ,"Station_Code":"QBT 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Khu phố 5"
    ,"Station_Address":"576 , đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.787811
    ,"Long":106.594925
    ,"Polyline":"[106.59577942,10.79174232] ; [106.59538269,10.78947639] ; [106.59510803,10.78816986] ; [106.59492493,10.78781128]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1931"
    ,"Station_Code":"QBT 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Tân Kỳ T ân Quý"
    ,"Station_Address":"642, đường Quốc l ộ 1A, Quận Bình Tân"
    ,"Lat":10.784723
    ,"Long":106.594276
    ,"Polyline":"[106.59492493,10.78781128] ; [106.59427643,10.78472328]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1939"
    ,"Station_Code":"QBT 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Thiên Phúc Học"
    ,"Station_Address":"770, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.781952
    ,"Long":106.593697
    ,"Polyline":"[106.59427643,10.78472328] ; [106.59369659,10.78195190]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1941"
    ,"Station_Code":"QBT 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ao Đôi"
    ,"Station_Address":"790 (Đối diện Ao Đôi), đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.779601
    ,"Long":106.593262
    ,"Polyline":"[106.59369659,10.78195190] ; [106.59326172,10.77960110]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1933"
    ,"Station_Code":"QBT 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"854, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.775476
    ,"Long":106.592377
    ,"Polyline":"[106.59326172,10.77960110.06.59237671]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1935"
    ,"Station_Code":"QBT 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Qua ngã tư Hương lộ 2"
    ,"Station_Address":"892 , đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.77234
    ,"Long":106.591667
    ,"Polyline":"[106.59237671,10.77547550] ; [106.59166718,10.77233982]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1789"
    ,"Station_Code":"QBT 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nghĩa trang  Bình TÂn"
    ,"Station_Address":"950, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.768545
    ,"Long":106.590935
    ,"Polyline":"[106.59166718,10.77233982] ; [106.59152985,10.77160740] ; [106.59126282,10.77024174] ; [106.59093475,10.76854515]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1788"
    ,"Station_Code":"QBT 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Bà Hom"
    ,"Station_Address":"978A, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.762401
    ,"Long":106.590683
    ,"Polyline":"[106.59093475,10.76854515] ; [106.59059906,10.76671982] ; [106.59052277,10.76624012] ; [106.59043884,10.76539993] ; [106.59044647,10.76469994] ; [106.59050751,10.76410007] ; [106.59056854,10.76379013] ; [106.59068298,10.76240063]"
    ,"Distance":"690"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1791"
    ,"Station_Code":"QBT 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà sách Tân Tạo"
    ,"Station_Address":"1024, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.758026
    ,"Long":106.591492
    ,"Polyline":"[106.59068298,10.76240063] ; [106.59136963,10.75918007] ; [106.59134674,10.75897026] ; [106.59145355,10.75819016] ; [106.59147644,10.75802040] ; [106.59149170,10.75802612]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1790"
    ,"Station_Code":"QBT 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Khu Công nghiệp Tân Tạo"
    ,"Station_Address":"666, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.752793
    ,"Long":106.592392
    ,"Polyline":"[106.59149170,10.75802612] ; [106.59147644,10.75802040] ; [106.59175873,10.75644970] ; [106.59213257,10.75438023] ; [106.59218597,10.75390530] ; [106.59217072,10.75279999] ; [106.59212494,10.75279331]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1792"
    ,"Station_Code":"QBT 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Công ty Pouyuen"
    ,"Station_Address":"Đối diện Pouyen,  đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.746899
    ,"Long":106.595367
    ,"Polyline":"[106.59212494,10.75279331] ; [106.59212494,10.75279331] ; [106.59217072,10.75279999] ; [106.59246826,10.75253487] ; [106.59294891,10.75080585] ; [106.59329224,10.75028992] ; [106.59352112,10.74989033] ; [106.59375763,10.74950027] ; [106.59417725,10.74882030] ; [106.59510803,10.74729633] ; [106.59536743,10.74689865] ; [106.59536743,10.74689865]"
    ,"Distance":"758"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1793"
    ,"Station_Code":"QBT 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Công ty Hai  Thành"
    ,"Station_Address":"A5/13Q, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.743526
    ,"Long":106.597519
    ,"Polyline":"[106.59536743,10.74689865] ; [106.59661102,10.74499989] ; [106.59751892,10.74352551]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1794"
    ,"Station_Code":"QBT 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Điện  Quốc lộ 1A"
    ,"Station_Address":"A5/3Q, đường  Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.740001
    ,"Long":106.599724
    ,"Polyline":"[106.59751892,10.74352551] ; [106.59972382,10.74000072]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1795"
    ,"Station_Code":"QBT 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Công an Quận Bình Tân"
    ,"Station_Address":"1054 (Quán ăn Xa lộ), đường Quốc lộ 1A , Quận Bình Tân"
    ,"Lat":10.736204
    ,"Long":106.602081
    ,"Polyline":"[106.59972382,10.74000072] ; [106.60070801,10.73845959] ; [106.60172272,10.73686028] ; [106.60208893,10.73622036] ; [106.60208130,10.73621273] ; [106.60208130,10.73620415]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1797"
    ,"Station_Code":"QBT 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Siêu thị Big C"
    ,"Station_Address":"Siêu thị Big C,  đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.731232
    ,"Long":106.60508
    ,"Polyline":"[106.60208130,10.73620415] ; [106.60208893,10.73622036] ; [106.60225677,10.73591042] ; [106.60249329,10.73536015] ; [106.60265350,10.73474026] ; [106.60269928,10.73461056] ; [106.60292816,10.73449039] ; [106.60321045,10.73437023] ; [106.60356903,10.73412037] ; [106.60431671,10.73291969] ; [106.60507965,10.73123169]"
    ,"Distance":"667"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1796"
    ,"Station_Code":"QBT 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã tư An L ạc"
    ,"Station_Address":"551, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.728676
    ,"Long":106.606819
    ,"Polyline":"[106.60507965,10.73123169] ; [106.60530090,10.73115826] ; [106.60678864,10.72884941] ; [106.60681915,10.72867584]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"709"
    ,"Station_Code":"QBT 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"703, đường Kinh Dương Vương, Quận Bình  Tân"
    ,"Lat":10.72832
    ,"Long":106.607605
    ,"Polyline":"[106.60681915,10.72867584] ; [106.60694885,10.72863865] ; [106.60732269,10.72815037] ; [106.60761261,10.72832966] ; [106.60760498,10.72832012]"
    ,"Distance":"122"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"714"
    ,"Station_Code":"QBT 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ủy ban"
    ,"Station_Address":"631-637, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729977
    ,"Long":106.610255
    ,"Polyline":"[106.60760498,10.72832012] ; [106.61019135,10.73007774]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"710"
    ,"Station_Code":"QBT 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Lâm Thành"
    ,"Station_Address":"289(561), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.734278
    ,"Long":106.61298
    ,"Polyline":"[106.61019135,10.73007774] ; [106.61285400,10.73427963]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"716"
    ,"Station_Code":"QBT 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"251(511), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.737541
    ,"Long":106.614906
    ,"Polyline":"[106.61285400,10.73427963] ; [106.61484528,10.73754978]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"713"
    ,"Station_Code":"QBT 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"Bệnh viện Triều An, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.739665
    ,"Long":106.61687
    ,"Polyline":"[106.61484528,10.73754978] ; [106.61484528,10.73754978] ; [106.61555481,10.73862076] ; [106.61680603,10.73975658] ; [106.61680603,10.73975658]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Qu ận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61679840,10.73976040] ; [106.61814880,10.74088955]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"630"
    ,"Station_Code":"QBT 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"480, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739675
    ,"Long":106.616392
    ,"Polyline":"[106.61831665,10.74070454] ; [106.61933899,10.74155140] ; [106.61916351,10.74172974] ; [106.61904907,10.74186039] ; [106.61823273,10.74118996] ; [106.61666107,10.73987961] ; [106.61643219,10.73968029] ; [106.61639404,10.73967457]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"631"
    ,"Station_Code":"QBT 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"548 , đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.735138
    ,"Long":106.613144
    ,"Polyline":"[106.61640930,10.73966026] ; [106.61547852,10.73880959] ; [106.61511993,10.73832989] ; [106.61479187,10.73777962] ; [106.61315155,10.73511982]"
    ,"Distance":"629"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"632"
    ,"Station_Code":"QBT 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"SinCo"
    ,"Station_Address":"Đối diện nhà trọ Thanh Trường, đường  Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.731674
    ,"Long":106.611028
    ,"Polyline":"[106.61314392,10.73513794] ; [106.61107635,10.73165607]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"633"
    ,"Station_Code":"QBT 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Hoa hồng"
    ,"Station_Address":"620, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.729014
    ,"Long":106.608276
    ,"Polyline":"[106.61107635,10.73165607] ; [106.61107635,10.73165035] ; [106.61047363,10.73066807] ; [106.61006927,10.73023987] ; [106.60946655,10.72978973] ; [106.60827637,10.72900963] ; [106.60827637,10.72901440]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1852"
    ,"Station_Code":"QBT 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã tư An Lạc"
    ,"Station_Address":"488, đường Hồ Học  Lãm, Quận Bình Tân"
    ,"Lat":10.729012
    ,"Long":106.606857
    ,"Polyline":"[106.60822296,10.72896957] ; [106.60722351,10.72830963] ; [106.60679626,10.72896957]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1853"
    ,"Station_Code":"QBT 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Siêu thị Big C"
    ,"Station_Address":"588, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.731232
    ,"Long":106.605507
    ,"Polyline":"[106.60685730,10.72901154] ; [106.60685730,10.72901249] ; [106.60610199,10.73000908] ; [106.60550690,10.73123169] ; [106.60550690,10.73123169]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1855"
    ,"Station_Code":"QBT 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hẻm Sinco Hồ Ngọc Lãm"
    ,"Station_Address":"E4/39, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.734642
    ,"Long":106.603302
    ,"Polyline":"[106.60550690,10.73123169] ; [106.60330200,10.73464203]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1856"
    ,"Station_Code":"QBT 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm Điện Quốc lộ 1A"
    ,"Station_Address":"1229C , đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.737657
    ,"Long":106.601364
    ,"Polyline":"[106.60330200,10.73464203] ; [106.60136414,10.73765659]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1854"
    ,"Station_Code":"QBT 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công ty Hai  Thành"
    ,"Station_Address":"E4/48, đường Quốc  lộ 1A, Quận Bình Tân"
    ,"Lat":10.742307
    ,"Long":106.598442
    ,"Polyline":"[106.60136414,10.73765659] ; [106.59844208,10.74230671]"
    ,"Distance":"608"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1857"
    ,"Station_Code":"QBT 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Công ty Pouyuen"
    ,"Station_Address":"Công ty Pouyuen, đường Quốc lộ 1A, Quận B ình Tân"
    ,"Lat":10.747634
    ,"Long":106.595078
    ,"Polyline":"[106.59844208,10.74230671] ; [106.59507751,10.74763393]"
    ,"Distance":"698"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1858"
    ,"Station_Code":"QBT 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"KCN Tân Tạo"
    ,"Station_Address":"56,  đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.752967
    ,"Long":106.592692
    ,"Polyline":"[106.59507751,10.74763393] ; [106.59507751,10.74763393] ; [106.59500885,10.74771023] ; [106.59461975,10.74842358] ; [106.59377289,10.74978352] ; [106.59329224,10.75055313] ; [106.59297180,10.75148106.06.59229279]"
    ,"Distance":"664"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1859"
    ,"Station_Code":"QBT 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nhà sách  Tân Tạo"
    ,"Station_Address":"1167-1169, đường  Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.755164
    ,"Long":106.592369
    ,"Polyline":"[106.59275818,10.75291920] ; [106.59236908,10.75516415]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1861"
    ,"Station_Code":"QBT 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm xăng số 5"
    ,"Station_Address":"1137 (D11/89A), đường Quốc lộ 1A, Quận Bình  Tân"
    ,"Lat":10.757884
    ,"Long":106.591858
    ,"Polyline":"[106.59236908,10.75516415] ; [106.59185791,10.75788403]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1863"
    ,"Station_Code":"QBT 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chung cư Tân Mai"
    ,"Station_Address":"Đối diện 952, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.763075
    ,"Long":106.590927
    ,"Polyline":"[106.59185791,10.75788403] ; [106.59092712,10.76307487]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1865"
    ,"Station_Code":"QBT 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"1087, đường Quốc lộ 1A, Qu ận Bình Tân"
    ,"Lat":10.768476
    ,"Long":106.591148
    ,"Polyline":"[106.59092712,10.76307487] ; [106.59063721,10.76408958] ; [106.59056854,10.76484013] ; [106.59056854,10.76541042] ; [106.59062958,10.76622963] ; [106.59071350,10.76669025] ; [106.59089661,10.76753044] ; [106.59114838,10.76847649]"
    ,"Distance":"613"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1893"
    ,"Station_Code":"QBT 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"1069, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.772055
    ,"Long":106.591965
    ,"Polyline":"[106.59114838,10.76847649] ; [106.59196472,10.77205467]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1886"
    ,"Station_Code":"QBT 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ao Đôi"
    ,"Station_Address":"1015 (Ao Đôi), đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.77548
    ,"Long":106.592667
    ,"Polyline":"[106.59196472,10.77205467] ; [106.59195709,10.77243996] ; [106.59200287,10.77277184] ; [106.59234619,10.77420998] ; [106.59256744,10.77521133] ; [106.59266663,10.77548027]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1887"
    ,"Station_Code":"QBT 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Khu phố 1"
    ,"Station_Address":"853, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.77957
    ,"Long":106.593506
    ,"Polyline":"[106.59266663,10.77548027] ; [106.59350586,10.77956963]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1895"
    ,"Station_Code":"QBT 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Sơn Expo"
    ,"Station_Address":"Sơn Expo, đư ờng Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.781994
    ,"Long":106.59404
    ,"Polyline":"[106.59350586,10.77956963] ; [106.59403992,10.78199387]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1888"
    ,"Station_Code":"QBT 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"813, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.784544
    ,"Long":106.594604
    ,"Polyline":"[106.59403992,10.78199387] ; [106.59460449,10.78454399]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1898"
    ,"Station_Code":"QBT 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"741, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.787306
    ,"Long":106.595161
    ,"Polyline":"[106.59460449,10.78454399] ; [106.59516144,10.78730583]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1892"
    ,"Station_Code":"QBT 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Phát Đạt"
    ,"Station_Address":"601, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.791437
    ,"Long":106.596062
    ,"Polyline":"[106.59516144,10.78730583] ; [106.59606171,10.79143715]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1900"
    ,"Station_Code":"QBT 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Trạm cân số 1"
    ,"Station_Address":"497, đư ờng Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.799468
    ,"Long":106.597801
    ,"Polyline":"[106.59606171,10.79143715] ; [106.59780121,10.79946804]"
    ,"Distance":"914"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1894"
    ,"Station_Code":"QBT 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Khu phố 3"
    ,"Station_Address":"461, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.803514
    ,"Long":106.598724
    ,"Polyline":"[106.59780121,10.79946804] ; [106.59872437,10.80351448]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1902"
    ,"Station_Code":"QBT 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cửa hàng Thảo Vân"
    ,"Station_Address":"383, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.80813
    ,"Long":106.599731
    ,"Polyline":"[106.59872437,10.80351448] ; [106.59973145,10.80813026]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1896"
    ,"Station_Code":"QBT 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Gò Mây"
    ,"Station_Address":"253, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.813484
    ,"Long":106.600754
    ,"Polyline":"[106.59973145,10.80813026] ; [106.60075378,10.81348419]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1904"
    ,"Station_Code":"QBT 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Hội quán"
    ,"Station_Address":"197 (Hội quán ), đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.817604
    ,"Long":106.601593
    ,"Polyline":"[106.60075378,10.81348419] ; [106.60159302,10.81760406]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1897"
    ,"Station_Code":"QBT 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Nồi Hơi"
    ,"Station_Address":"117, đường Quốc lộ 1A, Qu ận Bình Tân"
    ,"Lat":10.820871
    ,"Long":106.602333
    ,"Polyline":"[106.60159302,10.81760406] ; [106.60233307,10.82087135]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1906"
    ,"Station_Code":"QBT 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Quang Châu"
    ,"Station_Address":"19-21, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.823305
    ,"Long":106.602783
    ,"Polyline":"[106.60233307,10.82087135] ; [106.60278320,10.82330513]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1899"
    ,"Station_Code":"Q12 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Lộc Ích"
    ,"Station_Address":"168, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.827779
    ,"Long":106.603855
    ,"Polyline":"[106.60278320,10.82330513] ; [106.60379791,10.82789230]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1908"
    ,"Station_Code":"Q12 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã tư Bà Điểm"
    ,"Station_Address":"2945, đường Qu ốc lộ 1A, Quận 12"
    ,"Lat":10.833269
    ,"Long":106.606559
    ,"Polyline":"[106.60379791,10.82789230] ; [106.60404205,10.82874298] ; [106.60424805,10.82921696] ; [106.60445404,10.82973385] ; [106.60483551,10.83040333] ; [106.60634613,10.83298206]"
    ,"Distance":"634"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1901"
    ,"Station_Code":"Q12 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Qua ngã tư Bà Điểm"
    ,"Station_Address":"2879, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.834887
    ,"Long":106.607616
    ,"Polyline":"[106.60634613,10.83298206] ; [106.60759735,10.83501339]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1910"
    ,"Station_Code":"Q12 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm Rác"
    ,"Station_Address":"88/1, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.837358
    ,"Long":106.609543
    ,"Polyline":"[106.60759735,10.83501339] ; [106.60756683,10.83511829] ; [106.60796356,10.83583546] ; [106.60880280,10.83673954] ; [106.60949707,10.83740044] ; [106.60954285,10.83735752]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1903"
    ,"Station_Code":"Q12 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm măng"
    ,"Station_Address":"2797, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.839368
    ,"Long":107.611801
    ,"Polyline":"[106.60954285,10.83735752] ; [106.61180115,10.83936787]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1905"
    ,"Station_Code":"Q12 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Cầu vượt ngã tư An Sương"
    ,"Station_Address":"10P, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.841183
    ,"Long":106.61408
    ,"Polyline":"[106.61180115,10.83936787] ; [106.61337280,10.84080315] ; [106.61385345,10.84105587] ; [106.61399078,10.84119320]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Bến xe An  Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61399078,10.84119320] ; [106.61565399,10.84259987] ; [106.61401367,10.84493923]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"36"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61401367,10.84493923] ; [106.61396027,10.84490967] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61237335,10.84720993] ; [106.61244202,10.84710026] ; [106.61327362,10.84582043] ; [106.61369324,10.84515953] ; [106.61405182,10.84459972] ; [106.61413574,10.84444904] ; [106.61367035,10.84412766] ; [106.61328125,10.84385395] ; [106.61337280,10.84373760]"
    ,"Distance":"820"
  }]