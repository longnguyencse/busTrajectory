export const Route104 =[

  {
     "Route_Id":"104"
    ,"Station_Id":"1999"
    ,"Station_Code":"BX 15"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu chế xuất Tân Thuận"
    ,"Station_Address":"ĐẦU BẾN KCX TÂN THUẬN, đư ờng Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752883
    ,"Long":106.727501
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"843"
    ,"Station_Code":"Q7 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 49/2, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752498
    ,"Long":106.727414
    ,"Polyline":"[106.72750854,10.75273991] ; [106.72721863,10.75273228] ; [106.72689056,10.75271130] ; [106.72683716,10.75270367] ; [106.72635651,10.75262737] ; [106.72583771,10.75249004] ; [106.72537994,10.75231647] ; [106.72477722,10.75200272] ; [106.72483826,10.75189686] ; [106.72549438,10.75222397] ; [106.72608948,10.75241852] ; [106.72663116,10.75253487] ; [106.72730255,10.75261021]"
    ,"Distance":"610"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2122"
    ,"Station_Code":"Q7 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Khu chế xuất Tân Thuận"
    ,"Station_Address":"298, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.75166
    ,"Long":106.728428
    ,"Polyline":"[106.72730255,10.75261021] ; [106.72795105,10.75263977] ; [106.72817230,10.75255013] ; [106.72827911,10.75249004] ; [106.72839355,10.75240040] ; [106.72850800,10.75228024] ; [106.72855377,10.75185966]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2123"
    ,"Station_Code":"Q7 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Bùi Văn Ba"
    ,"Station_Address":"338, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.749151
    ,"Long":106.728643
    ,"Polyline":"[106.72855377,10.75185966] ; [106.72876740,10.74915028]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2125"
    ,"Station_Code":"Q7 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà sách  Tân Thuận"
    ,"Station_Address":"448A, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.745061
    ,"Long":106.729163
    ,"Polyline":"[106.72876740,10.74915028] ; [106.72884369,10.74833965] ; [106.72891998,10.74755001] ; [106.72923279,10.74543953]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2124"
    ,"Station_Code":"Q7 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Huỳnh Tấn Phát"
    ,"Station_Address":"488, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.742901
    ,"Long":106.729485
    ,"Polyline":"[106.72923279,10.74543953] ; [106.72960663,10.74291992]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2126"
    ,"Station_Code":"Q7 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Nghĩa trang liệt sỹ Nhà Bè"
    ,"Station_Address":"Nghĩa trang liệt sỹ Nhà Bè, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.740381
    ,"Long":106.729876
    ,"Polyline":"[106.72960663,10.74291992] ; [106.73001099,10.74030018]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3528"
    ,"Station_Code":"Q7 173"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Sân bóng đá mini Phú MỸ"
    ,"Station_Address":"38, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.737728
    ,"Long":106.728386
    ,"Polyline":"[106.73001099,10.74030018] ; [106.73040771,10.73754025] ; [106.73014832,10.73754978] ; [106.72837830,10.73766041]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3530"
    ,"Station_Code":"Q7 172"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Bệnh viện Quận 7"
    ,"Station_Address":"Đ/d Bệnh viện Quận 7, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738041
    ,"Long":106.723455
    ,"Polyline":"[106.72837830,10.73766041] ; [106.72750854,10.73771954] ; [106.72609711,10.73779011] ; [106.72364044,10.73791027] ; [106.72322845,10.73795033] ; [106.72313690,10.73797989]"
    ,"Distance":"574"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"867"
    ,"Station_Code":"Q7 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Tân Bình"
    ,"Station_Address":"452 , đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.73704
    ,"Long":106.721342
    ,"Polyline":"[106.72313690,10.73797989] ; [106.72322845,10.73795033] ; [106.72210693,10.73799992] ; [106.72152710,10.73803997] ; [106.72154236,10.73696995]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"864"
    ,"Station_Code":"Q7 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nguyễn Lư ơng Bằng"
    ,"Station_Address":"Đối diện Manulife , đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.732486
    ,"Long":106.720194
    ,"Polyline":"[106.72154236,10.73696995] ; [106.72144318,10.73575020] ; [106.72132874,10.73493004] ; [106.72122192,10.73447037] ; [106.72091675,10.73342991] ; [106.72067261,10.73291016]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1355"
    ,"Station_Code":"Q7 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Tân Trào"
    ,"Station_Address":"Văn phòng Đội Bảo vệ, đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.728222
    ,"Long":106.721873
    ,"Polyline":"[106.72067261,10.73291016] ; [106.72036743,10.73237991] ; [106.72000885,10.73186970] ; [106.71988678,10.73174953] ; [106.72022247,10.73114967] ; [106.72028351,10.73106003] ; [106.72109985,10.72968006] ; [106.72149658,10.72906017]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1243"
    ,"Station_Code":"Q7 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trần Văn Trà"
    ,"Station_Address":"Đ/d trường CĐ Công nghệ và QTDN, đường Trần Văn Trà, Quận 7"
    ,"Lat":10.724101
    ,"Long":106.720993
    ,"Polyline":"[106.72187042,10.72822189] ; [106.72149658,10.72906017] ; [106.72248077,10.72761631] ; [106.72370148,10.72565556] ; [106.72235870,10.72485447] ; [106.72099304,10.72410107]"
    ,"Distance":"894"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1242"
    ,"Station_Code":"Q7 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Mỹ Giang 2"
    ,"Station_Address":"KDC  Mỹ Giang 2, đường Nguyễn Đức Cảnh, Quận 7"
    ,"Lat":10.721586
    ,"Long":106.716857
    ,"Polyline":"[106.72099304,10.72410107] ; [106.72052002,10.72371960] ; [106.71852875,10.72253036] ; [106.71768951,10.72200012] ; [106.71685791,10.72158623]"
    ,"Distance":"533"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1203"
    ,"Station_Code":"Q7 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường  Nam Sài Gòn"
    ,"Station_Address":"Đ/d Trường Nam Sài Gòn, đường Nguyễn Đức Cảnh, Quận 7"
    ,"Lat":10.722751
    ,"Long":106.709948
    ,"Polyline":"[106.71768951,10.72200012] ; [106.71646118,10.72124958] ; [106.71585846,10.72091961] ; [106.71553802,10.72080994] ; [106.71537018,10.72076035] ; [106.71492767,10.72074032] ; [106.71443176,10.72084045] ; [106.71201324,10.72150040] ; [106.71174622,10.72152996] ; [106.71150208,10.72155952] ; [106.71125793,10.72161961] ; [106.71102142,10.72173023] ; [106.71092224,10.72179031] ; [106.70979309,10.72284985] ; [106.70935822,10.72323036]"
    ,"Distance":"1027"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"872"
    ,"Station_Code":"Q7 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Sky Garden"
    ,"Station_Address":"1048 (Kế siêu thị Fivimart), đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.729234
    ,"Long":106.7049
    ,"Polyline":"[106.70935822,10.72323036] ; [106.70893097,10.72364044] ; [106.70886993,10.72375011] ; [106.70880127,10.72391033] ; [106.70874786,10.72408009] ; [106.70873260,10.72449017] ; [106.70861053,10.72846031] ; [106.70860291,10.72910976] ; [106.70677185,10.72906017] ; [106.70377350,10.72900963]"
    ,"Distance":"1207"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1244"
    ,"Station_Code":"Q7 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"291/8, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.729324
    ,"Long":106.700522
    ,"Polyline":"[106.70377350,10.72900963] ; [106.70265198,10.72896957] ; [106.70046234,10.72889996] ; [106.70033264,10.72982979]"
    ,"Distance":"466"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1246"
    ,"Station_Code":"Q7 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"ĐH Tôn Đức Thắng"
    ,"Station_Address":"568, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.731859
    ,"Long":106.700152
    ,"Polyline":"[106.70033264,10.72982979] ; [106.70027924,10.73023987] ; [106.70027924,10.73056984] ; [106.70021057,10.73101997] ; [106.70018005,10.73122025]"
    ,"Distance":"155"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1245"
    ,"Station_Code":"Q7 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Đại học  Cảnh sát"
    ,"Station_Address":"Đối diện 36, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.734273
    ,"Long":106.700029
    ,"Polyline":"[106.70018005,10.73122025] ; [106.69995117,10.73309994] ; [106.69992828,10.73386955] ; [106.69994354,10.73416042] ; [106.69996643,10.73433971]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1247"
    ,"Station_Code":"Q7 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Siêu thị Lotte"
    ,"Station_Address":"Si êu thị Lotte, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74085
    ,"Long":106.701134
    ,"Polyline":"[106.69996643,10.73433971] ; [106.70007324,10.73509979] ; [106.70040894,10.73709965] ; [106.70108032,10.74098969]"
    ,"Distance":"750"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1249"
    ,"Station_Code":"Q7 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường 15"
    ,"Station_Address":"458B, đường Nguyễn Hữu Th ọ, Quận 7"
    ,"Lat":10.743865
    ,"Long":106.701665
    ,"Polyline":"[106.70108032,10.74098969] ; [106.70157623,10.74388981]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1453"
    ,"Station_Code":"Q7 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"221, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.745957
    ,"Long":106.704519
    ,"Polyline":"[106.70157623,10.74388981] ; [106.70169067,10.74450970] ; [106.70182800,10.74479961] ; [106.70192719,10.74495983] ; [106.70204926,10.74505997] ; [106.70220947,10.74514008] ; [106.70250702,10.74522972] ; [106.70433044,10.74499035] ; [106.70445251,10.74569988]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1445"
    ,"Station_Code":"Q7 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Phan Huy Thục"
    ,"Station_Address":"179, đường L ê Văn Lương, Quận 7"
    ,"Lat":10.748861
    ,"Long":106.704943
    ,"Polyline":"[106.70445251,10.74569988] ; [106.70458221,10.74656010.06.70467377] ; [10.74744987,106.70482635] ; [10.74837971,106.70488739]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1454"
    ,"Station_Code":"Q7 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"23-25, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.751468
    ,"Long":106.705124
    ,"Polyline":"[106.70488739,10.74884987] ; [106.70494843,10.74930000] ; [106.70504761,10.74981976] ; [106.70517731,10.75047016] ; [106.70522308,10.75082016] ; [106.70507813,10.75146008]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1455"
    ,"Station_Code":"Q7 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"Đối diện 263, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751839
    ,"Long":106.704508
    ,"Polyline":"[106.70507813,10.75146008] ; [106.70503235,10.75181007] ; [106.70436859,10.75179958]"
    ,"Distance":"111"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1446"
    ,"Station_Code":"Q7 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Ủy ban Phường Tân Hưng"
    ,"Station_Address":"Đối diện 733, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751786
    ,"Long":106.701347
    ,"Polyline":"[106.70436859,10.75179958] ; [106.70134735,10.75177002]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1456"
    ,"Station_Code":"Q7 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"chùa Kiều Đàm"
    ,"Station_Address":"Đối diện 829, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751776
    ,"Long":106.697998
    ,"Polyline":"[106.70134735,10.75177002] ; [106.69799042,10.75174046]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1450"
    ,"Station_Code":"Q7 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Bệnh viện Tân Hưng"
    ,"Station_Address":"Đối diện 933, đường Trần Xuân Soạn, Qu ận 7"
    ,"Lat":10.751731
    ,"Long":106.694519
    ,"Polyline":"[106.69799042,10.75174046] ; [106.69609070,10.75174046] ; [106.69451904,10.75170040]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1461"
    ,"Station_Code":"Q7 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Rạch Ông"
    ,"Station_Address":"Đối diện 999, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751496
    ,"Long":106.692969
    ,"Polyline":"[106.69451904,10.75170040] ; [106.69403839,10.75164986] ; [106.69360352,10.75156975] ; [106.69184875,10.75125027]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1452"
    ,"Station_Code":"Q8 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu Nguy ễn Văn Cừ"
    ,"Station_Address":"122, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.750859
    ,"Long":106.68724
    ,"Polyline":"[106.69297028,10.75149632] ; [106.69184875,10.75125027] ; [106.68919373,10.75076962] ; [106.68846130,10.75063038] ; [106.68824768,10.75063038] ; [106.68778992,10.75078011] ; [106.68771362,10.75080967] ; [106.68750763,10.75080013] ; [106.68724060,10.75085926]"
    ,"Distance":"640"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3009"
    ,"Station_Code":"Q5 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Chung cư 109 Nguyễn Biểu"
    ,"Station_Address":"64, đường Nguyễn Biểu, Quận 5"
    ,"Lat":10.755424
    ,"Long":106.683945
    ,"Polyline":"[106.68724060,10.75085926] ; [106.68713379,10.75070953] ; [106.68550873,10.75018406] ; [106.68487549,10.74993134] ; [106.68429565,10.74965763] ; [106.68361664,10.74927235] ; [106.68321228,10.74907207] ; [106.68352509,10.74855042] ; [106.68366241,10.74833393] ; [106.68382263,10.74826622] ; [106.68425751,10.74837685] ; [106.68485260,10.74867153] ; [106.68424225,10.74978352] ; [106.68370819,10.75091171] ; [106.68400574,10.75248241] ; [106.68424225,10.75331497] ; [106.68434906,10.75413704] ; [106.68389130,10.75539970] ; [106.68394470,10.75542355]"
    ,"Distance":"1526"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3012"
    ,"Station_Code":"Q5 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường THCS Ba Đình"
    ,"Station_Address":"230, đường Nguyễn Biểu, Quận 5"
    ,"Lat":10.75819
    ,"Long":106.682927
    ,"Polyline":"[106.68394470,10.75542355] ; [106.68366241,10.75599957] ; [106.68316650,10.75737953] ; [106.68292236,10.75806046] ; [106.68292999,10.75819016]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3529"
    ,"Station_Code":"Q5 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường  TH Bầu Sen"
    ,"Station_Address":"130, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.757842
    ,"Long":106.67951
    ,"Polyline":"[106.68292236,10.75806046] ; [106.68260956,10.75891972] ; [106.68079376,10.75827026] ; [106.67977142,10.75786018] ; [106.67955780,10.75778008]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3532"
    ,"Station_Code":"Q5 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bệnh viện Nguyễn Trãi"
    ,"Station_Address":"322, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.756071
    ,"Long":106.675299
    ,"Polyline":"[106.67951202,10.75784206] ; [106.67887878,10.75751972] ; [106.67823029,10.75722027] ; [106.67651367,10.75648785] ; [106.67530060,10.75607109]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3531"
    ,"Station_Code":"Q5 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trần Ph ú"
    ,"Station_Address":"420, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.755402
    ,"Long":106.673266
    ,"Polyline":"[106.67530060,10.75607109] ; [106.67483521,10.75582314] ; [106.67430115,10.75565434] ; [106.67369843,10.75547028] ; [106.67326355,10.75540161]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3535"
    ,"Station_Code":"Q5 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"Đối diện 493 , đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.754811
    ,"Long":106.670364
    ,"Polyline":"[106.67326355,10.75540161] ; [106.67266846,10.75523281] ; [106.67144012,10.75494862] ; [106.67036438,10.75481129]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2082"
    ,"Station_Code":"Q5 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"Đối diện 153, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.755486
    ,"Long":106.669698
    ,"Polyline":"[106.67036438,10.75481129] ; [106.66960907,10.75461674] ; [106.66963196,10.75505352] ; [106.66970062,10.75548553]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.66970062,10.75548553] ; [106.66963959,10.75607109] ; [106.66965485,10.75662422] ; [106.66961670,10.75715065]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"431"
    ,"Station_Code":"Q5 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"116A , đường Hùng Vương, Quận 5"
    ,"Lat":10.757257
    ,"Long":106.668566
    ,"Polyline":"[106.66961670,10.75715065] ; [106.66950226,10.75739956] ; [106.66941071,10.75765038] ; [106.66856384,10.75725746]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bệnh viện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66860199,10.75724030] ; [106.66710663,10.75650024] ; [106.66664886,10.75636005] ; [106.66629791,10.75623989] ; [106.66513824,10.75594044] ; [106.66452789,10.75582027]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66451263,10.75589657] ; [106.66236877,10.75539017] ; [106.66107178,10.75519562]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107178,10.75519562] ; [106.66039276,10.75501156] ; [106.65950012,10.75487518]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"435"
    ,"Station_Code":"Q5 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"Đối diện 385, đư ờng Hồng Bàng, Quận 5"
    ,"Lat":10.75458
    ,"Long":106.657934
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65891266,10.75471687] ; [106.65838623,10.75463963] ; [106.65793610,10.75457954]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"438"
    ,"Station_Code":"Q5 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Dương Tử Giang"
    ,"Station_Address":"Đối diện 455-457, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754158
    ,"Long":106.65552
    ,"Polyline":"[106.65793610,10.75457954] ; [106.65730286,10.75442123] ; [106.65667725,10.75429535] ; [106.65551758,10.75415802]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung , Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.65551758,10.75415802] ; [106.65483856,10.75398445] ; [106.65378571,10.75380993] ; [106.65370178,10.75378895] ; [106.65367889,10.75370979] ; [106.65369415,10.75365734] ; [106.65373230,10.75355148] ; [106.65354919,10.75275040] ; [106.65330505,10.75169182] ; [106.65180969,10.75149632] ; [106.65170288,10.75134850] ; [106.65151978,10.75130653] ; [106.65106964,10.75118542]"
    ,"Distance":"700"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.65106964,10.75118542] ; [106.65107727,10.75096035] ; [106.65048981,10.75103760] ; [106.65075684,10.75336742] ; [106.65158081,10.75338840] ; [106.65232849,10.75339031] ; [106.65439606,10.75373650] ; [106.65232849,10.75339317]"
    ,"Distance":"981"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"470"
    ,"Station_Code":"Q5 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"399, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754111
    ,"Long":106.656749
    ,"Polyline":"[106.65232849,10.75339031] ; [106.65300751,10.75347042] ; [106.65377808,10.75360012] ; [106.65473938,10.75378990] ; [106.65672302,10.75415993]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65672302,10.75415993] ; [106.65728760,10.75426006] ; [106.65841675,10.75444984] ; [106.65859222,10.75444031] ; [106.65921783,10.75457001]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"217, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.65921783,10.75457001] ; [106.66153717,10.75502014] ; [106.66317749,10.75535011]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bệnh viện Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66317749,10.75535011] ; [106.66470337,10.75564003]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1981"
    ,"Station_Code":"Q5 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"161, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.755728
    ,"Long":106.669473
    ,"Polyline":"[106.66470337,10.75564003] ; [106.66841125,10.75642014] ; [106.66954803,10.75667000] ; [106.66953278,10.75572968]"
    ,"Distance":"647"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3166"
    ,"Station_Code":"Q5 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"493 , đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.754638
    ,"Long":106.670149
    ,"Polyline":"[106.66953278,10.75572968] ; [106.66951752,10.75456047] ; [106.67011261,10.75467968] ; [106.67012787,10.75469017]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3519"
    ,"Station_Code":"Q5 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trần Phú"
    ,"Station_Address":"467-469, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.755212
    ,"Long":106.673014
    ,"Polyline":"[106.67012787,10.75469017] ; [106.67299652,10.75526047]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3521"
    ,"Station_Code":"Q5 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh viện Nguyễn Trãi"
    ,"Station_Address":"331-333, đường  Nguyễn Trãi, Quận 5"
    ,"Lat":10.755839
    ,"Long":106.675084
    ,"Polyline":"[106.67299652,10.75526047] ; [106.67369843,10.75539970] ; [106.67430115,10.75555038] ; [106.67505646,10.75586033]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3523"
    ,"Station_Code":"Q5 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường TH Bầu Sen"
    ,"Station_Address":"155, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.757573
    ,"Long":106.679199
    ,"Polyline":"[106.67505646,10.75586033] ; [106.67816925,10.75718975] ; [106.67868042,10.75743008] ; [106.67913055,10.75761032]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3524"
    ,"Station_Code":"Q5 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Đại học  Sài Gòn"
    ,"Station_Address":"83, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.758501
    ,"Long":106.681554
    ,"Polyline":"[106.67917633,10.75763035] ; [106.68009186,10.75798988] ; [106.68079376,10.75827026] ; [106.68151855,10.75852966]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3079"
    ,"Station_Code":"Q5 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường THCS Ba Đình"
    ,"Station_Address":"257, đường Nguyễn Biểu, Quận 5"
    ,"Lat":10.758242
    ,"Long":106.682788
    ,"Polyline":"[106.68151855,10.75852966] ; [106.68260956,10.75891972] ; [106.68283844,10.75825977]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3078"
    ,"Station_Code":"Q5 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chung cư 109 Nguyễn Biểu"
    ,"Station_Address":"109, đường Nguyễn Biểu, Quận 5"
    ,"Lat":10.755565
    ,"Long":106.683769
    ,"Polyline":"[106.68283844,10.75825977] ; [106.68316650,10.75737953] ; [106.68380737,10.75559044]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1436"
    ,"Station_Code":"Q8 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Cầu Nguyễn Văn Cừ"
    ,"Station_Address":"109-111 , đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.750469
    ,"Long":106.686602
    ,"Polyline":"[106.68376923,10.75556469] ; [106.68399811,10.75509071] ; [106.68417358,10.75461674] ; [106.68428040,10.75413132] ; [106.68421173,10.75370979] ; [106.68392944,10.75236034] ; [106.68383026,10.75184441] ; [106.68370819,10.75133801] ; [106.68365479,10.75098515] ; [106.68399811,10.75017357] ; [106.68484497,10.74867725] ; [106.68527985,10.74893475] ; [106.68567657,10.74914551] ; [106.68579865,10.74929905] ; [106.68566895,10.74977875] ; [106.68551636,10.75017929] ; [106.68605804,10.75035858] ; [106.68659973,10.75046921]"
    ,"Distance":"1169"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1437"
    ,"Station_Code":"Q7 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Cầu Rạch  Ông"
    ,"Station_Address":"1013, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751291
    ,"Long":106.692621
    ,"Polyline":"[106.68659973,10.75046921] ; [106.68679810,10.75061035] ; [106.68733215,10.75076962] ; [106.68771362,10.75080967] ; [106.68816376,10.75067043] ; [106.68824768,10.75063038] ; [106.68833923,10.75061989] ; [106.68865204,10.75063705] ; [106.69090271,10.75109005] ; [106.69196320,10.75118542] ; [106.69225311,10.75129128] ; [106.69261932,10.75129128]"
    ,"Distance":"678"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1439"
    ,"Station_Code":"Q7 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bệnh viện Tân Hưng"
    ,"Station_Address":"909, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751644
    ,"Long":106.694836
    ,"Polyline":"[106.69261932,10.75129128] ; [106.69396210,10.75162029] ; [106.69443512,10.75166512] ; [106.69483948,10.75164413]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1441"
    ,"Station_Code":"Q7 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"chùa Kiều Đàm"
    ,"Station_Address":"807, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751655
    ,"Long":106.698344
    ,"Polyline":"[106.69515228,10.75172043] ; [106.69743347,10.75174046]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1440"
    ,"Station_Code":"Q7 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ủy ban Phường Tân Hưng"
    ,"Station_Address":"725-727, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751691
    ,"Long":106.701713
    ,"Polyline":"[106.69834137,10.75165462] ; [106.69906616,10.75171280] ; [106.70072174,10.75177002] ; [106.70171356,10.75169086]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1447"
    ,"Station_Code":"Q7 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"603-601, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751726
    ,"Long":106.704552
    ,"Polyline":"[106.70171356,10.75169086] ; [106.70213318,10.75176048] ; [106.70315552,10.75177574] ; [106.70388794,10.75179672] ; [106.70455170,10.75172615]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1442"
    ,"Station_Code":"Q7 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã 3 T ân Quy"
    ,"Station_Address":"38, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.751333
    ,"Long":106.705018
    ,"Polyline":"[106.70455170,10.75172615] ; [106.70492554,10.75178623] ; [106.70502472,10.75173378] ; [106.70503998,10.75152302] ; [106.70501709,10.75133324]"
    ,"Distance":"98"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1448"
    ,"Station_Code":"Q7 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Phan Huy Thực"
    ,"Station_Address":"148, đường Lê Văn  Lương, Quận 7"
    ,"Lat":10.748961
    ,"Long":106.704825
    ,"Polyline":"[106.70501709,10.75133324] ; [106.70514679,10.75102234] ; [106.70513916,10.75073242] ; [106.70506287,10.75016308] ; [106.70500946,10.74988937] ; [106.70492554,10.74961472] ; [106.70487976,10.74928856] ; [106.70482635,10.74896145]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1443"
    ,"Station_Code":"Q7 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"192, đường Lê Văn  Lương, Quận 7"
    ,"Lat":10.746068
    ,"Long":106.704422
    ,"Polyline":"[106.70482635,10.74896145] ; [106.70479584,10.74864292] ; [106.70442200,10.74606800]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1201"
    ,"Station_Code":"Q7 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Đường 15"
    ,"Station_Address":"2, đường Nguyễn Hữu Thọ, Qu ận 7"
    ,"Lat":10.743765
    ,"Long":106.701375
    ,"Polyline":"[106.70442200,10.74606800] ; [106.70442200,10.74553013] ; [106.70433044,10.74499035] ; [106.70250702,10.74522972] ; [106.70172882,10.74534035] ; [106.70159149,10.74428177] ; [106.70137787,10.74376488]"
    ,"Distance":"589"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1199"
    ,"Station_Code":"Q7 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Siêu thị Lotte"
    ,"Station_Address":"Đối diện siêu thị Lotte, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74084
    ,"Long":106.700866
    ,"Polyline":"[106.70137787,10.74376488] ; [106.70143127,10.74347019] ; [106.70118713,10.74190998] ; [106.70086670,10.74083996]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1202"
    ,"Station_Code":"Q7 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Đại học Cảnh sát"
    ,"Station_Address":"Đối diện B10, đường Nguyễn Hữu Thọ, Qu ận 7"
    ,"Lat":10.734373
    ,"Long":106.699793
    ,"Polyline":"[106.70086670,10.74083996] ; [106.70080566,10.73995972] ; [106.70041656,10.73762035] ; [106.70007324,10.73544025] ; [106.69979095,10.73437309]"
    ,"Distance":"730"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1200"
    ,"Station_Code":"Q7 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"ĐH Tôn Đức Thắng"
    ,"Station_Address":"Đối diện 568, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.731752
    ,"Long":106.699959
    ,"Polyline":"[106.69979095,10.73437309] ; [106.69985962,10.73377037] ; [106.69992828,10.73258972] ; [106.70000458,10.73221207] ; [106.69995880,10.73175240]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1204"
    ,"Station_Code":"Q7 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"645, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.729419
    ,"Long":106.700243
    ,"Polyline":"[106.69995880,10.73175240] ; [106.70006561,10.73145294] ; [106.70011902,10.73116970] ; [106.70020294,10.73056030] ; [106.70027924,10.73023987] ; [106.70031738,10.72979259] ; [106.70024109,10.72941875]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"835"
    ,"Station_Code":"Q7 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Phòng cháy chữa cháy Quận 7"
    ,"Station_Address":"Cạnh cột điện 39, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728106
    ,"Long":106.704031
    ,"Polyline":"[106.70024109,10.72941875] ; [106.70040894,10.72909164] ; [106.70053864,10.72826004] ; [106.70264435,10.72825909] ; [106.70403290,10.72810555]"
    ,"Distance":"517"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1203"
    ,"Station_Code":"Q7 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường Nam Sài Gòn"
    ,"Station_Address":"Đ/d Trường Nam Sài Gòn, đường Nguyễn Đức Cảnh, Quận 7"
    ,"Lat":10.722751
    ,"Long":106.709948
    ,"Polyline":"[106.70403290,10.72810555] ; [106.70516968,10.72831154] ; [106.70861053,10.72846031] ; [106.70862579,10.72647190] ; [106.70873260,10.72449017] ; [106.70874786,10.72408009] ; [106.70880127,10.72391033] ; [106.70886993,10.72375011] ; [106.70893097,10.72364044] ; [106.70935822,10.72323036] ; [106.70994568,10.72275066]"
    ,"Distance":"1193"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3526"
    ,"Station_Code":"Q7 180"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Mỹ Giang 2"
    ,"Station_Address":"Đ/d KDC Mỹ Giang 2, đường Nguyễn Đức C ảnh, Quận 7"
    ,"Lat":10.72137
    ,"Long":106.716809
    ,"Polyline":"[106.70994568,10.72275066] ; [106.71092224,10.72179031] ; [106.71114349,10.72167015] ; [106.71138000,10.72159004] ; [106.71163177,10.72154045] ; [106.71201324,10.72150040] ; [106.71468353,10.72078037] ; [106.71492767,10.72074032] ; [106.71537018,10.72076035] ; [106.71571350,10.72085953] ; [106.71601105,10.72099018] ; [106.71681213,10.72136974]"
    ,"Distance":"826"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1260"
    ,"Station_Code":"Q7 181"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trần Văn Trà"
    ,"Station_Address":"Trường CĐBC Công nghệ và QTDN, đường Trần Văn Trà, Quận 7"
    ,"Lat":10.724074
    ,"Long":106.72125
    ,"Polyline":"[106.71681213,10.72136974] ; [106.71719360,10.72169018] ; [106.72052002,10.72371960] ; [106.72087860,10.72394753] ; [106.72125244,10.72407436]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1371"
    ,"Station_Code":"Q7 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Tân Trào"
    ,"Station_Address":"Đối diện VP Đội Bảo vệ, đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.728538
    ,"Long":106.722114
    ,"Polyline":"[106.72125244,10.72407436] ; [106.72145844,10.72428989] ; [106.72377014,10.72568989] ; [106.72312164,10.72671032] ; [106.72230530,10.72795868] ; [106.72211456,10.72853756]"
    ,"Distance":"697"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3525"
    ,"Station_Code":"Q7 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Bệnh viện Quận 7"
    ,"Station_Address":"Bệnh viện Quận 7, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.737809
    ,"Long":106.723691
    ,"Polyline":"[106.72211456,10.72853756] ; [106.72179413,10.72890759] ; [106.72030640,10.73133183] ; [106.72060394,10.73157978] ; [106.72081757,10.73202229] ; [106.72128296,10.73280716] ; [106.72150421,10.73342991] ; [106.72165680,10.73437309] ; [106.72171783,10.73528957] ; [106.72174072,10.73604870] ; [106.72176361,10.73658085] ; [106.72177887,10.73726082] ; [106.72190857,10.73795700] ; [106.72276306,10.73797989] ; [106.72369385,10.73780918]"
    ,"Distance":"1345"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"3527"
    ,"Station_Code":"Q7 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Huỳnh Tấn Phát"
    ,"Station_Address":"35, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.737467
    ,"Long":106.728712
    ,"Polyline":"[106.72369385,10.73780918] ; [106.72449493,10.73781967] ; [106.72562408,10.73775673] ; [106.72747040,10.73762989] ; [106.72818756,10.73757744] ; [106.72871399,10.73746681]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2189"
    ,"Station_Code":"Q7 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nghĩa Trang Liệt Sĩ Nhà Bè"
    ,"Station_Address":"619, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.739944
    ,"Long":106.730188
    ,"Polyline":"[106.72871399,10.73746681] ; [106.72923279,10.73757172] ; [106.73000336,10.73751926] ; [106.73046112,10.73755074] ; [106.73030853,10.73874760] ; [106.73019409,10.73934269] ; [106.73018646,10.73994446]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2185"
    ,"Station_Code":"Q7 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Trường Nguyễn Hữu Cảnh"
    ,"Station_Address":"571, đường Hu ỳnh Tấn Phát, Quận 7"
    ,"Lat":10.742621
    ,"Long":106.729796
    ,"Polyline":"[106.73018646,10.73994446] ; [106.72990417,10.74128246] ; [106.72979736,10.74262142] ; [106.72979736,10.74262142]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2187"
    ,"Station_Code":"Q7 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Nhà sách Tân Thuận"
    ,"Station_Address":"473-475, đư ờng Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.745789
    ,"Long":106.729308
    ,"Polyline":"[106.72979736,10.74262142] ; [106.72944641,10.74392986] ; [106.72930908,10.74578857]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2190"
    ,"Station_Code":"Q7 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm y tế Q7"
    ,"Station_Address":"375, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.749441
    ,"Long":106.728868
    ,"Polyline":"[106.72930908,10.74578857] ; [106.72913361,10.74644756] ; [106.72885895,10.74802017] ; [106.72879791,10.74876022] ; [106.72879028,10.74892998] ; [106.72886658,10.74944115]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"2188"
    ,"Station_Code":"Q7 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 298, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.751892
    ,"Long":106.72868
    ,"Polyline":"[106.72886658,10.74944115] ; [106.72860718,10.75113010.06.72868347]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"104"
    ,"Station_Id":"1999"
    ,"Station_Code":"BX 15"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Khu chế xuất Tân Thuận"
    ,"Station_Address":"ĐẦU BẾN KCX TÂN THUẬN, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752883
    ,"Long":106.727501
    ,"Polyline":"[106.72868347,10.75189209] ; [106.72855377,10.75239754] ; [106.72846222,10.75277996] ; [106.72750854,10.75273991] ; [106.72750092,10.75288296]"
    ,"Distance":"222"
  }]