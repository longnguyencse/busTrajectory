export const Route27 =[
  {
     "Route_Id":"27"
    ,"Station_Id":"1417"
    ,"Station_Code":"BX 24"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Ba Tơ"
    ,"Station_Address":"ĐẦU BẾN NGÃ 3 BA TƠ, đường Phạm Thế Hiển, Quận  8"
    ,"Lat":10.707229
    ,"Long":106.62204
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1414"
    ,"Station_Code":"Q8 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ba Tơ"
    ,"Station_Address":"3421, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.708167
    ,"Long":106.623704
    ,"Polyline":"[106.62203979,10.70722961] ; [106.62223816,10.70767975] ; [106.62316895,10.70724964] ; [106.62333679,10.70744038] ; [106.62357330,10.70814037]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1419"
    ,"Station_Code":"Q8 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Giáo xứ B ình Sơn"
    ,"Station_Address":"3391, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.710449
    ,"Long":106.624895
    ,"Polyline":"[106.62370300,10.70816708] ; [106.62429047,10.71016979] ; [106.62489319,10.71044922]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1415"
    ,"Station_Code":"Q8 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường Nguy ễn Trung Ngạn"
    ,"Station_Address":"3259, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.712552
    ,"Long":106.628698
    ,"Polyline":"[106.62489319,10.71044922] ; [106.62691498,10.71157742] ; [106.62757111,10.71181393]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1421"
    ,"Station_Code":"Q8 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Thánh Đường  Bình Thuận"
    ,"Station_Address":"3127, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.714118
    ,"Long":106.630452
    ,"Polyline":"[106.62757111,10.71181393] ; [106.62849426,10.71254158] ; [106.62953949,10.71347046] ; [106.62998199,10.71387005] ; [106.62998199,10.71386147]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1423"
    ,"Station_Code":"Q8 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Bến Đò Rạch Cát"
    ,"Station_Address":"3023, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.715983
    ,"Long":106.63204
    ,"Polyline":"[106.62998199,10.71387005] ; [106.63015747,10.71403027] ; [106.63037872,10.71428967] ; [106.63133240,10.71535969] ; [106.63146973,10.71553040]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1424"
    ,"Station_Code":"Q8 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Bến đò Hội  Đồng"
    ,"Station_Address":"2867 , đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.719805
    ,"Long":106.634116
    ,"Polyline":"[106.63146973,10.71553040] ; [106.63194275,10.71613026] ; [106.63213348,10.71640968] ; [106.63230896,10.71669960] ; [106.63249969,10.71710968] ; [106.63320923,10.71850014] ; [106.63339233,10.71887970]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1418"
    ,"Station_Code":"Q8 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Chợ Phú Lợi"
    ,"Station_Address":"2765-2767, đường  Phạm Thế Hiển, Quận 8"
    ,"Lat":10.722915
    ,"Long":106.635522
    ,"Polyline":"[106.63339233,10.71887970] ; [106.63433075,10.72091007] ; [106.63491821,10.72206974]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1420"
    ,"Station_Code":"Q8 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường Bình An"
    ,"Station_Address":"2673, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.724464
    ,"Long":106.636283
    ,"Polyline":"[106.63491821,10.72206974] ; [106.63523102,10.72266960] ; [106.63578796,10.72383976] ; [106.63607025,10.72441006] ; [106.63610077,10.72447014]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1422"
    ,"Station_Code":"Q8 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Tòa thánh Cao đài Huỳnh Quang Sắt"
    ,"Station_Address":"2551-2553, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.728712
    ,"Long":106.638483
    ,"Polyline":"[106.63610077,10.72447014] ; [106.63629150,10.72494984] ; [106.63668060,10.72577000] ; [106.63697815,10.72642040] ; [106.63748932,10.72739983] ; [106.63774109,10.72784042] ; [106.63796234,10.72823048] ; [106.63815308,10.72852039] ; [106.63845062,10.72891998]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1426"
    ,"Station_Code":"Q8 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thờ B ình An"
    ,"Station_Address":"2305, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.731753
    ,"Long":106.641321
    ,"Polyline":"[106.63848114,10.72871208] ; [106.63845062,10.72891998] ; [106.63870239,10.72926044] ; [106.63887787,10.72951984] ; [106.63919067,10.72990036] ; [106.63971710,10.73050022] ; [106.64099884,10.73169994] ; [106.64131927,10.73175335]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"4700"
    ,"Station_Code":"Q8 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Chợ Mười Giờ"
    ,"Station_Address":"2225, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.733451
    ,"Long":106.643965
    ,"Polyline":"[106.64131927,10.73175335] ; [106.64160919,10.73208523] ; [106.64266205,10.73278141] ; [106.64394379,10.73352242]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1425"
    ,"Station_Code":"Q8 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Mười Giờ"
    ,"Station_Address":"1935-1937, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.735348
    ,"Long":106.647098
    ,"Polyline":"[106.64394379,10.73352242] ; [106.64701080,10.73532009]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1428"
    ,"Station_Code":"Q8 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà thờ Bình Thái"
    ,"Station_Address":"1785, đường Phạm  Thế Hiển, Quận 8"
    ,"Lat":10.737029
    ,"Long":106.649909
    ,"Polyline":"[106.64701080,10.73532009] ; [106.64700317,10.73538971] ; [106.64986420,10.73703957] ; [106.64990997,10.73702908]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1430"
    ,"Station_Code":"Q8 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Lò Than"
    ,"Station_Address":"1537, đường Phạm  Thế Hiển, Quận 8"
    ,"Lat":10.739238
    ,"Long":106.653616
    ,"Polyline":"[106.64990997,10.73702908] ; [106.65180969,10.73824120] ; [106.65361786,10.73923779]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1427"
    ,"Station_Code":"Q8 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Cầu Hiệp Ân"
    ,"Station_Address":"1219, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.741409
    ,"Long":106.659254
    ,"Polyline":"[106.65403748,10.73966980] ; [106.65454865,10.73997021] ; [106.65473175,10.74005032] ; [106.65482330,10.74038982] ; [106.65490723,10.74059963] ; [106.65498352,10.74065971] ; [106.65554810,10.74092960] ; [106.65621948,10.74120998] ; [106.65634918,10.74123001] ; [106.65667725,10.74114037] ; [106.65695953,10.74104977] ; [106.65718079,10.74106026] ; [106.65750885,10.74112988] ; [106.65930939,10.74149990]"
    ,"Distance":"735"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1432"
    ,"Station_Code":"Q8 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Quận ủy Quận 8"
    ,"Station_Address":"1093, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.74248
    ,"Long":106.664864
    ,"Polyline":"[106.65956879,10.74155045] ; [106.66113281,10.74186993] ; [106.66188812,10.74199963] ; [106.66403198,10.74234009] ; [106.66487885,10.74248981]"
    ,"Distance":"630"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1429"
    ,"Station_Code":"Q8 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công an Qu ận 8"
    ,"Station_Address":"987-989, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.742869
    ,"Long":106.667333
    ,"Polyline":"[106.66486359,10.74248028] ; [106.66486359,10.74248028] ; [106.66552734,10.74267387] ; [106.66829681,10.74308968] ; [106.66829681,10.74303818]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1434"
    ,"Station_Code":"Q8 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Phạm Thế Hiển"
    ,"Station_Address":"907, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.743744
    ,"Long":106.672391
    ,"Polyline":"[106.66829681,10.74308968] ; [106.66898346,10.74320984] ; [106.66992188,10.74339008] ; [106.67070007,10.74351978] ; [106.67196655,10.74376011]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1431"
    ,"Station_Code":"Q8 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cao Lỗ"
    ,"Station_Address":"Đối diện 714 , đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.744598
    ,"Long":106.674972
    ,"Polyline":"[106.67239380,10.74374390] ; [106.67254639,10.74388981] ; [106.67327881,10.74409008] ; [106.67391205,10.74427986] ; [106.67463684,10.74454975] ; [106.67487335,10.74464035] ; [106.67497253,10.74459839]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1433"
    ,"Station_Code":"Q8 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngân hàng Sacombank"
    ,"Station_Address":"657-659, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.745583
    ,"Long":106.677053
    ,"Polyline":"[106.67497253,10.74459839] ; [106.67559052,10.74495983] ; [106.67646027,10.74540043] ; [106.67705536,10.74558258]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1435"
    ,"Station_Code":"Q8 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Mật"
    ,"Station_Address":"509-511, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.746679
    ,"Long":106.67899
    ,"Polyline":"[106.67705536,10.74558258] ; [106.67722321,10.74578953] ; [106.67899323,10.74667931]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1438"
    ,"Station_Code":"Q8 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Công viên Phường 2"
    ,"Station_Address":"231-233, đường Phạm Thế Hiển , Quận 8"
    ,"Lat":10.749104
    ,"Long":106.683533
    ,"Polyline":"[106.67899323,10.74667931] ; [106.67955780,10.74707985] ; [106.68154144,10.74816036] ; [106.68263245,10.74878025] ; [106.68353271,10.74910355]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1436"
    ,"Station_Code":"Q8 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Cầu Nguyễn Văn Cừ"
    ,"Station_Address":"109-111, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.750469
    ,"Long":106.686602
    ,"Polyline":"[106.68353271,10.74910355] ; [106.68382263,10.74938965] ; [106.68433380,10.74965000] ; [106.68550110,10.75014210.06.68634033] ; [10.75045300,106.68659973]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1437"
    ,"Station_Code":"Q7 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cầu Rạch Ông"
    ,"Station_Address":"1013, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751291
    ,"Long":106.692621
    ,"Polyline":"[106.68682861,10.75053978] ; [106.68679810,10.75061035] ; [106.68733215,10.75076962] ; [106.68771362,10.75080967] ; [106.68816376,10.75067043] ; [106.68824768,10.75063038] ; [106.68833923,10.75061989] ; [106.68865204,10.75063705] ; [106.69090271,10.75109005] ; [106.69196320,10.75118542] ; [106.69227600,10.75111198]"
    ,"Distance":"647"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1439"
    ,"Station_Code":"Q7 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh viện Tân Hưng"
    ,"Station_Address":"909, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751644
    ,"Long":106.694836
    ,"Polyline":"[106.69227600,10.75111198] ; [106.69249725,10.75130653] ; [106.69396210,10.75162029] ; [106.69443512,10.75166512] ; [106.69501495,10.75168133] ; [106.69515991,10.75151253]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1441"
    ,"Station_Code":"Q7 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"chùa Kiều Đàm"
    ,"Station_Address":"807, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751655
    ,"Long":106.698344
    ,"Polyline":"[106.69515228,10.75172043] ; [106.69743347,10.75174046]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1440"
    ,"Station_Code":"Q7 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ủy ban Ph ường Tân Hưng"
    ,"Station_Address":"725-727, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751691
    ,"Long":106.701713
    ,"Polyline":"[106.69742584,10.75164413] ; [106.69743347,10.75174046] ; [106.69906616,10.75171280] ; [106.70072174,10.75177002] ; [106.70072174,10.75166512]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1447"
    ,"Station_Code":"Q7 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"603-601, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751726
    ,"Long":106.704552
    ,"Polyline":"[106.70072174,10.75177002] ; [106.70455170,10.75181007]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1442"
    ,"Station_Code":"Q7 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"38, đường Lê Văn Lương, Qu ận 7"
    ,"Lat":10.751333
    ,"Long":106.705018
    ,"Polyline":"[106.70455170,10.75181007] ; [106.70503235,10.75181007] ; [106.70504761,10.75160980] ; [106.70510101,10.75131035]"
    ,"Distance":"121"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1448"
    ,"Station_Code":"Q7 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Phan Huy Thực"
    ,"Station_Address":"148, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.748961
    ,"Long":106.704825
    ,"Polyline":"[106.70510101,10.75131035] ; [106.70522308,10.75082016] ; [106.70517731,10.75047016] ; [106.70504761,10.74981976] ; [106.70494080,10.74930000] ; [106.70485687,10.74862957]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1443"
    ,"Station_Code":"Q7 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"192, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.746068
    ,"Long":106.704422
    ,"Polyline":"[106.70485687,10.74862957] ; [106.70468140,10.74750042] ; [106.70458221,10.74656010.06.70442200]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1346"
    ,"Station_Code":"Q7 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chung cư Minh Thành"
    ,"Station_Address":"222, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744576
    ,"Long":106.704216
    ,"Polyline":"[106.70442200,10.74553013] ; [106.70427704,10.74456978]"
    ,"Distance":"123"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1247"
    ,"Station_Code":"Q7 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Siêu thị Lotte"
    ,"Station_Address":"Siêu thị Lotte , đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74085
    ,"Long":106.701134
    ,"Polyline":"[106.70427704,10.74456978] ; [106.70401001,10.74250984] ; [106.70355225,10.73993015] ; [106.70098114,10.74038982] ; [106.70108032,10.74098969]"
    ,"Distance":"887"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1249"
    ,"Station_Code":"Q7 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Đường 15"
    ,"Station_Address":"458B, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.743865
    ,"Long":106.701665
    ,"Polyline":"[106.70108032,10.74098969] ; [106.70157623,10.74388981]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1251"
    ,"Station_Code":"Q7 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Cầu Kinh Tẻ"
    ,"Station_Address":"Đối diện 44/9, đường Nguy ễn Hữu Thọ, Quận 7"
    ,"Lat":10.748524
    ,"Long":106.702443
    ,"Polyline":"[106.70157623,10.74388981] ; [106.70184326,10.74543953] ; [106.70211792,10.74703026] ; [106.70237732,10.74864006]"
    ,"Distance":"550"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"4424"
    ,"Station_Code":"Q4 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Trung tâm TDTT Quận 4"
    ,"Station_Address":"120-122, đư ờng Khánh Hội, Quận 4"
    ,"Lat":10.75683
    ,"Long":106.700732
    ,"Polyline":"[106.70246124,10.74862385] ; [106.70209503,10.75481129] ; [106.70072937,10.75683022]"
    ,"Distance":"960"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1250"
    ,"Station_Code":"Q4 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chung cư Tân Vĩnh"
    ,"Station_Address":"202-204, đường Khánh Hội, Quận 4"
    ,"Lat":10.758848
    ,"Long":106.699213
    ,"Polyline":"[106.70072937,10.75683022] ; [106.69921112,10.75884819]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1253"
    ,"Station_Code":"Q4 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Chung cư H3"
    ,"Station_Address":"303-305, đường Hoàng Diệu , Quận 4"
    ,"Lat":10.760066
    ,"Long":106.699294
    ,"Polyline":"[106.69914246,10.75887012] ; [106.69864655,10.75953007] ; [106.69851685,10.75963974] ; [106.69918823,10.76012039]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1379"
    ,"Station_Code":"Q1 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"82 - 84, đường Nguyễn Thái  Học, Quận 1"
    ,"Lat":10.766109
    ,"Long":106.696686
    ,"Polyline":"[106.69918823,10.76012039] ; [106.69972992,10.76053047] ; [106.70041656,10.76099968] ; [106.69986725,10.76181984] ; [106.69959259,10.76220036] ; [106.69931793,10.76249027] ; [106.69872284,10.76309967] ; [106.69805145,10.76377010.06.69786835] ; [10.76395988,106.69760895] ; [10.76432037,106.69657135]"
    ,"Distance":"899"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1385"
    ,"Station_Code":"Q1 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trường Nguyễn Thái Học"
    ,"Station_Address":"141-149, đư ờng Lê Thị Hồng Gấm, Quận 1"
    ,"Lat":10.767635
    ,"Long":106.696281
    ,"Polyline":"[106.69668579,10.76610947] ; [106.69583130,10.76731968] ; [106.69628143,10.76763535]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận  1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69628143,10.76763535] ; [106.69622803,10.76768970] ; [106.69686127,10.76826954] ; [106.69642639,10.76920986] ; [106.69615173,10.76978970] ; [106.69595337,10.76980972]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69577789,10.76972771] ; [106.69577789,10.76972771] ; [106.69493103,10.76938725] ; [106.69409180,10.76904678] ; [106.69409180,10.76904678]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9 , đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.69398499,10.76903534] ; [106.69384003,10.76895618] ; [106.69238281,10.76828003] ; [106.69049072,10.76753044] ; [106.68981171,10.76729584] ; [106.68961334,10.76770687] ; [106.68936157,10.76767635] ; [106.68936157,10.76767635]"
    ,"Distance":"575"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68904877,10.76807022] ; [106.68920898,10.76819992] ; [106.68988800,10.76844978] ; [106.69026184,10.76860046]"
    ,"Distance":"145"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76860046] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1451"
    ,"Station_Code":"Q1 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trần Hưng Đạo"
    ,"Station_Address":"197, đường Nguy ễn Thái Học, Quận 1"
    ,"Lat":10.768461
    ,"Long":106.694984
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69412994,10.77013969] ; [106.69467163,10.76920033] ; [106.69509125,10.76852989] ; [106.69498444,10.76846123]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1344"
    ,"Station_Code":"Q1 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"65G, đường Nguyễn Thái Học, Quận 1"
    ,"Lat":10.766576
    ,"Long":106.696129
    ,"Polyline":"[106.69498444,10.76846123] ; [106.69612885,10.76657581]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1196"
    ,"Station_Code":"Q4 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"K48-K50 , đường Hoàng Diệu, Quận 4"
    ,"Lat":10.760429
    ,"Long":106.699428
    ,"Polyline":"[106.69615936,10.76659012] ; [106.69715881,10.76490974] ; [106.69769287,10.76404953] ; [106.69786835,10.76385021] ; [106.69870758,10.76303959] ; [106.69938660,10.76233959] ; [106.69954681,10.76216030] ; [106.69976044,10.76189041] ; [106.70005798,10.76144028] ; [106.70018005,10.76123047] ; [106.70036316,10.76097012] ; [106.69986725,10.76062012] ; [106.69950104,10.76035023]"
    ,"Distance":"913"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1194"
    ,"Station_Code":"Q4 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chung cư Tân Vĩnh"
    ,"Station_Address":"Đối diện 220, đường Khánh Hội, Quận 4"
    ,"Lat":10.758864
    ,"Long":106.698972
    ,"Polyline":"[106.69950104,10.76035023] ; [106.69892883,10.75992012] ; [106.69851685,10.75963974] ; [106.69857025,10.75949001] ; [106.69902039,10.75889969]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1198"
    ,"Station_Code":"Q4 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trung tâm TDTT Quận 4"
    ,"Station_Address":"149, đường Khánh Hội, Quận 4"
    ,"Lat":10.756725
    ,"Long":106.700581
    ,"Polyline":"[106.69902039,10.75889969] ; [106.69972992,10.75798035] ; [106.70034790,10.75714016] ; [106.70060730,10.75679016]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1197"
    ,"Station_Code":"Q7 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cầu Kinh Tẻ"
    ,"Station_Address":"44/7, đường Nguyễn Hữu Thọ, Qu ận 7"
    ,"Lat":10.74845
    ,"Long":106.702196
    ,"Polyline":"[106.70060730,10.75679016] ; [106.70114899,10.75607967] ; [106.70162964,10.75549030] ; [106.70181274,10.75527000] ; [106.70191193,10.75510025] ; [106.70195770,10.75491047] ; [106.70204163,10.75397015] ; [106.70223236,10.75174046] ; [106.70237732,10.74991035] ; [106.70236969,10.74905968] ; [106.70230103,10.74845028]"
    ,"Distance":"1003"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1201"
    ,"Station_Code":"Q7 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Đường 15"
    ,"Station_Address":"2, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.743765
    ,"Long":106.701375
    ,"Polyline":"[106.70230103,10.74845028] ; [106.70204926,10.74703979] ; [106.70172882,10.74534035] ; [106.70149994,10.74390984] ; [106.70143127,10.74347019]"
    ,"Distance":"581"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1199"
    ,"Station_Code":"Q7 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu thị  Lotte"
    ,"Station_Address":"Đối diện siêu th ị Lotte, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74084
    ,"Long":106.700866
    ,"Polyline":"[106.70143127,10.74347019] ; [106.70098114,10.74083996]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1444"
    ,"Station_Code":"Q7 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Lotte Mart"
    ,"Station_Address":"1, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.740144
    ,"Long":106.701525
    ,"Polyline":"[106.70098114,10.74083996] ; [106.70089722,10.74040985] ; [106.70088196,10.74030972] ; [106.70095825,10.74030018] ; [106.70149994,10.74020004]"
    ,"Distance":"135"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1380"
    ,"Station_Code":"Q7 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Lotte Mark"
    ,"Station_Address":"359, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.740208
    ,"Long":106.70369
    ,"Polyline":"[106.70149994,10.74020004] ; [106.70353699,10.73985958] ; [106.70355225,10.73993015] ; [106.70361328,10.74022007]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1382"
    ,"Station_Code":"Q7 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đường số 15"
    ,"Station_Address":"265, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744471
    ,"Long":106.70432
    ,"Polyline":"[106.70361328,10.74022007] ; [106.70401001,10.74250984] ; [106.70423126,10.74417973]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1453"
    ,"Station_Code":"Q7 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"221, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.745957
    ,"Long":106.704519
    ,"Polyline":"[106.70423126,10.74417973] ; [106.70445251,10.74569988]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1445"
    ,"Station_Code":"Q7 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Phan Huy  Thục"
    ,"Station_Address":"179, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.748861
    ,"Long":106.704943
    ,"Polyline":"[106.70445251,10.74569988] ; [106.70458221,10.74656010.06.70467377] ; [10.74744987,106.70482635] ; [10.74837971,106.70488739]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1454"
    ,"Station_Code":"Q7 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"23-25, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.751468
    ,"Long":106.705124
    ,"Polyline":"[106.70488739,10.74884987] ; [106.70497894,10.74948025] ; [106.70517731,10.75047016] ; [106.70522308,10.75082016] ; [106.70514679,10.75107002] ; [106.70507813,10.75146008]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1455"
    ,"Station_Code":"Q7 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã 3 Tân  Quy"
    ,"Station_Address":"Đối diện 263, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751839
    ,"Long":106.704508
    ,"Polyline":"[106.70507813,10.75146008] ; [106.70503235,10.75181007] ; [106.70436859,10.75179958]"
    ,"Distance":"131"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1446"
    ,"Station_Code":"Q7 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ủy ban Ph ường Tân Hưng"
    ,"Station_Address":"Đối diện 733 , đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751786
    ,"Long":106.701347
    ,"Polyline":"[106.70436859,10.75179958] ; [106.70134735,10.75177002]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1456"
    ,"Station_Code":"Q7 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"chùa Kiều Đ àm"
    ,"Station_Address":"Đối diện 829, đường Tr ần Xuân Soạn, Quận 7"
    ,"Lat":10.751776
    ,"Long":106.697998
    ,"Polyline":"[106.70134735,10.75177002] ; [106.69799042,10.75174046]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1450"
    ,"Station_Code":"Q7 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Bệnh viện Tân Hưng"
    ,"Station_Address":"Đối diện 933 , đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751731
    ,"Long":106.694519
    ,"Polyline":"[106.69799042,10.75174046] ; [106.69609070,10.75174046] ; [106.69451904,10.75170040]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1461"
    ,"Station_Code":"Q7 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Rạch Ông"
    ,"Station_Address":"Đối diện 999, đường Trần Xu ân Soạn, Quận 7"
    ,"Lat":10.751496
    ,"Long":106.692969
    ,"Polyline":"[106.69451904,10.75173092] ; [106.69437408,10.75171280] ; [106.69403839,10.75164986] ; [106.69360352,10.75156975] ; [106.69192505,10.75129128] ; [106.69183350,10.75133324]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1452"
    ,"Station_Code":"Q8 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Nguyễn Văn Cừ"
    ,"Station_Address":"122, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.750859
    ,"Long":106.68724
    ,"Polyline":"[106.69183350,10.75133324] ; [106.69169617,10.75122738] ; [106.68919373,10.75076962] ; [106.68846130,10.75063038] ; [106.68824768,10.75063038] ; [106.68778992,10.75078011] ; [106.68771362,10.75080967] ; [106.68751526,10.75086975] ; [106.68727875,10.75081635] ; [106.68711853,10.75075340]"
    ,"Distance":"550"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1449"
    ,"Station_Code":"Q8 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cầu Chữ Y"
    ,"Station_Address":"124, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.749931
    ,"Long":106.684767
    ,"Polyline":"[106.68711853,10.75075340] ; [106.68697357,10.75072193] ; [106.68621826,10.75046349] ; [106.68547821,10.75018978] ; [106.68484497,10.74994183] ; [106.68475342,10.74989986]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1463"
    ,"Station_Code":"Q8 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Âu Dương Lân"
    ,"Station_Address":"410, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.74796
    ,"Long":106.680937
    ,"Polyline":"[106.68476868,10.74985981] ; [106.68431091,10.74964046] ; [106.68263245,10.74878025] ; [106.68097687,10.74785042]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1457"
    ,"Station_Code":"Q8 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Mật"
    ,"Station_Address":"486, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.746822
    ,"Long":106.67885
    ,"Polyline":"[106.68097687,10.74785042] ; [106.67944336,10.74701977]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1458"
    ,"Station_Code":"Q8 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngân hàng  Sacombank"
    ,"Station_Address":"600A, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.745757
    ,"Long":106.676924
    ,"Polyline":"[106.67884827,10.74682236] ; [106.67891693,10.74676418] ; [106.67755127,10.74596024] ; [106.67710114,10.74573040] ; [106.67692566,10.74575710]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1464"
    ,"Station_Code":"Q8 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cao Lỗ"
    ,"Station_Address":"1A LÔ 8, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.744081
    ,"Long":106.672922
    ,"Polyline":"[106.67692566,10.74575710.06.67517853] ; [10.74477005,106.67417145] ; [10.74437046,106.67365265] ; [10.74419975,106.67349243] ; [10.74415016,106.67292023]"
    ,"Distance":"480"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1466"
    ,"Station_Code":"Q8 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Phạm Thế Hiển"
    ,"Station_Address":"1BLô27, đường Phạm Thế Hiê ̉n, Quận 8"
    ,"Lat":10.743501
    ,"Long":106.670047
    ,"Polyline":"[106.67292023,10.74408054] ; [106.67294312,10.74398994] ; [106.67215729,10.74380016] ; [106.67095184,10.74357033] ; [106.67004395,10.74350071]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1468"
    ,"Station_Code":"Q8 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Công an Quận 8"
    ,"Station_Address":"1092, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.743027
    ,"Long":106.667161
    ,"Polyline":"[106.67004395,10.74350071] ; [106.66954803,10.74332047] ; [106.66879272,10.74322701] ; [106.66753387,10.74302673] ; [106.66716003,10.74302673]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1459"
    ,"Station_Code":"Q8 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Quận ủy Quận 8"
    ,"Station_Address":"1228, đường Ph ạm Thế Hiển, Quận 8"
    ,"Lat":10.742252
    ,"Long":106.662987
    ,"Polyline":"[106.66716003,10.74302673] ; [106.66546631,10.74270058] ; [106.66415405,10.74242592] ; [106.66316223,10.74221039] ; [106.66298676,10.74225235]"
    ,"Distance":"466"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1460"
    ,"Station_Code":"Q8 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cầu Nhị Thiên Đường"
    ,"Station_Address":"1436, đường  Phạm Thế Hiển, Quận 8"
    ,"Lat":10.741562
    ,"Long":106.659173
    ,"Polyline":"[106.66298676,10.74225235] ; [106.66113281,10.74186993] ; [106.65917206,10.74156189]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1462"
    ,"Station_Code":"Q8 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Lò Than"
    ,"Station_Address":"1650, đường Phạm  Thế Hiển, Quận 8"
    ,"Lat":10.739433
    ,"Long":106.653482
    ,"Polyline":"[106.65924072,10.74147987] ; [106.65724945,10.74106979] ; [106.65705109,10.74104977] ; [106.65682983,10.74108028] ; [106.65647125,10.74120998] ; [106.65634918,10.74123001] ; [106.65622711,10.74122047] ; [106.65573120,10.74102020] ; [106.65498352,10.74065971] ; [106.65490723,10.74059963] ; [106.65487671,10.74053001] ; [106.65476227,10.74020958] ; [106.65473175,10.74005032] ; [106.65454865,10.73997021] ; [106.65415955,10.73974037]"
    ,"Distance":"727"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1465"
    ,"Station_Code":"Q8 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Nhà thờ Bình Thái"
    ,"Station_Address":"1808, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.73714
    ,"Long":106.649796
    ,"Polyline":"[106.65348053,10.73943329] ; [106.65319061,10.73917007] ; [106.65115356,10.73791027] ; [106.64979553,10.73713970]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1467"
    ,"Station_Code":"Q8 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Mười  Giờ"
    ,"Station_Address":"1978-1980, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.735248
    ,"Long":106.646631
    ,"Polyline":"[106.64979553,10.73713970] ; [106.64959717,10.73696041] ; [106.64662933,10.73524761]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1469"
    ,"Station_Code":"Q8 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nhà thờ B ình An"
    ,"Station_Address":"2258, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.73353
    ,"Long":106.643735
    ,"Polyline":"[106.64662933,10.73524761] ; [106.64662933,10.73517036] ; [106.64497375,10.73414993] ; [106.64373779,10.73353004]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1470"
    ,"Station_Code":"Q8 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Bà Tàng"
    ,"Station_Address":"2482, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.73061
    ,"Long":106.63977
    ,"Polyline":"[106.64366150,10.73338985] ; [106.64256287,10.73274040] ; [106.64153290,10.73206997] ; [106.64108276,10.73176956] ; [106.64090729,10.73161983] ; [106.63983154,10.73060036]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1472"
    ,"Station_Code":"Q8 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Tòa thánh  Cao đài Huỳnh Quang Sắt"
    ,"Station_Address":"2532A , đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.728886
    ,"Long":106.638381
    ,"Polyline":"[106.63983154,10.73060036] ; [106.63954926,10.73031044] ; [106.63941193,10.73013973] ; [106.63906097,10.72972965] ; [106.63874817,10.72933006] ; [106.63849640,10.72898960]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1471"
    ,"Station_Code":"Q8 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trường Bình  An"
    ,"Station_Address":"2618, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.724501
    ,"Long":106.636069
    ,"Polyline":"[106.63849640,10.72898960] ; [106.63831329,10.72873020] ; [106.63800812,10.72830009] ; [106.63787079,10.72809982] ; [106.63762665,10.72766972] ; [106.63729858,10.72704029] ; [106.63674927,10.72591019] ; [106.63629150,10.72494984] ; [106.63613892,10.72457027]"
    ,"Distance":"585"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1473"
    ,"Station_Code":"Q8 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Phú Lợi"
    ,"Station_Address":"2678A , đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.722951
    ,"Long":106.635275
    ,"Polyline":"[106.63607025,10.72450066] ; [106.63613892,10.72457027] ; [106.63591766,10.72412968] ; [106.63536835,10.72292995] ; [106.63527679,10.72295094]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1474"
    ,"Station_Code":"Q8 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Bến Đò Hội  Đồng"
    ,"Station_Address":"2756, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.719973
    ,"Long":106.633848
    ,"Polyline":"[106.63527679,10.72295094] ; [106.63488007,10.72196960] ; [106.63433075,10.72091007] ; [106.63385010,10.71997261]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1477"
    ,"Station_Code":"Q8 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Bến Đò Rạch Cát"
    ,"Station_Address":"2842, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.715983
    ,"Long":106.631799
    ,"Polyline":"[106.63385010,10.71997261] ; [106.63301849,10.71798134] ; [106.63179779,10.71598339]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1475"
    ,"Station_Code":"Q8 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Thánh Đư ờng Bình Thuận"
    ,"Station_Address":"2902A, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.713928
    ,"Long":106.630035
    ,"Polyline":"[106.63155365,10.71562958] ; [106.63050842,10.71442986] ; [106.63025665,10.71413994] ; [106.63004303,10.71391964]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1476"
    ,"Station_Code":"Q8 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trường Nguyễn Trung Ngạn"
    ,"Station_Address":"2968-2970, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.711944
    ,"Long":106.62748
    ,"Polyline":"[106.63004303,10.71391964] ; [106.62943268,10.71337032] ; [106.62888336,10.71288967] ; [106.62850952,10.71259022] ; [106.62824249,10.71236038] ; [106.62801361,10.71220970] ; [106.62747955,10.71193981]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1480"
    ,"Station_Code":"Q8 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Giáo xứ Bình Sơn"
    ,"Station_Address":"3022, đường Phạm  Thế Hiển, Quận 8"
    ,"Lat":10.710586
    ,"Long":106.624809
    ,"Polyline":"[106.62747955,10.71193981] ; [106.62663269,10.71148968] ; [106.62500763,10.71065998] ; [106.62444305,10.71033001]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"27"
    ,"Station_Id":"1417"
    ,"Station_Code":"BX 24"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Ba Tơ"
    ,"Station_Address":"ĐẦU BẾN NGÃ 3 BA TƠ, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.707229
    ,"Long":106.62204
    ,"Polyline":"[106.62444305,10.71033001] ; [106.62432861,10.71028042] ; [106.62423706,10.71020985] ; [106.62387085,10.70901966] ; [106.62371063,10.70860004] ; [106.62333679,10.70744038] ; [106.62316895,10.70724964] ; [106.62223816,10.70767975] ; [106.62203979,10.70722961]"
    ,"Distance":"547"
  }]