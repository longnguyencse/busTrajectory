export const Route66 =[

  {
     "Route_Id":"66"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ L ĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1408"
    ,"Station_Code":"QBTH 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã năm Liệt Sĩ"
    ,"Station_Address":"222/4 Ter, đ ường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.81204
    ,"Long":106.710624
    ,"Polyline":"[106.71129608,10.81473255] ; [106.71147156,10.81518078] ; [106.71171570,10.81559181] ; [106.71133423,10.81580257] ; [106.71108246,10.81585503] ; [106.71093750,10.81612873] ; [106.71057129,10.81539154] ; [106.71012878,10.81463242] ; [106.70972443,10.81376839] ; [106.70952606,10.81332588] ; [106.71062469,10.81204033]"
    ,"Distance":"752"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1410"
    ,"Station_Code":"QBTH 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Chợ Phường  25"
    ,"Station_Address":"đối diện 134/4A, đường Ung Văn Khiêm, Quận Bình Thạnh"
    ,"Lat":10.808304
    ,"Long":106.714674
    ,"Polyline":"[106.71063995,10.81206989] ; [106.71228790,10.81021976] ; [106.71260834,10.80994987] ; [106.71311188,10.80943966] ; [106.71337891,10.80918980] ; [106.71417999,10.80860996] ; [106.71463776,10.80834007]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1405"
    ,"Station_Code":"QBTH 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Đại học Ngoại Thương"
    ,"Station_Address":"8A, đường Đường D2, Quận B ình Thạnh"
    ,"Lat":10.806444
    ,"Long":106.716042
    ,"Polyline":"[106.71463776,10.80834007] ; [106.71562195,10.80786037] ; [106.71634674,10.80760002] ; [106.71617889,10.80694008] ; [106.71607208,10.80642986]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1407"
    ,"Station_Code":"QBTH 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường ĐH Giao thông Vận tải Tp . HCM"
    ,"Station_Address":"74 Cư xá Văn Thánh Bắc, đường Đường D2, Quận Bình Th ạnh"
    ,"Lat":10.804057
    ,"Long":106.715843
    ,"Polyline":"[106.71607208,10.80642986] ; [106.71597290,10.80599976] ; [106.71595001,10.80583954] ; [106.71589661,10.80473995] ; [106.71588135,10.80438042]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"483, đường Điện Biên Phủ,  Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71588135,10.80438042] ; [106.71578217,10.80307961] ; [106.71571350,10.80268955] ; [106.71565247,10.80245018] ; [106.71533203,10.80154991] ; [106.71513367,10.80097008] ; [106.71481323,10.80107975]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"422"
    ,"Station_Code":"QBTHT056"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cửa nhôm Bá Thịnh"
    ,"Station_Address":"459, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.801496505737305
    ,"Long":106.71380615234375
    ,"Polyline":"[106.71481323,10.80107975] ; [106.71379089,10.80140972]"
    ,"Distance":"117"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"419, đường Điện Bi ên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71379089,10.80140972] ; [106.71334839,10.80150986] ; [106.71280670,10.80154037]"
    ,"Distance":"108"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1873"
    ,"Station_Code":"QBTH 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"10b, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.801454
    ,"Long":106.710076
    ,"Polyline":"[106.71280670,10.80154037] ; [106.71231842,10.80156040] ; [106.71144867,10.80158043] ; [106.71138763,10.80160046] ; [106.71130371,10.80160046] ; [106.71124268,10.80158043] ; [106.71119690,10.80154991] ; [106.71060944,10.80148029] ; [106.71018982,10.80144978] ; [106.70973969,10.80136967]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1872"
    ,"Station_Code":"QBTH 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Đại học Hồng Bàng"
    ,"Station_Address":"205 , đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799747
    ,"Long":106.706268
    ,"Polyline":"[106.70973969,10.80136967] ; [106.70937347,10.80125046] ; [106.70861816,10.80097961] ; [106.70812988,10.80078030] ; [106.70787811,10.80064964] ; [106.70706177,10.80016994] ; [106.70671082,10.79996014] ; [106.70635986,10.79969025]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1875"
    ,"Station_Code":"QBTH 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trạm  Điện Nguyễn Cửu Vân"
    ,"Station_Address":"119, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.797724
    ,"Long":106.704175
    ,"Polyline":"[106.70635986,10.79969025] ; [106.70567322,10.79909039] ; [106.70514679,10.79858017] ; [106.70429993,10.79765987]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1874"
    ,"Station_Code":"QBTH 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cầu Điện Biên Phủ"
    ,"Station_Address":"45, đường Đi ện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.795157
    ,"Long":106.701745
    ,"Polyline":"[106.70429993,10.79765987] ; [106.70189667,10.79514027] ; [106.70137024,10.79452991] ; [106.70118713,10.79428959]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1877"
    ,"Station_Code":"Q1 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn Văn Thủ"
    ,"Station_Address":"75, đường Nguyễn Bỉnh Khiêm, Quận 1"
    ,"Lat":10.791216
    ,"Long":106.700569
    ,"Polyline":"[106.70118713,10.79428959] ; [106.70089722,10.79389954] ; [106.69998932,10.79294968] ; [106.69970703,10.79273033] ; [106.69946289,10.79261017] ; [106.69937134,10.79259014] ; [106.69928741,10.79255009] ; [106.69921112,10.79246998] ; [106.69915771,10.79236984] ; [106.69917297,10.79228973] ; [106.69924164,10.79220963] ; [106.69936371,10.79218006] ; [106.69947052,10.79218960] ; [106.69959259,10.79222965] ; [106.70001221,10.79185009] ; [106.70063019,10.79127979]"
    ,"Distance":"528"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đài truy ền hình"
    ,"Station_Address":"Đối diện 9, đường  Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70063019,10.79127979] ; [106.70249939,10.78956985] ; [106.70352936,10.78861046] ; [106.70334625,10.78841972] ; [106.70256805,10.78761005] ; [106.70207977,10.78709984]"
    ,"Distance":"665"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"371"
    ,"Station_Code":"Q1 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"nhà thờ Mạc Ti Nho"
    ,"Station_Address":"16A, đường Nguyễn Thị Minh Khai, Quận  1"
    ,"Lat":10.786397
    ,"Long":106.701294
    ,"Polyline":"[106.70207977,10.78709984] ; [106.70136261,10.78633976]"
    ,"Distance":"115"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"237"
    ,"Station_Code":"Q1 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"115Bis, đường Hai Bà Trưng , Quận 1"
    ,"Lat":10.779385
    ,"Long":106.701744
    ,"Polyline":"[106.70136261,10.78633976] ; [106.70050812,10.78544998] ; [106.69966125,10.78454018] ; [106.70120239,10.78316975] ; [106.70043182,10.78236961] ; [106.69959259,10.78149033] ; [106.70184326,10.77947998]"
    ,"Distance":"1089"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"238"
    ,"Station_Code":"Q1 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà Hát Thành Phố"
    ,"Station_Address":"101, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.777873
    ,"Long":106.70351
    ,"Polyline":"[106.70184326,10.77947998] ; [106.70368195,10.77779961]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"239"
    ,"Station_Code":"Q1 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"Đối diện 2, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.775807
    ,"Long":106.705734
    ,"Polyline":"[106.70368195,10.77779961] ; [106.70583344,10.77591038]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70583344,10.77591038] ; [106.70606995,10.77569008] ; [106.70603943,10.77565956] ; [106.70600128,10.77560997] ; [106.70594025,10.77550030] ; [106.70590210,10.77538967] ; [106.70588684,10.77530003] ; [106.70590973,10.77513027] ; [106.70599365,10.77497005] ; [106.70613098,10.77484035] ; [106.70619202,10.77478981] ; [106.70629883,10.77474976] ; [106.70644379,10.77474976] ; [106.70648956,10.77476025] ; [106.70658112,10.77460003] ; [106.70646667,10.77322006]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84, đường Hàm Nghi, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70635986,10.77329922] ; [106.70633698,10.77196980] ; [106.70632935,10.77149963] ; [106.70623779,10.77079964] ; [106.70545197,10.77081966] ; [106.70317078,10.77093029] ; [106.70302582,10.77097988]"
    ,"Distance":"631"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường H àm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70302582,10.77097988] ; [106.70302582,10.77097988] ; [106.70281982,10.77097511] ; [106.70269012,10.77099037] ; [106.70166016,10.77104759] ; [106.70166016,10.77104759]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70166016,10.77104759] ; [106.69935608,10.77116299]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"118"
    ,"Station_Code":"Q1TC1B"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bến Thành B"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77084
    ,"Long":106.698532
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69934845,10.77112007] ; [106.69915009,10.77112484] ; [106.69898987,10.77094555] ; [106.69853210,10.77083969]"
    ,"Distance":"105"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"120"
    ,"Station_Code":"Q1 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường Ernst  Thalmann"
    ,"Station_Address":"8, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768772
    ,"Long":106.695923
    ,"Polyline":"[106.69856262,10.77077961] ; [106.69744873,10.77035046] ; [106.69714355,10.76998997] ; [106.69642639,10.76920986] ; [106.69599152,10.76871014]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"121"
    ,"Station_Code":"Q1 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"10, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767363
    ,"Long":106.694695
    ,"Polyline":"[106.69592285,10.76877213] ; [106.69592285,10.76877213] ; [106.69599152,10.76871014] ; [106.69474792,10.76731968] ; [106.69469452,10.76736259] ; [106.69469452,10.76736259]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"122"
    ,"Station_Code":"Q1 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Rạp Hưng Đạo"
    ,"Station_Address":"112, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765832
    ,"Long":106.693375
    ,"Polyline":"[106.69469452,10.76736259] ; [106.69469452,10.76736259] ; [106.69474792,10.76731968] ; [106.69344330,10.76578045] ; [106.69337463,10.76583195] ; [106.69337463,10.76583195]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2976"
    ,"Station_Code":"Q1 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nguyễn  Cư Trinh"
    ,"Station_Address":"34 - 36, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.76471
    ,"Long":106.691933
    ,"Polyline":"[106.69337463,10.76583195] ; [106.69344330,10.76578045] ; [106.69265747,10.76488972] ; [106.69193268,10.76471043]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2973"
    ,"Station_Code":"Q1 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Cống Quỳnh"
    ,"Station_Address":"118, đường Nguy ễn Cư Trinh, Quận 1"
    ,"Lat":10.763884
    ,"Long":106.689842
    ,"Polyline":"[106.69193268,10.76471043] ; [106.69106293,10.76430988] ; [106.69072723,10.76422024] ; [106.69023132,10.76395988] ; [106.68984222,10.76388359]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2975"
    ,"Station_Code":"Q1 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"184, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.763081
    ,"Long":106.687935
    ,"Polyline":"[106.68984222,10.76388359] ; [106.68937683,10.76365471] ; [106.68888855,10.76346016] ; [106.68793488,10.76308060]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1021"
    ,"Station_Code":"Q1 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Nguyễn Tr ãi"
    ,"Station_Address":"Đối diện số 205 - 207, đư ờng Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.760314
    ,"Long":106.683769
    ,"Polyline":"[106.68793488,10.76308060] ; [106.68795776,10.76303005] ; [106.68682098,10.76255035] ; [106.68656158,10.76245022] ; [106.68588257,10.76130009] ; [106.68524170,10.76016998] ; [106.68495941,10.75986958] ; [106.68486023,10.75979042] ; [106.68399048,10.75940037] ; [106.68376923,10.76031399]"
    ,"Distance":"733"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"426"
    ,"Station_Code":"Q5 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Đại học Sư Phạm"
    ,"Station_Address":"280, đường An  Dương Vương, Quận 5"
    ,"Lat":10.76103
    ,"Long":106.68267
    ,"Polyline":"[106.68376923,10.76031399] ; [106.68334961,10.76117039] ; [106.68268585,10.76096058]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"429"
    ,"Station_Code":"Q5 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"370, đường An Dương Vương, Quận 5"
    ,"Lat":10.759407
    ,"Long":106.678764
    ,"Polyline":"[106.68268585,10.76096058] ; [106.68268585,10.76096058] ; [106.67877197,10.75938129] ; [106.67877197,10.75938129]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"427"
    ,"Station_Code":"Q5 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Huỳnh M ẫn Đạt"
    ,"Station_Address":"526, đường An Dương Vương, Quận 5"
    ,"Lat":10.757984
    ,"Long":106.675272
    ,"Polyline":"[106.67877197,10.75938129] ; [106.67877197,10.75938129] ; [106.67867279,10.75933838] ; [106.67813110,10.75911045] ; [106.67580414,10.75820065] ; [106.67552185,10.75808430] ; [106.67527008,10.75799942] ; [106.67527008,10.75799942]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2843"
    ,"Station_Code":"Q5 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bệnh viện 30/4"
    ,"Station_Address":"Đối diện 9, đường Sư Vạn Hạnh, Quận 5"
    ,"Lat":10.75801
    ,"Long":106.673797
    ,"Polyline":"[106.67529297,10.75794029] ; [106.67413330,10.75755024] ; [106.67411804,10.75755978] ; [106.67410278,10.75757980] ; [106.67404175,10.75759983] ; [106.67398834,10.75757980] ; [106.67395020,10.75753975] ; [106.67395020,10.75751972] ; [106.67388153,10.75749016] ; [106.67375183,10.75800037]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2978"
    ,"Station_Code":"Q10 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trường CĐ sư phạm TW thành phố"
    ,"Station_Address":"184, đường Nguyễn  Chí Thanh, Quận 10"
    ,"Lat":10.760277
    ,"Long":106.670578
    ,"Polyline":"[106.67375183,10.75800037] ; [106.67326355,10.76012039] ; [106.67311859,10.76076031] ; [106.67286682,10.76070976] ; [106.67059326,10.76023960]"
    ,"Distance":"605"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"389"
    ,"Station_Code":"Q10 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Nguyễn Tiểu La"
    ,"Station_Address":"292, đường Nguyễn Chí Thanh, Quận 10"
    ,"Lat":10.759739
    ,"Long":106.667976
    ,"Polyline":"[106.67057800,10.76027679] ; [106.66902924,10.75992966] ; [106.66902161,10.75994968] ; [106.66898346,10.75998020] ; [106.66893005,10.76000023] ; [106.66886902,10.76000023] ; [106.66877747,10.75994015] ; [106.66876221,10.75990009] ; [106.66797638,10.75973892]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"392"
    ,"Station_Code":"Q10 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngô Quyền"
    ,"Station_Address":"440, đường Nguyễn Chí Thanh, Quận 10"
    ,"Lat":10.759228
    ,"Long":106.665171
    ,"Polyline":"[106.66797638,10.75973892] ; [106.66797638,10.75973034] ; [106.66630554,10.75944710]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"391"
    ,"Station_Code":"Q10 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Nhà máy bia sài gòn"
    ,"Station_Address":"Đối diện nhà máy bia Sài Gòn, đường Nguyễn Chí Thanh, Quận 10"
    ,"Lat":10.759078
    ,"Long":106.66452
    ,"Polyline":"[106.66630554,10.75944710.06.66452026]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"393"
    ,"Station_Code":"Q11 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"BV Răng Hàm Mặt"
    ,"Station_Address":"598, đường Nguyễn Chí Thanh , Quận 11"
    ,"Lat":10.758364
    ,"Long":106.660828
    ,"Polyline":"[106.66452026,10.75907803] ; [106.66274261,10.75866032] ; [106.66149139,10.75844955] ; [106.66082764,10.75836372]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"279"
    ,"Station_Code":"Q5 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"Đối diện 59C, đường Thuận Kiều, Quận 5"
    ,"Lat":10.757109
    ,"Long":106.65839
    ,"Polyline":"[106.66082764,10.75836372] ; [106.65960693,10.75804234] ; [106.65827942,10.75778961] ; [106.65834045,10.75710964] ; [106.65834045,10.75711060]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"395"
    ,"Station_Code":"Q5 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"Đối diện 30-32 , đường Thuận Kiều, Quận 5"
    ,"Lat":10.755381
    ,"Long":106.658369
    ,"Polyline":"[106.65834045,10.75711060] ; [106.65834045,10.75710964] ; [106.65840149,10.75646019] ; [106.65840912,10.75580025] ; [106.65834045,10.75537205]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"397"
    ,"Station_Code":"Q5 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"81, đường Châu V ăn Liêm, Quận 5"
    ,"Lat":10.752445
    ,"Long":106.658792
    ,"Polyline":"[106.65834045,10.75537205] ; [106.65843964,10.75463009] ; [106.65840149,10.75444984] ; [106.65837097,10.75434017] ; [106.65849304,10.75378990] ; [106.65878296,10.75296974] ; [106.65880585,10.75244522]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.65880585,10.75244522] ; [106.65881348,10.75234509] ; [106.65887451,10.75204468] ; [106.65890503,10.75182343] ; [106.65893555,10.75155449] ; [106.65888214,10.75137997]"
    ,"Distance":"121"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"617"
    ,"Station_Code":"Q8 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"388, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.74483
    ,"Long":106.656926
    ,"Polyline":"[106.65888214,10.75137997] ; [106.65897369,10.75118065] ; [106.65905762,10.75084972] ; [106.65904236,10.75069046] ; [106.65909576,10.75060081] ; [106.65918732,10.75058460] ; [106.65926361,10.75060558] ; [106.65971375,10.75045967] ; [106.65985870,10.75035954] ; [106.65991974,10.75024986] ; [106.66014099,10.74962044] ; [106.66037750,10.74890041] ; [106.66050720,10.74841976] ; [106.66052246,10.74827957] ; [106.66052246,10.74806023] ; [106.66042328,10.74730968] ; [106.66036987,10.74703979] ; [106.66031647,10.74699020] ; [106.66024017,10.74695969] ; [106.66010284,10.74695015] ; [106.65994263,10.74693012] ; [106.65984344,10.74685001] ; [106.65956879,10.74660969] ; [106.65921783,10.74625969] ; [106.65902710,10.74600983] ; [106.65888214,10.74577999] ; [106.65854645,10.74563980] ; [106.65705872,10.74479961] ; [106.65664673,10.74456978] ; [106.65661621,10.74462128]"
    ,"Distance":"1074"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"618"
    ,"Station_Code":"Q8 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Chùa Pháp Quang"
    ,"Station_Address":"100, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738642
    ,"Long":106.656142
    ,"Polyline":"[106.65664673,10.74456978] ; [106.65602112,10.74423981] ; [106.65577698,10.74403954] ; [106.65567017,10.74392033] ; [106.65554047,10.74370003] ; [106.65541840,10.74337959] ; [106.65538788,10.74310017] ; [106.65545654,10.74271011] ; [106.65560150,10.74232006] ; [106.65605927,10.74118996] ; [106.65612030,10.74098015] ; [106.65618896,10.74079037] ; [106.65627289,10.74055958] ; [106.65628815,10.74038982] ; [106.65618896,10.73954010.06.65612793] ; [10.73927021,106.65612793] ; [10.73919010.06.65617371,10.73906040] ; [106.65619659,10.73863983]"
    ,"Distance":"751"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"619"
    ,"Station_Code":"Q8 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"224, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656126
    ,"Polyline":"[106.65618896,10.73864460] ; [106.65620422,10.73618889]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Bến xe Qu ận 8"
    ,"Station_Address":"GA  HKXB QUẬN 8, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":"[106.65620422,10.73618889] ; [106.65621948,10.73653984] ; [106.65615082,10.73353958] ; [106.65615082,10.73323441] ; [106.65630341,10.73327637] ; [106.65664673,10.73335075] ; [106.65663910,10.73363209]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Qu ận 8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"502"
    ,"Station_Code":"Q8 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"193, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656346
    ,"Polyline":"[106.65615082,10.73363972] ; [106.65621185,10.73606968]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"499"
    ,"Station_Code":"Q8 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Nhị Thi ên Đường"
    ,"Station_Address":"81, đường Quốc  lộ 50, Quận 8"
    ,"Lat":10.738769
    ,"Long":106.656427
    ,"Polyline":"[106.65621185,10.73606968] ; [106.65628815,10.73882961]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"542"
    ,"Station_Code":"Q8 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"487, đường T ùng Thiện Vương, Quận 8"
    ,"Lat":10.744513
    ,"Long":106.656802
    ,"Polyline":"[106.65628815,10.73882961] ; [106.65628815,10.73923969] ; [106.65638733,10.74069023] ; [106.65635681,10.74090958] ; [106.65622711,10.74122047] ; [106.65585327,10.74217033] ; [106.65570831,10.74260998] ; [106.65558624,10.74295044] ; [106.65554810,10.74326038] ; [106.65557861,10.74351978] ; [106.65567780,10.74376965] ; [106.65579987,10.74396992] ; [106.65583801,10.74407005] ; [106.65602112,10.74423981] ; [106.65647888,10.74448013]"
    ,"Distance":"690"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"501"
    ,"Station_Code":"Q8 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Xóm Củi"
    ,"Station_Address":"337, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.746073
    ,"Long":106.659763
    ,"Polyline":"[106.65647888,10.74448013] ; [106.65854645,10.74563980] ; [106.65904999,10.74584961] ; [106.65960693,10.74612045]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bưu điện  Quận 5"
    ,"Station_Address":"14-16, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65960693,10.74612045] ; [106.66024780,10.74643993] ; [106.66036224,10.74650955] ; [106.66045380,10.74662971] ; [106.66059875,10.74779987] ; [106.66062927,10.74816990] ; [106.66062164,10.74831009] ; [106.66056824,10.74868011] ; [106.66046143,10.74899960] ; [106.66005707,10.75010967] ; [106.66007233,10.75022030] ; [106.66011810,10.75030994] ; [106.66021729,10.75037956] ; [106.66040039,10.75045967] ; [106.66056061,10.75055981] ; [106.66060638,10.75063992] ; [106.66110229,10.75092030] ; [106.66133881,10.75100994] ; [106.66150665,10.75104046] ; [106.66149902,10.75119972] ; [106.66127014,10.75113010.06.66092682] ; [10.75098038,106.66050720] ; [10.75072002,106.66026306] ; [10.75057030,106.66011810] ; [10.75053024,106.65998077] ; [10.75053024,106.65986633] ; [10.75055027,106.65966034] ; [10.75063038,106.65926361] ; [10.75078964,106.65924835] ; [10.75082016,106.65920258] ; [10.75086975,106.65917206] ; [10.75088024,106.65911102]"
    ,"Distance":"1062"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"5"
    ,"Station_Code":"Q5 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"68, đường Châu V ăn Liêm, Quận 5"
    ,"Lat":10.752566
    ,"Long":106.658937
    ,"Polyline":"[106.65911102,10.75135994] ; [106.65904999,10.75183010.06.65895081] ; [10.75201035,106.65885162]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"279"
    ,"Station_Code":"Q5 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"Đối diện 59C, đường Thuận Kiều, Quận 5"
    ,"Lat":10.757109
    ,"Long":106.65839
    ,"Polyline":"[106.65885162,10.75255013] ; [106.65878296,10.75296974] ; [106.65849304,10.75378990] ; [106.65837097,10.75434017] ; [106.65840149,10.75444984] ; [106.65843964,10.75463009] ; [106.65840912,10.75580025] ; [106.65840149,10.75646019] ; [106.65834045,10.75710964]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"281"
    ,"Station_Code":"Q5 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"201A, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758079
    ,"Long":106.660128
    ,"Polyline":"[106.65834045,10.75710964] ; [106.65827942,10.75778961] ; [106.65953064,10.75802994] ; [106.66010284,10.75815010]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"282"
    ,"Station_Code":"Q5 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Lý Thường Kiệt"
    ,"Station_Address":"195B , đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758443
    ,"Long":106.662006
    ,"Polyline":"[106.66010284,10.75815010.06.66062164] ; [10.75825977,106.66149139] ; [10.75844955,106.66195679]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"283"
    ,"Station_Code":"Q5 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chung cư 155  Nguyễn Chí Thanh"
    ,"Station_Address":"153-155, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.759281
    ,"Long":106.666056
    ,"Polyline":"[106.66195679,10.75852966] ; [106.66274261,10.75866032] ; [106.66557312,10.75924969] ; [106.66605377,10.75934029]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"284"
    ,"Station_Code":"Q5 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường Kinh tế Công nghệ"
    ,"Station_Address":"131, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.759649
    ,"Long":106.668019
    ,"Polyline":"[106.66605377,10.75934029] ; [106.66800690,10.75973988]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2969"
    ,"Station_Code":"Q5 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ký túc xá Đại học Kinh tế"
    ,"Station_Address":"43, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.760477
    ,"Long":106.672016
    ,"Polyline":"[106.66800690,10.75973988] ; [106.66876221,10.75990009] ; [106.66874695,10.75988007] ; [106.66876221,10.75981998] ; [106.66883087,10.75973034] ; [106.66893005,10.75971985] ; [106.66902161,10.75977993] ; [106.66905212,10.75983047] ; [106.66903687,10.75990009] ; [106.66902924,10.75992966] ; [106.67108154,10.76033020] ; [106.67199707,10.76053047]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2844"
    ,"Station_Code":"Q5 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Bệnh viện 30/4"
    ,"Station_Address":"9, đường Sư Vạn H ạnh, Quận 5"
    ,"Lat":10.758147
    ,"Long":106.673652
    ,"Polyline":"[106.67199707,10.76053047] ; [106.67311859,10.76076031] ; [106.67333221,10.75979042] ; [106.67371368,10.75817013]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"466"
    ,"Station_Code":"Q5 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"439, đường An Dương Vương, Quận 5"
    ,"Lat":10.758374
    ,"Long":106.676576
    ,"Polyline":"[106.67371368,10.75817013] ; [106.67388153,10.75749016] ; [106.67395020,10.75751019] ; [106.67395020,10.75749969] ; [106.67395020,10.75747967] ; [106.67397308,10.75745964] ; [106.67401123,10.75741959] ; [106.67407227,10.75741959] ; [106.67411804,10.75745964] ; [106.67414093,10.75751972] ; [106.67413330,10.75753021] ; [106.67413330,10.75753975] ; [106.67575836,10.75811005] ; [106.67645264,10.75841045]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"472"
    ,"Station_Code":"Q5 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"373, đường An Dương Vương , Quận 5"
    ,"Lat":10.759138
    ,"Long":106.678453
    ,"Polyline":"[106.67645264,10.75841045] ; [106.67764282,10.75893021] ; [106.67813110,10.75911045] ; [106.67829895,10.75916958]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"467"
    ,"Station_Code":"Q5 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Đại học Sài Gòn"
    ,"Station_Address":"273-275 , đường An Dương Vương, Quận 5"
    ,"Lat":10.760735
    ,"Long":106.682289
    ,"Polyline":"[106.67829895,10.75916958] ; [106.67920685,10.75951004] ; [106.68013000,10.75986958] ; [106.68226624,10.76074982]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1051"
    ,"Station_Code":"Q5 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bộ Công an"
    ,"Station_Address":"211-213, đường Nguyễn Văn Cừ, Quận 5"
    ,"Lat":10.760672
    ,"Long":106.683453
    ,"Polyline":"[106.68226624,10.76074982] ; [106.68334961,10.76117039] ; [106.68351746,10.76070023]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1052"
    ,"Station_Code":"Q1 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Báo An Ninh  Thế Giới"
    ,"Station_Address":"371A, đường Nguy ễn Trãi, Quận 1"
    ,"Lat":10.759869
    ,"Long":106.685104
    ,"Polyline":"[106.68351746,10.76070023] ; [106.68399048,10.75940037] ; [106.68469238,10.75969982] ; [106.68492889,10.75984001] ; [106.68501282,10.75990963] ; [106.68509674,10.75984955]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1053"
    ,"Station_Code":"Q1 151"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà Khách Bộ Công An"
    ,"Station_Address":"333, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.762006
    ,"Long":106.686394
    ,"Polyline":"[106.68509674,10.75984955] ; [106.68501282,10.75990963] ; [106.68515015,10.76006031] ; [106.68537903,10.76039982] ; [106.68588257,10.76130009] ; [106.68631744,10.76204967]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2974"
    ,"Station_Code":"Q1 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"173  - 173B, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.76303
    ,"Long":106.688217
    ,"Polyline":"[106.68631744,10.76204967] ; [106.68656158,10.76245022] ; [106.68682098,10.76255035] ; [106.68759918,10.76288033] ; [106.68817902,10.76311970]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"2971"
    ,"Station_Code":"Q1 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trần H ưng Đạo"
    ,"Station_Address":"37, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.764468
    ,"Long":106.69178
    ,"Polyline":"[106.68817902,10.76311970] ; [106.68875885,10.76334953] ; [106.69074249,10.76418018] ; [106.69174194,10.76455975]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"25"
    ,"Station_Code":"Q1 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Rạp Trần Hưng Đạo"
    ,"Station_Address":"227 - 229, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765213
    ,"Long":106.693069
    ,"Polyline":"[106.69174194,10.76455975] ; [106.69265747,10.76488972] ; [106.69300079,10.76527023]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"26"
    ,"Station_Code":"Q1 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"135, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767064
    ,"Long":106.694824
    ,"Polyline":"[106.69300079,10.76527023] ; [106.69465637,10.76720047]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"27"
    ,"Station_Code":"Q1 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"71C, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768327
    ,"Long":106.695847
    ,"Polyline":"[106.69465637,10.76720047] ; [106.69523621,10.76791954] ; [106.69532776,10.76797962] ; [106.69573975,10.76842022]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69573975,10.76842022] ; [106.69744873,10.77035046] ; [106.69753265,10.77021980] ; [106.69843292,10.77056980]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69843292,10.77056980] ; [106.69907379,10.77081966] ; [106.69899750,10.77095032] ; [106.69956207,10.77093029]"
    ,"Distance":"152"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77093029] ; [106.70192719,10.77085972]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Hồ Tùng  Mậu"
    ,"Station_Address":"67, đường Hàm Nghi , Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70192719,10.77085972] ; [106.70417023,10.77075958]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"Bến thủy nội địa Thủ Thiêm , đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70417023,10.77075958] ; [106.70461273,10.77073002] ; [106.70455933,10.77058983] ; [106.70513153,10.76945972] ; [106.70516205,10.76939011] ; [106.70529175,10.76941967] ; [106.70593262,10.76953983] ; [106.70606995,10.76959991] ; [106.70616150,10.76972961] ; [106.70639038,10.77054977] ; [106.70635986,10.77071953] ; [106.70630646,10.77134037] ; [106.70632935,10.77157021] ; [106.70635223,10.77178955] ; [106.70652008,10.77388954]"
    ,"Distance":"801"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"34"
    ,"Station_Code":"Q1 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"2, đường Hai  Bà Trưng, Quận 1"
    ,"Lat":10.776048
    ,"Long":106.705719
    ,"Polyline":"[106.70652008,10.77388954] ; [106.70658112,10.77460003] ; [106.70667267,10.77488041] ; [106.70671844,10.77563953] ; [106.70661926,10.77577972] ; [106.70652771,10.77583027] ; [106.70635223,10.77583027] ; [106.70619965,10.77577972] ; [106.70610046,10.77571011] ; [106.70606995,10.77569008] ; [106.70570374,10.77602005]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"42"
    ,"Station_Code":"Q1 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Nhà Hát Thành Phố"
    ,"Station_Address":"74/A2-74/A4, đường Hai Bà Trưng, Quận  1"
    ,"Lat":10.778031
    ,"Long":106.703559
    ,"Polyline":"[106.70570374,10.77602005] ; [106.70349884,10.77795982]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"44"
    ,"Station_Code":"Q1 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"Đối diện 115Ter, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.779881
    ,"Long":106.701536
    ,"Polyline":"[106.70349884,10.77795982] ; [106.70147705,10.77980042]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"39"
    ,"Station_Code":"Q1 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Bưu Điện Thành Phố"
    ,"Station_Address":"86, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.780645
    ,"Long":106.700673
    ,"Polyline":"[106.70155334,10.77987862] ; [106.70067596,10.78061485]"
    ,"Distance":"131"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"294"
    ,"Station_Code":"Q1 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Mạc Đỉnh Chi"
    ,"Station_Address":"21, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.784191
    ,"Long":106.699503
    ,"Polyline":"[106.70067596,10.78064537] ; [106.69962311,10.78158283] ; [106.69829559,10.78272152] ; [106.69811249,10.78287888] ; [106.69877625,10.78358555] ; [106.69949341,10.78423500]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"296"
    ,"Station_Code":"Q1 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Đinh Tiên Hoàng"
    ,"Station_Address":"15C-15D, đường Nguyễn Thị Minh Khai, Qu ận 1"
    ,"Lat":10.786146
    ,"Long":106.70137
    ,"Polyline":"[106.69949341,10.78423500] ; [106.69949341,10.78423500] ; [106.70042419,10.78524494] ; [106.70135498,10.78616714] ; [106.70135498,10.78616714]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"730"
    ,"Station_Code":"QBTH 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Điện Biên Phủ"
    ,"Station_Address":"84, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.794815
    ,"Long":106.702223
    ,"Polyline":"[106.70127106,10.78625011] ; [106.70334625,10.78841972] ; [106.70352936,10.78861046] ; [106.70249939,10.78956985] ; [106.70127106,10.79069996] ; [106.70011902,10.79174042] ; [106.69970703,10.79211044] ; [106.69959259,10.79222965] ; [106.69963074,10.79224968] ; [106.69970703,10.79232979] ; [106.69975281,10.79242992] ; [106.69975281,10.79249001] ; [106.69992065,10.79263973] ; [106.70124054,10.79401016]"
    ,"Distance":"1374"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1916"
    ,"Station_Code":"QBTH 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm Điện Nguyễn Cửu Vân"
    ,"Station_Address":"174, đường Điện Biên Phủ, Qu ận Bình Thạnh"
    ,"Lat":10.797286
    ,"Long":106.704567
    ,"Polyline":"[106.70222473,10.79481506] ; [106.70328522,10.79614830] ; [106.70456696,10.79728603]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1918"
    ,"Station_Code":"QBTH 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Đại học Hồng Bàng"
    ,"Station_Address":"330, đường  Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799505
    ,"Long":106.70689
    ,"Polyline":"[106.70456696,10.79728603] ; [106.70588684,10.79885960] ; [106.70688629,10.79950523]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1925"
    ,"Station_Code":"QBTH 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Vòng xoay  Hàng Xanh"
    ,"Station_Address":"442, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.80108
    ,"Long":106.710269
    ,"Polyline":"[106.70688629,10.79950523] ; [106.70722198,10.79988003] ; [106.70823669,10.80045986] ; [106.70861816,10.80064011] ; [106.70899963,10.80078983] ; [106.70964050,10.80099964] ; [106.70983124,10.80103970] ; [106.71026611,10.80107975]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Vi ết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71026611,10.80107975] ; [106.70983124,10.80103970] ; [106.71054840,10.80115986] ; [106.71125031,10.80126953] ; [106.71132660,10.80123997] ; [106.71138763,10.80125046] ; [106.71147919,10.80128956] ; [106.71151733,10.80136013] ; [106.71154022,10.80144978] ; [106.71150208,10.80152988] ; [106.71144104,10.80158043] ; [106.71137238,10.80160999] ; [106.71132660,10.80160999] ; [106.71137238,10.80249977] ; [106.71140289,10.80298042] ; [106.71145630,10.80453014] ; [106.71154022,10.80474758]"
    ,"Distance":"634"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Th ạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71147919,10.80471039] ; [106.71151733,10.80535984] ; [106.71154022,10.80655003] ; [106.71154022,10.80681992] ; [106.71156311,10.80747032] ; [106.71161652,10.80797005] ; [106.71167755,10.80821037] ; [106.71177673,10.80848980] ; [106.71190643,10.80883980] ; [106.71198273,10.80906963]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71215820,10.80955029] ; [106.71228790,10.81021976] ; [106.71240997,10.81079102]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"522"
    ,"Station_Code":"QBTH 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"100-102, đường Quốc lộ 13, Quận Bình Th ạnh"
    ,"Lat":10.811666
    ,"Long":106.712532
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71244049,10.81123924] ; [106.71253204,10.81166553]"
    ,"Distance":"99"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128, đường Quốc lộ 13 , Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71253204,10.81166553] ; [106.71253204,10.81200314] ; [106.71260834,10.81231976]"
    ,"Distance":"74"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71260834,10.81231976] ; [106.71262360,10.81297302] ; [106.71267700,10.81343651] ; [106.71279144,10.81385326]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71293640,10.81564045] ; [106.71305084,10.81651974] ; [106.71318054,10.81737041] ; [106.71308136,10.81737995] ; [106.71288300,10.81739044] ; [106.71269989,10.81735992] ; [106.71225739,10.81723976] ; [106.71196747,10.81715012] ; [106.71172333,10.81700039] ; [106.71150208,10.81682014] ; [106.71125793,10.81666088]"
    ,"Distance":"625"
  },
  {
     "Route_Id":"66"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh,  Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71128845,10.81663990] ; [106.71118927,10.81653786] ; [106.71108246,10.81636906] ; [106.71044159,10.81512260] ; [106.70987701,10.81399250] ; [106.71009064,10.81390858] ; [106.71020508,10.81397915] ; [106.71073914,10.81503010]"
    ,"Distance":"577"
  }]