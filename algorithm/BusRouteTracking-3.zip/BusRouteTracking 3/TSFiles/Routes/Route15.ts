export const Route15 =[
  {
     "Route_Id":"15"
    ,"Station_Id":"394"
    ,"Station_Code":"BX73"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Bến xe buýt ĐH Nông Lâm, đường Quốc lộ 1 , Quận Thủ Đức"
    ,"Lat":10.868183135986328
    ,"Long":106.78744506835938
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1101"
    ,"Station_Code":"QTD 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"Kế 21, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867404
    ,"Long":106.787265
    ,"Polyline":"[106.78778076,10.86812019] ; [106.78777313,10.86791992] ; [106.78781891,10.86777973] ; [106.78798676,10.86765003] ; [106.78820801,10.86746025] ; [106.78827667,10.86736965] ; [106.78829956,10.86725998] ; [106.78669739,10.86732006]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1102"
    ,"Station_Code":"QTD 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty điện tử Samsung"
    ,"Station_Address":"Kế 59/6, đường Quốc lộ 1,  Quận Thủ Đức"
    ,"Lat":10.867867
    ,"Long":106.782201
    ,"Polyline":"[106.78669739,10.86732006] ; [106.78428650,10.86742020] ; [106.78352356,10.86748028] ; [106.78308105,10.86754990] ; [106.78215790,10.86777020]"
    ,"Distance":"500"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1103"
    ,"Station_Code":"QTD 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Đại học Kinh tế -Luật"
    ,"Station_Address":"Đại học Kinh  tế -Luật, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.869274
    ,"Long":106.777909
    ,"Polyline":"[106.78215790,10.86777020] ; [106.77870941,10.86888027] ; [106.77787018,10.86915016]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1104"
    ,"Station_Code":"QTD 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Đường số  14"
    ,"Station_Address":"Tr ụ  điện NB55, đường Đường số 14, Quận Thủ Đức"
    ,"Lat":10.861588
    ,"Long":106.772079
    ,"Polyline":"[106.77787018,10.86915016] ; [106.77601624,10.86975956] ; [106.77561188,10.86890030] ; [106.77493286,10.86760044] ; [106.77481842,10.86746025] ; [106.77249146,10.86235046] ; [106.77213287,10.86155987]"
    ,"Distance":"1221"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1105"
    ,"Station_Code":"QTD 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã ba đ ường 14"
    ,"Station_Address":"Trụ điện SB61, đường Đường số 6, Quận Thủ Đức"
    ,"Lat":10.861013
    ,"Long":106.770689
    ,"Polyline":"[106.77207947,10.86158752] ; [106.77175903,10.86075974] ; [106.77069092,10.86101341]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1106"
    ,"Station_Code":"QTD 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã ba Linh Trung đường số 6"
    ,"Station_Address":"Đối diện 94, đường Đường s ố 6, Quận Thủ Đức"
    ,"Lat":10.860602
    ,"Long":106.767921
    ,"Polyline":"[106.77069092,10.86101341] ; [106.77069092,10.86101341] ; [106.77026367,10.86106586] ; [106.76973724,10.86111832] ; [106.76924896,10.86112976] ; [106.76876068,10.86106968] ; [106.76812744,10.86068153] ; [106.76792145,10.86060238] ; [106.76792145,10.86060238]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1107"
    ,"Station_Code":"QTD 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Tô Vĩnh Diện"
    ,"Station_Address":"198, đường Hoàng Diệu 2, Quận Thủ Đức"
    ,"Lat":10.854312
    ,"Long":106.768898
    ,"Polyline":"[106.76792145,10.86060238] ; [106.76778412,10.86043930] ; [106.76796722,10.86020184] ; [106.76825714,10.85974884] ; [106.76839447,10.85943794] ; [106.76838684,10.85927486] ; [106.76817322,10.85909081] ; [106.76775360,10.85878468] ; [106.76725006,10.85857391] ; [106.76674652,10.85836315] ; [106.76648712,10.85771561] ; [106.76624298,10.85700989] ; [106.76615906,10.85654545] ; [106.76628113,10.85627747] ; [106.76648712,10.85592937] ; [106.76684570,10.85554981] ; [106.76787567,10.85496521] ; [106.76840973,10.85464954] ; [106.76867676,10.85449600] ; [106.76889801,10.85431194]"
    ,"Distance":"992"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1109"
    ,"Station_Code":"QTD 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã ba L ê Văn Chí"
    ,"Station_Address":"Đối diện 233, đường Hoàng Diệu 2, Quận Thủ Đức"
    ,"Lat":10.854164
    ,"Long":106.772385
    ,"Polyline":"[106.76891327,10.85435009] ; [106.76969910,10.85416031] ; [106.77011871,10.85410976] ; [106.77072144,10.85408974] ; [106.77097321,10.85406017] ; [106.77149200,10.85394955] ; [106.77174377,10.85396957] ; [106.77236176,10.85422039]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1108"
    ,"Station_Code":"QTD 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà máy nước Thủ Đức"
    ,"Station_Address":"Đối diện Nhà máy nước Thủ Đức, đường Lê Văn Chí, Quận Thủ Đức"
    ,"Lat":10.853545
    ,"Long":106.773216
    ,"Polyline":"[106.77236176,10.85422039] ; [106.77258301,10.85431957] ; [106.77292633,10.85443020] ; [106.77297974,10.85424995] ; [106.77306366,10.85394955] ; [106.77327728,10.85358047]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1110"
    ,"Station_Code":"QTD 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"ĐH Sư Phạm Kỹ Thuật"
    ,"Station_Address":"Đối diện 111 /4, đường Lê Văn Chí, Quận Thủ Đức"
    ,"Lat":10.850766
    ,"Long":106.773994
    ,"Polyline":"[106.77327728,10.85358047] ; [106.77404022,10.85237026] ; [106.77433777,10.85186958] ; [106.77436829,10.85173988] ; [106.77438354,10.85161972] ; [106.77435303,10.85142994] ; [106.77410889,10.85089016] ; [106.77404785,10.85074043]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1113"
    ,"Station_Code":"QTD 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã tư Th ủ Đức"
    ,"Station_Address":"Đối diện Coopmart, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.84828
    ,"Long":106.77299
    ,"Polyline":"[106.77404785,10.85074043] ; [106.77388000,10.85031986] ; [106.77380371,10.85015965] ; [106.77368164,10.84996986] ; [106.77336884,10.84957981] ; [106.77323914,10.84941006] ; [106.77330017,10.84934044] ; [106.77340698,10.84914017] ; [106.77345276,10.84897995] ; [106.77342224,10.84879971] ; [106.77340698,10.84871006] ; [106.77314758,10.84836006] ; [106.77310181,10.84827042]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1111"
    ,"Station_Code":"QTD 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Betong Hải Âu"
    ,"Station_Address":"Đối diện Betong Hải Âu, đường  Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.844297
    ,"Long":106.77063
    ,"Polyline":"[106.77310181,10.84827042] ; [106.77133942,10.84535027] ; [106.77044678,10.84377003]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1112"
    ,"Station_Code":"QTD 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"UBND Quận 9"
    ,"Station_Address":"126, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.840745
    ,"Long":106.768607
    ,"Polyline":"[106.77044678,10.84377003] ; [106.76873016,10.84070969]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"410"
    ,"Station_Code":"QTD 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Đối diện 592C, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.834945
    ,"Long":106.765244
    ,"Polyline":"[106.76873016,10.84070969] ; [106.76544952,10.83495045]"
    ,"Distance":"734"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"413"
    ,"Station_Code":"QTD 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Công ty truyền tải điện 4"
    ,"Station_Address":"Công ty truyền tải điện 4, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.831214
    ,"Long":106.763195
    ,"Polyline":"[106.76544952,10.83495045] ; [106.76335144,10.83117008]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"412"
    ,"Station_Code":"QTD 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"Nhà máy thép  Thủ Đức, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.825366
    ,"Long":106.759998
    ,"Polyline":"[106.76335144,10.83117008] ; [106.76077271,10.82660961] ; [106.76042175,10.82596970] ; [106.76006317,10.82534027]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"414"
    ,"Station_Code":"QTD 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Xi măng  Hà Tiên"
    ,"Station_Address":"Xi măng Hà Tiên 1, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.820576
    ,"Long":106.758142
    ,"Polyline":"[106.76006317,10.82534027] ; [106.75936127,10.82404041] ; [106.75901031,10.82326984] ; [106.75881958,10.82271957] ; [106.75849915,10.82153034] ; [106.75832367,10.82067966] ; [106.75824738,10.82028961]"
    ,"Distance":"599"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"415"
    ,"Station_Code":"Q2 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Đối diện Esstella, đường Xa Lộ Hà Nội, Qu ận 2"
    ,"Lat":10.802925
    ,"Long":106.747948
    ,"Polyline":"[106.75814056,10.82057571] ; [106.75708771,10.81532860] ; [106.75610352,10.81010151] ; [106.75592041,10.80940533] ; [106.75563812,10.80872059] ; [106.75491333,10.80733967] ; [106.75398254,10.80618095] ; [106.75343323,10.80556965] ; [106.75277710,10.80508518] ; [106.75159454,10.80427361] ; [106.75032043,10.80366230] ; [106.74913788,10.80324078] ; [106.74794769,10.80292511]"
    ,"Distance":"2452"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"416"
    ,"Station_Code":"Q2 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"655, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802134
    ,"Long":106.7434
    ,"Polyline":"[106.74796295,10.80286980] ; [106.74703217,10.80266953] ; [106.74620819,10.80251026] ; [106.74530792,10.80233955] ; [106.74463654,10.80222988] ; [106.74340820,10.80202007]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"417"
    ,"Station_Code":"Q2 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Ngã ba Thảo Điền , đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801309
    ,"Long":106.738762
    ,"Polyline":"[106.74340820,10.80202007] ; [106.74149323,10.80167007] ; [106.74060822,10.80146980] ; [106.73986816,10.80136013] ; [106.73879242,10.80115986]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"418"
    ,"Station_Code":"Q2 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"Đối diện Cầu Đen, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800451
    ,"Long":106.73436
    ,"Polyline":"[106.73879242,10.80115986] ; [106.73438263,10.80035019]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"419"
    ,"Station_Code":"QBTH 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"24(597), đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.79882
    ,"Long":106.719641
    ,"Polyline":"[106.73438263,10.80035019] ; [106.73294067,10.80004978] ; [106.73187256,10.79979992] ; [106.72416687,10.79837036] ; [106.72223663,10.79802990] ; [106.72196960,10.79800987] ; [106.72158051,10.79800034] ; [106.72128296,10.79804993] ; [106.72090149,10.79813957] ; [106.72048950,10.79827976] ; [106.72003937,10.79848003] ; [106.71987915,10.79856968] ; [106.71972656,10.79868984] ; [106.71945953,10.79881954]"
    ,"Distance":"1676"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"420"
    ,"Station_Code":"QBTH 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"152 /72c(559), đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.800153
    ,"Long":106.717442
    ,"Polyline":"[106.71945953,10.79881954] ; [106.71913147,10.79899025] ; [106.71864319,10.79930019] ; [106.71785736,10.79975033] ; [106.71719360,10.80008030]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường  Hutech"
    ,"Station_Address":"483, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71719360,10.80008030] ; [106.71645355,10.80043030] ; [106.71571350,10.80074024] ; [106.71513367,10.80097008] ; [106.71481323,10.80107975]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"419 , đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71485901,10.80122757] ; [106.71471405,10.80127525] ; [106.71443939,10.80134869] ; [106.71388245,10.80146503] ; [106.71343231,10.80159092] ; [106.71300507,10.80169678] ; [106.71281433,10.80164433] ; [106.71244812,10.80163860]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1114"
    ,"Station_Code":"QBTH 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã Ba  Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"18, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802998
    ,"Long":106.710441
    ,"Polyline":"[106.71244812,10.80163860] ; [106.71231842,10.80156040] ; [106.71192169,10.80169964] ; [106.71177673,10.80175972] ; [106.71166229,10.80185032] ; [106.71150970,10.80206013] ; [106.71137238,10.80249977] ; [106.71138763,10.80284023] ; [106.71114349,10.80286026] ; [106.71045685,10.80290985] ; [106.71044159,10.80299759]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.71044159,10.80299759] ; [106.70935059,10.80296993] ; [106.70844269,10.80305004] ; [106.70803070,10.80317688]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70797729,10.80307961] ; [106.70393372,10.80338955]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"288, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70393372,10.80338955] ; [106.70324707,10.80346012] ; [106.70278168,10.80356026] ; [106.70172882,10.80383968] ; [106.70149231,10.80385017] ; [106.70104980,10.80370045]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Chợ Bà  Chiểu"
    ,"Station_Address":"368, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70104218,10.80370235] ; [106.70104218,10.80368996] ; [106.69934082,10.80302238]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"UBND Qu ận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan  Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69924164,10.80296993] ; [106.69860077,10.80268002] ; [106.69795990,10.80245972] ; [106.69753265,10.80249977] ; [106.69599152,10.80268002] ; [106.69573212,10.80272007]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"594"
    ,"Station_Code":"QBTH 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"10, đường Phan Đăng Lưu, Quận Bình Th ạnh"
    ,"Lat":10.803088
    ,"Long":106.693586
    ,"Polyline":"[106.69573212,10.80272007] ; [106.69348145,10.80301952]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"593"
    ,"Station_Code":"QBTH 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Công an PCCC, Quận Bình Thạnh"
    ,"Station_Address":"14-16, đường  Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803362
    ,"Long":106.691473
    ,"Polyline":"[106.69358063,10.80300045] ; [106.69243622,10.80313015] ; [106.69143677,10.80327034]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"595"
    ,"Station_Code":"QPN 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bệnh viện Ph ước An"
    ,"Station_Address":"36A, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803894
    ,"Long":106.687535
    ,"Polyline":"[106.69143677,10.80327034] ; [106.68968964,10.80350018] ; [106.68791199,10.80370998] ; [106.68756866,10.80375004]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"596"
    ,"Station_Code":"QPN 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"68, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.804063
    ,"Long":106.686269
    ,"Polyline":"[106.68756866,10.80375004] ; [106.68601227,10.80395985]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"597"
    ,"Station_Code":"QPN 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"124, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802629
    ,"Long":106.683689
    ,"Polyline":"[106.68601227,10.80395985] ; [106.68576050,10.80399036] ; [106.68560028,10.80397987] ; [106.68544006,10.80395031] ; [106.68515778,10.80383015] ; [106.68492889,10.80364037] ; [106.68470764,10.80344963] ; [106.68376160,10.80249977]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"598"
    ,"Station_Code":"QPN 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"172, đường Phan Đăng Lưu, Quận Phú Nhu ận"
    ,"Lat":10.800854
    ,"Long":106.681833
    ,"Polyline":"[106.68376160,10.80249977] ; [106.68286133,10.80163956] ; [106.68202209,10.80080032]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"599"
    ,"Station_Code":"QPN 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"24, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.79931
    ,"Long":106.679354
    ,"Polyline":"[106.68202209,10.80080032] ; [106.68138885,10.80014992] ; [106.68048096,10.79924011] ; [106.68028259,10.79920006] ; [106.68000793,10.79918957] ; [106.67967987,10.79920959]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"601"
    ,"Station_Code":"QPN 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"202, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.800153
    ,"Long":106.669559
    ,"Polyline":"[106.67967987,10.79920959] ; [106.67832947,10.79928970] ; [106.67685699,10.79942989] ; [106.67536926,10.79955959] ; [106.67299652,10.79973030] ; [106.66980743,10.80000019]"
    ,"Distance":"1087"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu  7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66980743,10.80000019] ; [106.66771698,10.80020046] ; [106.66683960,10.80072021] ; [106.66658783,10.80090046]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"257"
    ,"Station_Code":"QTB 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Công vi ên Hoàng Văn Thụ"
    ,"Station_Address":"Công viên Hoàng Văn Thụ, đường Phan Th úc Duyện, Quận Tân Bình"
    ,"Lat":10.802403
    ,"Long":106.664221
    ,"Polyline":"[106.66662598,10.80095100] ; [106.66603851,10.80126953] ; [106.66596985,10.80132771] ; [106.66585541,10.80139065] ; [106.66416931,10.80236053]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Trần Qu ốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66416931,10.80236053] ; [106.66413879,10.80231953] ; [106.66355896,10.80266953] ; [106.66342163,10.80245972] ; [106.66260529,10.80168629] ; [106.66239929,10.80145454] ; [106.66230011,10.80137253]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"259"
    ,"Station_Code":"QTB 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Siêu thị Maximark Cộng Hòa"
    ,"Station_Address":"60, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801038
    ,"Long":106.659168
    ,"Polyline":"[106.66230011,10.80137253] ; [106.66233826,10.80132008] ; [106.66194153,10.80095959] ; [106.66171265,10.80080986] ; [106.66146088,10.80079079] ; [106.66128540,10.80080605] ; [106.66102600,10.80081177] ; [106.66071320,10.80084038] ; [106.65911102,10.80095959] ; [106.65911865,10.80101967]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"260"
    ,"Station_Code":"QTB 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà hát Quân Đội"
    ,"Station_Address":"138 (Kế nhà hát Quân đội), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801238
    ,"Long":106.656754
    ,"Polyline":"[106.65911102,10.80095959] ; [106.65675354,10.80115032]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"261"
    ,"Station_Code":"QTB 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Ngân hàng Quân đội"
    ,"Station_Address":"Tiệc cưới Hương Sen, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801412
    ,"Long":106.654817
    ,"Polyline":"[106.65675354,10.80115032] ; [106.65480042,10.80132008]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"262"
    ,"Station_Code":"QTB 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Công ty Lô Hội"
    ,"Station_Address":"184, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801728
    ,"Long":106.651127
    ,"Polyline":"[106.65480042,10.80132008] ; [106.65112305,10.80163956]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"263"
    ,"Station_Code":"QTB 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Ngã tư Hoàng Hoa Thám"
    ,"Station_Address":"304, đường Cộng Hòa, Quận  Tân Bình"
    ,"Lat":10.802102
    ,"Long":106.646953
    ,"Polyline":"[106.65112305,10.80163956] ; [106.65009308,10.80173016] ; [106.64747620,10.80193996] ; [106.64694214,10.80198002]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"264"
    ,"Station_Code":"QTB 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Ngã ba Bình Giã"
    ,"Station_Address":"390, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802276
    ,"Long":106.644512
    ,"Polyline":"[106.64694214,10.80198002] ; [106.64434052,10.80220032]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"265"
    ,"Station_Code":"QTB 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Lê Văn Huân"
    ,"Station_Address":"496, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802571
    ,"Long":106.640967
    ,"Polyline":"[106.64434052,10.80220032] ; [106.64096832,10.80247974]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"4485"
    ,"Station_Code":"QTBBXCH"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"592, Cộng Hòa"
    ,"Station_Address":"592, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.8040600032583
    ,"Long":106.63784712553
    ,"Polyline":"[106.64096832,10.80253983] ; [106.64059448,10.80252361] ; [106.64014435,10.80256081] ; [106.63980865,10.80258751] ; [106.63953400,10.80263996] ; [106.63924408,10.80271339] ; [106.63897705,10.80282402] ; [106.63866425,10.80297756] ; [106.63828278,10.80332470] ; [106.63798523,10.80373096] ; [106.63784790,10.80405998]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"266"
    ,"Station_Code":"QTB 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"660 (kế 592 ), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.806313
    ,"Long":106.636192
    ,"Polyline":"[106.63784790,10.80405998] ; [106.63617706,10.80631256]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Mũi tàu Cộng  Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63616180,10.80628967] ; [106.63549805,10.80685997] ; [106.63509369,10.80729008] ; [106.63481903,10.80762005] ; [106.63462067,10.80801010]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63462067,10.80801010.06.63450623] ; [10.80827045,106.63417053] ; [10.80928993,106.63343811]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63343811,10.81167984] ; [106.63253784,10.81462002]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63253784,10.81462002] ; [106.63163757,10.81752968]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63163757,10.81752968] ; [106.63038635,10.82162952]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường  Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63044739,10.82164383] ; [106.62984467,10.82299995] ; [106.62889862,10.82407475] ; [106.62714386,10.82559204] ; [106.62597656,10.82664108]"
    ,"Distance":"752"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"273"
    ,"Station_Code":"Q12 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"189/4, đường Trường Chinh, Quận 12"
    ,"Lat":10.828843
    ,"Long":106.624482
    ,"Polyline":"[106.62595367,10.82662010.06.62528229] ; [10.82740974,106.62447357] ; [10.82857037,106.62435913]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"274"
    ,"Station_Code":"Q12 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Chùa Vĩnh  Phước"
    ,"Station_Address":"258, đường Trường  Chinh, Quận 12"
    ,"Lat":10.832547
    ,"Long":106.622116
    ,"Polyline":"[106.62435913,10.82874012] ; [106.62193298,10.83242035]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"275"
    ,"Station_Code":"Q12 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Chùa Lạc Quang"
    ,"Station_Address":"408, đường Trường Chinh, Quận 12"
    ,"Lat":10.83514
    ,"Long":106.620464
    ,"Polyline":"[106.62193298,10.83242035] ; [106.62024689,10.83504009]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"277"
    ,"Station_Code":"Q12 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"640, đường Trường Chinh, Quận 12"
    ,"Lat":10.83819
    ,"Long":106.618495
    ,"Polyline":"[106.62024689,10.83504009] ; [106.61829376,10.83808041]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"276"
    ,"Station_Code":"Q12 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"774A, đường  Trường Chinh, Quận 12"
    ,"Lat":10.841436
    ,"Long":106.616457
    ,"Polyline":"[106.61829376,10.83808041] ; [106.61621094,10.84130955]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61621094,10.84130955] ; [106.61564636,10.84220028] ; [106.61560059,10.84230995] ; [106.61559296,10.84243965] ; [106.61566162,10.84257984] ; [106.61566162,10.84274006] ; [106.61560822,10.84286022] ; [106.61556244,10.84292984] ; [106.61546326,10.84298992] ; [106.61534119,10.84300995] ; [106.61528015,10.84300041] ; [106.61518097,10.84311962] ; [106.61475372,10.84370995] ; [106.61396027,10.84490967]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1116"
    ,"Station_Code":"Q12 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Trạm cây xăng"
    ,"Station_Address":"128, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.845487
    ,"Long":106.61371
    ,"Polyline":"[106.61396027,10.84490967] ; [106.61361694,10.84545040]"
    ,"Distance":"84"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1117"
    ,"Station_Code":"Q12 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"65"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"7C, đường  Quốc lộ 22, Quận 12"
    ,"Lat":10.845845
    ,"Long":106.613474
    ,"Polyline":"[106.61361694,10.84545040] ; [106.61338806,10.84578991]"
    ,"Distance":"58"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"66"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61338806,10.84578991] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61237335,10.84720993] ; [106.61244202,10.84710026] ; [106.61327362,10.84582043] ; [106.61369324,10.84515953] ; [106.61405182,10.84459972] ; [106.61386108,10.84449005] ; [106.61338806,10.84424973] ; [106.61322784,10.84414005] ; [106.61312103,10.84407997] ; [106.61319733,10.84385967]"
    ,"Distance":"720"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương,  đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"171"
    ,"Station_Code":"Q12 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"601, đường Trường Chinh, Quận 12"
    ,"Lat":10.841209
    ,"Long":106.615925
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61504364,10.84255981] ; [106.61511993,10.84243011] ; [106.61530304,10.84235001] ; [106.61535645,10.84234047] ; [106.61546326,10.84218979] ; [106.61605835,10.84127045]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"167"
    ,"Station_Code":"Q12 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"487, đường Trường Chinh, Quận 12"
    ,"Lat":10.837863
    ,"Long":106.618044
    ,"Polyline":"[106.61605835,10.84127045] ; [106.61820221,10.83794975]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"172"
    ,"Station_Code":"Q12 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Lạc  Quang"
    ,"Station_Address":"257, đường Trường  Chinh, Quận 12"
    ,"Lat":10.834623
    ,"Long":106.620163
    ,"Polyline":"[106.61820221,10.83794975] ; [106.62029266,10.83471012]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"168"
    ,"Station_Code":"Q12 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"Chùa Vĩnh Phước, đường Trường Chinh , Quận 12"
    ,"Lat":10.831836
    ,"Long":106.621928
    ,"Polyline":"[106.62029266,10.83471012] ; [106.62207794,10.83191967]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"170"
    ,"Station_Code":"Q12 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"113, đường Trường Chinh, Quận 12"
    ,"Lat":10.82898
    ,"Long":106.623768
    ,"Polyline":"[106.62207794,10.83191967] ; [106.62387848,10.82913017]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đư ờng Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62387848,10.82913017] ; [106.62487793,10.82758999] ; [106.62512207,10.82730007] ; [106.62560272,10.82676029] ; [106.62599182,10.82637978]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trư ờng Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62599182,10.82637978] ; [106.62699890,10.82542038] ; [106.62803650,10.82446957] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm KCN Tân Bình"
    ,"Station_Address":"881, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63089752,10.81947041]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chế Lan  Viên"
    ,"Station_Address":"28/7B, đường Trường  Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"178"
    ,"Station_Code":"QTB 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680 (Thượng Uyển), đường Cộng Hòa, Qu ận Tân Bình"
    ,"Lat":10.806144
    ,"Long":106.636055
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63455963,10.80772972] ; [106.63471985,10.80747986] ; [106.63487244,10.80729961] ; [106.63501740,10.80712986] ; [106.63535309,10.80681992] ; [106.63601685,10.80624962] ; [106.63609314,10.80617046]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"180"
    ,"Station_Code":"QTB 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"401, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.803541
    ,"Long":106.637887
    ,"Polyline":"[106.63609314,10.80617046] ; [106.63627625,10.80595016] ; [106.63709259,10.80482960] ; [106.63793182,10.80358028]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"181"
    ,"Station_Code":"QTB 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm ETown"
    ,"Station_Address":"364  (công ty Ree), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802371
    ,"Long":106.640253
    ,"Polyline":"[106.63793182,10.80358028] ; [106.63818359,10.80319977] ; [106.63858032,10.80292034] ; [106.63897705,10.80270004] ; [106.63944244,10.80257034] ; [106.63977814,10.80249023] ; [106.64025116,10.80243969]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"179"
    ,"Station_Code":"QTB 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã ba B ình Giã"
    ,"Station_Address":"303, đường Cộng  Hòa, Quận Tân Bình"
    ,"Lat":10.802055
    ,"Long":106.644292
    ,"Polyline":"[106.64025116,10.80243969] ; [106.64430237,10.80212021]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"183"
    ,"Station_Code":"QTB 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"19A (Công ty Lô H ội), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801544
    ,"Long":106.650413
    ,"Polyline":"[106.64430237,10.80212021] ; [106.64871979,10.80173969] ; [106.65028381,10.80160999]"
    ,"Distance":"656"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"182"
    ,"Station_Code":"QTB 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Pico Plaza"
    ,"Station_Address":"20Bis, đường Cộng Hòa, Qu ận Tân Bình"
    ,"Lat":10.801254
    ,"Long":106.653637
    ,"Polyline":"[106.65028381,10.80160999] ; [106.65370941,10.80130959]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"185"
    ,"Station_Code":"QTB 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Út tịch"
    ,"Station_Address":"35-37, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.800985
    ,"Long":106.656679
    ,"Polyline":"[106.65370941,10.80130959] ; [106.65663147,10.80105019]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"184"
    ,"Station_Code":"QTB 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"Đối diện 58 (Siêu thị Maximart), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.800833
    ,"Long":106.658819
    ,"Polyline":"[106.65663147,10.80105019] ; [106.65782928,10.80095959] ; [106.65878296,10.80086040] ; [106.65888214,10.80080032] ; [106.65921783,10.80078030]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65921783,10.80078030] ; [106.65979004,10.80074024] ; [106.66069031,10.80064011] ; [106.66075897,10.80056953] ; [106.66078186,10.80051041] ; [106.66087341,10.80027008] ; [106.66101074,10.80023003] ; [106.66108704,10.80027008] ; [106.66113281,10.80031967] ; [106.66117096,10.80035973] ; [106.66127777,10.80039024] ; [106.66149139,10.80056953] ; [106.66166687,10.80064964] ; [106.66182709,10.80068016] ; [106.66271210,10.80062008] ; [106.66326141,10.80056953]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80056953] ; [106.66545868,10.80035973] ; [106.66635895,10.80029964]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"511"
    ,"Station_Code":"QPN 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"241, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799905
    ,"Long":106.6698
    ,"Polyline":"[106.66635895,10.80029964] ; [106.66771698,10.80020046] ; [106.66876984,10.80010033]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"556"
    ,"Station_Code":"QPN 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Khách Sạn Tân Sơn Nhất"
    ,"Station_Address":"217, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799805
    ,"Long":106.670873
    ,"Polyline":"[106.66876984,10.80010033] ; [106.67032623,10.79996014]"
    ,"Distance":"171"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"512"
    ,"Station_Code":"QPN 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Công an Phú Nhuận"
    ,"Station_Address":"189, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799552
    ,"Long":106.673684
    ,"Polyline":"[106.67032623,10.79996014] ; [106.67369080,10.79967976]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"232"
    ,"Station_Code":"QPN 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"59, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799094
    ,"Long":106.679247
    ,"Polyline":"[106.67369080,10.79967976] ; [106.67604065,10.79950047] ; [106.67784882,10.79934025]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"558"
    ,"Station_Code":"QPN 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"171, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.800241
    ,"Long":106.681541
    ,"Polyline":"[106.67784882,10.79934025] ; [106.67846680,10.79928017] ; [106.68000793,10.79918957] ; [106.68028259,10.79920006] ; [106.68048096,10.79924011] ; [106.68096161,10.79973984] ; [106.68151093,10.80027008]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"513"
    ,"Station_Code":"QPN 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"141 - 143, đ ường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802197
    ,"Long":106.683619
    ,"Polyline":"[106.68151093,10.80027008] ; [106.68286133,10.80163956] ; [106.68315887,10.80191994] ; [106.68353271,10.80228043]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"514"
    ,"Station_Code":"QPN 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đại học  Văn Hiến"
    ,"Station_Address":"109, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803841
    ,"Long":106.686156
    ,"Polyline":"[106.68353271,10.80228043] ; [106.68470764,10.80344963] ; [106.68492889,10.80364037] ; [106.68515778,10.80383015] ; [106.68544006,10.80395031] ; [106.68560028,10.80397987] ; [106.68576050,10.80399036] ; [106.68614960,10.80393982]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"515"
    ,"Station_Code":"QPN 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Bệnh Viện Phước An"
    ,"Station_Address":"81 - 83, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.80362
    ,"Long":106.687744
    ,"Polyline":"[106.68614960,10.80393982] ; [106.68772125,10.80373001]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"516"
    ,"Station_Code":"QBTH 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Công an PCCC"
    ,"Station_Address":"45, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803188
    ,"Long":106.691371
    ,"Polyline":"[106.68772125,10.80373001] ; [106.68939972,10.80354977] ; [106.69088745,10.80335045] ; [106.69136810,10.80327988]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"517"
    ,"Station_Code":"QBTH 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"1, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802455
    ,"Long":106.696826
    ,"Polyline":"[106.69136810,10.80327988] ; [106.69243622,10.80313015] ; [106.69441986,10.80288982] ; [106.69599152,10.80268002] ; [106.69706726,10.80255032]"
    ,"Distance":"628"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"473C, đường Bạch  Đằng, Quận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69706726,10.80255032] ; [106.69795990,10.80245972] ; [106.69860077,10.80268002] ; [106.69898224,10.80286980] ; [106.69936371,10.80301952]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Th ạnh"
    ,"Station_Address":"449, đường Bạch Đằng , Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69936371,10.80301952] ; [106.70105743,10.80370045]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"375, đường Bạch  Đằng, Quận Bình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70105743,10.80370045] ; [106.70149231,10.80385017] ; [106.70172882,10.80383968] ; [106.70278168,10.80356026] ; [106.70324707,10.80346012] ; [106.70365143,10.80342007] ; [106.70391846,10.80338955]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70391846,10.80338955] ; [106.70670319,10.80317020]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70670319,10.80317020] ; [106.70815277,10.80307007] ; [106.70899200,10.80300045] ; [106.70997620,10.80294991] ; [106.71053314,10.80290031]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"476"
    ,"Station_Code":"QBTH 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"500-502, đường Điện Biên Phủ, Quận Bình  Thạnh"
    ,"Lat":10.800864
    ,"Long":106.714287
    ,"Polyline":"[106.71053314,10.80290031] ; [106.71138000,10.80284309] ; [106.71136475,10.80264759] ; [106.71134949,10.80234241] ; [106.71133423,10.80187893] ; [106.71132660,10.80160141] ; [106.71128845,10.80159950] ; [106.71124268,10.80158424] ; [106.71120453,10.80155087] ; [106.71115875,10.80150795] ; [106.71115112,10.80144691] ; [106.71114349,10.80140400] ; [106.71115875,10.80135727] ; [106.71118164,10.80132294] ; [106.71121979,10.80128002] ; [106.71126556,10.80125523] ; [106.71130371,10.80124187] ; [106.71138000,10.80124760] ; [106.71142578,10.80126572] ; [106.71148682,10.80129242] ; [106.71174622,10.80128860] ; [106.71202850,10.80128002] ; [106.71231842,10.80129623] ; [106.71240234,10.80129433] ; [106.71255493,10.80128479] ; [106.71269989,10.80127811] ; [106.71293640,10.80126286] ; [106.71311188,10.80123711] ; [106.71342468,10.80118847] ; [106.71377563,10.80111027] ; [106.71386719,10.80107975] ; [106.71414185,10.80101013]"
    ,"Distance":"605"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"473"
    ,"Station_Code":"QBTH 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"600, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799547
    ,"Long":106.717409
    ,"Polyline":"[106.71414185,10.80101013] ; [106.71469879,10.80084991] ; [106.71527863,10.80066013] ; [106.71617889,10.80035019] ; [106.71685791,10.80000973] ; [106.71720886,10.79983044]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"475"
    ,"Station_Code":"QBTH 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"658, đường Điện Biên Phủ, Qu ận Bình Thạnh"
    ,"Lat":10.798525
    ,"Long":106.719496
    ,"Polyline":"[106.71720886,10.79983044] ; [106.71833801,10.79920959] ; [106.71943665,10.79856968]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"477"
    ,"Station_Code":"Q2 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"794, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.799978
    ,"Long":106.7342
    ,"Polyline":"[106.71943665,10.79856968] ; [106.72039795,10.79808044] ; [106.72083282,10.79792976] ; [106.72122955,10.79782009] ; [106.72203064,10.79780960] ; [106.72254944,10.79782963] ; [106.72306824,10.79790020] ; [106.72541046,10.79833031] ; [106.72850037,10.79891968] ; [106.73149872,10.79944992] ; [106.73317719,10.79986954] ; [106.73404694,10.80006981] ; [106.73417664,10.80008984]"
    ,"Distance":"1654"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"478"
    ,"Station_Code":"Q2 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Đối diện ng ã 3 Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800838
    ,"Long":106.738899
    ,"Polyline":"[106.73417664,10.80008984] ; [106.73886871,10.80097961]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"480"
    ,"Station_Code":"Q2 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Metro Qu ận 2"
    ,"Station_Address":"170, đường Xa Lộ H à Nội, Quận 2"
    ,"Lat":10.801584
    ,"Long":106.742928
    ,"Polyline":"[106.73886871,10.80097961] ; [106.74289703,10.80173016]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"479"
    ,"Station_Code":"Q2 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Khu dân cư Estella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802592
    ,"Long":106.748089
    ,"Polyline":"[106.74289703,10.80173016] ; [106.74376678,10.80189037] ; [106.74430084,10.80200958] ; [106.74456787,10.80204010.06.74524689] ; [10.80206966,106.74575806] ; [10.80202961,106.74610901] ; [10.80202007,106.74642181] ; [10.80206966,106.74662781] ; [10.80214024,106.74687958] ; [10.80226040,106.74725342] ; [10.80241966,106.74761963] ; [10.80255032,106.74806213]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"482"
    ,"Station_Code":"Q9 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Xi măng hà tiên - trạm thu phí"
    ,"Station_Address":"249B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.819206
    ,"Long":106.758394
    ,"Polyline":"[106.74806213,10.80266953] ; [106.74839020,10.80274010.06.74857330] ; [10.80282021,106.74897003] ; [10.80292034,106.74938202] ; [10.80301952,106.74983215] ; [10.80315971,106.75074005] ; [10.80352020,106.75142670] ; [10.80387974,106.75209045] ; [10.80432034,106.75256348] ; [10.80461979,106.75302124] ; [10.80500984,106.75366974] ; [10.80558968,106.75424194] ; [10.80618000,106.75460052] ; [10.80661964,106.75485229] ; [10.80694962,106.75514221] ; [10.80733013,106.75559235] ; [10.80803967,106.75594330] ; [10.80877018,106.75621796] ; [10.80947018,106.75650787] ; [10.81050968,106.75662994] ; [10.81101990,106.75669098] ; [10.81138992,106.75772858] ; [10.81686020,106.75784302] ; [10.81725025,106.75820160] ; [10.81894970,106.75823975]"
    ,"Distance":"2327"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"481"
    ,"Station_Code":"Q9 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"185A , đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.825972
    ,"Long":106.760775
    ,"Polyline":"[106.75823975,10.81917953] ; [106.75846863,10.82038021] ; [106.75865936,10.82139015] ; [106.75891876,10.82240963] ; [106.75916290,10.82306004] ; [106.75942230,10.82365990] ; [106.75946045,10.82380962] ; [106.75950623,10.82392025] ; [106.75980377,10.82448006] ; [106.76068115,10.82600975]"
    ,"Distance":"813"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"485"
    ,"Station_Code":"Q9 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Trạm xây dựng"
    ,"Station_Address":"354A, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.829955
    ,"Long":106.76312
    ,"Polyline":"[106.76068115,10.82600975] ; [106.76112366,10.82678032] ; [106.76235962,10.82892036] ; [106.76296234,10.82999039]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"483"
    ,"Station_Code":"Q9 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Khu QLGTDT  số 2"
    ,"Station_Address":"Khu QLGTĐT số 2,  đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.833249
    ,"Long":106.764778
    ,"Polyline":"[106.76296234,10.82999039] ; [106.76477814,10.83325005]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1025"
    ,"Station_Code":"Q9 214"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Kho 71, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.836162
    ,"Long":106.76666
    ,"Polyline":"[106.76477814,10.83325005] ; [106.76647186,10.83621979]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1030"
    ,"Station_Code":"Q9 215"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"UBND quận 9"
    ,"Station_Address":"1B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.840466
    ,"Long":106.769074
    ,"Polyline":"[106.76647186,10.83621979] ; [106.76822662,10.83934021] ; [106.76892090,10.84057045]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1026"
    ,"Station_Code":"Q9 216"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Bê tông Hải Âu"
    ,"Station_Address":"Bê tông Hải Âu, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.843834
    ,"Long":106.77079
    ,"Polyline":"[106.76892090,10.84057045] ; [106.77076721,10.84383011]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1028"
    ,"Station_Code":"Q9 217"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Ngã 4 Thủ Đức"
    ,"Station_Address":"712, đường Xa  Lộ Hà Nội, Quận 9"
    ,"Lat":10.847142
    ,"Long":106.772974
    ,"Polyline":"[106.77076721,10.84383011] ; [106.77150726,10.84517956] ; [106.77175903,10.84545994] ; [106.77204132,10.84582996] ; [106.77229309,10.84620953] ; [106.77281189,10.84710979]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1031"
    ,"Station_Code":"QTD 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"ĐH Sư Phạm Kỹ Thuật"
    ,"Station_Address":"116/6, đường  Lê Văn Chí, Quận Thủ Đức"
    ,"Lat":10.850485
    ,"Long":106.774025
    ,"Polyline":"[106.77281189,10.84710979] ; [106.77333069,10.84799957] ; [106.77368927,10.84848976] ; [106.77414703,10.84902954] ; [106.77391052,10.84926033] ; [106.77371979,10.84939957] ; [106.77351379,10.84951973] ; [106.77336884,10.84957981] ; [106.77352142,10.84976959] ; [106.77380371,10.85015965] ; [106.77394867,10.85050964]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1033"
    ,"Station_Code":"QTD 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Nhà máy nước Thủ Đức"
    ,"Station_Address":"Nhà máy nước Thủ Đức, đường Lê Văn Chí, Quận Thủ Đức"
    ,"Lat":10.853954
    ,"Long":106.773173
    ,"Polyline":"[106.77394867,10.85050964] ; [106.77435303,10.85142994] ; [106.77438354,10.85161972] ; [106.77436829,10.85173988] ; [106.77433777,10.85186958] ; [106.77404022,10.85237026] ; [106.77348328,10.85326004] ; [106.77324677,10.85361958] ; [106.77320862,10.85369015]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1032"
    ,"Station_Code":"QTD 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Ngã ba Lê Văn Chí"
    ,"Station_Address":"225, đường Hoàng Diệu 2, Quận Thủ Đức"
    ,"Lat":10.854117
    ,"Long":106.77195
    ,"Polyline":"[106.77320862,10.85369015] ; [106.77306366,10.85394955] ; [106.77301025,10.85408974] ; [106.77292633,10.85443020] ; [106.77246857,10.85426044] ; [106.77197266,10.85406017]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1035"
    ,"Station_Code":"QTD 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Tô Vĩnh Diện"
    ,"Station_Address":"151, đường Hoàng Diệu 2, Quận Thủ Đức"
    ,"Lat":10.854728
    ,"Long":106.76843
    ,"Polyline":"[106.77197266,10.85406017] ; [106.77174377,10.85396957] ; [106.77149200,10.85394955] ; [106.77097321,10.85406017] ; [106.77072144,10.85408974] ; [106.77011871,10.85410976] ; [106.76969910,10.85416031] ; [106.76921844,10.85426044] ; [106.76870728,10.85441017] ; [106.76840210,10.85461044]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1036"
    ,"Station_Code":"QTD 226"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Hoàng Diệu 2"
    ,"Station_Address":"40, đường Đường số 7, Quận Thủ Đức"
    ,"Lat":10.857191
    ,"Long":106.766396
    ,"Polyline":"[106.76844025,10.85467052] ; [106.76679993,10.85564518] ; [106.76645660,10.85610867] ; [106.76614380,10.85648823] ; [106.76639557,10.85719109]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1037"
    ,"Station_Code":"QTD 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Ngã ba Linh Trung đường số 6"
    ,"Station_Address":"94A, đường Đường số 6, Quận Thủ Đức"
    ,"Lat":10.860866
    ,"Long":106.768479
    ,"Polyline":"[106.76631927,10.85721970] ; [106.76658630,10.85797024] ; [106.76664734,10.85813999] ; [106.76672363,10.85826015] ; [106.76690674,10.85838032] ; [106.76770020,10.85873985] ; [106.76808929,10.85898972] ; [106.76840973,10.85929012] ; [106.76828003,10.85960007] ; [106.76799011,10.86011028] ; [106.76779938,10.86036015] ; [106.76767731,10.86036968] ; [106.76849365,10.86089039]"
    ,"Distance":"613"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1038"
    ,"Station_Code":"QTD 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Ngã ba đường 14"
    ,"Station_Address":"62-64, đường Đường Số 6, Quận Thủ Đức"
    ,"Lat":10.860864
    ,"Long":106.770905
    ,"Polyline":"[106.76849365,10.86089039] ; [106.76876068,10.86106968] ; [106.76975250,10.86102962] ; [106.77091217,10.86085987]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1039"
    ,"Station_Code":"QTD 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Đường số 14"
    ,"Station_Address":"18, đường Đường số 14, Quận Thủ Đức"
    ,"Lat":10.861798
    ,"Long":106.772301
    ,"Polyline":"[106.77091217,10.86085987] ; [106.77175903,10.86075974] ; [106.77224731,10.86182022]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1040"
    ,"Station_Code":"QTD 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"ĐH Kinh tế Luật"
    ,"Station_Address":"Đối diện 665 , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.869306
    ,"Long":106.776724
    ,"Polyline":"[106.77230072,10.86179829] ; [106.77224731,10.86182022] ; [106.77268219,10.86275959] ; [106.77391052,10.86542320] ; [106.77490997,10.86755085] ; [106.77561951,10.86885738] ; [106.77601624,10.86965847] ; [106.77645874,10.86948967] ; [106.77672577,10.86930561]"
    ,"Distance":"1059"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1041"
    ,"Station_Code":"QTD 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Công ty đi ện tử Samsung"
    ,"Station_Address":"Công ty điện tử Samsung, đường Quốc l ộ 1, Quận Thủ Đức"
    ,"Lat":10.868691
    ,"Long":106.778656
    ,"Polyline":"[106.77672577,10.86930561] ; [106.77712250,10.86926842] ; [106.77748108,10.86913967] ; [106.77867889,10.86874962] ; [106.77865601,10.86869144]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"1042"
    ,"Station_Code":"QTD 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"Cột điện SI 2, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867122
    ,"Long":106.787277
    ,"Polyline":"[106.77865601,10.86869144] ; [106.77938843,10.86856270] ; [106.78088379,10.86806297] ; [106.78207397,10.86769390] ; [106.78311920,10.86743546] ; [106.78416443,10.86732483] ; [106.78519440,10.86727905] ; [106.78636932,10.86724091] ; [106.78727722,10.86712170]"
    ,"Distance":"965"
  },
  {
     "Route_Id":"15"
    ,"Station_Id":"394"
    ,"Station_Code":"BX73"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Bến xe buýt ĐH Nông Lâm, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868183135986328
    ,"Long":106.78744506835938
    ,"Polyline":"[106.78727722,10.86712170] ; [106.78791046,10.86715603] ; [106.78834534,10.86714077] ; [106.78868103,10.86714077] ; [106.78851318,10.86736202] ; [106.78821564,10.86758804] ; [106.78788757,10.86782551] ; [106.78781128,10.86807251] ; [106.78776550,10.86820412] ; [106.78759003,10.86824131] ; [106.78744507,10.86818314]"
    ,"Distance":"351"
  }]