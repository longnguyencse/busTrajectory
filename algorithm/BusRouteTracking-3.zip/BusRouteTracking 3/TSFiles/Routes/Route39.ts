export const Route39 =[

  {
     "Route_Id":"39"
    ,"Station_Id":"1999"
    ,"Station_Code":"BX 15"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu chế xuất Tân Thuận"
    ,"Station_Address":"ĐẦU BẾN KCX TÂN THUẬN, đường Nguy ễn Văn Linh, Quận 7"
    ,"Lat":10.752883
    ,"Long":106.727501
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"862"
    ,"Station_Code":"Q7 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Sân bóng CLB cảng SG"
    ,"Station_Address":"144-146, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.751697
    ,"Long":106.724088
    ,"Polyline":"[106.72750854,10.75273991] ; [106.72699738,10.75271988] ; [106.72669220,10.75269032] ; [106.72624207,10.75259972] ; [106.72566223,10.75242996] ; [106.72537231,10.75230980] ; [106.72501373,10.75212002] ; [106.72476959,10.75199986] ; [106.72418213,10.75160027] ; [106.72393036,10.75139046]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"861"
    ,"Station_Code":"Q7 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Ủy ban phường Tân Thuận Tây"
    ,"Station_Address":"UBND phường Tân Thuận Tây, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.747691
    ,"Long":106.721756
    ,"Polyline":"[106.72393036,10.75139046] ; [106.72342682,10.75094986] ; [106.72325897,10.75076962] ; [106.72280121,10.75014973] ; [106.72248840,10.74964046] ; [106.72219086,10.74907017] ; [106.72202301,10.74855995] ; [106.72180939,10.74767971]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"866"
    ,"Station_Code":"Q7 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Lý Phục Man"
    ,"Station_Address":"636, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.742521
    ,"Long":106.721508
    ,"Polyline":"[106.72180939,10.74767971] ; [106.72174835,10.74736977] ; [106.72170258,10.74685955] ; [106.72164154,10.74361038]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"863"
    ,"Station_Code":"Q7 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nguyễn Thị Thập"
    ,"Station_Address":"340A, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.739585
    ,"Long":106.721444
    ,"Polyline":"[106.72164154,10.74361038] ; [106.72157288,10.73958969]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2063"
    ,"Station_Code":"Q7 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Nguyễn Thị Thập"
    ,"Station_Address":"154, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.73821
    ,"Long":106.720027
    ,"Polyline":"[106.72157288,10.73958969] ; [106.72152710,10.73803997] ; [106.72058868,10.73808956] ; [106.71974945,10.73812962]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1373"
    ,"Station_Code":"Q7 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"222, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738384
    ,"Long":106.717485
    ,"Polyline":"[106.71974945,10.73812962] ; [106.71849060,10.73822021] ; [106.71804810,10.73822975] ; [106.71672058,10.73832035]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2064"
    ,"Station_Code":"Q7 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"273D, đường Lâm Văn Bền, Quận 7"
    ,"Lat":10.739549
    ,"Long":106.715977
    ,"Polyline":"[106.71672058,10.73832035] ; [106.71591949,10.73838043] ; [106.71589661,10.73954964]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2065"
    ,"Station_Code":"Q7 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường Nguyễn Thị Định"
    ,"Station_Address":"Tr ường Tiểu học Nguyễn Thị Định, đường Lâm Văn Bền, Quận 7"
    ,"Lat":10.742969
    ,"Long":106.715924
    ,"Polyline":"[106.71589661,10.73954964] ; [106.71588898,10.74069023] ; [106.71588135,10.74160004] ; [106.71588135,10.74248981] ; [106.71585846,10.74316978]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2066"
    ,"Station_Code":"Q7 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Nguyễn Hữu Thọ"
    ,"Station_Address":"41A, đường Lâm Văn Bền, Qu ận 7"
    ,"Lat":10.748935
    ,"Long":106.71594
    ,"Polyline":"[106.71585846,10.74316978] ; [106.71585846,10.74394035] ; [106.71585846,10.74464989] ; [106.71584320,10.74818039] ; [106.71585083,10.74901962]"
    ,"Distance":"651"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2067"
    ,"Station_Code":"Q7 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thờ Thuận Phát"
    ,"Station_Address":"Đối diện 253, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751902
    ,"Long":106.715049
    ,"Polyline":"[106.71585083,10.74901962] ; [106.71584320,10.75043011] ; [106.71584320,10.75189018] ; [106.71531677,10.75189018]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2069"
    ,"Station_Code":"Q7 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Miếu Bà C ố"
    ,"Station_Address":"Đối diện 331, đường Tr ần Xuân Soạn, Quận 7"
    ,"Lat":10.751886
    ,"Long":106.712512
    ,"Polyline":"[106.71531677,10.75189018] ; [106.71234894,10.75185966]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2068"
    ,"Station_Code":"Q7 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Bế Văn Cấm"
    ,"Station_Address":"Đối diện 413, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751855
    ,"Long":106.709207
    ,"Polyline":"[106.71234894,10.75185966] ; [106.70928955,10.75183010]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2070"
    ,"Station_Code":"Q7 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ủy ban Phường Tân Kiểng"
    ,"Station_Address":"Đối diện 505, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.75185
    ,"Long":106.706659
    ,"Polyline":"[106.70928955,10.75183010.06.70716095]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1455"
    ,"Station_Code":"Q7 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"Đối diện 263, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751839
    ,"Long":106.704508
    ,"Polyline":"[106.70716095,10.75183010.06.70436859]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1446"
    ,"Station_Code":"Q7 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ủy ban Phường Tân Hưng"
    ,"Station_Address":"Đối diện 733, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751786
    ,"Long":106.701347
    ,"Polyline":"[106.70436859,10.75179958] ; [106.70134735,10.75177002]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1456"
    ,"Station_Code":"Q7 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"chùa Kiều  Đàm"
    ,"Station_Address":"Đối diện 829, đường  Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751776
    ,"Long":106.697998
    ,"Polyline":"[106.70134735,10.75177002] ; [106.69799042,10.75174046]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1450"
    ,"Station_Code":"Q7 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Tân Hưng"
    ,"Station_Address":"Đối diện 933 , đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751731
    ,"Long":106.694519
    ,"Polyline":"[106.69799042,10.75174046] ; [106.69609070,10.75174046] ; [106.69451904,10.75170040]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1461"
    ,"Station_Code":"Q7 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cầu Rạch Ông"
    ,"Station_Address":"Đối diện 999, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751496
    ,"Long":106.692969
    ,"Polyline":"[106.69451904,10.75170040] ; [106.69403839,10.75164986] ; [106.69360352,10.75156975] ; [106.69184875,10.75125027]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1452"
    ,"Station_Code":"Q8 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu Nguyễn Văn Cừ"
    ,"Station_Address":"122, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.750859
    ,"Long":106.68724
    ,"Polyline":"[106.69184875,10.75125027] ; [106.68919373,10.75076962] ; [106.68846130,10.75063038] ; [106.68824768,10.75063038] ; [106.68778992,10.75078011] ; [106.68771362,10.75080967] ; [106.68750763,10.75080013] ; [106.68713379,10.75070953]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1449"
    ,"Station_Code":"Q8 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Chữ Y"
    ,"Station_Address":"124, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.749931
    ,"Long":106.684767
    ,"Polyline":"[106.68713379,10.75070953] ; [106.68547821,10.75018978] ; [106.68476868,10.74985981]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2071"
    ,"Station_Code":"Q8 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Âu Dương Lân"
    ,"Station_Address":"14, đường Âu Dương Lân, Quận 8"
    ,"Lat":10.747433
    ,"Long":106.682085
    ,"Polyline":"[106.68476868,10.74985981] ; [106.68431091,10.74964046] ; [106.68263245,10.74878025] ; [106.68170929,10.74825001] ; [106.68171692,10.74822998] ; [106.68196869,10.74779987]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2072"
    ,"Station_Code":"Q8 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đặng Ch ất"
    ,"Station_Address":"144-146, đường Âu D ương Lân, Quận 8"
    ,"Lat":10.745657
    ,"Long":106.683066
    ,"Polyline":"[106.68196869,10.74779987] ; [106.68296814,10.74602985]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2073"
    ,"Station_Code":"Q8 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Âu Dương Lân"
    ,"Station_Address":"122-124, đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.743189
    ,"Long":106.683121
    ,"Polyline":"[106.68296814,10.74602985] ; [106.68341064,10.74522018] ; [106.68331909,10.74510002] ; [106.68321228,10.74485016] ; [106.68298340,10.74433994] ; [106.68302155,10.74427986] ; [106.68344879,10.74335957] ; [106.68296051,10.74310017]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2074"
    ,"Station_Code":"Q8 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Tạ Quang  Bửu"
    ,"Station_Address":"Đối diện 152, đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.741657
    ,"Long":106.679703
    ,"Polyline":"[106.68296051,10.74310017] ; [106.68270111,10.74293995] ; [106.68221283,10.74262047] ; [106.68073273,10.74193001] ; [106.67948151,10.74141026]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2075"
    ,"Station_Code":"Q8 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đại học Sài Gòn"
    ,"Station_Address":"180, đường Cao  Lỗ, Quận 8"
    ,"Lat":10.738363
    ,"Long":106.67877
    ,"Polyline":"[106.67948151,10.74141026] ; [106.67777252,10.74069977] ; [106.67765045,10.74067020] ; [106.67771149,10.74059010.06.67790222] ; [10.74016953,106.67813873] ; [10.73972034,106.67871857] ; [10.73853970,106.67881012]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2076"
    ,"Station_Code":"Q8 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Đồng Diều"
    ,"Station_Address":"Đối diện 111, đường 204 Cao Lỗ, Quận 8"
    ,"Lat":10.736866
    ,"Long":106.676769
    ,"Polyline":"[106.67881012,10.73838043] ; [106.67903137,10.73797035] ; [106.67726898,10.73709011] ; [106.67671204,10.73678970]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2077"
    ,"Station_Code":"HBC 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường s ố 5"
    ,"Station_Address":"04-06, đường Đường số 5, Huy ện Bình Chánh"
    ,"Lat":10.735706
    ,"Long":106.673566
    ,"Polyline":"[106.67671204,10.73678970] ; [106.67556000,10.73618984] ; [106.67500305,10.73591995] ; [106.67488098,10.73595047] ; [106.67446136,10.73624039] ; [106.67357635,10.73565960]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2079"
    ,"Station_Code":"HBC 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Hòa Bình"
    ,"Station_Address":"9 Hồ bơi Hòa Bình, đường Phạm Hùng, Huyện Bình Chánh"
    ,"Lat":10.736091
    ,"Long":106.671941
    ,"Polyline":"[106.67357635,10.73565960] ; [106.67260742,10.73501015] ; [106.67224884,10.73556995] ; [106.67179871,10.73616982] ; [106.67188263,10.73622036]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2078"
    ,"Station_Code":"Q8 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Nhà thờ Nam Hải"
    ,"Station_Address":"4/12, đường Ph ạm Hùng, Quận 8"
    ,"Lat":10.737546
    ,"Long":106.670884
    ,"Polyline":"[106.67188263,10.73622036] ; [106.67179871,10.73616982] ; [106.67172241,10.73628044] ; [106.67137146,10.73676968] ; [106.67083740,10.73750019]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2080"
    ,"Station_Code":"Q8 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Sân vận động Quận 8"
    ,"Station_Address":"175, đường Phạm Hùng, Quận 8"
    ,"Lat":10.742432
    ,"Long":106.669044
    ,"Polyline":"[106.67083740,10.73750019] ; [106.66974640,10.73896027] ; [106.66938782,10.73948956] ; [106.66921234,10.73974991] ; [106.66915131,10.73989010.06.66899872] ; [10.74030972,106.66892242] ; [10.74073029,106.66889954] ; [10.74162960,106.66889954]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2081"
    ,"Station_Code":"Q5 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Siêu thị Điện máy"
    ,"Station_Address":"Đối diện 105, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.754163
    ,"Long":106.669661
    ,"Polyline":"[106.66889954,10.74190998] ; [106.66889191,10.74477005] ; [106.66893005,10.74573040] ; [106.66909790,10.74794960] ; [106.66919708,10.74884987] ; [106.66931152,10.75018978] ; [106.66938019,10.75148010.06.66941833] ; [10.75238037,106.66945648] ; [10.75271034,106.66951752] ; [10.75345993,106.66951752]"
    ,"Distance":"1367"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"2082"
    ,"Station_Code":"Q5 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"Đối diện 153, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.755486
    ,"Long":106.669698
    ,"Polyline":"[106.66951752,10.75417042] ; [106.66953278,10.75549984]"
    ,"Distance":"148"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.66953278,10.75549984] ; [106.66954803,10.75667000] ; [106.66947937,10.75714970]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"431"
    ,"Station_Code":"Q5 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"116A, đường Hùng Vương, Qu ận 5"
    ,"Lat":10.757257
    ,"Long":106.668566
    ,"Polyline":"[106.66947937,10.75714970] ; [106.66941071,10.75765038] ; [106.66860199,10.75724030]"
    ,"Distance":"155"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bệnh viện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66860199,10.75724030] ; [106.66710663,10.75650024] ; [106.66664886,10.75636005] ; [106.66629791,10.75623989] ; [106.66513824,10.75594044] ; [106.66452789,10.75582027]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66452789,10.75582027] ; [106.66236877,10.75539017] ; [106.66108704,10.75514030]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66108704,10.75514030] ; [106.65962219,10.75487995]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"435"
    ,"Station_Code":"Q5 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"Đối diện 385, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75458
    ,"Long":106.657934
    ,"Polyline":"[106.65962219,10.75487995] ; [106.65854645,10.75469971] ; [106.65838623,10.75463963] ; [106.65796661,10.75454998]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung,  Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65793610,10.75457954] ; [106.65377045,10.75384140] ; [106.65322113,10.75149155] ; [106.65256500,10.75125313]"
    ,"Distance":"808"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.65106964,10.75118542] ; [106.65105438,10.75101662] ; [106.65052795,10.75107002] ; [106.65081024,10.75331497] ; [106.65233612,10.75333118] ; [106.65233612,10.75333118]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"470"
    ,"Station_Code":"Q5 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Thuận Kiều  Plaza"
    ,"Station_Address":"399, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754111
    ,"Long":106.656749
    ,"Polyline":"[106.65232849,10.75339031] ; [106.65300751,10.75347042] ; [106.65377808,10.75360012] ; [106.65473938,10.75378990] ; [106.65672302,10.75415993]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65672302,10.75415993] ; [106.65728760,10.75426006] ; [106.65841675,10.75444984] ; [106.65859222,10.75444031] ; [106.65921783,10.75457001]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Đại học Y  Dược"
    ,"Station_Address":"217, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.65921783,10.75457001] ; [106.66153717,10.75502014] ; [106.66317749,10.75535011]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bệnh viện Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66317749,10.75535011] ; [106.66470337,10.75564003]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1981"
    ,"Station_Code":"Q5 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"161 , đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.755728
    ,"Long":106.669473
    ,"Polyline":"[106.66470337,10.75564003] ; [106.66841125,10.75642014] ; [106.66954803,10.75667000] ; [106.66953278,10.75572968]"
    ,"Distance":"647"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"11"
    ,"Station_Code":"Q5 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Siêu thị Đi ện máy"
    ,"Station_Address":"99, đường Nguyễn  Tri Phương, Quận 5"
    ,"Lat":10.754023
    ,"Long":106.669418
    ,"Polyline":"[106.66953278,10.75572968] ; [106.66951752,10.75401974]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"14"
    ,"Station_Code":"Q5 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà Văn hóa Quận 5"
    ,"Station_Address":"388, đường Trần Phú, Quận 5"
    ,"Lat":10.753025
    ,"Long":106.668588
    ,"Polyline":"[106.66951752,10.75401974] ; [106.66951752,10.75345993] ; [106.66847992,10.75290966] ; [106.66840363,10.75286961]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1978"
    ,"Station_Code":"Q8 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Sân vận đ ộng Quận 8"
    ,"Station_Address":"302, đường Phạm Hùng, Quận 8"
    ,"Lat":10.74202
    ,"Long":106.668749
    ,"Polyline":"[106.66840363,10.75286961] ; [106.66847992,10.75290966] ; [106.66841125,10.75284958] ; [106.66837311,10.75279999] ; [106.66837311,10.75275993] ; [106.66842651,10.75269032] ; [106.66851807,10.75263977] ; [106.66945648,10.75271034] ; [106.66941833,10.75238037] ; [106.66938019,10.75148010.06.66931915] ; [10.75037003,106.66929626] ; [10.75010967,106.66918945] ; [10.74882030,106.66909790] ; [10.74794960,106.66893005] ; [10.74573040,106.66889191] ; [10.74477005,106.66887665] ; [10.74456024,106.66889954] ; [10.74219990,106.66889191]"
    ,"Distance":"1345"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1983"
    ,"Station_Code":"Q8 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thờ Nam  Hải"
    ,"Station_Address":"8B/22 (356), đường Phạm H ùng, Quận 8"
    ,"Lat":10.737577
    ,"Long":106.670519
    ,"Polyline":"[106.66889191,10.74205017] ; [106.66890717,10.74092007] ; [106.66893768,10.74065018] ; [106.66899872,10.74030972] ; [106.66906738,10.74007034] ; [106.66921234,10.73974991] ; [106.66953278,10.73927021] ; [106.67070007,10.73768044] ; [106.67104340,10.73725033] ; [106.67127991,10.73690987]"
    ,"Distance":"649"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1980"
    ,"Station_Code":"HBC 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Hòa Bình"
    ,"Station_Address":"C1/03, đường Phạm Hùng, Huyện Bình Chánh"
    ,"Lat":10.735959
    ,"Long":106.671839
    ,"Polyline":"[106.67127991,10.73690987] ; [106.67157745,10.73647976]"
    ,"Distance":"58"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1985"
    ,"Station_Code":"HBC 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Đường số 5"
    ,"Station_Address":"31-33 , đường Đường số 5, Huyện Bình Chánh"
    ,"Lat":10.735548
    ,"Long":106.673561
    ,"Polyline":"[106.67157745,10.73647976] ; [106.67179871,10.73616982] ; [106.67224884,10.73556995] ; [106.67260742,10.73501015] ; [106.67315674,10.73538971]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1982"
    ,"Station_Code":"Q8 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đồng Di ều"
    ,"Station_Address":"129-131 , đường 204 Cao Lỗ, Quận 8"
    ,"Lat":10.736645
    ,"Long":106.676618
    ,"Polyline":"[106.67315674,10.73538971] ; [106.67446136,10.73624039] ; [106.67471313,10.73604965] ; [106.67488098,10.73595047] ; [106.67500305,10.73591995] ; [106.67594910,10.73639965] ; [106.67652130,10.73670006]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1987"
    ,"Station_Code":"Q8 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Đại học Sài Gòn"
    ,"Station_Address":"Đối diện 184, đường Cao Lỗ, Quận 8"
    ,"Lat":10.739164
    ,"Long":106.678507
    ,"Polyline":"[106.67652130,10.73670006] ; [106.67903137,10.73797035] ; [106.67855835,10.73886013] ; [106.67835236,10.73929024]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1984"
    ,"Station_Code":"Q8 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Tạ Quang Bửu"
    ,"Station_Address":"152, đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.741383
    ,"Long":106.679885
    ,"Polyline":"[106.67835236,10.73929024] ; [106.67771149,10.74059010.06.67765045] ; [10.74067020,106.67777252] ; [10.74069977,106.67993164]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1986"
    ,"Station_Code":"Q8 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Âu Dương Lân"
    ,"Station_Address":"177-179, đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.743122
    ,"Long":106.683394
    ,"Polyline":"[106.67993164,10.74160004] ; [106.68087769,10.74199009] ; [106.68221283,10.74262047] ; [106.68247986,10.74277973] ; [106.68282318,10.74302959] ; [106.68321991,10.74322987]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1989"
    ,"Station_Code":"Q8 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Đặng Chất"
    ,"Station_Address":"147-149, đường Âu Dương Lân, Quận 8"
    ,"Lat":10.745778
    ,"Long":106.683195
    ,"Polyline":"[106.68321991,10.74322987] ; [106.68344116,10.74335957] ; [106.68302155,10.74427986] ; [106.68298340,10.74433041] ; [106.68306732,10.74456978] ; [106.68331909,10.74510002] ; [106.68341064,10.74522018] ; [106.68316650,10.74567986] ; [106.68308258,10.74582958]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1991"
    ,"Station_Code":"Q8 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Phạm Thế Hiển"
    ,"Station_Address":"35-37, đường Âu Dương Lân, Quận 8"
    ,"Lat":10.747828
    ,"Long":106.682063
    ,"Polyline":"[106.68308258,10.74582958] ; [106.68215179,10.74748039]"
    ,"Distance":"209"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1438"
    ,"Station_Code":"Q8 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Công viên Phường 2"
    ,"Station_Address":"231-233, đường  Phạm Thế Hiển, Quận 8"
    ,"Lat":10.749104
    ,"Long":106.683533
    ,"Polyline":"[106.68215179,10.74748039] ; [106.68171692,10.74822998] ; [106.68170929,10.74825001] ; [106.68263245,10.74878025] ; [106.68382263,10.74938965]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1436"
    ,"Station_Code":"Q8 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Nguyễn Văn Cừ"
    ,"Station_Address":"109-111, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.750469
    ,"Long":106.686602
    ,"Polyline":"[106.68382263,10.74938965] ; [106.68433380,10.74965000] ; [106.68547821,10.75018978] ; [106.68627167,10.75043964] ; [106.68679810,10.75061035]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1437"
    ,"Station_Code":"Q7 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Rạch Ông"
    ,"Station_Address":"1013, đường Tr ần Xuân Soạn, Quận 7"
    ,"Lat":10.751291
    ,"Long":106.692621
    ,"Polyline":"[106.68679810,10.75061035] ; [106.68733215,10.75076962] ; [106.68771362,10.75080967] ; [106.68816376,10.75067043] ; [106.68824768,10.75063038] ; [106.68833923,10.75061989] ; [106.68859863,10.75065994] ; [106.69090271,10.75109005] ; [106.69216156,10.75129986]"
    ,"Distance":"599"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1439"
    ,"Station_Code":"Q7 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh viện Tân Hưng"
    ,"Station_Address":"909, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751644
    ,"Long":106.694836
    ,"Polyline":"[106.69223785,10.75131989] ; [106.69396210,10.75162029] ; [106.69444275,10.75170040] ; [106.69515228,10.75172043]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1441"
    ,"Station_Code":"Q7 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"chùa Kiều  Đàm"
    ,"Station_Address":"807, đường Trần Xu ân Soạn, Quận 7"
    ,"Lat":10.751655
    ,"Long":106.698344
    ,"Polyline":"[106.69515228,10.75172043] ; [106.69743347,10.75174046]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1440"
    ,"Station_Code":"Q7 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ủy ban Phường Tân Hưng"
    ,"Station_Address":"725-727, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751691
    ,"Long":106.701713
    ,"Polyline":"[106.69743347,10.75174046] ; [106.70072174,10.75177002]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1447"
    ,"Station_Code":"Q7 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"603-601, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751726
    ,"Long":106.704552
    ,"Polyline":"[106.70072174,10.75177002] ; [106.70455170,10.75181007]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1988"
    ,"Station_Code":"Q7 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ủy ban Phường Tân Kiểng"
    ,"Station_Address":"525-527, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751728
    ,"Long":106.706874
    ,"Polyline":"[106.70455170,10.75181007] ; [106.70674896,10.75183010]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1990"
    ,"Station_Code":"Q7 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Bế Văn Cấm"
    ,"Station_Address":"429-431, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751739
    ,"Long":106.709052
    ,"Polyline":"[106.70674896,10.75183010.06.70903778]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1993"
    ,"Station_Code":"Q7 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Miếu Bà Cố"
    ,"Station_Address":"327, đường  Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751776
    ,"Long":106.71263
    ,"Polyline":"[106.70903778,10.75183010.06.71263123]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1992"
    ,"Station_Code":"Q7 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Nhà thờ Thuận Phát"
    ,"Station_Address":"253, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751818
    ,"Long":106.715451
    ,"Polyline":"[106.71263123,10.75187016] ; [106.71543884,10.75189018]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1995"
    ,"Station_Code":"Q7 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường Nguyễn Hữu Thọ"
    ,"Station_Address":"55/8, đường Lâm Văn Bền, Quận 7"
    ,"Lat":10.748334
    ,"Long":106.715806
    ,"Polyline":"[106.71543884,10.75189018] ; [106.71584320,10.75189018] ; [106.71584320,10.75043011] ; [106.71585083,10.74870968] ; [106.71584320,10.74827003]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1994"
    ,"Station_Code":"Q7 185"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Nguy ễn Thị Định"
    ,"Station_Address":"138, đường Lâm Văn Bền, Quận 7"
    ,"Lat":10.743159
    ,"Long":106.715806
    ,"Polyline":"[106.71584320,10.74827003] ; [106.71585846,10.74485016] ; [106.71585083,10.74442005] ; [106.71585846,10.74349976] ; [106.71585846,10.74330044]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1997"
    ,"Station_Code":"Q7 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Nguyễn Thị Thập"
    ,"Station_Address":"52A, đường Mai Văn Vĩnh, Quận 7"
    ,"Lat":10.739471
    ,"Long":106.713615
    ,"Polyline":"[106.71585846,10.74330044] ; [106.71585846,10.74298954] ; [106.71369171,10.74297047] ; [106.71369934,10.74203014] ; [106.71369934,10.73946953]"
    ,"Distance":"661"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1351"
    ,"Station_Code":"Q7 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Mai Văn V ĩnh"
    ,"Station_Address":"351, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738368
    ,"Long":106.714003
    ,"Polyline":"[106.71369934,10.73946953] ; [106.71369171,10.73849964] ; [106.71440887,10.73845959]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1352"
    ,"Station_Code":"Q7 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Lâm Văn B ền"
    ,"Station_Address":"269-271, đường Nguyễn  Thị Thập, Quận 7"
    ,"Lat":10.738152
    ,"Long":106.717522
    ,"Polyline":"[106.71440887,10.73845959] ; [106.71781921,10.73824978]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1996"
    ,"Station_Code":"Q7 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"195A, đường Nguy ễn Thị Thập, Quận 7"
    ,"Lat":10.737989
    ,"Long":106.720027
    ,"Polyline":"[106.71781921,10.73824978] ; [106.71959686,10.73812962] ; [106.72033691,10.73810005]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"840"
    ,"Station_Code":"Q7 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Đa Khoa"
    ,"Station_Address":"Đối diện 354, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.738937
    ,"Long":106.721798
    ,"Polyline":"[106.72033691,10.73810005] ; [106.72152710,10.73803997] ; [106.72174072,10.73803043] ; [106.72170258,10.73824978] ; [106.72171021,10.73890018]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"842"
    ,"Station_Code":"Q7 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cầu Lý Phục Man"
    ,"Station_Address":"Đối diện 404, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.742031
    ,"Long":106.721862
    ,"Polyline":"[106.72171021,10.73890018] ; [106.72177124,10.74203014]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"841"
    ,"Station_Code":"Q7 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"UBND P. Tân Thuận Tây"
    ,"Station_Address":"Đối diện UBND P. Tân Thuận Tây, đường Nguyễn Văn Linh , Quận 7"
    ,"Lat":10.746975
    ,"Long":106.721991
    ,"Polyline":"[106.72177124,10.74203014] ; [106.72178650,10.74322987] ; [106.72184753,10.74672985] ; [106.72187042,10.74699020]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"844"
    ,"Station_Code":"Q7 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu Tân Thuận 2"
    ,"Station_Address":"Đối diện 41, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.751307
    ,"Long":106.724174
    ,"Polyline":"[106.72187042,10.74699020] ; [106.72196198,10.74767971] ; [106.72203064,10.74800014] ; [106.72218323,10.74855042] ; [106.72241211,10.74915028] ; [106.72284698,10.74999046] ; [106.72299957,10.75020981] ; [106.72331238,10.75063038] ; [106.72351837,10.75086021] ; [106.72374725,10.75107002]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"843"
    ,"Station_Code":"Q7 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 49/2, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752498
    ,"Long":106.727414
    ,"Polyline":"[106.72374725,10.75107002] ; [106.72411346,10.75139046] ; [106.72440338,10.75160027] ; [106.72483826,10.75189972] ; [106.72545624,10.75220013] ; [106.72586823,10.75234985] ; [106.72624207,10.75245953] ; [106.72669220,10.75255013] ; [106.72730255,10.75261021]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"39"
    ,"Station_Id":"1999"
    ,"Station_Code":"BX 15"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Khu chế xu ất Tân Thuận"
    ,"Station_Address":"ĐẦU BẾN KCX TÂN THUẬN, đường Nguyễn V ăn Linh, Quận 7"
    ,"Lat":10.752883
    ,"Long":106.727501
    ,"Polyline":"[106.72730255,10.75261021] ; [106.72846985,10.75267029] ; [106.72846222,10.75277996] ; [106.72794342,10.75275993] ; [106.72750854,10.75273991]"
    ,"Distance":"244"
  }]