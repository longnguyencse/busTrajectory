export const Route63 =[

  {
     "Route_Id":"63"
    ,"Station_Id":"2479"
    ,"Station_Code":"BX77"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Chợ nông sản Thủ Đức"
    ,"Station_Address":"ĐẦU BẾN CHỢ NÔNG SẢN THỦ ĐỨC , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868857383728027
    ,"Long":106.72943115234375
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"347"
    ,"Station_Code":"QTD 195"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ đầu mối nông sản Thủ Đức"
    ,"Station_Address":"Chợ đầu mối nông sản Thủ Đức, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86812
    ,"Long":106.729158
    ,"Polyline":"[106.72962952,10.86896038] ; [106.72991180,10.86843967] ; [106.72882080,10.86787033]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"349"
    ,"Station_Code":"QTD 214"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã 4 Bình Phước"
    ,"Station_Address":"777, đường Quốc l ộ 13, Quận Thủ Đức"
    ,"Lat":10.863809
    ,"Long":106.72451
    ,"Polyline":"[106.72882080,10.86787033] ; [106.72811127,10.86750031] ; [106.72702026,10.86693001] ; [106.72646332,10.86676979] ; [106.72441864,10.86573029] ; [106.72399139,10.86561012] ; [106.72377777,10.86565018] ; [106.72368622,10.86561966] ; [106.72361755,10.86555958] ; [106.72355652,10.86544991] ; [106.72354889,10.86542034] ; [106.72355652,10.86528015] ; [106.72361755,10.86515045] ; [106.72366333,10.86507034] ; [106.72380066,10.86495018] ; [106.72390747,10.86491013] ; [106.72409058,10.86472034] ; [106.72431946,10.86429024] ; [106.72454834,10.86388969] ; [106.72457123,10.86384010]"
    ,"Distance":"862"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"350"
    ,"Station_Code":"QTD 215"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Hồ bơi Mèo Mun"
    ,"Station_Address":"Đối diện 782, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.861345
    ,"Long":106.724396
    ,"Polyline":"[106.72457123,10.86384010.06.72473907] ; [10.86353016,106.72483826] ; [10.86318016,106.72486877] ; [10.86281967,106.72486877] ; [10.86262989,106.72482300] ; [10.86233997,106.72450256] ; [10.86145020,106.72444916]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"353"
    ,"Station_Code":"QTD 216"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"UBND P.Hiệp Bình Phước"
    ,"Station_Address":"715, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.859791
    ,"Long":106.723782
    ,"Polyline":"[106.72444916,10.86131954] ; [106.72419739,10.86071014] ; [106.72392273,10.85991001] ; [106.72386932,10.85978031]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"351"
    ,"Station_Code":"QTD 217"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trạm y tế P. Hiệp Bình Phước"
    ,"Station_Address":"645, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.856024
    ,"Long":106.722343
    ,"Polyline":"[106.72386932,10.85978031] ; [106.72328186,10.85824966] ; [106.72283936,10.85709000] ; [106.72255707,10.85641003] ; [106.72241211,10.85599995]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"355"
    ,"Station_Code":"QTD 218"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã 3 Đ ường Hiệp Bình"
    ,"Station_Address":"607, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852579
    ,"Long":106.720719
    ,"Polyline":"[106.72241211,10.85599995] ; [106.72168732,10.85418034] ; [106.72133636,10.85344028] ; [106.72078705,10.85254002]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"352"
    ,"Station_Code":"QTD 219"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã 3 Hiệp Bình"
    ,"Station_Address":"557A, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.848727
    ,"Long":106.718346
    ,"Polyline":"[106.72078705,10.85254002] ; [106.71970367,10.85097980] ; [106.71938324,10.85054016] ; [106.71903229,10.84994030] ; [106.71888733,10.84965992] ; [106.71858978,10.84904957] ; [106.71842194,10.84869957]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"358"
    ,"Station_Code":"QTD 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cân Nhơn Hòa"
    ,"Station_Address":"447-449, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.844473
    ,"Long":106.718086
    ,"Polyline":"[106.71842194,10.84869957] ; [106.71826172,10.84827995] ; [106.71816254,10.84772968] ; [106.71811676,10.84702969] ; [106.71813965,10.84626007] ; [106.71816254,10.84447956] ; [106.71816254,10.84447002]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"354"
    ,"Station_Code":"QTD 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"385, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.84109
    ,"Long":106.716858
    ,"Polyline":"[106.71816254,10.84447002] ; [106.71817780,10.84362030] ; [106.71814728,10.84313011] ; [106.71807098,10.84270000] ; [106.71791077,10.84232998] ; [106.71782684,10.84216976] ; [106.71765137,10.84193993] ; [106.71736145,10.84158993] ; [106.71691895,10.84103966]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"359"
    ,"Station_Code":"QTD 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"327-329, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.83877
    ,"Long":106.714915
    ,"Polyline":"[106.71691895,10.84103966] ; [106.71498871,10.83872032]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"356"
    ,"Station_Code":"QTD 223"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"261, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.835822
    ,"Long":106.713745
    ,"Polyline":"[106.71498871,10.83872032] ; [106.71470642,10.83839035] ; [106.71434784,10.83794022] ; [106.71421814,10.83777046] ; [106.71411133,10.83755970] ; [106.71394348,10.83718967] ; [106.71386719,10.83691978] ; [106.71382904,10.83662033] ; [106.71382904,10.83598995] ; [106.71383667,10.83582973]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"357"
    ,"Station_Code":"QTD 224"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"173, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.83294
    ,"Long":106.71389
    ,"Polyline":"[106.71383667,10.83582973] ; [106.71389008,10.83508968] ; [106.71392822,10.83368015] ; [106.71396637,10.83294010]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"360"
    ,"Station_Code":"QTD 225"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"UBND P.Hiệp Bình Chánh"
    ,"Station_Address":"328/5 (Đại học Luật), đường Quốc lộ 13, Quận Thủ Đ ức"
    ,"Lat":10.830039
    ,"Long":106.714027
    ,"Polyline":"[106.71396637,10.83294010.06.71407318] ; [10.83065033,106.71411133]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh,  Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71411133,10.83003998] ; [106.71411896,10.82958984] ; [106.71415710,10.82874012] ; [106.71427155,10.82709980] ; [106.71421814,10.82666969] ; [106.71417236,10.82645988] ; [106.71411896,10.82631969] ; [106.71408081,10.82625008] ; [106.71405029,10.82623959] ; [106.71395874,10.82619953] ; [106.71385193,10.82608032] ; [106.71379089,10.82594967] ; [106.71379089,10.82581043] ; [106.71385956,10.82565975] ; [106.71389771,10.82561016] ; [106.71395111,10.82551956] ; [106.71395874,10.82530975] ; [106.71392822,10.82505035] ; [106.71385956,10.82472038] ; [106.71365356,10.82373047] ; [106.71360016,10.82353973] ; [106.71338654,10.82240963] ; [106.71317291,10.82098961] ; [106.71273804,10.81783962] ; [106.71263885,10.81770992] ; [106.71254730,10.81760979] ; [106.71222687,10.81737995] ; [106.71204376,10.81717968] ; [106.71183777,10.81707954] ; [106.71160889,10.81692028] ; [106.71128845,10.81663990]"
    ,"Distance":"1601"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường Đinh Bộ Lĩnh, Quận Bình  Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71128845,10.81663990] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71038818,10.81499958] ; [106.70954132,10.81330013] ; [106.70925140,10.81260014]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70925140,10.81260014] ; [106.70919037,10.81247044] ; [106.70913696,10.81227016] ; [106.70912933,10.81159019] ; [106.70913696,10.81058025] ; [106.70919037,10.80980968]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh  Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70919037,10.80980968] ; [106.70926666,10.80805969] ; [106.70937347,10.80710983] ; [106.70938873,10.80690956]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70938873,10.80690956] ; [106.70948792,10.80566978] ; [106.70947266,10.80506039] ; [106.70944214,10.80442047]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70944214,10.80442047] ; [106.70935059,10.80296993] ; [106.71051025,10.80290985]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"221 , đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71051025,10.80290985] ; [106.71114349,10.80286026] ; [106.71138763,10.80284023] ; [106.71137238,10.80249977] ; [106.71132660,10.80160999] ; [106.71128082,10.80160046] ; [106.71121979,10.80156994] ; [106.71115875,10.80150032] ; [106.71115112,10.80144024] ; [106.71115875,10.80136967] ; [106.71118164,10.80132008] ; [106.71125031,10.80126953] ; [106.71128082,10.80125046] ; [106.71130371,10.80125046] ; [106.71128082,10.80101967] ; [106.71122742,10.80066967] ; [106.71115875,10.79998016] ; [106.71115112,10.79981041]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường  TH Hồng Hà"
    ,"Station_Address":"153, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71115112,10.79981041] ; [106.71102905,10.79864025] ; [106.71092987,10.79813004] ; [106.71070862,10.79736042] ; [106.71057892,10.79699993] ; [106.71047211,10.79671955]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"369"
    ,"Station_Code":"QBTH 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu Th ị Điện máy tự do"
    ,"Station_Address":"151, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.794978
    ,"Long":106.709368
    ,"Polyline":"[106.71047211,10.79671955] ; [106.70999146,10.79553986] ; [106.70974731,10.79522038] ; [106.70942688,10.79487991]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"373"
    ,"Station_Code":"QBTH 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"79, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793534
    ,"Long":106.707979
    ,"Polyline":"[106.70942688,10.79487991] ; [106.70806122,10.79343987]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"370"
    ,"Station_Code":"Q1 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"2A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790694
    ,"Long":106.705259
    ,"Polyline":"[106.70806122,10.79343987] ; [106.70539093,10.79061031]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đài truyền hình"
    ,"Station_Address":"Đối diện 9, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70539093,10.79061031] ; [106.70334625,10.78841972] ; [106.70207977,10.78709984]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"1190"
    ,"Station_Code":"Q1 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"43, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785716
    ,"Long":106.702385
    ,"Polyline":"[106.70207977,10.78709984] ; [106.70159149,10.78658009] ; [106.70243835,10.78577995]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2146"
    ,"Station_Code":"Q1 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Cty Xổ S ố Kiến Thiết"
    ,"Station_Address":"Đối diện Central Plaza, đường Lê Duẩn, Quận 1"
    ,"Lat":10.78428
    ,"Long":106.702118
    ,"Polyline":"[106.70243835,10.78577995] ; [106.70307922,10.78518009] ; [106.70217896,10.78421974]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2771"
    ,"Station_Code":"Q1 159"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Pasteur"
    ,"Station_Address":"84, đường Nguyễn  Du, Quận 1"
    ,"Lat":10.77831
    ,"Long":106.699192
    ,"Polyline":"[106.70217896,10.78421974] ; [106.69959259,10.78149033] ; [106.69828796,10.78011036] ; [106.69921112,10.77925968] ; [106.69976044,10.77877045] ; [106.69930267,10.77824974]"
    ,"Distance":"920"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2774"
    ,"Station_Code":"Q1 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Nam Kỳ Khởi Nghĩa"
    ,"Station_Address":"100, đường Nguyễn Du, Quận 1"
    ,"Lat":10.777256
    ,"Long":106.698259
    ,"Polyline":"[106.69930267,10.77824974] ; [106.69834900,10.77717018]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"200"
    ,"Station_Code":"Q1 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Tòa Án Thành Phố"
    ,"Station_Address":"131, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.776052
    ,"Long":106.698647
    ,"Polyline":"[106.69834900,10.77717018] ; [106.69799805,10.77678013] ; [106.69873047,10.77614021]"
    ,"Distance":"164"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"199"
    ,"Station_Code":"Q1 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chùa Ông"
    ,"Station_Address":"Đối diện 96A, đường Nam K ỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.773957
    ,"Long":106.699722
    ,"Polyline":"[106.69873047,10.77614021] ; [106.69909668,10.77581978] ; [106.69954681,10.77466011] ; [106.69982147,10.77400017]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2773"
    ,"Station_Code":"Q1 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh viện Đa khoa Sài Gòn"
    ,"Station_Address":"108, đường Lê Lợi, Quận 1"
    ,"Lat":10.772507
    ,"Long":106.698952
    ,"Polyline":"[106.69982147,10.77400017] ; [106.70002747,10.77346039] ; [106.69983673,10.77326012] ; [106.69902039,10.77243996]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bến Tha ̀nh A"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69902039,10.77243996] ; [106.69883728,10.77225971] ; [106.69824982,10.77184010.06.69815826] ; [10.77176952,106.69803619] ; [10.77159977,106.69802094] ; [10.77138042,106.69805908] ; [10.77128983,106.69812775] ; [10.77122021,106.69818878] ; [10.77118015,106.69828796] ; [10.77116966,106.69840240] ; [10.77116966,106.69850159] ; [10.77120018,106.69860077] ; [10.77124977,106.69898224] ; [10.77095985,106.69879150] ; [10.77097034,106.69854736]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69854736,10.77087021] ; [106.69744873,10.77035046] ; [106.69615173,10.76978970] ; [106.69412994,10.76896954]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường L ê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69412994,10.76896954] ; [106.69238281,10.76828003] ; [106.69049072,10.76753044] ; [106.68995667,10.76846981] ; [106.68968964,10.76871967] ; [106.68936157,10.76838970] ; [106.68920898,10.76819992] ; [106.68907166,10.76811028]"
    ,"Distance":"685"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68907166,10.76811028] ; [106.68920898,10.76819992] ; [106.68995667,10.76846981] ; [106.69026184,10.76858997]"
    ,"Distance":"141"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76858997] ; [106.69268036,10.76959038] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"1451"
    ,"Station_Code":"Q1 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trần Hưng Đạo"
    ,"Station_Address":"197, đường Nguyễn  Thái Học, Quận 1"
    ,"Lat":10.768461
    ,"Long":106.694984
    ,"Polyline":"[106.69329834,10.76982975] ; [106.69412994,10.77013969] ; [106.69467163,10.76920033] ; [106.69509125,10.76852989]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"1344"
    ,"Station_Code":"Q1 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"65G, đường Nguyễn Thái Học, Quận 1"
    ,"Lat":10.766576
    ,"Long":106.696129
    ,"Polyline":"[106.69509125,10.76852989] ; [106.69522858,10.76828957] ; [106.69539642,10.76784039] ; [106.69590759,10.76700020] ; [106.69615936,10.76659012]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"1379"
    ,"Station_Code":"Q1 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"82 - 84, đường  Nguyễn Thái Học, Quận 1"
    ,"Lat":10.766109
    ,"Long":106.696686
    ,"Polyline":"[106.69615936,10.76659012] ; [106.69663239,10.76581001] ; [106.69692230,10.76531029] ; [106.69696808,10.76511955] ; [106.69716644,10.76476955] ; [106.69748688,10.76420975] ; [106.69766998,10.76436996] ; [106.69757080,10.76453018] ; [106.69731140,10.76498032] ; [106.69715881,10.76521015] ; [106.69699860,10.76535034] ; [106.69670868,10.76585007] ; [106.69658661,10.76605034]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"27"
    ,"Station_Code":"Q1 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"71C, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768327
    ,"Long":106.695847
    ,"Polyline":"[106.69658661,10.76605034] ; [106.69583130,10.76731968] ; [106.69554138,10.76780033] ; [106.69541168,10.76805973] ; [106.69573975,10.76842022]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69573975,10.76842022] ; [106.69744873,10.77035046] ; [106.69753265,10.77021980] ; [106.69838715,10.77060032]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2721"
    ,"Station_Code":"Q1 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bệnh viện Đa khoa Sài Gòn"
    ,"Station_Address":"125, đường Lê Lợi, Quận 1"
    ,"Lat":10.772139
    ,"Long":106.699219
    ,"Polyline":"[106.69838715,10.77060032] ; [106.69888306,10.77081013] ; [106.69898224,10.77095985] ; [106.69879150,10.77097034] ; [106.69744873,10.77035046] ; [106.69818878,10.77118015] ; [106.69840240,10.77116966] ; [106.69850159,10.77120018] ; [106.69860077,10.77124977] ; [106.69866180,10.77130985] ; [106.69872284,10.77140045] ; [106.69876099,10.77159023] ; [106.69873810,10.77169991] ; [106.69930267,10.77231026]"
    ,"Distance":"577"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2723"
    ,"Station_Code":"Q1 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Sài Gòn Centre"
    ,"Station_Address":"Đối diện 58, đường Lê Lợi, Quận 1"
    ,"Lat":10.773594
    ,"Long":106.700587
    ,"Polyline":"[106.69930267,10.77231026] ; [106.70050049,10.77359962]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2724"
    ,"Station_Code":"Q1 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Lê Thánh Tôn"
    ,"Station_Address":"144, đường Pasteur, Quận 1"
    ,"Lat":10.775088
    ,"Long":106.700768
    ,"Polyline":"[106.70050049,10.77359962] ; [106.70104980,10.77418995] ; [106.70099640,10.77433014] ; [106.70069122,10.77505016]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2725"
    ,"Station_Code":"Q1 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Sở Tài nguyên Môi trường"
    ,"Station_Address":"63, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.777108
    ,"Long":106.700386
    ,"Polyline":"[106.70069122,10.77505016] ; [106.69995880,10.77676010.06.70031738]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2569"
    ,"Station_Code":"Q1 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"TTTM Vincom"
    ,"Station_Address":"47, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.778568
    ,"Long":106.701721
    ,"Polyline":"[106.70031738,10.77717018] ; [106.70162964,10.77865028]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"44"
    ,"Station_Code":"Q1 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"Đối diện 115Ter, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.779881
    ,"Long":106.701536
    ,"Polyline":"[106.70162964,10.77865028] ; [106.70214844,10.77921009] ; [106.70147705,10.77980042]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"39"
    ,"Station_Code":"Q1 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bưu Điện Thành Phố"
    ,"Station_Address":"86, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.780645
    ,"Long":106.700673
    ,"Polyline":"[106.70147705,10.77980042] ; [106.70063019,10.78055954]"
    ,"Distance":"125"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2028"
    ,"Station_Code":"Q1T083"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Tòa Nhà  Kumho"
    ,"Station_Address":"Kumho Asiana Plaza, đường Lê Duẩn, Quận 1"
    ,"Lat":10.782015
    ,"Long":106.700243
    ,"Polyline":"[106.70063019,10.78055954] ; [106.69959259,10.78149033] ; [106.70018005,10.78211021]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2029"
    ,"Station_Code":"Q1 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Cty Xổ S ố Kiến Thiết"
    ,"Station_Address":"Sofitel Plaza , đường Lê Duẩn, Quận 1"
    ,"Lat":10.78417
    ,"Long":106.702303
    ,"Polyline":"[106.70018005,10.78211021] ; [106.70230103,10.78433990]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"1096"
    ,"Station_Code":"Q1 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Đại học Khoa học xã hội nhân v ăn"
    ,"Station_Address":"10, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785778
    ,"Long":106.702663
    ,"Polyline":"[106.70230103,10.78433990] ; [106.70307922,10.78518009] ; [106.70259857,10.78563023]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"293"
    ,"Station_Code":"Q1 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Thảo Cầm  Viên"
    ,"Station_Address":"3, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.789598
    ,"Long":106.70459
    ,"Polyline":"[106.70259857,10.78563023] ; [106.70159149,10.78658009] ; [106.70256805,10.78761005] ; [106.70334625,10.78841972] ; [106.70446777,10.78962994]"
    ,"Distance":"616"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"295"
    ,"Station_Code":"Q1 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu Thị Nghè"
    ,"Station_Address":"1A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790669
    ,"Long":106.705597
    ,"Polyline":"[106.70451355,10.78966999] ; [106.70552063,10.79074001]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"298"
    ,"Station_Code":"QBTH 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"22 B , đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793445
    ,"Long":106.70814
    ,"Polyline":"[106.70552063,10.79074001] ; [106.70809174,10.79347038]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trung  tâm Dưỡng Lão"
    ,"Station_Address":"138, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70809174,10.79347038] ; [106.70974731,10.79522038] ; [106.70999146,10.79553986] ; [106.71012878,10.79586029] ; [106.71057892,10.79699993] ; [106.71076202,10.79751968]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Vòng xoay  Hàng Xanh"
    ,"Station_Address":"246, đường Xô Viết Nghệ Tĩnh, Quận Bình  Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71076202,10.79751968] ; [106.71092987,10.79813004] ; [106.71101379,10.79852962] ; [106.71112061,10.79951000] ; [106.71114349,10.79975986]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71114349,10.79975986] ; [106.71124268,10.80076027] ; [106.71130371,10.80125046] ; [106.71134949,10.80123997] ; [106.71141052,10.80125999] ; [106.71148682,10.80130959] ; [106.71153259,10.80138016] ; [106.71153259,10.80148029] ; [106.71147919,10.80154991] ; [106.71141815,10.80158997] ; [106.71134186,10.80160999] ; [106.71132660,10.80160999] ; [106.71135712,10.80218983] ; [106.71138763,10.80284023] ; [106.71143341,10.80377960] ; [106.71147919,10.80475044]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Đài Li ệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ T ĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71147919,10.80475044] ; [106.71151733,10.80535984] ; [106.71154022,10.80655003] ; [106.71154022,10.80681992] ; [106.71156311,10.80747032] ; [106.71161652,10.80797005] ; [106.71167755,10.80821037] ; [106.71177673,10.80848980] ; [106.71190643,10.80883980] ; [106.71202850,10.80918026]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71202850,10.80918026] ; [106.71212006,10.80941010.06.71227264] ; [10.81005001,106.71235657]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152,  đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71235657,10.81079960] ; [106.71272278,10.81385994]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"304"
    ,"Station_Code":"QTD 198"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường  TH Bình Triệu"
    ,"Station_Address":"136, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.829247
    ,"Long":106.71434
    ,"Polyline":"[106.71272278,10.81385994] ; [106.71293640,10.81564045] ; [106.71305084,10.81651974] ; [106.71320343,10.81752968] ; [106.71324158,10.81793976] ; [106.71360016,10.82091999] ; [106.71389771,10.82341957] ; [106.71395111,10.82402992] ; [106.71395874,10.82425976] ; [106.71408081,10.82483006] ; [106.71418762,10.82528019] ; [106.71424866,10.82542038] ; [106.71430969,10.82551003] ; [106.71439362,10.82555008] ; [106.71452332,10.82567024] ; [106.71456146,10.82575035] ; [106.71457672,10.82583046] ; [106.71456909,10.82598972] ; [106.71450043,10.82612038] ; [106.71440887,10.82625008] ; [106.71437836,10.82647991] ; [106.71437836,10.82715034] ; [106.71430969,10.82845974] ; [106.71427917,10.82911015] ; [106.71427155,10.82923985]"
    ,"Distance":"1744"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"309"
    ,"Station_Code":"QTD 199"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"64/1, đường Quốc  lộ 13, Quận Thủ Đức"
    ,"Lat":10.832655
    ,"Long":106.714149
    ,"Polyline":"[106.71427155,10.82923985] ; [106.71415710,10.83108997] ; [106.71408844,10.83248043] ; [106.71408081,10.83265018]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"306"
    ,"Station_Code":"QTD 200"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"416, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.836135
    ,"Long":106.714012
    ,"Polyline":"[106.71408081,10.83265018] ; [106.71398926,10.83428955] ; [106.71394348,10.83520031] ; [106.71394348,10.83563042] ; [106.71392059,10.83613014]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"310"
    ,"Station_Code":"QTD 201"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"486, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.838815
    ,"Long":106.715317
    ,"Polyline":"[106.71391296,10.83619022] ; [106.71391296,10.83650970] ; [106.71394348,10.83681011] ; [106.71401215,10.83708000] ; [106.71412659,10.83742046] ; [106.71427917,10.83771038] ; [106.71449280,10.83800030] ; [106.71515656,10.83878040] ; [106.71524048,10.83887959]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"312"
    ,"Station_Code":"QTD 202"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"510, đường Quốc l ộ 13, Quận Thủ Đức"
    ,"Lat":10.841072
    ,"Long":106.71714
    ,"Polyline":"[106.71524048,10.83887959] ; [106.71601105,10.83979988] ; [106.71708679,10.84111023]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"307"
    ,"Station_Code":"QTD 203"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cân Nhơn Hòa"
    ,"Station_Address":"Cân Nhơn Hòa, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.844687
    ,"Long":106.718307
    ,"Polyline":"[106.71708679,10.84111023] ; [106.71772003,10.84187984] ; [106.71788025,10.84210014] ; [106.71803284,10.84237957] ; [106.71814728,10.84270954] ; [106.71823120,10.84305954] ; [106.71826172,10.84362984] ; [106.71824646,10.84469032]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"308"
    ,"Station_Code":"QTD 204"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 3 Hi ệp Bình"
    ,"Station_Address":"1/42A, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.848944
    ,"Long":106.718704
    ,"Polyline":"[106.71824646,10.84469032] ; [106.71823120,10.84589958] ; [106.71822357,10.84700966] ; [106.71823120,10.84759998] ; [106.71832275,10.84811974] ; [106.71843719,10.84848976] ; [106.71864319,10.84897995]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"314"
    ,"Station_Code":"QTD 205"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã 3  Đường Hiệp Bình"
    ,"Station_Address":"620, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852921
    ,"Long":106.721222
    ,"Polyline":"[106.71864319,10.84897995] ; [106.71903992,10.84974957] ; [106.71926880,10.85019016] ; [106.71974945,10.85093975] ; [106.72103119,10.85272980] ; [106.72116089,10.85295010]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"316"
    ,"Station_Code":"QTD 206"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm y tế Hiệp Bình Phước"
    ,"Station_Address":"702, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.855787
    ,"Long":106.722504
    ,"Polyline":"[106.72116089,10.85295010.06.72158813] ; [10.85377026,106.72202301] ; [10.85478020,106.72242737]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"311"
    ,"Station_Code":"QTD 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"UBND P .Hiệp Bình Phước"
    ,"Station_Address":"750, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.858809
    ,"Long":106.723663
    ,"Polyline":"[106.72242737,10.85581017] ; [106.72274017,10.85661030] ; [106.72328949,10.85807037] ; [106.72358704,10.85883045]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"313"
    ,"Station_Code":"QTD 208"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"784, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.861172
    ,"Long":106.724564
    ,"Polyline":"[106.72358704,10.85883045] ; [106.72450256,10.86120033]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"318"
    ,"Station_Code":"QTD 209"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngã 4 B ình Phước"
    ,"Station_Address":"828, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.863845
    ,"Long":106.724792
    ,"Polyline":"[106.72450256,10.86120033] ; [106.72486115,10.86213017] ; [106.72496033,10.86248016] ; [106.72498322,10.86283016] ; [106.72495270,10.86308956] ; [106.72486877,10.86340046] ; [106.72470093,10.86380005]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"315"
    ,"Station_Code":"QTD 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Đầu  Mối"
    ,"Station_Address":"120, đường Quốc lộ 1, Quận  Thủ Đức"
    ,"Lat":10.86689
    ,"Long":106.727425
    ,"Polyline":"[106.72470093,10.86380005] ; [106.72431946,10.86454964] ; [106.72418213,10.86485004] ; [106.72416687,10.86505985] ; [106.72418976,10.86513042] ; [106.72427368,10.86524010.06.72438049] ; [10.86532974,106.72454834] ; [10.86540985,106.72463989] ; [10.86544991,106.72666168] ; [10.86645985,106.72680664] ; [10.86657047,106.72705841] ; [10.86676025,106.72728729] ; [10.86688042,106.72740173]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"320"
    ,"Station_Code":"QTD 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Đầu Mối"
    ,"Station_Address":"160, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86831
    ,"Long":106.730198
    ,"Polyline":"[106.72740173,10.86693001] ; [106.73017120,10.86837959]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"63"
    ,"Station_Id":"2479"
    ,"Station_Code":"BX77"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ nông sản Thủ Đức"
    ,"Station_Address":"ĐẦU BẾN CHỢ N ÔNG SẢN THỦ ĐỨC, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868857383728027
    ,"Long":106.72943115234375
    ,"Polyline":"[106.73017120,10.86837959] ; [106.73184967,10.86923027] ; [106.73319244,10.86993027] ; [106.73339081,10.87003040] ; [106.73359680,10.87001038] ; [106.73372650,10.86997986] ; [106.73384857,10.86989975] ; [106.73400116,10.86944008] ; [106.73419189,10.86880016] ; [106.73419189,10.86872959] ; [106.73415375,10.86859989] ; [106.73404694,10.86849022] ; [106.73390198,10.86845016] ; [106.73374939,10.86847019] ; [106.73361206,10.86855984] ; [106.73314667,10.87007046] ; [106.73277283,10.87137032] ; [106.73284149,10.87150955] ; [106.73293304,10.87160969] ; [106.73304749,10.87166023] ; [106.73317719,10.87166023] ; [106.73330688,10.87160015] ; [106.73336792,10.87154961] ; [106.73361206,10.87073040] ; [106.73362732,10.87063980] ; [106.73361969,10.87053013] ; [106.73355865,10.87040043] ; [106.73342896,10.87020016] ; [106.73307800,10.87003994] ; [106.73204041,10.86952972] ; [106.72991180,10.86843967] ; [106.72975159,10.86874008] ; [106.72962952,10.86896038]"
    ,"Distance":"1737"
  }]