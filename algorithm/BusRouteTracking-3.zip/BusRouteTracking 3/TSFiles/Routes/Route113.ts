export const Route113 =[

  {
     "Route_Id":"113"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"KCN LÊ MINH XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường  Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3304"
    ,"Station_Code":"HBC 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường  mầm non Thiên Ân"
    ,"Station_Address":"G15/25, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.748498
    ,"Long":106.540749
    ,"Polyline":"[106.53951263,10.74420834] ; [106.53951263,10.74421024] ; [106.53942108,10.74427032] ; [106.53952026,10.74442005] ; [106.53990936,10.74488735] ; [106.53934479,10.74521923] ; [106.54074860,10.74849796]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3306"
    ,"Station_Code":"HBC 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty Đại Vĩnh Lợi"
    ,"Station_Address":"G15 /2A, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.75206
    ,"Long":106.542326
    ,"Polyline":"[106.54074860,10.74849796] ; [106.54232788,10.75205994]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3305"
    ,"Station_Code":"HBC 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cổng 4"
    ,"Station_Address":"G14/11, đường Láng Le b àu Cò, Huyện Bình Chánh"
    ,"Lat":10.755866
    ,"Long":106.544015
    ,"Polyline":"[106.54232788,10.75205994] ; [106.54401398,10.75586605]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3308"
    ,"Station_Code":"HBC 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cổng 3"
    ,"Station_Address":"G13/27B, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.759123
    ,"Long":106.54567
    ,"Polyline":"[106.54401398,10.75586605] ; [106.54566956,10.75912285]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3307"
    ,"Station_Code":"HBC 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Cổng 2"
    ,"Station_Address":"G12/28B, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.761736
    ,"Long":106.547073
    ,"Polyline":"[106.54566956,10.75912285] ; [106.54707336,10.76173592]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3309"
    ,"Station_Code":"HBC 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cổng 1 - Ngã tư Bà Lát"
    ,"Station_Address":"G12/8, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.765779
    ,"Long":106.549305
    ,"Polyline":"[106.54707336,10.76173592] ; [106.54930878,10.76577854]"
    ,"Distance":"512"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3310"
    ,"Station_Code":"HBC 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Sập"
    ,"Station_Address":"G111/11, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.768651
    ,"Long":106.550785
    ,"Polyline":"[106.54930878,10.76577854] ; [106.55078125,10.76865101]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3311"
    ,"Station_Code":"HBC 302"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty Thịnh Uy"
    ,"Station_Address":"Đối diện 1A/38/1, đường Trần Văn Giàu , Huyện Bình Chánh"
    ,"Lat":10.767349
    ,"Long":106.557877
    ,"Polyline":"[106.55078125,10.76865101] ; [106.55125427,10.76958847] ; [106.55174255,10.77050591] ; [106.55427551,10.76918793] ; [106.55787659,10.76734924]"
    ,"Distance":"989"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3313"
    ,"Station_Code":"HBC 303"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Coop Mart Vĩnh Lộc B"
    ,"Station_Address":"Đối diện 1A/24/2, đường Trần Văn Giàu , Huyện Bình Chánh"
    ,"Lat":10.764925
    ,"Long":106.563097
    ,"Polyline":"[106.55787659,10.76734924] ; [106.56309509,10.76492500]"
    ,"Distance":"631"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3312"
    ,"Station_Code":"HBC 304"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Võ Văn Vân"
    ,"Station_Address":"Đối diện 1A/7, đ ường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.763033
    ,"Long":106.567174
    ,"Polyline":"[106.56309509,10.76492500] ; [106.56549835,10.76389027] ; [106.56717682,10.76303291]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"4598"
    ,"Station_Code":"T0044"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trần Văn  Giàu"
    ,"Station_Address":"Trần Văn Giàu, đư ờng Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.762147
    ,"Long":106.569786
    ,"Polyline":"[106.56717682,10.76303291] ; [106.56978607,10.76214695]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3446"
    ,"Station_Code":"QBT 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cầu T ân Tạo"
    ,"Station_Address":"Đ/d 1800, đường T ỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.76113
    ,"Long":106.571632
    ,"Polyline":"[106.56978607,10.76214695] ; [106.57163239,10.76113033]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3445"
    ,"Station_Code":"QBT 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Giai Hồng Phát"
    ,"Station_Address":"1749, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình  Tân"
    ,"Lat":10.759614
    ,"Long":106.575447
    ,"Polyline":"[106.57164764,10.76117039] ; [106.57228088,10.76088047] ; [106.57308960,10.76054955] ; [106.57401276,10.76012993] ; [106.57460022,10.75986004] ; [106.57482147,10.75979996] ; [106.57502747,10.75973988] ; [106.57544708,10.75961971]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3448"
    ,"Station_Code":"QBT 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Phòng khám Đa khoa Khánh An"
    ,"Station_Address":"1689, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.758846
    ,"Long":106.578438
    ,"Polyline":"[106.57544708,10.75961971] ; [106.57631683,10.75938988] ; [106.57765198,10.75905991] ; [106.57843781,10.75885963]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3447"
    ,"Station_Code":"QBT 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Mầm non Vy Vy"
    ,"Station_Address":"1581, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam , Quận Bình Tân"
    ,"Lat":10.758222
    ,"Long":106.580635
    ,"Polyline":"[106.57843781,10.75885963] ; [106.57990265,10.75846004] ; [106.58065033,10.75827980]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3450"
    ,"Station_Code":"QBT 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu vượt Tân Tạo - Chợ Đệm"
    ,"Station_Address":"1441, đường Tỉnh lộ 10,T ân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.757578
    ,"Long":106.583069
    ,"Polyline":"[106.58065033,10.75827980] ; [106.58307648,10.75765038]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3449"
    ,"Station_Code":"QBT 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Phòng  Y học Cổ truyền"
    ,"Station_Address":"1335, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.756835
    ,"Long":106.586945
    ,"Polyline":"[106.58306885,10.75757790] ; [106.58307648,10.75765038] ; [106.58402252,10.75740433] ; [106.58522797,10.75706673] ; [106.58654785,10.75678825] ; [106.58693695,10.75685024] ; [106.58694458,10.75683498]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"1790"
    ,"Station_Code":"QBT 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Khu Công nghiệp Tân Tạo"
    ,"Station_Address":"666, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.752793
    ,"Long":106.592392
    ,"Polyline":"[106.58694458,10.75683498] ; [106.58694458,10.75683498] ; [106.58693695,10.75685024] ; [106.58882904,10.75680351] ; [106.59168243,10.75647640] ; [106.59233856,10.75295639] ; [106.59217072,10.75279999] ; [106.59212494,10.75279331] ; [106.59212494,10.75279331]"
    ,"Distance":"952"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3777"
    ,"Station_Code":"QBT 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nguyễn Cửu Phú"
    ,"Station_Address":"4539, đường Nguy ễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.756076
    ,"Long":106.586496
    ,"Polyline":"[106.59212494,10.75279331] ; [106.59212494,10.75279331] ; [106.59217072,10.75279999] ; [106.59320831,10.75022125] ; [106.59068298,10.74967289] ; [106.59051514,10.75006866] ; [106.59062958,10.75151253] ; [106.59089661,10.75485325] ; [106.59046936,10.75492764] ; [106.59027100,10.75523853] ; [106.58943176,10.75660896] ; [106.58932495,10.75684071] ; [106.58858490,10.75693512] ; [106.58761597,10.75694084] ; [106.58649445,10.75683498] ; [106.58654022,10.75603962] ; [106.58649445,10.75607586] ; [106.58649445,10.75607586]"
    ,"Distance":"1879"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3778"
    ,"Station_Code":"QBT 170"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Lê Ngung"
    ,"Station_Address":"4443, đường Nguy ễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.751154
    ,"Long":106.585493
    ,"Polyline":"[106.58654022,10.75603962] ; [106.58657074,10.75564003] ; [106.58657074,10.75543022] ; [106.58647919,10.75500011] ; [106.58630371,10.75422955] ; [106.58590698,10.75265980] ; [106.58553314,10.75113010]"
    ,"Distance":"571"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3779"
    ,"Station_Code":"QBT 169"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Chùa Bình An"
    ,"Station_Address":"4403, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.744519
    ,"Long":106.584157
    ,"Polyline":"[106.58553314,10.75113010.06.58528900] ; [10.75004959,106.58518982] ; [10.74950027,106.58515930] ; [10.74915028,106.58515930] ; [10.74882030,106.58509827] ; [10.74829960,106.58497620] ; [10.74771023,106.58467102] ; [10.74656010.06.58437347,10.74557972] ; [106.58410645,10.74462986]"
    ,"Distance":"761"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3780"
    ,"Station_Code":"QBT 168"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Công ty thiết bị vệ sinh"
    ,"Station_Address":"4367/4, đường Nguy ễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.739348
    ,"Long":106.582709
    ,"Polyline":"[106.58410645,10.74462986] ; [106.58329010,10.74153996] ; [106.58267212,10.73927975]"
    ,"Distance":"638"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3781"
    ,"Station_Code":"QBT 167"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"nhà thờ Họ Thịnh"
    ,"Station_Address":"Kế nhà thờ Họ Thịnh, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.734889
    ,"Long":106.581207
    ,"Polyline":"[106.58267212,10.73927975] ; [106.58184814,10.73628998] ; [106.58155060,10.73525047] ; [106.58144379,10.73482990]"
    ,"Distance":"549"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3782"
    ,"Station_Code":"HBC 346"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bờ bao Xóm Hố"
    ,"Station_Address":"1575, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.730536
    ,"Long":106.581341
    ,"Polyline":"[106.58144379,10.73482990] ; [106.58120728,10.73396015] ; [106.58119202,10.73348045] ; [106.58123779,10.73299026] ; [106.58128357,10.73264980] ; [106.58129883,10.73178959] ; [106.58132172,10.73054028]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3783"
    ,"Station_Code":"HBC 347"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bờ bao Xóm Hố"
    ,"Station_Address":"1513 , đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.728565
    ,"Long":106.581266
    ,"Polyline":"[106.58134460,10.73053646] ; [106.58132172,10.73054028] ; [106.58135223,10.73003006] ; [106.58132935,10.72939014] ; [106.58126831,10.72856522]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3784"
    ,"Station_Code":"HBC 348"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Điện m áy Công Thảo"
    ,"Station_Address":"kế 1317, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.723009
    ,"Long":106.581357
    ,"Polyline":"[106.58133698,10.72852993] ; [106.58136749,10.72766018] ; [106.58138275,10.72531986] ; [106.58139801,10.72307968]"
    ,"Distance":"625"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3785"
    ,"Station_Code":"HBC 349"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường Tân Kiên"
    ,"Station_Address":"Đối diện Trường Tân Kiên, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.716152
    ,"Long":106.581464
    ,"Polyline":"[106.58139801,10.72307968] ; [106.58146667,10.71615982]"
    ,"Distance":"780"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3786"
    ,"Station_Code":"HBC 350"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Công ty Hồng Ngọc Mai"
    ,"Station_Address":"889-891, đường Nguyễn Cửu Phú, Huyện B ình Chánh"
    ,"Lat":10.71135
    ,"Long":106.580896
    ,"Polyline":"[106.58146667,10.71615982] ; [106.58148956,10.71376038] ; [106.58144379,10.71327972] ; [106.58126068,10.71286011] ; [106.58100891,10.71222019] ; [106.58093262,10.71191025] ; [106.58087158,10.71131992]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3787"
    ,"Station_Code":"HBC 351"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Mầm non Minh Thư"
    ,"Station_Address":"Cột điện 69P , đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.704466
    ,"Long":106.580365
    ,"Polyline":"[106.58087158,10.71131992] ; [106.58049774,10.70615005] ; [106.58036041,10.70448017]"
    ,"Distance":"769"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3789"
    ,"Station_Code":"HBC 352"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"cầu Ch ợ Đệm"
    ,"Station_Address":"Đối diện C11/65, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.697419
    ,"Long":106.579839
    ,"Polyline":"[106.58036041,10.70448017] ; [106.58004761,10.69997025] ; [106.57993317,10.69853973] ; [106.57987213,10.69744015]"
    ,"Distance":"792"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3788"
    ,"Station_Code":"HBC 415"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chùa Tường Văn"
    ,"Station_Address":"Đối diện cột điện 2AT, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.696902
    ,"Long":106.579045
    ,"Polyline":"[106.57984161,10.69741917] ; [106.57987213,10.69744015] ; [106.57971954,10.69595909] ; [106.57934570,10.69645405] ; [106.57904816,10.69690228]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3791"
    ,"Station_Code":"HBC 416"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Cầu Chợ Đệm"
    ,"Station_Address":"Đối diện cột điện 9AT, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.699164
    ,"Long":106.577581
    ,"Polyline":"[106.57904816,10.69690228] ; [106.57828522,10.69803524] ; [106.57758331,10.69916439]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3790"
    ,"Station_Code":"HBC 417"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Đình Phục Đức"
    ,"Station_Address":"Đình Phục Đức, đường Thế Lữ, Huyện Bình  Chánh"
    ,"Lat":10.700497
    ,"Long":106.575397
    ,"Polyline":"[106.57758331,10.69916439] ; [106.57716370,10.69973850] ; [106.57625580,10.70010757] ; [106.57539368,10.70049667]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3793"
    ,"Station_Code":"HBC 419"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Tân Tạo - Chợ Đệm"
    ,"Station_Address":"Đối diện cột điện 280T, đường Thế Lữ, Huyện Bình Ch ánh"
    ,"Lat":10.702495
    ,"Long":106.571792
    ,"Polyline":"[106.57539368,10.70049667] ; [106.57424164,10.70120335] ; [106.57271576,10.70218372] ; [106.57254028,10.70226860] ; [106.57226563,10.70231533] ; [106.57179260,10.70249462]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"2156"
    ,"Station_Code":"HBC 410"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Thiên Giang"
    ,"Station_Address":"A14 /7, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.692385
    ,"Long":106.577436
    ,"Polyline":"[106.57179260,10.70249462] ; [106.57179260,10.70249462] ; [106.57120514,10.70265293] ; [106.56690979,10.68430901] ; [106.58536530,10.68810463] ; [106.58425140,10.69413471] ; [106.57743835,10.69238472] ; [106.57743835,10.69238472]"
    ,"Distance":"5678"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"2159"
    ,"Station_Code":"HBC 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bùi Thanh  Khiết"
    ,"Station_Address":"B2/15E, đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.689628
    ,"Long":106.574721
    ,"Polyline":"[106.57743073,10.69235992] ; [106.57399750,10.69165039] ; [106.57472992,10.68962002]"
    ,"Distance":"628"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3792"
    ,"Station_Code":"HBC 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Bùi Thanh Khiết"
    ,"Station_Address":"C8/8, đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.684104
    ,"Long":106.576717
    ,"Polyline":"[106.57472229,10.68962765] ; [106.57493591,10.68915844] ; [106.57641602,10.68487835] ; [106.57671356,10.68410397]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3795"
    ,"Station_Code":"HBC 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bùi Thanh Khiết"
    ,"Station_Address":"Đối diện C3/15, đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.679249
    ,"Long":106.578525
    ,"Polyline":"[106.57672119,10.68414021] ; [106.57853699,10.67928028]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3794"
    ,"Station_Code":"HBC 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bùi Thanh Khiết"
    ,"Station_Address":"C4/19A, đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.67558
    ,"Long":106.579893
    ,"Polyline":"[106.57853699,10.67928028] ; [106.57990265,10.67562962]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"644"
    ,"Station_Code":"HBC 371"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trịnh Như Khuê"
    ,"Station_Address":"A17/8, đường Quốc  lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.670561
    ,"Long":106.576653
    ,"Polyline":"[106.57990265,10.67562962] ; [106.58049774,10.67403984] ; [106.57974243,10.67325974] ; [106.57919312,10.67271996]"
    ,"Distance":"766"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"645"
    ,"Station_Code":"HBC 372"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Trường Trần Đại Nghĩa"
    ,"Station_Address":"A16/4, đường Quốc lộ 1A, Huyện Bình Ch ánh"
    ,"Lat":10.668874
    ,"Long":106.57455
    ,"Polyline":"[106.57665253,10.67056084] ; [106.57454681,10.66887379]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"646"
    ,"Station_Code":"HBC 373"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Bình Chánh"
    ,"Station_Address":"A13/7, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.66647
    ,"Long":106.571503
    ,"Polyline":"[106.57454681,10.66887379] ; [106.57150269,10.66646957]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3720"
    ,"Station_Code":"BX 57"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Chợ Bình Chánh"
    ,"Station_Address":"ĐẦU BẾN CHỢ BÌNH CHÁNH, đường Quốc lộ 1A,  Huyện Bình Chánh"
    ,"Lat":10.665985
    ,"Long":106.571835
    ,"Polyline":"[106.57150269,10.66646957] ; [106.57150269,10.66646957] ; [106.56964874,10.66483593] ; [106.56982422,10.66467285] ; [106.57131195,10.66585827] ; [106.57183838,10.66598511] ; [106.57183838,10.66598511]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3720"
    ,"Station_Code":"BX 57"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Chợ Bình Chánh"
    ,"Station_Address":"ĐẦU BẾN CHỢ BÌNH CHÁNH, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.665985
    ,"Long":106.571835
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"699"
    ,"Station_Code":"HBC 380"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Bình Chánh"
    ,"Station_Address":"D6/33, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.666301
    ,"Long":106.571835
    ,"Polyline":"[106.57122040,10.66586971] ; [106.57180023,10.66633987]"
    ,"Distance":"82"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"698"
    ,"Station_Code":"HBC 381"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường Trần Đại Nghĩa"
    ,"Station_Address":"D6/18A, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.668742
    ,"Long":106.574904
    ,"Polyline":"[106.57180023,10.66633987] ; [106.57328033,10.66751003] ; [106.57482147,10.66876030] ; [106.57562256,10.66940022]"
    ,"Distance":"539"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3722"
    ,"Station_Code":"HBC 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Bùi Thanh Khiết"
    ,"Station_Address":"Đối diện 4 /15, đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.676107
    ,"Long":106.579791
    ,"Polyline":"[106.57562256,10.66940022] ; [106.57740021,10.67084980] ; [106.57816315,10.67150021] ; [106.57911682,10.67245007] ; [106.58016205,10.67350006] ; [106.58058929,10.67391014] ; [106.58049774,10.67403984] ; [106.57972717,10.67605972]"
    ,"Distance":"998"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3724"
    ,"Station_Code":"HBC 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bùi Thanh  Khiết"
    ,"Station_Address":"C3/15, đường Bu ̀i Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.679602
    ,"Long":106.578476
    ,"Polyline":"[106.57972717,10.67605972] ; [106.57843018,10.67957020]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3721"
    ,"Station_Code":"HBC 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bùi Thanh  Khiết"
    ,"Station_Address":"Cột điện 22L C2 /17E, đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.684162
    ,"Long":106.576781
    ,"Polyline":"[106.57843018,10.67957020] ; [106.57672119,10.68412971]"
    ,"Distance":"540"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"2240"
    ,"Station_Code":"HBC 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"C1/4 , đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.689976
    ,"Long":106.574684
    ,"Polyline":"[106.57699585,10.68422508] ; [106.57475281,10.68999195]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"2241"
    ,"Station_Code":"HBC 397"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Thiên Giang"
    ,"Station_Address":"14/2, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.692506
    ,"Long":106.578412
    ,"Polyline":"[106.57460785,10.68994045] ; [106.57399750,10.69165039] ; [106.57807922,10.69250011] ; [106.57842255,10.69256973]"
    ,"Distance":"745"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3723"
    ,"Station_Code":"HBC 447"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Tân Tạo - Chợ Đệm"
    ,"Station_Address":"Cột điện 21T, đường Thế Lữ, Huyện Bình  Chánh"
    ,"Lat":10.702305
    ,"Long":106.572044
    ,"Polyline":"[106.57841492,10.69250584] ; [106.57841492,10.69250584] ; [106.58415985,10.69406128] ; [106.58517456,10.68803120] ; [106.56686401,10.68454075] ; [106.57131195,10.70263195] ; [106.57204437,10.70230484] ; [106.57204437,10.70230484]"
    ,"Distance":"5533"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3725"
    ,"Station_Code":"HBC 448"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Đình Phục Đức"
    ,"Station_Address":"Đình Phục Đức (cột điện 18T ), đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.70036
    ,"Long":106.575456
    ,"Polyline":"[106.57204437,10.70230484] ; [106.57226563,10.70224190] ; [106.57250214,10.70217896] ; [106.57266235,10.70212078] ; [106.57405853,10.70121956] ; [106.57491302,10.70068169] ; [106.57545471,10.70036030]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3727"
    ,"Station_Code":"HBC 449"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cầu Ch ợ Đệm"
    ,"Station_Address":"9AT, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.699169
    ,"Long":106.577446
    ,"Polyline":"[106.57545471,10.70036030] ; [106.57695770,10.69974327] ; [106.57711792,10.69965363] ; [106.57744598,10.69916916]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3728"
    ,"Station_Code":"HBC 450"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Chùa Trường Văn"
    ,"Station_Address":"Cột điện 2AT, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.69696
    ,"Long":106.578884
    ,"Polyline":"[106.57744598,10.69916916] ; [106.57814789,10.69806194] ; [106.57888031,10.69696045]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3726"
    ,"Station_Code":"HBC 353"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bi da Khánh Hội"
    ,"Station_Address":"C11/65, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.697256
    ,"Long":106.579925
    ,"Polyline":"[106.57888031,10.69696045] ; [106.57890320,10.69690990] ; [106.57929230,10.69639111] ; [106.57962799,10.69589996] ; [106.57980347,10.69572639] ; [106.57984924,10.69602776] ; [106.57991028,10.69706059] ; [106.57992554,10.69725609]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3729"
    ,"Station_Code":"HBC 354"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Thánh thất Cao Đài"
    ,"Station_Address":"290, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.701293
    ,"Long":106.580231
    ,"Polyline":"[106.57992554,10.69725609] ; [106.58023071,10.70129299]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3730"
    ,"Station_Code":"HBC 355"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Công ty Hồng Ngọc Mai"
    ,"Station_Address":"D16/25A, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.704646
    ,"Long":106.580483
    ,"Polyline":"[106.58023071,10.70129299] ; [106.58048248,10.70464611]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3732"
    ,"Station_Code":"HBC 356"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trạm xăng Lai Lai"
    ,"Station_Address":"D17/24A, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.707935
    ,"Long":106.580724
    ,"Polyline":"[106.58048248,10.70464611] ; [106.58072662,10.70793533]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3731"
    ,"Station_Code":"HBC 357"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Qua cầu Mỹ Phú"
    ,"Station_Address":"878-A10/17, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.71145
    ,"Long":106.580998
    ,"Polyline":"[106.58072662,10.70793533] ; [106.58100128,10.71144962]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3733"
    ,"Station_Code":"HBC 358"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường tiểu học Tân Kiên"
    ,"Station_Address":"A11/28, đường Nguyễn Cửu Phú, Huyện B ình Chánh"
    ,"Lat":10.717506
    ,"Long":106.581818
    ,"Polyline":"[106.58088684,10.71146011] ; [106.58093262,10.71191025] ; [106.58100891,10.71222019] ; [106.58126068,10.71286011] ; [106.58144379,10.71327972] ; [106.58148956,10.71376038] ; [106.58145905,10.71669006] ; [106.58145905,10.71695042] ; [106.58145905,10.71739960] ; [106.58149719,10.71737957] ; [106.58174133,10.71730042]"
    ,"Distance":"741"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3735"
    ,"Station_Code":"HBC 359"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Công ty Nam Long"
    ,"Station_Address":"A4/4T, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.724127
    ,"Long":106.581448
    ,"Polyline":"[106.58174133,10.71730042] ; [106.58145905,10.71739960] ; [106.58142853,10.72000980] ; [106.58139038,10.72412968]"
    ,"Distance":"813"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3739"
    ,"Station_Code":"HBC 360"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã tư Lò Mổ"
    ,"Station_Address":"A1/15, đ ường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.728407
    ,"Long":106.581411
    ,"Polyline":"[106.58145142,10.72412682] ; [106.58141327,10.72840691]"
    ,"Distance":"476"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3734"
    ,"Station_Code":"HBC 361"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu B à Bộ"
    ,"Station_Address":"A1/4, đường Nguyễn Cửu Phú, Huyện Bình Chánh"
    ,"Lat":10.730705
    ,"Long":106.581427
    ,"Polyline":"[106.58141327,10.72840691] ; [106.58135986,10.72938728] ; [106.58145905,10.73016167] ; [106.58142853,10.73070526]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3741"
    ,"Station_Code":"QBT 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Giày Gia Định"
    ,"Station_Address":"Đối diện 4333, đường Nguyễn Cửu Phú, Qu ận Bình Tân"
    ,"Lat":10.734062
    ,"Long":106.581325
    ,"Polyline":"[106.58142853,10.73070526] ; [106.58135986,10.73179054] ; [106.58125305,10.73365116] ; [106.58132172,10.73406219]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3736"
    ,"Station_Code":"QBT 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Tân Vĩnh Cường"
    ,"Station_Address":"Đối diện 160, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.738389
    ,"Long":106.582425
    ,"Polyline":"[106.58132172,10.73406219] ; [106.58155060,10.73525047] ; [106.58184814,10.73628998] ; [106.58242798,10.73840046] ; [106.58242798,10.73838902]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3737"
    ,"Station_Code":"QBT 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nghĩa trang An Vĩnh"
    ,"Station_Address":"Đối diện 4379, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.743797
    ,"Long":106.58405
    ,"Polyline":"[106.58242798,10.73838902] ; [106.58405304,10.74379730]"
    ,"Distance":"628"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3738"
    ,"Station_Code":"QBT 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Cầu Kinh"
    ,"Station_Address":"4378 , đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.750869
    ,"Long":106.585557
    ,"Polyline":"[106.58390045,10.74384022] ; [106.58419037,10.74491024] ; [106.58467102,10.74656010.06.58503723] ; [10.74796963,106.58513641] ; [10.74855995,106.58515167] ; [10.74907970,106.58518219] ; [10.74929047,106.58522034] ; [10.74971008,106.58547211]"
    ,"Distance":"830"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3740"
    ,"Station_Code":"QBT 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm y  tế phường Tân Tạo"
    ,"Station_Address":"4430, đường Nguy ễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.755644
    ,"Long":106.586604
    ,"Polyline":"[106.58547211,10.75086975] ; [106.58589935,10.75259972] ; [106.58621979,10.75389004] ; [106.58653259,10.75522995] ; [106.58657074,10.75553989] ; [106.58657074,10.75566006]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3449"
    ,"Station_Code":"QBT 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Phòng Y học Cổ truyền"
    ,"Station_Address":"1335, đường  Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.756835
    ,"Long":106.586945
    ,"Polyline":"[106.58660126,10.75564384] ; [106.58656311,10.75677204] ; [106.58694458,10.75683498]"
    ,"Distance":"168"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"1858"
    ,"Station_Code":"QBT 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"KCN Tân Tạo"
    ,"Station_Address":"56, đường Quốc lộ 1A, Quận Bình Tân"
    ,"Lat":10.752967
    ,"Long":106.592692
    ,"Polyline":"[106.58694458,10.75683498] ; [106.58856201,10.75683498] ; [106.59175110,10.75643444] ; [106.59229279,10.75291443]"
    ,"Distance":"925"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3462"
    ,"Station_Code":"QBT 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"1730-1370, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận B ình Tân"
    ,"Lat":10.756949
    ,"Long":106.586159
    ,"Polyline":"[106.59229279,10.75291443] ; [106.59229279,10.75291443] ; [106.59229279,10.75291443] ; [106.59317780,10.75024700] ; [106.59296417,10.75016880] ; [106.59066772,10.74968910.06.59052277] ; [10.75007915,106.59096527] ; [10.75486374,106.59054565] ; [10.75496960,106.58934784] ; [10.75684547,106.58822632] ; [10.75696182,106.58654785] ; [10.75690937,106.58615875] ; [10.75694942,106.58615875] ; [10.75694942,106.58615875]"
    ,"Distance":"1819"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3466"
    ,"Station_Code":"QBT 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Khang Mỹ Lạc"
    ,"Station_Address":"1480, đường Tỉnh lộ 10,Tân  Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.757694
    ,"Long":106.583252
    ,"Polyline":"[106.58615875,10.75694942] ; [106.58615112,10.75693989] ; [106.58325195,10.75769424]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3463"
    ,"Station_Code":"QBT 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Đạt H òa"
    ,"Station_Address":"1598, đường Tỉnh lộ 10 ,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.758303
    ,"Long":106.580856
    ,"Polyline":"[106.58325195,10.75769424] ; [106.58085632,10.75830269]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3464"
    ,"Station_Code":"QBT 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Bà Hom"
    ,"Station_Address":"1724, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam , Quận Bình Tân"
    ,"Lat":10.758835
    ,"Long":106.57856
    ,"Polyline":"[106.58085632,10.75830269] ; [106.58054352,10.75837898] ; [106.57990265,10.75851631] ; [106.57894135,10.75877476] ; [106.57855988,10.75883484]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3465"
    ,"Station_Code":"QBT 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Bà Hom"
    ,"Station_Address":"1754, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh , Việt Nam, Quận Bình Tân"
    ,"Lat":10.759585
    ,"Long":106.57563
    ,"Polyline":"[106.57855988,10.75883484] ; [106.57563019,10.75958538]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3468"
    ,"Station_Code":"QBT 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Công ty XNK Tam Phát"
    ,"Station_Address":"1806-1810, đ ường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.761275
    ,"Long":106.57151
    ,"Polyline":"[106.57563019,10.75958538] ; [106.57563019,10.75957966] ; [106.57460022,10.75986004] ; [106.57357788,10.76033020] ; [106.57253265,10.76078033] ; [106.57192230,10.76106167] ; [106.57151031,10.76127529]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3289"
    ,"Station_Code":"HBC 280"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Võ Văn Vân"
    ,"Station_Address":"1A7, đường Trần Văn Giàu, Huyện Bình Ch ánh"
    ,"Lat":10.763138
    ,"Long":106.567447
    ,"Polyline":"[106.57151031,10.76127529] ; [106.57111359,10.76143074] ; [106.56974792,10.76202965] ; [106.56775665,10.76292992] ; [106.56744385,10.76313782]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3288"
    ,"Station_Code":"HBC 281"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Coop mart Vĩnh Lộc B"
    ,"Station_Address":"1A24/2, đường Tr ần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.765099
    ,"Long":106.563247
    ,"Polyline":"[106.56744385,10.76313782] ; [106.56520081,10.76412010.06.56324768]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3290"
    ,"Station_Code":"HBC 282"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Công ty Th ịnh Uy"
    ,"Station_Address":"1A38/1, đường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.767576
    ,"Long":106.557931
    ,"Polyline":"[106.56324768,10.76509857] ; [106.55967712,10.76667976] ; [106.55792999,10.76757622]"
    ,"Distance":"644"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3292"
    ,"Station_Code":"HBC 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã tư Bà Lát"
    ,"Station_Address":"Đối diện G11/10, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.768487
    ,"Long":106.550608
    ,"Polyline":"[106.55416107,10.76941967] ; [106.55332184,10.76986027] ; [106.55320740,10.76986980] ; [106.55168915,10.77066040] ; [106.55166626,10.77054024] ; [106.55113220,10.76947021] ; [106.55059814,10.76848030]"
    ,"Distance":"1037"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3293"
    ,"Station_Code":"HBC 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Cổng 1"
    ,"Station_Address":"Đối diện G12/7, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.765947
    ,"Long":106.549283
    ,"Polyline":"[106.55059814,10.76848030] ; [106.54924011,10.76599026]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3291"
    ,"Station_Code":"HBC 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Cổng 2"
    ,"Station_Address":"Đối diện G12/31, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.762274
    ,"Long":106.547234
    ,"Polyline":"[106.54924011,10.76599026] ; [106.54826355,10.76422977] ; [106.54721832,10.76228046]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3294"
    ,"Station_Code":"HBC 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cổng 3"
    ,"Station_Address":"Đối diện D17/38 , đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.759449
    ,"Long":106.5457
    ,"Polyline":"[106.54721832,10.76228046] ; [106.54569244,10.75946999]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3296"
    ,"Station_Code":"HBC 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Cổng 4"
    ,"Station_Address":"Đối diện G14/18, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.756271
    ,"Long":106.544096
    ,"Polyline":"[106.54569244,10.75946999] ; [106.54483795,10.75792027] ; [106.54418182,10.75667953] ; [106.54400635,10.75629997]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3295"
    ,"Station_Code":"HBC 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Công ty Đại Vĩnh Lợi"
    ,"Station_Address":"Đối diện G14/40, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.752825
    ,"Long":106.542556
    ,"Polyline":"[106.54400635,10.75629997] ; [106.54245758,10.75286007]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"3297"
    ,"Station_Code":"HBC 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trường mầm non Thiên Ân"
    ,"Station_Address":"Đối diện G15/37, đường Láng Le bàu Cò , Huyện Bình Chánh"
    ,"Lat":10.748856
    ,"Long":106.540791
    ,"Polyline":"[106.54245758,10.75286007] ; [106.54090118,10.74936008] ; [106.54068756,10.74886990]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"113"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"KCN LÊ MINH XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường Trần  Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":"[106.54068756,10.74886990] ; [106.53997803,10.74728966] ; [106.53955841,10.74633980] ; [106.53909302,10.74542046] ; [106.53904724,10.74528027] ; [106.53909302,10.74518967] ; [106.53928375,10.74507046] ; [106.53946686,10.74497986] ; [106.53954315,10.74493027] ; [106.53958893,10.74483967] ; [106.53961182,10.74468994] ; [106.53952026,10.74442005] ; [106.53942108,10.74427032] ; [106.53951263,10.74421024]"
    ,"Distance":"610"
  }]