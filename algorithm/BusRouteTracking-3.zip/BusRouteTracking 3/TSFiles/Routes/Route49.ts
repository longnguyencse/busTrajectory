export const Route49 =[

  {
     "Route_Id":"49"
    ,"Station_Id":"2426"
    ,"Station_Code":"BX 53"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Xuân Thới Thượng"
    ,"Station_Address":"ĐẦU BẾN XUÂN THỚI THƯỢNG, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.86085
    ,"Long":106.567406
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"3971"
    ,"Station_Code":"HHM 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường Ngã ba Giòng"
    ,"Station_Address":"Trường Ngã ba Giòng, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.863611
    ,"Long":106.568241
    ,"Polyline":"[106.56740570,10.86085033] ; [106.56761932,10.86087132] ; [106.56775665,10.86197758] ; [106.56831360,10.86346340] ; [106.56823730,10.86361122]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"4715"
    ,"Station_Code":"HHM 189"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"124 /2B, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.864938
    ,"Long":106.565688
    ,"Polyline":"[106.56823730,10.86361122] ; [106.56817627,10.86350536] ; [106.56771851,10.86365795] ; [106.56564331,10.86482811] ; [106.56568909,10.86493778]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2220"
    ,"Station_Code":"HHM 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã 3 Gi ồng"
    ,"Station_Address":"135/4A, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.866392
    ,"Long":106.562319
    ,"Polyline":"[106.56568909,10.86493778] ; [106.56564331,10.86482239] ; [106.56227875,10.86629772] ; [106.56231689,10.86639214]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2519"
    ,"Station_Code":"HHM 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trang trại Bò Sửa"
    ,"Station_Address":"Đối diện 44/1, đường Dương Công Khi , Huyện Hóc Môn"
    ,"Lat":10.864243
    ,"Long":106.561997
    ,"Polyline":"[106.56231689,10.86639214] ; [106.56191254,10.86650848] ; [106.56223297,10.86427402] ; [106.56199646,10.86424255]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2428"
    ,"Station_Code":"HHM 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Xuân Thới Thượng 18"
    ,"Station_Address":"Đối diện 17/3A, đường Dương Công Khi, Huyện Hóc Môn"
    ,"Lat":10.860993
    ,"Long":106.562492
    ,"Polyline":"[106.56199646,10.86424255] ; [106.56217957,10.86426353] ; [106.56270599,10.86102962] ; [106.56249237,10.86099339]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2427"
    ,"Station_Code":"HHM 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Công ty Trúc Hà"
    ,"Station_Address":"Đối di ện 16/2A, đường Dương Công Khi, Huyện Hóc Môn"
    ,"Lat":10.856104
    ,"Long":106.563377
    ,"Polyline":"[106.56249237,10.86099339] ; [106.56337738,10.85610390]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2534"
    ,"Station_Code":"HHM 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Công ty Tr úc Hà"
    ,"Station_Address":"24/5, đường Dương Công Khi, Huyện Hóc Môn"
    ,"Lat":10.849786
    ,"Long":106.564229
    ,"Polyline":"[106.56337738,10.85610390] ; [106.56448364,10.84978676] ; [106.56423187,10.84978580]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2432"
    ,"Station_Code":"HBC 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty An  Khánh"
    ,"Station_Address":"D11/40A, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.845108
    ,"Long":106.565205
    ,"Polyline":"[106.56423187,10.84978580] ; [106.56446838,10.84970188] ; [106.56520844,10.84510803]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2431"
    ,"Station_Code":"HBC 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Cafe Phư ơng Nhi"
    ,"Station_Address":"D11/3A, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.839349
    ,"Long":106.566943
    ,"Polyline":"[106.56519318,10.84517956] ; [106.56551361,10.84305954] ; [106.56569672,10.84214973] ; [106.56587982,10.84175014] ; [106.56590271,10.84169006]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2433"
    ,"Station_Code":"HBC 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã 3 Thới Hòa"
    ,"Station_Address":"F12/15, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.836004
    ,"Long":106.568488
    ,"Polyline":"[106.56591797,10.84154129] ; [106.56728363,10.83864307]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2435"
    ,"Station_Code":"HBC 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Công ty Đất Rồng"
    ,"Station_Address":"C1/2 (C1/1C), đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.830271
    ,"Long":106.571074
    ,"Polyline":"[106.56728363,10.83864307] ; [106.56916809,10.83458614]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2434"
    ,"Station_Code":"HBC 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Công ty Đất Rồng"
    ,"Station_Address":"Đối diện F12/35A, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.825382
    ,"Long":106.573391
    ,"Polyline":"[106.56912231,10.83471012] ; [106.57077789,10.83129978] ; [106.57096100,10.83088970]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2437"
    ,"Station_Code":"HBC 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Tổ 11 xã Vỉnh Lộc"
    ,"Station_Address":"F5/28A (F2/3D), đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.822141
    ,"Long":106.575032
    ,"Polyline":"[106.57095337,10.83079815] ; [106.57096100,10.83088970] ; [106.57216644,10.82844830] ; [106.57272339,10.82703972] ; [106.57278442,10.82697773]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2436"
    ,"Station_Code":"HBC 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"cafe Em và Tôi"
    ,"Station_Address":"F2/3A,  đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.818969
    ,"Long":106.576186
    ,"Polyline":"[106.57278442,10.82697773] ; [106.57479095,10.82264233]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2440"
    ,"Station_Code":"HBC 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Nhà hàng  Suối Mơ"
    ,"Station_Address":"F2/1G, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.816266
    ,"Long":106.576749
    ,"Polyline":"[106.57479095,10.82275963] ; [106.57575226,10.82085991] ; [106.57592010,10.82059956] ; [106.57601929,10.82013988] ; [106.57624054,10.81906033]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2438"
    ,"Station_Code":"HBC 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà tưởng  niệm Vĩnh Lộc"
    ,"Station_Address":"F1/56K, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.813568
    ,"Long":106.577307
    ,"Polyline":"[106.57624054,10.81906033] ; [106.57646179,10.81812000] ; [106.57649231,10.81785965] ; [106.57701111,10.81542969] ; [106.57714081,10.81478024]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2439"
    ,"Station_Code":"HBC 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Nguyễn Thị Tú"
    ,"Station_Address":"D7/15, đường Nguyễn Thị Tú, Huyện Bình Chánh"
    ,"Lat":10.813832
    ,"Long":106.580488
    ,"Polyline":"[106.57709503,10.81469059] ; [106.57714081,10.81478024] ; [106.57759857,10.81252956] ; [106.57810211,10.81287003] ; [106.57905579,10.81345272] ; [106.57969666,10.81377029] ; [106.58016968,10.81377411]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2441"
    ,"Station_Code":"QBT 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Thép Quốc Thái"
    ,"Station_Address":"507, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.814548
    ,"Long":106.584091
    ,"Polyline":"[106.58287048,10.81443024] ; [106.58405304,10.81470966]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2443"
    ,"Station_Code":"QBT 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Công ty Thịnh Khang"
    ,"Station_Address":"415-419, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.81497
    ,"Long":106.586288
    ,"Polyline":"[106.58405304,10.81470966] ; [106.58603668,10.81515980] ; [106.58630371,10.81517029]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2442"
    ,"Station_Code":"QBT 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cafe Gia Nguyễn"
    ,"Station_Address":"355, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.81516
    ,"Long":106.589607
    ,"Polyline":"[106.58630371,10.81517029] ; [106.58895874,10.81525040] ; [106.58959961,10.81529999]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2445"
    ,"Station_Code":"QBT 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà hàng tiệc cưới Thịnh Phước"
    ,"Station_Address":"255B, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815407
    ,"Long":106.592563
    ,"Polyline":"[106.58959961,10.81529999] ; [106.59126282,10.81538963] ; [106.59253693,10.81550980]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2444"
    ,"Station_Code":"QBT 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Công ty Bảo Ngọc Châu"
    ,"Station_Address":"117, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.81555
    ,"Long":106.594913
    ,"Polyline":"[106.59253693,10.81550980] ; [106.59487152,10.81567001]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2447"
    ,"Station_Code":"QBT 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Nguyễn Thị Tú"
    ,"Station_Address":"810-814, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.815718
    ,"Long":106.602783
    ,"Polyline":"[106.59487152,10.81567001] ; [106.59867096,10.81595993] ; [106.59950256,10.81604958] ; [106.60008240,10.81630993] ; [106.60030365,10.81636047] ; [106.60061646,10.81632042] ; [106.60106659,10.81622982] ; [106.60122681,10.81616020] ; [106.60154724,10.81608963] ; [106.60281372,10.81583023]"
    ,"Distance":"911"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2446"
    ,"Station_Code":"QBT 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Từ bảo Nghi"
    ,"Station_Address":"692, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.814411
    ,"Long":106.60495
    ,"Polyline":"[106.60281372,10.81583023] ; [106.60318756,10.81569958] ; [106.60452271,10.81492043] ; [106.60505676,10.81459045]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2451"
    ,"Station_Code":"QBT 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đường CN1"
    ,"Station_Address":"642, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.813337
    ,"Long":106.607063
    ,"Polyline":"[106.60494995,10.81441116] ; [106.60505676,10.81459045] ; [106.60547638,10.81433010.06.60559845] ; [10.81425953,106.60569763] ; [10.81424999,106.60576630] ; [10.81420994,106.60635376] ; [10.81385040,106.60710907] ; [10.81337833,106.60706329]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2448"
    ,"Station_Code":"QTP 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cty Việt Phong"
    ,"Station_Address":"Công ty Việt Phong, đường Đường CN1, Qu ận Tân Phú"
    ,"Lat":10.814264
    ,"Long":106.609634
    ,"Polyline":"[106.60717773,10.81334972] ; [106.60777283,10.81301022] ; [106.60791016,10.81291962] ; [106.60794067,10.81295967] ; [106.60946655,10.81443024]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2453"
    ,"Station_Code":"QTP 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Công Ty Rosa"
    ,"Station_Address":"Công ty Rosa, đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.816625
    ,"Long":106.612267
    ,"Polyline":"[106.60946655,10.81443024] ; [106.61109924,10.81601048] ; [106.61138916,10.81626034] ; [106.61210632,10.81682014]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2449"
    ,"Station_Code":"QTP 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cty MGA"
    ,"Station_Address":"Công ty MGA, đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.817815
    ,"Long":106.614662
    ,"Polyline":"[106.61210632,10.81682014] ; [106.61257935,10.81717968] ; [106.61283112,10.81733990] ; [106.61302185,10.81742954] ; [106.61337280,10.81756973] ; [106.61403656,10.81781006] ; [106.61437225,10.81791019] ; [106.61451721,10.81801033]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2450"
    ,"Station_Code":"QTP 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Công ty Masan"
    ,"Station_Address":"Công ty Masan, đường Đường CN1, Quận T ân Phú"
    ,"Lat":10.818774
    ,"Long":106.616814
    ,"Polyline":"[106.61451721,10.81801033] ; [106.61476135,10.81816006] ; [106.61512756,10.81836033] ; [106.61582184,10.81871986] ; [106.61631775,10.81892967] ; [106.61640930,10.81898022] ; [106.61666107,10.81902027] ; [106.61676025,10.81904030]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2455"
    ,"Station_Code":"QTP 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Hội quán KCNTBình"
    ,"Station_Address":"H ội quán KCN Tân Bình (Coopfood), đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.817868
    ,"Long":106.620079
    ,"Polyline":"[106.61676025,10.81904030] ; [106.61711121,10.81910038] ; [106.61741638,10.81908035] ; [106.61760712,10.81904030] ; [106.61773682,10.81898975] ; [106.61808777,10.81879044] ; [106.61855316,10.81842041] ; [106.61888885,10.81818962] ; [106.61907959,10.81807041] ; [106.61917877,10.81805038] ; [106.62000275,10.81811047] ; [106.62004852,10.81812000]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2452"
    ,"Station_Code":"QTP 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Lô D chung cư KCN Tân Bình"
    ,"Station_Address":"L ô D chung cư KCN Tân Bình, đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.816646
    ,"Long":106.622917
    ,"Polyline":"[106.62004852,10.81812000] ; [106.62107849,10.81822014] ; [106.62129974,10.81818962] ; [106.62153625,10.81801987] ; [106.62187195,10.81772041] ; [106.62297058,10.81669998]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2457"
    ,"Station_Code":"QTP 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trạm Công Ty Ngọc Nghĩa"
    ,"Station_Address":"Đối diện công ty Ngọc Nghĩa, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.815767
    ,"Long":106.625061
    ,"Polyline":"[106.62297058,10.81669998] ; [106.62452698,10.81532955] ; [106.62502289,10.81581020]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2454"
    ,"Station_Code":"QTP 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Cty Dầu Thực Vật"
    ,"Station_Address":"Công ty dầu thực  vật Tân Bình, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.81896
    ,"Long":106.628532
    ,"Polyline":"[106.62502289,10.81581020] ; [106.62677765,10.81744957] ; [106.62828827,10.81877995] ; [106.62851715,10.81896973]"
    ,"Distance":"528"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm KCN  Tân Bình"
    ,"Station_Address":"881, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.62851715,10.81896973] ; [106.62944031,10.81964970] ; [106.63059998,10.82044029] ; [106.63089752,10.81947041]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chế Lan Viên"
    ,"Station_Address":"28/7B, đ ường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm Đài Li ệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"597"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"178"
    ,"Station_Code":"QTB 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680 (Thượng Uyển), đường Cộng Hòa, Qu ận Tân Bình"
    ,"Lat":10.806144
    ,"Long":106.636055
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63455963,10.80772972] ; [106.63471985,10.80747986] ; [106.63487244,10.80729961] ; [106.63501740,10.80712986] ; [106.63535309,10.80681992] ; [106.63601685,10.80624962] ; [106.63609314,10.80617046]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"180"
    ,"Station_Code":"QTB 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"401, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.803541
    ,"Long":106.637887
    ,"Polyline":"[106.63609314,10.80617046] ; [106.63627625,10.80595016] ; [106.63709259,10.80482960] ; [106.63793182,10.80358028]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"181"
    ,"Station_Code":"QTB 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm ETown"
    ,"Station_Address":"364  (công ty Ree), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802371
    ,"Long":106.640253
    ,"Polyline":"[106.63793182,10.80358028] ; [106.63818359,10.80319977] ; [106.63858032,10.80292034] ; [106.63897705,10.80270004] ; [106.63944244,10.80257034] ; [106.63977814,10.80249023] ; [106.64025116,10.80243969]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"179"
    ,"Station_Code":"QTB 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã ba B ình Giã"
    ,"Station_Address":"303, đường Cộng  Hòa, Quận Tân Bình"
    ,"Lat":10.802055
    ,"Long":106.644292
    ,"Polyline":"[106.64025116,10.80243969] ; [106.64430237,10.80212021]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"183"
    ,"Station_Code":"QTB 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"19A (Công ty Lô H ội), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801544
    ,"Long":106.650413
    ,"Polyline":"[106.64430237,10.80212021] ; [106.64871979,10.80173969] ; [106.65028381,10.80160999]"
    ,"Distance":"672"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"182"
    ,"Station_Code":"QTB 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Pico Plaza"
    ,"Station_Address":"20Bis, đường Cộng Hòa, Qu ận Tân Bình"
    ,"Lat":10.801254
    ,"Long":106.653637
    ,"Polyline":"[106.65028381,10.80160999] ; [106.65370941,10.80130959]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"185"
    ,"Station_Code":"QTB 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Trạm Út tịch"
    ,"Station_Address":"35-37, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.800985
    ,"Long":106.656679
    ,"Polyline":"[106.65370941,10.80130959] ; [106.65663147,10.80105019]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"184"
    ,"Station_Code":"QTB 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"Đối diện 58 (Siêu thị Maximart ), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.800833
    ,"Long":106.658819
    ,"Polyline":"[106.65662384,10.80099297] ; [106.65663147,10.80105019] ; [106.65782928,10.80095959] ; [106.65878296,10.80088043] ; [106.65889740,10.80086899] ; [106.65908051,10.80087471] ; [106.65923309,10.80078983] ; [106.65922546,10.80075645]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2458"
    ,"Station_Code":"QTB 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Bùi Thị  Xuân"
    ,"Station_Address":"Đối diện 400, đường Lê Văn  Sỹ, Quận Tân Bình"
    ,"Lat":10.798415
    ,"Long":106.66256
    ,"Polyline":"[106.65921783,10.80078030] ; [106.65979004,10.80074024] ; [106.66069031,10.80064011] ; [106.66075897,10.80056953] ; [106.66078186,10.80051041] ; [106.66087341,10.80027008] ; [106.66066742,10.79998016] ; [106.66117859,10.79955959] ; [106.66235352,10.79870033] ; [106.66262054,10.79848957]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2456"
    ,"Station_Code":"QTB 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Nhà thờ Tân Xa Châu"
    ,"Station_Address":"387, đường Lê Văn Sỹ, Quận Tân Bình"
    ,"Lat":10.797228
    ,"Long":106.664177
    ,"Polyline":"[106.66264343,10.79846954] ; [106.66422272,10.79728031]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2459"
    ,"Station_Code":"QTB 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"345, đường Lê Văn Sỹ, Quận Tân Bình"
    ,"Lat":10.796211
    ,"Long":106.665512
    ,"Polyline":"[106.66422272,10.79728031] ; [106.66557312,10.79627991]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2460"
    ,"Station_Code":"QTB 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bệnh viện Chấn thương Chỉnh hình Sài Gòn"
    ,"Station_Address":"279, đường Lê Văn Sỹ, Quận Tân Bình"
    ,"Lat":10.794536
    ,"Long":106.667751
    ,"Polyline":"[106.66557312,10.79627991] ; [106.66648865,10.79559994] ; [106.66694641,10.79524994] ; [106.66716003,10.79512024] ; [106.66789246,10.79459000]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2465"
    ,"Station_Code":"QPN 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Nhà thờ Ba Chuông"
    ,"Station_Address":"183, đường Lê Văn Sỹ, Quận Phú Nhuận"
    ,"Lat":10.792536
    ,"Long":106.670509
    ,"Polyline":"[106.66789246,10.79459000] ; [106.66941071,10.79345036] ; [106.67054749,10.79259014]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2461"
    ,"Station_Code":"QPN 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Ngã Tư Huỳnh Văn Bánh"
    ,"Station_Address":"83 - 85, đường Lê Văn Sỹ, Quận Phú Nhuận"
    ,"Lat":10.790729
    ,"Long":106.672935
    ,"Polyline":"[106.67054749,10.79259014] ; [106.67199707,10.79154015] ; [106.67298889,10.79080009]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2466"
    ,"Station_Code":"Q3 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Hẻm 491"
    ,"Station_Address":"485, đường Lê Văn Sỹ, Quận 3"
    ,"Lat":10.789698
    ,"Long":106.674221
    ,"Polyline":"[106.67298889,10.79080009] ; [106.67415619,10.78995037]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2462"
    ,"Station_Code":"Q3 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Nhà thờ vườn  xoài"
    ,"Station_Address":"411, đường Lê Văn Sỹ, Quận  3"
    ,"Lat":10.788905
    ,"Long":106.675682
    ,"Polyline":"[106.67421722,10.78969765] ; [106.67430878,10.78979301] ; [106.67472839,10.78958988] ; [106.67542267,10.78921986] ; [106.67575073,10.78901005] ; [106.67568207,10.78890514]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"557"
    ,"Station_Code":"Q3 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Chợ Nguyễn Văn Trỗi"
    ,"Station_Address":"217, đường Lê Văn Sỹ, Quận  3"
    ,"Lat":10.786577
    ,"Long":106.679787
    ,"Polyline":"[106.67575073,10.78901005] ; [106.67607880,10.78882027] ; [106.67669678,10.78849030] ; [106.67788696,10.78781033] ; [106.67826843,10.78761959] ; [106.67977905,10.78676033] ; [106.67986298,10.78670979]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2468"
    ,"Station_Code":"Q3 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Bệnh viện tai mũi họng"
    ,"Station_Address":"159, đường Trần Quốc Thảo , Quận 3"
    ,"Lat":10.784608
    ,"Long":106.683512
    ,"Polyline":"[106.67986298,10.78670979] ; [106.68153381,10.78577709] ; [106.68366241,10.78470039]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2470"
    ,"Station_Code":"Q3 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Ủy ban Quận 3"
    ,"Station_Address":"101, đường Trần Quốc Thảo, Quận 3"
    ,"Lat":10.783036
    ,"Long":106.686356
    ,"Polyline":"[106.68366241,10.78470039] ; [106.68522644,10.78405952] ; [106.68551636,10.78386974] ; [106.68595123,10.78349972] ; [106.68640137,10.78308964]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2463"
    ,"Station_Code":"Q3 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Tú Xương"
    ,"Station_Address":"81, đường Trần Quốc Thảo, Quận 3"
    ,"Lat":10.782096
    ,"Long":106.687309
    ,"Polyline":"[106.68640137,10.78308964] ; [106.68688202,10.78269958] ; [106.68740845,10.78219986]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2464"
    ,"Station_Code":"Q3 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"Cạnh 63C, đư ờng Trần Quốc Thảo, Quận 3"
    ,"Lat":10.780824
    ,"Long":106.68878
    ,"Polyline":"[106.68730927,10.78209591] ; [106.68740845,10.78219986] ; [106.68769073,10.78194046] ; [106.68863678,10.78105068] ; [106.68878174,10.78082371]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2471"
    ,"Station_Code":"Q3 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"39, đường Trần Quốc Thảo, Quận 3"
    ,"Lat":10.779394
    ,"Long":106.690262
    ,"Polyline":"[106.68878174,10.78082371] ; [106.68881989,10.78085518] ; [106.69029999,10.77943993] ; [106.69026184,10.77939415]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"1883"
    ,"Station_Code":"Q3 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Trương Đ ịnh"
    ,"Station_Address":"216, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.77824
    ,"Long":106.689789
    ,"Polyline":"[106.69029999,10.77943993] ; [106.69069672,10.77910042] ; [106.69016266,10.77849007] ; [106.68984985,10.77818012]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2477"
    ,"Station_Code":"Q3 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Nguyễn Thị Diệu"
    ,"Station_Address":"179D, đường Cách Mạng Tháng T ám, Quận 3"
    ,"Lat":10.77469
    ,"Long":106.687202
    ,"Polyline":"[106.68984985,10.77818012] ; [106.68846893,10.77674961] ; [106.68682098,10.77501011] ; [106.68704987,10.77488041] ; [106.68727112,10.77478027]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"1396"
    ,"Station_Code":"Q1 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"85, đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.772392
    ,"Long":106.691371
    ,"Polyline":"[106.68727112,10.77478027] ; [106.68858337,10.77406979] ; [106.68985748,10.77340031] ; [106.69113922,10.77270985] ; [106.69139862,10.77256012]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"1401"
    ,"Station_Code":"Q1 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"26 - 32, đường Nguyễn Thị Ngh ĩa, Quận 1"
    ,"Lat":10.770854
    ,"Long":106.693588
    ,"Polyline":"[106.69136810,10.77239227] ; [106.69146729,10.77243996] ; [106.69309235,10.77160168] ; [106.69311523,10.77151203] ; [106.69306946,10.77142811] ; [106.69308472,10.77125359] ; [106.69324493,10.77117538] ; [106.69341278,10.77120113] ; [106.69358826,10.77085400]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ng ũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69365692,10.77089024] ; [106.69467926,10.76920986] ; [106.69412994,10.76898003]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"65"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.69398499,10.76903534] ; [106.69384003,10.76895618] ; [106.69238281,10.76828003] ; [106.69049072,10.76753044] ; [106.68981171,10.76729584] ; [106.68961334,10.76770687] ; [106.68936157,10.76767635] ; [106.68936157,10.76767635]"
    ,"Distance":"575"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài  Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất T ùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68904877,10.76807022] ; [106.68920898,10.76819992] ; [106.68988800,10.76844978] ; [106.69026184,10.76860046]"
    ,"Distance":"145"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối di ện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"84"
    ,"Station_Code":"Q1 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện số  26, đường Nguyễn Thị Nghĩa, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.693779
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69421387,10.77011013] ; [106.69377899,10.77097988]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"1297"
    ,"Station_Code":"Q1 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"Đối diện số 89, đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.773046
    ,"Long":106.690813
    ,"Polyline":"[106.69362640,10.77093983] ; [106.69352722,10.77110004] ; [106.69338226,10.77124977] ; [106.69341278,10.77128029] ; [106.69344330,10.77134991] ; [106.69339752,10.77143002] ; [106.69332123,10.77147007] ; [106.69322968,10.77147961] ; [106.69319916,10.77147961] ; [106.69315338,10.77161026] ; [106.69281769,10.77180004] ; [106.69113922,10.77270985] ; [106.69075012,10.77291965]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"292"
    ,"Station_Code":"Q1 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Sở Y Tế"
    ,"Station_Address":"Đối diện 214-216, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.774179
    ,"Long":106.690158
    ,"Polyline":"[106.69075012,10.77291965] ; [106.68985748,10.77340031] ; [106.68975830,10.77377033] ; [106.68977356,10.77388954] ; [106.68982697,10.77410030] ; [106.68995667,10.77423000]"
    ,"Distance":"211"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"242"
    ,"Station_Code":"Q1 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhà Văn Hóa Lao Động"
    ,"Station_Address":"Đối diện số 138, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.777097
    ,"Long":106.692757
    ,"Polyline":"[106.68995667,10.77423000] ; [106.69161987,10.77598953] ; [106.69270325,10.77715015]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2481"
    ,"Station_Code":"Q3 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"Đối diện 19C1, đường Lê Quý Đôn, Quận 3"
    ,"Lat":10.780887
    ,"Long":106.691391
    ,"Polyline":"[106.69270325,10.77715015] ; [106.69328308,10.77781010.06.69384003] ; [10.77842045,106.69287109] ; [10.77931976,106.69127655]"
    ,"Distance":"571"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2483"
    ,"Station_Code":"Q3 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà thiếu nhi thành phố"
    ,"Station_Address":"Đối diện 47, đường Lê Quý Đôn, Quận 3"
    ,"Lat":10.78357
    ,"Long":106.688479
    ,"Polyline":"[106.69139099,10.78088665] ; [106.68847656,10.78357029]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2491"
    ,"Station_Code":"Q3 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bảo tàng Phụ Nữ"
    ,"Station_Address":"200, đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.783535
    ,"Long":106.687561
    ,"Polyline":"[106.68847656,10.78357029] ; [106.68803406,10.78394890] ; [106.68756104,10.78353500]"
    ,"Distance":"134"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2494"
    ,"Station_Code":"Q3 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ủy ban Qu ận 3"
    ,"Station_Address":"78Bis, đường Trần Quốc Thảo, Quận 3"
    ,"Lat":10.783424
    ,"Long":106.686134
    ,"Polyline":"[106.68762207,10.78347969] ; [106.68688202,10.78269958] ; [106.68660736,10.78289986] ; [106.68630219,10.78318024] ; [106.68608093,10.78337002]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2485"
    ,"Station_Code":"Q3 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh viện tai mũi họng"
    ,"Station_Address":"118, đường Trần Quốc Thảo, Quận 3"
    ,"Lat":10.78467
    ,"Long":106.683907
    ,"Polyline":"[106.68608093,10.78337002] ; [106.68592072,10.78353024] ; [106.68537903,10.78398037] ; [106.68509674,10.78413010.06.68448639] ; [10.78435993,106.68388367]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"449"
    ,"Station_Code":"Q3 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Nguyễn Văn Trỗi"
    ,"Station_Address":"332 - 334, đường Lê Văn Sỹ, Quận 3"
    ,"Lat":10.787041
    ,"Long":106.679535
    ,"Polyline":"[106.68388367,10.78460979] ; [106.68130493,10.78590393] ; [106.67946625,10.78693008]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2496"
    ,"Station_Code":"Q3 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường Trần Quang Diệu"
    ,"Station_Address":"Đối diện 345, đường Lê Văn  Sỹ, Quận 3"
    ,"Lat":10.788124
    ,"Long":106.677666
    ,"Polyline":"[106.67946625,10.78693008] ; [106.67826843,10.78761959] ; [106.67788696,10.78781033] ; [106.67758179,10.78798962]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2487"
    ,"Station_Code":"Q3 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà thờ Vườn Xoài"
    ,"Station_Address":"470, đường Lê Văn Sỹ, Quận 3"
    ,"Lat":10.789529
    ,"Long":106.675004
    ,"Polyline":"[106.67758179,10.78798962] ; [106.67669678,10.78849030] ; [106.67607880,10.78882027] ; [106.67542267,10.78921986] ; [106.67516327,10.78936005]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2497"
    ,"Station_Code":"QPN 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã Tư Huỳnh Văn Bánh"
    ,"Station_Address":"88, đường Lê Văn Sỹ, Quận Phú Nhuận"
    ,"Lat":10.791295
    ,"Long":106.67244
    ,"Polyline":"[106.67500305,10.78952885] ; [106.67472839,10.78958988] ; [106.67401886,10.79004002] ; [106.67294312,10.79084015] ; [106.67237854,10.79125977] ; [106.67243958,10.79129505]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2489"
    ,"Station_Code":"QPN 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà thờ Ba Chuông"
    ,"Station_Address":"190, đường Lê Văn Sỹ, Quận Phú Nhuận"
    ,"Lat":10.793252
    ,"Long":106.669762
    ,"Polyline":"[106.67237854,10.79125977] ; [106.67156982,10.79185009] ; [106.67034912,10.79273033] ; [106.66973114,10.79321003]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2499"
    ,"Station_Code":"QTB 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường Cao Đẳng Tài nguyên Môi trường"
    ,"Station_Address":"236A , đường Lê Văn Sỹ, Quận Tân Bình"
    ,"Lat":10.795373
    ,"Long":106.666893
    ,"Polyline":"[106.66973114,10.79321003] ; [106.66848755,10.79413986] ; [106.66716003,10.79512024] ; [106.66684723,10.79531956]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2492"
    ,"Station_Code":"QTB 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Phạm Văn  Hai"
    ,"Station_Address":"308, đường Lê Văn S ỹ, Quận Tân Bình"
    ,"Lat":10.796459
    ,"Long":106.665405
    ,"Polyline":"[106.66684723,10.79531956] ; [106.66538239,10.79642010]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2493"
    ,"Station_Code":"QTB 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Cây Xăng dầu"
    ,"Station_Address":"380, đường Lê Văn Sỹ, Quận Tân Bình"
    ,"Lat":10.798293
    ,"Long":106.662994
    ,"Polyline":"[106.66538239,10.79642010.06.66294861]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"259"
    ,"Station_Code":"QTB 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Siêu thị Maximark Cộng Hòa"
    ,"Station_Address":"60,  đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801038
    ,"Long":106.659168
    ,"Polyline":"[106.66294861,10.79823971] ; [106.66235352,10.79870033] ; [106.66117859,10.79955959] ; [106.66066742,10.79998016] ; [106.66087341,10.80027008] ; [106.66094208,10.80023956] ; [106.66101074,10.80023003] ; [106.66108704,10.80027008] ; [106.66113281,10.80031967] ; [106.66117096,10.80041027] ; [106.66116333,10.80053043] ; [106.66111755,10.80058956] ; [106.66091919,10.80072975] ; [106.66071320,10.80084038] ; [106.65994263,10.80090046] ; [106.65911102,10.80095959]"
    ,"Distance":"648"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"260"
    ,"Station_Code":"QTB 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà hát Qu ân Đội"
    ,"Station_Address":"138 (Kế nhà hát Qu ân đội), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801238
    ,"Long":106.656754
    ,"Polyline":"[106.65911102,10.80095959] ; [106.65675354,10.80115032]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"261"
    ,"Station_Code":"QTB 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngân hàng  Quân đội"
    ,"Station_Address":"Tiệc cưới Hương  Sen, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801412
    ,"Long":106.654817
    ,"Polyline":"[106.65675354,10.80115032] ; [106.65480042,10.80132008]"
    ,"Distance":"214"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"262"
    ,"Station_Code":"QTB 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Công ty  Lô Hội"
    ,"Station_Address":"184, đường Cộng  Hòa, Quận Tân Bình"
    ,"Lat":10.801728
    ,"Long":106.651127
    ,"Polyline":"[106.65480042,10.80132008] ; [106.65112305,10.80163956]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"263"
    ,"Station_Code":"QTB 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã tư Hoàng Hoa Thám"
    ,"Station_Address":"304, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802102
    ,"Long":106.646953
    ,"Polyline":"[106.65112305,10.80163956] ; [106.65009308,10.80173016] ; [106.64747620,10.80193996] ; [106.64694214,10.80198002]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"264"
    ,"Station_Code":"QTB 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã ba B ình Giã"
    ,"Station_Address":"390, đường Cộng  Hòa, Quận Tân Bình"
    ,"Lat":10.802276
    ,"Long":106.644512
    ,"Polyline":"[106.64694214,10.80198002] ; [106.64434052,10.80220032]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"265"
    ,"Station_Code":"QTB 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Lê Văn Huân"
    ,"Station_Address":"496, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802571
    ,"Long":106.640967
    ,"Polyline":"[106.64434052,10.80220032] ; [106.64096832,10.80247974]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"266"
    ,"Station_Code":"QTB 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"660 (kế 592), đường Cộng H òa, Quận Tân Bình"
    ,"Lat":10.806313
    ,"Long":106.636192
    ,"Polyline":"[106.64096832,10.80247974] ; [106.63993073,10.80255985] ; [106.63947296,10.80265045] ; [106.63915253,10.80274963] ; [106.63868713,10.80298996] ; [106.63829041,10.80329037] ; [106.63803864,10.80364037] ; [106.63768005,10.80418015] ; [106.63687897,10.80537033] ; [106.63649750,10.80589962] ; [106.63616943,10.80628014] ; [106.63616180,10.80628967]"
    ,"Distance":"721"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63616180,10.80628967] ; [106.63549805,10.80685997] ; [106.63509369,10.80729008] ; [106.63481903,10.80762005] ; [106.63462067,10.80801010]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận  Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63462067,10.80801010.06.63450623] ; [10.80827045,106.63417053] ; [10.80928993,106.63343811]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63343811,10.81167984] ; [106.63253784,10.81462002]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63258362,10.81463814] ; [106.63169098,10.81754112]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2454"
    ,"Station_Code":"QTP 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cty Dầu Thực Vật"
    ,"Station_Address":"Công ty dầu thực vật Tân Bình, đường Tây Th ạnh, Quận Tân Phú"
    ,"Lat":10.81896
    ,"Long":106.628532
    ,"Polyline":"[106.63169098,10.81754112] ; [106.63079834,10.82069206] ; [106.62853241,10.81896019]"
    ,"Distance":"678"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2457"
    ,"Station_Code":"QTP 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm Công Ty Ngọc Nghĩa"
    ,"Station_Address":"Đối diện công ty Ngọc Nghĩa, đường T ây Thạnh, Quận Tân Phú"
    ,"Lat":10.815767
    ,"Long":106.625061
    ,"Polyline":"[106.62853241,10.81896019] ; [106.62506104,10.81576729]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2495"
    ,"Station_Code":"QTP 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cty JingGong"
    ,"Station_Address":"Công ty JingGong , đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.816925
    ,"Long":106.622803
    ,"Polyline":"[106.62502289,10.81581020] ; [106.62452698,10.81532955] ; [106.62277222,10.81688976]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2498"
    ,"Station_Code":"QTP 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Hội quán KCNTB ình"
    ,"Station_Address":"Đối diện CoopFood, đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.818205
    ,"Long":106.620056
    ,"Polyline":"[106.62277222,10.81688976] ; [106.62153625,10.81801987] ; [106.62129974,10.81818962] ; [106.62107849,10.81822014] ; [106.62006378,10.81812000]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2502"
    ,"Station_Code":"QTP 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cty MGA"
    ,"Station_Address":"Đối diện Công ty MGA, đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.81928
    ,"Long":106.617203
    ,"Polyline":"[106.62006378,10.81812000] ; [106.61930084,10.81805992] ; [106.61917877,10.81805038] ; [106.61910248,10.81805992] ; [106.61903381,10.81809998] ; [106.61855316,10.81842041] ; [106.61791229,10.81890965] ; [106.61760712,10.81904030] ; [106.61721039,10.81910992]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2500"
    ,"Station_Code":"QTP 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cty Masan"
    ,"Station_Address":"Đối diện Công ty Masan, đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.818079
    ,"Long":106.614304
    ,"Polyline":"[106.61721039,10.81910992] ; [106.61701202,10.81908989] ; [106.61640930,10.81898022] ; [106.61582184,10.81871986] ; [106.61508179,10.81834030] ; [106.61464691,10.81809998] ; [106.61441040,10.81793022]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2501"
    ,"Station_Code":"QTP 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Cty ROSA"
    ,"Station_Address":"Đối diện Rosa, đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.816804
    ,"Long":106.611931
    ,"Polyline":"[106.61430359,10.81807899] ; [106.61441040,10.81793022] ; [106.61360168,10.81766033] ; [106.61298370,10.81746769] ; [106.61257935,10.81717968] ; [106.61199188,10.81672955] ; [106.61193085,10.81680393]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2503"
    ,"Station_Code":"QTP 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Cty TANIMEX"
    ,"Station_Address":"Đối diện Công ty Tanimex (Việt Phong) , đường Đường CN1, Quận Tân Phú"
    ,"Lat":10.81478
    ,"Long":106.609528
    ,"Polyline":"[106.61199188,10.81672955] ; [106.61128235,10.81616974] ; [106.61064148,10.81556034] ; [106.60968018,10.81462955]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2504"
    ,"Station_Code":"QBT 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Ngoại ngữ tin  học Đại Tây Dương"
    ,"Station_Address":"597 (688/11), đường Lê Trọng Tấn, Quận  Bình Tân"
    ,"Lat":10.81341
    ,"Long":106.607353
    ,"Polyline":"[106.60968018,10.81462955] ; [106.60794067,10.81295967] ; [106.60791016,10.81291962] ; [106.60777283,10.81301022] ; [106.60727692,10.81328964]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2505"
    ,"Station_Code":"QBT 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Gò Mây"
    ,"Station_Address":"665, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.814612
    ,"Long":106.605427
    ,"Polyline":"[106.60727692,10.81328964] ; [106.60588074,10.81414032] ; [106.60569763,10.81424999] ; [106.60568237,10.81431007] ; [106.60536194,10.81451988]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2521"
    ,"Station_Code":"QBT 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Ngân hàng Á Châu"
    ,"Station_Address":"787-745, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.815971
    ,"Long":106.603043
    ,"Polyline":"[106.60532379,10.81453991] ; [106.60404968,10.81529045] ; [106.60323334,10.81577015] ; [106.60299683,10.81587029]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2520"
    ,"Station_Code":"QBT 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Công ty Bảo Châu"
    ,"Station_Address":"88, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815697
    ,"Long":106.594925
    ,"Polyline":"[106.60299683,10.81587029] ; [106.60191345,10.81610012] ; [106.60124969,10.81624031] ; [106.60106659,10.81622982] ; [106.60040283,10.81634998] ; [106.60018921,10.81634998] ; [106.59971619,10.81612968] ; [106.59950256,10.81604958] ; [106.59927368,10.81601048] ; [106.59806061,10.81591034] ; [106.59635925,10.81577969] ; [106.59493256,10.81567955]"
    ,"Distance":"896"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2511"
    ,"Station_Code":"QBT 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà hàng Thịnh Phước"
    ,"Station_Address":"Đối diện 255B, đường Nguy ễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815518
    ,"Long":106.592453
    ,"Polyline":"[106.59493256,10.81567955] ; [106.59304810,10.81556034] ; [106.59245300,10.81550026]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2518"
    ,"Station_Code":"QBT 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Công ty Gia Nguyễn"
    ,"Station_Address":"210, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815318
    ,"Long":106.589088
    ,"Polyline":"[106.59245300,10.81550026] ; [106.59126282,10.81538963] ; [106.59046936,10.81534958] ; [106.58908844,10.81525993]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2513"
    ,"Station_Code":"QBT 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Công ty Thịnh Khang"
    ,"Station_Address":"264 , đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815228
    ,"Long":106.586555
    ,"Polyline":"[106.58908844,10.81525993] ; [106.58656311,10.81517982]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2516"
    ,"Station_Code":"QBT 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Thép Qu ốc Thái"
    ,"Station_Address":"D1/1B, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.814812
    ,"Long":106.58387
    ,"Polyline":"[106.58656311,10.81517982] ; [106.58603668,10.81515980] ; [106.58390045,10.81466961]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2517"
    ,"Station_Code":"HBC 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Ngã 5 V ĩnh Lộc"
    ,"Station_Address":"1, đường Nguyễn  Thị Tú, Huyện Bình Chánh"
    ,"Lat":10.8139
    ,"Long":106.580215
    ,"Polyline":"[106.58390045,10.81466961] ; [106.58206177,10.81424999]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2522"
    ,"Station_Code":"HBC 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Nhà tưởng niệm Vĩnh Lộc"
    ,"Station_Address":"F7/16, đường  Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.813705
    ,"Long":106.577409
    ,"Polyline":"[106.57985687,10.81381607] ; [106.57765198,10.81255627] ; [106.57740784,10.81370544]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2523"
    ,"Station_Code":"HBC 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Cà phê Em v à Tôi"
    ,"Station_Address":"F12/2, đường Quách  Điêu, Huyện Bình Chánh"
    ,"Lat":10.816166
    ,"Long":106.57691
    ,"Polyline":"[106.57740784,10.81370544] ; [106.57691193,10.81616592]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2524"
    ,"Station_Code":"HBC 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Cà phê Em và Tôi"
    ,"Station_Address":"F12/1, đường Quách Điêu, Huyện Bình Ch ánh"
    ,"Lat":10.819127
    ,"Long":106.576298
    ,"Polyline":"[106.57691193,10.81616592] ; [106.57642365,10.81848431]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2506"
    ,"Station_Code":"HBC 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Tổ 11 xã Vĩnh Lộc"
    ,"Station_Address":"F12/22A, đường Quách Điêu , Huyện Bình Chánh"
    ,"Lat":10.822405
    ,"Long":106.575043
    ,"Polyline":"[106.57642365,10.81848431] ; [106.57585907,10.82070255] ; [106.57504272,10.82240486]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2529"
    ,"Station_Code":"HBC 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Công ty Đất Rồng"
    ,"Station_Address":"E1/2C, đường Quách Điêu, Huyện Bình Ch ánh"
    ,"Lat":10.825634
    ,"Long":106.57353
    ,"Polyline":"[106.57504272,10.82240486] ; [106.57353210,10.82563400]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2527"
    ,"Station_Code":"HBC 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Bia Liệt sỹ"
    ,"Station_Address":"E12/29G, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.83181
    ,"Long":106.570607
    ,"Polyline":"[106.57353210,10.82563400] ; [106.57061005,10.83181000]"
    ,"Distance":"758"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2507"
    ,"Station_Code":"HBC 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Công ty Chiến Lược"
    ,"Station_Address":"D11/7, đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.835872
    ,"Long":106.568692
    ,"Polyline":"[106.57061005,10.83181000] ; [106.56869507,10.83587170]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2508"
    ,"Station_Code":"HBC 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Quách Điêu"
    ,"Station_Address":"D11/11B(D11/35D), đường Quách Điêu, Huyện Bình Chánh"
    ,"Lat":10.839218
    ,"Long":106.567152
    ,"Polyline":"[106.56869507,10.83587170] ; [106.56790161,10.83757401]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2510"
    ,"Station_Code":"HHM 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Me Nhật Huy"
    ,"Station_Address":"Đối diện 24/5, đường Dương Công Khi, Huyện Hóc Môn"
    ,"Lat":10.849702
    ,"Long":106.564711
    ,"Polyline":"[106.56790161,10.83757401] ; [106.56571198,10.84215736] ; [106.56471252,10.84970188]"
    ,"Distance":"1410"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2430"
    ,"Station_Code":"HHM 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Công ty Dịch Đạt"
    ,"Station_Address":"17/3A, đường Dương Công Khi, Huyện Hóc Môn"
    ,"Lat":10.852863
    ,"Long":106.564229
    ,"Polyline":"[106.56471252,10.84970188] ; [106.56423187,10.85286331]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2429"
    ,"Station_Code":"HHM 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Trang trại Bò sửa"
    ,"Station_Address":"16/2A, đường Dương Công Khi, Huyện Hóc Môn"
    ,"Lat":10.858047
    ,"Long":106.563456
    ,"Polyline":"[106.56423187,10.85286331] ; [106.56345367,10.85804653]"
    ,"Distance":"583"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2536"
    ,"Station_Code":"HHM 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Công ty Dịch Đạt"
    ,"Station_Address":"40/1 , đường Dương Công Khi, Huyện Hóc Môn"
    ,"Lat":10.863758
    ,"Long":106.562555
    ,"Polyline":"[106.56345367,10.85804653] ; [106.56255341,10.86375809]"
    ,"Distance":"643"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2269"
    ,"Station_Code":"QHMT180"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Ngã 3 Gi ồng"
    ,"Station_Address":"3, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.86580753326416
    ,"Long":106.56269073486328
    ,"Polyline":"[106.56255341,10.86375809] ; [106.56237030,10.86373138] ; [106.56193542,10.86638165] ; [106.56281281,10.86597061] ; [106.56269073,10.86580753]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"4656"
    ,"Station_Code":"HHM 192"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"30/2B, đường Phan Văn Hớn , Huyện Hóc Môn"
    ,"Lat":10.865212
    ,"Long":106.564164
    ,"Polyline":"[106.56269073,10.86580753] ; [106.56276703,10.86602306] ; [106.56426239,10.86536503] ; [106.56416321,10.86521244]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2271"
    ,"Station_Code":"QHMT181"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Ngã 3 Giồng"
    ,"Station_Address":"28/7A, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.863937377929688
    ,"Long":106.56668853759766
    ,"Polyline":"[106.56416321,10.86521244] ; [106.56423187,10.86536503] ; [106.56560516,10.86479092] ; [106.56679535,10.86411667] ; [106.56668854,10.86393738]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"1159"
    ,"Station_Code":"HHM 193"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Trường Ngã ba Giòng"
    ,"Station_Address":"Trường Ngã ba  Giòng, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.863337
    ,"Long":106.567876
    ,"Polyline":"[106.56668854,10.86393738] ; [106.56677246,10.86411667] ; [106.56793213,10.86352634] ; [106.56787872,10.86333656]"
    ,"Distance":"187"
  },
  {
     "Route_Id":"49"
    ,"Station_Id":"2426"
    ,"Station_Code":"BX 53"
    ,"Station_Direction":"1"
    ,"Station_Order":"65"
    ,"Station_Name":"Xuân Thới  Thượng"
    ,"Station_Address":"ĐẦU BẾN XUÂN THỚI THƯỢNG, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.86085
    ,"Long":106.567406
    ,"Polyline":"[106.56787872,10.86333656] ; [106.56802368,10.86349487] ; [106.56831360,10.86338902] ; [106.56784058,10.86237812] ; [106.56771851,10.86185074] ; [106.56759644,10.86086082] ; [106.56740570,10.86085033]"
    ,"Distance":"374"
  }]