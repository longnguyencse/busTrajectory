export const Route16 =[
  {
     "Route_Id":"16"
    ,"Station_Id":"955"
    ,"Station_Code":"BX 65"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bố Heo"
    ,"Station_Address":"ĐẦU BẾN BỐ HEO, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.061848
    ,"Long":106.421696
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"956"
    ,"Station_Code":"HCC 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bố Heo"
    ,"Station_Address":"Đối diện 1010, đường Hương lộ 2, Huyện  Củ Chi"
    ,"Lat":11.0617
    ,"Long":106.421333
    ,"Polyline":"[106.42112732,11.06268501] ; [106.42078400,11.06252670] ; [106.42133331,11.06169987]"
    ,"Distance":"151"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"958"
    ,"Station_Code":"QCCT244"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Biogas Computer"
    ,"Station_Address":"Đối diện cột điện 210/31A , đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.049638748168945
    ,"Long":106.43225860595703
    ,"Polyline":"[106.42133331,11.06169987] ; [106.43224335,11.05038643] ; [106.43225861,11.04963875]"
    ,"Distance":"1817"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"959"
    ,"Station_Code":"QCCT245"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Kênh Đông"
    ,"Station_Address":"Đối diện cột điện TH2/120, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.045110702514648
    ,"Long":106.43672180175781
    ,"Polyline":"[106.43225861,11.04963875] ; [106.43267059,11.04994392] ; [106.43700409,11.04541588] ; [106.43672180,11.04511070]"
    ,"Distance":"794"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"960"
    ,"Station_Code":"QCCT246"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Điện tử Hoàn"
    ,"Station_Address":"Đối diện cột điện 210/15A, đường Hương lộ  2, Huyện Củ Chi"
    ,"Lat":11.040624618530273
    ,"Long":106.44110107421875
    ,"Polyline":"[106.43707275,11.04543018] ; [106.44136810,11.04086971]"
    ,"Distance":"784"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"962"
    ,"Station_Code":"QCCT247"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Vật  liệu  xây dựng Thanh Hiền"
    ,"Station_Address":"Đối  diện cột điện 210/1A, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.035338401794434
    ,"Long":106.44583892822266
    ,"Polyline":"[106.44136810,11.04086971] ; [106.44624329,11.03571033]"
    ,"Distance":"884"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"968"
    ,"Station_Code":"QCCT186"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cửa hàng Khánh Trung"
    ,"Station_Address":"Đối diện 176 , đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.033866882324219
    ,"Long":106.44636535644531
    ,"Polyline":"[106.44583893,11.03533840] ; [106.44613647,11.03561211] ; [106.44710541,11.03459644] ; [106.44641876,11.03381729] ; [106.44636536,11.03386688]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"970"
    ,"Station_Code":"HCC 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã tư Lào Táo"
    ,"Station_Address":"57, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.027333
    ,"Long":106.442131
    ,"Polyline":"[106.44636536,11.03386688] ; [106.44612885,11.03360081] ; [106.44434357,11.03155804] ; [106.44213104,11.02733326]"
    ,"Distance":"868"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"957"
    ,"Station_Code":"HCC 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã 3 Đất Đỏ"
    ,"Station_Address":"981, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.017517
    ,"Long":106.436348
    ,"Polyline":"[106.43968964,11.02305984] ; [106.43785095,11.02001953] ; [106.43692780,11.01842022]"
    ,"Distance":"1262"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"971"
    ,"Station_Code":"HCC 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Xưởng Cưa"
    ,"Station_Address":"901, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.013717
    ,"Long":106.434166
    ,"Polyline":"[106.43634796,11.01751709] ; [106.43416595,11.01371670]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"961"
    ,"Station_Code":"HCC 142"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Kinh Đông"
    ,"Station_Address":"Đối diện 878, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.0091
    ,"Long":106.430649
    ,"Polyline":"[106.43434906,11.01397991] ; [106.43283844,11.01132011] ; [106.43213654,11.01049995] ; [106.43110657,11.00951958]"
    ,"Distance":"719"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"975"
    ,"Station_Code":"HCC 143"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"trường tiểu học An Phước"
    ,"Station_Address":"825, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.007324
    ,"Long":106.428505
    ,"Polyline":"[106.43064880,11.00909996] ; [106.42850494,11.00732422]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"790"
    ,"Station_Code":"HCC 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm y tế xã Phước Thạnh"
    ,"Station_Address":"Trạm y tế xã Phước Tha ̣nh ( Đối diện 830 ), đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":11.005567
    ,"Long":106.428069
    ,"Polyline":"[106.42850494,11.00732422] ; [106.42762756,11.00648403] ; [106.42740631,11.00587273] ; [106.42808533,11.00564957]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"784"
    ,"Station_Code":"HCC 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Xã Phước Hiệp"
    ,"Station_Address":"585, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.996617
    ,"Long":106.44487
    ,"Polyline":"[106.42808533,11.00564957] ; [106.43528748,11.00329304] ; [106.44228363,10.99937439] ; [106.44487000,10.99661732]"
    ,"Distance":"2127"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"792"
    ,"Station_Code":"HCC 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường tiểu học Phước Hiệp"
    ,"Station_Address":"499, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.9928
    ,"Long":106.448334
    ,"Polyline":"[106.44487000,10.99661732] ; [106.44833374,10.99279976]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"794"
    ,"Station_Code":"HCC 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã 3 Cây Trôm"
    ,"Station_Address":"Trạm y  tế Nguyễn Thị Rành, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.989567
    ,"Long":106.451263
    ,"Polyline":"[106.44833374,10.99279976] ; [106.45126343,10.98956680]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"785"
    ,"Station_Code":"HCC 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cây xăng Phước Hiệp 1"
    ,"Station_Address":"281, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.982883
    ,"Long":106.461014
    ,"Polyline":"[106.45126343,10.98956680] ; [106.46101379,10.98288345]"
    ,"Distance":"1300"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"796"
    ,"Station_Code":"HCC 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công ty  sinh hóa Củ Chi"
    ,"Station_Address":"121, đ ường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.977784
    ,"Long":106.469632
    ,"Polyline":"[106.46101379,10.98288345] ; [106.46965027,10.97784996]"
    ,"Distance":"1098"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"787"
    ,"Station_Code":"HCC 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 3 Nguyễn Thị Rành"
    ,"Station_Address":"55, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.976109
    ,"Long":106.472717
    ,"Polyline":"[106.46965027,10.97784996] ; [106.47273254,10.97614956]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"788"
    ,"Station_Code":"HCC 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Bệnh viện Củ Chi"
    ,"Station_Address":"991, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.973655
    ,"Long":106.477443
    ,"Polyline":"[106.47273254,10.97614956] ; [106.47273254,10.97614956] ; [106.47513580,10.97480297] ; [106.47747040,10.97373295] ; [106.47747040,10.97373295]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"963"
    ,"Station_Code":"HCC 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Bệnh vi ện Củ Chi"
    ,"Station_Address":"907, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.972091
    ,"Long":106.48049
    ,"Polyline":"[106.47747040,10.97373295] ; [106.47747040,10.97373295] ; [106.48021698,10.97238636] ; [106.48051453,10.97213268] ; [106.48051453,10.97213268]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc  lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":"[106.48051453,10.97213268] ; [106.48102570,10.97177505] ; [106.48171997,10.97117519] ; [106.48210144,10.97161674]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"734"
    ,"Station_Code":"HCC 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe C ủ Chi"
    ,"Station_Address":"926, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.972533
    ,"Long":106.480347
    ,"Polyline":"[106.48210144,10.97161674] ; [106.48176575,10.97135925] ; [106.48105621,10.97202301] ; [106.48034668,10.97253323]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"733"
    ,"Station_Code":"HCC 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Bệnh viện Củ Chi"
    ,"Station_Address":"18,  đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.974417
    ,"Long":106.476402
    ,"Polyline":"[106.48034668,10.97253323] ; [106.47640228,10.97441673]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"738"
    ,"Station_Code":"HCC 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm xăng"
    ,"Station_Address":"86, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.976133
    ,"Long":106.473129
    ,"Polyline":"[106.47640228,10.97441673] ; [106.47312927,10.97613335]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"735"
    ,"Station_Code":"HCC 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà máy Sinh hóa Củ Chi"
    ,"Station_Address":"128, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.978179
    ,"Long":106.469455
    ,"Polyline":"[106.47312927,10.97613335] ; [106.46943665,10.97816658]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"741"
    ,"Station_Code":"HCC 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trạm xăng Phước Hiệp 1"
    ,"Station_Address":"282, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.98305
    ,"Long":106.461232
    ,"Polyline":"[106.46943665,10.97816658] ; [106.46116638,10.98296738]"
    ,"Distance":"1050"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"736"
    ,"Station_Code":"HCC 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trạm y tế Nguyễn Thị Rành"
    ,"Station_Address":"Đối diện trạm y tế Nguyễn Thị Rành, đường Quốc lộ 22, Huyện  Củ Chi"
    ,"Lat":10.991035
    ,"Long":106.450378
    ,"Polyline":"[106.46116638,10.98296738] ; [106.45194244,10.98922253] ; [106.45037842,10.99103546]"
    ,"Distance":"1490"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"743"
    ,"Station_Code":"HCC 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã 3 Ba Sa"
    ,"Station_Address":"508, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.993072
    ,"Long":106.448448
    ,"Polyline":"[106.45037842,10.99103546] ; [106.44837952,10.99295044]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"737"
    ,"Station_Code":"HCC 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây xăng Phước Thạnh 2"
    ,"Station_Address":"580, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.996789
    ,"Long":106.445058
    ,"Polyline":"[106.44837952,10.99295044] ; [106.44496918,10.99673271]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"745"
    ,"Station_Code":"HCC 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"UBND xã Phước Thạnh"
    ,"Station_Address":"UBND xã Phước Thạnh, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":11.00463
    ,"Long":106.431969
    ,"Polyline":"[106.44336700,10.99845028] ; [106.44286346,10.99899960] ; [106.44242859,10.99940014] ; [106.44203949,10.99971008] ; [106.44156647,11.00002956] ; [106.44090271,11.00041008] ; [106.43900299,11.00142956] ; [106.43641663,11.00282001] ; [106.43560028,11.00325012] ; [106.43491364,11.00356007] ; [106.43373871,11.00397015]"
    ,"Distance":"1689"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"739"
    ,"Station_Code":"QCCT028"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Phước Thạnh"
    ,"Station_Address":"892, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":11.005766868591309
    ,"Long":106.42814636230469
    ,"Polyline":"[106.43198395,11.00454998] ; [106.42814636,11.00576687]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"947"
    ,"Station_Code":"HCC 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường tiểu học An Phước"
    ,"Station_Address":"814B, đường Tỉnh lộ 7 Củ Chi , Huyện Củ Chi"
    ,"Lat":11.006868
    ,"Long":106.428146
    ,"Polyline":"[106.42814636,11.00576687] ; [106.42750549,11.00602055] ; [106.42761993,11.00638866] ; [106.42814636,11.00686836]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"939"
    ,"Station_Code":"HCC 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Quán 777"
    ,"Station_Address":"896, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.009431
    ,"Long":106.431084
    ,"Polyline":"[106.42814636,11.00686836] ; [106.43108368,11.00943089]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"949"
    ,"Station_Code":"HCC 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Kinh Đông"
    ,"Station_Address":"1028, đường Tỉnh lộ 7 Cu ̉ Chi, Huyện Củ Chi"
    ,"Lat":11.0142
    ,"Long":106.434502
    ,"Polyline":"[106.43108368,11.00943089] ; [106.43247986,11.01087570] ; [106.43325043,11.01192856] ; [106.43450165,11.01420021]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"940"
    ,"Station_Code":"HCC 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Xưởng Cưa"
    ,"Station_Address":"1080B, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.017812
    ,"Long":106.436638
    ,"Polyline":"[106.43450165,11.01420021] ; [106.43663788,11.01781178]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"950"
    ,"Station_Code":"HCC 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã 3 Đất Đỏ"
    ,"Station_Address":"Đối diện 37, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.026721
    ,"Long":106.441864
    ,"Polyline":"[106.43663788,11.01781178] ; [106.44186401,11.02672100]"
    ,"Distance":"1144"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"941"
    ,"Station_Code":"HCC 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã tư Lào Táo"
    ,"Station_Address":"176, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.03415
    ,"Long":106.446716
    ,"Polyline":"[106.44186401,11.02672100] ; [106.44468689,11.03172684] ; [106.44671631,11.03415012]"
    ,"Distance":"986"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"952"
    ,"Station_Code":"QCCT238"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Vật  liệu xây dựng Thanh Hiền"
    ,"Station_Address":"Cột điện 210/1A, đường Hư ơng lộ 2, Huyện Củ Chi"
    ,"Lat":11.036370277404785
    ,"Long":106.44581604003906
    ,"Polyline":"[106.44671631,11.03415012] ; [106.44718933,11.03466415] ; [106.44569397,11.03627586] ; [106.44581604,11.03637028]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"945"
    ,"Station_Code":"QCCT239"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Điện tử  Hoàn"
    ,"Station_Address":"Nhà nghỉ Ngọc Huyền - Điện tử Hoàn, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.040477752685547
    ,"Long":106.44189453125
    ,"Polyline":"[106.44581604,11.03637028] ; [106.44569397,11.03625488] ; [106.44181061,11.04041386] ; [106.44189453,11.04047775]"
    ,"Distance":"658"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"953"
    ,"Station_Code":"QCCT240"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Kênh Đông"
    ,"Station_Address":"Cột điện TH 120, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.04513168334961
    ,"Long":106.43766784667969
    ,"Polyline":"[106.44181061,11.04039955] ; [106.43749237,11.04498005]"
    ,"Distance":"733"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"948"
    ,"Station_Code":"QCCT241"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Biogas Computer"
    ,"Station_Address":"Cột điện VH 3 - 127, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.050586700439453
    ,"Long":106.43266296386719
    ,"Polyline":"[106.43749237,11.04498005] ; [106.43242645,11.05037975]"
    ,"Distance":"877"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"954"
    ,"Station_Code":"HCC 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm cuối Củ Chi"
    ,"Station_Address":"1010, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.059183
    ,"Long":106.424202
    ,"Polyline":"[106.43242645,11.05037975] ; [106.42872620,11.05432034]"
    ,"Distance":"1364"
  },
  {
     "Route_Id":"16"
    ,"Station_Id":"955"
    ,"Station_Code":"BX 65"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bố Heo"
    ,"Station_Address":"ĐẦU BẾN BỐ HEO, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.061848
    ,"Long":106.421696
    ,"Polyline":"[106.42420197,11.05918312] ; [106.42112732,11.06268501]"
    ,"Distance":"515"
  }]