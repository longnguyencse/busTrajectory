export const Route31 =[
  {
     "Route_Id":"31"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguyễn Ảnh Thủ, Quận  12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1744"
    ,"Station_Code":"Q12 172"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Hiệp Thành 31"
    ,"Station_Address":"66A, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.876613
    ,"Long":106.644137
    ,"Polyline":"[106.64203644,10.87744999] ; [106.64182281,10.87708664] ; [106.64400482,10.87676525] ; [106.64413452,10.87661266]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1743"
    ,"Station_Code":"Q12 173"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Lê Văn Kh ương"
    ,"Station_Address":"17 - 21, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.87617
    ,"Long":106.648069
    ,"Polyline":"[106.64413452,10.87661266] ; [106.64440155,10.87672806] ; [106.64671326,10.87646484] ; [106.64807129,10.87617016]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1746"
    ,"Station_Code":"Q12 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Đài liệt sỹ"
    ,"Station_Address":"Đài liệt sỹ, đường Lê Văn Khương, Qu ận 12"
    ,"Lat":10.874953
    ,"Long":106.648972
    ,"Polyline":"[106.64807129,10.87617016] ; [106.64823151,10.87622833] ; [106.64904785,10.87611198] ; [106.64907074,10.87511063] ; [106.64897156,10.87495327]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1745"
    ,"Station_Code":"Q12 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Hiệp Thành 49"
    ,"Station_Address":"251, đường Lê Văn Khương,  Quận 12"
    ,"Lat":10.871424
    ,"Long":106.649185
    ,"Polyline":"[106.64897156,10.87495327] ; [106.64906311,10.87473679] ; [106.64918518,10.87142372]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1748"
    ,"Station_Code":"Q12 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà máy Bia"
    ,"Station_Address":"119, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.867475
    ,"Long":106.649368
    ,"Polyline":"[106.64918518,10.87142372] ; [106.64936829,10.86747456]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1747"
    ,"Station_Code":"Q12 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Metro Hiệp Phú"
    ,"Station_Address":"Metro Hiệp Phú, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.862768
    ,"Long":106.649641
    ,"Polyline":"[106.64936829,10.86747456] ; [106.64964294,10.86276817]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"973"
    ,"Station_Code":"QGV 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Nhà thờ Nữ Vương Hòa Bình"
    ,"Station_Address":"Đối diện nhà thờ Nữ Vương Hòa Bình, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.856841
    ,"Long":106.653809
    ,"Polyline":"[106.64964294,10.86276817] ; [106.64980316,10.86125088] ; [106.64985657,10.86099720] ; [106.64997101,10.86074448] ; [106.65338135,10.85738373] ; [106.65380859,10.85684109]"
    ,"Distance":"834"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"974"
    ,"Station_Code":"QGV 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã Ba Lê Đức Thọ"
    ,"Station_Address":"603 (đối di ện 658), đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.854064
    ,"Long":106.655944
    ,"Polyline":"[106.65380859,10.85684109] ; [106.65502930,10.85591888] ; [106.65582275,10.85510731] ; [106.65605927,10.85489655] ; [106.65594482,10.85406399]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"978"
    ,"Station_Code":"QGV 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà hàng  Tư Trì"
    ,"Station_Address":"477, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.849254
    ,"Long":106.656454
    ,"Polyline":"[106.65594482,10.85406399] ; [106.65615082,10.85058689] ; [106.65645599,10.84925365]"
    ,"Distance":"540"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"979"
    ,"Station_Code":"QGV 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Câu lạc  bộ Tenis"
    ,"Station_Address":"329, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.845756
    ,"Long":106.656947
    ,"Polyline":"[106.65645599,10.84925365] ; [106.65674591,10.84858513] ; [106.65693665,10.84761620] ; [106.65698242,10.84655190] ; [106.65694427,10.84575558]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"981"
    ,"Station_Code":"QGV 149"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã Ba Cây Trâm"
    ,"Station_Address":"217, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.843266
    ,"Long":106.657059
    ,"Polyline":"[106.65694427,10.84575558] ; [106.65705109,10.84455967] ; [106.65705872,10.84326553]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"4731"
    ,"Station_Code":"QGV 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Đường số 12"
    ,"Station_Address":"76 , đường Đường số 11, Quận Gò Vấp"
    ,"Lat":10.842236
    ,"Long":106.659522
    ,"Polyline":"[106.65705872,10.84326553] ; [106.65712738,10.84259987] ; [106.65763092,10.84257412] ; [106.65854645,10.84235764] ; [106.65861511,10.84226799]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"4729"
    ,"Station_Code":"QGV 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Chùa Ngh ệ Sỹ"
    ,"Station_Address":"Chùa Nghệ Sỹ, đường Đường số 11, Quận Gò Vấp"
    ,"Lat":10.841725
    ,"Long":106.661566
    ,"Polyline":"[106.65861511,10.84226799] ; [106.65873718,10.84231567] ; [106.65978241,10.84215260] ; [106.66144562,10.84170437] ; [106.66155243,10.84160423]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"4730"
    ,"Station_Code":"QGV 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"111 , đường Đường số 11, Quận Gò Vấp"
    ,"Lat":10.840651
    ,"Long":106.662558
    ,"Polyline":"[106.66155243,10.84160423] ; [106.66166687,10.84163570] ; [106.66248322,10.84144115] ; [106.66255951,10.84120369] ; [106.66253662,10.84085083]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"4734"
    ,"Station_Code":"QGV 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Công an  Phường 11"
    ,"Station_Address":"Đối diện Công an Phường 11, đường Đường số 11, Quận Gò Vấp"
    ,"Lat":10.839702
    ,"Long":106.664178
    ,"Polyline":"[106.66253662,10.84085083] ; [106.66268921,10.84009743] ; [106.66472626,10.83967018] ; [106.66484070,10.83961296]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1754"
    ,"Station_Code":"QGV 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Ba Nguyễn Văn Lượng"
    ,"Station_Address":"303, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.839223
    ,"Long":106.665245
    ,"Polyline":"[106.66484070,10.83961296] ; [106.66484070,10.83961296] ; [106.66493988,10.83967590] ; [106.66530609,10.83971310.06.66524506] ; [10.83922291,106.66524506]"
    ,"Distance":"108"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1755"
    ,"Station_Code":"QGV 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Điện Lực Gò Vấp"
    ,"Station_Address":"287, đường Nguyễn Văn Lượng, Quận Gò V ấp"
    ,"Lat":10.838564
    ,"Long":106.666275
    ,"Polyline":"[106.66524506,10.83922291] ; [106.66526031,10.83865929] ; [106.66613770,10.83863831] ; [106.66627502,10.83856392]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1757"
    ,"Station_Code":"QGV 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Công ty Hùng Hy"
    ,"Station_Address":"Đối diện 282, đường Nguyễn Văn Lượng, Quận Gò Vấp"
    ,"Lat":10.838548
    ,"Long":106.670712
    ,"Polyline":"[106.66627502,10.83856392] ; [106.67109680,10.83850384]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1756"
    ,"Station_Code":"QGV 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã 6 Gò Vấp"
    ,"Station_Address":"159, đường Nguyễn Văn Lượng,  Quận Gò Vấp"
    ,"Lat":10.838501
    ,"Long":106.674693
    ,"Polyline":"[106.67109680,10.83850384] ; [106.67301941,10.83858490] ; [106.67499542,10.83848476]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1758"
    ,"Station_Code":"QGV 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"133, đường Nguyễn Văn Lượng, Quận Gò Vấp"
    ,"Lat":10.83847
    ,"Long":106.675911
    ,"Polyline":"[106.67499542,10.83848476] ; [106.67512512,10.83855915] ; [106.67584229,10.83854866] ; [106.67591095,10.83847046]"
    ,"Distance":"107"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1759"
    ,"Station_Code":"QGV 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"UBND Ph ường 17, Quận Gò Vấp"
    ,"Station_Address":"27, đường Nguyễn Văn Lượng, Qu ận Gò Vấp"
    ,"Lat":10.838429
    ,"Long":106.679352
    ,"Polyline":"[106.67591095,10.83847046] ; [106.67601776,10.83853817] ; [106.67763519,10.83856392] ; [106.67920685,10.83852768] ; [106.67935181,10.83842945]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1760"
    ,"Station_Code":"QGV 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường văn thư lưu trữ"
    ,"Station_Address":"Đối diện 210, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.837426
    ,"Long":106.680545
    ,"Polyline":"[106.67935181,10.83842945] ; [106.67945862,10.83853817] ; [106.68009949,10.83858013] ; [106.68043518,10.83794785] ; [106.68054199,10.83742619]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"4743"
    ,"Station_Code":"QGV 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Đường số 9"
    ,"Station_Address":"211, đường Dương Quãng Hàm , Quận Gò Vấp"
    ,"Lat":10.836646
    ,"Long":106.683179
    ,"Polyline":"[106.68054199,10.83742619] ; [106.68099213,10.83650398] ; [106.68298340,10.83722115] ; [106.68318176,10.83664608]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1763"
    ,"Station_Code":"QGV 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Karaoke Tuấn"
    ,"Station_Address":"127, đường Dương Quảng Hàm, Quận Gò Vấp"
    ,"Lat":10.834676
    ,"Long":106.684174
    ,"Polyline":"[106.68318176,10.83664608] ; [106.68328857,10.83662033] ; [106.68419647,10.83485508] ; [106.68417358,10.83467579]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1764"
    ,"Station_Code":"QGV 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Bến  Cát"
    ,"Station_Address":"Đối diện 272 (22), đường Dương Quảng Hàm, Quận Gò Vấp"
    ,"Lat":10.828843
    ,"Long":106.689193
    ,"Polyline":"[106.68417358,10.83467579] ; [106.68495178,10.83336926] ; [106.68791199,10.83041859] ; [106.68919373,10.82884312]"
    ,"Distance":"854"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1765"
    ,"Station_Code":"QGV 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà hàng Vườn Cau"
    ,"Station_Address":"Đối diện 472 , đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.826978
    ,"Long":106.689879
    ,"Polyline":"[106.68919373,10.82884312] ; [106.68931580,10.82884884] ; [106.69024658,10.82785225] ; [106.69062805,10.82758427] ; [106.68988037,10.82697773]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1766"
    ,"Station_Code":"QGV 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Bãi hậu  cần số 1"
    ,"Station_Address":"439, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.823559
    ,"Long":106.692165
    ,"Polyline":"[106.68988037,10.82697773] ; [106.68931580,10.82627773] ; [106.69079590,10.82493877] ; [106.69216156,10.82355881]"
    ,"Distance":"534"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1767"
    ,"Station_Code":"QBTH 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chùa Giác Quang"
    ,"Station_Address":"189, đường Phan  Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.819749
    ,"Long":106.694375
    ,"Polyline":"[106.69216156,10.82355881] ; [106.69315338,10.82271576] ; [106.69337463,10.82239914] ; [106.69364929,10.82148266] ; [106.69437408,10.81974888]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1769"
    ,"Station_Code":"QBTH 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"235, đường Phan Văn Trị, Quận Bình Th ạnh"
    ,"Lat":10.813695
    ,"Long":106.695217
    ,"Polyline":"[106.69437408,10.81974888] ; [106.69457245,10.81925869] ; [106.69498444,10.81817341] ; [106.69533539,10.81724644] ; [106.69523621,10.81641388] ; [106.69521332,10.81369495]"
    ,"Distance":"694"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1768"
    ,"Station_Code":"QBTH 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"89, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809833
    ,"Long":106.695061
    ,"Polyline":"[106.69521332,10.81369495] ; [106.69531250,10.81149197] ; [106.69546509,10.81126022] ; [106.69518280,10.81051254] ; [106.69506073,10.80983257]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1770"
    ,"Station_Code":"QBTH 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Cây Xăng 178"
    ,"Station_Address":"117-119, đường  Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.806666
    ,"Long":106.696794
    ,"Polyline":"[106.69506073,10.80983257] ; [106.69509125,10.80830479] ; [106.69532776,10.80818844] ; [106.69631958,10.80723476] ; [106.69679260,10.80666637]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1771"
    ,"Station_Code":"QBTH 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường TH  Nguyễn Đình Chiểu"
    ,"Station_Address":"1A, đường Lê Quang Định, Quận Bình Th ạnh"
    ,"Lat":10.803278
    ,"Long":106.698366
    ,"Polyline":"[106.69679260,10.80666637] ; [106.69734192,10.80589676] ; [106.69788361,10.80525875] ; [106.69805145,10.80476856] ; [106.69836426,10.80327797]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"473C, đường Bạch Đằng, Qu ận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69836426,10.80327797] ; [106.69856262,10.80260849] ; [106.69955444,10.80296135]"
    ,"Distance":"193"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Th ạnh"
    ,"Station_Address":"449, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69955444,10.80296135] ; [106.70040131,10.80334568] ; [106.70117950,10.80362511]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chùa B ồ Đề"
    ,"Station_Address":"375, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70117950,10.80362511] ; [106.70127106,10.80370426] ; [106.70159149,10.80382538] ; [106.70271301,10.80353546] ; [106.70398712,10.80329323]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70398712,10.80329323] ; [106.70536804,10.80324078] ; [106.70671082,10.80307674]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đ ằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70671082,10.80307674] ; [106.70861816,10.80306149] ; [106.71051025,10.80279255]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338 , đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71051025,10.80279255] ; [106.71124268,10.80278206] ; [106.71140289,10.80285072] ; [106.71154022,10.80474758]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Đài Li ệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71158600,10.80786705] ; [106.71176910,10.80845165] ; [106.71196747,10.80883121]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128, đường  Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71196747,10.80883121] ; [106.71220398,10.80967999] ; [106.71260834,10.81231976] ; [106.71260834,10.81231976]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Qu ốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71260834,10.81231976] ; [106.71263885,10.81297302] ; [106.71279144,10.81385326]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71313477,10.81739330] ; [106.71292114,10.81740475] ; [106.71209717,10.81723022] ; [106.71125793,10.81666088]"
    ,"Distance":"623"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền  Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71125793,10.81666088] ; [106.70979309,10.81382656] ; [106.71014404,10.81394291] ; [106.71070099,10.81506443] ; [106.71129608,10.81473255]"
    ,"Distance":"608"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền  Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71129608,10.81473255] ; [106.71073151,10.81503296] ; [106.71122742,10.81597137] ; [106.71095276,10.81619263] ; [106.70922089,10.81262493]"
    ,"Distance":"666"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã Tư Chu  Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70922089,10.81262493] ; [106.70911407,10.81200886] ; [106.70914459,10.80975914]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Đinh  Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh  Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70914459,10.80975914] ; [106.70934296,10.80690765]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh B ộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70934296,10.80690765] ; [106.70949554,10.80552769] ; [106.70939636,10.80442142]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường B ạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.70939636,10.80442142] ; [106.70938110,10.80305576] ; [106.70803070,10.80317688]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70803070,10.80317688] ; [106.70401764,10.80348301]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"288 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70401764,10.80348301] ; [106.70288086,10.80356216] ; [106.70153809,10.80391026] ; [106.70096588,10.80375671]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Bà Chi ểu"
    ,"Station_Address":"368, đường Bạch Đằng , Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70096588,10.80375671] ; [106.69937134,10.80312538]"
    ,"Distance":"188"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1648"
    ,"Station_Code":"QBTH 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường TH Nguyễn Đình Chiểu"
    ,"Station_Address":"22-24, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.803241
    ,"Long":106.698462
    ,"Polyline":"[106.69937134,10.80312538] ; [106.69855499,10.80271912] ; [106.69846344,10.80324078]"
    ,"Distance":"159"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1651"
    ,"Station_Code":"QBTH 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cây Xăng  178"
    ,"Station_Address":"164, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.80665
    ,"Long":106.696912
    ,"Polyline":"[106.69846344,10.80324078] ; [106.69805908,10.80475330] ; [106.69786835,10.80528545] ; [106.69734955,10.80588627] ; [106.69691467,10.80665016]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1650"
    ,"Station_Code":"QBTH 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"124, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809732
    ,"Long":106.695158
    ,"Polyline":"[106.69691467,10.80665016] ; [106.69630432,10.80727196] ; [106.69534302,10.80816174] ; [106.69512939,10.80827808] ; [106.69515991,10.80973244]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1654"
    ,"Station_Code":"QBTH 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"182B/2, đường Phan Văn Trị, Quận Bình  Thạnh"
    ,"Lat":10.812722
    ,"Long":106.695343
    ,"Polyline":"[106.69515991,10.80973244] ; [106.69518280,10.81048107] ; [106.69544220,10.81123924] ; [106.69532776,10.81149197] ; [106.69534302,10.81272221]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1652"
    ,"Station_Code":"QBTH 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chùa Giác Quang"
    ,"Station_Address":"342, đường Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.819601
    ,"Long":106.694536
    ,"Polyline":"[106.69534302,10.81272221] ; [106.69522858,10.81621361] ; [106.69531250,10.81720448] ; [106.69522858,10.81767845] ; [106.69485474,10.81857395] ; [106.69453430,10.81960106]"
    ,"Distance":"780"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"6853"
    ,"Station_Code":"QGV 196"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Phan Văn Trị"
    ,"Station_Address":"39, đường Phạm Văn Đồng, Qu ận Gò Vấp"
    ,"Lat":10.820618
    ,"Long":106.693372
    ,"Polyline":"[106.69453430,10.81960106.06.69434357] ; [10.81999683,106.69420624] ; [10.82033920,106.69425964] ; [10.82044983,106.69429016] ; [10.82053375,106.69428253] ; [10.82062912,106.69425964] ; [10.82068729,106.69419098] ; [10.82075024,106.69409943] ; [10.82075500,106.69401550] ; [10.82074451,106.69359589] ; [10.82063389,106.69337463]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"2046"
    ,"Station_Code":"QGV 152"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"28, đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.821646
    ,"Long":106.688759
    ,"Polyline":"[106.69337463,10.82061768] ; [106.69268799,10.82036591] ; [106.69000244,10.81961727] ; [106.69002533,10.81977558] ; [106.68997192,10.81996536] ; [106.68982697,10.82015514] ; [106.68949890,10.82047653] ; [106.68914795,10.82075500] ; [106.68899536,10.82102394] ; [106.68892670,10.82118702] ; [106.68878937,10.82149792] ; [106.68875885,10.82164574]"
    ,"Distance":"659"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"462"
    ,"Station_Code":"QGV 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"UBND Phường 5, Quận Gò Vấp"
    ,"Station_Address":"396, đường Nguyễn Thái Sơn , Quận Gò Vấp"
    ,"Lat":10.82507
    ,"Long":106.687881
    ,"Polyline":"[106.68875885,10.82164574] ; [106.68867493,10.82170868] ; [106.68833160,10.82238388] ; [106.68793488,10.82313728] ; [106.68746948,10.82352161] ; [106.68654633,10.82417011] ; [106.68694305,10.82463837] ; [106.68773651,10.82508087] ; [106.68788147,10.82507038]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1656"
    ,"Station_Code":"QGV 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhà hàng Vườn Cau"
    ,"Station_Address":"484, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.827052
    ,"Long":106.690178
    ,"Polyline":"[106.68788147,10.82507038] ; [106.68788147,10.82507038] ; [106.68875122,10.82571316] ; [106.69017792,10.82705212] ; [106.69017792,10.82705212]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1653"
    ,"Station_Code":"QGV 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Bến Cát"
    ,"Station_Address":"262, đường Dương Quảng Hàm, Quận Gò V ấp"
    ,"Lat":10.82839
    ,"Long":106.689815
    ,"Polyline":"[106.69017792,10.82705212] ; [106.69061279,10.82756805] ; [106.69022369,10.82786369] ; [106.68981171,10.82839012]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1655"
    ,"Station_Code":"QGV 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Karaoke Tuấn"
    ,"Station_Address":"428 , đường Dương Quảng Hàm, Quận Gò Vấp"
    ,"Lat":10.834939
    ,"Long":106.684212
    ,"Polyline":"[106.68981171,10.82839012] ; [106.68741608,10.83098793] ; [106.68614960,10.83224678] ; [106.68550873,10.83288479] ; [106.68514252,10.83322716] ; [106.68490601,10.83351707] ; [106.68453217,10.83424377] ; [106.68421173,10.83493900]"
    ,"Distance":"959"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1660"
    ,"Station_Code":"QGV 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường s ố 9"
    ,"Station_Address":"484, đường Dương Quảng Hàm, Quận Gò Vấp"
    ,"Lat":10.83661
    ,"Long":106.683383
    ,"Polyline":"[106.68421173,10.83493900] ; [106.68373871,10.83575630] ; [106.68338013,10.83660984]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1657"
    ,"Station_Code":"QGV 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường V ăn Thư lưu trữ"
    ,"Station_Address":"214, đường L ê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.837026
    ,"Long":106.68091
    ,"Polyline":"[106.68338013,10.83660984] ; [106.68298340,10.83722115] ; [106.68102264,10.83652020] ; [106.68096924,10.83667755] ; [106.68090820,10.83689404] ; [106.68090820,10.83702564]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1662"
    ,"Station_Code":"QGV 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"UBND Phường 17, Quận Gò Vấp"
    ,"Station_Address":"54, đường Nguyễn Văn Lượng, Quận Gò V ấp"
    ,"Lat":10.838612
    ,"Long":106.679177
    ,"Polyline":"[106.68090820,10.83702564] ; [106.68077850,10.83714199] ; [106.68041229,10.83804226] ; [106.68009949,10.83860683] ; [106.67955780,10.83854866] ; [106.67917633,10.83861160]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1659"
    ,"Station_Code":"QGV 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"178, đường Nguyễn Văn Lượng,  Quận Gò Vấp"
    ,"Lat":10.838612
    ,"Long":106.676071
    ,"Polyline":"[106.67917633,10.83861160] ; [106.67761993,10.83855915] ; [106.67607117,10.83861160]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1664"
    ,"Station_Code":"QGV 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã 6 Gò Vấp"
    ,"Station_Address":"192, đường Nguyễn Văn Lượng, Quận Gò Vấp"
    ,"Lat":10.838617
    ,"Long":106.674467
    ,"Polyline":"[106.67607117,10.83861160] ; [106.67474365,10.83863258]"
    ,"Distance":"146"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1661"
    ,"Station_Code":"QGV 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Sân banh Đạt Đức"
    ,"Station_Address":"286, đường Nguyễn Văn Lượng , Quận Gò Vấp"
    ,"Lat":10.83867
    ,"Long":106.670144
    ,"Polyline":"[106.67474365,10.83863258] ; [106.67234039,10.83860683] ; [106.66989899,10.83868504]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1666"
    ,"Station_Code":"QGV 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Điện Lực Gò Vấp"
    ,"Station_Address":"372, đường Nguyễn Văn Lượng, Quận Gò  Vấp"
    ,"Lat":10.838696
    ,"Long":106.667027
    ,"Polyline":"[106.66989899,10.83868504] ; [106.66634369,10.83870602]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"4727"
    ,"Station_Code":"QGV 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Công an Phường 11"
    ,"Station_Address":"C ông an Phường 11, đường Đường số 11, Quận Gò Vấp"
    ,"Lat":10.839765
    ,"Long":106.665042
    ,"Polyline":"[106.66634369,10.83870602] ; [106.66526031,10.83865356] ; [106.66531372,10.83973408] ; [106.66503906,10.83976460]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"4728"
    ,"Station_Code":"QGV 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"90, đường Đường số 8, Quận Gò Vấp"
    ,"Lat":10.84054
    ,"Long":106.662698
    ,"Polyline":"[106.66503906,10.83976460] ; [106.66471100,10.83968639] ; [106.66268921,10.84009743] ; [106.66269684,10.84053993]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"928"
    ,"Station_Code":"QGV 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã Ba Cây Trâm"
    ,"Station_Address":"200, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.842993
    ,"Long":106.657219
    ,"Polyline":"[106.66269684,10.84053993] ; [106.66248322,10.84143066] ; [106.65979767,10.84214687] ; [106.65767670,10.84255791] ; [106.65715790,10.84258461] ; [106.65721893,10.84299278]"
    ,"Distance":"745"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"927"
    ,"Station_Code":"QGV 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Câu lạc  bộ Tenis"
    ,"Station_Address":"322, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.84584
    ,"Long":106.657074
    ,"Polyline":"[106.65721893,10.84299278] ; [106.65706635,10.84460258] ; [106.65707397,10.84584045]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"931"
    ,"Station_Code":"QGV 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Nhà hàng  Tư Trì"
    ,"Station_Address":"444, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.84918
    ,"Long":106.65667
    ,"Polyline":"[106.65707397,10.84584045] ; [106.65691376,10.84763718] ; [106.65666962,10.84918022]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"934"
    ,"Station_Code":"QGV 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã Ba L ê Đức Thọ"
    ,"Station_Address":"660, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.853996
    ,"Long":106.656137
    ,"Polyline":"[106.65666962,10.84918022] ; [106.65640259,10.84976578] ; [106.65612030,10.85078716] ; [106.65605927,10.85352707] ; [106.65613556,10.85399628]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"2742"
    ,"Station_Code":"QGV 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Nhà thờ Nữ Vương Hòa Bình"
    ,"Station_Address":"Nhà thờ Nữ Vương Hòa Binh, đường Lê Đ ức Thọ, Quận Gò Vấp"
    ,"Lat":10.856788
    ,"Long":106.654142
    ,"Polyline":"[106.65613556,10.85399628] ; [106.65613556,10.85399628] ; [106.65609741,10.85489655] ; [106.65582275,10.85512829] ; [106.65553284,10.85547638] ; [106.65414429,10.85678768] ; [106.65414429,10.85678768]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1670"
    ,"Station_Code":"Q12 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Metro Hiệp Phú"
    ,"Station_Address":"48, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.863513
    ,"Long":106.649757
    ,"Polyline":"[106.65414429,10.85678768] ; [106.65233612,10.85843754] ; [106.65055084,10.86013317] ; [106.64991760,10.86082935] ; [106.64982605,10.86125088] ; [106.64975739,10.86351299]"
    ,"Distance":"945"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1669"
    ,"Station_Code":"Q12 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Công ty bia Tiger"
    ,"Station_Address":"Công ty bia Tiger, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.868094
    ,"Long":106.649555
    ,"Polyline":"[106.64975739,10.86351299] ; [106.64955139,10.86809444]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1674"
    ,"Station_Code":"Q12 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Bảo hiểm xã hội Quận 12"
    ,"Station_Address":"270, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.872066
    ,"Long":106.649335
    ,"Polyline":"[106.64955139,10.86809444] ; [106.64937592,10.87005901] ; [106.64933777,10.87206554]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1671"
    ,"Station_Code":"Q12 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"UBND phường Thới An"
    ,"Station_Address":"Ủy ban nhân dan P.Thới An, đường Lê  Văn Khương, Quận 12"
    ,"Lat":10.874247
    ,"Long":106.649238
    ,"Polyline":"[106.64933777,10.87206554] ; [106.64920044,10.87318802] ; [106.64923859,10.87424660]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"6834"
    ,"Station_Code":"Q12 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Lê Văn Khương"
    ,"Station_Address":"89/4, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.87627
    ,"Long":106.648445
    ,"Polyline":"[106.64923859,10.87424660] ; [106.64917755,10.87446880] ; [106.64906311,10.87611198] ; [106.64844513,10.87627029]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"6835"
    ,"Station_Code":"Q12 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Hiệp Th ành 31"
    ,"Station_Address":"140, đường Nguyễn  Ảnh Thủ, Quận 12"
    ,"Lat":10.876876
    ,"Long":106.64418
    ,"Polyline":"[106.64844513,10.87627029] ; [106.64418030,10.87687588]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"31"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":"[106.64418030,10.87687588] ; [106.64182281,10.87707615] ; [106.64203644,10.87744999]"
    ,"Distance":"306"
  }]