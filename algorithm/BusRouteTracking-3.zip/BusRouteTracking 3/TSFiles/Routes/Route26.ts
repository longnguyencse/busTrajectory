export const Route26 =[
  {
     "Route_Id":"26"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vư ơng, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"4149"
    ,"Station_Code":"QBT 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"49-51 (317), Kinh Dương Vương"
    ,"Station_Address":"49-51 (317), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743396
    ,"Long":106.62136
    ,"Polyline":"[106.61979720,10.74053589] ; [106.61992200,10.74073772] ; [106.61960700,10.74118199] ; [106.61933900,10.74149895] ; [106.61916350,10.74172497] ; [106.62038420,10.74270058] ; [106.62089540,10.74316406] ; [106.62136080,10.74339581]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.62136078,10.74339581] ; [106.62225342,10.74422836] ; [106.62316132,10.74491882]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"718"
    ,"Station_Code":"Q6 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cư xá Phú Lâm"
    ,"Station_Address":"799 (209), đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.74776
    ,"Long":106.626332
    ,"Polyline":"[106.62316132,10.74491882] ; [106.62332153,10.74508286] ; [106.62363434,10.74522495] ; [106.62371826,10.74528790] ; [106.62382507,10.74531937] ; [106.62390137,10.74537754] ; [106.62394714,10.74544621] ; [106.62397766,10.74551487] ; [106.62398529,10.74561977] ; [106.62428284,10.74606323] ; [106.62633514,10.74775982]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"715"
    ,"Station_Code":"Q6 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"685 (157), đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.748877
    ,"Long":106.627727
    ,"Polyline":"[106.62633514,10.74775982] ; [106.62772369,10.74887657]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"720"
    ,"Station_Code":"Q6 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"93, đường Kinh  Dương Vương, Quận 6"
    ,"Lat":10.751201
    ,"Long":106.630753
    ,"Polyline":"[106.62772369,10.74887657] ; [106.63075256,10.75120068]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"717"
    ,"Station_Code":"Q6 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"21A-21B, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.753246
    ,"Long":106.633521
    ,"Polyline":"[106.63075256,10.75120068] ; [106.63206482,10.75226593] ; [106.63247681,10.75258732] ; [106.63352203,10.75324631]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"724"
    ,"Station_Code":"Q6 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Ông Buông"
    ,"Station_Address":"963, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754548
    ,"Long":106.637995
    ,"Polyline":"[106.63352203,10.75324631] ; [106.63419342,10.75377846] ; [106.63428497,10.75369453] ; [106.63439178,10.75366783] ; [106.63457489,10.75368404] ; [106.63468170,10.75373077] ; [106.63475037,10.75380993] ; [106.63478851,10.75390530] ; [106.63482666,10.75399971] ; [106.63520813,10.75428963] ; [106.63536835,10.75437927] ; [106.63555908,10.75439548] ; [106.63591766,10.75436306] ; [106.63633728,10.75440025] ; [106.63775635,10.75459576] ; [106.63799286,10.75454807]"
    ,"Distance":"550"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"719"
    ,"Station_Code":"Q6 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngân hàng ACB"
    ,"Station_Address":"871, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754295
    ,"Long":106.641245
    ,"Polyline":"[106.63799286,10.75454807] ; [106.63948059,10.75452137] ; [106.64124298,10.75429535]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"148"
    ,"Station_Code":"Q11 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Nguyễn Thi"
    ,"Station_Address":"1559, đường Đường 3/2, Quận 11"
    ,"Lat":10.755201
    ,"Long":106.644314
    ,"Polyline":"[106.64124298,10.75429535] ; [106.64231873,10.75421047] ; [106.64431763,10.75520134]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"150"
    ,"Station_Code":"Q11 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chùa Phụng Sơn"
    ,"Station_Address":"1479,  đường Đường 3/2, Quận 11"
    ,"Lat":10.756082
    ,"Long":106.645993
    ,"Polyline":"[106.64431763,10.75520134] ; [106.64599609,10.75608158]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"149"
    ,"Station_Code":"Q11 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Hàn Hải Nguyên"
    ,"Station_Address":"1375, đường  Đường 3/2, Quận 11"
    ,"Lat":10.757257
    ,"Long":106.648171
    ,"Polyline":"[106.64599609,10.75608158] ; [106.64703369,10.75668812] ; [106.64817047,10.75725746]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"151"
    ,"Station_Code":"Q11 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Xóm Đất"
    ,"Station_Address":"1293, đường Đường 3/2, Qu ận 11"
    ,"Lat":10.758469
    ,"Long":106.650301
    ,"Polyline":"[106.64817047,10.75725746] ; [106.64902496,10.75784683] ; [106.65029907,10.75846863]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"152"
    ,"Station_Code":"Q11 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Công an P12, Q11"
    ,"Station_Address":"1231, đường Đường 3/2, Quận 11"
    ,"Lat":10.759454
    ,"Long":106.652108
    ,"Polyline":"[106.65029907,10.75846863] ; [106.65210724,10.75945377]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"153"
    ,"Station_Code":"Q11 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"1163, đường Đường 3/2, Quận 11"
    ,"Lat":10.760371
    ,"Long":106.653763
    ,"Polyline":"[106.65210724,10.75945377] ; [106.65376282,10.76037121]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"154"
    ,"Station_Code":"Q11 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Lê Đại H ành"
    ,"Station_Address":"1007 (1029), đường  Đường 3/2, Quận 11"
    ,"Lat":10.761562
    ,"Long":106.656006
    ,"Polyline":"[106.65376282,10.76037121] ; [106.65600586,10.76156235]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"155"
    ,"Station_Code":"Q11 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trung tâm chăm sóc sức khỏe sinh  sản"
    ,"Station_Address":"957, đường Đường 3/2, Quận 11"
    ,"Lat":10.76245
    ,"Long":106.657539
    ,"Polyline":"[106.65600586,10.76156235] ; [106.65686035,10.76210022] ; [106.65753937,10.76245022]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"156"
    ,"Station_Code":"Q10 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"781, đường Đường 3/2, Quận 10"
    ,"Lat":10.76434
    ,"Long":106.661078
    ,"Polyline":"[106.65753937,10.76245022] ; [106.65995026,10.76378632] ; [106.66057587,10.76408386]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"157"
    ,"Station_Code":"Q10 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà thờ tin  lành Nguyễn Tri Phương"
    ,"Station_Address":"635 , đường Đường 3/2, Quận 10"
    ,"Lat":10.766232
    ,"Long":106.664627
    ,"Polyline":"[106.66057587,10.76408386] ; [106.66462708,10.76623154]"
    ,"Distance":"504"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1397"
    ,"Station_Code":"Q10 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Bệnh viện nhi đồng 1"
    ,"Station_Address":"359, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767765
    ,"Long":106.67038
    ,"Polyline":"[106.66462708,10.76623154] ; [106.66771698,10.76792336] ; [106.66812897,10.76793385] ; [106.66857910,10.76788616] ; [106.66902161,10.76774120]"
    ,"Distance":"533"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1398"
    ,"Station_Code":"Q10 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ P10, Q10"
    ,"Station_Address":"183, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767623
    ,"Long":106.673357
    ,"Polyline":"[106.66902161,10.76774120] ; [106.66995239,10.76780701] ; [106.67335510,10.76766014]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1404"
    ,"Station_Code":"Q10 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Hồ Thị Kỳ"
    ,"Station_Address":"93 (27B), đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767207
    ,"Long":106.67554
    ,"Polyline":"[106.67335510,10.76766014] ; [106.67400360,10.76764393] ; [106.67416382,10.76761818] ; [106.67424011,10.76750183] ; [106.67434692,10.76744366] ; [106.67443848,10.76742840] ; [106.67451477,10.76744938] ; [106.67459869,10.76748085] ; [106.67467499,10.76752853] ; [106.67704010,10.76679325]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1402"
    ,"Station_Code":"Q10 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà Khách  Chính Phủ"
    ,"Station_Address":"Đối diện 180  (1B), đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.766522
    ,"Long":106.677799
    ,"Polyline":"[106.67704010,10.76679325] ; [106.67857361,10.76630592]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1406"
    ,"Station_Code":"Q10 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã 6 Cộng  Hòa"
    ,"Station_Address":"Đối diện 30-32, đư ờng Lý Thái Tổ, Quận 10"
    ,"Lat":10.76571
    ,"Long":106.680449
    ,"Polyline":"[106.67857361,10.76630592] ; [106.68026733,10.76574707]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"287"
    ,"Station_Code":"Q1 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Phạm Viết Chánh"
    ,"Station_Address":"Đối diện 492, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.766214
    ,"Long":106.682533
    ,"Polyline":"[106.68026733,10.76574707] ; [106.68127441,10.76551533] ; [106.68132019,10.76536751] ; [106.68140411,10.76524067] ; [106.68151093,10.76516724] ; [106.68163300,10.76516724] ; [106.68173981,10.76521492] ; [106.68182373,10.76530457] ; [106.68185425,10.76540947] ; [106.68186188,10.76552582] ; [106.68196869,10.76576233] ; [106.68253326,10.76621437]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"290"
    ,"Station_Code":"Q1 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh viện Tù Dũ"
    ,"Station_Address":"Đối di ện 446, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.768709
    ,"Long":106.685024
    ,"Polyline":"[106.68253326,10.76621437] ; [106.68502045,10.76870918]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"289"
    ,"Station_Code":"Q1 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Tôn Thất T ùng"
    ,"Station_Address":"99, đường Nguyễn Th ị Minh Khai, Quận 1"
    ,"Lat":10.77185
    ,"Long":106.687943
    ,"Polyline":"[106.68502045,10.76870918] ; [106.68794250,10.77184963]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"292"
    ,"Station_Code":"Q1 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Sở Y Tế"
    ,"Station_Address":"Đối diện 214-216, đường Nguyễn Thị Minh Khai, Quận  1"
    ,"Lat":10.774179
    ,"Long":106.690158
    ,"Polyline":"[106.68794250,10.77184963] ; [106.69015503,10.77417946]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"242"
    ,"Station_Code":"Q1 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nhà Văn Hóa Lao Động"
    ,"Station_Address":"Đối diện số 138, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.777097
    ,"Long":106.692757
    ,"Polyline":"[106.69015503,10.77417946] ; [106.69275665,10.77709675]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"291"
    ,"Station_Code":"Q1 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Pasteur"
    ,"Station_Address":"43 - 45 - 47, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.781031
    ,"Long":106.696434
    ,"Polyline":"[106.69275665,10.77709675] ; [106.69643402,10.78103065]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"294"
    ,"Station_Code":"Q1 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Mạc Đỉnh Chi"
    ,"Station_Address":"21, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.784191
    ,"Long":106.699503
    ,"Polyline":"[106.69643402,10.78103065] ; [106.69950104,10.78419113]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"296"
    ,"Station_Code":"Q1 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Đinh Tiên Hoàng"
    ,"Station_Address":"15C-15D, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.786146
    ,"Long":106.70137
    ,"Polyline":"[106.69950104,10.78419113] ; [106.70041656,10.78521347] ; [106.70137024,10.78614616]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"293"
    ,"Station_Code":"Q1 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"3, đường  Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.789598
    ,"Long":106.70459
    ,"Polyline":"[106.70137024,10.78614616] ; [106.70458984,10.78959846]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"295"
    ,"Station_Code":"Q1 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Cầu Thị Nghè"
    ,"Station_Address":"1A, đường Nguyễn  Thị Minh Khai, Quận 1"
    ,"Lat":10.790669
    ,"Long":106.705597
    ,"Polyline":"[106.70458984,10.78959846] ; [106.70516205,10.79027748] ; [106.70559692,10.79066944]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"298"
    ,"Station_Code":"QBTH 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"22 B, đường Xô Viết Nghệ Tĩnh, Quận B ình Thạnh"
    ,"Lat":10.793445
    ,"Long":106.70814
    ,"Polyline":"[106.70559692,10.79066944] ; [106.70813751,10.79344463]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trung tâm Dưỡng Lão"
    ,"Station_Address":"138, đường Xô Viết Nghệ T ĩnh, Quận Bình Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70813751,10.79344463] ; [106.71009827,10.79551601] ; [106.71087646,10.79750156]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"246, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71087646,10.79750156] ; [106.71112061,10.79859257] ; [106.71124268,10.79976845]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71124268,10.79976845] ; [106.71129608,10.80050087] ; [106.71139526,10.80120182] ; [106.71154022,10.80130196] ; [106.71157837,10.80147552] ; [106.71154785,10.80161285] ; [106.71144104,10.80171776] ; [106.71143341,10.80284500] ; [106.71154022,10.80474758]"
    ,"Distance":"570"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ T ĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71163940,10.80783558] ; [106.71174622,10.80835152] ; [106.71196747,10.80883121]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71212006,10.80930042] ; [106.71221161,10.80964851] ; [106.71233368,10.81025887] ; [106.71240997,10.81079102]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71253204,10.81168175] ; [106.71263123,10.81257248] ; [106.71276855,10.81356335] ; [106.71318054,10.81729317] ; [106.71314240,10.81736183] ; [106.71307373,10.81740475] ; [106.71301270,10.81744099] ; [106.71290588,10.81743622] ; [106.71202087,10.81721973] ; [106.71158600,10.81692982] ; [106.71125793,10.81666088]"
    ,"Distance":"969"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71125793,10.81666088] ; [106.70979309,10.81382656] ; [106.71014404,10.81394291] ; [106.71070099,10.81506443] ; [106.71129608,10.81473255]"
    ,"Distance":"608"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ L ĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1408"
    ,"Station_Code":"QBTH 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã năm Liệt Sĩ"
    ,"Station_Address":"222/4 Ter, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.81204
    ,"Long":106.710624
    ,"Polyline":"[106.71129608,10.81473255] ; [106.71041107,10.81519127] ; [106.70948792,10.81330490] ; [106.71062469,10.81204033]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1410"
    ,"Station_Code":"QBTH 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Chợ Phường 25"
    ,"Station_Address":"đối diện 134/4A, đường Ung Văn Khiêm, Quận Bình Thạnh"
    ,"Lat":10.808304
    ,"Long":106.714674
    ,"Polyline":"[106.71062469,10.81204033] ; [106.71196747,10.81052780] ; [106.71345520,10.80904770] ; [106.71467590,10.80830383]"
    ,"Distance":"612"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1405"
    ,"Station_Code":"QBTH 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Đại học Ngoại Thương"
    ,"Station_Address":"8A, đường Đư ờng D2, Quận Bình Thạnh"
    ,"Lat":10.806444
    ,"Long":106.716042
    ,"Polyline":"[106.71467590,10.80830383] ; [106.71543121,10.80792999] ; [106.71628571,10.80763531] ; [106.71604156,10.80644417]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1407"
    ,"Station_Code":"QBTH 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường ĐH Giao thông Vận tải Tp . HCM"
    ,"Station_Address":"74 Cư xá Văn Thánh Bắc, đường Đường D2, Quận Bình Thạnh"
    ,"Lat":10.804057
    ,"Long":106.715843
    ,"Polyline":"[106.71604156,10.80644417] ; [106.71592712,10.80582809] ; [106.71584320,10.80405712]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"483, đường Đi ện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71584320,10.80405712] ; [106.71579742,10.80341434] ; [106.71574402,10.80294037] ; [106.71563721,10.80251884] ; [106.71512604,10.80114365] ; [106.71485901,10.80122757]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"419, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71485901,10.80122757] ; [106.71370697,10.80155945] ; [106.71331024,10.80165482] ; [106.71292114,10.80166531] ; [106.71244812,10.80163860]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"221, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71244812,10.80163860] ; [106.71163940,10.80162811] ; [106.71137238,10.80173397] ; [106.71126556,10.80171776] ; [106.71115875,10.80167580] ; [106.71109009,10.80155945] ; [106.71108246,10.80142784] ; [106.71112061,10.80131245] ; [106.71118927,10.80120659] ; [106.71107483,10.79983711]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường TH Hồng Hà"
    ,"Station_Address":"153, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71107483,10.79983711] ; [106.71102142,10.79907799] ; [106.71088409,10.79831886] ; [106.71067810,10.79752827] ; [106.71041107,10.79673767]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"369"
    ,"Station_Code":"QBTH 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Siêu Thị  Điện máy tự do"
    ,"Station_Address":"151, đường Xô Viết Nghệ Tĩnh, Quận Bình  Thạnh"
    ,"Lat":10.794978
    ,"Long":106.709368
    ,"Polyline":"[106.71041107,10.79673767] ; [106.71023560,10.79620552] ; [106.70999908,10.79567337] ; [106.70968628,10.79529476] ; [106.70936584,10.79497814]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"373"
    ,"Station_Code":"QBTH 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"79, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793534
    ,"Long":106.707979
    ,"Polyline":"[106.70936584,10.79497814] ; [106.70797729,10.79353428]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"370"
    ,"Station_Code":"Q1 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"2A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790694
    ,"Long":106.705259
    ,"Polyline":"[106.70797729,10.79353428] ; [106.70526123,10.79069424]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Đài truyền hình"
    ,"Station_Address":"Đối di ện 9, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70526123,10.79069424] ; [106.70201111,10.78715706]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"371"
    ,"Station_Code":"Q1 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"nhà thờ M ạc Ti Nho"
    ,"Station_Address":"16A, đường Nguy ễn Thị Minh Khai, Quận 1"
    ,"Lat":10.786397
    ,"Long":106.701294
    ,"Polyline":"[106.70201111,10.78715706] ; [106.70129395,10.78639698]"
    ,"Distance":"115"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"372"
    ,"Station_Code":"Q1 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Phùng Khắc Khoan"
    ,"Station_Address":"2 - 4, đường Phùng Khắc Khoan, Quận 1"
    ,"Lat":10.784048
    ,"Long":106.698586
    ,"Polyline":"[106.70129395,10.78639698] ; [106.69964600,10.78463936] ; [106.69886017,10.78384399] ; [106.69858551,10.78404808]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"378"
    ,"Station_Code":"Q3 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Hồ Con Rùa"
    ,"Station_Address":"24 - 26, đường Trần Cao Vân, Quận 3"
    ,"Lat":10.783314
    ,"Long":106.696411
    ,"Polyline":"[106.69858551,10.78404808] ; [106.69780731,10.78478146] ; [106.69641113,10.78331375]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"375"
    ,"Station_Code":"Q3 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Sân Phan  Đình Phùng"
    ,"Station_Address":"8, đường Võ Văn Tần, Quận 3"
    ,"Lat":10.781172
    ,"Long":106.694402
    ,"Polyline":"[106.69641113,10.78331375] ; [106.69620514,10.78302670] ; [106.69605255,10.78308487] ; [106.69590759,10.78309536] ; [106.69575500,10.78305817] ; [106.69561768,10.78295326] ; [106.69554138,10.78281593] ; [106.69554138,10.78267384] ; [106.69556427,10.78253174] ; [106.69561005,10.78239441] ; [106.69492340,10.78166676] ; [106.69440460,10.78117180]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"377"
    ,"Station_Code":"Q3 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bảo tàng chiến tranh"
    ,"Station_Address":"28, đường Võ Văn Tần, Quận 3"
    ,"Lat":10.779143
    ,"Long":106.69254
    ,"Polyline":"[106.69440460,10.78117180] ; [106.69254303,10.77914333]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"376"
    ,"Station_Code":"Q3 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trần Quốc  Thảo"
    ,"Station_Address":"44, đường Võ Văn T ần, Quận 3"
    ,"Lat":10.777889
    ,"Long":106.691365
    ,"Polyline":"[106.69254303,10.77914333] ; [106.69136810,10.77788925]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"379"
    ,"Station_Code":"Q3 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đại học Mở thành phố HCM"
    ,"Station_Address":"62, đường Võ Văn Tần, Quận 3"
    ,"Lat":10.776418
    ,"Long":106.69004
    ,"Polyline":"[106.69136810,10.77788925] ; [106.69004059,10.77641773]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"381"
    ,"Station_Code":"Q3 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Nguyễn Thị Minh Khai"
    ,"Station_Address":"17, đường Bà  Huyện Thanh Quan, Quận 3"
    ,"Lat":10.775102
    ,"Long":106.690186
    ,"Polyline":"[106.69004059,10.77641773] ; [106.68952942,10.77579689] ; [106.69002533,10.77531719] ; [106.69018555,10.77510166]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"380"
    ,"Station_Code":"Q3 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cách Mạng tháng 8"
    ,"Station_Address":"284, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.773112
    ,"Long":106.688812
    ,"Polyline":"[106.69018555,10.77510166] ; [106.69034576,10.77502728] ; [106.69055176,10.77488518] ; [106.68881226,10.77311230]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"383"
    ,"Station_Code":"Q3 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"414, đư ờng Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.77079
    ,"Long":106.686634
    ,"Polyline":"[106.68881226,10.77311230] ; [106.68663025,10.77079010]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"382"
    ,"Station_Code":"Q3 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bệnh viện Từ  Dũ"
    ,"Station_Address":"436, đường Nguyễn Th ị Minh Khai, Quận 3"
    ,"Lat":10.768946
    ,"Long":106.684883
    ,"Polyline":"[106.68663025,10.77079010.06.68488312]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"89"
    ,"Station_Code":"Q3 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Hội Chữ thập đỏ thành phố"
    ,"Station_Address":"464 - 466, đường Nguyễn Thị Minh Khai , Quận 3"
    ,"Lat":10.767691
    ,"Long":106.683693
    ,"Polyline":"[106.68488312,10.76894569] ; [106.68369293,10.76769066]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"90"
    ,"Station_Code":"Q3 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà sách Minh Khai"
    ,"Station_Address":"488, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.766416
    ,"Long":106.682428
    ,"Polyline":"[106.68369293,10.76769066] ; [106.68242645,10.76641560]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1409"
    ,"Station_Code":"Q3 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà hàng Sinh Đôi"
    ,"Station_Address":"120, đường Lý Thái Tổ, Quận 3"
    ,"Lat":10.765963
    ,"Long":106.680363
    ,"Polyline":"[106.68242645,10.76641560] ; [106.68171692,10.76570511] ; [106.68162537,10.76571560] ; [106.68153381,10.76570511] ; [106.68144989,10.76568413] ; [106.68135834,10.76563072] ; [106.68036652,10.76596260]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1413"
    ,"Station_Code":"Q3 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"170, đường Lý Thái Tổ, Quận 3"
    ,"Lat":10.76668
    ,"Long":106.678099
    ,"Polyline":"[106.68036652,10.76596260] ; [106.67862701,10.76648426] ; [106.67810059,10.76667976]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1416"
    ,"Station_Code":"Q3 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Hồ Thị Kỷ"
    ,"Station_Address":"306, đường Lý Thái Tổ, Quận 3"
    ,"Lat":10.767423
    ,"Long":106.675664
    ,"Polyline":"[106.67810059,10.76667976] ; [106.67691040,10.76701736] ; [106.67566681,10.76742268]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1411"
    ,"Station_Code":"Q10 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ Phường 10, Quận 10"
    ,"Station_Address":"430, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767865
    ,"Long":106.673051
    ,"Polyline":"[106.67566681,10.76742268] ; [106.67471313,10.76768112] ; [106.67465210,10.76784420] ; [106.67457581,10.76790714] ; [106.67447662,10.76795006] ; [106.67439270,10.76796055] ; [106.67429352,10.76792908] ; [106.67421722,10.76786518] ; [106.67416382,10.76778126] ; [106.67313385,10.76779747]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1412"
    ,"Station_Code":"Q10 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bện viện Nhi Đồng 1"
    ,"Station_Address":"B ệnh viện Nhi đồng 1, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.768029
    ,"Long":106.669739
    ,"Polyline":"[106.67313385,10.76779747] ; [106.66973877,10.76802921]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"98"
    ,"Station_Code":"Q10 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"626-628, đường Đường 3/2, Quận 10"
    ,"Lat":10.764972
    ,"Long":106.661743
    ,"Polyline":"[106.66973877,10.76802921] ; [106.66773987,10.76811314] ; [106.66174316,10.76497173]"
    ,"Distance":"962"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"100"
    ,"Station_Code":"Q11 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Nhà sách  Phú Thọ"
    ,"Station_Address":"940 (6B), đường Đường 3/2, Quận 11"
    ,"Lat":10.763115
    ,"Long":106.658409
    ,"Polyline":"[106.66174316,10.76497173] ; [106.66004181,10.76404953] ; [106.65840912,10.76311493]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"101"
    ,"Station_Code":"Q11 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Lãnh Binh  Thăng"
    ,"Station_Address":"970, đường Đường 3/2, Quận 11"
    ,"Lat":10.761842
    ,"Long":106.65603
    ,"Polyline":"[106.65840912,10.76311493] ; [106.65707397,10.76233196] ; [106.65602875,10.76184177]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"103"
    ,"Station_Code":"Q11 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"1114A-1116A , đường Đường 3/2, Quận 11"
    ,"Lat":10.760535
    ,"Long":106.653557
    ,"Polyline":"[106.65602875,10.76184177] ; [106.65479279,10.76116180] ; [106.65355682,10.76053524]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"105"
    ,"Station_Code":"Q11 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Xóm Đất"
    ,"Station_Address":"1196, đường Đường 3/2, Qu ận 11"
    ,"Lat":10.758648
    ,"Long":106.650156
    ,"Polyline":"[106.65355682,10.76053524] ; [106.65188599,10.75958061] ; [106.65015411,10.75864792]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"104"
    ,"Station_Code":"Q11 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Đội Giao Thông Phú Lâm"
    ,"Station_Address":"1274, đường Đường 3/2, Qu ận 11"
    ,"Lat":10.757357
    ,"Long":106.647838
    ,"Polyline":"[106.65015411,10.75864792] ; [106.64894104,10.75791550] ; [106.64783478,10.75735664]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"107"
    ,"Station_Code":"Q11 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa Phụng Sơn"
    ,"Station_Address":"1354, đường Đường 3/2, Quận 11"
    ,"Lat":10.756348
    ,"Long":106.646034
    ,"Polyline":"[106.64783478,10.75735664] ; [106.64603424,10.75634766]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"106"
    ,"Station_Code":"Q11 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trường Nguyễn Thi"
    ,"Station_Address":"1456, đường Đường 3/2, Quận 11"
    ,"Lat":10.755207
    ,"Long":106.643858
    ,"Polyline":"[106.64603424,10.75634766] ; [106.64385986,10.75520706]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"625"
    ,"Station_Code":"Q11 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chùa Huê  Lâm"
    ,"Station_Address":"690 (138), đường Hồng Bàng, Quận 11"
    ,"Lat":10.754558
    ,"Long":106.641229
    ,"Polyline":"[106.64385986,10.75520706] ; [106.64281464,10.75456905] ; [106.64262390,10.75447464] ; [106.64238739,10.75440598] ; [106.64122772,10.75455761]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"623"
    ,"Station_Code":"Q11 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"786, đường Hồng Bàng, Quận 11"
    ,"Lat":10.75477
    ,"Long":106.638428
    ,"Polyline":"[106.64122772,10.75455761] ; [106.63912201,10.75476360] ; [106.63842773,10.75477028]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"626"
    ,"Station_Code":"Q6 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trường Mạc Đỉnh Chi"
    ,"Station_Address":"832-834, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754732
    ,"Long":106.635574
    ,"Polyline":"[106.63842773,10.75477028] ; [106.63761139,10.75486374] ; [106.63706207,10.75479031] ; [106.63665771,10.75483799] ; [106.63618469,10.75483227] ; [106.63591766,10.75480652] ; [106.63557434,10.75473213]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"627"
    ,"Station_Code":"Q6 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"528, đường Kinh  Dương Vương, Quận 6"
    ,"Lat":10.753346
    ,"Long":106.633365
    ,"Polyline":"[106.63557434,10.75473213] ; [106.63522339,10.75456333] ; [106.63486481,10.75433731] ; [106.63466644,10.75424194] ; [106.63459015,10.75428963] ; [106.63449860,10.75430012] ; [106.63439178,10.75429535] ; [106.63430023,10.75423145] ; [106.63421631,10.75414753] ; [106.63418579,10.75405788] ; [106.63416290,10.75395203] ; [106.63417816,10.75383663] ; [106.63336182,10.75334644]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"629"
    ,"Station_Code":"Q6 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"94-96, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.749589
    ,"Long":106.628435
    ,"Polyline":"[106.63336182,10.75334644] ; [106.62843323,10.74958897]"
    ,"Distance":"682"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"1386"
    ,"Station_Code":"Q6 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Công Viên Phú Lâm"
    ,"Station_Address":"Đối diện 907, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.746384
    ,"Long":106.624525
    ,"Polyline":"[106.62843323,10.74958897] ; [106.62452698,10.74638367]"
    ,"Distance":"557"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62452698,10.74638367] ; [106.62425995,10.74613094] ; [106.62394714,10.74568367] ; [106.62385559,10.74570942] ; [106.62377167,10.74571514] ; [106.62369537,10.74569416] ; [106.62362671,10.74564075] ; [106.62349701,10.74558353] ; [106.62332153,10.74547291] ; [106.62266541,10.74488258] ; [106.62247467,10.74474621]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62143707,10.74389172] ; [106.62039948,10.74309158]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"26"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình  Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.62039948,10.74309158] ; [106.61800385,10.74101353] ; [106.61831665,10.74070454]"
    ,"Distance":"398"
  }]