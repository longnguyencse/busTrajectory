export const Route17 =[
  {
     "Route_Id":"17"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"BÃI XE BUÝT ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT ĐẦM SEN, đường Hòa Bình,  Quận 11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1043"
    ,"Station_Code":"Q11 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"3 (79), đường Hòa Bình, Quận 11"
    ,"Lat":10.76698
    ,"Long":106.641571
    ,"Polyline":"[106.63967133,10.76786041] ; [106.63973999,10.76793385] ; [106.64027405,10.76760769] ; [106.64076233,10.76737022] ; [106.64122772,10.76716423] ; [106.64157104,10.76698017]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1044"
    ,"Station_Code":"Q11 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Tòa án nhân dân Q11"
    ,"Station_Address":"85, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.766342
    ,"Long":106.643349
    ,"Polyline":"[106.64157104,10.76698017] ; [106.64176941,10.76694870] ; [106.64216614,10.76684284] ; [106.64218140,10.76674271] ; [106.64223480,10.76666927] ; [106.64230347,10.76663208] ; [106.64237213,10.76664829] ; [106.64243317,10.76666355] ; [106.64248657,10.76671124] ; [106.64303589,10.76651096] ; [106.64334869,10.76634216]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1045"
    ,"Station_Code":"Q11 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ông Ích Khiêm"
    ,"Station_Address":"43, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.765737
    ,"Long":106.645157
    ,"Polyline":"[106.64334869,10.76634216] ; [106.64415741,10.76609516] ; [106.64515686,10.76573658]"
    ,"Distance":"209"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1046"
    ,"Station_Code":"Q11 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Lãnh Binh Thăng"
    ,"Station_Address":"307, đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.764374
    ,"Long":106.647964
    ,"Polyline":"[106.64515686,10.76573658] ; [106.64633942,10.76534081] ; [106.64796448,10.76437378]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1047"
    ,"Station_Code":"Q11 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"CV Lãnh Binh Thăng"
    ,"Station_Address":"281A (Siêu thị Vinatex), đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.763238
    ,"Long":106.650167
    ,"Polyline":"[106.64796448,10.76437378] ; [106.65016937,10.76323795]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1048"
    ,"Station_Code":"Q11 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường TH Phú Thọ"
    ,"Station_Address":"316, đường Tôn Thất Hiệp, Quận 11"
    ,"Lat":10.761051
    ,"Long":106.652656
    ,"Polyline":"[106.65016937,10.76323795] ; [106.65128326,10.76271152] ; [106.65225983,10.76262188] ; [106.65229797,10.76200485] ; [106.65238190,10.76161003] ; [106.65246582,10.76136208] ; [106.65265656,10.76105118]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"153"
    ,"Station_Code":"Q11 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"1163, đường Đường 3/2, Qu ận 11"
    ,"Lat":10.760371
    ,"Long":106.653763
    ,"Polyline":"[106.65265656,10.76105118] ; [106.65303802,10.76062965] ; [106.65320587,10.76050854] ; [106.65341949,10.76020241] ; [106.65376282,10.76037121]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"154"
    ,"Station_Code":"Q11 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Lê Đại Hành"
    ,"Station_Address":"1007 (1029), đường Đường 3/2, Quận 11"
    ,"Lat":10.761562
    ,"Long":106.656006
    ,"Polyline":"[106.65376282,10.76037121] ; [106.65600586,10.76156235]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1049"
    ,"Station_Code":"Q11 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"167-169, đường Phó Cơ Điều, Quận 11"
    ,"Lat":10.761036
    ,"Long":106.656982
    ,"Polyline":"[106.65600586,10.76156235] ; [106.65705109,10.76223660] ; [106.65698242,10.76103592]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1050"
    ,"Station_Code":"Q5 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Thiếc"
    ,"Station_Address":"235, đường Nguyễn Chí Thanh , Quận 5"
    ,"Lat":10.757568
    ,"Long":106.657616
    ,"Polyline":"[106.65698242,10.76103592] ; [106.65709686,10.75935936] ; [106.65710449,10.75749969] ; [106.65761566,10.75756836]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"281"
    ,"Station_Code":"Q5 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"201A , đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758079
    ,"Long":106.660128
    ,"Polyline":"[106.65761566,10.75756836] ; [106.65831757,10.75769997] ; [106.65959930,10.75798416] ; [106.66012573,10.75807858]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"616"
    ,"Station_Code":"Q5 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Bệnh viện Hùng  Vương"
    ,"Station_Address":"Hông Bệnh viện Hùng Vương, đường Lý Thường Kiệt, Quận 5"
    ,"Lat":10.755702
    ,"Long":106.66221
    ,"Polyline":"[106.66012573,10.75807858] ; [106.66153717,10.75834274] ; [106.66220856,10.75570202]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"217, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.66220856,10.75570202] ; [106.66238403,10.75521755] ; [106.66319275,10.75535965]"
    ,"Distance":"147"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh viện  Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66319275,10.75535965] ; [106.66384888,10.75551224] ; [106.66468048,10.75567055]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"465"
    ,"Station_Code":"Q5 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện  Nguyễn Tri Phương"
    ,"Station_Address":"121, đường An Dương Vương, Quận 5"
    ,"Lat":10.756714
    ,"Long":106.670492
    ,"Polyline":"[106.66468048,10.75567055] ; [106.66519928,10.75579739] ; [106.66795349,10.75629234] ; [106.66950226,10.75657654] ; [106.67049408,10.75671387]"
    ,"Distance":"646"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"469"
    ,"Station_Code":"Q5 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"59C, đường An Dương Vương, Quận 5"
    ,"Lat":10.757057
    ,"Long":106.672182
    ,"Polyline":"[106.67049408,10.75671387] ; [106.67218018,10.75705719]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"466"
    ,"Station_Code":"Q5 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"439, đường An Dương Vương, Quận 5"
    ,"Lat":10.758374
    ,"Long":106.676576
    ,"Polyline":"[106.67218018,10.75705719] ; [106.67390442,10.75743103] ; [106.67402649,10.75744152] ; [106.67416382,10.75743103] ; [106.67421722,10.75745678] ; [106.67425537,10.75749397] ; [106.67494202,10.75771523] ; [106.67657471,10.75837421]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"472"
    ,"Station_Code":"Q5 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"373, đường An Dương Vương, Quận 5"
    ,"Lat":10.759138
    ,"Long":106.678453
    ,"Polyline":"[106.67657471,10.75837421] ; [106.67754364,10.75879002] ; [106.67845154,10.75913811]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"467"
    ,"Station_Code":"Q5 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Đại học Sài Gòn"
    ,"Station_Address":"273-275, đường An Dương Vương, Quận 5"
    ,"Lat":10.760735
    ,"Long":106.682289
    ,"Polyline":"[106.67845154,10.75913811] ; [106.68228912,10.76073456]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1051"
    ,"Station_Code":"Q5 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Bộ Công an"
    ,"Station_Address":"211-213, đường Nguyễn Văn Cừ, Quận 5"
    ,"Lat":10.760672
    ,"Long":106.683453
    ,"Polyline":"[106.68228912,10.76073456] ; [106.68325806,10.76115131] ; [106.68345642,10.76067162]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1052"
    ,"Station_Code":"Q1 150"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Báo An Ninh Thế Giới"
    ,"Station_Address":"371A, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.759869
    ,"Long":106.685104
    ,"Polyline":"[106.68345642,10.76067162] ; [106.68392181,10.75940704] ; [106.68483734,10.75973415] ; [106.68510437,10.75986862]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1053"
    ,"Station_Code":"Q1 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà Khách Bộ Công An"
    ,"Station_Address":"333, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.762006
    ,"Long":106.686394
    ,"Polyline":"[106.68510437,10.75986862] ; [106.68639374,10.76200581]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1056"
    ,"Station_Code":"Q1 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chùa Lâm Tế"
    ,"Station_Address":"217, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.765754
    ,"Long":106.688004
    ,"Polyline":"[106.68639374,10.76200581] ; [106.68684387,10.76292706] ; [106.68708801,10.76336479] ; [106.68745422,10.76440811] ; [106.68759155,10.76473999] ; [106.68767548,10.76504040] ; [106.68784332,10.76541519] ; [106.68800354,10.76575375]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đư ờng Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68800354,10.76575375] ; [106.68807983,10.76613140] ; [106.68817902,10.76637936] ; [106.68827057,10.76657963] ; [106.68835449,10.76662159] ; [106.68841553,10.76667976] ; [106.68841553,10.76676369] ; [106.68835449,10.76683807] ; [106.68836975,10.76696396] ; [106.68842316,10.76709557] ; [106.68868256,10.76755428] ; [106.68896484,10.76800728] ; [106.69033813,10.76855087]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường  Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69194794,10.76920891] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A  Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69510651,10.77044201] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Bến Thành  F"
    ,"Station_Address":"B ến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69676971,10.77109146] ; [106.69785309,10.77158642] ; [106.69801331,10.77157593] ; [106.69805145,10.77144909] ; [106.69808960,10.77133274] ; [106.69815826,10.77125931] ; [106.69731903,10.77032089] ; [106.69613647,10.76985264] ; [106.69639587,10.76930904] ; [106.69646454,10.76924610.06.69657135] ; [10.76926231,106.69750214] ; [10.77022648,106.69845581] ; [10.77047157,106.69845581]"
    ,"Distance":"811"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"4226"
    ,"Station_Code":"BX 05"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Đầu bến Hàm  Nghi"
    ,"Station_Address":"Đầu bến Hàm Nghi, đường Hàm Nghi, Quận 1"
    ,"Lat":10.77117
    ,"Long":106.700196
    ,"Polyline":"[106.69845581,10.77047157] ; [106.69901276,10.77082157] ; [106.69913483,10.77094841] ; [106.69922638,10.77100086] ; [106.69931793,10.77101707] ; [106.70252228,10.77083206] ; [106.70243835,10.77103233] ; [106.70019531,10.77116966]"
    ,"Distance":"734"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"4226"
    ,"Station_Code":"BX 05"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Đầu bến Hàm Nghi"
    ,"Station_Address":"Đầu bến Hàm Nghi, đường Hàm Nghi, Qu ận 1"
    ,"Lat":10.77117
    ,"Long":106.700196
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"202"
    ,"Station_Code":"Q1TC1C"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến Thành C"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ L ão, Quận 1"
    ,"Lat":10.770787
    ,"Long":106.698532
    ,"Polyline":"[106.70019531,10.77116966] ; [106.69933319,10.77120113] ; [106.69853210,10.77078724]"
    ,"Distance":"193"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853210,10.77078724] ; [106.69595337,10.76980972]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"84"
    ,"Station_Code":"Q1 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện số 26, đường Nguyễn Thị Nghĩa , Quận 1"
    ,"Lat":10.77098
    ,"Long":106.693779
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69476318,10.76933575] ; [106.69377899,10.77097988]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"85"
    ,"Station_Code":"Q1 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã 6 Phù Đổng"
    ,"Station_Address":"22, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.77097
    ,"Long":106.69268
    ,"Polyline":"[106.69377899,10.77097988] ; [106.69358826,10.77118587] ; [106.69347382,10.77129650] ; [106.69345856,10.77138042] ; [106.69341278,10.77146435] ; [106.69336700,10.77152824] ; [106.69328308,10.77156448] ; [106.69315338,10.77155399] ; [106.69309235,10.77148056] ; [106.69306946,10.77139664] ; [106.69308472,10.77131176] ; [106.69297791,10.77116966] ; [106.69268036,10.77097034]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"87"
    ,"Station_Code":"Q1 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"136, đư ờng Nguyễn Trãi, Quận 1"
    ,"Lat":10.769646
    ,"Long":106.690788
    ,"Polyline":"[106.69268036,10.77097034] ; [106.69078827,10.76964569]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"86"
    ,"Station_Code":"Q1 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhà thờ Huyện Sỹ"
    ,"Station_Address":"206Bis, đường Nguy ễn Trãi, Quận 1"
    ,"Lat":10.767692
    ,"Long":106.688591
    ,"Polyline":"[106.69078827,10.76964569] ; [106.69022369,10.76924133] ; [106.68971252,10.76882458] ; [106.68917084,10.76820278] ; [106.68894958,10.76809692] ; [106.68880463,10.76796532] ; [106.68859100,10.76769161]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1012"
    ,"Station_Code":"Q1 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Chùa Lâm Tế"
    ,"Station_Address":"Đối diện 211 (212A), đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.765736
    ,"Long":106.687798
    ,"Polyline":"[106.68859100,10.76769161] ; [106.68833923,10.76710129] ; [106.68830872,10.76695919] ; [106.68824005,10.76687431] ; [106.68820190,10.76678467] ; [106.68820190,10.76670074] ; [106.68822479,10.76663780] ; [106.68810272,10.76641655] ; [106.68779755,10.76573563]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1019"
    ,"Station_Code":"Q1 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"City plaza"
    ,"Station_Address":"230, đường Nguyễn  Trãi, Quận 1"
    ,"Lat":10.764556
    ,"Long":106.687385
    ,"Polyline":"[106.68779755,10.76573563] ; [106.68749237,10.76477242] ; [106.68734741,10.76440334] ; [106.68719482,10.76393414] ; [106.68708038,10.76375198]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1021"
    ,"Station_Code":"Q1 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Nguyễn Trãi"
    ,"Station_Address":"Đối diện số 205 - 207, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.760314
    ,"Long":106.683769
    ,"Polyline":"[106.68708038,10.76375198] ; [106.68659210,10.76275921] ; [106.68614960,10.76194763] ; [106.68508911,10.76013470] ; [106.68498230,10.75999737] ; [106.68480682,10.75989151] ; [106.68408203,10.75960732] ; [106.68376923,10.76031399]"
    ,"Distance":"671"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"426"
    ,"Station_Code":"Q5 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đại học Sư Phạm"
    ,"Station_Address":"280, đường An Dương Vương, Quận 5"
    ,"Lat":10.76103
    ,"Long":106.68267
    ,"Polyline":"[106.68376923,10.76031399] ; [106.68341827,10.76130390] ; [106.68267059,10.76103020]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"429"
    ,"Station_Code":"Q5 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"370, đường An Dương Vương , Quận 5"
    ,"Lat":10.759407
    ,"Long":106.678764
    ,"Polyline":"[106.68267059,10.76103020] ; [106.67876434,10.75940704]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"427"
    ,"Station_Code":"Q5 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"526, đường An Dương Vương, Quận 5"
    ,"Lat":10.757984
    ,"Long":106.675272
    ,"Polyline":"[106.67876434,10.75940704] ; [106.67527008,10.75798416]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"430"
    ,"Station_Code":"Q5 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"Đối diện số 5, đường An Dương Vương, Qu ận 5"
    ,"Lat":10.757536
    ,"Long":106.673534
    ,"Polyline":"[106.67527008,10.75798416] ; [106.67478180,10.75777340] ; [106.67424011,10.75758362] ; [106.67418671,10.75762558] ; [106.67412567,10.75764179] ; [106.67405701,10.75763130] ; [106.67398071,10.75759983] ; [106.67353058,10.75753593]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"428"
    ,"Station_Code":"Q5 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"102C-D, đường An Dương Vương, Quận 5"
    ,"Lat":10.756967
    ,"Long":106.670653
    ,"Polyline":"[106.67353058,10.75753593] ; [106.67065430,10.75696659]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.67065430,10.75696659] ; [106.66966248,10.75674534] ; [106.66961670,10.75715065]"
    ,"Distance":"156"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"431"
    ,"Station_Code":"Q5 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"116A, đường Hùng Vương, Quận 5"
    ,"Lat":10.757257
    ,"Long":106.668566
    ,"Polyline":"[106.66961670,10.75715065] ; [106.66948700,10.75773621] ; [106.66856384,10.75725746]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66856384,10.75725746] ; [106.66702271,10.75647640] ; [106.66451263,10.75589657]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"544"
    ,"Station_Code":"Q5 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Hùng Vương Plaza"
    ,"Station_Address":"4, đường Lý Thường Kiệt, Quận 5"
    ,"Lat":10.756013
    ,"Long":106.662333
    ,"Polyline":"[106.66451263,10.75589657] ; [106.66245270,10.75545406] ; [106.66233063,10.75601292]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"393"
    ,"Station_Code":"Q11 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"BV Răng Hàm Mặt"
    ,"Station_Address":"598, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.758364
    ,"Long":106.660828
    ,"Polyline":"[106.66233063,10.75601292] ; [106.66167450,10.75847435] ; [106.66082764,10.75836372]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1014"
    ,"Station_Code":"Q11 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường 3/2"
    ,"Station_Address":"170-172, đường Lê Đại Hành, Quận 11"
    ,"Lat":10.761931
    ,"Long":106.657376
    ,"Polyline":"[106.66082764,10.75836372] ; [106.65832520,10.75779438] ; [106.65887451,10.75944424] ; [106.65887451,10.75963879] ; [106.65882111,10.75980759] ; [106.65737915,10.76193142]"
    ,"Distance":"800"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1016"
    ,"Station_Code":"Q11 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cổng chào CV Đầm sen"
    ,"Station_Address":"20, đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.762369
    ,"Long":106.655917
    ,"Polyline":"[106.65737915,10.76193142] ; [106.65714264,10.76224804] ; [106.65699768,10.76227951] ; [106.65591431,10.76236916]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1023"
    ,"Station_Code":"Q11 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Chợ Phú Thọ"
    ,"Station_Address":"134, đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.762564
    ,"Long":106.653879
    ,"Polyline":"[106.65591431,10.76236916] ; [106.65460205,10.76246357] ; [106.65387726,10.76256371]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1018"
    ,"Station_Code":"Q11 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"CV Lãnh Binh Thăng"
    ,"Station_Address":"Đối diện Trường mầm non (278), đường L ãnh Binh Thăng, Quận 11"
    ,"Lat":10.762875
    ,"Long":106.651239
    ,"Polyline":"[106.65387726,10.76256371] ; [106.65136719,10.76281643] ; [106.65123749,10.76287460]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1024"
    ,"Station_Code":"Q11 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nhà văn hóa Quận 11"
    ,"Station_Address":"284, đường L ãnh Binh Thăng, Quận 11"
    ,"Lat":10.764453
    ,"Long":106.648193
    ,"Polyline":"[106.65123749,10.76287460] ; [106.64957428,10.76367092] ; [106.64819336,10.76445293]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1027"
    ,"Station_Code":"Q11 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Lãnh Binh Thăng"
    ,"Station_Address":"308-310, đư ờng Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.76512
    ,"Long":106.646926
    ,"Polyline":"[106.64819336,10.76445293] ; [106.64763641,10.76471424] ; [106.64692688,10.76511955]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1020"
    ,"Station_Code":"Q11 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Tòa án nhân dân Q11"
    ,"Station_Address":"150, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.76659
    ,"Long":106.643082
    ,"Polyline":"[106.64692688,10.76511955] ; [106.64639282,10.76543045] ; [106.64475250,10.76599503] ; [106.64308167,10.76659012]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1029"
    ,"Station_Code":"Q11 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Bãi xe bu ýt Đầm Sen"
    ,"Station_Address":"40A, đường Hòa Bình, Quận 11"
    ,"Lat":10.767302
    ,"Long":106.641181
    ,"Polyline":"[106.64308167,10.76659012] ; [106.64255524,10.76676941] ; [106.64252472,10.76690674] ; [106.64243317,10.76699066] ; [106.64230347,10.76701164] ; [106.64214325,10.76694298] ; [106.64118195,10.76730156]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"17"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"BÃI XE BUÝT  ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT ĐẦM SEN, đường Hòa Bình, Quận  11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":"[106.64118195,10.76730156] ; [106.64076996,10.76747036] ; [106.64031982,10.76767540] ; [106.63975525,10.76803970] ; [106.63967133,10.76786041]"
    ,"Distance":"199"
  }]