export const Route118 =[

  {
     "Route_Id":"118"
    ,"Station_Id":"2272"
    ,"Station_Code":"BX 40"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bãi xe buýt 19/5"
    ,"Station_Address":"BÃI XE BUÝT 19/5, đường Hương L ộ 60B, Huyện Hóc Môn"
    ,"Lat":10.893196
    ,"Long":106.583473
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3829"
    ,"Station_Code":"HHM 232"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bãi xe buýt 19/5"
    ,"Station_Address":"Cây xăng Lý Quý, đường Lê Lợi, Huyện H óc Môn"
    ,"Lat":10.894514
    ,"Long":106.584633
    ,"Polyline":"[106.58379364,10.89367962] ; [106.58310699,10.89410973] ; [106.58342743,10.89445019] ; [106.58364868,10.89468956] ; [106.58406830,10.89529991] ; [106.58483124,10.89482975]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3830"
    ,"Station_Code":"HHM 231"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Đường song hành"
    ,"Station_Address":"91/14, đường Lê Lợi, Huyện Hóc Môn"
    ,"Lat":10.89306
    ,"Long":106.587341
    ,"Polyline":"[106.58483124,10.89482975] ; [106.58744812,10.89323997]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3831"
    ,"Station_Code":"HHM 227"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã ba Hóc Môn"
    ,"Station_Address":"10/5, đường Lê Lợi, Huyện Hóc Môn"
    ,"Lat":10.890747
    ,"Long":106.591194
    ,"Polyline":"[106.58744812,10.89323997] ; [106.58773804,10.89305973] ; [106.58824158,10.89270973] ; [106.58901978,10.89223003] ; [106.59068298,10.89124012] ; [106.59127045,10.89087009]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3832"
    ,"Station_Code":"HHM 228"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường tiểu học Nguyễn An Ninh"
    ,"Station_Address":"Đối diện trường Nguy ễn An Ninh, đường Lê Lợi, Huyện Hóc Môn"
    ,"Lat":10.889109
    ,"Long":106.594193
    ,"Polyline":"[106.59127045,10.89087009] ; [106.59184265,10.89054012] ; [106.59294891,10.89023018] ; [106.59426117,10.88918972]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"2332"
    ,"Station_Code":"HHM 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ Hóc  Môn"
    ,"Station_Address":"36 /6A, đường Quang Trung, Huyện Hóc Môn"
    ,"Lat":10.888083
    ,"Long":106.598915
    ,"Polyline":"[106.59426117,10.88918972] ; [106.59487152,10.88871002] ; [106.59494781,10.88862038] ; [106.59488678,10.88856983] ; [106.59490204,10.88850021] ; [106.59494781,10.88846016] ; [106.59503937,10.88846970] ; [106.59506989,10.88850021] ; [106.59559631,10.88842964] ; [106.59629059,10.88836956] ; [106.59723663,10.88833046] ; [106.59745026,10.88831997] ; [106.59803772,10.88829994] ; [106.59851837,10.88825989] ; [106.59893799,10.88819027]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"2333"
    ,"Station_Code":"HHM 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Công an  huyện Hóc Môn"
    ,"Station_Address":"1/18, đường Quang Trung, Huyện Hóc Môn"
    ,"Lat":10.887849
    ,"Long":106.601341
    ,"Polyline":"[106.59893799,10.88819027] ; [106.59963989,10.88805962] ; [106.60012054,10.88801956] ; [106.60134888,10.88796997]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3833"
    ,"Station_Code":"HHM 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã 3 Chùa"
    ,"Station_Address":"59/1, đường  Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.888002
    ,"Long":106.603249
    ,"Polyline":"[106.60134888,10.88796997] ; [106.60160828,10.88794041] ; [106.60192871,10.88786030] ; [106.60227966,10.88772964] ; [106.60317993,10.88813972]"
    ,"Distance":"214"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3834"
    ,"Station_Code":"HHM 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã 3 Chùa - Đặng Thúc Vịnh"
    ,"Station_Address":"87/1, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.888603
    ,"Long":106.606606
    ,"Polyline":"[106.60317993,10.88813972] ; [106.60381317,10.88840008] ; [106.60411835,10.88848019] ; [106.60568237,10.88866043] ; [106.60656738,10.88879967]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3823"
    ,"Station_Code":"HHM 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Siêu thị Maximax"
    ,"Station_Address":"17/2P, đường Đặng Thúc Vịnh, Huyện Hóc  Môn"
    ,"Lat":10.888729
    ,"Long":106.608646
    ,"Polyline":"[106.60660553,10.88860321] ; [106.60712433,10.88872910.06.60864258]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3836"
    ,"Station_Code":"HHM 142"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã tư Thới Tứ"
    ,"Station_Address":"153, đường Đặng Thúc Vịnh , Huyện Hóc Môn"
    ,"Lat":10.889624
    ,"Long":106.611199
    ,"Polyline":"[106.60864258,10.88872910.06.60992432] ; [10.88906097,106.61119843]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3837"
    ,"Station_Code":"HHM 143"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà Trẻ Họa Mi"
    ,"Station_Address":"137, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.890968
    ,"Long":106.614016
    ,"Polyline":"[106.61119843,10.88962364] ; [106.61189270,10.89021015] ; [106.61248779,10.89049911] ; [106.61398315,10.89097023] ; [106.61401367,10.89096832]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3838"
    ,"Station_Code":"HHM 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Tấn Lộc"
    ,"Station_Address":"29/5B, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.891963
    ,"Long":106.617154
    ,"Polyline":"[106.61401367,10.89096832] ; [106.61399841,10.89096928] ; [106.61398315,10.89097023] ; [106.61540222,10.89133644] ; [106.61663055,10.89167309] ; [106.61715698,10.89196301]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3839"
    ,"Station_Code":"QHMT056"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Thạch cao Tân Thanh Hà"
    ,"Station_Address":"Đối diện 3/3E, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.89320182800293
    ,"Long":106.61908721923828
    ,"Polyline":"[106.61715698,10.89196301] ; [106.61812592,10.89272690] ; [106.61908722,10.89320183]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3840"
    ,"Station_Code":"QHMT057"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Sửa xe Hồng Ân"
    ,"Station_Address":"5/14B, đường  Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.894524574279785
    ,"Long":106.62101745605469
    ,"Polyline":"[106.61908722,10.89320183] ; [106.62011719,10.89404392] ; [106.62101746,10.89452457]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3817"
    ,"Station_Code":"HHM 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Đại Hoàng Thủy"
    ,"Station_Address":"19, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.895619
    ,"Long":106.622508
    ,"Polyline":"[106.62101746,10.89452457] ; [106.62176514,10.89521313] ; [106.62250519,10.89561939]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3841"
    ,"Station_Code":"QHMT059"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Đông Thạnh"
    ,"Station_Address":"333, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.897336959838867
    ,"Long":106.62483215332031
    ,"Polyline":"[106.62250519,10.89561939] ; [106.62337494,10.89633560] ; [106.62483215,10.89733696]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3818"
    ,"Station_Code":"HHM 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trịnh Thị Miếng"
    ,"Station_Address":"409, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.898674
    ,"Long":106.626992
    ,"Polyline":"[106.62483215,10.89733696] ; [106.62699127,10.89867401]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3845"
    ,"Station_Code":"QHMT060"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường tiểu học Đông Thạnh"
    ,"Station_Address":"270, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.899402618408203
    ,"Long":106.62842559814453
    ,"Polyline":"[106.62699127,10.89867401] ; [106.62760162,10.89922237] ; [106.62842560,10.89940262]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3820"
    ,"Station_Code":"HHM 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà trọ Thanh Vân"
    ,"Station_Address":"357, đường Đặng Thúc Vịnh, Huyện Hóc M ôn"
    ,"Lat":10.90135
    ,"Long":106.63152
    ,"Polyline":"[106.62842560,10.89940262] ; [106.62944794,10.90038586] ; [106.63152313,10.90135002]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3822"
    ,"Station_Code":"HHM 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Xí nghiệp Pepssi"
    ,"Station_Address":"325, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.90272
    ,"Long":106.633945
    ,"Polyline":"[106.63152313,10.90135002] ; [106.63394165,10.90272045]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3819"
    ,"Station_Code":"HHM 149"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã tư Thới Tứ"
    ,"Station_Address":"3/7D (Đ/d 286), đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.903963
    ,"Long":106.636198
    ,"Polyline":"[106.63394165,10.90272045] ; [106.63619995,10.90396309]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3843"
    ,"Station_Code":"HHM 150"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã 3 Đồn"
    ,"Station_Address":"272, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.905122
    ,"Long":106.638343
    ,"Polyline":"[106.63619995,10.90396309] ; [106.63723755,10.90468502] ; [106.63834381,10.90512180]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3844"
    ,"Station_Code":"QHMT063"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã tư Đình"
    ,"Station_Address":"7/5B, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.905406951904297
    ,"Long":106.63896179199219
    ,"Polyline":"[106.63834381,10.90512180] ; [106.63854980,10.90536404] ; [106.63896179,10.90540695]"
    ,"Distance":"80"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3846"
    ,"Station_Code":"HHM 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cây xăng Đông Thạnh"
    ,"Station_Address":"205, đường Đặng Thúc Vịnh , Huyện Hóc Môn"
    ,"Lat":10.906576
    ,"Long":106.640875
    ,"Polyline":"[106.63896179,10.90540695] ; [106.63986969,10.90619087] ; [106.64087677,10.90657616]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3848"
    ,"Station_Code":"QHMT064"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã tư Đình"
    ,"Station_Address":"171, đường Đặng Th úc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.907693862915039
    ,"Long":106.64261627197266
    ,"Polyline":"[106.64087677,10.90657616] ; [106.64114380,10.90693378] ; [106.64261627,10.90769386]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3835"
    ,"Station_Code":"HHM 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Tập h óa Nam Phong"
    ,"Station_Address":"169, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.908166
    ,"Long":106.643429
    ,"Polyline":"[106.64261627,10.90769386] ; [106.64300537,10.90798187] ; [106.64343262,10.90816593]"
    ,"Distance":"104"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3808"
    ,"Station_Code":"HHM 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Công ty Huy Phát"
    ,"Station_Address":"147A, đường Lê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.907392
    ,"Long":106.644003
    ,"Polyline":"[106.64343262,10.90816593] ; [106.64414215,10.90873528] ; [106.64413452,10.90832424] ; [106.64400482,10.90739155]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3810"
    ,"Station_Code":"HHM 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Hương lộ 80B"
    ,"Station_Address":"85, đường Lê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.906591
    ,"Long":106.643922
    ,"Polyline":"[106.64400482,10.90739155] ; [106.64392090,10.90659142]"
    ,"Distance":"90"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3809"
    ,"Station_Code":"HHM 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Công ty dây cáp điện"
    ,"Station_Address":"39 , đường Lê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.905659
    ,"Long":106.643831
    ,"Polyline":"[106.64392090,10.90659142] ; [106.64382935,10.90565872]"
    ,"Distance":"104"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3813"
    ,"Station_Code":"HHM 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Giáo x ứ Tân Đông"
    ,"Station_Address":"27, đường Lê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.904843
    ,"Long":106.64396
    ,"Polyline":"[106.64382935,10.90565872] ; [106.64384460,10.90535355] ; [106.64388275,10.90517426] ; [106.64395905,10.90484333]"
    ,"Distance":"92"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3852"
    ,"Station_Code":"Q12 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Cầu dừa"
    ,"Station_Address":"730, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.889677
    ,"Long":106.647034
    ,"Polyline":"[106.64395905,10.90484333] ; [106.64664459,10.89471340] ; [106.64703369,10.88967705]"
    ,"Distance":"1727"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3853"
    ,"Station_Code":"Q12 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chùa Pháp Thạnh"
    ,"Station_Address":"125, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.885484
    ,"Long":106.647849
    ,"Polyline":"[106.64703369,10.88967705] ; [106.64732361,10.88906002] ; [106.64749146,10.88783360] ; [106.64785004,10.88548374]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3854"
    ,"Station_Code":"Q12 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Thới An 13"
    ,"Station_Address":"473, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.882033
    ,"Long":106.648525
    ,"Polyline":"[106.64785004,10.88548374] ; [106.64852142,10.88203335]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3855"
    ,"Station_Code":"Q12 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"381, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.879731
    ,"Long":106.648766
    ,"Polyline":"[106.64852142,10.88203335] ; [106.64872742,10.88075352] ; [106.64876556,10.87973118]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"2745"
    ,"Station_Code":"BX35"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"BÃI XE THỚI AN, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.878466606140137
    ,"Long":106.64797973632812
    ,"Polyline":"[106.64876556,10.87973118] ; [106.64891052,10.87851048] ; [106.64797974,10.87846661]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"2745"
    ,"Station_Code":"BX35"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"BÃI XE THỚI AN,  đường Lê Văn Khương, Quận 12"
    ,"Lat":10.878466606140137
    ,"Long":106.64797973632812
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3426"
    ,"Station_Code":"Q12 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bãi xe  buýt Thới An"
    ,"Station_Address":"390, đường  Lê Văn Khương, Quận 12"
    ,"Lat":10.878841
    ,"Long":106.649002
    ,"Polyline":"[106.64891052,10.87851048] ; [106.64890289,10.87884045]"
    ,"Distance":"36"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3804"
    ,"Station_Code":"Q12 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Lệ Thanh"
    ,"Station_Address":"458, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.88158
    ,"Long":106.648788
    ,"Polyline":"[106.64900208,10.87884140] ; [106.64878845,10.88158035]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3805"
    ,"Station_Code":"Q12 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Thiếc"
    ,"Station_Address":"548, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.88511
    ,"Long":106.64817
    ,"Polyline":"[106.64878845,10.88158035] ; [106.64817047,10.88510990]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3806"
    ,"Station_Code":"Q12 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Di động Thanh Thuận"
    ,"Station_Address":"31 /1, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.887744
    ,"Long":106.647667
    ,"Polyline":"[106.64810944,10.88510036] ; [106.64759827,10.88772964]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3807"
    ,"Station_Code":"Q12 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Dừa"
    ,"Station_Address":"772, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.891036
    ,"Long":106.647171
    ,"Polyline":"[106.64759827,10.88772964] ; [106.64752960,10.88815975] ; [106.64723206,10.88951969] ; [106.64713287,10.89052010.06.64710999]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3847"
    ,"Station_Code":"HHM 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu dừa"
    ,"Station_Address":"22 , đường Lê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.904848
    ,"Long":106.644142
    ,"Polyline":"[106.64717102,10.89103603] ; [106.64717102,10.89103603] ; [106.64711761,10.89298534] ; [106.64695740,10.89496613] ; [106.64658356,10.89622974] ; [106.64615631,10.89795780] ; [106.64468384,10.90359402] ; [106.64414215,10.90484810.06.64414215]"
    ,"Distance":"1582"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3849"
    ,"Station_Code":"HHM 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Xí nghi ệp Sam Mico"
    ,"Station_Address":"46, đường Lê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.906586
    ,"Long":106.644073
    ,"Polyline":"[106.64414215,10.90484810.06.64399719] ; [10.90541649,106.64407349]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3851"
    ,"Station_Code":"HHM 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chùa Phúc Thạnh"
    ,"Station_Address":"78, đ ường Lê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.907197
    ,"Long":106.644132
    ,"Polyline":"[106.64407349,10.90658569] ; [106.64413452,10.90719700]"
    ,"Distance":"68"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3850"
    ,"Station_Code":"HHM 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã tư  Đông Thạnh"
    ,"Station_Address":"156, đường L ê Văn Khương, Huyện Hóc Môn"
    ,"Lat":10.908446
    ,"Long":106.644271
    ,"Polyline":"[106.64413452,10.90719700] ; [106.64427185,10.90844631]"
    ,"Distance":"140"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3221"
    ,"Station_Code":"HHM 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đông Thạnh"
    ,"Station_Address":"32, đường Đặng Thúc Vinh, Huyện Hóc Môn"
    ,"Lat":10.908514
    ,"Long":106.64345
    ,"Polyline":"[106.64427185,10.90844631] ; [106.64424133,10.90881443] ; [106.64416504,10.90885162] ; [106.64344788,10.90851402]"
    ,"Distance":"137"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3222"
    ,"Station_Code":"HHM 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Tạp h óa Nguyên Hiền"
    ,"Station_Address":"49B, đường  Đặng Thúc Vinh, Huyện Hóc Môn"
    ,"Lat":10.907461
    ,"Long":106.641669
    ,"Polyline":"[106.64344788,10.90851402] ; [106.64167023,10.90746117]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3223"
    ,"Station_Code":"HHM 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Cầu Thi  Đua"
    ,"Station_Address":"246, đường Đặng Thúc  Vinh, Huyện Hóc Môn"
    ,"Lat":10.906934
    ,"Long":106.640897
    ,"Polyline":"[106.64167023,10.90746117] ; [106.64089966,10.90693378]"
    ,"Distance":"103"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3244"
    ,"Station_Code":"HHM 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường Mầm non"
    ,"Station_Address":"286, đường Đặng Thúc Vịnh, Huyện Hóc  Môn"
    ,"Lat":10.906007
    ,"Long":106.639191
    ,"Polyline":"[106.64089966,10.90693378] ; [106.63919067,10.90600681]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3811"
    ,"Station_Code":"HHM 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Đông Thạnh"
    ,"Station_Address":"324, đường Đặng Thúc Vịnh, Huy ện Hóc Môn"
    ,"Lat":10.904479
    ,"Long":106.636423
    ,"Polyline":"[106.63919067,10.90600681] ; [106.63783264,10.90520096] ; [106.63642120,10.90447903]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3812"
    ,"Station_Code":"HHM 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"363, đường Đặng Thúc Vịnh , Huyện Hóc Môn"
    ,"Lat":10.903447
    ,"Long":106.634653
    ,"Polyline":"[106.63642120,10.90447903] ; [106.63557434,10.90393162] ; [106.63465118,10.90344715]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"4162"
    ,"Station_Code":"HHM 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"447, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.902425
    ,"Long":106.6327
    ,"Polyline":"[106.63465118,10.90344715] ; [106.63269806,10.90242481]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"4163"
    ,"Station_Code":"HHM 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"60, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.898969
    ,"Long":106.626799
    ,"Polyline":"[106.63269806,10.90242481] ; [106.62680054,10.89896870]"
    ,"Distance":"751"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3815"
    ,"Station_Code":"HHM 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"10/1, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.896051
    ,"Long":106.622626
    ,"Polyline":"[106.62680054,10.89896870] ; [106.62262726,10.89605141]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3816"
    ,"Station_Code":"HHM 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Hóc M ôn"
    ,"Station_Address":"14/5, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.891426
    ,"Long":106.614568
    ,"Polyline":"[106.62262726,10.89605141] ; [106.61658478,10.89178371] ; [106.61457062,10.89142609]"
    ,"Distance":"1038"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3814"
    ,"Station_Code":"HHM 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"HĐND x ã Thới Tam Thôn"
    ,"Station_Address":"23/12,  đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.890267
    ,"Long":106.611564
    ,"Polyline":"[106.61457062,10.89142609] ; [106.61156464,10.89026737]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3821"
    ,"Station_Code":"HHM 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Chùa Minh  Hòa"
    ,"Station_Address":"292, đường Đặng Thúc Vịnh, Huyện Hóc Môn"
    ,"Lat":10.888918
    ,"Long":106.607219
    ,"Polyline":"[106.61156464,10.89026737] ; [106.61067200,10.88958263] ; [106.60970306,10.88910294] ; [106.60803223,10.88886070] ; [106.60721588,10.88891792]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3824"
    ,"Station_Code":"HHM 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã 3 Chùa"
    ,"Station_Address":"4/47, đường Đặng Thúc Vịnh , Huyện Hóc Môn"
    ,"Lat":10.888108
    ,"Long":106.602806
    ,"Polyline":"[106.60721588,10.88891792] ; [106.60494995,10.88866520] ; [106.60371399,10.88843346] ; [106.60280609,10.88810825]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"2266"
    ,"Station_Code":"HHM 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã 3 Chùa"
    ,"Station_Address":"4/36, đường Quang  Trung, Huyện Hóc Môn"
    ,"Lat":10.887975
    ,"Long":106.601688
    ,"Polyline":"[106.60280609,10.88810825] ; [106.60226440,10.88780689] ; [106.60168457,10.88797474]"
    ,"Distance":"134"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"2257"
    ,"Station_Code":"HHM 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Hóc Môn"
    ,"Station_Address":"1/18, đường Quang Trung, Huyện Hóc Môn"
    ,"Lat":10.888287
    ,"Long":106.598663
    ,"Polyline":"[106.60168457,10.88797474] ; [106.60168457,10.88797474] ; [106.60150909,10.88802242] ; [106.60121918,10.88805962] ; [106.59989929,10.88807583] ; [106.59942627,10.88809967] ; [106.59866333,10.88828659] ; [106.59866333,10.88828659]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3825"
    ,"Station_Code":"HHM 226"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã ba  Hóc Môn"
    ,"Station_Address":"Đối diện 19/2, đường Lê Lợi, Huyện Hóc Môn"
    ,"Lat":10.889009
    ,"Long":106.594666
    ,"Polyline":"[106.59866333,10.88828659] ; [106.59796906,10.88835430] ; [106.59572601,10.88845444] ; [106.59506226,10.88862324] ; [106.59466553,10.88900948]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3826"
    ,"Station_Code":"HHM 229"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường Nguyễn An Ninh"
    ,"Station_Address":"Trường Nguyễn An Ninh, đường Lê Lợi, Huyện Hóc Môn"
    ,"Lat":10.890684
    ,"Long":106.59185
    ,"Polyline":"[106.59466553,10.88900948] ; [106.59298706,10.89028263] ; [106.59197998,10.89057255] ; [106.59185028,10.89068413]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3827"
    ,"Station_Code":"HHM 230"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường sông hành QL22"
    ,"Station_Address":"131 /3, đường Lê Lợi, Huyện Hóc Môn"
    ,"Lat":10.893007
    ,"Long":106.58802
    ,"Polyline":"[106.59185028,10.89068413] ; [106.59134674,10.89090443] ; [106.59068298,10.89130497] ; [106.58946228,10.89204216] ; [106.58831787,10.89275837] ; [106.58802032,10.89300728]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"3828"
    ,"Station_Code":"HHM 233"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Bến xe 19 /5"
    ,"Station_Address":"Đối diện cây xăng Lý Quý, đường Lê Lợi, Huyện Hóc Môn"
    ,"Lat":10.89464
    ,"Long":106.585197
    ,"Polyline":"[106.58802032,10.89300728] ; [106.58766937,10.89315891] ; [106.58663940,10.89380169] ; [106.58519745,10.89463997]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"118"
    ,"Station_Id":"2272"
    ,"Station_Code":"BX 40"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Bãi xe buýt 19/5"
    ,"Station_Address":"BÃI XE BUÝT 19/5, đường H ương Lộ 60B, Huyện Hóc Môn"
    ,"Lat":10.893196
    ,"Long":106.583473
    ,"Polyline":"[106.58519745,10.89463997] ; [106.58519745,10.89463997] ; [106.58519745,10.89463997] ; [106.58519745,10.89463997] ; [106.58411407,10.89528751] ; [106.58362579,10.89466572] ; [106.58311462,10.89407539] ; [106.58379364,10.89367962] ; [106.58347321,10.89319611] ; [106.58347321,10.89319611] ; [106.58347321,10.89319611] ; [106.58347321,10.89319611]"
    ,"Distance":"463"
  }]