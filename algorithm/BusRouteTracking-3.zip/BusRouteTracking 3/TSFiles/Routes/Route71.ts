export const Route71 =[

  {
     "Route_Id":"71"
    ,"Station_Id":"3161"
    ,"Station_Code":"BX48"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Chợ Bình Hưng Hòa"
    ,"Station_Address":"Bình Tân, đường Tân Kỳ Tân Quý,  Quận Tân Phú"
    ,"Lat":10.783332
    ,"Long":106.599097
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1739"
    ,"Station_Code":"QBT 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Mã Lò"
    ,"Station_Address":"973, đường Tân Kỳ Tân Quý , Quận Bình Tân"
    ,"Lat":10.78817
    ,"Long":106.599548
    ,"Polyline":"[106.59909821,10.78333187] ; [106.59788513,10.78714752] ; [106.59954834,10.78816986]"
    ,"Distance":"659"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1742"
    ,"Station_Code":"QBT 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Kinh mới"
    ,"Station_Address":"753-755, đường T ân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.791951
    ,"Long":106.605995
    ,"Polyline":"[106.59948730,10.78816032] ; [106.60095215,10.78901005] ; [106.60281372,10.79012012] ; [106.60333252,10.79045963] ; [106.60369873,10.79067039] ; [106.60526276,10.79166985] ; [106.60594940,10.79203033]"
    ,"Distance":"827"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1741"
    ,"Station_Code":"QBT 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ủy ban phường Bình Hưng Hòa"
    ,"Station_Address":"Ủy ban phường Bình Hưng H òa, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.794422
    ,"Long":106.6101
    ,"Polyline":"[106.60594940,10.79203033] ; [106.60745239,10.79292965] ; [106.60888672,10.79380035] ; [106.60923767,10.79403973] ; [106.60954285,10.79421997] ; [106.61004639,10.79450989]"
    ,"Distance":"526"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1965"
    ,"Station_Code":"QBT 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nghĩa trang  Bình Hưng Hòa"
    ,"Station_Address":"Đối diện văn  phòng nghĩa trang, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.795908
    ,"Long":106.612541
    ,"Polyline":"[106.61004639,10.79450989] ; [106.61068726,10.79487991] ; [106.61083984,10.79500008] ; [106.61145020,10.79539013] ; [106.61202240,10.79574013] ; [106.61247253,10.79601002]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1967"
    ,"Station_Code":"QTP 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trạm Bình Long"
    ,"Station_Address":"595-597, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.797259
    ,"Long":106.614601
    ,"Polyline":"[106.61247253,10.79601002] ; [106.61328125,10.79648972] ; [106.61370087,10.79671001] ; [106.61440277,10.79714966] ; [106.61464691,10.79730034] ; [106.61466217,10.79728031] ; [106.61469269,10.79720020]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1970"
    ,"Station_Code":"QTP 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Tiểu Học Tân Quý"
    ,"Station_Address":"545, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798479
    ,"Long":106.616829
    ,"Polyline":"[106.61469269,10.79720020] ; [106.61464691,10.79730034] ; [106.61566925,10.79790020] ; [106.61621857,10.79821968] ; [106.61650085,10.79837036] ; [106.61666870,10.79843044] ; [106.61678314,10.79846954]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1973"
    ,"Station_Code":"QTP 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Tân Quý"
    ,"Station_Address":"457-459, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799005
    ,"Long":106.618256
    ,"Polyline":"[106.61678314,10.79846954] ; [106.61817932,10.79899025]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2592"
    ,"Station_Code":"QTP 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm Nh à Thờ Họ Tộc Nguyễn"
    ,"Station_Address":"395-397 , đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799767
    ,"Long":106.620506
    ,"Polyline":"[106.61820984,10.79899979] ; [106.62046814,10.79986000]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2597"
    ,"Station_Code":"QTP 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Showroom  otô"
    ,"Station_Address":"343-345, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.800703
    ,"Long":106.622986
    ,"Polyline":"[106.62046814,10.79986000] ; [106.62236023,10.80058002] ; [106.62294006,10.80082035]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2926"
    ,"Station_Code":"QTP 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Đầu cầu  xéo"
    ,"Station_Address":"Đối diện 9, đường Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.800399
    ,"Long":106.624222
    ,"Polyline":"[106.62298584,10.80070305] ; [106.62369537,10.80105877] ; [106.62424469,10.80129051] ; [106.62461090,10.80141258] ; [106.62422180,10.80039883]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2922"
    ,"Station_Code":"QTP 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Lê Đình Thám"
    ,"Station_Address":"94, đường Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.796659
    ,"Long":106.623749
    ,"Polyline":"[106.62422180,10.80039883] ; [106.62422943,10.80039978] ; [106.62400818,10.79967022] ; [106.62390900,10.79926014] ; [106.62384033,10.79883957] ; [106.62377930,10.79788971] ; [106.62374878,10.79665947]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2923"
    ,"Station_Code":"QTP 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Café Tino"
    ,"Station_Address":"111 , đường Gò Dầu, Quận Tân Phú"
    ,"Lat":10.795829
    ,"Long":106.624748
    ,"Polyline":"[106.62374878,10.79665947] ; [106.62380981,10.79590034] ; [106.62394714,10.79590034] ; [106.62474823,10.79586983] ; [106.62474823,10.79582882]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2927"
    ,"Station_Code":"QTP 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Chung cư  Gò Dầu"
    ,"Station_Address":"65, đường Gò Dầu, Quận Tân Phú"
    ,"Lat":10.795624
    ,"Long":106.628082
    ,"Polyline":"[106.62474823,10.79586983] ; [106.62737274,10.79580975] ; [106.62792969,10.79576969] ; [106.62803650,10.79572964] ; [106.62811279,10.79570007]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"4323"
    ,"Station_Code":"QTP 210"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"Kios 07, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.794481
    ,"Long":106.63808
    ,"Polyline":"[106.62808228,10.79562378] ; [106.62918091,10.79505157] ; [106.63029480,10.79444027] ; [106.63272858,10.79395580] ; [106.63544464,10.79354477] ; [106.63784790,10.79309177] ; [106.63807678,10.79448128]"
    ,"Distance":"1272"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2557"
    ,"Station_Code":"QTB 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Cư xá Tân Sơn Nhì"
    ,"Station_Address":"Đối diện 145, đường Ba Vân, Quận Tân B ình"
    ,"Lat":10.796127
    ,"Long":106.639497
    ,"Polyline":"[106.63807678,10.79448128] ; [106.63817596,10.79521561] ; [106.63824463,10.79558945] ; [106.63845062,10.79567909] ; [106.63880157,10.79585838] ; [106.63909149,10.79602146] ; [106.63944244,10.79606915] ; [106.63959503,10.79598236]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2560"
    ,"Station_Code":"QTB 143"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chùa Thiền Quang"
    ,"Station_Address":"19 , đường Trương Công Định, Quận Tân Bình"
    ,"Lat":10.797898
    ,"Long":106.641678
    ,"Polyline":"[106.63961029,10.79601002] ; [106.63993835,10.79590988] ; [106.64083099,10.79559994] ; [106.64160919,10.79788971]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2559"
    ,"Station_Code":"QTB 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã ba  Hồng Đào"
    ,"Station_Address":"351, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797666
    ,"Long":106.644266
    ,"Polyline":"[106.64167786,10.79789829] ; [106.64196014,10.79899025] ; [106.64334106,10.79825974] ; [106.64402008,10.79792023] ; [106.64427185,10.79767609]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1392"
    ,"Station_Code":"QTB 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"233, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796426
    ,"Long":106.646553
    ,"Polyline":"[106.64427185,10.79767609] ; [106.64549255,10.79712772] ; [106.64655304,10.79642582]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1826"
    ,"Station_Code":"QTB 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà thờ Đắc Lộ"
    ,"Station_Address":"97 (đối diện 160B), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794978
    ,"Long":106.64926
    ,"Polyline":"[106.64655304,10.79642582] ; [106.64727783,10.79612732] ; [106.64810944,10.79570007] ; [106.64932251,10.79506969] ; [106.64927673,10.79499626]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1830"
    ,"Station_Code":"QTB 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"67, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.793856
    ,"Long":106.651368
    ,"Polyline":"[106.64927673,10.79499626] ; [106.64968109,10.79483032] ; [106.65074921,10.79431438] ; [106.65154266,10.79377842]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình),  đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65154266,10.79377842] ; [106.65280914,10.79319668] ; [106.65324402,10.79296494] ; [106.65344238,10.79289150] ; [106.65374756,10.79316521] ; [106.65419769,10.79370308] ; [106.65456390,10.79416656] ; [106.65505981,10.79458714]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"555"
    ,"Station_Code":"QTB 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà hàng  Đông Phương"
    ,"Station_Address":"431, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.798622
    ,"Long":106.659286
    ,"Polyline":"[106.65502167,10.79463959] ; [106.65596771,10.79557991] ; [106.65693665,10.79648972] ; [106.65862274,10.79810047] ; [106.65920258,10.79870033]"
    ,"Distance":"663"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65920258,10.79870033] ; [106.66005707,10.79953098] ; [106.66081238,10.80016327] ; [106.66117859,10.80035305] ; [106.66164398,10.80065346] ; [106.66330719,10.80058002]"
    ,"Distance":"549"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80050278] ; [106.66330719,10.80050278] ; [106.66426086,10.80052662] ; [106.66532135,10.80041599] ; [106.66635132,10.80023193] ; [106.66635132,10.80023193]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"511"
    ,"Station_Code":"QPN 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"241, đường Hoàng Văn Thụ, Quận Phú Nhu ận"
    ,"Lat":10.799905
    ,"Long":106.6698
    ,"Polyline":"[106.66635132,10.80023193] ; [106.66703033,10.80025291] ; [106.66793060,10.80015850] ; [106.66875458,10.79998875]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"556"
    ,"Station_Code":"QPN 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Khách Sạn Tân Sơn Nhất"
    ,"Station_Address":"217, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799805
    ,"Long":106.670873
    ,"Polyline":"[106.66875458,10.79998875] ; [106.66928101,10.80004215] ; [106.66995239,10.80000496] ; [106.67037201,10.79985237]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"512"
    ,"Station_Code":"QPN 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Công an  Phú Nhuận"
    ,"Station_Address":"189, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799552
    ,"Long":106.673684
    ,"Polyline":"[106.67037201,10.79985237] ; [106.67132568,10.79988384] ; [106.67258453,10.79974174] ; [106.67368317,10.79955196]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"232"
    ,"Station_Code":"QPN 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"59, đường Hoàng Văn Thụ, Quận Phú Nhu ận"
    ,"Lat":10.799094
    ,"Long":106.679247
    ,"Polyline":"[106.67368317,10.79955196] ; [106.67463684,10.79958344] ; [106.67701721,10.79942513] ; [106.67924500,10.79913139]"
    ,"Distance":"611"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"558"
    ,"Station_Code":"QPN 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"171, đường Phan  Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.800241
    ,"Long":106.681541
    ,"Polyline":"[106.67924500,10.79913139] ; [106.68000793,10.79918957] ; [106.68028259,10.79920006] ; [106.68048096,10.79924011] ; [106.68096161,10.79973984] ; [106.68151093,10.80027008] ; [106.68154144,10.80024147]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"513"
    ,"Station_Code":"QPN 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"141 - 143, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802197
    ,"Long":106.683619
    ,"Polyline":"[106.68154144,10.80024147] ; [106.68151093,10.80027008] ; [106.68286133,10.80163956] ; [106.68315887,10.80191994] ; [106.68361664,10.80219746]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"514"
    ,"Station_Code":"QPN 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"109, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803841
    ,"Long":106.686156
    ,"Polyline":"[106.68361664,10.80219746] ; [106.68470764,10.80344963] ; [106.68492889,10.80364037] ; [106.68515778,10.80383015] ; [106.68544006,10.80395031] ; [106.68560028,10.80397987] ; [106.68576050,10.80399036] ; [106.68614960,10.80393982] ; [106.68615723,10.80384064]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"515"
    ,"Station_Code":"QPN 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh Viện Phước An"
    ,"Station_Address":"81 - 83, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.80362
    ,"Long":106.687744
    ,"Polyline":"[106.68615723,10.80384064] ; [106.68688202,10.80382538] ; [106.68737793,10.80374146] ; [106.68774414,10.80362034]"
    ,"Distance":"177"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"516"
    ,"Station_Code":"QBTH 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Công an PCCC"
    ,"Station_Address":"45, đường Phan Đ ăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803188
    ,"Long":106.691371
    ,"Polyline":"[106.68774414,10.80362034] ; [106.68869019,10.80360985] ; [106.69014740,10.80343533] ; [106.69136810,10.80318832]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"517"
    ,"Station_Code":"QBTH 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"1, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802455
    ,"Long":106.696826
    ,"Polyline":"[106.69136810,10.80318832] ; [106.69271088,10.80306721] ; [106.69474792,10.80281925] ; [106.69587708,10.80267143] ; [106.69682312,10.80245495]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"473C, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69682312,10.80245495] ; [106.69731903,10.80251312] ; [106.69795990,10.80245972] ; [106.69858551,10.80256653] ; [106.69895935,10.80278206] ; [106.69924927,10.80286694] ; [106.69955444,10.80296135]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"449, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69955444,10.80296135] ; [106.69955444,10.80296135] ; [106.70026398,10.80331421] ; [106.70071411,10.80349922] ; [106.70117950,10.80362511] ; [106.70117950,10.80362511]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"375, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70117950,10.80362511] ; [106.70153809,10.80381489] ; [106.70172882,10.80383968] ; [106.70278168,10.80356026] ; [106.70324707,10.80346012] ; [106.70365143,10.80342007] ; [106.70372009,10.80341434] ; [106.70398712,10.80329323]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70398712,10.80329323] ; [106.70473480,10.80331421] ; [106.70602417,10.80322456] ; [106.70671082,10.80307674]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Ba  Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70670319,10.80317020] ; [106.70815277,10.80307007] ; [106.70899200,10.80300045] ; [106.70997620,10.80294991] ; [106.71053314,10.80290031]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ Tĩnh, Quận Bình  Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71053314,10.80290031] ; [106.71114349,10.80286026] ; [106.71138763,10.80284023] ; [106.71141815,10.80298042] ; [106.71143341,10.80377960] ; [106.71145630,10.80453014] ; [106.71147919,10.80471039]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71166229,10.80680275] ; [106.71163177,10.80777264] ; [106.71178436,10.80830956] ; [106.71196747,10.80883121]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71215820,10.80955029] ; [106.71228790,10.81021976] ; [106.71240997,10.81079102]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"522"
    ,"Station_Code":"QBTH 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"100-102, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.811666
    ,"Long":106.712532
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71244049,10.81123924] ; [106.71253204,10.81166553]"
    ,"Distance":"99"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71253204,10.81166553] ; [106.71262360,10.81279373] ; [106.71268463,10.81333160] ; [106.71279144,10.81385326]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền  Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71272278,10.81385994] ; [106.71285248,10.81464291] ; [106.71298218,10.81557083] ; [106.71313477,10.81710911] ; [106.71311951,10.81738281] ; [106.71269226,10.81735134] ; [106.71208191,10.81720448] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71052551,10.81531811] ; [106.71003723,10.81440067] ; [106.70980072,10.81379986] ; [106.71015930,10.81397915] ; [106.71044922,10.81452751] ; [106.71067810,10.81497002] ; [106.71129608,10.81473255]"
    ,"Distance":"1222"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền  Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường Đinh  Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71129608,10.81473255] ; [106.71068573,10.81504345] ; [106.71095276,10.81552315] ; [106.71109772,10.81583977] ; [106.71091461,10.81609249] ; [106.71015930,10.81459045] ; [106.70964813,10.81360531] ; [106.70922089,10.81262493]"
    ,"Distance":"637"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70925140,10.81260014] ; [106.70919037,10.81247044] ; [106.70913696,10.81227016] ; [106.70912933,10.81159019] ; [106.70913696,10.81058025] ; [106.70919037,10.80980968]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70919037,10.80980968] ; [106.70926666,10.80805969] ; [106.70937347,10.80710983] ; [106.70941162,10.80679989] ; [106.70925140,10.80677986] ; [106.70924377,10.80677986]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70924377,10.80677986] ; [106.70941162,10.80679989] ; [106.70947266,10.80597973] ; [106.70950317,10.80550957] ; [106.70947266,10.80498028] ; [106.70942688,10.80436993]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.70942688,10.80436993] ; [106.70935059,10.80296993] ; [106.70806885,10.80307007] ; [106.70793152,10.80307961]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70793152,10.80307961] ; [106.70395660,10.80338955]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"288, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70395660,10.80338955] ; [106.70346069,10.80342960] ; [106.70278168,10.80356026] ; [106.70172882,10.80383968] ; [106.70157623,10.80385017] ; [106.70136261,10.80381966] ; [106.70104218,10.80368996]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"368, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70104218,10.80368996] ; [106.69924164,10.80296993]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"UBND Quận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69924164,10.80296993] ; [106.69860077,10.80268002] ; [106.69795990,10.80245972] ; [106.69753265,10.80249977] ; [106.69599152,10.80268002] ; [106.69573212,10.80272007]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"594"
    ,"Station_Code":"QBTH 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"10, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803088
    ,"Long":106.693586
    ,"Polyline":"[106.69573212,10.80272007] ; [106.69348145,10.80301952]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"593"
    ,"Station_Code":"QBTH 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Công an PCCC, Quận Bình Thạnh"
    ,"Station_Address":"14-16, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803362
    ,"Long":106.691473
    ,"Polyline":"[106.69348145,10.80301952] ; [106.69243622,10.80313015] ; [106.69145966,10.80327034]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"595"
    ,"Station_Code":"QPN 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bệnh viện Phước An"
    ,"Station_Address":"36A, đường Phan Đăng Lưu, Qu ận Phú Nhuận"
    ,"Lat":10.803894
    ,"Long":106.687535
    ,"Polyline":"[106.69145966,10.80327034] ; [106.68968964,10.80350018] ; [106.68791199,10.80370998] ; [106.68756866,10.80375004]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"596"
    ,"Station_Code":"QPN 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"68, đường Phan Đăng Lưu, Quận Phú Nhu ận"
    ,"Lat":10.804063
    ,"Long":106.686269
    ,"Polyline":"[106.68756866,10.80375004] ; [106.68601227,10.80395985]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"597"
    ,"Station_Code":"QPN 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"124, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802629
    ,"Long":106.683689
    ,"Polyline":"[106.68601227,10.80395985] ; [106.68576050,10.80399036] ; [106.68560028,10.80397987] ; [106.68544006,10.80395031] ; [106.68515778,10.80383015] ; [106.68492889,10.80364037] ; [106.68470764,10.80344963] ; [106.68376160,10.80249977]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"598"
    ,"Station_Code":"QPN 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã tư  Phan Xích Long"
    ,"Station_Address":"172, đư ờng Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.800854
    ,"Long":106.681833
    ,"Polyline":"[106.68376160,10.80249977] ; [106.68202209,10.80080032]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"599"
    ,"Station_Code":"QPN 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Tư  Phú Nhuận"
    ,"Station_Address":"24, đường Ho àng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.79931
    ,"Long":106.679354
    ,"Polyline":"[106.68202209,10.80080032] ; [106.68138885,10.80014992] ; [106.68048096,10.79924011] ; [106.68028259,10.79920006] ; [106.68000793,10.79918957] ; [106.67967987,10.79920959]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"601"
    ,"Station_Code":"QPN 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"202, đường Hoàng Văn Thụ, Quận Phú Nhu ận"
    ,"Lat":10.800153
    ,"Long":106.669559
    ,"Polyline":"[106.67967987,10.79920959] ; [106.67832947,10.79928970] ; [106.67685699,10.79942989] ; [106.67492676,10.79959011] ; [106.67141724,10.79986954] ; [106.66980743,10.80000019]"
    ,"Distance":"1082"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu 7), đường Phan  Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66954041,10.80016899] ; [106.66892242,10.80012131] ; [106.66771698,10.80022621] ; [106.66728210,10.80047321] ; [106.66683960,10.80072021] ; [106.66662598,10.80095100]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"257"
    ,"Station_Code":"QTB 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Công viên Hoàng Văn Thụ"
    ,"Station_Address":"Công viên Hoàng Văn Thụ, đường Phan Thúc Duyện, Quận Tân Bình"
    ,"Lat":10.802403
    ,"Long":106.664221
    ,"Polyline":"[106.66662598,10.80095100] ; [106.66603851,10.80126953] ; [106.66596985,10.80132771] ; [106.66585541,10.80139065] ; [106.66416931,10.80236053]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66416931,10.80236053] ; [106.66416931,10.80236053] ; [106.66355896,10.80266953] ; [106.66342163,10.80245972] ; [106.66260529,10.80168629] ; [106.66230011,10.80137253]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"600"
    ,"Station_Code":"QTB 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"216 , đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.799836
    ,"Long":106.660385
    ,"Polyline":"[106.66230011,10.80137253] ; [106.66194153,10.80095959] ; [106.66171265,10.80080986] ; [106.66152191,10.80070019] ; [106.66134644,10.80066013] ; [106.66101074,10.80058956] ; [106.66092682,10.80056953] ; [106.66085052,10.80051041] ; [106.66081238,10.80045986] ; [106.66082001,10.80033970] ; [106.66074371,10.80012035] ; [106.66063690,10.80002975] ; [106.66038513,10.79983616]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"602"
    ,"Station_Code":"QTB 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Công an  Quận Tân Bình"
    ,"Station_Address":"340H, đường Ho àng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.796577
    ,"Long":106.656952
    ,"Polyline":"[106.66038513,10.79983616] ; [106.66037750,10.79979992] ; [106.65936279,10.79885960] ; [106.65862274,10.79810047] ; [106.65837860,10.79788017] ; [106.65695190,10.79657745]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đư ờng Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65695190,10.79657745] ; [106.65577698,10.79539013] ; [106.65519714,10.79608059]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62), đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65519714,10.79608059] ; [106.65519714,10.79608059] ; [106.65464783,10.79653263] ; [106.65386963,10.79587364] ; [106.65386963,10.79587364]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường Xu ân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65386963,10.79587364] ; [106.65386963,10.79587364] ; [106.65312958,10.79512024] ; [106.65233612,10.79437923] ; [106.65233612,10.79437923]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1719"
    ,"Station_Code":"QTB 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"106, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794182
    ,"Long":106.651191
    ,"Polyline":"[106.65233612,10.79437923] ; [106.65184021,10.79384041] ; [106.65165710,10.79380798] ; [106.65145111,10.79391003] ; [106.65115356,10.79411888]"
    ,"Distance":"166"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1720"
    ,"Station_Code":"QTB 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Nhà Thở Đắc Lộ"
    ,"Station_Address":"150, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794973
    ,"Long":106.649743
    ,"Polyline":"[106.65115356,10.79411888] ; [106.65038300,10.79452038] ; [106.64967346,10.79491615]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1301"
    ,"Station_Code":"QTB 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"162T, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796137
    ,"Long":106.647565
    ,"Polyline":"[106.64967346,10.79491615] ; [106.64884186,10.79538918] ; [106.64792633,10.79585838] ; [106.64751434,10.79607868]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2713"
    ,"Station_Code":"QTB 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã ba Bình Giã"
    ,"Station_Address":"298 , đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797792
    ,"Long":106.644453
    ,"Polyline":"[106.64751434,10.79607868] ; [106.64681244,10.79640961] ; [106.64584351,10.79693985] ; [106.64439392,10.79774761]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2714"
    ,"Station_Code":"QTB 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Chùa Thi ền Quang"
    ,"Station_Address":"22, đường Trương Công Định, Quận Tân Bình"
    ,"Lat":10.798234
    ,"Long":106.641663
    ,"Polyline":"[106.64439392,10.79774761] ; [106.64437866,10.79773045] ; [106.64402008,10.79792023] ; [106.64340210,10.79830360] ; [106.64197540,10.79908276] ; [106.64186859,10.79879856] ; [106.64166260,10.79823399]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2715"
    ,"Station_Code":"QTB 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cư xá T ân Sơn Nhì"
    ,"Station_Address":"133, đường Ba Vân, Quận Tân Bình"
    ,"Lat":10.796006
    ,"Long":106.639529
    ,"Polyline":"[106.64166260,10.79823399] ; [106.64083099,10.79559994] ; [106.63993835,10.79590988] ; [106.63951111,10.79605007] ; [106.63950348,10.79603958]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"4312"
    ,"Station_Code":"QTP 186"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã 3 Dân Tộc"
    ,"Station_Address":"1033, đường Lũy B án Bích, Quận Tân Phú"
    ,"Lat":10.794408
    ,"Long":106.638026
    ,"Polyline":"[106.63950348,10.79603958] ; [106.63919830,10.79608440] ; [106.63895416,10.79596329] ; [106.63867188,10.79577923] ; [106.63833618,10.79566288] ; [106.63823700,10.79555798] ; [106.63811493,10.79498386] ; [106.63802338,10.79440784]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2913"
    ,"Station_Code":"QTP 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chung cư  Gò Dầu"
    ,"Station_Address":"38, đường Gò Dầu, Quận Tân Phú"
    ,"Lat":10.795697
    ,"Long":106.628242
    ,"Polyline":"[106.63802338,10.79440784] ; [106.63782501,10.79316044] ; [106.63555145,10.79353428] ; [106.63327789,10.79387188] ; [106.63164520,10.79417706] ; [106.63035583,10.79440403] ; [106.62930298,10.79504108] ; [106.62876892,10.79535770] ; [106.62824249,10.79569721]"
    ,"Distance":"1241"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2912"
    ,"Station_Code":"QTP 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Café Tino"
    ,"Station_Address":"122, đường Gò Dầu, Quận Tân Phú"
    ,"Lat":10.795903
    ,"Long":106.62487
    ,"Polyline":"[106.62824249,10.79569721] ; [106.62792969,10.79576969] ; [106.62737274,10.79580975] ; [106.62692261,10.79585838] ; [106.62546539,10.79587364] ; [106.62487030,10.79590321]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2918"
    ,"Station_Code":"QTP 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Lê Đình  Thám"
    ,"Station_Address":"77, đường Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.796464
    ,"Long":106.623871
    ,"Polyline":"[106.62487030,10.79590321] ; [106.62455750,10.79590034] ; [106.62380981,10.79590034] ; [106.62380219,10.79618454] ; [106.62387085,10.79646397]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2914"
    ,"Station_Code":"QTP 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cuối Cầu Xéo"
    ,"Station_Address":"3, đường Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.800497
    ,"Long":106.624283
    ,"Polyline":"[106.62387085,10.79646397] ; [106.62377930,10.79788971] ; [106.62384033,10.79883957] ; [106.62390900,10.79926014] ; [106.62400818,10.79967022] ; [106.62416077,10.80021000] ; [106.62428284,10.80053043] ; [106.62428284,10.80049706]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2658"
    ,"Station_Code":"QTP 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Showroom otô"
    ,"Station_Address":"51/13, đường Tân  Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.801045
    ,"Long":106.62336
    ,"Polyline":"[106.62428284,10.80049706] ; [106.62463379,10.80146503] ; [106.62403107,10.80124378] ; [106.62335968,10.80104542]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2660"
    ,"Station_Code":"QTP 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm Nhà Thờ Họ Tộc Nguyễn"
    ,"Station_Address":"378, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799963
    ,"Long":106.620499
    ,"Polyline":"[106.62335968,10.80104542] ; [106.62235260,10.80058479] ; [106.62122345,10.80018997] ; [106.62049866,10.79996300]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2004"
    ,"Station_Code":"QTP 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Tân Quý"
    ,"Station_Address":"Kế 410, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798983
    ,"Long":106.618134
    ,"Polyline":"[106.62049866,10.79996300] ; [106.61989594,10.79970455] ; [106.61903381,10.79936790] ; [106.61813354,10.79898262]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2007"
    ,"Station_Code":"QTP 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Trường Tiểu Học Tân Quý"
    ,"Station_Address":"3/1B, đường Tân Kỳ Tân Qu ý, Quận Tân Phú"
    ,"Lat":10.798385
    ,"Long":106.616493
    ,"Polyline":"[106.61813354,10.79898262] ; [106.61814117,10.79897022] ; [106.61731720,10.79870892] ; [106.61649323,10.79838467]"
    ,"Distance":"193"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2009"
    ,"Station_Code":"QTP 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Bình Long"
    ,"Station_Address":"520-522, đư ờng Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.797263
    ,"Long":106.614571
    ,"Polyline":"[106.61650085,10.79837036] ; [106.61505890,10.79755020] ; [106.61457825,10.79726028]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"2008"
    ,"Station_Code":"QBT 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Lò Thi êu"
    ,"Station_Address":"Đối diện Thành Minh Trương Tế, đường Tân Kỳ Tân Qu ý, Quận Bình Tân"
    ,"Lat":10.795939
    ,"Long":106.612221
    ,"Polyline":"[106.61457062,10.79726315] ; [106.61459351,10.79726028] ; [106.61370087,10.79671001] ; [106.61280060,10.79621983] ; [106.61222076,10.79593945]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1804"
    ,"Station_Code":"QBT 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"UBND Phường Bình Hưng Hòa"
    ,"Station_Address":"Đối diện Ủy ban nhân dân phường Bình Hưng Hòa, đường Tân Kỳ Tân  Quý, Quận Bình Tân"
    ,"Lat":10.794702
    ,"Long":106.610229
    ,"Polyline":"[106.61222076,10.79593945] ; [106.61157227,10.79546261] ; [106.61083221,10.79502010.06.61064911] ; [10.79491520,106.61022949]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1808"
    ,"Station_Code":"QBT 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Phòng khám Đa khoa"
    ,"Station_Address":"722, đường T ân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.792528
    ,"Long":106.606636
    ,"Polyline":"[106.61022949,10.79470158] ; [106.60951233,10.79424572] ; [106.60922241,10.79406643] ; [106.60887146,10.79385090] ; [106.60805511,10.79335499] ; [106.60746765,10.79298115] ; [106.60663605,10.79252815]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"1810"
    ,"Station_Code":"QBT 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bưu điện"
    ,"Station_Address":"928, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.788981
    ,"Long":106.6007
    ,"Polyline":"[106.60663605,10.79252815] ; [106.60604095,10.79220104] ; [106.60524750,10.79171085] ; [106.60374451,10.79075241] ; [106.60333252,10.79045963] ; [106.60278320,10.79013538] ; [106.60234070,10.78985023] ; [106.60108185,10.78918743] ; [106.60070038,10.78898144]"
    ,"Distance":"760"
  },
  {
     "Route_Id":"71"
    ,"Station_Id":"3161"
    ,"Station_Code":"BX48"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Chợ Bình Hưng Hòa"
    ,"Station_Address":"Bình  Tân, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.783332
    ,"Long":106.599097
    ,"Polyline":"[106.60070038,10.78898144] ; [106.59819794,10.78752708] ; [106.59783173,10.78727436] ; [106.59785461,10.78687382] ; [106.59894562,10.78320599] ; [106.59909821,10.78333187]"
    ,"Distance":"859"
  }]