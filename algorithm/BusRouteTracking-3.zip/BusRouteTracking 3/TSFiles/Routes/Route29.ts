export const Route29 =[

  {
     "Route_Id":"29"
    ,"Station_Id":"1560"
    ,"Station_Code":"BX54"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Cư xá Nhiêu Lộc"
    ,"Station_Address":"Bến xe buýt Cư xá Nhiêu Lộc, đường Lê Th úc Hoạch, Quận Tân Phú"
    ,"Lat":10.788043
    ,"Long":106.621895
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1561"
    ,"Station_Code":"QTP 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"239, đường Lê Thúc Hoạch, Quận Tân Phú"
    ,"Lat":10.788292
    ,"Long":106.618896
    ,"Polyline":"[106.62181091,10.78789043] ; [106.62132263,10.78820038] ; [106.62104034,10.78845024] ; [106.61901855,10.78827953] ; [106.61889648,10.78827000]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1559"
    ,"Station_Code":"QBT 209"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Nghĩa trang Đa Minh"
    ,"Station_Address":"Nghĩa trang Đa Minh, đường B ình Long, Quận Bình Tân"
    ,"Lat":10.787274
    ,"Long":106.617401
    ,"Polyline":"[106.61889648,10.78829193] ; [106.61889648,10.78829193] ; [106.61735535,10.78818035] ; [106.61764526,10.78734303] ; [106.61740112,10.78727436]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1564"
    ,"Station_Code":"QBT 210"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Sơn Xuân Phát"
    ,"Station_Address":"175, đường Bình Long, Quận Bình Tân"
    ,"Lat":10.78299
    ,"Long":106.619273
    ,"Polyline":"[106.61740112,10.78727436] ; [106.61764526,10.78731632] ; [106.61851501,10.78531361] ; [106.61927032,10.78297424] ; [106.61887360,10.78285313]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1566"
    ,"Station_Code":"QBT 211"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"660 (99), đường Bình Long, Quận Bình Tân"
    ,"Lat":10.779475
    ,"Long":106.620555
    ,"Polyline":"[106.61887360,10.78285313] ; [106.61927795,10.78295326] ; [106.62043762,10.77947521] ; [106.62000275,10.77939320]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1562"
    ,"Station_Code":"QBT 212"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Chùa Như Thị Thất"
    ,"Station_Address":"25, đường Bình Long, Quận Bình Tân"
    ,"Lat":10.775928
    ,"Long":106.621424
    ,"Polyline":"[106.62046051,10.77954006] ; [106.62088776,10.77826023] ; [106.62117004,10.77731991] ; [106.62127686,10.77694988] ; [106.62138367,10.77657986] ; [106.62143707,10.77614975] ; [106.62145233,10.77593040]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1568"
    ,"Station_Code":"QTP 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"257, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.772962
    ,"Long":106.62294
    ,"Polyline":"[106.62112427,10.77592087] ; [106.62136841,10.77590179] ; [106.62156677,10.77365685] ; [106.62215424,10.77359390] ; [106.62303162,10.77328777] ; [106.62294006,10.77296162] ; [106.62294006,10.77296162]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1563"
    ,"Station_Code":"QTP 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"245, đường Hòa Bình, Quận  Tân Phú"
    ,"Lat":10.772165
    ,"Long":106.6259
    ,"Polyline":"[106.62294006,10.77296162] ; [106.62307739,10.77326679] ; [106.62593079,10.77227020] ; [106.62590027,10.77216530]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1565"
    ,"Station_Code":"QTP 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trâm Tâm Mua Sắm"
    ,"Station_Address":"165, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.771252
    ,"Long":106.628975
    ,"Polyline":"[106.62590027,10.77216530] ; [106.62593079,10.77227020] ; [106.62777710,10.77155972] ; [106.62898254,10.77128029] ; [106.62897491,10.77125168]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1570"
    ,"Station_Code":"QTP 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"69, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769694
    ,"Long":106.633057
    ,"Polyline":"[106.62897491,10.77125168] ; [106.62897491,10.77125168] ; [106.63311768,10.76979923] ; [106.63305664,10.76969433] ; [106.63305664,10.76969433]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1567"
    ,"Station_Code":"QTP 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Cây Xăng Hòa Bình"
    ,"Station_Address":"176/26, đường Hòa  Bình, Quận Tân Phú"
    ,"Lat":10.769394
    ,"Long":106.63533
    ,"Polyline":"[106.63313293,10.76990032] ; [106.63390350,10.76963043] ; [106.63421631,10.76949978] ; [106.63432312,10.76947021] ; [106.63439941,10.76947975] ; [106.63446045,10.76947975] ; [106.63500977,10.76953030] ; [106.63530731,10.76955986]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1571"
    ,"Station_Code":"Q11 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Thuỷ Tạ"
    ,"Station_Address":"đd 90 (nhà hàng Thủy Tạ Đ ầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.768719
    ,"Long":106.637909
    ,"Polyline":"[106.63530731,10.76955986] ; [106.63571167,10.76959038] ; [106.63597870,10.76955986] ; [106.63630676,10.76949024] ; [106.63687134,10.76930046] ; [106.63793182,10.76887035] ; [106.63796234,10.76885033]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1569"
    ,"Station_Code":"Q11 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Bãi xe bu ýt Đầm Sen"
    ,"Station_Address":"7B (Bến xe bu ýt Đầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.767916
    ,"Long":106.639511
    ,"Polyline":"[106.63790894,10.76871872] ; [106.63796234,10.76885033] ; [106.63870239,10.76849747] ; [106.63908386,10.76835060] ; [106.63943481,10.76813412] ; [106.63951111,10.76791573]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1043"
    ,"Station_Code":"Q11 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 4 Hòa  Bình"
    ,"Station_Address":"3 (79), đường Hòa Bình, Qu ận 11"
    ,"Lat":10.76698
    ,"Long":106.641571
    ,"Polyline":"[106.63963318,10.76807976] ; [106.64053345,10.76756001] ; [106.64096832,10.76729012] ; [106.64115143,10.76718998] ; [106.64138794,10.76710033] ; [106.64158630,10.76704025]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1572"
    ,"Station_Code":"Q11 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Cổng 1 Đầm Sen"
    ,"Station_Address":"281, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.765199
    ,"Long":106.642128
    ,"Polyline":"[106.64157104,10.76698017] ; [106.64157104,10.76698017] ; [106.64162445,10.76703262] ; [106.64214325,10.76684856] ; [106.64218903,10.76671124] ; [106.64228821,10.76663208] ; [106.64219666,10.76518345] ; [106.64212799,10.76519871] ; [106.64212799,10.76519871]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1776"
    ,"Station_Code":"Q11 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"công an P10"
    ,"Station_Address":"569 (596), đ ường Minh Phụng, Quận 11"
    ,"Lat":10.763649
    ,"Long":106.644706
    ,"Polyline":"[106.64212799,10.76519871] ; [106.64212799,10.76519871] ; [106.64212799,10.76519871] ; [106.64210510,10.76281166] ; [106.64234924,10.76281643] ; [106.64337158,10.76325417] ; [106.64489746,10.76428223] ; [106.64476013,10.76361561] ; [106.64470673,10.76364899] ; [106.64470673,10.76364899]"
    ,"Distance":"699"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1777"
    ,"Station_Code":"Q11 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Đội Cung"
    ,"Station_Address":"461, đường Minh Phụng, Quận 11"
    ,"Lat":10.761968
    ,"Long":106.644459
    ,"Polyline":"[106.64476013,10.76361561] ; [106.64448547,10.76198959]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1779"
    ,"Station_Code":"Q11 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"THCS Lê Anh Xuân"
    ,"Station_Address":"385, đường Minh Phụng, Quận 11"
    ,"Lat":10.759449
    ,"Long":106.644051
    ,"Polyline":"[106.64446259,10.76196766] ; [106.64448547,10.76198959] ; [106.64410400,10.75958061] ; [106.64405060,10.75944901]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1576"
    ,"Station_Code":"Q11 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Hàn Hải Nguyên"
    ,"Station_Address":"211, đường Hàn Hải Nguyên, Quận 11"
    ,"Lat":10.758216
    ,"Long":106.645349
    ,"Polyline":"[106.64405060,10.75944901] ; [106.64386749,10.75832176] ; [106.64534760,10.75821590]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1575"
    ,"Station_Code":"Q11 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Đường 3/2"
    ,"Station_Address":"107, đường Hàn Hải Nguyên, Quận 11"
    ,"Lat":10.757984
    ,"Long":106.647908
    ,"Polyline":"[106.64534760,10.75822353] ; [106.64790344,10.75804996]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1577"
    ,"Station_Code":"Q11 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Nguyễn Thị Nhỏ"
    ,"Station_Address":"59-61,  đường Hàn Hải Nguyên, Quận 11"
    ,"Lat":10.757858
    ,"Long":106.650118
    ,"Polyline":"[106.64790344,10.75804996] ; [106.65011597,10.75790215]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1578"
    ,"Station_Code":"Q11 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trần Quý"
    ,"Station_Address":"225-227, đường Trần Quý, Quận 11"
    ,"Lat":10.758248
    ,"Long":106.652226
    ,"Polyline":"[106.65011597,10.75785828] ; [106.65011597,10.75790215] ; [106.65130615,10.75786304] ; [106.65132904,10.75809479] ; [106.65222168,10.75823212] ; [106.65222931,10.75824833]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1015"
    ,"Station_Code":"Q11 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm Trần Quý - Tạ Uyên"
    ,"Station_Address":"193, đường Tạ Uyên, Quận 11"
    ,"Lat":10.758068
    ,"Long":106.653492
    ,"Polyline":"[106.65222931,10.75824833] ; [106.65347290,10.75858498] ; [106.65349579,10.75806808]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1580"
    ,"Station_Code":"Q5 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Khách sạn Hoàng Hậu"
    ,"Station_Address":"321-323, đường Nguyễn Chí Thanh, Quận  5"
    ,"Lat":10.757026
    ,"Long":106.655022
    ,"Polyline":"[106.65349579,10.75806808] ; [106.65365601,10.75680351] ; [106.65502167,10.75702572]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1050"
    ,"Station_Code":"Q5 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Thiếc"
    ,"Station_Address":"235, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.757568
    ,"Long":106.657616
    ,"Polyline":"[106.65500641,10.75708961] ; [106.65760803,10.75763035]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"395"
    ,"Station_Code":"Q5 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"Đối diện 30-32, đường Thuận Kiều, Quận  5"
    ,"Lat":10.755381
    ,"Long":106.658369
    ,"Polyline":"[106.65761566,10.75756836] ; [106.65822601,10.75771523] ; [106.65837097,10.75642395] ; [106.65837097,10.75538063]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"435"
    ,"Station_Code":"Q5 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"Đối diện 385, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75458
    ,"Long":106.657934
    ,"Polyline":"[106.65837097,10.75538063] ; [106.65847015,10.75477505] ; [106.65838623,10.75464249] ; [106.65793610,10.75457954]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"438"
    ,"Station_Code":"Q5 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Dương Tử Giang"
    ,"Station_Address":"Đối diện 455-457, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754158
    ,"Long":106.65552
    ,"Polyline":"[106.65793610,10.75457954] ; [106.65730286,10.75442123] ; [106.65667725,10.75429535] ; [106.65551758,10.75415802]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"4773"
    ,"Station_Code":"Q6 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cây xăng"
    ,"Station_Address":"Đối diện 13, đường Lê Quang  Sung, Quận 6"
    ,"Lat":10.751112
    ,"Long":106.652538
    ,"Polyline":"[106.65551758,10.75415802] ; [106.65384674,10.75379944] ; [106.65326691,10.75171280] ; [106.65331268,10.75111675] ; [106.65253448,10.75111198]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"4418"
    ,"Station_Code":"Q6 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Phan Văn Khỏe"
    ,"Station_Address":"1D, đường Phạm Đình Hổ, Quận 6"
    ,"Lat":10.748803
    ,"Long":106.649303
    ,"Polyline":"[106.65253448,10.75111198] ; [106.65106964,10.75098515] ; [106.65009308,10.75109100] ; [106.64953613,10.75077438] ; [106.64929962,10.74880314]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1579"
    ,"Station_Code":"Q6 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ủy ban nhân dân Quận 6"
    ,"Station_Address":"Đối diện 91, đường Phạm Văn Ch í, Quận 6"
    ,"Lat":10.746295
    ,"Long":106.649201
    ,"Polyline":"[106.64929962,10.74880314] ; [106.64956665,10.74703217] ; [106.64971924,10.74651623] ; [106.64920044,10.74629498]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1581"
    ,"Station_Code":"Q6 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Ban Chỉ huy Quân sự Phường 4"
    ,"Station_Address":"148, đường Ph ạm Văn Chí, Quận 6"
    ,"Lat":10.745436
    ,"Long":106.647608
    ,"Polyline":"[106.64920044,10.74629498] ; [106.64817810,10.74567318] ; [106.64760590,10.74543571]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1582"
    ,"Station_Code":"Q6 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Phạm Phú Thứ"
    ,"Station_Address":"322, đường Phạm V ăn Chí, Quận 6"
    ,"Lat":10.744666
    ,"Long":106.646224
    ,"Polyline":"[106.64760590,10.74543571] ; [106.64718628,10.74520874] ; [106.64622498,10.74466610]"
    ,"Distance":"174"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1585"
    ,"Station_Code":"Q6 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Phường 8"
    ,"Station_Address":"560, đường Phạm Văn Chí, Quận 6"
    ,"Lat":10.741994
    ,"Long":106.641594
    ,"Polyline":"[106.64622498,10.74466610.06.64159393]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1584"
    ,"Station_Code":"Q6 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Giáo xứ Bình Phước"
    ,"Station_Address":"648-650, đường Phạm Văn Chí, Quận 6"
    ,"Lat":10.74074
    ,"Long":106.639309
    ,"Polyline":"[106.64160919,10.74198627] ; [106.63963318,10.74092674]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"757"
    ,"Station_Code":"Q6 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Cầu Phạm V ăn Chí"
    ,"Station_Address":"Đối diện 693, đường Phạm Văn Chí, Quận 6"
    ,"Lat":10.738521
    ,"Long":106.635484
    ,"Polyline":"[106.63931274,10.74073982] ; [106.63548279,10.73852921] ; [106.63548279,10.73852062]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"4352"
    ,"Station_Code":"Q6 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Lý Chiêu Ho àng"
    ,"Station_Address":"156/1, đường Lý Chi êu Hoàng, Quận 6"
    ,"Lat":10.736966
    ,"Long":106.632775
    ,"Polyline":"[106.63548279,10.73852062] ; [106.63277435,10.73696613]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1586"
    ,"Station_Code":"Q6 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Bình Phú"
    ,"Station_Address":"94 Bis, đường Lý Chiêu Ho àng, Quận 6"
    ,"Lat":10.737361
    ,"Long":106.630216
    ,"Polyline":"[106.63277435,10.73696613] ; [106.63216400,10.73657036] ; [106.63021851,10.73736095]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1587"
    ,"Station_Code":"Q6 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Bình Phú"
    ,"Station_Address":"Chợ Bình Phú, đường Lý Chiêu Hoàng, Quận 6"
    ,"Lat":10.738816
    ,"Long":106.626534
    ,"Polyline":"[106.63021851,10.73736095] ; [106.62909698,10.73781490] ; [106.62785339,10.73823071] ; [106.62653351,10.73881626] ; [106.62653351,10.73881626]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1588"
    ,"Station_Code":"Q6 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Nhà hàng Đại Hỷ"
    ,"Station_Address":"156, đường Lý Chiêu Hoàng, Quận 6"
    ,"Lat":10.73909
    ,"Long":106.624503
    ,"Polyline":"[106.62653351,10.73881626] ; [106.62653351,10.73881626] ; [106.62566376,10.73914814] ; [106.62530518,10.73918533] ; [106.62449646,10.73910904] ; [106.62450409,10.73908997]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"806"
    ,"Station_Code":"Q6 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Lý Chiêu Ho àng"
    ,"Station_Address":"369/F31, đường An Dương Vương, Quận 6"
    ,"Lat":10.740239
    ,"Long":106.623715
    ,"Polyline":"[106.62450409,10.73908997] ; [106.62365723,10.73893738] ; [106.62371826,10.74023914]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1591"
    ,"Station_Code":"Q6 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ An Dư ơng Vương"
    ,"Station_Address":"648-650, đường  An Dương Vương, Quận 6"
    ,"Lat":10.743876
    ,"Long":106.623784
    ,"Polyline":"[106.62370300,10.74023914] ; [106.62377930,10.74334240]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường Kinh Dương Vương, Quận  Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62378693,10.74387646] ; [106.62378693,10.74511909] ; [106.62380981,10.74530411] ; [106.62394714,10.74541473] ; [106.62398529,10.74553585] ; [106.62392426,10.74567318] ; [106.62373352,10.74570942] ; [106.62352753,10.74556732] ; [106.62303162,10.74514580] ; [106.62247467,10.74474621]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62247467,10.74474621] ; [106.62148285,10.74386024] ; [106.62096405,10.74344349] ; [106.62039948,10.74309158] ; [106.62039948,10.74309158]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"4150"
    ,"Station_Code":"QBT 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"428, Kinh Dương Vương"
    ,"Station_Address":"428, đường Kinh Dương Vương, Quận Bình  Tân"
    ,"Lat":10.741383
    ,"Long":106.618377
    ,"Polyline":"[106.62039948,10.74309158] ; [106.61966705,10.74241066] ; [106.61837769,10.74138260]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61837770,10.74138260] ; [106.61824040,10.74123001] ; [106.61858370,10.74084473] ; [106.61933900,10.74151993] ; [106.61903440,10.74188333] ; [106.61765190,10.74070672] ; [106.61640350,10.73962760] ; [106.61653700,10.73948542] ; [106.61816350,10.74085304] ; [106.61831670,10.74070454]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến  xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"4149"
    ,"Station_Code":"QBT 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"49-51 (317), Kinh Dương Vương"
    ,"Station_Address":"49-51 (317), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743396
    ,"Long":106.62136
    ,"Polyline":"[106.61831665,10.74070454] ; [106.62136078,10.74339581]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.62136078,10.74339581] ; [106.62135315,10.74351692] ; [106.62223053,10.74420738] ; [106.62316132,10.74491882]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"761"
    ,"Station_Code":"Q6 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ An Dương Vương"
    ,"Station_Address":"421, đường An Dương Vương, Quận 6"
    ,"Lat":10.742985
    ,"Long":106.623602
    ,"Polyline":"[106.62316132,10.74491882] ; [106.62329865,10.74508762] ; [106.62360382,10.74521446] ; [106.62374878,10.74535656] ; [106.62367249,10.74315929] ; [106.62360382,10.74298477]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1589"
    ,"Station_Code":"Q6 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Lý Chiêu Hoàng"
    ,"Station_Address":"426, đường An Dương Vương, Quận 6"
    ,"Lat":10.740065
    ,"Long":106.623548
    ,"Polyline":"[106.62360382,10.74298477] ; [106.62355042,10.74006462]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1592"
    ,"Station_Code":"Q6 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà hàng Đ ại Hỷ"
    ,"Station_Address":"129, đường Lý Chiêu Hoàng, Quận 6"
    ,"Lat":10.738973
    ,"Long":106.624367
    ,"Polyline":"[106.62355042,10.74006462] ; [106.62362671,10.73891640] ; [106.62436676,10.73897266]"
    ,"Distance":"210"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1590"
    ,"Station_Code":"Q6 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trần Văn Ki ểu"
    ,"Station_Address":"99 , đường Lý Chiêu Hoàng, Quận 6"
    ,"Lat":10.738758
    ,"Long":106.626402
    ,"Polyline":"[106.62436676,10.73897266] ; [106.62436676,10.73897266] ; [106.62490845,10.73908520] ; [106.62551880,10.73916340] ; [106.62599945,10.73897457] ; [106.62629700,10.73884201] ; [106.62640381,10.73875809]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1593"
    ,"Station_Code":"Q6 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường THCS Ph ú Định"
    ,"Station_Address":"61, đường Lý Chi êu Hoàng, Quận 6"
    ,"Lat":10.737309
    ,"Long":106.630071
    ,"Polyline":"[106.62631989,10.73877621] ; [106.62896729,10.73777294]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"4607"
    ,"Station_Code":"Q6 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Lý Chiêu Hoàng"
    ,"Station_Address":"Đối diện 156/1 , đường Lý Chiêu Hoàng, Quận 6"
    ,"Lat":10.737114
    ,"Long":106.63322
    ,"Polyline":"[106.63007355,10.73730946] ; [106.63215637,10.73651791] ; [106.63321686,10.73711395]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1595"
    ,"Station_Code":"Q6 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cầu Phạm Văn Chí"
    ,"Station_Address":"713-715, đường Ph ạm Văn Chí, Quận 6"
    ,"Lat":10.738384
    ,"Long":106.635447
    ,"Polyline":"[106.63321686,10.73711395] ; [106.63437653,10.73784065] ; [106.63544464,10.73838425]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1594"
    ,"Station_Code":"Q6 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà máy rượu Bình Tây"
    ,"Station_Address":"621, đường Ph ạm Văn Chí, Quận 6"
    ,"Lat":10.740545
    ,"Long":106.639169
    ,"Polyline":"[106.63544464,10.73838425] ; [106.63582611,10.73859978] ; [106.63916779,10.74054527]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1596"
    ,"Station_Code":"Q6 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bình Tiên"
    ,"Station_Address":"483, đường Phạm Văn Chí, Quận 6"
    ,"Lat":10.741804
    ,"Long":106.641471
    ,"Polyline":"[106.63916779,10.74054527] ; [106.64147186,10.74180412]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1597"
    ,"Station_Code":"Q6 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Phạm Phú Thứ"
    ,"Station_Address":"333, đường Phạm Văn Chí, Quận 6"
    ,"Lat":10.744392
    ,"Long":106.645972
    ,"Polyline":"[106.64147186,10.74180412] ; [106.64597321,10.74439240]"
    ,"Distance":"570"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1607"
    ,"Station_Code":"Q6 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ban Chỉ huy  Quân sự Phường 4"
    ,"Station_Address":"117-181, đường Phạm Văn Chí, Quận 6"
    ,"Lat":10.745188
    ,"Long":106.647339
    ,"Polyline":"[106.64597321,10.74439240] ; [106.64597321,10.74439240] ; [106.64716339,10.74514008] ; [106.64733887,10.74518776] ; [106.64733887,10.74518776]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1598"
    ,"Station_Code":"Q6 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Ủy ban nhân dân Quận 6"
    ,"Station_Address":"81, đường Phạm Văn Chí, Quận 6"
    ,"Lat":10.746231
    ,"Long":106.649303
    ,"Polyline":"[106.64733887,10.74518776] ; [106.64820862,10.74564648] ; [106.64929962,10.74623108]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"4606"
    ,"Station_Code":"Q6 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bãi Sậy"
    ,"Station_Address":"22, đường Phạm Đình Hổ, Qu ận 6"
    ,"Lat":10.747523
    ,"Long":106.64955
    ,"Polyline":"[106.64929962,10.74623108] ; [106.64969635,10.74651051] ; [106.64959717,10.74702740] ; [106.64955139,10.74752331]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27, đường Th áp Mười, Quận 6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.64955139,10.74752331] ; [106.64955139,10.74752331] ; [106.64946747,10.74788666] ; [106.64937592,10.74861336] ; [106.64945221,10.74968338] ; [106.65228271,10.75021553] ; [106.65255737,10.75023174] ; [106.65255737,10.75023174]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"470"
    ,"Station_Code":"Q5 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"399, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754111
    ,"Long":106.656749
    ,"Polyline":"[106.65254211,10.75026989] ; [106.65338898,10.75043011] ; [106.65335846,10.75067997] ; [106.65332794,10.75109005] ; [106.65329742,10.75150013] ; [106.65325928,10.75164032] ; [106.65334320,10.75209045] ; [106.65357208,10.75275040] ; [106.65377808,10.75360012] ; [106.65442657,10.75372028] ; [106.65511322,10.75386047] ; [106.65672302,10.75415993]"
    ,"Distance":"794"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"279"
    ,"Station_Code":"Q5 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Bệnh viện Ch ợ Rẫy"
    ,"Station_Address":"Đối diện 59C, đường Thuận Kiều, Quận 5"
    ,"Lat":10.757109
    ,"Long":106.65839
    ,"Polyline":"[106.65674591,10.75411129] ; [106.65672302,10.75413895] ; [106.65850067,10.75454807] ; [106.65834045,10.75711060] ; [106.65838623,10.75710869]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1608"
    ,"Station_Code":"Q11 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"698, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.757636
    ,"Long":106.657387
    ,"Polyline":"[106.65838623,10.75710869] ; [106.65824890,10.75775719] ; [106.65738678,10.75763607]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1599"
    ,"Station_Code":"Q11 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"816, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.756951
    ,"Long":106.65412
    ,"Polyline":"[106.65738678,10.75763607] ; [106.65412140,10.75695133]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"896"
    ,"Station_Code":"Q11 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm Trần Quý - Tạ Uyên"
    ,"Station_Address":"114, đường Tạ Uyên, Quận 11"
    ,"Lat":10.758002
    ,"Long":106.653603
    ,"Polyline":"[106.65412140,10.75695133] ; [106.65415955,10.75699329] ; [106.65367126,10.75678253] ; [106.65360260,10.75800228] ; [106.65360260,10.75800228]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1610"
    ,"Station_Code":"Q11 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trần Quý"
    ,"Station_Address":"258, đường Trần Quý, Quận 11"
    ,"Lat":10.758298
    ,"Long":106.651901
    ,"Polyline":"[106.65360260,10.75800228] ; [106.65360260,10.75800228] ; [106.65354156,10.75864792] ; [106.65190125,10.75829792] ; [106.65190125,10.75829792]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1600"
    ,"Station_Code":"Q11 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nguyễn Th ị Nhỏ"
    ,"Station_Address":"36, đường Hàn Hải Nguyên, Quận 11"
    ,"Lat":10.757958
    ,"Long":106.650451
    ,"Polyline":"[106.65190125,10.75829792] ; [106.65135956,10.75814724] ; [106.65126801,10.75786781] ; [106.65045166,10.75795841]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1612"
    ,"Station_Code":"Q11 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Hàn Hải Nguyên"
    ,"Station_Address":"176 (190), đường Hàn Hải Nguy ên, Quận 11"
    ,"Lat":10.758295
    ,"Long":106.646118
    ,"Polyline":"[106.65045166,10.75795841] ; [106.65045166,10.75799751] ; [106.64891052,10.75797367] ; [106.64611816,10.75829506] ; [106.64611816,10.75829506]"
    ,"Distance":"480"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1601"
    ,"Station_Code":"Q11 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Điện lạnh Vi Thành"
    ,"Station_Address":"292, đường H àn Hải Nguyên, Quận 11"
    ,"Lat":10.758379
    ,"Long":106.644469
    ,"Polyline":"[106.64611816,10.75829506] ; [106.64604187,10.75825787] ; [106.64447021,10.75837898]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1677"
    ,"Station_Code":"Q11 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"THCS Lê Anh Xuân"
    ,"Station_Address":"382, đường Minh  Phụng, Quận 11"
    ,"Lat":10.759729
    ,"Long":106.64426
    ,"Polyline":"[106.64447021,10.75837898] ; [106.64396667,10.75841618] ; [106.64425659,10.75972939]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1680"
    ,"Station_Code":"Q11 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Đội Cung"
    ,"Station_Address":"470, đường Minh Phụng, Quận 11"
    ,"Lat":10.761849
    ,"Long":106.644592
    ,"Polyline":"[106.64420319,10.75973415] ; [106.64459229,10.76184940]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1679"
    ,"Station_Code":"Q11 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"công an P10"
    ,"Station_Address":"618, đường Minh Phụng, Quận 11"
    ,"Lat":10.763865
    ,"Long":106.644928
    ,"Polyline":"[106.64459229,10.76184940] ; [106.64492798,10.76386547]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1603"
    ,"Station_Code":"Q11 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường Ph ùng Hưng"
    ,"Station_Address":"240, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.763818
    ,"Long":106.642259
    ,"Polyline":"[106.64492798,10.76386547] ; [106.64492798,10.76386547] ; [106.64492798,10.76386547] ; [106.64498138,10.76438713] ; [106.64363098,10.76351738] ; [106.64315796,10.76323318] ; [106.64237976,10.76290131] ; [106.64219666,10.76290131] ; [106.64223480,10.76336479] ; [106.64229584,10.76383114] ; [106.64225769,10.76381779] ; [106.64225769,10.76381779]"
    ,"Distance":"517"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1029"
    ,"Station_Code":"Q11 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"40A, đường Hòa Bình, Quận 11"
    ,"Lat":10.767302
    ,"Long":106.641181
    ,"Polyline":"[106.64225769,10.76381779] ; [106.64231110,10.76602650] ; [106.64233398,10.76660633] ; [106.64248657,10.76670647] ; [106.64249420,10.76694298] ; [106.64232635,10.76700687] ; [106.64215851,10.76689529] ; [106.64118195,10.76730156]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1616"
    ,"Station_Code":"Q11 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Hòa Bình"
    ,"Station_Address":"72, đường Hòa Bình, Quận 11"
    ,"Lat":10.768496
    ,"Long":106.639137
    ,"Polyline":"[106.64118195,10.76730156] ; [106.64053345,10.76756477] ; [106.63979340,10.76801300] ; [106.63913727,10.76849556] ; [106.63913727,10.76849556]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1604"
    ,"Station_Code":"QTP 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Đầm Sen"
    ,"Station_Address":"45 (Đối diện công viên nước Đầm Sen), đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769367
    ,"Long":106.63707
    ,"Polyline":"[106.63913727,10.76849556] ; [106.63913727,10.76849556] ; [106.63863373,10.76860332] ; [106.63778687,10.76895618] ; [106.63738251,10.76910400] ; [106.63706970,10.76936722] ; [106.63706970,10.76936722]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1617"
    ,"Station_Code":"QTP 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chùa Huệ Quang"
    ,"Station_Address":"116, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769747
    ,"Long":106.635246
    ,"Polyline":"[106.63706970,10.76936722] ; [106.63706970,10.76936722] ; [106.63663483,10.76935196] ; [106.63597107,10.76957798] ; [106.63524628,10.76974678] ; [106.63524628,10.76974678]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1619"
    ,"Station_Code":"QTP 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã 4 Hòa  Bình"
    ,"Station_Address":"126, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.77
    ,"Long":106.633362
    ,"Polyline":"[106.63524628,10.76974678] ; [106.63524628,10.76974678] ; [106.63452148,10.76955223] ; [106.63336182,10.77000046] ; [106.63336182,10.77000046]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1621"
    ,"Station_Code":"QTP 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trung Tâm Mua Sắm"
    ,"Station_Address":"214, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.771277
    ,"Long":106.629044
    ,"Polyline":"[106.63330841,10.76984024] ; [106.63278961,10.77000999] ; [106.63179779,10.77029037] ; [106.63123322,10.77048969] ; [106.63047791,10.77079010.06.62935638] ; [10.77114964,106.62904358]"
    ,"Distance":"513"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1605"
    ,"Station_Code":"QTP 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"278, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.772361
    ,"Long":106.626106
    ,"Polyline":"[106.62904358,10.77127743] ; [106.62904358,10.77127743] ; [106.62904358,10.77126026] ; [106.62793732,10.77163887] ; [106.62633514,10.77220249] ; [106.62610626,10.77236080] ; [106.62610626,10.77236080]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1606"
    ,"Station_Code":"QTP 141"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã 4 bốn xã"
    ,"Station_Address":"314-316, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.773267
    ,"Long":106.6231
    ,"Polyline":"[106.62610626,10.77236080] ; [106.62310028,10.77326679]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1609"
    ,"Station_Code":"QTP 182"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"54 (445), đường Bình Long, Quận Tân Phú"
    ,"Lat":10.776197
    ,"Long":106.621689
    ,"Polyline":"[106.62310028,10.77326679] ; [106.62310028,10.77326679] ; [106.62221527,10.77363586] ; [106.62158203,10.77372074] ; [106.62147522,10.77621841] ; [106.62168884,10.77619743] ; [106.62168884,10.77619743]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1623"
    ,"Station_Code":"QTP 183"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Đỗ Bí"
    ,"Station_Address":"156, đường Bình Long, Quận Tân Phú"
    ,"Lat":10.780313
    ,"Long":106.6203
    ,"Polyline":"[106.62143707,10.77616024] ; [106.62138367,10.77657986] ; [106.62127686,10.77694988] ; [106.62117004,10.77731991] ; [106.62088776,10.77826023] ; [106.62042236,10.77966976] ; [106.62023163,10.78028965]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1626"
    ,"Station_Code":"QTP 184"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Nguyễn S ơn"
    ,"Station_Address":"220B-C, đường Bình Long , Quận Tân Phú"
    ,"Lat":10.784101
    ,"Long":106.61924
    ,"Polyline":"[106.62030029,10.78031254] ; [106.61923981,10.78410149]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1611"
    ,"Station_Code":"QTP 185"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Phú Thọ Hòa"
    ,"Station_Address":"333, đường Bình Long, Quận Tân Phú"
    ,"Lat":10.786708
    ,"Long":106.618011
    ,"Polyline":"[106.61923981,10.78410053] ; [106.61923981,10.78410149] ; [106.61896515,10.78401756] ; [106.61856842,10.78536606] ; [106.61801147,10.78670788] ; [106.61801147,10.78670788]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1614"
    ,"Station_Code":"QTP 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"214 , đường Lê Thúc Hoạch, Quận Tân Phú"
    ,"Lat":10.788112
    ,"Long":106.61882
    ,"Polyline":"[106.61801147,10.78670788] ; [106.61801147,10.78670788] ; [106.61741638,10.78803825] ; [106.61882019,10.78811169] ; [106.61882019,10.78811169]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"29"
    ,"Station_Id":"1560"
    ,"Station_Code":"BX54"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Cư xá Nhiêu  Lộc"
    ,"Station_Address":"Bến xe buýt Cư xá Nhiêu Lộc, đường Lê Thúc Hoạch, Quận Tân Phú"
    ,"Lat":10.788043
    ,"Long":106.621895
    ,"Polyline":"[106.61882019,10.78811169] ; [106.62104034,10.78830147] ; [106.62125397,10.78806496] ; [106.62185669,10.78772736] ; [106.62242126,10.78753757] ; [106.62248230,10.78771114] ; [106.62195587,10.78790665] ; [106.62189484,10.78804302]"
    ,"Distance":"519"
  }]