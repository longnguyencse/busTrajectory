export const Route61 =[

  {
     "Route_Id":"61"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận  12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"976"
    ,"Station_Code":"Q12 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đá hoa cương Hoà Thắng"
    ,"Station_Address":"96/2, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.86193
    ,"Long":106.675143
    ,"Polyline":"[106.67832947,10.86166954] ; [106.67665863,10.86178017] ; [106.67514038,10.86182976]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"964"
    ,"Station_Code":"Q12 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Tô Ngọc Vân"
    ,"Station_Address":"972, đường Quốc l ộ 1A, Quận 12"
    ,"Lat":10.861904
    ,"Long":106.671935
    ,"Polyline":"[106.67514038,10.86182976] ; [106.67407227,10.86184025] ; [106.67252350,10.86182022]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"937"
    ,"Station_Code":"Q12 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây xăng Thạnh Xuân"
    ,"Station_Address":"Cây xăng Thạnh Xuân, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861577
    ,"Long":106.671882
    ,"Polyline":"[106.67252350,10.86182022] ; [106.67125702,10.86178970] ; [106.67125702,10.86166000] ; [106.67188263,10.86166954]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"938"
    ,"Station_Code":"Q12 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu Cả Bốn"
    ,"Station_Address":"109, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.861619
    ,"Long":106.674446
    ,"Polyline":"[106.67188263,10.86166954] ; [106.67445374,10.86170006]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"944"
    ,"Station_Code":"Q12 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Đối diện Bx Ngã tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861472
    ,"Long":106.678078
    ,"Polyline":"[106.67445374,10.86170006] ; [106.67534637,10.86168957] ; [106.67703247,10.86161041] ; [106.67807770,10.86155033]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"213"
    ,"Station_Code":"Q12 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã tư Ga"
    ,"Station_Address":"154, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.857331
    ,"Long":106.679907
    ,"Polyline":"[106.67807770,10.86155033] ; [106.67893982,10.86147976] ; [106.67906189,10.86143017] ; [106.67913818,10.86135006] ; [106.67925262,10.86112022] ; [106.67916107,10.85962963] ; [106.67913818,10.85900974] ; [106.67917633,10.85890007] ; [106.67925262,10.85879993] ; [106.67945862,10.85869980] ; [106.67958832,10.85865974] ; [106.67976379,10.85851002] ; [106.67980957,10.85840988] ; [106.67986298,10.85826969] ; [106.67980957,10.85787010.06.67960358] ; [10.85624027,106.67935181]"
    ,"Distance":"946"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"209"
    ,"Station_Code":"QGV 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu An Lộc"
    ,"Station_Address":"521 , đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.84862
    ,"Long":106.678535
    ,"Polyline":"[106.67935181,10.85433960] ; [106.67900848,10.85216999] ; [106.67874908,10.85031033] ; [106.67865753,10.84939003] ; [106.67861176,10.84860992]"
    ,"Distance":"643"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"210"
    ,"Station_Code":"QGV 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"451, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.847015
    ,"Long":106.67826
    ,"Polyline":"[106.67861176,10.84860992] ; [106.67855072,10.84794998] ; [106.67851257,10.84753990] ; [106.67839813,10.84704018] ; [106.67839050,10.84700012]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"212"
    ,"Station_Code":"QGV 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Bưu điện An Nhơn"
    ,"Station_Address":"357, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.843833
    ,"Long":106.677139
    ,"Polyline":"[106.67839050,10.84700012] ; [106.67726135,10.84381962]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2897"
    ,"Station_Code":"QGV 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ An Nhơn"
    ,"Station_Address":"257-263, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.841104
    ,"Long":106.677856
    ,"Polyline":"[106.67726135,10.84381962] ; [106.67659760,10.84193993] ; [106.67685699,10.84177017] ; [106.67726135,10.84150028] ; [106.67749786,10.84134960] ; [106.67772675,10.84125042] ; [106.67790222,10.84117031]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1760"
    ,"Station_Code":"QGV 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường văn thư lưu trữ"
    ,"Station_Address":"Đối diện 210, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.837426
    ,"Long":106.680545
    ,"Polyline":"[106.67790222,10.84117031] ; [106.67826080,10.84090042] ; [106.67858124,10.84058952] ; [106.67880249,10.84029961] ; [106.67900085,10.84002018] ; [106.67926025,10.83959961] ; [106.67948914,10.83930016] ; [106.67971802,10.83905029] ; [106.68009949,10.83852959] ; [106.68026733,10.83827019] ; [106.68051910,10.83769989]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2898"
    ,"Station_Code":"QGV 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Coop Mark Phan Văn Trị"
    ,"Station_Address":"19-21, đường Lê Đức Thọ, Qu ận Gò Vấp"
    ,"Lat":10.830213
    ,"Long":106.68201
    ,"Polyline":"[106.68051910,10.83769989] ; [106.68087006,10.83687973] ; [106.68106079,10.83631992] ; [106.68116760,10.83582973]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2901"
    ,"Station_Code":"QGV 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Vòng xoay Nguyễn Huy Điển"
    ,"Station_Address":"78, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.832294
    ,"Long":106.682702
    ,"Polyline":"[106.68116760,10.83582973] ; [106.68144989,10.83495998] ; [106.68170929,10.83436966] ; [106.68206787,10.83368015] ; [106.68257141,10.83250999] ; [106.68260193,10.83242035]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2903"
    ,"Station_Code":"QGV 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Khách sạn Lavie"
    ,"Station_Address":"93, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.835161
    ,"Long":106.681269
    ,"Polyline":"[106.68260193,10.83242035] ; [106.68266296,10.83218956] ; [106.68264008,10.83218002] ; [106.68260956,10.83215046] ; [106.68260193,10.83211994] ; [106.68260956,10.83203983] ; [106.68263245,10.83199978] ; [106.68251038,10.83164978] ; [106.68215942,10.83049965] ; [106.68209839,10.83030033]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2770"
    ,"Station_Code":"QGV 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"PCCC Quận Gò Vấp"
    ,"Station_Address":"771, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.828364
    ,"Long":106.684939
    ,"Polyline":"[106.68209839,10.83030033] ; [106.68182373,10.82942963] ; [106.68240356,10.82925034] ; [106.68359375,10.82886982] ; [106.68508911,10.82835960] ; [106.68566132,10.82816982]"
    ,"Distance":"544"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2767"
    ,"Station_Code":"QGV 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Caphê Cát Đằng"
    ,"Station_Address":"689, đường Phan  Văn Trị, Quận Gò Vấp"
    ,"Lat":10.827421
    ,"Long":106.687996
    ,"Polyline":"[106.68566132,10.82816982] ; [106.68710327,10.82771015] ; [106.68771362,10.82750034] ; [106.68808746,10.82736969] ; [106.68821716,10.82728958] ; [106.68849182,10.82703972]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1766"
    ,"Station_Code":"QGV 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bãi hậu cần số 1"
    ,"Station_Address":"439, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.823559
    ,"Long":106.692165
    ,"Polyline":"[106.68849182,10.82703972] ; [106.69226074,10.82355022]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1767"
    ,"Station_Code":"QBTH 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chùa Giác Quang"
    ,"Station_Address":"189, đường Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.819749
    ,"Long":106.694375
    ,"Polyline":"[106.69226074,10.82355022] ; [106.69307709,10.82279015] ; [106.69338226,10.82236004] ; [106.69344330,10.82225037] ; [106.69354248,10.82186031] ; [106.69362640,10.82159042] ; [106.69390869,10.82096004] ; [106.69436646,10.81991005] ; [106.69441986,10.81974983]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1769"
    ,"Station_Code":"QBTH 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"235, đường Phan  Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.813695
    ,"Long":106.695217
    ,"Polyline":"[106.69441986,10.81974983] ; [106.69467163,10.81892967] ; [106.69480133,10.81857967] ; [106.69509125,10.81801033] ; [106.69523621,10.81762981] ; [106.69529724,10.81739044] ; [106.69529724,10.81711960] ; [106.69528961,10.81688023] ; [106.69519043,10.81626034] ; [106.69519043,10.81604004] ; [106.69522095,10.81577969] ; [106.69523621,10.81509018] ; [106.69525146,10.81369019]"
    ,"Distance":"693"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2746"
    ,"Station_Code":"QBTH 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã 5 Bình Hòa"
    ,"Station_Address":"170L, đường N ơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.811745
    ,"Long":106.695925
    ,"Polyline":"[106.69525146,10.81369019] ; [106.69528961,10.81313992] ; [106.69526672,10.81250954] ; [106.69522858,10.81215000] ; [106.69519043,10.81198978] ; [106.69518280,10.81180000] ; [106.69519043,10.81167984] ; [106.69522858,10.81159019] ; [106.69550323,10.81120014] ; [106.69557190,10.81130981] ; [106.69586945,10.81173992]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2748"
    ,"Station_Code":"QBTH 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Siêu thị  Satra Food"
    ,"Station_Address":"244-246, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.813811
    ,"Long":106.69754
    ,"Polyline":"[106.69586945,10.81173992] ; [106.69635010,10.81237984] ; [106.69734955,10.81363964] ; [106.69747925,10.81383038]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2747"
    ,"Station_Code":"QBTH 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà văn hóa Lao Động"
    ,"Station_Address":"290, đường N ơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.816245
    ,"Long":106.697931
    ,"Polyline":"[106.69747925,10.81383038] ; [106.69776917,10.81431007] ; [106.69783783,10.81455040] ; [106.69788361,10.81472969] ; [106.69789124,10.81482983] ; [106.69790649,10.81536961] ; [106.69789124,10.81577969] ; [106.69786835,10.81622028]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2750"
    ,"Station_Code":"QBTH 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường Trung  cấp xây dựng Tp. HCM"
    ,"Station_Address":"380, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.81889
    ,"Long":106.70078
    ,"Polyline":"[106.69786835,10.81622028] ; [106.69785309,10.81661034] ; [106.69780731,10.81684017] ; [106.69779205,10.81711960] ; [106.69795227,10.81756020] ; [106.69806671,10.81779003] ; [106.69841766,10.81812954] ; [106.69889069,10.81849957] ; [106.69914246,10.81865025] ; [106.69944000,10.81888008] ; [106.69954681,10.81892014] ; [106.69966125,10.81896019] ; [106.69985962,10.81896019] ; [106.70043945,10.81890965] ; [106.70059204,10.81892014]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2749"
    ,"Station_Code":"QBTH 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"UBND Phường 13, Quận Bình Thạnh"
    ,"Station_Address":"450-452, đường Nơ Trang Long, Quận Bình Th ạnh"
    ,"Lat":10.819697
    ,"Long":106.70327
    ,"Polyline":"[106.70059204,10.81892014] ; [106.70149231,10.81917953] ; [106.70265961,10.81951046] ; [106.70316315,10.81966019]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2899"
    ,"Station_Code":"QBTH 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã Tư Nơ Trang Long"
    ,"Station_Address":"225, đường Nguyễn  Xí, Quận Bình Thạnh"
    ,"Lat":10.81859
    ,"Long":106.704685
    ,"Polyline":"[106.70316315,10.81966019] ; [106.70369720,10.81989002] ; [106.70394897,10.82001972] ; [106.70403290,10.82005978] ; [106.70416260,10.81962013] ; [106.70442200,10.81914043] ; [106.70478821,10.81863022]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2900"
    ,"Station_Code":"QBTH 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà Sách Miền Đông"
    ,"Station_Address":"79/5B, đường  Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.815729
    ,"Long":106.707357
    ,"Polyline":"[106.70478821,10.81863022] ; [106.70509338,10.81822968] ; [106.70527649,10.81803036] ; [106.70561218,10.81770039] ; [106.70610046,10.81715965] ; [106.70642090,10.81676960] ; [106.70733643,10.81573009]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2905"
    ,"Station_Code":"QBTH 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã Tư Đinh Bộ Lĩnh"
    ,"Station_Address":"153, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.813679
    ,"Long":106.709127
    ,"Polyline":"[106.70733643,10.81573009] ; [106.70915985,10.81371975]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1408"
    ,"Station_Code":"QBTH 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã năm Liệt Sĩ"
    ,"Station_Address":"222/4 Ter, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.81204
    ,"Long":106.710624
    ,"Polyline":"[106.70915985,10.81371975] ; [106.71063995,10.81206989]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Th ạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71063995,10.81206989] ; [106.71228790,10.81021976] ; [106.71235657,10.81079960]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71235657,10.81079960] ; [106.71272278,10.81385994]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71272278,10.81385994] ; [106.71285248,10.81464291] ; [106.71298218,10.81557083] ; [106.71313477,10.81710911] ; [106.71311951,10.81738281] ; [106.71269226,10.81735134] ; [106.71208191,10.81720448] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71052551,10.81531811] ; [106.71003723,10.81440067] ; [106.70980072,10.81379986] ; [106.71015930,10.81397915] ; [106.71044922,10.81452751] ; [106.71067810,10.81497002] ; [106.71129608,10.81473255]"
    ,"Distance":"1223"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2890"
    ,"Station_Code":"QBTH 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã Tư Đinh Bộ Lĩnh"
    ,"Station_Address":"134, đường Nguyễn Xí, Quận  Bình Thạnh"
    ,"Lat":10.813647
    ,"Long":106.709282
    ,"Polyline":"[106.71073914,10.81503010.06.71019745] ; [10.81396961,106.71009827] ; [10.81390953,106.70989227] ; [10.81398964,106.70986176] ; [10.81394005,106.70954132] ; [10.81330013,106.70928192]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2893"
    ,"Station_Code":"QBTH 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nhà Sách Miền Đông"
    ,"Station_Address":"Đối diện 79/5B, đường Nguyễn Xí, Quận  Bình Thạnh"
    ,"Lat":10.81585
    ,"Long":106.707367
    ,"Polyline":"[106.70928192,10.81359959] ; [106.70729065,10.81579018]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2895"
    ,"Station_Code":"QBTH 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã Tư Nơ Trang Long"
    ,"Station_Address":"292, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.818669
    ,"Long":106.704739
    ,"Polyline":"[106.70729065,10.81579018] ; [106.70642090,10.81676960] ; [106.70610046,10.81715965] ; [106.70548248,10.81783009] ; [106.70513153,10.81818962] ; [106.70481110,10.81859970]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2550"
    ,"Station_Code":"QBTH 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"UBND Phường 13, Quận Bình Thạnh"
    ,"Station_Address":"363, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.819649
    ,"Long":106.702915
    ,"Polyline":"[106.70481110,10.81859970] ; [106.70442200,10.81914043] ; [106.70416260,10.81962013] ; [106.70403290,10.82005978] ; [106.70394897,10.82001972] ; [106.70369720,10.81989002] ; [106.70307922,10.81962967] ; [106.70282745,10.81956005]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2541"
    ,"Station_Code":"QBTH 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Trung cấp xây dựng Tp. HCM"
    ,"Station_Address":"327, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.818959
    ,"Long":106.700345
    ,"Polyline":"[106.70282745,10.81956005] ; [106.70160675,10.81921959] ; [106.70097351,10.81900978] ; [106.70065308,10.81892967] ; [106.70053101,10.81890011] ; [106.70043945,10.81890965] ; [106.70030212,10.81892014]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2543"
    ,"Station_Code":"QBTH 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhà văn hóa Lao Động"
    ,"Station_Address":"217, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.816113
    ,"Long":106.69784
    ,"Polyline":"[106.70030212,10.81892014] ; [106.69985962,10.81896019] ; [106.69966125,10.81896019] ; [106.69954681,10.81892014] ; [106.69944000,10.81888008] ; [106.69914246,10.81865025] ; [106.69889069,10.81849957] ; [106.69841766,10.81812954] ; [106.69806671,10.81779003] ; [106.69795227,10.81756020] ; [106.69779205,10.81711960] ; [106.69780731,10.81684017] ; [106.69785309,10.81661034] ; [106.69786835,10.81610012]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2545"
    ,"Station_Code":"QBTH 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Siêu thị Satra Food"
    ,"Station_Address":"167, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.813605
    ,"Long":106.697266
    ,"Polyline":"[106.69786835,10.81610012] ; [106.69790649,10.81536961] ; [106.69788361,10.81472969] ; [106.69776917,10.81431007] ; [106.69734955,10.81363964] ; [106.69725800,10.81352997]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2552"
    ,"Station_Code":"QBTH 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã Năm Bình Hòa"
    ,"Station_Address":"131, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.811719
    ,"Long":106.69578
    ,"Polyline":"[106.69725800,10.81352997] ; [106.69635010,10.81237984] ; [106.69580078,10.81165028]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1654"
    ,"Station_Code":"QBTH 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"182B/2, đường Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.812722
    ,"Long":106.695343
    ,"Polyline":"[106.69580078,10.81165028] ; [106.69557190,10.81130981] ; [106.69550323,10.81120014] ; [106.69522858,10.81159019] ; [106.69519043,10.81167984] ; [106.69518280,10.81180000] ; [106.69519043,10.81198978] ; [106.69522858,10.81215000] ; [106.69525146,10.81235981] ; [106.69526672,10.81250954] ; [106.69526672,10.81272030]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1652"
    ,"Station_Code":"QBTH 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chùa Giác Quang"
    ,"Station_Address":"342, đường Phan Văn Trị, Quận Bình Th ạnh"
    ,"Lat":10.819601
    ,"Long":106.694536
    ,"Polyline":"[106.69526672,10.81272030] ; [106.69528961,10.81313992] ; [106.69525146,10.81365967] ; [106.69525146,10.81478024] ; [106.69522858,10.81560040] ; [106.69522095,10.81571007] ; [106.69519043,10.81614017] ; [106.69522858,10.81649017] ; [106.69525909,10.81669044] ; [106.69529724,10.81700039] ; [106.69531250,10.81725979] ; [106.69526672,10.81750965] ; [106.69519043,10.81777000] ; [106.69486237,10.81846046] ; [106.69474030,10.81871986] ; [106.69458771,10.81917000] ; [106.69448853,10.81949043]"
    ,"Distance":"771"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"539"
    ,"Station_Code":"QGV 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bãi hậu cần số 1"
    ,"Station_Address":"Đối diện 439, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.82389
    ,"Long":106.69202
    ,"Polyline":"[106.69448853,10.81949043] ; [106.69436646,10.81991005] ; [106.69415283,10.82040977] ; [106.69406128,10.82061958] ; [106.69364929,10.82153988] ; [106.69357300,10.82178020] ; [106.69345093,10.82215023] ; [106.69341278,10.82229996] ; [106.69316101,10.82269955] ; [106.69277191,10.82308006] ; [106.69232941,10.82347965] ; [106.69180298,10.82396984]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2729"
    ,"Station_Code":"QGV 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã Tư  Nguyễn Thái Sơn"
    ,"Station_Address":"12, đư ờng Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.827015
    ,"Long":106.68864
    ,"Polyline":"[106.69180298,10.82396984] ; [106.68917847,10.82639027]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2731"
    ,"Station_Code":"QGV 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"PCCC Quận Gò Vấp"
    ,"Station_Address":"16B, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.828654
    ,"Long":106.68474
    ,"Polyline":"[106.68917847,10.82639027] ; [106.68834686,10.82717037] ; [106.68817139,10.82732010.06.68795013] ; [10.82742977,106.68668365] ; [10.82783985,106.68498993]"
    ,"Distance":"519"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2891"
    ,"Station_Code":"QGV 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Khách sạn Lavie"
    ,"Station_Address":"146 (đối diện 93), đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.835392
    ,"Long":106.681398
    ,"Polyline":"[106.68498993,10.82839012] ; [106.68359375,10.82886982] ; [106.68240356,10.82925034] ; [106.68182373,10.82942963] ; [106.68197632,10.82993031]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2894"
    ,"Station_Code":"QGV 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Vòng xoay Nguyễn Huy Điển"
    ,"Station_Address":"45, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.832684
    ,"Long":106.682423
    ,"Polyline":"[106.68197632,10.82993031] ; [106.68263245,10.83199978] ; [106.68260193,10.83209038] ; [106.68260956,10.83215046] ; [106.68266296,10.83218956] ; [106.68253326,10.83259964]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2892"
    ,"Station_Code":"QGV 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Coop Mark Phan Văn Trị"
    ,"Station_Address":"Đối diện 19-21 (543), đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.830113
    ,"Long":106.682122
    ,"Polyline":"[106.68253326,10.83259964] ; [106.68206787,10.83368015] ; [106.68170929,10.83436966] ; [106.68144989,10.83495998] ; [106.68115997,10.83586025] ; [106.68112946,10.83600998]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"1657"
    ,"Station_Code":"QGV 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường Văn Thư lưu trữ"
    ,"Station_Address":"214, đường Lê Đức Thọ, Qu ận Gò Vấp"
    ,"Lat":10.837026
    ,"Long":106.68091
    ,"Polyline":"[106.68112946,10.83600998] ; [106.68106079,10.83631992] ; [106.68096161,10.83662033] ; [106.68067932,10.83732033] ; [106.68058777,10.83753014]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"2896"
    ,"Station_Code":"QGV 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ An Nhơn"
    ,"Station_Address":"340, đường Lê Đức  Thọ, Quận Gò Vấp"
    ,"Lat":10.841172
    ,"Long":106.678099
    ,"Polyline":"[106.68058777,10.83753014] ; [106.68026733,10.83827019] ; [106.68009949,10.83852959] ; [106.67971802,10.83905029] ; [106.67948914,10.83930016] ; [106.67926025,10.83959961] ; [106.67900085,10.84002018] ; [106.67880249,10.84029961] ; [106.67858124,10.84058952] ; [106.67826080,10.84090042] ; [106.67799377,10.84111023]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"72"
    ,"Station_Code":"QGV 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã tư An Nhơn"
    ,"Station_Address":"388, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.842342
    ,"Long":106.676903
    ,"Polyline":"[106.67799377,10.84111023] ; [106.67784882,10.84121037] ; [106.67772675,10.84125042] ; [106.67749786,10.84134960] ; [106.67726135,10.84150028] ; [106.67685699,10.84177017] ; [106.67659760,10.84193993] ; [106.67671204,10.84226036]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"64"
    ,"Station_Code":"QGV 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"530, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.846894
    ,"Long":106.678512
    ,"Polyline":"[106.67671204,10.84226036] ; [106.67819214,10.84642029] ; [106.67835236,10.84691048]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"66"
    ,"Station_Code":"QGVT111"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu An  Lộc"
    ,"Station_Address":"604, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.849006
    ,"Long":106.678749
    ,"Polyline":"[106.67835236,10.84691048] ; [106.67851257,10.84753990] ; [106.67855835,10.84811020] ; [106.67864227,10.84901047]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"73"
    ,"Station_Code":"Q12 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà hàng Bến Xưa"
    ,"Station_Address":"42, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.852642
    ,"Long":106.679285
    ,"Polyline":"[106.67864227,10.84901047] ; [106.67865753,10.84939003] ; [106.67874908,10.85031033] ; [106.67893982,10.85177994]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"61"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":"[106.67893982,10.85177994] ; [106.67929840,10.85394001] ; [106.67948914,10.85542011] ; [106.67980957,10.85789967] ; [106.68025208,10.86151981] ; [106.68048859,10.86376953] ; [106.68048859,10.86413002] ; [106.68067932,10.86421967] ; [106.68080139,10.86425018] ; [106.68158722,10.86421967] ; [106.68174744,10.86417961] ; [106.68189240,10.86406994] ; [106.68192291,10.86398983] ; [106.68193054,10.86382961] ; [106.68183899,10.86297035] ; [106.68173218,10.86184978] ; [106.68166351,10.86168957] ; [106.68161011,10.86161995] ; [106.68153381,10.86155033] ; [106.68129730,10.86145020] ; [106.68041992,10.86151028] ; [106.67832947,10.86166954]"
    ,"Distance":"2188"
  }]