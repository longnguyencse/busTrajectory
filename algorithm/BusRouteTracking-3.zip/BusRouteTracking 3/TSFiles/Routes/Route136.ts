export const Route136 =[

  {
     "Route_Id":"136"
    ,"Station_Id":"890"
    ,"Station_Code":"BX 60"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Chợ Đầu mối Bình Điền"
    ,"Station_Address":"ĐẦU BẾN CHỢ ĐM BÌNH ĐIỀN,  đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.7024
    ,"Long":106.608665
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"893"
    ,"Station_Code":"HBC 451"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Công ty bất động sản"
    ,"Station_Address":"Công ty bất động sản, đường  Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698684
    ,"Long":106.609113
    ,"Polyline":"[106.60823822,10.70228958] ; [106.60803223,10.70302963] ; [106.60791779,10.70298958] ; [106.60826874,10.70178986] ; [106.60910797,10.69869041]"
    ,"Distance":"594"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"817"
    ,"Station_Code":"HBC 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm thu  phí"
    ,"Station_Address":"Cột điện 291, đường Nguyễn  Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.694493
    ,"Long":106.613388
    ,"Polyline":"[106.60910797,10.69869041] ; [106.60958862,10.69699001] ; [106.60984802,10.69610023] ; [106.60990906,10.69583988] ; [106.61019135,10.69478989] ; [106.61032867,10.69449997] ; [106.61045074,10.69396019] ; [106.61045074,10.69394016] ; [106.61186981,10.69433022] ; [106.61483002,10.69515038]"
    ,"Distance":"1047"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"814"
    ,"Station_Code":"HBC 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Cần Giuộc"
    ,"Station_Address":"Cột điện 277, đường Nguyễn Văn Linh,  Huyện Bình Chánh"
    ,"Lat":10.696591
    ,"Long":106.620603
    ,"Polyline":"[106.61483002,10.69515038] ; [106.61888123,10.69624043]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"818"
    ,"Station_Code":"HBC 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu Sập"
    ,"Station_Address":"Cột điện 258, đường Nguyễn Văn Linh, Huyện Bình Ch ánh"
    ,"Lat":10.698183
    ,"Long":106.626692
    ,"Polyline":"[106.61888123,10.69624043] ; [106.62425995,10.69769955]"
    ,"Distance":"610"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"816"
    ,"Station_Code":"HBC 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Kim Hằng"
    ,"Station_Address":"Cột  điện 240, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.700144
    ,"Long":106.631413
    ,"Polyline":"[106.62425995,10.69769955] ; [106.62719727,10.69849968] ; [106.62834930,10.69884968] ; [106.62866211,10.69896984]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"820"
    ,"Station_Code":"HBC 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trịnh Quang Nghị"
    ,"Station_Address":"Cột điện 230, đường Nguyễn Văn Linh, Huy ện Bình Chánh"
    ,"Lat":10.702237
    ,"Long":106.634218
    ,"Polyline":"[106.62866211,10.69896984] ; [106.62963867,10.69937038] ; [106.63060760,10.69983006] ; [106.63160706,10.70046043] ; [106.63188171,10.70067024]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"819"
    ,"Station_Code":"HBC 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Qua Trịnh Quang Nghị"
    ,"Station_Address":"Cột điện 213 , đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.705494
    ,"Long":106.638354
    ,"Polyline":"[106.63188171,10.70067024] ; [106.63288116,10.70141983] ; [106.63604736,10.70390034]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"822"
    ,"Station_Code":"HBC 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Khu dân  cư 13A"
    ,"Station_Address":"Cột điện 189, đ ường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.709337
    ,"Long":106.643343
    ,"Polyline":"[106.63604736,10.70390034] ; [106.64292908,10.70925999]"
    ,"Distance":"960"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"821"
    ,"Station_Code":"HBC 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Cầu Bà  Lớn"
    ,"Station_Address":"Cột điện 175, đường  Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.711382
    ,"Long":106.645961
    ,"Polyline":"[106.64292908,10.70925999] ; [106.64530182,10.71109962]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"824"
    ,"Station_Code":"HBC 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"KĐT H ạnh Phúc"
    ,"Station_Address":"Cột điện 158, đư ờng Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.713791
    ,"Long":106.648997
    ,"Polyline":"[106.64530182,10.71109962] ; [106.64691925,10.71234035] ; [106.64753723,10.71282959] ; [106.64840698,10.71350002] ; [106.64909363,10.71405029] ; [106.64993286,10.71471024]"
    ,"Distance":"646"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"823"
    ,"Station_Code":"HBC 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Quốc l ộ 50"
    ,"Station_Address":"Cột điện 137, đường  Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.717971
    ,"Long":106.654356
    ,"Polyline":"[106.64993286,10.71471024] ; [106.65318298,10.71724987]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2247"
    ,"Station_Code":"HBC 219"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn  Văn Linh"
    ,"Station_Address":"B17/24, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.720848
    ,"Long":106.655837
    ,"Polyline":"[106.65318298,10.71724987] ; [106.65573120,10.71928978] ; [106.65572357,10.71977997] ; [106.65579987,10.72247028] ; [106.65580750,10.72274017]"
    ,"Distance":"743"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2244"
    ,"Station_Code":"HBC 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Giáo xứ Bình Hưng"
    ,"Station_Address":"A18 /16, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.724923
    ,"Long":106.655944
    ,"Polyline":"[106.65580750,10.72274017] ; [106.65583038,10.72443008] ; [106.65590668,10.72694969] ; [106.65593719,10.72741985]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2246"
    ,"Station_Code":"HBC 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm x ăng SaiGon Petro"
    ,"Station_Address":"A24/20B , đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.7277
    ,"Long":106.656089
    ,"Polyline":"[106.65593719,10.72741985] ; [106.65599823,10.72928047]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2249"
    ,"Station_Code":"Q8 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bến xe  Quận 8"
    ,"Station_Address":"407, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733134
    ,"Long":106.656239
    ,"Polyline":"[106.65599823,10.72928047] ; [106.65608978,10.73266029] ; [106.65611267,10.73299026]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2248"
    ,"Station_Code":"HBC 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Công an B ình Hưng"
    ,"Station_Address":"A27/13, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.730905
    ,"Long":106.656105
    ,"Polyline":"[106.65611267,10.73299026] ; [106.65609741,10.73313046] ; [106.65614319,10.73344994]"
    ,"Distance":"51"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"502"
    ,"Station_Code":"Q8 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bùi Minh  Trực"
    ,"Station_Address":"193, đường Quốc l ộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656346
    ,"Polyline":"[106.65614319,10.73344994] ; [106.65619659,10.73571968]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"499"
    ,"Station_Code":"Q8 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cầu Nhị Thiên Đường"
    ,"Station_Address":"81, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738769
    ,"Long":106.656427
    ,"Polyline":"[106.65619659,10.73571968] ; [106.65628052,10.73875046]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"542"
    ,"Station_Code":"Q8 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"487, đường Tùng Thi ện Vương, Quận 8"
    ,"Lat":10.744513
    ,"Long":106.656802
    ,"Polyline":"[106.65628052,10.73875046] ; [106.65628815,10.73904037] ; [106.65638733,10.74053001] ; [106.65637970,10.74079990] ; [106.65631866,10.74100971] ; [106.65621948,10.74125004] ; [106.65576935,10.74242020] ; [106.65560913,10.74285984] ; [106.65556335,10.74310970] ; [106.65556335,10.74341011] ; [106.65563202,10.74365044] ; [106.65579987,10.74396992] ; [106.65583801,10.74407959] ; [106.65602112,10.74423981] ; [106.65621185,10.74433994] ; [106.65647888,10.74448013]"
    ,"Distance":"699"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"501"
    ,"Station_Code":"Q8 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Xóm Củi"
    ,"Station_Address":"337, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.746073
    ,"Long":106.659763
    ,"Polyline":"[106.65647888,10.74448013] ; [106.65854645,10.74563980] ; [106.65904999,10.74584961] ; [106.65960693,10.74612045]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bưu đi ện Quận 5"
    ,"Station_Address":"14-16, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65960693,10.74612045] ; [106.66031647,10.74646378] ; [106.66056061,10.74690628] ; [106.66063690,10.74810791] ; [106.66034698,10.74942493] ; [106.66010284,10.75022602] ; [106.66133881,10.75095367] ; [106.66150665,10.75102234] ; [106.66149902,10.75124359] ; [106.66106415,10.75104809] ; [106.66050720,10.75070095] ; [106.66017914,10.75053692] ; [106.65981293,10.75057983] ; [106.65956116,10.75064754] ; [106.65933228,10.75076962] ; [106.65918732,10.75097466] ; [106.65914154,10.75135994]"
    ,"Distance":"1054"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.65914154,10.75135994] ; [106.65905762,10.75183964] ; [106.65895081,10.75201035] ; [106.65892792,10.75181961] ; [106.65898895,10.75139046]"
    ,"Distance":"146"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"138"
    ,"Station_Code":"Q5 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Hải Th ượng Lãn Ông"
    ,"Station_Address":"210-212, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750948
    ,"Long":106.658358
    ,"Polyline":"[106.65898895,10.75139046] ; [106.65905762,10.75084972] ; [106.65836334,10.75088024]"
    ,"Distance":"137"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"139"
    ,"Station_Code":"Q5 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"5, đường Trang Tử, Quận 5"
    ,"Lat":10.751128
    ,"Long":106.655086
    ,"Polyline":"[106.65836334,10.75088024] ; [106.65743256,10.75090981] ; [106.65646362,10.75100040] ; [106.65547180,10.75098038] ; [106.65509033,10.75100994]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"621"
    ,"Station_Code":"Q6 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Võ Văn Tần"
    ,"Station_Address":"96-98, đường  Phạm Đình Hổ, Quận 6"
    ,"Lat":10.752271
    ,"Long":106.64975
    ,"Polyline":"[106.65509033,10.75100994] ; [106.65386200,10.75109005] ; [106.65325928,10.75164032] ; [106.65261841,10.75156021] ; [106.65180969,10.75142956] ; [106.65052795,10.75148010.06.64961243] ; [10.75158978,106.64967346]"
    ,"Distance":"703"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.64967346,10.75228024] ; [106.64975739,10.75343990] ; [106.65072632,10.75337029] ; [106.65086365,10.75333977] ; [106.65180206,10.75333023] ; [106.65232849,10.75339031]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"897"
    ,"Station_Code":"Q5 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"20-22, đường Tạ Uyên, Quận 5"
    ,"Lat":10.754606
    ,"Long":106.65383
    ,"Polyline":"[106.65232849,10.75339031] ; [106.65300751,10.75347042] ; [106.65377808,10.75360012] ; [106.65377808,10.75376987] ; [106.65380859,10.75393963] ; [106.65377045,10.75498962] ; [106.65373230,10.75535011]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1580"
    ,"Station_Code":"Q5 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Khách sạn Hoàng Hậu"
    ,"Station_Address":"321-323, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.757026
    ,"Long":106.655022
    ,"Polyline":"[106.65373230,10.75535011] ; [106.65370178,10.75566006] ; [106.65370178,10.75631046] ; [106.65368652,10.75687027] ; [106.65454865,10.75699043] ; [106.65500641,10.75708961]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1050"
    ,"Station_Code":"Q5 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ Thiếc"
    ,"Station_Address":"235, đường Nguy ễn Chí Thanh, Quận 5"
    ,"Lat":10.757568
    ,"Long":106.657616
    ,"Polyline":"[106.65500641,10.75708961] ; [106.65760803,10.75763035]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"281"
    ,"Station_Code":"Q5 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"201A, đường  Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758079
    ,"Long":106.660128
    ,"Polyline":"[106.65760803,10.75763035] ; [106.65827942,10.75778961] ; [106.66010284,10.75815010]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"282"
    ,"Station_Code":"Q5 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Lý Thường Kiệt"
    ,"Station_Address":"195B, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758443
    ,"Long":106.662006
    ,"Polyline":"[106.66010284,10.75815010.06.66062164] ; [10.75825977,106.66149139] ; [10.75844955,106.66195679]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"283"
    ,"Station_Code":"Q5 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chung cư 155 Nguyễn Chí Thanh"
    ,"Station_Address":"153-155, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.759281
    ,"Long":106.666056
    ,"Polyline":"[106.66195679,10.75852966] ; [106.66274261,10.75866032] ; [106.66557312,10.75924969] ; [106.66605377,10.75934029]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"284"
    ,"Station_Code":"Q5 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Trường Kinh tế Công nghệ"
    ,"Station_Address":"131, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.759649
    ,"Long":106.668019
    ,"Polyline":"[106.66605377,10.75934029] ; [106.66800690,10.75973988]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2969"
    ,"Station_Code":"Q5 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Ký túc xá Đại học Kinh tế"
    ,"Station_Address":"43, đường Nguyễn Chí Thanh , Quận 5"
    ,"Lat":10.760477
    ,"Long":106.672016
    ,"Polyline":"[106.66800690,10.75973988] ; [106.66876221,10.75990009] ; [106.66876984,10.75992012] ; [106.66880035,10.75996017] ; [106.66889954,10.76000977] ; [106.66900635,10.75996017] ; [106.66902924,10.75992966] ; [106.67199707,10.76053047]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2844"
    ,"Station_Code":"Q5 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bệnh viện 30/4"
    ,"Station_Address":"9, đường Sư Vạn Hạnh, Quận 5"
    ,"Lat":10.758147
    ,"Long":106.673652
    ,"Polyline":"[106.67199707,10.76053047] ; [106.67311859,10.76076031] ; [106.67344666,10.75922012] ; [106.67371368,10.75817013]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"466"
    ,"Station_Code":"Q5 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Huỳnh Mẫn  Đạt"
    ,"Station_Address":"439, đường An Dương Vương, Quận 5"
    ,"Lat":10.758374
    ,"Long":106.676576
    ,"Polyline":"[106.67371368,10.75817013] ; [106.67388153,10.75749016] ; [106.67398834,10.75751019] ; [106.67404175,10.75759029] ; [106.67413330,10.75757980] ; [106.67417145,10.75753021] ; [106.67575836,10.75811005] ; [106.67645264,10.75839996]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"472"
    ,"Station_Code":"Q5 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"373, đường An Dương Vương, Quận 5"
    ,"Lat":10.759138
    ,"Long":106.678453
    ,"Polyline":"[106.67645264,10.75839996] ; [106.67813110,10.75911045] ; [106.67829895,10.75916958]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"467"
    ,"Station_Code":"Q5 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Đại học  Sài Gòn"
    ,"Station_Address":"273-275, đường An Dương Vương, Quận 5"
    ,"Lat":10.760735
    ,"Long":106.682289
    ,"Polyline":"[106.67829895,10.75916958] ; [106.67920685,10.75951004] ; [106.68013000,10.75986958] ; [106.68226624,10.76074982]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1051"
    ,"Station_Code":"Q5 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bộ Công an"
    ,"Station_Address":"211-213, đường Nguyễn Văn Cừ, Quận 5"
    ,"Lat":10.760672
    ,"Long":106.683453
    ,"Polyline":"[106.68226624,10.76074982] ; [106.68334961,10.76117039] ; [106.68351746,10.76070023]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1052"
    ,"Station_Code":"Q1 150"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Báo An Ninh Thế Giới"
    ,"Station_Address":"371A, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.759869
    ,"Long":106.685104
    ,"Polyline":"[106.68351746,10.76070023] ; [106.68399048,10.75940037] ; [106.68469238,10.75969982] ; [106.68492889,10.75984001] ; [106.68501282,10.75990963] ; [106.68498230,10.75988960] ; [106.68508911,10.75983047]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1053"
    ,"Station_Code":"Q1 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Nhà Khách Bộ Công An"
    ,"Station_Address":"333, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.762006
    ,"Long":106.686394
    ,"Polyline":"[106.68508911,10.75983047] ; [106.68498230,10.75988960] ; [106.68501282,10.75990963] ; [106.68515015,10.76006031] ; [106.68537903,10.76039982] ; [106.68631744,10.76204967]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2974"
    ,"Station_Code":"Q1 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"173 - 173B,  đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.76303
    ,"Long":106.688217
    ,"Polyline":"[106.68631744,10.76204967] ; [106.68656158,10.76245022] ; [106.68682098,10.76255035] ; [106.68759918,10.76288033] ; [106.68817902,10.76311970]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2971"
    ,"Station_Code":"Q1 157"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Trần Hưng Đạo"
    ,"Station_Address":"37, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.764468
    ,"Long":106.69178
    ,"Polyline":"[106.68817902,10.76311970] ; [106.68875885,10.76334953] ; [106.69023132,10.76395988] ; [106.69072723,10.76422024] ; [106.69106293,10.76430988] ; [106.69174194,10.76455975]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"25"
    ,"Station_Code":"Q1 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Rạp Trần Hưng Đạo"
    ,"Station_Address":"227 - 229, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765213
    ,"Long":106.693069
    ,"Polyline":"[106.69174194,10.76455975] ; [106.69265747,10.76488972] ; [106.69300079,10.76527023]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"26"
    ,"Station_Code":"Q1 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"135, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767064
    ,"Long":106.694824
    ,"Polyline":"[106.69300079,10.76527023] ; [106.69467163,10.76718998]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"27"
    ,"Station_Code":"Q1 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"71C, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768327
    ,"Long":106.695847
    ,"Polyline":"[106.69467163,10.76718998] ; [106.69525909,10.76788044] ; [106.69538879,10.76801014] ; [106.69573975,10.76842022]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69573975,10.76842022] ; [106.69650269,10.76931953] ; [106.69714355,10.76998997] ; [106.69744873,10.77035046] ; [106.69774628,10.77033997] ; [106.69840240,10.77060032]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69840240,10.77060032] ; [106.69865417,10.77070045] ; [106.69902802,10.77087975] ; [106.69875336,10.77111149] ; [106.69863129,10.77127552] ; [106.69876099,10.77150154] ; [106.69872284,10.77178097] ; [106.69844818,10.77189732] ; [106.69820404,10.77180195] ; [106.69805908,10.77158070] ; [106.69806671,10.77132225] ; [106.69817352,10.77116489] ; [106.69808197,10.77101135] ; [106.69743347,10.77035809] ; [106.69580841,10.76966000]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69580841,10.76966000] ; [106.69412994,10.76898003]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường L ê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69412994,10.76898003] ; [106.69102478,10.76774406] ; [106.68942261,10.76710129] ; [106.68904877,10.76807022]"
    ,"Distance":"670"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68904877,10.76807022] ; [106.68920898,10.76819992] ; [106.68988800,10.76844978] ; [106.69026184,10.76860046]"
    ,"Distance":"145"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76860046] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69329834,10.76982975] ; [106.69458008,10.77031040] ; [106.69673157,10.77118969]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành A"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69673157,10.77118969] ; [106.69795227,10.77165985] ; [106.69806671,10.77159023] ; [106.69803619,10.77147007] ; [106.69805908,10.77134037] ; [106.69811249,10.77126026] ; [106.69819641,10.77120018] ; [106.69828796,10.77116966] ; [106.69841003,10.77116966] ; [106.69854736,10.77122021] ; [106.69860077,10.77124977] ; [106.69899750,10.77095032] ; [106.69857788,10.77079010]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"120"
    ,"Station_Code":"Q1 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Ernst  Thalmann"
    ,"Station_Address":"8, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768772
    ,"Long":106.695923
    ,"Polyline":"[106.69857788,10.77079010.06.69744873] ; [10.77035046,106.69714355] ; [10.76998997,106.69642639] ; [10.76924038,106.69599152]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"121"
    ,"Station_Code":"Q1 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"10, đường Tr ần Hưng Đạo, Quận 1"
    ,"Lat":10.767363
    ,"Long":106.694695
    ,"Polyline":"[106.69599152,10.76871967] ; [106.69538879,10.76801014] ; [106.69525909,10.76788044] ; [106.69476318,10.76731014]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"122"
    ,"Station_Code":"Q1 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Rạp Hưng Đạo"
    ,"Station_Address":"112, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765832
    ,"Long":106.693375
    ,"Polyline":"[106.69476318,10.76731014] ; [106.69344330,10.76578045]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2976"
    ,"Station_Code":"Q1 153"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nguyễn Cư Trinh"
    ,"Station_Address":"34 - 36, đường Nguy ễn Cư Trinh, Quận 1"
    ,"Lat":10.76471
    ,"Long":106.691933
    ,"Polyline":"[106.69344330,10.76578045] ; [106.69265747,10.76488972] ; [106.69210052,10.76469040] ; [106.69196320,10.76463985]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2973"
    ,"Station_Code":"Q1 154"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cống Quỳnh"
    ,"Station_Address":"118, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.763884
    ,"Long":106.689842
    ,"Polyline":"[106.69196320,10.76463985] ; [106.69106293,10.76430988] ; [106.69072723,10.76422024] ; [106.69023132,10.76395988] ; [106.68987274,10.76381016]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2975"
    ,"Station_Code":"Q1 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"184, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.763081
    ,"Long":106.687935
    ,"Polyline":"[106.68987274,10.76381016] ; [106.68795776,10.76303005]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1021"
    ,"Station_Code":"Q1 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nguyễn  Trãi"
    ,"Station_Address":"Đối diện số 205 - 207, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.760314
    ,"Long":106.683769
    ,"Polyline":"[106.68795776,10.76303005] ; [106.68682098,10.76255035] ; [106.68656158,10.76245022] ; [106.68588257,10.76130009] ; [106.68524170,10.76016998] ; [106.68495941,10.75986958] ; [106.68486023,10.75979042] ; [106.68399048,10.75940037] ; [106.68367004,10.76027966]"
    ,"Distance":"726"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"426"
    ,"Station_Code":"Q5 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Đại học Sư Phạm"
    ,"Station_Address":"280, đường An Dương Vương , Quận 5"
    ,"Lat":10.76103
    ,"Long":106.68267
    ,"Polyline":"[106.68367004,10.76027966] ; [106.68334961,10.76117039] ; [106.68270111,10.76091003]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"429"
    ,"Station_Code":"Q5 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"370 , đường An Dương Vương, Quận 5"
    ,"Lat":10.759407
    ,"Long":106.678764
    ,"Polyline":"[106.68270111,10.76091003] ; [106.68013000,10.75986958] ; [106.67920685,10.75951004] ; [106.67878723,10.75934029]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"427"
    ,"Station_Code":"Q5 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Huỳnh Mẫn  Đạt"
    ,"Station_Address":"526, đường An Dương Vương, Quận 5"
    ,"Lat":10.757984
    ,"Long":106.675272
    ,"Polyline":"[106.67878723,10.75934029] ; [106.67813110,10.75911045] ; [106.67575836,10.75811005] ; [106.67529297,10.75794029]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2843"
    ,"Station_Code":"Q5 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện 30/4"
    ,"Station_Address":"Đối diện 9, đường Sư Vạn Hạnh, Quận 5"
    ,"Lat":10.75801
    ,"Long":106.673797
    ,"Polyline":"[106.67529297,10.75794029] ; [106.67417145,10.75753021] ; [106.67413330,10.75757980] ; [106.67404175,10.75759029] ; [106.67398834,10.75751019] ; [106.67388153,10.75749016] ; [106.67375183,10.75800037]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2978"
    ,"Station_Code":"Q10 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trường CĐ sư phạm TW thành phố"
    ,"Station_Address":"184, đường Nguyễn  Chí Thanh, Quận 10"
    ,"Lat":10.760277
    ,"Long":106.670578
    ,"Polyline":"[106.67375183,10.75800037] ; [106.67326355,10.76012039] ; [106.67311859,10.76076031] ; [106.67286682,10.76070976] ; [106.67059326,10.76023960]"
    ,"Distance":"597"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"389"
    ,"Station_Code":"Q10 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nguyễn Tiểu La"
    ,"Station_Address":"292, đường Nguyễn Chí Thanh, Quận 10"
    ,"Lat":10.759739
    ,"Long":106.667976
    ,"Polyline":"[106.67059326,10.76023960] ; [106.66902924,10.75992966] ; [106.66902161,10.75994968] ; [106.66898346,10.75998020] ; [106.66893005,10.76000023] ; [106.66886902,10.76000023] ; [106.66877747,10.75994015] ; [106.66876221,10.75990009] ; [106.66797638,10.75973034]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"392"
    ,"Station_Code":"Q10 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngô Quyền"
    ,"Station_Address":"440, đường Nguyễn Chí Thanh, Quận 10"
    ,"Lat":10.759228
    ,"Long":106.665171
    ,"Polyline":"[106.66797638,10.75973034] ; [106.66631317,10.75938988]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"391"
    ,"Station_Code":"Q10 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà máy bia sài gòn"
    ,"Station_Address":"Đ ối diện nhà máy bia Sài Gòn, đường Nguyễn Chí Thanh, Quận 10"
    ,"Lat":10.759078
    ,"Long":106.66452
    ,"Polyline":"[106.66631317,10.75938988] ; [106.66452789,10.75903034]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"393"
    ,"Station_Code":"Q11 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"BV Răng Hàm Mặt"
    ,"Station_Address":"598, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.758364
    ,"Long":106.660828
    ,"Polyline":"[106.66452789,10.75903034] ; [106.66274261,10.75866032] ; [106.66149139,10.75844955] ; [106.66084290,10.75831032]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1608"
    ,"Station_Code":"Q11 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"698, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.757636
    ,"Long":106.657387
    ,"Polyline":"[106.66084290,10.75831032] ; [106.65827942,10.75778961] ; [106.65738678,10.75759029]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1599"
    ,"Station_Code":"Q11 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"816, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.756951
    ,"Long":106.65412
    ,"Polyline":"[106.65738678,10.75759029] ; [106.65561676,10.75720978] ; [106.65454865,10.75699043] ; [106.65416718,10.75693989]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"1017"
    ,"Station_Code":"Q5 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"79 , đường Tạ Uyên, Quận 5"
    ,"Lat":10.755201
    ,"Long":106.653696
    ,"Polyline":"[106.65416718,10.75693989] ; [106.65368652,10.75687027] ; [106.65368652,10.75669956] ; [106.65370178,10.75566006] ; [106.65374756,10.75520992]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2"
    ,"Station_Code":"Q5 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"11-12, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750732
    ,"Long":106.655075
    ,"Polyline":"[106.65369415,10.75520134] ; [106.65374756,10.75384140] ; [106.65322113,10.75168133] ; [106.65331268,10.75038433] ; [106.65472412,10.75075340] ; [106.65507507,10.75073242]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"617"
    ,"Station_Code":"Q8 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"388, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.74483
    ,"Long":106.656926
    ,"Polyline":"[106.65503693,10.75078964] ; [106.65529633,10.75076962] ; [106.65573120,10.75074291] ; [106.65592194,10.75074768] ; [106.65629578,10.75077438] ; [106.65677643,10.75078487] ; [106.65741730,10.75071144] ; [106.65824890,10.75065899] ; [106.65882111,10.75063705] ; [106.65904236,10.75065327] ; [106.65914154,10.75060844] ; [106.65924835,10.75062466] ; [106.65929413,10.75063705] ; [106.65966034,10.75048161] ; [106.65982056,10.75039482] ; [106.65991211,10.75026035] ; [106.66003418,10.74991035] ; [106.66014099,10.74958038] ; [106.66031647,10.74908829] ; [106.66043091,10.74869823] ; [106.66050720,10.74845314] ; [106.66051483,10.74807072] ; [106.66046906,10.74772549] ; [106.66043091,10.74734116] ; [106.66040802,10.74718285] ; [106.66035461,10.74702168] ; [106.66024780,10.74696159] ; [106.66017151,10.74695492] ; [106.66004944,10.74694920] ; [106.65994263,10.74692726] ; [106.65979767,10.74681377] ; [106.65959930,10.74662590] ; [106.65933990,10.74637413] ; [106.65914154,10.74616051] ; [106.65896606,10.74590969] ; [106.65888214,10.74578476] ; [106.65868378,10.74569798] ; [106.65853882,10.74563599] ; [106.65664673,10.74456978]"
    ,"Distance":"1472"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"618"
    ,"Station_Code":"Q8 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chùa Pháp Quang"
    ,"Station_Address":"100, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738642
    ,"Long":106.656142
    ,"Polyline":"[106.65692902,10.74483013] ; [106.65617371,10.74440765] ; [106.65563965,10.74380684] ; [106.65553284,10.74354362] ; [106.65547943,10.74324799] ; [106.65550995,10.74296379] ; [106.65557098,10.74267960] ; [106.65628052,10.74075031] ; [106.65614319,10.73864174]"
    ,"Distance":"777"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"619"
    ,"Station_Code":"Q8 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Bùi Minh  Trực"
    ,"Station_Address":"224, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656126
    ,"Polyline":"[106.65614319,10.73864174] ; [106.65618896,10.73756695] ; [106.65612793,10.73645973]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2148"
    ,"Station_Code":"Q8 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Bến xe Qu ận 8"
    ,"Station_Address":"328-330, đường Quốc  lộ 50, Quận 8"
    ,"Lat":10.732776
    ,"Long":106.656051
    ,"Polyline":"[106.65620422,10.73618889] ; [106.65608978,10.73287392]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2149"
    ,"Station_Code":"HBC 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Linh Sơn"
    ,"Station_Address":"A6/17, đường  Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.7308
    ,"Long":106.655971
    ,"Polyline":"[106.65608978,10.73287392] ; [106.65612030,10.73224926] ; [106.65605927,10.73153019]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2151"
    ,"Station_Code":"HBC 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Mầm non Ánh Dương"
    ,"Station_Address":"A11/07, đường Quốc lộ 50, Huyện Bình  Chánh"
    ,"Lat":10.72789
    ,"Long":106.65589
    ,"Polyline":"[106.65606689,10.73147011] ; [106.65598297,10.72867012]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2150"
    ,"Station_Code":"HBC 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngân hàng Nam Á"
    ,"Station_Address":"A13/1A, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.725292
    ,"Long":106.655831
    ,"Polyline":"[106.65589142,10.72789001] ; [106.65583038,10.72529221]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"2153"
    ,"Station_Code":"HBC 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"B2/21, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.72058
    ,"Long":106.655686
    ,"Polyline":"[106.65585327,10.72528648] ; [106.65581512,10.72303009]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"879"
    ,"Station_Code":"HBC 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Sau Quốc lộ 50"
    ,"Station_Address":"Cột đèn 144, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.718972
    ,"Long":106.654415
    ,"Polyline":"[106.65568542,10.72058010.06.65569305] ; [10.71999454,106.65441132]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"881"
    ,"Station_Code":"HBC 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Hoa Kiểng Phú Vinh"
    ,"Station_Address":"Cột đèn 156, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.714903
    ,"Long":106.649158
    ,"Polyline":"[106.65441132,10.71897221] ; [106.64915466,10.71490288]"
    ,"Distance":"732"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"884"
    ,"Station_Code":"HBC 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Xây dựng Tân Bình"
    ,"Station_Address":"Cột đèn 172, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.71174
    ,"Long":106.645103
    ,"Polyline":"[106.64915466,10.71490288] ; [106.64510345,10.71173954]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"878"
    ,"Station_Code":"HBC 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Chung cư Conic"
    ,"Station_Address":"Cột đèn 184, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.709506
    ,"Long":106.64227
    ,"Polyline":"[106.64510345,10.71173954] ; [106.64227295,10.70950603]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"880"
    ,"Station_Code":"HBC 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Khu dân cư 13A"
    ,"Station_Address":"Cột đèn 192, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.707397
    ,"Long":106.639502
    ,"Polyline":"[106.64227295,10.70950603] ; [106.63950348,10.70739746]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"882"
    ,"Station_Code":"HBC 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trịnh Quang Nghị"
    ,"Station_Address":"Cột đèn 210, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.703602
    ,"Long":106.634567
    ,"Polyline":"[106.63950348,10.70739746] ; [106.63456726,10.70360184]"
    ,"Distance":"685"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"886"
    ,"Station_Code":"HBC 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Nhôm Kim Hằng"
    ,"Station_Address":"Cột đèn 216, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.701414
    ,"Long":106.631713
    ,"Polyline":"[106.63456726,10.70360184] ; [106.63171387,10.70141411]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"887"
    ,"Station_Code":"HBC 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cầu sập"
    ,"Station_Address":"Cột đèn 232, đường Nguyễn  Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69925
    ,"Long":106.627235
    ,"Polyline":"[106.63171387,10.70141411] ; [106.63054657,10.70063972] ; [106.62888336,10.69987011] ; [106.62723541,10.69925022]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"883"
    ,"Station_Code":"HBC 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Ba Tơ"
    ,"Station_Address":"Cột đèn 249, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.696855
    ,"Long":106.61828
    ,"Polyline":"[106.62723541,10.69925022] ; [106.61827850,10.69685459]"
    ,"Distance":"1015"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"885"
    ,"Station_Code":"HBC 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Cầu Cần Giuộc"
    ,"Station_Address":"Cột đèn 258, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.695133
    ,"Long":106.612183
    ,"Polyline":"[106.61827850,10.69685459] ; [106.61218262,10.69513321]"
    ,"Distance":"694"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"888"
    ,"Station_Code":"HBC 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Khu dân cư Nguyễn Minh"
    ,"Station_Address":"Cột đèn 265, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.6944
    ,"Long":106.60952
    ,"Polyline":"[106.61218262,10.69513321] ; [106.60951996,10.69439983]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"889"
    ,"Station_Code":"HBC 452"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Đối diện công ty bất động  sản, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698468
    ,"Long":106.609279
    ,"Polyline":"[106.60951996,10.69439983] ; [106.61037445,10.69462013] ; [106.60927582,10.69846821]"
    ,"Distance":"541"
  },
  {
     "Route_Id":"136"
    ,"Station_Id":"890"
    ,"Station_Code":"BX 60"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Chợ Đầu mối Bình Điền"
    ,"Station_Address":"ĐẦU BẾN CHỢ ĐM BÌNH ĐIỀN, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.7024
    ,"Long":106.608665
    ,"Polyline":"[106.60929871,10.69845963] ; [106.60823822,10.70228958]"
    ,"Distance":"492"
  }]