export const Route33 =[
  {
     "Route_Id":"33"
    ,"Station_Id":"6832"
    ,"Station_Code":"BX 75"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu dân cư Bình Hưng Hòa B"
    ,"Station_Address":"Khu dân cư Bình Hưng Hòa B , đường Đường số 3, Quận Bình Tân"
    ,"Lat":10.806413
    ,"Long":106.588326
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2444"
    ,"Station_Code":"QBT 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Công ty B ảo Ngọc Châu"
    ,"Station_Address":"117, đường Nguy ễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.81555
    ,"Long":106.594913
    ,"Polyline":"[106.58832550,10.80641270] ; [106.58734131,10.80154419] ; [106.59085846,10.80080605] ; [106.59291840,10.81024837] ; [106.59410095,10.81551838] ; [106.59490967,10.81554985]"
    ,"Distance":"2711"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2447"
    ,"Station_Code":"QBT 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Tú"
    ,"Station_Address":"810-814, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.815718
    ,"Long":106.602783
    ,"Polyline":"[106.59487152,10.81567001] ; [106.59867096,10.81595993] ; [106.59950256,10.81604958] ; [106.60008240,10.81630993] ; [106.60030365,10.81636047] ; [106.60061646,10.81632042] ; [106.60106659,10.81622982] ; [106.60122681,10.81616020] ; [106.60154724,10.81608963] ; [106.60281372,10.81583023]"
    ,"Distance":"911"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2446"
    ,"Station_Code":"QBT 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Từ bảo Nghi"
    ,"Station_Address":"692 , đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.814411
    ,"Long":106.60495
    ,"Polyline":"[106.60281372,10.81583023] ; [106.60318756,10.81569958] ; [106.60452271,10.81492043] ; [106.60505676,10.81459045]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2451"
    ,"Station_Code":"QBT 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Đường CN1"
    ,"Station_Address":"642 , đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.813337
    ,"Long":106.607063
    ,"Polyline":"[106.60505676,10.81459045] ; [106.60547638,10.81433010.06.60559845] ; [10.81425953,106.60569763] ; [10.81424999,106.60576630] ; [10.81420994,106.60635376] ; [10.81385040,106.60717773]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1813"
    ,"Station_Code":"QTP 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Phạm Văn X ảo"
    ,"Station_Address":"277 , đường Nguyễn Sơn, Quận Tân Phú"
    ,"Lat":10.78386
    ,"Long":106.623253
    ,"Polyline":"[106.60706329,10.81333733] ; [106.60787201,10.81288338] ; [106.60743713,10.80807781] ; [106.60858154,10.80567551] ; [106.60995483,10.80314541] ; [106.61364746,10.79671669] ; [106.61561584,10.79269123] ; [106.61721039,10.78853893] ; [106.61879730,10.78455448] ; [106.61967468,10.78478146] ; [106.61994171,10.78480244] ; [106.62044525,10.78476620] ; [106.62100983,10.78464413] ; [106.62315369,10.78393841] ; [106.62325287,10.78386021]"
    ,"Distance":"4051"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1816"
    ,"Station_Code":"QTP 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Tân Phú"
    ,"Station_Address":"131-133, đường Nguyễn S ơn, Quận Tân Phú"
    ,"Lat":10.783206
    ,"Long":106.62532
    ,"Polyline":"[106.62325287,10.78386021] ; [106.62532043,10.78320599]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1818"
    ,"Station_Code":"QTP 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Pham Văn Năm"
    ,"Station_Address":"69, đường Nguyễn Sơn, Quận Tân Phú"
    ,"Lat":10.781941
    ,"Long":106.629295
    ,"Polyline":"[106.62534332,10.78324986] ; [106.62600708,10.78302956] ; [106.62831879,10.78229046] ; [106.62880707,10.78215027] ; [106.62902069,10.78217030] ; [106.62934113,10.78205967]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1815"
    ,"Station_Code":"QTPT182"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Thoại Ngọc Hầu"
    ,"Station_Address":"5, đường Nguyễn Sơn, Quận Tân Phú"
    ,"Lat":10.780895233154297
    ,"Long":106.63308715820312
    ,"Polyline":"[106.62934113,10.78205967] ; [106.63069153,10.78160000] ; [106.63101196,10.78149986] ; [106.63259888,10.78110981] ; [106.63311005,10.78098011]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1820"
    ,"Station_Code":"QTP 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Tập hóa Thanh Hoa"
    ,"Station_Address":"151, đường Thoại Ngọc Hầu, Qu ận Tân Phú"
    ,"Lat":10.780979
    ,"Long":106.635101
    ,"Polyline":"[106.63308716,10.78089523] ; [106.63311005,10.78093433] ; [106.63425446,10.78068161] ; [106.63502502,10.78107166] ; [106.63510132,10.78097916]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1817"
    ,"Station_Code":"QTP 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Công ty In Ngọc Anh"
    ,"Station_Address":"71, đường Tho ại Ngọc Hầu, Quận Tân Phú"
    ,"Lat":10.783043
    ,"Long":106.637772
    ,"Polyline":"[106.63510132,10.78097916] ; [106.63516998,10.78116131] ; [106.63593292,10.78165627] ; [106.63649750,10.78213120] ; [106.63689423,10.78257370] ; [106.63760376,10.78307915] ; [106.63777161,10.78304291]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1821"
    ,"Station_Code":"QTP 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường Trung Cấp CNTT Sài Gòn"
    ,"Station_Address":"5, đường Thoại Ngọc Hầu, Quận Tân Phú"
    ,"Lat":10.784998
    ,"Long":106.640533
    ,"Polyline":"[106.63771820,10.78310966] ; [106.63913727,10.78413010.06.64048004]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1819"
    ,"Station_Code":"QTB 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Hồng Lạc"
    ,"Station_Address":"323 (564), đường Hồng  Lạc, Quận Tân Bình"
    ,"Lat":10.786288
    ,"Long":106.642738
    ,"Polyline":"[106.64048004,10.78507042] ; [106.64173889,10.78602028] ; [106.64270782,10.78637028]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1823"
    ,"Station_Code":"QTB 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Bàu Cát 9"
    ,"Station_Address":"215, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.787601
    ,"Long":106.643263
    ,"Polyline":"[106.64270782,10.78637028] ; [106.64315796,10.78654003] ; [106.64343262,10.78666973] ; [106.64311981,10.78785992]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1822"
    ,"Station_Code":"QTB 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Công viên Bàu Cát"
    ,"Station_Address":"149 , đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.790478
    ,"Long":106.643445
    ,"Polyline":"[106.64311981,10.78785992] ; [106.64282227,10.78890038] ; [106.64283752,10.78915024] ; [106.64292145,10.78934002] ; [106.64327240,10.79014015] ; [106.64340973,10.79051971]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1825"
    ,"Station_Code":"QTB 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Trần  Quốc Toản"
    ,"Station_Address":"113, đường Đ ồng Đen, Quận Tân Bình"
    ,"Lat":10.792459
    ,"Long":106.644325
    ,"Polyline":"[106.64340973,10.79051971] ; [106.64427185,10.79248047]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1824"
    ,"Station_Code":"QTB 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Đường Đồng Đen"
    ,"Station_Address":"45, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.794153
    ,"Long":106.644974
    ,"Polyline":"[106.64427185,10.79248047] ; [106.64469147,10.79356956] ; [106.64485168,10.79399014] ; [106.64491272,10.79417992]"
    ,"Distance":"215"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1828"
    ,"Station_Code":"QTB 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Hội chữ th ập đỏ Tân Bình"
    ,"Station_Address":"1, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.796401
    ,"Long":106.645736
    ,"Polyline":"[106.64491272,10.79417992] ; [106.64534760,10.79541969] ; [106.64559937,10.79619980]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1392"
    ,"Station_Code":"QTB 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Hoàng Hoa  Thám"
    ,"Station_Address":"233, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796426
    ,"Long":106.646553
    ,"Polyline":"[106.64559937,10.79619980] ; [106.64584351,10.79693985] ; [106.64660645,10.79652023]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1826"
    ,"Station_Code":"QTB 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà thờ  Đắc Lộ"
    ,"Station_Address":"97 (đối diện 160B), đường Trường Chinh, Qu ận Tân Bình"
    ,"Lat":10.794978
    ,"Long":106.64926
    ,"Polyline":"[106.64655304,10.79642582] ; [106.64727783,10.79612732] ; [106.64810944,10.79570007] ; [106.64932251,10.79506969] ; [106.64927673,10.79499626]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1830"
    ,"Station_Code":"QTB 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"67, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.793856
    ,"Long":106.651368
    ,"Polyline":"[106.64927673,10.79499626] ; [106.64968109,10.79483032] ; [106.65074921,10.79431438] ; [106.65154266,10.79377842]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1827"
    ,"Station_Code":"QTB 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường Nguy ễn Thượng Hiền"
    ,"Station_Address":"28 (hông Trư ờng Nguyễn Thượng Hiền), đường Lê Bình, Quận Tân Bình"
    ,"Lat":10.793779
    ,"Long":106.656006
    ,"Polyline":"[106.65158081,10.79384995] ; [106.65300751,10.79310989] ; [106.65322113,10.79306984] ; [106.65341187,10.79314995] ; [106.65367889,10.79327965] ; [106.65377808,10.79337978] ; [106.65458679,10.79424000] ; [106.65479279,10.79413986] ; [106.65540314,10.79399014] ; [106.65602112,10.79384041]"
    ,"Distance":"581"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1829"
    ,"Station_Code":"QTB 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đầu đường Hoàng Sa"
    ,"Station_Address":"128, đường Lê Bình, Quận Tân Bình"
    ,"Lat":10.792931
    ,"Long":106.65847
    ,"Polyline":"[106.65602112,10.79384041] ; [106.65677643,10.79366016] ; [106.65702820,10.79358959] ; [106.65718842,10.79351044] ; [106.65804291,10.79290962] ; [106.65815735,10.79286957] ; [106.65843964,10.79298019]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1832"
    ,"Station_Code":"QTB 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chùa Khuông Việt"
    ,"Station_Address":"Chùa Khuông Vi ệt, đường Hoàng Sa, Quận Tân Bình"
    ,"Lat":10.792386
    ,"Long":106.659943
    ,"Polyline":"[106.65843964,10.79298019] ; [106.65889740,10.79321003] ; [106.65901947,10.79325008] ; [106.65915680,10.79314995] ; [106.65933228,10.79298973] ; [106.66001892,10.79248047]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1831"
    ,"Station_Code":"QTB 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cầu Số 2"
    ,"Station_Address":"307 (318/15), đường Hoàng Sa, Quận Tân Bình"
    ,"Lat":10.791521
    ,"Long":106.661606
    ,"Polyline":"[106.66001892,10.79248047] ; [106.66068268,10.79195976] ; [106.66095734,10.79179001] ; [106.66162109,10.79156971]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1834"
    ,"Station_Code":"QTB 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Số 3"
    ,"Station_Address":"1213 (55/9), đường  Hoàng Sa, Quận Tân Bình"
    ,"Lat":10.790744
    ,"Long":106.664894
    ,"Polyline":"[106.66162109,10.79156971] ; [106.66200256,10.79146004] ; [106.66223907,10.79144001] ; [106.66256714,10.79146004] ; [106.66304016,10.79144955] ; [106.66333008,10.79141045] ; [106.66358185,10.79133034] ; [106.66433716,10.79104996] ; [106.66491699,10.79080963]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1833"
    ,"Station_Code":"Q3 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Xí nghiệp Đầu máy Sài Gòn"
    ,"Station_Address":"540/21 (XN Đầu máy SG), đường Hoàng Sa, Quận 3"
    ,"Lat":10.78846
    ,"Long":106.668143
    ,"Polyline":"[106.66489410,10.79074383] ; [106.66491699,10.79080963] ; [106.66542816,10.79063034] ; [106.66586304,10.79053974] ; [106.66606140,10.79049969] ; [106.66629791,10.79039955] ; [106.66649628,10.79026031] ; [106.66651917,10.79022026] ; [106.66654205,10.79012012] ; [106.66651154,10.78995037] ; [106.66642761,10.78962040] ; [106.66648865,10.78942013] ; [106.66667938,10.78927994] ; [106.66713715,10.78903008] ; [106.66789246,10.78864002] ; [106.66814423,10.78845978]"
    ,"Distance":"500"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1836"
    ,"Station_Code":"Q3 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường ray xe lữa"
    ,"Station_Address":"1003, đường Hoàng Sa, Quận 3"
    ,"Lat":10.786874
    ,"Long":106.673019
    ,"Polyline":"[106.66892242,10.78827953] ; [106.66948700,10.78806019] ; [106.67034912,10.78779984] ; [106.67070007,10.78765965] ; [106.67118835,10.78750992] ; [106.67204285,10.78722000] ; [106.67243958,10.78711987] ; [106.67304230,10.78693008]"
    ,"Distance":"570"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1835"
    ,"Station_Code":"Q3 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Coop Mart Nhiêu Lộc"
    ,"Station_Address":"Kế 913  Hoàng Sa, đường Hoàng Sa, Quận 3"
    ,"Lat":10.785503
    ,"Long":106.675481
    ,"Polyline":"[106.67304230,10.78693008] ; [106.67417908,10.78656960] ; [106.67446899,10.78637981] ; [106.67495728,10.78598022] ; [106.67508698,10.78586960]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1840"
    ,"Station_Code":"Q3 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Rạch Bùng  Binh"
    ,"Station_Address":"789 , đường Hoàng Sa, Quận 3"
    ,"Lat":10.783959
    ,"Long":106.679939
    ,"Polyline":"[106.67548370,10.78550339] ; [106.67661285,10.78474426] ; [106.67707825,10.78461838] ; [106.67761230,10.78440762] ; [106.67824554,10.78390121] ; [106.67852020,10.78390121] ; [106.67892456,10.78390121] ; [106.67926025,10.78403282] ; [106.67948914,10.78404903] ; [106.67977905,10.78402233] ; [106.67993927,10.78395939]"
    ,"Distance":"544"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1838"
    ,"Station_Code":"Q3 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ủy ban Phường 7"
    ,"Station_Address":"125, đường Bà Huyện Thanh Quan, Quận 3"
    ,"Lat":10.781393
    ,"Long":106.681951
    ,"Polyline":"[106.67993927,10.78402042] ; [106.68016052,10.78400993] ; [106.68036652,10.78394985] ; [106.68032074,10.78384018] ; [106.68019867,10.78254986] ; [106.68202972,10.78149033]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1839"
    ,"Station_Code":"Q3 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Bệnh viện Mắt"
    ,"Station_Address":"Đối diện 58, đường Bà Huyện Thanh Quan, Quận 3"
    ,"Lat":10.779206
    ,"Long":106.685545
    ,"Polyline":"[106.68195343,10.78139305] ; [106.68554688,10.77920628]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1841"
    ,"Station_Code":"Q3 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Hồ Xuân Hương"
    ,"Station_Address":"Đối diện 40, đường Bà Huyện Thanh Quan, Quận 3"
    ,"Lat":10.777372
    ,"Long":106.68768
    ,"Polyline":"[106.68554688,10.77920628] ; [106.68565369,10.77919579] ; [106.68607330,10.77892208] ; [106.68687439,10.77822113] ; [106.68766785,10.77748299] ; [106.68768311,10.77737236]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1842"
    ,"Station_Code":"Q3 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Võ Văn Tần"
    ,"Station_Address":"Đối diện 12, đường Bà Huyện Thanh Quan, Quận 3"
    ,"Lat":10.775918
    ,"Long":106.6893
    ,"Polyline":"[106.68768311,10.77737236] ; [106.68774414,10.77740955] ; [106.68930817,10.77600765] ; [106.68930054,10.77591801]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"381"
    ,"Station_Code":"Q3 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Thị Minh Khai"
    ,"Station_Address":"17, đường Bà Huyện Thanh Quan, Quận 3"
    ,"Lat":10.775102
    ,"Long":106.690186
    ,"Polyline":"[106.68927002,10.77600956] ; [106.69023132,10.77515030]"
    ,"Distance":"160"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"242"
    ,"Station_Code":"Q1 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Nhà Văn Hóa Lao Động"
    ,"Station_Address":"Đối diện số 138, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.777097
    ,"Long":106.692757
    ,"Polyline":"[106.69020844,10.77513027] ; [106.69053650,10.77482986] ; [106.69161987,10.77598953] ; [106.69270325,10.77715015]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1843"
    ,"Station_Code":"Q1 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Sân vận động Tao Đàn"
    ,"Station_Address":"3 , đường Huy ền Trân Công Chúa, Quận 1"
    ,"Lat":10.776223
    ,"Long":106.694198
    ,"Polyline":"[106.69270325,10.77715015] ; [106.69291687,10.77738953] ; [106.69406128,10.77645969]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1845"
    ,"Station_Code":"Q1 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Thủ Khoa Huân"
    ,"Station_Address":"55 - 57, đường Th ủ Khoa Huân, Quận 1"
    ,"Lat":10.774358
    ,"Long":106.696548
    ,"Polyline":"[106.69406128,10.77645969] ; [106.69607544,10.77481651] ; [106.69663239,10.77443981]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1844"
    ,"Station_Code":"Q1 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Bến Thành"
    ,"Station_Address":"220, đường Lê Thánh Tôn, Quận 1"
    ,"Lat":10.77234
    ,"Long":106.696295
    ,"Polyline":"[106.69663239,10.77443981] ; [106.69712067,10.77396965] ; [106.69764709,10.77313042] ; [106.69632721,10.77229023]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69632721,10.77229023] ; [106.69529724,10.77167034] ; [106.69551086,10.77118969] ; [106.69628143,10.77116013] ; [106.69667053,10.77118015] ; [106.69515228,10.77054977] ; [106.69412994,10.77013969] ; [106.69467163,10.76920033] ; [106.69412994,10.76896954]"
    ,"Distance":"827"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt S ài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.69398499,10.76903534] ; [106.69384003,10.76895618] ; [106.69238281,10.76828003] ; [106.69049072,10.76753044] ; [106.68981171,10.76729584] ; [106.68961334,10.76770687] ; [106.68936157,10.76767635] ; [106.68936157,10.76767635]"
    ,"Distance":"575"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt  Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68923187,10.76808643] ; [106.68927765,10.76815033] ; [106.68992615,10.76840782] ; [106.69019318,10.76849747] ; [106.69033813,10.76855087]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69268036,10.76948357] ; [106.69322968,10.76969910.06.69343567]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"241"
    ,"Station_Code":"Q1 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Bà Ấn"
    ,"Station_Address":"42, đường Trương Định, Quận 1"
    ,"Lat":10.772419
    ,"Long":106.695839
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69675446,10.77112770] ; [106.69583893,10.77241898]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1705"
    ,"Station_Code":"Q3 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Nguyễn Thị Diệu"
    ,"Station_Address":"Đối di ện 67, đường Trương Định, Quận 3"
    ,"Lat":10.77721
    ,"Long":106.69043
    ,"Polyline":"[106.69583893,10.77241898] ; [106.69042969,10.77721024]"
    ,"Distance":"796"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1709"
    ,"Station_Code":"Q3 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Nguyễn  Thị Minh Khai"
    ,"Station_Address":"32C, đường  Trương Định, Quận 3"
    ,"Lat":10.779335
    ,"Long":106.688095
    ,"Polyline":"[106.69042969,10.77721024] ; [106.68809509,10.77933502]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1707"
    ,"Station_Code":"Q3 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"Đối diện 115 - 117, đường Trương Định, Qu ận 3"
    ,"Lat":10.780396
    ,"Long":106.68679
    ,"Polyline":"[106.68809509,10.77933502] ; [106.68679047,10.78039646]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1710"
    ,"Station_Code":"Q3 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Sở xây Dựng"
    ,"Station_Address":"66, đường Trương Định, Quận 3"
    ,"Lat":10.782252
    ,"Long":106.684011
    ,"Polyline":"[106.68679047,10.78039646] ; [106.68401337,10.78225231]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1708"
    ,"Station_Code":"Q3 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Hoàng Sa"
    ,"Station_Address":"16/20, đường Trương Định, Quận 3"
    ,"Lat":10.783646
    ,"Long":106.681206
    ,"Polyline":"[106.68401337,10.78225231] ; [106.68120575,10.78364563]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1714"
    ,"Station_Code":"Q3 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Trư ơng Quyền"
    ,"Station_Address":"946, đường Trường Sa, Quận 3"
    ,"Lat":10.785008
    ,"Long":106.677557
    ,"Polyline":"[106.68120575,10.78364563] ; [106.68034363,10.78405952] ; [106.68067169,10.78428078] ; [106.68027496,10.78474426] ; [106.68012238,10.78467083] ; [106.67971039,10.78466606] ; [106.67929840,10.78469181] ; [106.67906952,10.78464413] ; [106.67877197,10.78452873] ; [106.67852020,10.78446579] ; [106.67831421,10.78450203] ; [106.67813873,10.78457642] ; [106.67799377,10.78468704] ; [106.67781830,10.78486061] ; [106.67755890,10.78500843]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1713"
    ,"Station_Code":"Q3 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Coop Mart"
    ,"Station_Address":"Co.op mart, đường Trường Sa, Quận 3"
    ,"Lat":10.786747
    ,"Long":106.674972
    ,"Polyline":"[106.67755890,10.78500843] ; [106.67726135,10.78506565] ; [106.67687225,10.78518772] ; [106.67667389,10.78530312] ; [106.67651367,10.78542423] ; [106.67611694,10.78565121] ; [106.67553711,10.78617764] ; [106.67523193,10.78645229] ; [106.67497253,10.78674698]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1716"
    ,"Station_Code":"Q3 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường mầm non 12"
    ,"Station_Address":"Trường mầm non 12, đường Trường Sa, Quận 3"
    ,"Lat":10.787654
    ,"Long":106.6726
    ,"Polyline":"[106.67497253,10.78674698] ; [106.67451477,10.78697872] ; [106.67415619,10.78713226] ; [106.67347717,10.78732681] ; [106.67278290,10.78754807] ; [106.67259979,10.78765392]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1712"
    ,"Station_Code":"QPN 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Cầu Số 5"
    ,"Station_Address":"1254, đường Trường Sa, Quận Phú Nhuận"
    ,"Lat":10.788478
    ,"Long":106.669785
    ,"Polyline":"[106.67259979,10.78765392] ; [106.67236328,10.78768539] ; [106.66978455,10.78847790]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1718"
    ,"Station_Code":"QPN 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu Số 6"
    ,"Station_Address":"1198, đường Trường Sa, Quận Phú Nhuận"
    ,"Lat":10.790794
    ,"Long":106.666534
    ,"Polyline":"[106.66978455,10.78847790] ; [106.66979218,10.78847980] ; [106.66898346,10.78874969] ; [106.66816711,10.78905964] ; [106.66744232,10.78942966] ; [106.66716003,10.78954029] ; [106.66705322,10.78962040] ; [106.66699982,10.78967953] ; [106.66696930,10.78975964] ; [106.66696930,10.78993034] ; [106.66700745,10.79004955] ; [106.66701508,10.79016685] ; [106.66703796,10.79025650] ; [106.66701508,10.79036236] ; [106.66693115,10.79047775] ; [106.66653442,10.79079437]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1715"
    ,"Station_Code":"QTB 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Đường Phạm Văn Hai"
    ,"Station_Address":"1410A, đường Trường Sa, Quận Tân Bình"
    ,"Lat":10.792043
    ,"Long":106.661606
    ,"Polyline":"[106.66653442,10.79079437] ; [106.66374207,10.79175854] ; [106.66160583,10.79204273]"
    ,"Distance":"559"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1721"
    ,"Station_Code":"QTB 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đầu đường Hoàng Sa"
    ,"Station_Address":"59 (đối diện 136), đường Lê Bình, Quận Tân Bình"
    ,"Lat":10.79302
    ,"Long":106.658394
    ,"Polyline":"[106.66160583,10.79204273] ; [106.66116333,10.79216957] ; [106.66059875,10.79256439] ; [106.65930176,10.79358196] ; [106.65915680,10.79346561] ; [106.65911865,10.79334450] ; [106.65901947,10.79325485] ; [106.65869904,10.79310703] ; [106.65839386,10.79302025]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1717"
    ,"Station_Code":"QTB 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trường Nguyễn Thượng Hiền"
    ,"Station_Address":"33B (1425 Bis), đường Lê Bình, Quận Tân Bình"
    ,"Lat":10.793845
    ,"Long":106.656319
    ,"Polyline":"[106.65839386,10.79302025] ; [106.65827942,10.79292870] ; [106.65816498,10.79287529] ; [106.65793610,10.79303360] ; [106.65739441,10.79339218] ; [106.65712738,10.79357147] ; [106.65636444,10.79381847]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình),  đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65636444,10.79381847] ; [106.65579224,10.79391384] ; [106.65461731,10.79424000] ; [106.65505981,10.79458714]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Hội Chợ Tri ển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đường Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65505981,10.79458714] ; [106.65575409,10.79543114] ; [106.65519714,10.79608059]"
    ,"Distance":"215"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62), đường Xuân Hồng, Qu ận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65519714,10.79608059] ; [106.65519714,10.79608059] ; [106.65464783,10.79653263] ; [106.65386963,10.79587364] ; [106.65386963,10.79587364]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65386963,10.79587364] ; [106.65386963,10.79587364] ; [106.65312958,10.79512024] ; [106.65233612,10.79437923] ; [106.65233612,10.79437923]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1719"
    ,"Station_Code":"QTB 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"106, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.794182
    ,"Long":106.651191
    ,"Polyline":"[106.65233612,10.79437923] ; [106.65184021,10.79384041] ; [106.65165710,10.79380798] ; [106.65145111,10.79391003] ; [106.65115356,10.79411888]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1720"
    ,"Station_Code":"QTB 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà Thở Đắc Lộ"
    ,"Station_Address":"150, đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.794973
    ,"Long":106.649743
    ,"Polyline":"[106.65115356,10.79411888] ; [106.65038300,10.79452038] ; [106.64967346,10.79491615]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1301"
    ,"Station_Code":"QTB 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"162T, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796137
    ,"Long":106.647565
    ,"Polyline":"[106.64967346,10.79491615] ; [106.64884186,10.79538918] ; [106.64792633,10.79585838] ; [106.64751434,10.79607868]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1723"
    ,"Station_Code":"QTB 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Hội Chữ th ập đỏ Tân Bình"
    ,"Station_Address":"32, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.796322
    ,"Long":106.645591
    ,"Polyline":"[106.64751434,10.79607868] ; [106.64585876,10.79694366] ; [106.64559174,10.79634285]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1724"
    ,"Station_Code":"QTB 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Tr ần Quốc Toản"
    ,"Station_Address":"96 (L8-L10 ), đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.792597
    ,"Long":106.644241
    ,"Polyline":"[106.64559174,10.79634285] ; [106.64424133,10.79259682]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1722"
    ,"Station_Code":"QTB 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công viên  Bầu Cát"
    ,"Station_Address":"Đối diện 147B, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.790708
    ,"Long":106.643417
    ,"Polyline":"[106.64424133,10.79259682] ; [106.64397430,10.79179573] ; [106.64341736,10.79070759]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1726"
    ,"Station_Code":"QTB 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Bàu Cát 9"
    ,"Station_Address":"Đối diện 209, đường Đồng  Đen, Quận Tân Bình"
    ,"Lat":10.787754
    ,"Long":106.643091
    ,"Polyline":"[106.64341736,10.79070759] ; [106.64326477,10.79025173] ; [106.64306641,10.78974533] ; [106.64286041,10.78917122] ; [106.64302826,10.78821182] ; [106.64306641,10.78783226]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1725"
    ,"Station_Code":"QTB 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Hồng Lạc"
    ,"Station_Address":"Đối diên 313 (565), đường Hồng  Lạc, Quận Tân Bình"
    ,"Lat":10.786508
    ,"Long":106.642883
    ,"Polyline":"[106.64306641,10.78783226] ; [106.64314270,10.78780651] ; [106.64342499,10.78670502] ; [106.64288330,10.78650761]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1729"
    ,"Station_Code":"QTP 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường Trung Cấp CNTT Sài Gòn"
    ,"Station_Address":"14 (1333), đường Thoại Ngọc Hầu, Quận Tân Phú"
    ,"Lat":10.785255
    ,"Long":106.640594
    ,"Polyline":"[106.64288330,10.78650761] ; [106.64163971,10.78595161] ; [106.64059448,10.78525543]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1727"
    ,"Station_Code":"QTP 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"UBND Quận Tân Phú"
    ,"Station_Address":"Đối diện 65, đường Thoại Ngọc Hầu, Quận Tân Phú"
    ,"Lat":10.783206
    ,"Long":106.637779
    ,"Polyline":"[106.64059448,10.78525543] ; [106.63777924,10.78320599]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1731"
    ,"Station_Code":"QTP 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cafe Newmoom"
    ,"Station_Address":"124, đường Tho ại Ngọc Hầu, Quận Tân Phú"
    ,"Lat":10.781124
    ,"Long":106.635056
    ,"Polyline":"[106.63777924,10.78320599] ; [106.63731384,10.78289986] ; [106.63683319,10.78252125] ; [106.63636780,10.78207779] ; [106.63609314,10.78177261] ; [106.63505554,10.78112411]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1728"
    ,"Station_Code":"QTP 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Thoại Ngọc Hầu"
    ,"Station_Address":"6, đường Nguyễn S ơn, Quận Tân Phú"
    ,"Lat":10.78099
    ,"Long":106.633224
    ,"Polyline":"[106.63505554,10.78112411] ; [106.63422394,10.78069210.06.63322449]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1730"
    ,"Station_Code":"QTP 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Phan Văn Năm"
    ,"Station_Address":"98-100, đường Nguy ễn Sơn, Quận Tân Phú"
    ,"Lat":10.781983
    ,"Long":106.629768
    ,"Polyline":"[106.63322449,10.78098965] ; [106.63313293,10.78096676] ; [106.63215637,10.78120899] ; [106.63102722,10.78149891] ; [106.63064575,10.78158855] ; [106.62977600,10.78190422] ; [106.62976837,10.78198338]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1732"
    ,"Station_Code":"QTP 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Tân Phú"
    ,"Station_Address":"178, đường Nguyễn Sơn, Quận Tân Phú"
    ,"Lat":10.783249
    ,"Long":106.625412
    ,"Polyline":"[106.62976837,10.78198338] ; [106.62907410,10.78214169] ; [106.62878418,10.78215218] ; [106.62541199,10.78324890]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1733"
    ,"Station_Code":"QTP 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Phạm Văn  Xảo"
    ,"Station_Address":"302-304, đường Nguy ễn Sơn, Quận Tân Phú"
    ,"Lat":10.784016
    ,"Long":106.622986
    ,"Polyline":"[106.62541199,10.78324890] ; [106.62298584,10.78401566]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"1611"
    ,"Station_Code":"QTP 185"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Phú Thọ Hòa"
    ,"Station_Address":"333, đường Bình Long, Quận Tân Phú"
    ,"Lat":10.786708
    ,"Long":106.618011
    ,"Polyline":"[106.62298584,10.78401566] ; [106.62059784,10.78474426] ; [106.61968231,10.78478718] ; [106.61880493,10.78453350] ; [106.61853790,10.78536606] ; [106.61801147,10.78670788]"
    ,"Distance":"731"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"4310"
    ,"Station_Code":"QTPT207"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"131, Bình Long"
    ,"Station_Address":"131, đường Bình Long, Quận Tân Phú"
    ,"Lat":10.7901934433557
    ,"Long":106.61661380118
    ,"Polyline":"[106.61801147,10.78670788] ; [106.61730194,10.78821182] ; [106.61661530,10.79019356]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"4311"
    ,"Station_Code":"QTPT208"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"83, Bình Long"
    ,"Station_Address":"83, đường Bình Long, Quận Tân Phú"
    ,"Lat":10.7924461754853
    ,"Long":106.61576085871
    ,"Polyline":"[106.61661530,10.79019356] ; [106.61576080,10.79244614]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"3484"
    ,"Station_Code":"QTP 181"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"17, đường Bình Long, Quận Tân Phú"
    ,"Lat":10.795888
    ,"Long":106.614075
    ,"Polyline":"[106.61576080,10.79244614] ; [106.61407471,10.79588795]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2504"
    ,"Station_Code":"QBT 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Ngoại ngữ tin học Đại Tây Dương"
    ,"Station_Address":"597 (688/11), đư ờng Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.81341
    ,"Long":106.607353
    ,"Polyline":"[106.61407471,10.79588795] ; [106.60990906,10.80312443] ; [106.60863495,10.80542183] ; [106.60749054,10.80789852] ; [106.60745239,10.80810928] ; [106.60745239,10.80839443] ; [106.60754395,10.80945873] ; [106.60786438,10.81266212] ; [106.60797119,10.81292057] ; [106.60763550,10.81309414] ; [106.60730743,10.81331062] ; [106.60735321,10.81340981]"
    ,"Distance":"2180"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2505"
    ,"Station_Code":"QBT 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Gò Mây"
    ,"Station_Address":"665, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.814612
    ,"Long":106.605427
    ,"Polyline":"[106.60727692,10.81328964] ; [106.60588074,10.81414032] ; [106.60571289,10.81424999] ; [106.60568237,10.81431007] ; [106.60536194,10.81451988]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2521"
    ,"Station_Code":"QBT 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Ngân hàng Á Châu"
    ,"Station_Address":"787-745, đường Lê Trọng Tấn, Quận Bình  Tân"
    ,"Lat":10.815971
    ,"Long":106.603043
    ,"Polyline":"[106.60532379,10.81453991] ; [106.60404968,10.81529045] ; [106.60323334,10.81577015] ; [106.60299683,10.81587029]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"2520"
    ,"Station_Code":"QBT 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Công ty Bảo Châu"
    ,"Station_Address":"88 , đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815697
    ,"Long":106.594925
    ,"Polyline":"[106.60299683,10.81587029] ; [106.60191345,10.81610012] ; [106.60124969,10.81624031] ; [106.60106659,10.81622982] ; [106.60040283,10.81634998] ; [106.60018921,10.81634998] ; [106.59971619,10.81612968] ; [106.59950256,10.81604958] ; [106.59927368,10.81601048] ; [106.59806061,10.81591034] ; [106.59635925,10.81577969] ; [106.59493256,10.81567955]"
    ,"Distance":"911"
  },
  {
     "Route_Id":"33"
    ,"Station_Id":"6832"
    ,"Station_Code":"BX 75"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Khu dân cư  Bình Hưng Hòa B"
    ,"Station_Address":"Khu dân cư B ình Hưng Hòa B, đường Đường số 3, Quận Bình Tân"
    ,"Lat":10.806413
    ,"Long":106.588326
    ,"Polyline":"[106.59492493,10.81569672] ; [106.59404755,10.81565475] ; [106.59272766,10.81029129] ; [106.59083557,10.80081654] ; [106.58731842,10.80160713] ; [106.58832550,10.80641270]"
    ,"Distance":"2726"
  }]