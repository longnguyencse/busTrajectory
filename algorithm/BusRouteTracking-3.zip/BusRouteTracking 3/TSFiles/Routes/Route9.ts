export const Route9 =[
  {
     "Route_Id":"9"
    ,"Station_Id":"3043"
    ,"Station_Code":"BX 58"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hưng Long"
    ,"Station_Address":"ĐẦU BẾN HƯNG LONG, đường Quốc lộ 50, Huyện  Bình Chánh"
    ,"Lat":10.637669
    ,"Long":106.647307
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"672"
    ,"Station_Code":"HBC 225"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Nguyễn Văn Long"
    ,"Station_Address":"B10/21A, đường Hương Lộ 11, Huyện Bình Ch ánh"
    ,"Lat":10.639393
    ,"Long":106.644459
    ,"Polyline":"[106.64730835,10.63766861] ; [106.64446259,10.63939285]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"674"
    ,"Station_Code":"HBC 226"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Văn Thời"
    ,"Station_Address":"Đối diện C5/1A, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.640954
    ,"Long":106.6416
    ,"Polyline":"[106.64446259,10.63939285] ; [106.64160156,10.64095402]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"677"
    ,"Station_Code":"HBC 227"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm Xăng Hòa Hiệp"
    ,"Station_Address":"D12/18, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.642109
    ,"Long":106.639454
    ,"Polyline":"[106.64160156,10.64095402] ; [106.63945770,10.64210892]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"676"
    ,"Station_Code":"HBC 228"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Hốc Hưu"
    ,"Station_Address":"B1/6/15, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.643933
    ,"Long":106.636085
    ,"Polyline":"[106.63945770,10.64210892] ; [106.63608551,10.64393330]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"679"
    ,"Station_Code":"HBC 229"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Tân Liễu"
    ,"Station_Address":"B11/13, đường Hương Lộ 11, Huyện Bình  Chánh"
    ,"Lat":10.64601
    ,"Long":106.63219
    ,"Polyline":"[106.63608551,10.64393330] ; [106.63218689,10.64601040]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"678"
    ,"Station_Code":"HBC 230"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Hội Quán Thanh Niên"
    ,"Station_Address":"Đ/d Hội Quán Thanh Niên, đường Hương Lộ 11, Huyện B ình Chánh"
    ,"Lat":10.647491
    ,"Long":106.629481
    ,"Polyline":"[106.63218689,10.64601040] ; [106.62947845,10.64749146]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"681"
    ,"Station_Code":"HBC 231"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Ấp 2"
    ,"Station_Address":"C5/31, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.649242
    ,"Long":106.626177
    ,"Polyline":"[106.62947845,10.64749146] ; [106.62617493,10.64924240]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"680"
    ,"Station_Code":"HBC 232"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ủy ban nhân dân xã Hưng Long"
    ,"Station_Address":"Ủy ban nhân dân xã Hưng Long, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.651377
    ,"Long":106.622009
    ,"Polyline":"[106.62617493,10.64924240] ; [106.62200928,10.65137672]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"683"
    ,"Station_Code":"HBC 233"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ấp 3"
    ,"Station_Address":"C16A/25, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.652637
    ,"Long":106.619589
    ,"Polyline":"[106.62200928,10.65137672] ; [106.61959076,10.65263653]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"682"
    ,"Station_Code":"HBC 234"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trạm y tế xã Hưng Long"
    ,"Station_Address":"Trạm y tế xã Hưng Long, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.654008
    ,"Long":106.616789
    ,"Polyline":"[106.61959076,10.65263653] ; [106.61679077,10.65400791]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"685"
    ,"Station_Code":"HBC 235"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"An Phú Tây"
    ,"Station_Address":"D10/45, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.655869
    ,"Long":106.613104
    ,"Polyline":"[106.61679077,10.65400791] ; [106.61310577,10.65586853]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"684"
    ,"Station_Code":"HBC 236"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Phòng khám  Thanh Lịch"
    ,"Station_Address":"D12B/41, đư ờng Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.657329
    ,"Long":106.610223
    ,"Polyline":"[106.61310577,10.65586853] ; [106.61022186,10.65732861]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"687"
    ,"Station_Code":"HBC 237"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"chợ Hưng Long"
    ,"Station_Address":"Đối diện chợ Hưng Long,  đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.659011
    ,"Long":106.606768
    ,"Polyline":"[106.61022186,10.65732861] ; [106.60676575,10.65901089]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"686"
    ,"Station_Code":"HBC 238"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường Tân  Quý Tây"
    ,"Station_Address":"Trường Tân Quý  Tây, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.65996
    ,"Long":106.604794
    ,"Polyline":"[106.60676575,10.65901089] ; [106.60479736,10.65995979]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"689"
    ,"Station_Code":"HBC 239"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Mầm non B ông Sen"
    ,"Station_Address":"Mầm non Bông Sen , đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.662079
    ,"Long":106.600594
    ,"Polyline":"[106.60479736,10.65995979] ; [106.60059357,10.66207886]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"688"
    ,"Station_Code":"HBC 240"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Công ty Th ông Hương"
    ,"Station_Address":"9/6B, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.661831
    ,"Long":106.598958
    ,"Polyline":"[106.60059357,10.66207886] ; [106.60002136,10.66234779] ; [106.59896088,10.66183090]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"691"
    ,"Station_Code":"HBC 241"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Minh Quân"
    ,"Station_Address":"D17/20, đường  Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.66016
    ,"Long":106.595128
    ,"Polyline":"[106.59896088,10.66183090] ; [106.59513092,10.66016006]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"690"
    ,"Station_Code":"HBC 242"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Đình Phước Bình"
    ,"Station_Address":"12/11C, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.658599
    ,"Long":106.591721
    ,"Polyline":"[106.59513092,10.66016006] ; [106.59172058,10.65859890]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"693"
    ,"Station_Code":"HBC 243"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Xã Tân Quý Tây"
    ,"Station_Address":"Xã Tân Quý Tây, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.65726
    ,"Long":106.588524
    ,"Polyline":"[106.59172058,10.65859890] ; [106.58852386,10.65725994]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"692"
    ,"Station_Code":"HBC 244"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chùa Liên Hoa"
    ,"Station_Address":"Chùa Liên Hoa, đường Hương lộ 11, Huyện Bình Chánh"
    ,"Lat":10.656206
    ,"Long":106.586035
    ,"Polyline":"[106.58852386,10.65725994] ; [106.58603668,10.65620613]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"695"
    ,"Station_Code":"HBC 269"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bờ Kinh T12"
    ,"Station_Address":"B1/12, đường Đinh Đức Thiện, Huyện Bình  Chánh"
    ,"Lat":10.656101
    ,"Long":106.584646
    ,"Polyline":"[106.58603668,10.65620613] ; [106.58554840,10.65595341] ; [106.58517456,10.65578461] ; [106.58464813,10.65610123]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"694"
    ,"Station_Code":"HBC 270"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đinh Đức Thiện"
    ,"Station_Address":"1/11A, đường Đinh Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.657213
    ,"Long":106.582854
    ,"Polyline":"[106.58434296,10.65628529] ; [106.58285522,10.65721321]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"697"
    ,"Station_Code":"HBC 271"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Cửa hàng Thanh Thảo"
    ,"Station_Address":"D17/39, đường Đinh Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.658847
    ,"Long":106.580096
    ,"Polyline":"[106.58285522,10.65721321] ; [106.58069611,10.65848923]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"696"
    ,"Station_Code":"HBC 272"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bờ Kinh"
    ,"Station_Address":"Đối diện C13/41, đường Đinh Đức Thiện, Huyện Bình Ch ánh"
    ,"Lat":10.660903
    ,"Long":106.576663
    ,"Polyline":"[106.58009338,10.65884686] ; [106.57666016,10.66090298] ; [106.57666016,10.66090298]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"3435"
    ,"Station_Code":"HBC 273"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trịnh Như Khuê"
    ,"Station_Address":"Đối diện C10/13, đường Đinh  Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.663328
    ,"Long":106.571363
    ,"Polyline":"[106.57666016,10.66090298] ; [106.57494354,10.66189957] ; [106.57379150,10.66237926]"
    ,"Distance":"641"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"699"
    ,"Station_Code":"HBC 380"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Chợ Bình Chánh"
    ,"Station_Address":"D6/33, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.666301
    ,"Long":106.571835
    ,"Polyline":"[106.57379150,10.66237926] ; [106.57047272,10.66374969] ; [106.56990051,10.66477299] ; [106.57183838,10.66630077]"
    ,"Distance":"1082"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"698"
    ,"Station_Code":"HBC 381"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường Tr ần Đại Nghĩa"
    ,"Station_Address":"D6/18A, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.668742
    ,"Long":106.574904
    ,"Polyline":"[106.57183838,10.66630077] ; [106.57183838,10.66630077] ; [106.57490540,10.66874218]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"701"
    ,"Station_Code":"HBC 382"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trịnh Như Khuê"
    ,"Station_Address":"D10/68 , đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.670197
    ,"Long":106.576663
    ,"Polyline":"[106.57490540,10.66874218] ; [106.57666016,10.67019653]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"700"
    ,"Station_Code":"HBC 383"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ô tô Hải  Âu"
    ,"Station_Address":"C3/21F, đường Quốc l ộ 1A, Huyện Bình Chánh"
    ,"Lat":10.675522
    ,"Long":106.582333
    ,"Polyline":"[106.57666016,10.67019653] ; [106.58233643,10.67552185]"
    ,"Distance":"858"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"703"
    ,"Station_Code":"HBC 384"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Văn phòng Ấp 5"
    ,"Station_Address":"11/10, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.681405
    ,"Long":106.58928
    ,"Polyline":"[106.58568573,10.67840481] ; [106.58882904,10.68098831]"
    ,"Distance":"1003"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"3431"
    ,"Station_Code":"HBC 386"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Công ty Thiên Lộc"
    ,"Station_Address":"Đối diện D7/3B, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.68452
    ,"Long":106.59251
    ,"Polyline":"[106.58927917,10.68140507] ; [106.59250641,10.68451977]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"3432"
    ,"Station_Code":"HBC 387"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"An Phú Tây"
    ,"Station_Address":"359A/14, đường  Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.686876
    ,"Long":106.593695
    ,"Polyline":"[106.59250641,10.68451977] ; [106.59295654,10.68535328] ; [106.59355164,10.68650246] ; [106.59369659,10.68687630]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"702"
    ,"Station_Code":"HBC 388"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Nút giao Bình Thuận"
    ,"Station_Address":"194A/8, đường Quốc lộ 1A, Huyện Bình  Chánh"
    ,"Lat":10.691816
    ,"Long":106.595428
    ,"Polyline":"[106.59369659,10.68687630] ; [106.59542847,10.69181633]"
    ,"Distance":"582"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"704"
    ,"Station_Code":"HBC 389"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"45/2A, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.697161
    ,"Long":106.597059
    ,"Polyline":"[106.59542847,10.69181633] ; [106.59706116,10.69716072]"
    ,"Distance":"621"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"705"
    ,"Station_Code":"HBC 390"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C14/17, đường Quốc lộ 1A,  Huyện Bình Chánh"
    ,"Lat":10.70658
    ,"Long":106.598266
    ,"Polyline":"[106.59706116,10.69716072] ; [106.59758759,10.70018673] ; [106.59745789,10.70400238] ; [106.59826660,10.70658016]"
    ,"Distance":"1067"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"706"
    ,"Station_Code":"HBC 392"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã tư An Lạc"
    ,"Station_Address":"591 cầu đi bộ, đường Quốc lộ 1A, Huyện Bình  Chánh"
    ,"Lat":10.71359
    ,"Long":106.599564
    ,"Polyline":"[106.59826660,10.70658016] ; [106.59956360,10.71358967]"
    ,"Distance":"793"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"711"
    ,"Station_Code":"HBC 393"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trần Đại Nghĩa"
    ,"Station_Address":"591B (cầu bộ hành), đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.721333
    ,"Long":106.600948
    ,"Polyline":"[106.59956360,10.71358967] ; [106.59955597,10.71359062] ; [106.60029602,10.71768570] ; [106.60090637,10.72177696] ; [106.60094452,10.72133255]"
    ,"Distance":"974"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"708"
    ,"Station_Code":"QBT 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"849, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.724317
    ,"Long":106.602337
    ,"Polyline":"[106.60094452,10.72133255] ; [106.60090637,10.72177696] ; [106.60110474,10.72268295] ; [106.60160828,10.72348404] ; [106.60195160,10.72385311] ; [106.60215759,10.72420597] ; [106.60234070,10.72431660]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"712"
    ,"Station_Code":"QBT 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu An Lạc"
    ,"Station_Address":"771, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.726583
    ,"Long":106.605191
    ,"Polyline":"[106.60234070,10.72431660] ; [106.60257721,10.72475910.06.60305786] ; [10.72522354,106.60477448] ; [10.72641945,106.60519409]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"709"
    ,"Station_Code":"QBT 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"703 , đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72832
    ,"Long":106.607605
    ,"Polyline":"[106.60519409,10.72658253] ; [106.60601807,10.72725201] ; [106.60760498,10.72832012] ; [106.60760498,10.72832012]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"714"
    ,"Station_Code":"QBT 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ủy ban"
    ,"Station_Address":"631-637, đường Kinh Dương Vương, Quận  Bình Tân"
    ,"Lat":10.729977
    ,"Long":106.610255
    ,"Polyline":"[106.60760498,10.72832012] ; [106.60760498,10.72832012] ; [106.60823822,10.72869682] ; [106.60923004,10.72938728] ; [106.60974121,10.72972965] ; [106.61025238,10.72997665]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"710"
    ,"Station_Code":"QBT 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Lâm Thành"
    ,"Station_Address":"289 (561), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.734278
    ,"Long":106.61298
    ,"Polyline":"[106.61025238,10.72997665] ; [106.61050415,10.73048878] ; [106.61253357,10.73375130] ; [106.61298370,10.73427773]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"716"
    ,"Station_Code":"QBT 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"251(511), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.737541
    ,"Long":106.614906
    ,"Polyline":"[106.61298370,10.73427773] ; [106.61325073,10.73487854] ; [106.61454010,10.73712444] ; [106.61490631,10.73754120]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"713"
    ,"Station_Code":"QBT 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"Bệnh viện Triều An, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739665
    ,"Long":106.61687
    ,"Polyline":"[106.61490631,10.73754120] ; [106.61490631,10.73754120] ; [106.61528015,10.73815155] ; [106.61576080,10.73875809] ; [106.61632538,10.73920631] ; [106.61686707,10.73966503] ; [106.61686707,10.73966503]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"119"
    ,"Station_Code":"QBT 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.741035
    ,"Long":106.618468
    ,"Polyline":"[106.61686707,10.73966503] ; [106.61846924,10.74103546]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"4149"
    ,"Station_Code":"QBT 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"49-51 (317), Kinh Dương Vương"
    ,"Station_Address":"49-51 (317), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743396
    ,"Long":106.62136
    ,"Polyline":"[106.61846924,10.74103546] ; [106.62136078,10.74339581]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.62136078,10.74339581] ; [106.62225342,10.74422836] ; [106.62316132,10.74491882]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"718"
    ,"Station_Code":"Q6 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Cư xá Phú Lâm"
    ,"Station_Address":"799 (209), đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.74776
    ,"Long":106.626332
    ,"Polyline":"[106.62316132,10.74491882] ; [106.62333679,10.74515629] ; [106.62362671,10.74527264] ; [106.62384033,10.74534035] ; [106.62398529,10.74553013] ; [106.62394714,10.74564648] ; [106.62432098,10.74612045] ; [106.62524414,10.74691677] ; [106.62580872,10.74739075] ; [106.62633514,10.74775982]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"715"
    ,"Station_Code":"Q6 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"685 (157), đ ường Kinh Dương Vương, Quận 6"
    ,"Lat":10.748877
    ,"Long":106.627727
    ,"Polyline":"[106.62633514,10.74775982] ; [106.62633514,10.74775982] ; [106.62679291,10.74818134] ; [106.62728882,10.74856091] ; [106.62772369,10.74887657] ; [106.62772369,10.74887657]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"720"
    ,"Station_Code":"Q6 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"93, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.751201
    ,"Long":106.630753
    ,"Polyline":"[106.62772369,10.74887657] ; [106.62772369,10.74887657] ; [106.62864685,10.74957848] ; [106.63020325,10.75082684] ; [106.63075256,10.75120068] ; [106.63075256,10.75120068]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"717"
    ,"Station_Code":"Q6 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"21A-21B, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.753246
    ,"Long":106.633521
    ,"Polyline":"[106.63075256,10.75120068] ; [106.63075256,10.75120068] ; [106.63143158,10.75178146] ; [106.63230133,10.75249290] ; [106.63298798,10.75294590] ; [106.63352203,10.75324631] ; [106.63352203,10.75324631]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"724"
    ,"Station_Code":"Q6 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Cầu Ông Buông"
    ,"Station_Address":"963, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754548
    ,"Long":106.637995
    ,"Polyline":"[106.63352203,10.75324631] ; [106.63393402,10.75367355] ; [106.63417816,10.75380516] ; [106.63444519,10.75366211] ; [106.63468933,10.75375748] ; [106.63482666,10.75403118] ; [106.63520050,10.75432110.06.63577271] ; [10.75441647,106.63697815] ; [10.75450134,106.63749695] ; [10.75459576,106.63799286]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"719"
    ,"Station_Code":"Q6 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngân hàng ACB"
    ,"Station_Address":"871, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754295
    ,"Long":106.641245
    ,"Polyline":"[106.63799286,10.75454807] ; [106.63799286,10.75454807] ; [106.63817596,10.75458622] ; [106.63922882,10.75454235] ; [106.64124298,10.75429535] ; [106.64124298,10.75429535]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"721"
    ,"Station_Code":"Q6 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Trường Nguy ễn Đức Cảnh"
    ,"Station_Address":"799, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754021
    ,"Long":106.644003
    ,"Polyline":"[106.64124298,10.75429535] ; [106.64124298,10.75429535] ; [106.64299011,10.75414753] ; [106.64400482,10.75402069] ; [106.64400482,10.75402069]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"723"
    ,"Station_Code":"Q6 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Chùa Nam Phổ Đà"
    ,"Station_Address":"735, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753789
    ,"Long":106.645955
    ,"Polyline":"[106.64400482,10.75402069] ; [106.64595795,10.75378895]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"722"
    ,"Station_Code":"Q6 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"647, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753647
    ,"Long":106.647323
    ,"Polyline":"[106.64595795,10.75378895] ; [106.64595795,10.75378895] ; [106.64595795,10.75378895] ; [106.64668274,10.75370979] ; [106.64732361,10.75364685] ; [106.64732361,10.75364685] ; [106.64732361,10.75364685]"
    ,"Distance":"151"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.64732361,10.75364685] ; [106.65072632,10.75331974] ; [106.65233612,10.75333118]"
    ,"Distance":"550"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65233612,10.75333118] ; [106.65377045,10.75363064] ; [106.65330505,10.75169659] ; [106.65313721,10.75147057] ; [106.65296936,10.75133324] ; [106.65256500,10.75125313]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB  CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"621"
    ,"Station_Code":"Q6 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường Võ Văn Tần"
    ,"Station_Address":"96-98, đường Phạm Đình Hổ, Quận 6"
    ,"Lat":10.752271
    ,"Long":106.64975
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65221405,10.75122738] ; [106.65207672,10.75117493] ; [106.65200043,10.75107479] ; [106.65099335,10.75101185] ; [106.64961243,10.75117493] ; [106.64974976,10.75227070]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"620"
    ,"Station_Code":"Q11 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cây Mai"
    ,"Station_Address":"384, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753689
    ,"Long":106.64926
    ,"Polyline":"[106.64974976,10.75227070] ; [106.64984131,10.75363636] ; [106.64926147,10.75368881]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"622"
    ,"Station_Code":"Q11 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"508, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753952
    ,"Long":106.646787
    ,"Polyline":"[106.64926147,10.75368881] ; [106.64678955,10.75395203]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"624"
    ,"Station_Code":"Q11 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"638-640 , đường Hồng Bàng, Quận 11"
    ,"Lat":10.754232
    ,"Long":106.644368
    ,"Polyline":"[106.64678955,10.75395203] ; [106.64678955,10.75395203] ; [106.64557648,10.75405788] ; [106.64437103,10.75423241] ; [106.64437103,10.75423241]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"625"
    ,"Station_Code":"Q11 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chùa Huê Lâm"
    ,"Station_Address":"690 (138), đường  Hồng Bàng, Quận 11"
    ,"Lat":10.754558
    ,"Long":106.641229
    ,"Polyline":"[106.64437103,10.75423241] ; [106.64278412,10.75437450] ; [106.64122772,10.75455761]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"623"
    ,"Station_Code":"Q11 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"786, đường Hồng Bàng, Quận  11"
    ,"Lat":10.75477
    ,"Long":106.638428
    ,"Polyline":"[106.64122772,10.75455761] ; [106.63910675,10.75477982] ; [106.63842773,10.75477028]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"626"
    ,"Station_Code":"Q6 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Mạc Đỉnh Chi"
    ,"Station_Address":"832-834, đường Hồng Bàng,  Quận 6"
    ,"Lat":10.754732
    ,"Long":106.635574
    ,"Polyline":"[106.63842773,10.75477028] ; [106.63761139,10.75486374] ; [106.63706207,10.75479031] ; [106.63665771,10.75483799] ; [106.63618469,10.75483227] ; [106.63591766,10.75480652] ; [106.63557434,10.75473213]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"627"
    ,"Station_Code":"Q6 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"528 , đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.753346
    ,"Long":106.633365
    ,"Polyline":"[106.63557434,10.75473213] ; [106.63557434,10.75473213] ; [106.63470459,10.75426292] ; [106.63449860,10.75430012] ; [106.63428497,10.75424767] ; [106.63415527,10.75408459] ; [106.63415527,10.75385761] ; [106.63336182,10.75334644]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"629"
    ,"Station_Code":"Q6 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"94-96, đường Kinh Dương  Vương, Quận 6"
    ,"Lat":10.749589
    ,"Long":106.628435
    ,"Polyline":"[106.63336182,10.75334644] ; [106.62843323,10.74958897]"
    ,"Distance":"682"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"1386"
    ,"Station_Code":"Q6 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Công Viên Phú Lâm"
    ,"Station_Address":"Đối diện 907, đư ờng Kinh Dương Vương, Quận 6"
    ,"Lat":10.746384
    ,"Long":106.624525
    ,"Polyline":"[106.62843323,10.74958897] ; [106.62647247,10.74799728] ; [106.62452698,10.74638367]"
    ,"Distance":"557"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường  Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62452698,10.74638367] ; [106.62425995,10.74613094] ; [106.62394714,10.74568367] ; [106.62385559,10.74570942] ; [106.62377167,10.74571514] ; [106.62369537,10.74569416] ; [106.62362671,10.74564075] ; [106.62349701,10.74558353] ; [106.62332153,10.74547291] ; [106.62266541,10.74488258] ; [106.62247467,10.74474621]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đư ờng Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62143707,10.74389172] ; [106.62039948,10.74309158]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"4150"
    ,"Station_Code":"QBT 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"428, Kinh  Dương Vương"
    ,"Station_Address":"428, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.741383
    ,"Long":106.618377
    ,"Polyline":"[106.62039948,10.74309158] ; [106.61966705,10.74241066] ; [106.61837769,10.74138260]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"630"
    ,"Station_Code":"QBT 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"480, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739675
    ,"Long":106.616392
    ,"Polyline":"[106.61837769,10.74138260] ; [106.61790466,10.74094009] ; [106.61639404,10.73967457]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"631"
    ,"Station_Code":"QBT 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"548, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.735138
    ,"Long":106.613144
    ,"Polyline":"[106.61639404,10.73967457] ; [106.61544800,10.73885250] ; [106.61504364,10.73830509] ; [106.61314392,10.73513794]"
    ,"Distance":"623"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"632"
    ,"Station_Code":"QBT 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"SinCo"
    ,"Station_Address":"Đối diện nhà trọ Thanh Trường, đường Kinh Dương Vương, Quận Bình  Tân"
    ,"Lat":10.731674
    ,"Long":106.611028
    ,"Polyline":"[106.61314392,10.73513794] ; [106.61103058,10.73167419]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"633"
    ,"Station_Code":"QBT 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Hoa hồng"
    ,"Station_Address":"620, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729014
    ,"Long":106.608276
    ,"Polyline":"[106.61103058,10.73167419] ; [106.61064148,10.73102093] ; [106.61013794,10.73030376] ; [106.60967255,10.72996712] ; [106.60827637,10.72901440]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"634"
    ,"Station_Code":"QBT 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"676, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72733
    ,"Long":106.605751
    ,"Polyline":"[106.60827637,10.72901440] ; [106.60706329,10.72817993] ; [106.60575104,10.72733021]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"635"
    ,"Station_Code":"QBT 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Thời trang"
    ,"Station_Address":"724, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.725466
    ,"Long":106.603027
    ,"Polyline":"[106.60575104,10.72733021] ; [106.60440826,10.72639847] ; [106.60302734,10.72546577]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"636"
    ,"Station_Code":"HBC 362"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Bãi xe Ph ương Trang"
    ,"Station_Address":"Bãi xe Phương Trang, đường Quốc lộ 1A , Huyện Bình Chánh"
    ,"Lat":10.721333
    ,"Long":106.600379
    ,"Polyline":"[106.60302734,10.72546577] ; [106.60277557,10.72525501] ; [106.60255432,10.72497559] ; [106.60186768,10.72414780] ; [106.60152435,10.72396374] ; [106.60144806,10.72397423] ; [106.60136414,10.72394753] ; [106.60128784,10.72391605] ; [106.60123444,10.72383213] ; [106.60118103,10.72373676] ; [106.60116577,10.72363186] ; [106.60114288,10.72350502] ; [106.60109711,10.72337341] ; [106.60076904,10.72232914] ; [106.60053253,10.72180748] ; [106.60037231,10.72127533] ; [106.60033417,10.72101212]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"637"
    ,"Station_Code":"HBC 363"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Hưng Nhơn"
    ,"Station_Address":"B1/5, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.71328
    ,"Long":106.598904
    ,"Polyline":"[106.60033417,10.72101212] ; [106.60005188,10.71951962]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"638"
    ,"Station_Code":"HBC 364"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C3/4, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.70706
    ,"Long":106.598089
    ,"Polyline":"[106.60005188,10.71951962] ; [106.59968567,10.71702194] ; [106.59925842,10.71448612] ; [106.59899139,10.71319485] ; [106.59877777,10.71189880] ; [106.59861755,10.71048546] ; [106.59847260,10.70945263]"
    ,"Distance":"1134"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"639"
    ,"Station_Code":"HBC 365"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"Kế E9/21, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.696064
    ,"Long":106.596496
    ,"Polyline":"[106.59847260,10.70945263] ; [106.59816742,10.70752335] ; [106.59786224,10.70595264] ; [106.59727478,10.70433998] ; [106.59706116,10.70279026] ; [106.59724426,10.70028114] ; [106.59719849,10.69917393] ; [106.59671783,10.69681263] ; [106.59539795,10.69269562]"
    ,"Distance":"1912"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"640"
    ,"Station_Code":"HBC 366"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nút giao Bình Thuận"
    ,"Station_Address":"D1/25, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.691884
    ,"Long":106.595101
    ,"Polyline":"[106.59539795,10.69269562] ; [106.59469604,10.69044495] ; [106.59394073,10.68824673]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"3422"
    ,"Station_Code":"HBC 367"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"An Phú Tây"
    ,"Station_Address":"38A, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.687614
    ,"Long":106.593717
    ,"Polyline":"[106.59394073,10.68824673] ; [106.59363556,10.68707180] ; [106.59314728,10.68596458] ; [106.59284973,10.68543720] ; [106.59225464,10.68460464] ; [106.59150696,10.68376637]"
    ,"Distance":"574"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"641"
    ,"Station_Code":"HBC 368"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Văn phòng Ấp 5"
    ,"Station_Address":"C11/12, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.681494
    ,"Long":106.588969
    ,"Polyline":"[106.59150696,10.68376637] ; [106.58949280,10.68177891] ; [106.58904266,10.68139362]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"643"
    ,"Station_Code":"HBC 369"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Ô tô Hải Âu"
    ,"Station_Address":"Ô tô Hải  Âu, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.676528
    ,"Long":106.583154
    ,"Polyline":"[106.58904266,10.68139362] ; [106.58616638,10.67899036]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"642"
    ,"Station_Code":"HBC 370"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Bùi Thanh  Khiết"
    ,"Station_Address":"C4/26A, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.673877
    ,"Long":106.580247
    ,"Polyline":"[106.58616638,10.67899036] ; [106.58354187,10.67677116] ; [106.58186340,10.67527866]"
    ,"Distance":"627"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"644"
    ,"Station_Code":"HBC 371"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trịnh Như  Khuê"
    ,"Station_Address":"A17/8, đường Quốc  lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.670561
    ,"Long":106.576653
    ,"Polyline":"[106.58186340,10.67527866] ; [106.57922363,10.67267513]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"645"
    ,"Station_Code":"HBC 372"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường Trần Đại Nghĩa"
    ,"Station_Address":"A16/4, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.668874
    ,"Long":106.57455
    ,"Polyline":"[106.57922363,10.67267513] ; [106.57814789,10.67154694] ; [106.57673645,10.67043495] ; [106.57533264,10.66925907]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"646"
    ,"Station_Code":"HBC 373"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Bình Chánh"
    ,"Station_Address":"A13/7,  đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.66647
    ,"Long":106.571503
    ,"Polyline":"[106.57533264,10.66925907] ; [106.57173920,10.66637516]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"647"
    ,"Station_Code":"HBC 274"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trịnh Như  Khuê"
    ,"Station_Address":"C10/13, đường Đinh Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.663265
    ,"Long":106.571159
    ,"Polyline":"[106.57173920,10.66637516] ; [106.56974792,10.66481495] ; [106.57038116,10.66364956] ; [106.57086182,10.66340733] ; [106.57330322,10.66245842]"
    ,"Distance":"772"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"648"
    ,"Station_Code":"HBC 275"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Bờ Kinh"
    ,"Station_Address":"C13/38, đường Đinh Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.660914
    ,"Long":106.5764
    ,"Polyline":"[106.57330322,10.66245842] ; [106.57489014,10.66181564] ; [106.57605743,10.66112518]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"649"
    ,"Station_Code":"HBC 276"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Điện máy Lộc Đức"
    ,"Station_Address":"C15/47, đường Đinh Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.658794
    ,"Long":106.579973
    ,"Polyline":"[106.57605743,10.66112518] ; [106.58058167,10.65841961]"
    ,"Distance":"579"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"650"
    ,"Station_Code":"HBC 277"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Công ty Tia Sáng"
    ,"Station_Address":"C17/53, đường Đinh Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.657171
    ,"Long":106.582661
    ,"Polyline":"[106.58058167,10.65841961] ; [106.58306885,10.65691757]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"651"
    ,"Station_Code":"HBC 278"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Bờ Kinh T12"
    ,"Station_Address":"D1/8, đường Đinh Đức Thiện, Huyện Bình Chánh"
    ,"Lat":10.656021
    ,"Long":106.584538
    ,"Polyline":"[106.58306885,10.65691757] ; [106.58380127,10.65647984] ; [106.58454132,10.65602112]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"653"
    ,"Station_Code":"HBC 245"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa Liên Hoa"
    ,"Station_Address":"Đối diện Chùa Liên Hoa, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.656058
    ,"Long":106.586008
    ,"Polyline":"[106.58454132,10.65602112] ; [106.58516693,10.65567303] ; [106.58563995,10.65590477]"
    ,"Distance":"137"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"652"
    ,"Station_Code":"HBC 246"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Xã Tân Quý Tây"
    ,"Station_Address":"D5/12, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.657102
    ,"Long":106.588406
    ,"Polyline":"[106.58563995,10.65590477] ; [106.58734894,10.65666962]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"655"
    ,"Station_Code":"HBC 247"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Đình Phước Bình"
    ,"Station_Address":"D7/7B , đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.658441
    ,"Long":106.591641
    ,"Polyline":"[106.58734894,10.65666962] ; [106.58928680,10.65746593]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"654"
    ,"Station_Code":"HBC 248"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Minh Quân"
    ,"Station_Address":"D10/9, đường Hương Lộ 11 , Huyện Bình Chánh"
    ,"Lat":10.659975
    ,"Long":106.594999
    ,"Polyline":"[106.59164429,10.65844059] ; [106.59500122,10.65997505]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"657"
    ,"Station_Code":"HBC 249"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Công ty Thông Hương"
    ,"Station_Address":"D12/1, đường Hương Lộ 11, Huyện Bình  Chánh"
    ,"Lat":10.661657
    ,"Long":106.598877
    ,"Polyline":"[106.59500122,10.65997505] ; [106.59887695,10.66165733]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"656"
    ,"Station_Code":"HBC 250"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Mầm non Bông Sen"
    ,"Station_Address":"Đối diện Mầm non Bông Sen , đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.66191
    ,"Long":106.600685
    ,"Polyline":"[106.59887695,10.66165733] ; [106.60007477,10.66225815] ; [106.60068512,10.66191006]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"659"
    ,"Station_Code":"HBC 251"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Hương lộ 11"
    ,"Station_Address":"D16/17A, đường Hương Lộ  11, Huyện Bình Chánh"
    ,"Lat":10.659912
    ,"Long":106.604617
    ,"Polyline":"[106.60068512,10.66191006] ; [106.60461426,10.65991211]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"658"
    ,"Station_Code":"HBC 252"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Chợ Hưng Long"
    ,"Station_Address":"D16/34 - D16/39, đường Hương Lộ 11, Huyện  Bình Chánh"
    ,"Lat":10.658847
    ,"Long":106.606822
    ,"Polyline":"[106.60461426,10.65991211] ; [106.60681915,10.65884686]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"661"
    ,"Station_Code":"HBC 253"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Phòng khám Thanh Lịch"
    ,"Station_Address":"577, đường Hương Lộ 11, Huyện Bình Ch ánh"
    ,"Lat":10.657118
    ,"Long":106.610336
    ,"Polyline":"[106.60681915,10.65884686] ; [106.61033630,10.65711784]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"660"
    ,"Station_Code":"HBC 254"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Trạm xăng dầu Mười Vũ"
    ,"Station_Address":"Cột điện 73PTrạm xăng dầu Mười Vũ, đường Hương Lộ 11 , Huyện Bình Chánh"
    ,"Lat":10.655631
    ,"Long":106.613297
    ,"Polyline":"[106.61033630,10.65711784] ; [106.61329651,10.65563107]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"662"
    ,"Station_Code":"HBC 255"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Trạm y tế xã Hưng Long"
    ,"Station_Address":"D3/46, đường Hương Lộ 11, Huyện Bình  Chánh"
    ,"Lat":10.653823
    ,"Long":106.616902
    ,"Polyline":"[106.61329651,10.65563107] ; [106.61690521,10.65382290]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"663"
    ,"Station_Code":"HBC 256"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Đường liên ấp 3-4-5"
    ,"Station_Address":"C14/26, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.652584
    ,"Long":106.619316
    ,"Polyline":"[106.61690521,10.65382290] ; [106.61931610,10.65258408]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"664"
    ,"Station_Code":"HBC 257"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Trường mầm non Quỳnh Anh"
    ,"Station_Address":"C3/28 (Trường mầm non Quỳnh Anh), đường Hương Lộ 11, Huyện Bình  Chánh"
    ,"Lat":10.651055
    ,"Long":106.622229
    ,"Polyline":"[106.61931610,10.65258408] ; [106.62223053,10.65105534]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"665"
    ,"Station_Code":"HBC 258"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Ấp 2"
    ,"Station_Address":"C7/32, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.648968
    ,"Long":106.626386
    ,"Polyline":"[106.62223053,10.65105534] ; [106.62638855,10.64896774]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"4159"
    ,"Station_Code":"HBC 259"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Hội Quán Thanh Niên"
    ,"Station_Address":"Hội Quán Thanh Niên, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.64747
    ,"Long":106.629074
    ,"Polyline":"[106.62638855,10.64896774] ; [106.62907410,10.64747047]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"667"
    ,"Station_Code":"HBC 260"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Tân Liễu"
    ,"Station_Address":"B1/14B, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.645615
    ,"Long":106.632668
    ,"Polyline":"[106.62907410,10.64747047] ; [106.63266754,10.64561462]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"666"
    ,"Station_Code":"HBC 261"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Hốc Hưu"
    ,"Station_Address":"B13/14A, đường  Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.644028
    ,"Long":106.635656
    ,"Polyline":"[106.63266754,10.64561462] ; [106.63565826,10.64402771]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"669"
    ,"Station_Code":"HBC 262"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trạm Xăng Hòa  Hiệp"
    ,"Station_Address":"Đối diện B2/18, đ ường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.641819
    ,"Long":106.639711
    ,"Polyline":"[106.63565826,10.64402771] ; [106.63970947,10.64181900]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"668"
    ,"Station_Code":"HBC 263"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Nguyễn Văn  Thời"
    ,"Station_Address":"Trụ điện 142B, đư ờng Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.640617
    ,"Long":106.641948
    ,"Polyline":"[106.63970947,10.64181900] ; [106.64194489,10.64061737]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"671"
    ,"Station_Code":"HBC 264"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Nguyễn Văn  Long"
    ,"Station_Address":"Đối diện Trường Quy  Đức, đường Hương Lộ 11, Huyện Bình Chánh"
    ,"Lat":10.639399
    ,"Long":106.644271
    ,"Polyline":"[106.64194489,10.64061737] ; [106.64427185,10.63939857]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"9"
    ,"Station_Id":"3043"
    ,"Station_Code":"BX 58"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Hưng Long"
    ,"Station_Address":"ĐẦU BẾN HƯNG LONG, đường Quốc lộ 50,  Huyện Bình Chánh"
    ,"Lat":10.637669
    ,"Long":106.647307
    ,"Polyline":"[106.64427185,10.63939857] ; [106.64730835,10.63766861]"
    ,"Distance":"384"
  }]