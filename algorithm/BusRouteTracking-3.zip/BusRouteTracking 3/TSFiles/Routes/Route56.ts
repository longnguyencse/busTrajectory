export const Route56 =[

  {
     "Route_Id":"56"
    ,"Station_Id":"6844"
    ,"Station_Code":"BX 77"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Làng báo chí"
    ,"Station_Address":"Gần Hẻm 76, đường Nguyễn Văn Hưởng, Quận  2"
    ,"Lat":10.809105
    ,"Long":106.732419
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7117"
    ,"Station_Code":"Q2 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Làng báo chí"
    ,"Station_Address":"89-91  , đường Thảo Điền, Quận 2"
    ,"Lat":10.807208
    ,"Long":106.734173
    ,"Polyline":"[106.73242188,10.80910492] ; [106.73240662,10.80900478] ; [106.73376465,10.80779362] ; [106.73417664,10.80720806]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7115"
    ,"Station_Code":"Q2 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Quốc Hương - Lê Văn Miến"
    ,"Station_Address":"17-19 , đường  Lê Văn Miến, Quận 2"
    ,"Lat":10.804785
    ,"Long":106.732001
    ,"Polyline":"[106.73417664,10.80720806] ; [106.73540497,10.80602264] ; [106.73200226,10.80478477]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7113"
    ,"Station_Code":"Q2 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cục hậu cần Quân Khu 7"
    ,"Station_Address":"Đối diện CGV Thảo Điền Pearl, đường Quốc Hương, Quận 2"
    ,"Lat":10.801428
    ,"Long":106.732661
    ,"Polyline":"[106.73200226,10.80478477] ; [106.73149872,10.80459976] ; [106.73194122,10.80325127] ; [106.73225403,10.80327225] ; [106.73265839,10.80142784]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7120"
    ,"Station_Code":"Q2 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Công viên dạ cầu Sài Gòn"
    ,"Station_Address":"Cà phê Rita Võ, đường Trần Não, Quận 2"
    ,"Lat":10.798382
    ,"Long":106.732752
    ,"Polyline":"[106.73265839,10.80142784] ; [106.73265839,10.80092239] ; [106.72938538,10.80064774] ; [106.72918701,10.80036354] ; [106.72940063,10.79886723] ; [106.72963715,10.79866695] ; [106.72987366,10.79860401] ; [106.73135376,10.79884624] ; [106.73154449,10.79874039] ; [106.73141479,10.79792881] ; [106.73274994,10.79838181]"
    ,"Distance":"1118"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7112"
    ,"Station_Code":"Q2 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Trắng"
    ,"Station_Address":"Kế số 29, đường Song Hành, Quận 2"
    ,"Lat":10.799995
    ,"Long":106.737489
    ,"Polyline":"[106.73274994,10.79838181] ; [106.73334503,10.79871941] ; [106.73349762,10.79901505] ; [106.73359680,10.79934120] ; [106.73748779,10.79999542]"
    ,"Distance":"582"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7109"
    ,"Station_Code":"Q2 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Chung cư cao  ốc An Cư"
    ,"Station_Address":"08, đường Thái Thuận, Quận 2"
    ,"Lat":10.798198
    ,"Long":106.73906
    ,"Polyline":"[106.73748779,10.79999542] ; [106.73824310,10.80016899] ; [106.73862457,10.79814529] ; [106.73905945,10.79819775]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7108"
    ,"Station_Code":"Q2 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Metro An Phú"
    ,"Station_Address":"01, đường Vũ  Tông Phan, Quận 2"
    ,"Lat":10.797961
    ,"Long":106.743706
    ,"Polyline":"[106.73905945,10.79819775] ; [106.73905945,10.79819775] ; [106.74020386,10.79845047] ; [106.74031830,10.79791355] ; [106.74053955,10.79782867] ; [106.74147797,10.79831409] ; [106.74207306,10.79715443] ; [106.74301910,10.79760265] ; [106.74370575,10.79796124] ; [106.74370575,10.79796124]"
    ,"Distance":"676"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7106"
    ,"Station_Code":"Q2 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chung Cư Bình Khánh"
    ,"Station_Address":"86 - 88 , đ ường Nguyễn Hoàng, Quận 2"
    ,"Lat":10.795315
    ,"Long":106.745095
    ,"Polyline":"[106.74370575,10.79796124] ; [106.74456787,10.79842949] ; [106.74509430,10.79531479]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4073"
    ,"Station_Code":"Q2 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Công An phường An Phú"
    ,"Station_Address":"268, đường Nguyễn Hoàng, Quận 2"
    ,"Lat":10.792064
    ,"Long":106.745787
    ,"Polyline":"[106.74509430,10.79531479] ; [106.74578857,10.79206371]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2980"
    ,"Station_Code":"Q2 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"Đối diện siêu thị điện máy Chợ Lớn, đường  Lương Định Của, Quận 2"
    ,"Lat":10.791052
    ,"Long":106.745251
    ,"Polyline":"[106.74578857,10.79206371] ; [106.74597931,10.79121590] ; [106.74525452,10.79105186]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4065"
    ,"Station_Code":"Q2 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà hàng Ca Dao"
    ,"Station_Address":"333, đường Lương Định Của, Quận 2"
    ,"Lat":10.790178
    ,"Long":106.741211
    ,"Polyline":"[106.74525452,10.79105186] ; [106.74121094,10.79017830]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4070"
    ,"Station_Code":"Q2 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Chùa Huệ Nghiêm"
    ,"Station_Address":"Kế 22/4B, đường Lương Định Của, Quận 2"
    ,"Lat":10.789572
    ,"Long":106.738459
    ,"Polyline":"[106.74121094,10.79017830] ; [106.74050140,10.78996658] ; [106.73845673,10.78957176]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2981"
    ,"Station_Code":"Q2 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"C ột điện UD21, đường Lương Định Của, Quận 2"
    ,"Lat":10.788312
    ,"Long":106.735268
    ,"Polyline":"[106.73827362,10.78948021] ; [106.73732758,10.78925037] ; [106.73693085,10.78909969] ; [106.73651886,10.78888035] ; [106.73538208,10.78827953]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2984"
    ,"Station_Code":"Q2 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Đình Bình  Khánh"
    ,"Station_Address":"16/2, đường Lương  Định Của, Quận 2"
    ,"Lat":10.78709
    ,"Long":106.73295
    ,"Polyline":"[106.73526764,10.78831196] ; [106.73294830,10.78709030]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2983"
    ,"Station_Code":"Q2 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trần Não"
    ,"Station_Address":"F2, đường Lương Định Của, Quận 2"
    ,"Lat":10.785555
    ,"Long":106.730072
    ,"Polyline":"[106.73294830,10.78709030] ; [106.73244476,10.78674221] ; [106.73159027,10.78628826] ; [106.73065186,10.78580379] ; [106.73007202,10.78555489]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"3989"
    ,"Station_Code":"Q2 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Khu đô thị Sala"
    ,"Station_Address":"Đối diện Khu  đô thị Sala, đường Mai Chí Thọ, Quận 2"
    ,"Lat":10.773183
    ,"Long":106.721642
    ,"Polyline":"[106.73007202,10.78555489] ; [106.72947693,10.78499794] ; [106.72908783,10.78251076] ; [106.72869873,10.78179359] ; [106.72834015,10.77987576] ; [106.72808075,10.77909565] ; [106.72803497,10.77833652] ; [106.72824860,10.77759933] ; [106.72805786,10.77650261] ; [106.72164154,10.77318287]"
    ,"Distance":"1856"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2888"
    ,"Station_Code":"Q1 168"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Chợ Dân Sinh"
    ,"Station_Address":"98 , đường Ký Con, Quận 1"
    ,"Lat":10.767259
    ,"Long":106.698505
    ,"Polyline":"[106.72164154,10.77318287] ; [106.71565247,10.77129650] ; [106.70681763,10.76986313] ; [106.70265961,10.76856041] ; [106.70125580,10.76684856] ; [106.70003510,10.76560497] ; [106.69850159,10.76725864]"
    ,"Distance":"2830"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"38"
    ,"Station_Code":"Q1TC1D"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Bến Thành D"
    ,"Station_Address":"B ến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770603
    ,"Long":106.698441
    ,"Polyline":"[106.69850159,10.76725864] ; [106.69653320,10.76921940] ; [106.69750214,10.77025795] ; [106.69844055,10.77060318]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69844055,10.77060318] ; [106.69910431,10.77093792] ; [106.69956207,10.77094269]"
    ,"Distance":"132"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77094269] ; [106.70195770,10.77082157]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4271"
    ,"Station_Code":"Q1 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Đền Thờ Ấn Giáo, Pasteur"
    ,"Station_Address":"Đền Thờ Ấn Giáo, đường Pasteur, Quận 1"
    ,"Lat":10.773595
    ,"Long":106.70139
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70257568,10.77080059] ; [106.70139313,10.77359486]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2724"
    ,"Station_Code":"Q1 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Lê Thánh Tôn"
    ,"Station_Address":"144, đường Pasteur, Quận 1"
    ,"Lat":10.775088
    ,"Long":106.700768
    ,"Polyline":"[106.70139313,10.77359486] ; [106.70076752,10.77508831]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4272"
    ,"Station_Code":"Q1 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Lý Tự Trọng"
    ,"Station_Address":"158, đường Pasteur, Quận 1"
    ,"Lat":10.777089
    ,"Long":106.699657
    ,"Polyline":"[106.70076752,10.77508831] ; [106.69995117,10.77685070] ; [106.69965363,10.77708912]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4273"
    ,"Station_Code":"Q1 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Công viên  30/4"
    ,"Station_Address":"178, đường Pasteur , Quận 1"
    ,"Lat":10.778307999999999
    ,"Long":106.698333
    ,"Polyline":"[106.69965363,10.77708912] ; [106.69833374,10.77830791]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2692"
    ,"Station_Code":"Q1 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà thờ Đức Bà"
    ,"Station_Address":"47, đường Lê Duẩn, Quận 1"
    ,"Lat":10.780794
    ,"Long":106.69912
    ,"Polyline":"[106.69833374,10.77830791] ; [106.69752502,10.77907467] ; [106.69836426,10.77999115] ; [106.69848633,10.78009129] ; [106.69857788,10.78005505] ; [106.69866180,10.78008080] ; [106.69872284,10.78016567] ; [106.69872284,10.78023911] ; [106.69870758,10.78031826] ; [106.69911957,10.78079414]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2029"
    ,"Station_Code":"Q1 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cty Xổ Số Kiến Thiết"
    ,"Station_Address":"Sofitel Plaza, đường Lê Duẩn, Quận 1"
    ,"Lat":10.78417
    ,"Long":106.702303
    ,"Polyline":"[106.69911957,10.78079414] ; [106.70230103,10.78417015]"
    ,"Distance":"512"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"1096"
    ,"Station_Code":"Q1 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đại học Khoa học xã hội nhân văn"
    ,"Station_Address":"10, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785778
    ,"Long":106.702663
    ,"Polyline":"[106.70230103,10.78417015] ; [106.70319366,10.78521919] ; [106.70265961,10.78577805]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2030"
    ,"Station_Code":"Q1 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"SVĐ Hoa Lư"
    ,"Station_Address":"2, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.7872
    ,"Long":106.701027
    ,"Polyline":"[106.70265961,10.78577805] ; [106.70102692,10.78719997]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2031"
    ,"Station_Code":"Q1 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"18,  đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.788253
    ,"Long":106.699898
    ,"Polyline":"[106.70102692,10.78719997] ; [106.69989777,10.78825283]"
    ,"Distance":"170"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2032"
    ,"Station_Code":"Q1 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Điện Biên Ph ủ"
    ,"Station_Address":"68, đường Đinh Tiên Ho àng, Quận 1"
    ,"Lat":10.789892
    ,"Long":106.698135
    ,"Polyline":"[106.69989777,10.78825283] ; [106.69813538,10.78989220]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"1877"
    ,"Station_Code":"Q1 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Nguyễn Văn Thủ"
    ,"Station_Address":"75, đường Nguyễn  Bỉnh Khiêm, Quận 1"
    ,"Lat":10.791216
    ,"Long":106.700569
    ,"Polyline":"[106.69813538,10.78989220] ; [106.69753265,10.79041481] ; [106.69928741,10.79221725] ; [106.69946289,10.79216957] ; [106.69962311,10.79220104] ; [106.70063019,10.79127407] ; [106.70056915,10.79121590]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2695"
    ,"Station_Code":"BX 09"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bến xe buýt Hoàng Sa"
    ,"Station_Address":"Đối diện 43-45, đường Hoàng Sa, Quận 1"
    ,"Lat":10.792291
    ,"Long":106.703773
    ,"Polyline":"[106.70056915,10.79121590] ; [106.70064545,10.79124737] ; [106.70152283,10.79047298] ; [106.70240784,10.79144764] ; [106.70325470,10.79239082] ; [106.70377350,10.79229069]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2695"
    ,"Station_Code":"BX 09"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe buýt Hoàng Sa"
    ,"Station_Address":"Đối diện 43-45, đường Hoàng Sa, Quận 1"
    ,"Lat":10.792291
    ,"Long":106.703773
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2697"
    ,"Station_Code":"Q1 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Kho Bạc Q1"
    ,"Station_Address":"Kho bạc NN Quận 1, đường Nguyễn Đình Chiểu, Quận 1"
    ,"Lat":10.791495
    ,"Long":106.702389
    ,"Polyline":"[106.70377350,10.79229069] ; [106.70320892,10.79238605] ; [106.70239258,10.79149532]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"1879"
    ,"Station_Code":"Q1 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"UBND Phường Dakao"
    ,"Station_Address":"52 -54, đường Nguyễn Đình Chi ểu, Quận 1"
    ,"Lat":10.78885
    ,"Long":106.699738
    ,"Polyline":"[106.70239258,10.79149532] ; [106.70239258,10.79149532] ; [106.69984436,10.78875446] ; [106.69973755,10.78884983] ; [106.69973755,10.78884983]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"1876"
    ,"Station_Code":"Q1 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Mạc Đỉnh Chi"
    ,"Station_Address":"102, đường Nguyễn Đình Chiểu, Quận 1"
    ,"Lat":10.786848
    ,"Long":106.697861
    ,"Polyline":"[106.69979858,10.78878975] ; [106.69792175,10.78680038]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"296"
    ,"Station_Code":"Q1 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Đinh Tiên Hoàng"
    ,"Station_Address":"15C-15D, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.786146
    ,"Long":106.70137
    ,"Polyline":"[106.69786072,10.78684807] ; [106.69794464,10.78678894] ; [106.69764709,10.78645706] ; [106.69975281,10.78451252] ; [106.70137024,10.78614616]"
    ,"Distance":"630"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"1190"
    ,"Station_Code":"Q1 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Đại học Y D ược"
    ,"Station_Address":"43, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785716
    ,"Long":106.702385
    ,"Polyline":"[106.70137024,10.78614616] ; [106.70166779,10.78652096] ; [106.70245361,10.78575134] ; [106.70238495,10.78571606]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2146"
    ,"Station_Code":"Q1 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Cty Xổ Số Kiến Thiết"
    ,"Station_Address":"Đối diện Central Plaza, đường Lê Duẩn, Quận 1"
    ,"Lat":10.78428
    ,"Long":106.702118
    ,"Polyline":"[106.70243835,10.78577995] ; [106.70307922,10.78518009] ; [106.70217896,10.78421974]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2696"
    ,"Station_Code":"Q1 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Nhà thờ Đức Bà"
    ,"Station_Address":"12, đường Lê Duẩn, Quận 1"
    ,"Lat":10.780676
    ,"Long":106.698854
    ,"Polyline":"[106.70217896,10.78421974] ; [106.69959259,10.78149033] ; [106.69898224,10.78085041]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"200"
    ,"Station_Code":"Q1 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Tòa Án Thành Phố"
    ,"Station_Address":"131, đường Nam  Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.776052
    ,"Long":106.698647
    ,"Polyline":"[106.69885254,10.78067589] ; [106.69889832,10.78062344] ; [106.69870758,10.78040791] ; [106.69863129,10.78032303] ; [106.69851685,10.78030205] ; [106.69844818,10.78014946] ; [106.69830322,10.78003883] ; [106.69647980,10.77817822] ; [106.69864655,10.77605247] ; [106.69864655,10.77605247]"
    ,"Distance":"725"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"199"
    ,"Station_Code":"Q1 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chùa Ông"
    ,"Station_Address":"Đối diện 96A, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.773957
    ,"Long":106.699722
    ,"Polyline":"[106.69873047,10.77614021] ; [106.69909668,10.77581978] ; [106.69954681,10.77466011] ; [106.69982147,10.77400017]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"201"
    ,"Station_Code":"Q1 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường CĐKT  Cao Thắng"
    ,"Station_Address":"Đối diện 86, đường Nam Kỳ Khởi Nghĩa,  Quận 1"
    ,"Lat":10.771416
    ,"Long":106.700851
    ,"Polyline":"[106.69982147,10.77400017] ; [106.70012665,10.77320004] ; [106.70027924,10.77283955] ; [106.70078278,10.77180004] ; [106.70092773,10.77145004]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận  1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70092773,10.77145004] ; [106.70111084,10.77103043] ; [106.69934845,10.77110958]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"202"
    ,"Station_Code":"Q1TC1C"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bến Thành C"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ L ão, Quận 1"
    ,"Lat":10.770787
    ,"Long":106.698532
    ,"Polyline":"[106.69915771,10.77110958] ; [106.69898987,10.77095318] ; [106.69853973,10.77077007]"
    ,"Distance":"103"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2854"
    ,"Station_Code":"Q1 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Dân Sinh"
    ,"Station_Address":"125-127, đường Ký Con, Quận 1"
    ,"Lat":10.767312
    ,"Long":106.698242
    ,"Polyline":"[106.69853210,10.77078724] ; [106.69618988,10.76985264] ; [106.69642639,10.76935673] ; [106.69824219,10.76731205]"
    ,"Distance":"640"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4452"
    ,"Station_Code":"Q2 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Khu đô thị Sala"
    ,"Station_Address":"Khu đô thị Sala, Mai Chí Thọ, quận2, đường Mai Chí Thọ, Quận 2"
    ,"Lat":10.773235
    ,"Long":106.723509
    ,"Polyline":"[106.69824219,10.76731205] ; [106.70025635,10.76525688] ; [106.70114899,10.76596260] ; [106.70195770,10.76725960] ; [106.70313263,10.76823997] ; [106.70441437,10.76883030] ; [106.71400452,10.77063179] ; [106.71479797,10.77071667] ; [106.71529388,10.77061081] ; [106.71767426,10.77111721] ; [106.72077179,10.77206516] ; [106.72351074,10.77323532]"
    ,"Distance":"3094"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"4075"
    ,"Station_Code":"Q2 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Công An phường Bình Khánh"
    ,"Station_Address":"D8A, đường Trần Não, Quận 2"
    ,"Lat":10.783828
    ,"Long":106.729329
    ,"Polyline":"[106.72351074,10.77323532] ; [106.72769165,10.77534389] ; [106.72732544,10.77620792] ; [106.72805786,10.77658749] ; [106.72821045,10.77755642] ; [106.72805786,10.77863216] ; [106.72824860,10.77964401] ; [106.72872162,10.78170967] ; [106.72914886,10.78265762] ; [106.72933197,10.78382778]"
    ,"Distance":"1536"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2939"
    ,"Station_Code":"Q2 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trần Não"
    ,"Station_Address":"8B, đường Lương Định Của, Quận 2"
    ,"Lat":10.785556
    ,"Long":106.730418
    ,"Polyline":"[106.72933197,10.78382778] ; [106.72949219,10.78488159] ; [106.72943878,10.78508759] ; [106.73041534,10.78555584]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2941"
    ,"Station_Code":"Q2 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Đình Bình Khánh"
    ,"Station_Address":"6/4, đường Lương Định Của, Quận 2"
    ,"Lat":10.786663
    ,"Long":106.732553
    ,"Polyline":"[106.73041534,10.78555584] ; [106.73152161,10.78618813] ; [106.73255157,10.78666306]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"3990"
    ,"Station_Code":"Q2 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Đường Số 8"
    ,"Station_Address":"Đối diện 21/2, đường Lương Định Của, Qu ận 2"
    ,"Lat":10.788528
    ,"Long":106.736094
    ,"Polyline":"[106.73255157,10.78666306] ; [106.73249054,10.78674984] ; [106.73603821,10.78862000] ; [106.73609161,10.78852844]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"3995"
    ,"Station_Code":"Q2 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chùa Huệ Nghiêm"
    ,"Station_Address":"Đối diện 22/4B, đường Lương  Định Của, Quận 2"
    ,"Lat":10.789487
    ,"Long":106.738856
    ,"Polyline":"[106.73609161,10.78852844] ; [106.73603821,10.78862000] ; [106.73659515,10.78892326] ; [106.73709869,10.78914452] ; [106.73751831,10.78929806] ; [106.73883057,10.78960037] ; [106.73885345,10.78948689]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"3991"
    ,"Station_Code":"Q2 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà hàng Ca Dao"
    ,"Station_Address":"Cột điện UEB33, đường Lương Định Của, Quận  2"
    ,"Lat":10.790099
    ,"Long":106.741667
    ,"Polyline":"[106.73883057,10.78960037] ; [106.74173737,10.79018974]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2944"
    ,"Station_Code":"Q2 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"Cột điện UEB38A, đường Lương Định Của, Quận 2"
    ,"Lat":10.79072
    ,"Long":106.744548
    ,"Polyline":"[106.74173737,10.79018974] ; [106.74452209,10.79080009]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"3994"
    ,"Station_Code":"Q2 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Công An phường An Phú"
    ,"Station_Address":"Đối diện 244 , đường Nguyễn Hoàng, Qu ận 2"
    ,"Lat":10.79227
    ,"Long":106.745878
    ,"Polyline":"[106.74454498,10.79071999] ; [106.74607086,10.79112625] ; [106.74588013,10.79226971]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7105"
    ,"Station_Code":"Q2 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Chung Cư Bình Khánh"
    ,"Station_Address":"108 - 110 , đường Nguyễn Hoàng, Quận 2"
    ,"Lat":10.79482
    ,"Long":106.745406
    ,"Polyline":"[106.74588013,10.79226971] ; [106.74540710,10.79481983]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7107"
    ,"Station_Code":"Q2 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Metro An Phú"
    ,"Station_Address":"Chung cư An Lộc, đường Vũ Tông Phan, Quận 2"
    ,"Lat":10.798214
    ,"Long":106.743931
    ,"Polyline":"[106.74540710,10.79481983] ; [106.74459076,10.79855061] ; [106.74393463,10.79821396]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7110"
    ,"Station_Code":"Q2 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chung cư cao ốc An Cư"
    ,"Station_Address":"Đoạn giữa đường số 17 và đường số 19, đường Thái Thuận, Quận 2"
    ,"Lat":10.798493
    ,"Long":106.739463
    ,"Polyline":"[106.74393463,10.79821396] ; [106.74393463,10.79821396] ; [106.74306488,10.79770756] ; [106.74211884,10.79725456] ; [106.74151611,10.79840374] ; [106.74057007,10.79791832] ; [106.74041748,10.79797077] ; [106.74024963,10.79863548] ; [106.73946381,10.79849339] ; [106.73946381,10.79849339]"
    ,"Distance":"668"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2936"
    ,"Station_Code":"Q2 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công viên dạ cầu Sài Gòn"
    ,"Station_Address":"Đối diện số 3, đường Trần Não, Quận 2"
    ,"Lat":10.798277
    ,"Long":106.732119
    ,"Polyline":"[106.73946381,10.79849339] ; [106.73878479,10.79836082] ; [106.73838806,10.80024719] ; [106.73350525,10.79942513] ; [106.73328400,10.79883575] ; [106.73211670,10.79827690]"
    ,"Distance":"1043"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"2990"
    ,"Station_Code":"Q2 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường Quốc Hương"
    ,"Station_Address":"Kế số 3 Quốc Hương , đường Quốc Hương, Quận 2"
    ,"Lat":10.800705
    ,"Long":106.732162
    ,"Polyline":"[106.73211670,10.79827690] ; [106.73183441,10.79820347] ; [106.73162842,10.79835033] ; [106.73169708,10.79862499] ; [106.73162079,10.79891968] ; [106.73136139,10.79899311] ; [106.72972107,10.79878235] ; [106.72946930,10.79897785] ; [106.72933197,10.79958916] ; [106.72923279,10.80018425] ; [106.72925568,10.80039024] ; [106.72934723,10.80052185] ; [106.72948456,10.80059528] ; [106.73075867,10.80068016] ; [106.73212433,10.80076885] ; [106.73216248,10.80070496] ; [106.73216248,10.80070496] ; [106.73216248,10.80070496] ; [106.73216248,10.80070496] ; [106.73216248,10.80070496]"
    ,"Distance":"863"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7114"
    ,"Station_Code":"Q2 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Quốc Hương - Lê Văn Miến"
    ,"Station_Address":"Đối diện 39 , đường Quốc Hương, Quận 2"
    ,"Lat":10.804194
    ,"Long":106.731732
    ,"Polyline":"[106.73216248,10.80070496] ; [106.73275757,10.80076408] ; [106.73281097,10.80141735] ; [106.73234558,10.80335617] ; [106.73201752,10.80329323] ; [106.73173523,10.80419445]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"7116"
    ,"Station_Code":"Q2 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Làng báo chí"
    ,"Station_Address":"Đối  diện nhà số 91 , đường Thảo Điền, Quận 2"
    ,"Lat":10.807372
    ,"Long":106.734205
    ,"Polyline":"[106.73173523,10.80419445] ; [106.73162079,10.80455780] ; [106.73556519,10.80604362] ; [106.73420715,10.80737209]"
    ,"Distance":"715"
  },
  {
     "Route_Id":"56"
    ,"Station_Id":"6844"
    ,"Station_Code":"BX 77"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Làng báo ch í"
    ,"Station_Address":"Gần Hẻm 76, đường Nguyễn Văn Hưởng, Quận 2"
    ,"Lat":10.809105
    ,"Long":106.732419
    ,"Polyline":"[106.73420715,10.80737209] ; [106.73381042,10.80787277] ; [106.73242188,10.80910492]"
    ,"Distance":"275"
  }]