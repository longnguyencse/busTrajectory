export const Route35 =[
  {
     "Route_Id":"35"
    ,"Station_Id":"1871"
    ,"Station_Code":"BX86"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Tân Vạn"
    ,"Station_Address":"Ngã ba Tân Vạn, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.898041725158691
    ,"Long":106.82798767089844
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1186"
    ,"Station_Code":"Q9 230"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Công ty TNHH Thuận Thành Tâm"
    ,"Station_Address":"Công ty TNHH Thuận Thành Tâm, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.892685
    ,"Long":106.822804
    ,"Polyline":"[106.82794952,10.89793015] ; [106.82804108,10.89789963] ; [106.82778931,10.89762020] ; [106.82766724,10.89748955] ; [106.82733154,10.89710045] ; [106.82705688,10.89684010.06.82695770] ; [10.89678955,106.82613373] ; [10.89624023,106.82563019] ; [10.89585018,106.82495880] ; [10.89523029,106.82431030] ; [10.89451981,106.82362366]"
    ,"Distance":"693"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1188"
    ,"Station_Code":"Q9 231"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty Dosan"
    ,"Station_Address":"Công ty Dosan, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.888961
    ,"Long":106.820047
    ,"Polyline":"[106.82362366,10.89361954] ; [106.81923676,10.88766003]"
    ,"Distance":"818"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1187"
    ,"Station_Code":"Q9 232"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Công ty Cp Đức Khải"
    ,"Station_Address":"C ông ty Cp Đức Khải, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.879241
    ,"Long":106.812918
    ,"Polyline":"[106.81923676,10.88766003] ; [106.81300354,10.87917042]"
    ,"Distance":"1165"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"572"
    ,"Station_Code":"QTD 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"621-Ngã 3  Lâm Viên"
    ,"Station_Address":"Nhà máy Tiến Thành, đường Quốc lộ 1, Quận  Thủ Đức"
    ,"Lat":10.871128
    ,"Long":106.806979
    ,"Polyline":"[106.81291962,10.87924099] ; [106.81300354,10.87917042] ; [106.81025696,10.87545967] ; [106.80934906,10.87423992] ; [106.80892181,10.87368011] ; [106.80873871,10.87341022] ; [106.80798340,10.87234020] ; [106.80744171,10.87158012] ; [106.80697632,10.87112808]"
    ,"Distance":"1125"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo dục Quốc phòng, đường Quốc lộ  1, Quận Thủ Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80683899,10.87077999] ; [106.80651855,10.87038040] ; [106.80586243,10.86958027] ; [106.80507660,10.86878967] ; [106.80455017,10.86830044] ; [106.80441284,10.86816978]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"574"
    ,"Station_Code":"QTD 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Khu DL Suối Tiên"
    ,"Station_Address":"9/29, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86605
    ,"Long":106.801116
    ,"Polyline":"[106.80441284,10.86816978] ; [106.80362701,10.86754036] ; [106.80291748,10.86703968] ; [106.80229950,10.86666012] ; [106.80117798,10.86598015]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"398"
    ,"Station_Code":"QTD 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Khu Công nghệ cao Q9"
    ,"Station_Address":"Đối diện Khu  công nghệ cao, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.860545
    ,"Long":106.791723
    ,"Polyline":"[106.80111694,10.86604977] ; [106.80117798,10.86598015] ; [106.79895020,10.86468029] ; [106.79505920,10.86238003] ; [106.79172516,10.86054516]"
    ,"Distance":"1208"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"401"
    ,"Station_Code":"QTD 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty Cocacola"
    ,"Station_Address":"Công ty Cocacola, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.856483
    ,"Long":106.784964
    ,"Polyline":"[106.78871155,10.85859013] ; [106.78813934,10.85824966] ; [106.78781128,10.85799980] ; [106.78724670,10.85772991] ; [106.78677368,10.85744953] ; [106.78600311,10.85698032] ; [106.78494263,10.85636997]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1113"
    ,"Station_Code":"QTD 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã tư Thủ Đức"
    ,"Station_Address":"Đối diện Coopmart , đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.84828
    ,"Long":106.77299
    ,"Polyline":"[106.78494263,10.85636997] ; [106.78103638,10.85406017] ; [106.77652740,10.85136986] ; [106.77603149,10.85103989] ; [106.77538300,10.85056973] ; [106.77496338,10.85021973] ; [106.77391052,10.84926033] ; [106.77340698,10.84871006] ; [106.77314758,10.84836006] ; [106.77310181,10.84827042]"
    ,"Distance":"1587"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1111"
    ,"Station_Code":"QTD 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Betong H ải Âu"
    ,"Station_Address":"Đối diện Betong Hải Âu, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.844297
    ,"Long":106.77063
    ,"Polyline":"[106.77298737,10.84827995] ; [106.77310181,10.84827042] ; [106.77133942,10.84535027] ; [106.77062988,10.84429741]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1112"
    ,"Station_Code":"QTD 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"UBND Quận 9"
    ,"Station_Address":"126, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.840745
    ,"Long":106.768607
    ,"Polyline":"[106.77044678,10.84377003] ; [106.76873016,10.84070969]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"410"
    ,"Station_Code":"QTD 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Đối di ện 592C, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.834945
    ,"Long":106.765244
    ,"Polyline":"[106.76873016,10.84070969] ; [106.76544952,10.83495045]"
    ,"Distance":"734"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"413"
    ,"Station_Code":"QTD 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Công ty  truyền tải điện 4"
    ,"Station_Address":"Công  ty truyền tải điện 4, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.831214
    ,"Long":106.763195
    ,"Polyline":"[106.76544952,10.83495045] ; [106.76335144,10.83117008]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"412"
    ,"Station_Code":"QTD 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"Nhà máy thép Thủ Đức, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.825366
    ,"Long":106.759998
    ,"Polyline":"[106.76335144,10.83117008] ; [106.76077271,10.82660961] ; [106.76042175,10.82596970] ; [106.76006317,10.82534027]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"414"
    ,"Station_Code":"QTD 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Xi măng Hà Tiên"
    ,"Station_Address":"Xi  măng Hà Tiên 1, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.820576
    ,"Long":106.758142
    ,"Polyline":"[106.75999451,10.82536602] ; [106.76006317,10.82534027] ; [106.75936127,10.82404041] ; [106.75901031,10.82326984] ; [106.75881958,10.82271957] ; [106.75849915,10.82153034] ; [106.75832367,10.82067966] ; [106.75814056,10.82057571]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"415"
    ,"Station_Code":"Q2 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Đối diện Esstella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802925
    ,"Long":106.747948
    ,"Polyline":"[106.75824738,10.82028961] ; [106.75800323,10.81882000] ; [106.75762177,10.81719971] ; [106.75750732,10.81649971] ; [106.75665283,10.81186962] ; [106.75646210,10.81079006] ; [106.75637054,10.81039047] ; [106.75617981,10.80984020] ; [106.75598145,10.80965996] ; [106.75581360,10.80947018] ; [106.75559235,10.80926037] ; [106.75546265,10.80908012] ; [106.75527191,10.80881023] ; [106.75486755,10.80805969] ; [106.75475311,10.80792999] ; [106.75462341,10.80772018] ; [106.75428772,10.80725002] ; [106.75395203,10.80685043] ; [106.75332642,10.80630016] ; [106.75301361,10.80597019] ; [106.75257111,10.80548954] ; [106.75234985,10.80527973] ; [106.75190735,10.80494022] ; [106.75112152,10.80440998] ; [106.75038910,10.80405998] ; [106.74987030,10.80385017] ; [106.74957275,10.80370998] ; [106.74935913,10.80356026] ; [106.74886322,10.80315018] ; [106.74861145,10.80301952] ; [106.74826050,10.80294991] ; [106.74796295,10.80286980]"
    ,"Distance":"2404"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"416"
    ,"Station_Code":"Q2 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"655, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802134
    ,"Long":106.7434
    ,"Polyline":"[106.74796295,10.80286980] ; [106.74703217,10.80266953] ; [106.74620819,10.80251026] ; [106.74530792,10.80233955] ; [106.74463654,10.80222988] ; [106.74340820,10.80202007]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"417"
    ,"Station_Code":"Q2 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Ngã ba Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801309
    ,"Long":106.738762
    ,"Polyline":"[106.74340820,10.80202007] ; [106.74149323,10.80167007] ; [106.74060822,10.80146980] ; [106.73986816,10.80136013] ; [106.73879242,10.80115986]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"418"
    ,"Station_Code":"Q2 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"Đối diện Cầu Đen, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800451
    ,"Long":106.73436
    ,"Polyline":"[106.73879242,10.80115986] ; [106.73438263,10.80035019]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"419"
    ,"Station_Code":"QBTH 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"24(597), đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.79882
    ,"Long":106.719641
    ,"Polyline":"[106.73438263,10.80035019] ; [106.73294067,10.80004978] ; [106.73187256,10.79979992] ; [106.72416687,10.79837036] ; [106.72223663,10.79802990] ; [106.72196960,10.79800987] ; [106.72158051,10.79800034] ; [106.72128296,10.79804993] ; [106.72090149,10.79813957] ; [106.72048950,10.79827976] ; [106.72003937,10.79848003] ; [106.71987915,10.79856968] ; [106.71972656,10.79868984] ; [106.71945953,10.79881954]"
    ,"Distance":"1676"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"420"
    ,"Station_Code":"QBTH 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"152/72c(559), đường Điện Bi ên Phủ, Quận Bình Thạnh"
    ,"Lat":10.800153
    ,"Long":106.717442
    ,"Polyline":"[106.71945953,10.79881954] ; [106.71913147,10.79899025] ; [106.71864319,10.79930019] ; [106.71785736,10.79975033] ; [106.71719360,10.80008030]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"483, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71719360,10.80008030] ; [106.71645355,10.80043030] ; [106.71571350,10.80074024] ; [106.71513367,10.80097008] ; [106.71481323,10.80107975]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"419, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71485901,10.80122757] ; [106.71471405,10.80127525] ; [106.71443939,10.80134869] ; [106.71388245,10.80146503] ; [106.71343231,10.80159092] ; [106.71300507,10.80169678] ; [106.71281433,10.80164433] ; [106.71244812,10.80163860]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1873"
    ,"Station_Code":"QBTH 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"10b, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801454
    ,"Long":106.710076
    ,"Polyline":"[106.71244812,10.80163860] ; [106.71231842,10.80156040] ; [106.71144867,10.80158043] ; [106.71138763,10.80160046] ; [106.71130371,10.80160046] ; [106.71124268,10.80158043] ; [106.71119690,10.80154991] ; [106.71060944,10.80148029] ; [106.71018982,10.80144978] ; [106.71007538,10.80145359]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1872"
    ,"Station_Code":"QBTH 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đại học Hồng Bàng"
    ,"Station_Address":"205, đường Đi ện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799747
    ,"Long":106.706268
    ,"Polyline":"[106.70973969,10.80136967] ; [106.70937347,10.80125046] ; [106.70861816,10.80097961] ; [106.70812988,10.80078030] ; [106.70787811,10.80064964] ; [106.70706177,10.80016994] ; [106.70671082,10.79996014] ; [106.70635986,10.79969025]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1875"
    ,"Station_Code":"QBTH 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm Điện Nguyễn Cửu Vân"
    ,"Station_Address":"119, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.797724
    ,"Long":106.704175
    ,"Polyline":"[106.70635986,10.79969025] ; [106.70567322,10.79909039] ; [106.70514679,10.79858017] ; [106.70429993,10.79765987]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1874"
    ,"Station_Code":"QBTH 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Cầu Điện Biên Phủ"
    ,"Station_Address":"45, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.795157
    ,"Long":106.701745
    ,"Polyline":"[106.70417786,10.79772377] ; [106.70429993,10.79765987] ; [106.70189667,10.79514027] ; [106.70174408,10.79515743]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1877"
    ,"Station_Code":"Q1 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nguyễn Văn Thủ"
    ,"Station_Address":"75, đường Nguyễn  Bỉnh Khiêm, Quận 1"
    ,"Lat":10.791216
    ,"Long":106.700569
    ,"Polyline":"[106.70118713,10.79428959] ; [106.70089722,10.79389954] ; [106.69998932,10.79294968] ; [106.69970703,10.79273033] ; [106.69946289,10.79261017] ; [106.69937134,10.79259014] ; [106.69928741,10.79255009] ; [106.69921112,10.79246998] ; [106.69915771,10.79236984] ; [106.69917297,10.79228973] ; [106.69924164,10.79220963] ; [106.69936371,10.79218006] ; [106.69947052,10.79218960] ; [106.69959259,10.79222965] ; [106.70001221,10.79185009] ; [106.70063019,10.79127979]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1879"
    ,"Station_Code":"Q1 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"UBND Phường Dakao"
    ,"Station_Address":"52 -54, đường Nguyễn Đình Chiểu, Quận  1"
    ,"Lat":10.78885
    ,"Long":106.699738
    ,"Polyline":"[106.70063019,10.79127979] ; [106.70127106,10.79069996] ; [106.70146942,10.79051018] ; [106.70099640,10.79004002] ; [106.70011139,10.78911972] ; [106.69979858,10.78878975]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1876"
    ,"Station_Code":"Q1 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Mạc Đỉnh Chi"
    ,"Station_Address":"102, đường Nguyễn Đình Chiểu, Quận 1"
    ,"Lat":10.786848
    ,"Long":106.697861
    ,"Polyline":"[106.69979858,10.78878975] ; [106.69792175,10.78680038]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1878"
    ,"Station_Code":"Q1 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Hai Bà Trưng"
    ,"Station_Address":"116 - 118, đường Nguyễn Đình Chiểu, Quận 1"
    ,"Lat":10.785293
    ,"Long":106.696457
    ,"Polyline":"[106.69792175,10.78680038] ; [106.69648743,10.78526020]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1881"
    ,"Station_Code":"Q3 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Đại học Kinh tế"
    ,"Station_Address":"138B, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.782981
    ,"Long":106.694191
    ,"Polyline":"[106.69648743,10.78526020] ; [106.69486237,10.78357029] ; [106.69425964,10.78291988]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1880"
    ,"Station_Code":"Q3 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Coop Mart Nguyễn Đình Chiểu"
    ,"Station_Address":"170, đường Nguyễn Đình Chi ểu, Quận 3"
    ,"Lat":10.780828
    ,"Long":106.6922
    ,"Polyline":"[106.69423676,10.78293991] ; [106.69374084,10.78242970] ; [106.69290161,10.78145027] ; [106.69225311,10.78077984]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1883"
    ,"Station_Code":"Q3 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trương Định"
    ,"Station_Address":"216, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.77824
    ,"Long":106.689789
    ,"Polyline":"[106.69225311,10.78077984] ; [106.69178009,10.78030968] ; [106.69069672,10.77910042] ; [106.69016266,10.77849007] ; [106.68984985,10.77818012]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1882"
    ,"Station_Code":"Q3 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Cách mạng Tháng Tám"
    ,"Station_Address":"Đối diện 193, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.77465
    ,"Long":106.686394
    ,"Polyline":"[106.68984985,10.77818012] ; [106.68846893,10.77674961] ; [106.68643951,10.77460957]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1889"
    ,"Station_Code":"Q3 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chợ Vườn Chuối"
    ,"Station_Address":"448 - 450, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.772213
    ,"Long":106.684086
    ,"Polyline":"[106.68639374,10.77464962] ; [106.68374634,10.77185345]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1884"
    ,"Station_Code":"Q3 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Cao thắng"
    ,"Station_Address":"596 - 598,  đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.769731
    ,"Long":106.681672
    ,"Polyline":"[106.68374634,10.77185345] ; [106.68173218,10.76971149]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1890"
    ,"Station_Code":"Q3 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Bàn Cờ"
    ,"Station_Address":"678 - 680, đường Nguyễn  Đình Chiểu, Quận 3"
    ,"Lat":10.768289
    ,"Long":106.680359
    ,"Polyline":"[106.68173218,10.76971149] ; [106.68035889,10.76828861]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1885"
    ,"Station_Code":"Q3 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Lý Thái Tổ"
    ,"Station_Address":"766 - 768, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.76709
    ,"Long":106.67926
    ,"Polyline":"[106.68035889,10.76828861] ; [106.67926025,10.76708984]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1413"
    ,"Station_Code":"Q3 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"170, đường Lý Thái Tổ, Quận 3"
    ,"Lat":10.76668
    ,"Long":106.678099
    ,"Polyline":"[106.67929840,10.76706982] ; [106.67897797,10.76675034] ; [106.67878723,10.76653004] ; [106.67868042,10.76636982] ; [106.67828369,10.76650047]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1416"
    ,"Station_Code":"Q3 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Hồ Thị Kỷ"
    ,"Station_Address":"306, đường L ý Thái Tổ, Quận 3"
    ,"Lat":10.767423
    ,"Long":106.675664
    ,"Polyline":"[106.67829132,10.76652908] ; [106.67582703,10.76730824]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1891"
    ,"Station_Code":"Q10 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Đài tưởng niệm"
    ,"Station_Address":"66, đường Ngô Gia Tự, Quận 10"
    ,"Lat":10.766427
    ,"Long":106.67347
    ,"Polyline":"[106.67581177,10.76725960] ; [106.67461395,10.76760483] ; [106.67459106,10.76778412] ; [106.67449951,10.76786327] ; [106.67433929,10.76789665] ; [106.67420197,10.76781559] ; [106.67417145,10.76767540] ; [106.67419434,10.76756287] ; [106.67425537,10.76748085] ; [106.67406464,10.76717377] ; [106.67386627,10.76691818] ; [106.67360687,10.76653004]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"388"
    ,"Station_Code":"Q10 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Hòa Hảo"
    ,"Station_Address":"222, đường Ngô Gia Tự, Quận 10"
    ,"Lat":10.763286
    ,"Long":106.671168
    ,"Polyline":"[106.67360687,10.76653004] ; [106.67295074,10.76554012] ; [106.67228699,10.76469994] ; [106.67131042,10.76327991]"
    ,"Distance":"455"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"390"
    ,"Station_Code":"Q10 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Trường khi ếm thị Nguyễn Đình Chiểu"
    ,"Station_Address":"446, đường Ngô Gia Tự, Quận 10"
    ,"Lat":10.760857
    ,"Long":106.669525
    ,"Polyline":"[106.67131042,10.76327991] ; [106.67047119,10.76204014] ; [106.66957855,10.76080990]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"569"
    ,"Station_Code":"Q5 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Ngô Gia Tự"
    ,"Station_Address":"500, đường Ngô Gia Tự, Quận 5"
    ,"Lat":10.758801
    ,"Long":106.668062
    ,"Polyline":"[106.66957855,10.76080990] ; [106.66899109,10.75997639] ; [106.66891479,10.76000214] ; [106.66885376,10.75999165] ; [106.66877747,10.75994968] ; [106.66875458,10.75987625] ; [106.66876221,10.75981045] ; [106.66882324,10.75973129] ; [106.66812897,10.75876999]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"573"
    ,"Station_Code":"Q5 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Trung tâm giáo dục thường xuyên"
    ,"Station_Address":"546 , đường Ngô Gia Tự, Quận 5"
    ,"Lat":10.757331
    ,"Long":106.667016
    ,"Polyline":"[106.66805267,10.75882816] ; [106.66802216,10.75873280] ; [106.66720581,10.75756264] ; [106.66699982,10.75734711]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Bệnh viện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường H ồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66699982,10.75734711] ; [106.66706085,10.75730038] ; [106.66629791,10.75623989] ; [106.66517639,10.75601292] ; [106.66485596,10.75592327] ; [106.66465759,10.75587559] ; [106.66451263,10.75588226]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66451263,10.75588226] ; [106.66433716,10.75582314] ; [106.66336060,10.75557041] ; [106.66236877,10.75539017] ; [106.66139221,10.75520134] ; [106.66107941,10.75520515]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng B àng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107941,10.75520515] ; [106.66094208,10.75514317] ; [106.65982819,10.75493240] ; [106.65961456,10.75492668]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"435"
    ,"Station_Code":"Q5 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"Đối diện 385, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75458
    ,"Long":106.657934
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65793610,10.75457954]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"438"
    ,"Station_Code":"Q5 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Dương Tử Giang"
    ,"Station_Address":"Đối diện 455-457, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754158
    ,"Long":106.65552
    ,"Polyline":"[106.65793610,10.75457954] ; [106.65551758,10.75415802]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65554810,10.75404835] ; [106.65554810,10.75404835] ; [106.65554810,10.75404835] ; [106.65554047,10.75407982] ; [106.65385437,10.75379944] ; [106.65376282,10.75377846] ; [106.65372467,10.75371552] ; [106.65373230,10.75359917] ; [106.65352631,10.75275612] ; [106.65337372,10.75208664] ; [106.65328217,10.75167084] ; [106.65316772,10.75150681] ; [106.65305328,10.75138569] ; [106.65267181,10.75127029] ; [106.65256500,10.75125313]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA  HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27, đường Tháp Mười, Quận 6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65203857,10.75116444] ; [106.65194702,10.75102234] ; [106.65099335,10.75097466] ; [106.65003967,10.75107002] ; [106.64955139,10.75079060] ; [106.64944458,10.74973106.06.65254211] ; [10.75026989,106.65255737]"
    ,"Distance":"815"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"470"
    ,"Station_Code":"Q5 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"399, đường Hồng B àng, Quận 5"
    ,"Lat":10.754111
    ,"Long":106.656749
    ,"Polyline":"[106.65254211,10.75026989] ; [106.65338898,10.75043011] ; [106.65335846,10.75067997] ; [106.65332794,10.75109005] ; [106.65329742,10.75150013] ; [106.65325928,10.75164032] ; [106.65334320,10.75209045] ; [106.65357208,10.75275040] ; [106.65377808,10.75360012] ; [106.65442657,10.75372028] ; [106.65511322,10.75386047] ; [106.65672302,10.75415993]"
    ,"Distance":"783"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65674591,10.75411129] ; [106.65923309,10.75455284]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"217, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.65923309,10.75455284] ; [106.66319275,10.75535965]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bệnh viện Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66319275,10.75535965] ; [106.66468048,10.75567055]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"441"
    ,"Station_Code":"Q5 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Trần Khai Nguyên"
    ,"Station_Address":"138G-138F,  đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.758706
    ,"Long":106.66928
    ,"Polyline":"[106.66468048,10.75567055] ; [106.66968536,10.75664520] ; [106.66928101,10.75870609]"
    ,"Distance":"791"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"285"
    ,"Station_Code":"Q10 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường khiếm thị Nguyễn Đình Chi ểu"
    ,"Station_Address":"417, đường Ngô Gia Tự, Qu ận 10"
    ,"Lat":10.760582
    ,"Long":106.669511
    ,"Polyline":"[106.66928101,10.75870609] ; [106.66905212,10.75970745] ; [106.66908264,10.75981331] ; [106.66909790,10.75993443] ; [106.66905975,10.76002884] ; [106.66949463,10.76061916]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"286"
    ,"Station_Code":"Q10 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Hòa Hảo"
    ,"Station_Address":"277, đường Ngô Gia Tự, Quận 10"
    ,"Lat":10.762933
    ,"Long":106.671093
    ,"Polyline":"[106.66949463,10.76061916] ; [106.67111969,10.76291180]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1907"
    ,"Station_Code":"Q10 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Đài tưởng niệm"
    ,"Station_Address":"105, đường Ngô Gia Tự, Quận 10"
    ,"Lat":10.765404
    ,"Long":106.672826
    ,"Polyline":"[106.67111969,10.76291180] ; [106.67285919,10.76534081]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1909"
    ,"Station_Code":"Q3 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã 7 Lý  Thái Tổ"
    ,"Station_Address":"647, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.768703
    ,"Long":106.675224
    ,"Polyline":"[106.67282104,10.76537037] ; [106.67295074,10.76554012] ; [106.67388153,10.76692963] ; [106.67426300,10.76749039] ; [106.67420197,10.76756001] ; [106.67417145,10.76764965] ; [106.67417145,10.76770020] ; [106.67417908,10.76776028] ; [106.67421722,10.76782036] ; [106.67426300,10.76784992] ; [106.67433929,10.76788998] ; [106.67445374,10.76788998] ; [106.67449188,10.76788044] ; [106.67450714,10.76786041] ; [106.67500305,10.76848984] ; [106.67526245,10.76883984]"
    ,"Distance":"513"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"92"
    ,"Station_Code":"Q3 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Cao Thắng"
    ,"Station_Address":"503, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.771249
    ,"Long":106.677505
    ,"Polyline":"[106.67526245,10.76883984] ; [106.67579651,10.76959038] ; [106.67671967,10.77056980] ; [106.67742920,10.77132034]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1911"
    ,"Station_Code":"Q3 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Cư Xá Đô Thành"
    ,"Station_Address":"399, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.773248
    ,"Long":106.67981
    ,"Polyline":"[106.67742920,10.77132034] ; [106.67758179,10.77147007] ; [106.67807770,10.77190018] ; [106.67839813,10.77215958] ; [106.67903900,10.77270985] ; [106.67974091,10.77332020]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1912"
    ,"Station_Code":"Q3 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Bệnh viện  Bình Dân"
    ,"Station_Address":"371, đường Đi ện Biên Phủ, Quận 3"
    ,"Lat":10.774641
    ,"Long":106.68145
    ,"Polyline":"[106.67974091,10.77332020] ; [106.68138885,10.77470970]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"731"
    ,"Station_Code":"Q3 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Cách Mạng tháng 8"
    ,"Station_Address":"303, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.777009
    ,"Long":106.684145
    ,"Polyline":"[106.68138885,10.77470970] ; [106.68270111,10.77581978] ; [106.68357849,10.77657986] ; [106.68399048,10.77696037]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1913"
    ,"Station_Code":"Q3 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện  Mắt"
    ,"Station_Address":"291, đường Điện Bi ên Phủ, Quận 3"
    ,"Lat":10.778255
    ,"Long":106.685471
    ,"Polyline":"[106.68399048,10.77696037] ; [106.68540955,10.77832031]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1917"
    ,"Station_Code":"Q3 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Sở Khoa học và Công nghệ"
    ,"Station_Address":"273, đường  Điện Biên Phủ, Quận 3"
    ,"Lat":10.780286
    ,"Long":106.687621
    ,"Polyline":"[106.68540955,10.77832031] ; [106.68717194,10.78003025] ; [106.68752289,10.78034973]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1914"
    ,"Station_Code":"Q3 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường Marie Curie"
    ,"Station_Address":"Đối diện số 206 (247), đường Điện Bi ên Phủ, Quận 3"
    ,"Lat":10.782872
    ,"Long":106.690369
    ,"Polyline":"[106.68752289,10.78034973] ; [106.69029999,10.78293991]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1920"
    ,"Station_Code":"Q3 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Phạm Ngọc Thạch"
    ,"Station_Address":"209, đường Điện Bi ên Phủ, Quận 3"
    ,"Lat":10.784965
    ,"Long":106.692375
    ,"Polyline":"[106.69029999,10.78293991] ; [106.69084930,10.78347969] ; [106.69232941,10.78501034]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1915"
    ,"Station_Code":"Q1 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Công Viên Lê Văn Tám"
    ,"Station_Address":"179 - 181,  đường Điện Biên Phủ, Quận 1"
    ,"Lat":10.786934
    ,"Long":106.694313
    ,"Polyline":"[106.69232941,10.78501034] ; [106.69373322,10.78643990] ; [106.69423676,10.78699017]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1924"
    ,"Station_Code":"Q1 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đinh Tiên Hoàng"
    ,"Station_Address":"87, đường Điện Bi ên Phủ, Quận 1"
    ,"Lat":10.789477
    ,"Long":106.696783
    ,"Polyline":"[106.69423676,10.78699017] ; [106.69612885,10.78896046] ; [106.69682312,10.78964043]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"730"
    ,"Station_Code":"QBTH 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Điện Biên Phủ"
    ,"Station_Address":"84, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.794815
    ,"Long":106.702223
    ,"Polyline":"[106.69682312,10.78964043] ; [106.69753265,10.79039001] ; [106.69812775,10.79096985] ; [106.69902802,10.79195976] ; [106.69936371,10.79218006] ; [106.69959259,10.79222965] ; [106.69967651,10.79228020] ; [106.69972992,10.79238033] ; [106.69975281,10.79249001] ; [106.69992065,10.79263973] ; [106.70092773,10.79370022] ; [106.70121002,10.79397964]"
    ,"Distance":"689"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1916"
    ,"Station_Code":"QBTH 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm Điện Nguyễn Cửu Vân"
    ,"Station_Address":"174, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.797286
    ,"Long":106.704567
    ,"Polyline":"[106.70222473,10.79481506] ; [106.70456696,10.79728603]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1918"
    ,"Station_Code":"QBTH 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Đại học  Hồng Bàng"
    ,"Station_Address":"330, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799505
    ,"Long":106.70689
    ,"Polyline":"[106.70456696,10.79728603] ; [106.70588684,10.79885960] ; [106.70678711,10.79959965] ; [106.70688629,10.79950523]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1925"
    ,"Station_Code":"QBTH 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"442, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.80108
    ,"Long":106.710269
    ,"Polyline":"[106.70678711,10.79959965] ; [106.70722198,10.79988003] ; [106.70823669,10.80045986] ; [106.70861816,10.80064011] ; [106.70899963,10.80078983] ; [106.70964050,10.80099964] ; [106.70980072,10.80103016]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"476"
    ,"Station_Code":"QBTH 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"500-502, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.800864
    ,"Long":106.714287
    ,"Polyline":"[106.71026611,10.80107975] ; [106.71054840,10.80115414] ; [106.71117401,10.80126953] ; [106.71131134,10.80124092] ; [106.71145630,10.80127239] ; [106.71151733,10.80129051] ; [106.71234894,10.80130196] ; [106.71299744,10.80125713] ; [106.71352386,10.80117226] ; [106.71414185,10.80101013] ; [106.71428680,10.80086422]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"473"
    ,"Station_Code":"QBTH 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"600, đường Điện Bi ên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799547
    ,"Long":106.717409
    ,"Polyline":"[106.71428680,10.80086422] ; [106.71469879,10.80084991] ; [106.71527863,10.80066013] ; [106.71617889,10.80035019] ; [106.71685791,10.80000973] ; [106.71720886,10.79983044] ; [106.71740723,10.79954720]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"475"
    ,"Station_Code":"QBTH 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"658, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.798525
    ,"Long":106.719496
    ,"Polyline":"[106.71740723,10.79954720] ; [106.71833801,10.79920959] ; [106.71943665,10.79856968] ; [106.71949768,10.79852486]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"477"
    ,"Station_Code":"Q2 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"794, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.799978
    ,"Long":106.7342
    ,"Polyline":"[106.71943665,10.79856968] ; [106.72039795,10.79808044] ; [106.72083282,10.79792976] ; [106.72122955,10.79782009] ; [106.72203064,10.79780960] ; [106.72254944,10.79782963] ; [106.72306824,10.79790020] ; [106.72541046,10.79833031] ; [106.72850037,10.79891968] ; [106.73149872,10.79944992] ; [106.73317719,10.79986954] ; [106.73404694,10.80006981] ; [106.73417664,10.80008984]"
    ,"Distance":"1676"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"478"
    ,"Station_Code":"Q2 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Đối diện ngã 3 Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800838
    ,"Long":106.738899
    ,"Polyline":"[106.73417664,10.80008984] ; [106.73886871,10.80097961]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"480"
    ,"Station_Code":"Q2 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"170, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801584
    ,"Long":106.742928
    ,"Polyline":"[106.73886871,10.80097961] ; [106.74289703,10.80173016]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"479"
    ,"Station_Code":"Q2 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Khu dân cư Estella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802592
    ,"Long":106.748089
    ,"Polyline":"[106.74289703,10.80173016] ; [106.74376678,10.80189037] ; [106.74430084,10.80200958] ; [106.74456787,10.80204010.06.74524689] ; [10.80206966,106.74575806] ; [10.80202961,106.74610901] ; [10.80202007,106.74642181] ; [10.80206966,106.74662781] ; [10.80214024,106.74687958] ; [10.80226040,106.74725342] ; [10.80241966,106.74761963] ; [10.80255032,106.74806213]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"482"
    ,"Station_Code":"Q9 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Xi măng hà tiên - trạm thu phí"
    ,"Station_Address":"249B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.819206
    ,"Long":106.758394
    ,"Polyline":"[106.74806213,10.80266953] ; [106.74839020,10.80274010.06.74857330] ; [10.80282021,106.74897003] ; [10.80292034,106.74938202] ; [10.80301952,106.74983215] ; [10.80315971,106.75074005] ; [10.80352020,106.75142670] ; [10.80387974,106.75209045] ; [10.80432034,106.75256348] ; [10.80461979,106.75302124] ; [10.80500984,106.75366974] ; [10.80558968,106.75424194] ; [10.80618000,106.75460052] ; [10.80661964,106.75485229] ; [10.80694962,106.75514221] ; [10.80733013,106.75559235] ; [10.80803967,106.75594330] ; [10.80877018,106.75621796] ; [10.80947018,106.75650787] ; [10.81050968,106.75662994] ; [10.81101990,106.75669098] ; [10.81138992,106.75772858] ; [10.81686020,106.75784302] ; [10.81725025,106.75820160] ; [10.81894970,106.75823975]"
    ,"Distance":"2327"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"481"
    ,"Station_Code":"Q9 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"185A, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.825972
    ,"Long":106.760775
    ,"Polyline":"[106.75823975,10.81917953] ; [106.75846863,10.82038021] ; [106.75865936,10.82139015] ; [106.75891876,10.82240963] ; [106.75916290,10.82306004] ; [106.75942230,10.82365990] ; [106.75946045,10.82380962] ; [106.75950623,10.82392025] ; [106.75980377,10.82448006] ; [106.76068115,10.82600975]"
    ,"Distance":"813"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"485"
    ,"Station_Code":"Q9 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm xây dựng"
    ,"Station_Address":"354A, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.829955
    ,"Long":106.76312
    ,"Polyline":"[106.76068115,10.82600975] ; [106.76112366,10.82678032] ; [106.76235962,10.82892036] ; [106.76296234,10.82999039]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"483"
    ,"Station_Code":"Q9 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Khu QLGTDT số 2"
    ,"Station_Address":"Khu QLGTĐT số 2, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.833249
    ,"Long":106.764778
    ,"Polyline":"[106.76296234,10.82999039] ; [106.76477814,10.83325005]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1025"
    ,"Station_Code":"Q9 214"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Kho 71 , đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.836162
    ,"Long":106.76666
    ,"Polyline":"[106.76477814,10.83325005] ; [106.76647186,10.83621979]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1030"
    ,"Station_Code":"Q9 215"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"UBND quận 9"
    ,"Station_Address":"1B, đường Xa Lộ H à Nội, Quận 9"
    ,"Lat":10.840466
    ,"Long":106.769074
    ,"Polyline":"[106.76647186,10.83621979] ; [106.76822662,10.83934021] ; [106.76892090,10.84057045]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1026"
    ,"Station_Code":"Q9 216"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bê tông Hải Âu"
    ,"Station_Address":"Bê tông Hải Âu, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.843834
    ,"Long":106.77079
    ,"Polyline":"[106.76892090,10.84057045] ; [106.77076721,10.84383011]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1028"
    ,"Station_Code":"Q9 217"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã 4 Thủ Đức"
    ,"Station_Address":"712, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.847142
    ,"Long":106.772974
    ,"Polyline":"[106.77076721,10.84383011] ; [106.77150726,10.84517956] ; [106.77175903,10.84545994] ; [106.77204132,10.84582996] ; [106.77229309,10.84620953] ; [106.77281189,10.84710979]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"494"
    ,"Station_Code":"Q9 218"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Công an Quận 9"
    ,"Station_Address":"Công an Quận 9, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.849966
    ,"Long":106.775066
    ,"Polyline":"[106.77281189,10.84710979] ; [106.77333069,10.84799957] ; [106.77368927,10.84848976] ; [106.77414703,10.84902954] ; [106.77458191,10.84947968] ; [106.77507019,10.84990025]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"498"
    ,"Station_Code":"Q9 219"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ chiều"
    ,"Station_Address":"Kế 830 (Chợ Chi ều), đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.853511
    ,"Long":106.780474
    ,"Polyline":"[106.77507019,10.84990025] ; [106.77549744,10.85027981] ; [106.77593994,10.85058975] ; [106.77648926,10.85103989] ; [106.77693939,10.85134983] ; [106.77751923,10.85171032] ; [106.77758026,10.85181999] ; [106.77851105,10.85239029] ; [106.78000641,10.85330963] ; [106.78044128,10.85358047]"
    ,"Distance":"718"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"495"
    ,"Station_Code":"Q9 220"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Khu Công ngh ệ cao quận 9"
    ,"Station_Address":"Khu công ngh ệ cao, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.858511
    ,"Long":106.788869
    ,"Polyline":"[106.78044128,10.85358047] ; [106.78164673,10.85431957] ; [106.78484344,10.85618973] ; [106.78681946,10.85729027] ; [106.78800201,10.85803032] ; [106.78878784,10.85851002]"
    ,"Distance":"1065"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"536"
    ,"Station_Code":"Q9 221"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Cầu Vượt  Trạm 2"
    ,"Station_Address":"Tiệm vàng Kim Lợi, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.863595
    ,"Long":106.797538
    ,"Polyline":"[106.78878784,10.85851002] ; [106.79067230,10.85966969] ; [106.79197693,10.86044979] ; [106.79512024,10.86227989] ; [106.79592896,10.86273956] ; [106.79680634,10.86328030] ; [106.79727936,10.86357021]"
    ,"Distance":"1085"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"537"
    ,"Station_Code":"Q9 223"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"Suối Tiên, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.866498
    ,"Long":106.802377
    ,"Polyline":"[106.79753876,10.86359501] ; [106.80146790,10.86606026] ; [106.80248260,10.86666965] ; [106.80237579,10.86649799]"
    ,"Distance":"662"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1919"
    ,"Station_Code":"Q9 225"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Nghĩa trang liệt sĩ TP.HCM"
    ,"Station_Address":"Nghĩa trang liệt sĩ Thành  phố HCM, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.873694
    ,"Long":106.809286
    ,"Polyline":"[106.80248260,10.86666965] ; [106.80357361,10.86740971] ; [106.80422211,10.86791039] ; [106.80460358,10.86822987] ; [106.80522156,10.86880016] ; [106.80615997,10.86979008] ; [106.80673218,10.87049007] ; [106.80814362,10.87240028] ; [106.80947113,10.87421989]"
    ,"Distance":"1145"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1097"
    ,"Station_Code":"Q9 227"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Công ty Nam  Hàn"
    ,"Station_Address":"Công ty TNHH Nam H àn, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.884067
    ,"Long":106.816818
    ,"Polyline":"[106.80947113,10.87421989] ; [106.81282806,10.87882042]"
    ,"Distance":"630"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1098"
    ,"Station_Code":"Q9 228"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Khu tưởng niệm các Vua Hùng"
    ,"Station_Address":"Kho 190C - 19/11 Hiệp Thắng, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.887623
    ,"Long":106.81943
    ,"Polyline":"[106.81681824,10.88406658] ; [106.81690979,10.88436985] ; [106.81897736,10.88716984] ; [106.81941223,10.88776970] ; [106.81942749,10.88762283]"
    ,"Distance":"519"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1100"
    ,"Station_Code":"Q9 229"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Trạm xăng Hiệp Phú"
    ,"Station_Address":"Trạm xăng Hiệp Phú, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.893459
    ,"Long":106.823743
    ,"Polyline":"[106.81941223,10.88776970] ; [106.82103729,10.88998032] ; [106.82296753,10.89260960] ; [106.82341003,10.89315033] ; [106.82372284,10.89356995]"
    ,"Distance":"799"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1099"
    ,"Station_Code":"BD004"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Ngã 3 Tân Vạn"
    ,"Station_Address":"Ngã 3 Tân Vạn, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.896781
    ,"Long":106.827225
    ,"Polyline":"[106.82372284,10.89356995] ; [106.82411194,10.89410973] ; [106.82453918,10.89461994] ; [106.82511139,10.89523029] ; [106.82543182,10.89552975] ; [106.82601166,10.89601040] ; [106.82652283,10.89638042] ; [106.82720947,10.89680958]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"35"
    ,"Station_Id":"1871"
    ,"Station_Code":"BX86"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Tân Vạn"
    ,"Station_Address":"Ngã ba Tân Vạn, đường Xa L ộ Hà Nội, Quận 9"
    ,"Lat":10.898041725158691
    ,"Long":106.82798767089844
    ,"Polyline":"[106.82722473,10.89678097] ; [106.82722473,10.89678097] ; [106.84339142,10.90282536] ; [106.84613800,10.90392113] ; [106.84728241,10.90456867] ; [106.84832764,10.90534878] ; [106.84878540,10.90570164] ; [106.84901428,10.90590668] ; [106.84895325,10.90604877] ; [106.84880829,10.90609646] ; [106.84860229,10.90601730] ; [106.84853363,10.90590096] ; [106.84825134,10.90558529] ; [106.84744263,10.90498447] ; [106.84719849,10.90481663] ; [106.84695435,10.90524292] ; [106.84670258,10.90513229] ; [106.84695435,10.90466881] ; [106.84607697,10.90415287] ; [106.84384155,10.90339375] ; [106.83794403,10.90109730] ; [106.83247375,10.89899063] ; [106.83139801,10.89870548] ; [106.83107758,10.89883232] ; [106.83081055,10.89884853] ; [106.83005524,10.89853764] ; [106.82869720,10.89792633] ; [106.82830048,10.89786816] ; [106.82798767,10.89804173]"
    ,"Distance":"5238"
  }]