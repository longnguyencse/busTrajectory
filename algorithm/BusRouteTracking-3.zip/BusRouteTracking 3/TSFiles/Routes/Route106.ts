export const Route106 =[

  {
     "Route_Id":"106"
    ,"Station_Id":"3522"
    ,"Station_Code":"BX 67"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe buýt Bến Súc"
    ,"Station_Address":"Bến xe buýt Bến Súc, đường T ỉnh lộ 15, Huyện Củ Chi"
    ,"Lat":11.155424
    ,"Long":106.45372
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3536"
    ,"Station_Code":"QCCT103"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 3 Đền Bến Dược"
    ,"Station_Address":"2185, đường Tỉnh lộ 15 Củ Chi, Huy ện Củ Chi"
    ,"Lat":11.149666786193848
    ,"Long":106.46046447753906
    ,"Polyline":"[106.45372009,11.15542412] ; [106.45532227,11.15501404] ; [106.45718384,11.15444565] ; [106.45772552,11.15405560] ; [106.45817566,11.15348721] ; [106.45852661,11.15290833] ; [106.45920563,11.15149784] ; [106.45957184,11.15079308] ; [106.45999908,11.15009785] ; [106.46046448,11.14966679]"
    ,"Distance":"1044"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3533"
    ,"Station_Code":"QCCT104"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Lai Thai"
    ,"Station_Address":"2045, đường Tỉnh lộ 15 Củ Chi, Huyện C ủ Chi"
    ,"Lat":11.142566680908203
    ,"Long":106.46981811523438
    ,"Polyline":"[106.46046448,11.14966679] ; [106.46981812,11.14256668]"
    ,"Distance":"1292"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3534"
    ,"Station_Code":"QCCT105"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Xã Phú Mỹ Hưng"
    ,"Station_Address":"1979, đường  Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.139049530029297
    ,"Long":106.47348022460938
    ,"Polyline":"[106.46981812,11.14256668] ; [106.47148895,11.14106655] ; [106.47348022,11.13904953]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3538"
    ,"Station_Code":"QCCT106"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã 3 Tỉnh lộ 15"
    ,"Station_Address":"1833, đường Tỉnh lộ 15 Củ Chi, Huy ện Củ Chi"
    ,"Lat":11.130499839782715
    ,"Long":106.47985076904297
    ,"Polyline":"[106.47348022,11.13904953] ; [106.47412872,11.13828754] ; [106.47433472,11.13787651] ; [106.47466278,11.13657093] ; [106.47518921,11.13585567] ; [106.47598267,11.13501358] ; [106.47730255,11.13354969] ; [106.47933960,11.13132858] ; [106.47985077,11.13049984]"
    ,"Distance":"1195"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3537"
    ,"Station_Code":"QCCT107"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Nguyễn Thị Rành"
    ,"Station_Address":"1799 (Đối diện 1694), đường Tỉnh lộ  15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.129483222961426
    ,"Long":106.48374938964844
    ,"Polyline":"[106.47985077,11.13049984] ; [106.48011780,11.13010788] ; [106.48025513,11.13000298] ; [106.48041534,11.12993908] ; [106.48208618,11.12974453] ; [106.48374939,11.12948322]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3539"
    ,"Station_Code":"QCCT108"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã 3 C ây Gỗ"
    ,"Station_Address":"1771 (1171), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.129166603088379
    ,"Long":106.48695373535156
    ,"Polyline":"[106.48374939,11.12948322] ; [106.48463440,11.12938690] ; [106.48527527,11.12926579] ; [106.48695374,11.12916660]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3540"
    ,"Station_Code":"QCCT109"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Phú Bình"
    ,"Station_Address":"1645-1647 , đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.124349594116211
    ,"Long":106.49323272705078
    ,"Polyline":"[106.48695374,11.12916660] ; [106.48805237,11.12918186] ; [106.48841858,11.12907600] ; [106.49060822,11.12687588] ; [106.49323273,11.12434959]"
    ,"Distance":"906"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3541"
    ,"Station_Code":"QCCT110"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Xã An Phú"
    ,"Station_Address":"1561, đường  Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.119783401489258
    ,"Long":106.49788665771484
    ,"Polyline":"[106.49323273,11.12434959] ; [106.49788666,11.11978340]"
    ,"Distance":"719"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3542"
    ,"Station_Code":"QCCT111"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Công ty bò sửa An Phú"
    ,"Station_Address":"1467-1469 , đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.115616798400879
    ,"Long":106.5020980834961
    ,"Polyline":"[106.49788666,11.11978340] ; [106.50209808,11.11561680]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3544"
    ,"Station_Code":"QCCT112"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Một thoáng Việt Nam"
    ,"Station_Address":"1329, đường Tỉnh lộ 15 Củ  Chi, Huyện Củ Chi"
    ,"Lat":11.110483169555664
    ,"Long":106.50659942626953
    ,"Polyline":"[106.50209808,11.11561680] ; [106.50277710,11.11501694] ; [106.50337219,11.11438560] ; [106.50371552,11.11413288] ; [106.50453186,11.11324310.06.50582886] ; [11.11190605,106.50603485] ; [11.11170101,106.50624084] ; [11.11142731,106.50659943]"
    ,"Distance":"763"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3543"
    ,"Station_Code":"QCCT113"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Đường  787"
    ,"Station_Address":"1239, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.105517387390137
    ,"Long":106.50845336914062
    ,"Polyline":"[106.50659943,11.11048317] ; [106.50715637,11.10933208] ; [106.50767517,11.10802078] ; [106.50831604,11.10622597] ; [106.50845337,11.10551739]"
    ,"Distance":"590"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3545"
    ,"Station_Code":"QCCT114"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn Văn Tiệp"
    ,"Station_Address":"112, đường Ti ̉nh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.098532676696777
    ,"Long":106.51066589355469
    ,"Polyline":"[106.50845337,11.10551739] ; [106.50878906,11.10439968] ; [106.50908661,11.10317326] ; [106.50988007,11.10085297] ; [106.51023865,11.09970379] ; [106.51034546,11.09931469] ; [106.51066589,11.09853268]"
    ,"Distance":"815"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3546"
    ,"Station_Code":"QCCT115"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Nghĩa trang An Nhơn Tây"
    ,"Station_Address":"1109 , đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.094685554504395
    ,"Long":106.51249694824219
    ,"Polyline":"[106.51066589,11.09853268] ; [106.51091003,11.09838772] ; [106.51177216,11.09672451] ; [106.51229095,11.09598732] ; [106.51240540,11.09563541] ; [106.51249695,11.09468555]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3547"
    ,"Station_Code":"QCCT116"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã tư An Nhơn Tây"
    ,"Station_Address":"20-22, đường Tỉnh lộ 15 Cu ̉ Chi, Huyện Củ Chi"
    ,"Lat":11.08946704864502
    ,"Long":106.51388549804688
    ,"Polyline":"[106.51249695,11.09468555] ; [106.51268005,11.09429264] ; [106.51332092,11.09198666] ; [106.51376343,11.09018612] ; [106.51388550,11.08946705]"
    ,"Distance":"601"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3548"
    ,"Station_Code":"QCCT117"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Xã An  Nhơn Tây"
    ,"Station_Address":"Đối diện 872, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.084600448608398
    ,"Long":106.51513671875
    ,"Polyline":"[106.51388550,11.08946705] ; [106.51429749,11.08819675] ; [106.51513672,11.08460045]"
    ,"Distance":"559"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3549"
    ,"Station_Code":"QCCT118"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"911A, đường Tỉnh lộ 15 Củ  Chi, Huyện Củ Chi"
    ,"Lat":11.080666542053223
    ,"Long":106.51625061035156
    ,"Polyline":"[106.51513672,11.08460045] ; [106.51548767,11.08323765] ; [106.51580048,11.08186913] ; [106.51625061,11.08066654]"
    ,"Distance":"455"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3551"
    ,"Station_Code":"QCCT119"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường  Thiếu Sinh Quân"
    ,"Station_Address":"Trường Thiếu  Sinh Quân, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.070067405700684
    ,"Long":106.52200317382812
    ,"Polyline":"[106.51625061,11.08066654] ; [106.51645660,11.07998943] ; [106.51674652,11.07931614] ; [106.51728821,11.07796288] ; [106.51839447,11.07527256] ; [106.51903534,11.07368755] ; [106.52014160,11.07146645] ; [106.52068329,11.07099819] ; [106.52130127,11.07065582] ; [106.52200317,11.07006741]"
    ,"Distance":"1367"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3550"
    ,"Station_Code":"QCCT120"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Địa đạo Bến Đình"
    ,"Station_Address":"Cột điện ANT 116b, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.061483383178711
    ,"Long":106.52935028076172
    ,"Polyline":"[106.52200317,11.07006741] ; [106.52390289,11.06843948] ; [106.52587128,11.06683350] ; [106.52613068,11.06658077] ; [106.52642059,11.06626511] ; [106.52678680,11.06578064] ; [106.52709198,11.06540108] ; [106.52754211,11.06470108] ; [106.52861023,11.06299019] ; [106.52894592,11.06222725] ; [106.52935028,11.06148338]"
    ,"Distance":"1265"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3552"
    ,"Station_Code":"QCCT121"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Xăng dầu Tân Phong"
    ,"Station_Address":"667 (Xăng dầu Tân Phong), đường Tỉnh lộ 15 Củ Chi, Huyện Củ  Chi"
    ,"Lat":11.056483268737793
    ,"Long":106.5317153930664
    ,"Polyline":"[106.52935028,11.06148338] ; [106.53001404,11.05991554] ; [106.53078461,11.05826283] ; [106.53130341,11.05712032] ; [106.53171539,11.05648327]"
    ,"Distance":"615"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3553"
    ,"Station_Code":"QCCT122"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Trường tiều học Nhuận Đức"
    ,"Station_Address":"599, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.052066802978516
    ,"Long":106.53748321533203
    ,"Polyline":"[106.53171539,11.05648327] ; [106.53192139,11.05594063] ; [106.53227997,11.05528736] ; [106.53267670,11.05490875] ; [106.53445435,11.05365086] ; [106.53568268,11.05298138] ; [106.53712463,11.05233383] ; [106.53748322,11.05206680]"
    ,"Distance":"823"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3555"
    ,"Station_Code":"QCCT123"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bùi Thị Đẹt"
    ,"Station_Address":"529, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.047750473022461
    ,"Long":106.54419708251953
    ,"Polyline":"[106.53748322,11.05206680] ; [106.53816986,11.05169201] ; [106.54419708,11.04775047]"
    ,"Distance":"877"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3554"
    ,"Station_Code":"QCCT124"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bùi Thị Đẹt"
    ,"Station_Address":"501, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.045040130615234
    ,"Long":106.54846954345703
    ,"Polyline":"[106.54419708,11.04775047] ; [106.54627991,11.04637909] ; [106.54846954,11.04504013]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3556"
    ,"Station_Code":"QCCT125"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Bùi Thị Điệt"
    ,"Station_Address":"483, đường Tỉnh  lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.042699813842773
    ,"Long":106.55183410644531
    ,"Polyline":"[106.54846954,11.04504013] ; [106.55051422,11.04372025] ; [106.55183411,11.04269981]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3557"
    ,"Station_Code":"QCCT126"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Phú An"
    ,"Station_Address":"431-433, đường Tỉnh lô ̣ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.04004955291748
    ,"Long":106.55560302734375
    ,"Polyline":"[106.55183411,11.04269981] ; [106.55560303,11.04004955]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3558"
    ,"Station_Code":"QCCT127"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cây Tr ắc"
    ,"Station_Address":"395, đường Tỉnh lộ  15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.037266731262207
    ,"Long":106.55953216552734
    ,"Polyline":"[106.55560303,11.04004955] ; [106.55953217,11.03726673]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3559"
    ,"Station_Code":"QCCT128"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà th ờ Phú Hòa Đông"
    ,"Station_Address":"257A (Đối di ện 254), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.028667449951172
    ,"Long":106.56501770019531
    ,"Polyline":"[106.55953217,11.03726673] ; [106.55991364,11.03698158] ; [106.56036377,11.03661251] ; [106.56121826,11.03577042] ; [106.56152344,11.03552818] ; [106.56183624,11.03542805] ; [106.56211090,11.03540134] ; [106.56278229,11.03551197] ; [106.56369019,11.03562832] ; [106.56411743,11.03560734] ; [106.56451416,11.03552818] ; [106.56468201,11.03548050] ; [106.56480408,11.03540134] ; [106.56486511,11.03528595] ; [106.56499481,11.03473282] ; [106.56558228,11.03407478] ; [106.56600189,11.03363228] ; [106.56611633,11.03339005] ; [106.56609344,11.03318501] ; [106.56573486,11.03262138] ; [106.56543732,11.03233719] ; [106.56530762,11.03206921] ; [106.56526947,11.03178406] ; [106.56527710,11.03115749] ; [106.56522369,11.03050232] ; [106.56501770,11.02866745]"
    ,"Distance":"1486"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3560"
    ,"Station_Code":"QCCT129"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường tiểu học Phú Hòa Đông"
    ,"Station_Address":"91D , đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.0217866897583
    ,"Long":106.56378936767578
    ,"Polyline":"[106.56501770,11.02866745] ; [106.56455994,11.02518749] ; [106.56449127,11.02461815] ; [106.56423187,11.02347565] ; [106.56378937,11.02178669]"
    ,"Distance":"779"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3561"
    ,"Station_Code":"QCCT130"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nguyễn Thị Nê"
    ,"Station_Address":"51 (223), đường Tỉnh lộ 15 Củ Chi,  Huyện Củ Chi"
    ,"Lat":11.018635749816895
    ,"Long":106.56340026855469
    ,"Polyline":"[106.56378937,11.02178669] ; [106.56361389,11.02087975] ; [106.56359100,11.02053261] ; [106.56349182,11.01923752] ; [106.56340027,11.01863575]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3563"
    ,"Station_Code":"QCCT131"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"1203 (Cừ  tràm Năm Hồng)"
    ,"Station_Address":"Đối diện vựa cừ tràm Năm Hồng, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.010832786560059
    ,"Long":106.56407928466797
    ,"Polyline":"[106.56340027,11.01863575] ; [106.56333923,11.01710987] ; [106.56310272,11.01591969] ; [106.56296539,11.01468754] ; [106.56327057,11.01230717] ; [106.56352997,11.01170731] ; [106.56407928,11.01083279]"
    ,"Distance":"897"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3562"
    ,"Station_Code":"QCCT132"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Đá hoa cương"
    ,"Station_Address":"Kế 373, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.999300003051758
    ,"Long":106.56988525390625
    ,"Polyline":"[106.56407928,11.01083279] ; [106.56988525,10.99930000]"
    ,"Distance":"1432"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3564"
    ,"Station_Code":"QCCT133"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Láng The"
    ,"Station_Address":"339 (321), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.996600151062012
    ,"Long":106.57102966308594
    ,"Polyline":"[106.56988525,10.99930000] ; [106.57008362,10.99894333] ; [106.57102966,10.99660015]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3565"
    ,"Station_Code":"QCCT134"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"(Citimart Sài Gòn)"
    ,"Station_Address":"263 Citimart  Sài Gòn, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.990633010864258
    ,"Long":106.573486328125
    ,"Polyline":"[106.57102966,10.99660015] ; [106.57227325,10.99365616] ; [106.57348633,10.99063301]"
    ,"Distance":"716"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3566"
    ,"Station_Code":"QCCT135"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã tư Tân Quy"
    ,"Station_Address":"179 (171-173), đường Tỉnh lộ 15 Củ  Chi, Huyện Củ Chi"
    ,"Lat":10.98479175567627
    ,"Long":106.57601165771484
    ,"Polyline":"[106.57348633,10.99063301] ; [106.57415009,10.98929596] ; [106.57478333,10.98776817] ; [106.57601166,10.98479176]"
    ,"Distance":"707"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"1185"
    ,"Station_Code":"BX 62"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bến xe T ân Quy"
    ,"Station_Address":"Bến xe Tân Quy, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.984251
    ,"Long":106.578176
    ,"Polyline":"[106.57601166,10.98479176] ; [106.57647705,10.98365021] ; [106.57740021,10.98359299] ; [106.57740784,10.98397732]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"1185"
    ,"Station_Code":"BX 62"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Tân Quy"
    ,"Station_Address":"Bến xe Tân Quy,  đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.984251
    ,"Long":106.578176
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"1322"
    ,"Station_Code":"QCCT360"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường  PTTH Tân Phú Trung"
    ,"Station_Address":"749, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.983782768249512
    ,"Long":106.57693481445312
    ,"Polyline":"[106.57740784,10.98397732] ; [106.57741547,10.98369312] ; [106.57693481,10.98378277]"
    ,"Distance":"85"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3485"
    ,"Station_Code":"QCCT069"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã tư Tân Quy"
    ,"Station_Address":"1044 (46-47), đường Tỉnh lộ 15 Củ Chi, Huyện Củ  Chi"
    ,"Lat":10.984983444213867
    ,"Long":106.57598114013672
    ,"Polyline":"[106.57693481,10.98378277] ; [106.57653809,10.98373508] ; [106.57598114,10.98498344]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3489"
    ,"Station_Code":"QCCT070"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Pháp Bửu"
    ,"Station_Address":"1112, đường Tỉnh lộ 15 Củ Chi, Huy ện Củ Chi"
    ,"Lat":10.988499641418457
    ,"Long":106.57450866699219
    ,"Polyline":"[106.57598114,10.98498344] ; [106.57450867,10.98849964]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3491"
    ,"Station_Code":"QCCT071"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bàu Trâm"
    ,"Station_Address":"1152, đường Tỉnh lộ 15 Củ Chi, Huyện C ủ Chi"
    ,"Lat":10.991227149963379
    ,"Long":106.57337188720703
    ,"Polyline":"[106.57450867,10.98849964] ; [106.57337189,10.99122715]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3487"
    ,"Station_Code":"QCCT072"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Láng The"
    ,"Station_Address":"1206, đường Tỉnh lộ 15 Củ Chi, Huyện C ủ Chi"
    ,"Lat":10.9951171875
    ,"Long":106.57171630859375
    ,"Polyline":"[106.57337189,10.99122715] ; [106.57171631,10.99511719]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3493"
    ,"Station_Code":"QCCT073"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Thạnh An"
    ,"Station_Address":"Đối diện 375 (575), đường Tỉnh lộ 15 Cu ̉ Chi, Huyện Củ Chi"
    ,"Lat":10.999616622924805
    ,"Long":106.5698471069336
    ,"Polyline":"[106.57171631,10.99511719] ; [106.56984711,10.99961662]"
    ,"Distance":"541"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3488"
    ,"Station_Code":"QCCT074"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Bến  Nẩy"
    ,"Station_Address":"Đối diện 1203 (HTX  Cây trồng Minh Khoa), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.011449813842773
    ,"Long":106.56378173828125
    ,"Polyline":"[106.56984711,10.99961662] ; [106.56378174,11.01144981]"
    ,"Distance":"1475"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3490"
    ,"Station_Code":"QCCT075"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nguyễn Thị Bâng"
    ,"Station_Address":"42, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.017749786376953
    ,"Long":106.56351470947266
    ,"Polyline":"[106.56378174,11.01144981] ; [106.56341553,11.01235008] ; [106.56336212,11.01304436] ; [106.56313324,11.01459312] ; [106.56313324,11.01508808] ; [106.56345367,11.01699352] ; [106.56351471,11.01774979]"
    ,"Distance":"714"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3494"
    ,"Station_Code":"QCCT076"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Nguyễn Văn Khạ"
    ,"Station_Address":"108, đường Tỉnh lộ 15 Củ Chi, Huyện Củ  Chi"
    ,"Lat":11.022482872009277
    ,"Long":106.56414794921875
    ,"Polyline":"[106.56351471,11.01774979] ; [106.56375885,11.02089024] ; [106.56414795,11.02248287]"
    ,"Distance":"533"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3492"
    ,"Station_Code":"QCCT077"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ấp An Hòa"
    ,"Station_Address":"236-238, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.029796600341797
    ,"Long":106.56531524658203
    ,"Polyline":"[106.56414795,11.02248287] ; [106.56461334,11.02445030] ; [106.56481934,11.02606106.06.56500244] ; [11.02762985,106.56531525]"
    ,"Distance":"825"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3495"
    ,"Station_Code":"QCCT078"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Cây Trắc"
    ,"Station_Address":"Đối diện 401 (366), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.037567138671875
    ,"Long":106.55924987792969
    ,"Polyline":"[106.56531525,11.02979660] ; [106.56539917,11.03139496] ; [106.56538391,11.03177357] ; [106.56542206,11.03204250] ; [106.56551361,11.03226852] ; [106.56583405,11.03258991] ; [106.56620789,11.03313255] ; [106.56623840,11.03341675] ; [106.56610107,11.03369617] ; [106.56568909,11.03413296] ; [106.56510925,11.03474903] ; [106.56497192,11.03530693] ; [106.56491089,11.03545952] ; [106.56465912,11.03560734] ; [106.56411743,11.03570747] ; [106.56370544,11.03572845] ; [106.56282806,11.03562260] ; [106.56211853,11.03550720] ; [106.56185913,11.03553867] ; [106.56160736,11.03562260] ; [106.56130219,11.03583908] ; [106.56104279,11.03608131] ; [106.56042480,11.03670216] ; [106.55984497,11.03714943] ; [106.55924988,11.03756714]"
    ,"Distance":"1416"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3497"
    ,"Station_Code":"QCCT079"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Phú An"
    ,"Station_Address":"394, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.039950370788574
    ,"Long":106.55584716796875
    ,"Polyline":"[106.55924988,11.03756714] ; [106.55584717,11.03995037]"
    ,"Distance":"457"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3496"
    ,"Station_Code":"QCCT080"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Bùi Thị Điệt"
    ,"Station_Address":"483 (Đối diện 483), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.04283332824707
    ,"Long":106.55176544189453
    ,"Polyline":"[106.55584717,11.03995037] ; [106.55176544,11.04283333]"
    ,"Distance":"549"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3499"
    ,"Station_Code":"QCCT081"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bùi Thị Đẹt"
    ,"Station_Address":"452A, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.044966697692871
    ,"Long":106.54865264892578
    ,"Polyline":"[106.55176544,11.04283333] ; [106.54865265,11.04496670]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3498"
    ,"Station_Code":"QCCT082"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bùi Thị Đẹt"
    ,"Station_Address":"Kế 476A, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.047599792480469
    ,"Long":106.54447937011719
    ,"Polyline":"[106.54865265,11.04496670] ; [106.54447937,11.04759979]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3500"
    ,"Station_Code":"QCCT083"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"trường tiểu học Nhuận Đức"
    ,"Station_Address":"Đối diện trường tiểu học Nhuận Đức, đường Tỉnh lộ 15  Củ Chi, Huyện Củ Chi"
    ,"Lat":11.051650047302246
    ,"Long":106.538330078125
    ,"Polyline":"[106.54447937,11.04759979] ; [106.53833008,11.05165005]"
    ,"Distance":"809"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3502"
    ,"Station_Code":"QCCT084"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Xăng d ầu Tân Phong"
    ,"Station_Address":"608, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.05716323852539
    ,"Long":106.53146362304688
    ,"Polyline":"[106.53833008,11.05165005] ; [106.53714752,11.05248165] ; [106.53571320,11.05310249] ; [106.53452301,11.05377674] ; [106.53275299,11.05499840] ; [106.53239441,11.05534554] ; [106.53186035,11.05625153] ; [106.53146362,11.05716324]"
    ,"Distance":"999"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3501"
    ,"Station_Code":"QCCT085"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Địa đạo Bến Đình"
    ,"Station_Address":"654, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.06216049194336
    ,"Long":106.52911376953125
    ,"Polyline":"[106.53146362,11.05716324] ; [106.52911377,11.06216049]"
    ,"Distance":"613"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3503"
    ,"Station_Code":"QCCT086"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường Thiếu Sinh Quân"
    ,"Station_Address":"Trường Thiếu  Sinh Quân, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.069592475891113
    ,"Long":106.5226821899414
    ,"Polyline":"[106.52911377,11.06216049] ; [106.52888489,11.06259537] ; [106.52870178,11.06305313] ; [106.52719116,11.06544399] ; [106.52648926,11.06634903] ; [106.52600098,11.06684399] ; [106.52460480,11.06798649] ; [106.52268219,11.06959248]"
    ,"Distance":"1100"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3505"
    ,"Station_Code":"QCCT087"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"820, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.080514907836914
    ,"Long":106.51644897460938
    ,"Polyline":"[106.52268219,11.06959248] ; [106.52138519,11.07072926] ; [106.52064514,11.07114029] ; [106.52024078,11.07147694] ; [106.51914978,11.07374096] ; [106.51827240,11.07580948] ; [106.51721191,11.07841015] ; [106.51678467,11.07945824] ; [106.51652527,11.08009529] ; [106.51643372,11.08034706] ; [106.51644897,11.08051491]"
    ,"Distance":"1431"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3504"
    ,"Station_Code":"QCCT088"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Xã An Nhơn Tây"
    ,"Station_Address":"890, đường Tỉnh lộ 15 Củ Chi, Huyện Củ  Chi"
    ,"Lat":11.085189819335938
    ,"Long":106.51515197753906
    ,"Polyline":"[106.51644897,11.08051491] ; [106.51590729,11.08203697] ; [106.51515198,11.08518982]"
    ,"Distance":"540"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3506"
    ,"Station_Code":"QCCT089"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà văn hóa Cụm An Nhơn Tây"
    ,"Station_Address":"Đối diện 1029, đường Ti ̉nh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.089067459106445
    ,"Long":106.51408386230469
    ,"Polyline":"[106.51515198,11.08518982] ; [106.51408386,11.08906746]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3507"
    ,"Station_Code":"QCCT090"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nghĩa trang An Nhơn Tây"
    ,"Station_Address":"35A (Kế 1020), đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.09433650970459
    ,"Long":106.51278686523438
    ,"Polyline":"[106.51408386,11.08906746] ; [106.51278687,11.09433651]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3510"
    ,"Station_Code":"QCCT091"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nguyễn Văn Tiệp"
    ,"Station_Address":"1070-1072, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.09822940826416
    ,"Long":106.5110092163086
    ,"Polyline":"[106.51278687,11.09433651] ; [106.51239777,11.09604073] ; [106.51100922,11.09822941]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3509"
    ,"Station_Code":"QCCT092"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Đường 787"
    ,"Station_Address":"1154, đường Tỉnh lộ 15 Cu ̉ Chi, Huyện Củ Chi"
    ,"Lat":11.106636047363281
    ,"Long":106.50825500488281
    ,"Polyline":"[106.51100922,11.09822941] ; [106.51055908,11.09913540] ; [106.51045227,11.09935665] ; [106.51008606,11.10053062] ; [106.50939178,11.10264111] ; [106.50919342,11.10317802] ; [106.50839233,11.10626316] ; [106.50825500,11.10663605]"
    ,"Distance":"985"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3512"
    ,"Station_Code":"QCCT093"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Xã An  Phú"
    ,"Station_Address":"1242, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.111566543579102
    ,"Long":106.50655364990234
    ,"Polyline":"[106.50825500,11.10663605] ; [106.50738525,11.10905266] ; [106.50635529,11.11144257] ; [106.50655365,11.11156654]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3508"
    ,"Station_Code":"QCCT094"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Công ty bò sửa An Phú"
    ,"Station_Address":"1360, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.116649627685547
    ,"Long":106.50108337402344
    ,"Polyline":"[106.50655365,11.11156654] ; [106.50376892,11.11421108] ; [106.50348663,11.11442184] ; [106.50286102,11.11507988] ; [106.50108337,11.11664963]"
    ,"Distance":"823"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3513"
    ,"Station_Code":"QCCT095"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đối diện 1567"
    ,"Station_Address":"Đối diện 1567, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.1202974319458
    ,"Long":106.4974594116211
    ,"Polyline":"[106.50108337,11.11664963] ; [106.49745941,11.12029743]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3511"
    ,"Station_Code":"QCCT096"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Phú Bình"
    ,"Station_Address":"1532, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.123967170715332
    ,"Long":106.49356842041016
    ,"Polyline":"[106.49745941,11.12029743] ; [106.49356842,11.12396717]"
    ,"Distance":"590"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3517"
    ,"Station_Code":"QCCT097"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã 3 Cây Gõ"
    ,"Station_Address":"Kế 1656, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.129233360290527
    ,"Long":106.48648071289062
    ,"Polyline":"[106.49356842,11.12396717] ; [106.49110413,11.12661266] ; [106.48854828,11.12918186] ; [106.48809814,11.12929153] ; [106.48648071,11.12923336]"
    ,"Distance":"1026"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3514"
    ,"Station_Code":"QCCT098"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã 3 Nguyễn Thị Rành"
    ,"Station_Address":"1686, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.129467010498047
    ,"Long":106.4838638305664
    ,"Polyline":"[106.48648071,11.12923336] ; [106.48386383,11.12946701]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3515"
    ,"Station_Code":"QCCT099"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Nguyễn Thị Rành - Tỉnh lộ 15"
    ,"Station_Address":"Đối diện 1873, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.131916999816895
    ,"Long":106.47886657714844
    ,"Polyline":"[106.48386383,11.12946701] ; [106.48052216,11.13005543] ; [106.48022461,11.13017082] ; [106.47943115,11.13143444] ; [106.47886658,11.13191700]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3518"
    ,"Station_Code":"QCCT100"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Xã Phú Mỹ Hưng"
    ,"Station_Address":"1832, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.13933277130127
    ,"Long":106.47333526611328
    ,"Polyline":"[106.47886658,11.13191700] ; [106.47735596,11.13369751] ; [106.47525787,11.13606644] ; [106.47485352,11.13663483] ; [106.47467804,11.13701344] ; [106.47449493,11.13792896] ; [106.47421265,11.13844490] ; [106.47384644,11.13890839] ; [106.47333527,11.13933277]"
    ,"Distance":"1038"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3520"
    ,"Station_Code":"QCCT101"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Lai Thai"
    ,"Station_Address":"1928-1930, đường Tỉnh lộ 15 Củ Chi , Huyện Củ Chi"
    ,"Lat":11.143166542053223
    ,"Long":106.46913146972656
    ,"Polyline":"[106.47333527,11.13933277] ; [106.47209930,11.14069748] ; [106.47067261,11.14202404] ; [106.46913147,11.14316654]"
    ,"Distance":"629"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3516"
    ,"Station_Code":"QCCT102"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã 3 Đền  Bến Dược"
    ,"Station_Address":"2056, đường Ti ̉nh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.1493501663208
    ,"Long":106.46099853515625
    ,"Polyline":"[106.46913147,11.14316654] ; [106.46099854,11.14935017]"
    ,"Distance":"1124"
  },
  {
     "Route_Id":"106"
    ,"Station_Id":"3522"
    ,"Station_Code":"BX 67"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Bến xe buýt Bến Súc"
    ,"Station_Address":"Bến xe buýt Bến Súc, đường Tỉnh lộ 15, Huyện Củ Chi"
    ,"Lat":11.155424
    ,"Long":106.45372
    ,"Polyline":"[106.46099854,11.14935017] ; [106.46015167,11.15016079] ; [106.45902252,11.15222454] ; [106.45875549,11.15287685] ; [106.45777893,11.15420341] ; [106.45720673,11.15462399] ; [106.45382690,11.15564537] ; [106.45372009,11.15542412]"
    ,"Distance":"1142"
  }]