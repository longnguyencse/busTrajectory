export const Route76 =[
  {
     "Route_Id":"76"
    ,"Station_Id":"3186"
    ,"Station_Code":"BX31"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"KTX Đại học Sư phạm kỹ thuật"
    ,"Station_Address":"KTX Đại học Sư phạm k ỹ thuật, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845909
    ,"Long":106.797581
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1535"
    ,"Station_Code":"Q9 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bệnh viện  Quận 9"
    ,"Station_Address":"99, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844607
    ,"Long":106.790349
    ,"Polyline":"[106.79758453,10.84590912] ; [106.79735565,10.84627724] ; [106.79035187,10.84460735]"
    ,"Distance":"836"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1532"
    ,"Station_Code":"Q9 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường Trần  Quốc Toản"
    ,"Station_Address":"Đối diện chợ Tăng Nhơn Phú, đường Lê V ăn Việt, Quận 9"
    ,"Lat":10.844923
    ,"Long":106.788209
    ,"Polyline":"[106.79042053,10.84451962] ; [106.78981781,10.84436035] ; [106.78964233,10.84432983] ; [106.78929138,10.84436035] ; [106.78904724,10.84440041] ; [106.78878784,10.84449959] ; [106.78855133,10.84461021] ; [106.78823853,10.84480000] ; [106.78817749,10.84482002]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1537"
    ,"Station_Code":"Q9 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ nhỏ"
    ,"Station_Address":"249 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.84427
    ,"Long":106.784084
    ,"Polyline":"[106.78817749,10.84482002] ; [106.78733063,10.84517002] ; [106.78697968,10.84519005] ; [106.78665161,10.84515953] ; [106.78656006,10.84514999] ; [106.78630066,10.84504032] ; [106.78617096,10.84496021] ; [106.78610992,10.84486961] ; [106.78553772,10.84447956] ; [106.78539276,10.84440994] ; [106.78479767,10.84430981] ; [106.78407288,10.84418964]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1534"
    ,"Station_Code":"Q9 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cổng đình Phong Phú"
    ,"Station_Address":"189-191, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844381
    ,"Long":106.781723
    ,"Polyline":"[106.78407288,10.84418964] ; [106.78273010,10.84399986] ; [106.78231049,10.84407997] ; [106.78182220,10.84426975]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1536"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị  Thành Nghĩa"
    ,"Station_Address":"Đối diện 140-142 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845176
    ,"Long":106.780377
    ,"Polyline":"[106.78172302,10.84438133] ; [106.78141785,10.84442043] ; [106.78103638,10.84461021] ; [106.78050232,10.84504032] ; [106.78038025,10.84512043] ; [106.78038025,10.84517574]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1539"
    ,"Station_Code":"Q9 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện 7C-Trường Quân y 2"
    ,"Station_Address":"91-93, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846799
    ,"Long":106.777512
    ,"Polyline":"[106.78038025,10.84512043] ; [106.78009033,10.84529972] ; [106.77919769,10.84576035] ; [106.77778625,10.84655952] ; [106.77747345,10.84673977]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1538"
    ,"Station_Code":"Q9 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Siêu thị Coopmark"
    ,"Station_Address":"17-19, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.848411
    ,"Long":106.775045
    ,"Polyline":"[106.77747345,10.84673977] ; [106.77583313,10.84768963] ; [106.77510071,10.84823036] ; [106.77494812,10.84834003]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"400"
    ,"Station_Code":"QTD 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường Đại học Sư phạm Kỹ thuật"
    ,"Station_Address":"1, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849823
    ,"Long":106.772089
    ,"Polyline":"[106.77494812,10.84834003] ; [106.77404022,10.84914017] ; [106.77384949,10.84932041] ; [106.77361298,10.84947014] ; [106.77336884,10.84957981] ; [106.77220917,10.84963036]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"402"
    ,"Station_Code":"QTD 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Siêu thị Nguyễn Kim"
    ,"Station_Address":"312, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849805
    ,"Long":106.768837
    ,"Polyline":"[106.77208710,10.84982300] ; [106.77165985,10.84971046] ; [106.77108765,10.84969044] ; [106.76917267,10.84974003] ; [106.76882935,10.84974957] ; [106.76883698,10.84980488]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"403"
    ,"Station_Code":"QTD 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thiếu nhi Thủ Đức"
    ,"Station_Address":"Nhà thiếu nhi, đường Võ V ăn Ngân, Quận Thủ Đức"
    ,"Lat":10.850556
    ,"Long":106.766794
    ,"Polyline":"[106.76882935,10.84974957] ; [106.76818848,10.84976959] ; [106.76777649,10.84984016] ; [106.76760864,10.84994984] ; [106.76741791,10.85015011] ; [106.76728058,10.85031033] ; [106.76711273,10.85042000] ; [106.76699066,10.85046005]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"404"
    ,"Station_Code":"QTD 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"231, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850808
    ,"Long":106.764101
    ,"Polyline":"[106.76679230,10.85055637] ; [106.76458740,10.85072994] ; [106.76432037,10.85076046] ; [106.76409912,10.85080814]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"405"
    ,"Station_Code":"QTD 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"95,  đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850679
    ,"Long":106.75943
    ,"Polyline":"[106.76409912,10.85080814] ; [106.76315308,10.85087013] ; [106.76287842,10.85089016] ; [106.76275635,10.85087967] ; [106.76242828,10.85074043] ; [106.76216125,10.85056019] ; [106.76194000,10.85048008] ; [106.76145935,10.85046005] ; [106.75942230,10.85060024] ; [106.75942993,10.85067940]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"406"
    ,"Station_Code":"QTD 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Làng trẻ em  SOS"
    ,"Station_Address":"249, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.849723
    ,"Long":106.758698
    ,"Polyline":"[106.75942230,10.85060024] ; [106.75862122,10.85064983] ; [106.75868225,10.85041046] ; [106.75875854,10.84972954]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"408"
    ,"Station_Code":"QTD 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường THPT Quận Thủ Đức"
    ,"Station_Address":"229-231, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.848207
    ,"Long":106.759613
    ,"Polyline":"[106.75875854,10.84972954] ; [106.75885773,10.84918022] ; [106.75898743,10.84897041] ; [106.75966644,10.84825993]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"407"
    ,"Station_Code":"QTD 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Công ty may Sài Gòn"
    ,"Station_Address":"Kế 145B, đường  Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.844107
    ,"Long":106.762133
    ,"Polyline":"[106.75966644,10.84825993] ; [106.76048279,10.84727001] ; [106.76058197,10.84714031] ; [106.76087189,10.84685040] ; [106.76116943,10.84642029] ; [106.76135254,10.84605980] ; [106.76145172,10.84580040] ; [106.76154327,10.84535980] ; [106.76155090,10.84523010.06.76161957] ; [10.84508991,106.76194000] ; [10.84461021,106.76222229]"
    ,"Distance":"539"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"411"
    ,"Station_Code":"QTD 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Công ty Sanofi Aventis"
    ,"Station_Address":"15/6C, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.84132
    ,"Long":106.764354
    ,"Polyline":"[106.76222229,10.84418964] ; [106.76264954,10.84348965] ; [106.76338196,10.84224987] ; [106.76361084,10.84197998] ; [106.76378632,10.84185028] ; [106.76441193,10.84142971]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"409"
    ,"Station_Code":"QTD 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Tu viện Quảng Đức"
    ,"Station_Address":"Tu viện Quảng Đức, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.839607
    ,"Long":106.766136
    ,"Polyline":"[106.76441193,10.84142971] ; [106.76564789,10.84060001] ; [106.76583099,10.84045982] ; [106.76589966,10.84037018] ; [106.76621246,10.83977985] ; [106.76627350,10.83967018]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"410"
    ,"Station_Code":"QTD 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Đối diện 592C, đường Xa L ộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.834945
    ,"Long":106.765244
    ,"Polyline":"[106.76613617,10.83960724] ; [106.76640320,10.83908081] ; [106.77210999,10.84947014] ; [106.77256012,10.84955502] ; [106.77298737,10.84953308] ; [106.77350616,10.84928036] ; [106.76524353,10.83494473]"
    ,"Distance":"3374"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"413"
    ,"Station_Code":"QTD 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Công ty truyền tải điện 4"
    ,"Station_Address":"Công ty truyền tải điện 4, đường Xa L ộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.831214
    ,"Long":106.763195
    ,"Polyline":"[106.76524353,10.83494473] ; [106.76319122,10.83121395]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"412"
    ,"Station_Code":"QTD 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"Nhà máy thép Thủ Đức, đường Xa Lộ Hà  Nội, Quận Thủ Đức"
    ,"Lat":10.825366
    ,"Long":106.759998
    ,"Polyline":"[106.76319122,10.83121395] ; [106.75999451,10.82536602]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"414"
    ,"Station_Code":"QTD 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Xi măng Hà Tiên"
    ,"Station_Address":"Xi măng Hà Ti ên 1, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.820576
    ,"Long":106.758142
    ,"Polyline":"[106.75999451,10.82536602] ; [106.75891113,10.82329464] ; [106.75814056,10.82057571]"
    ,"Distance":"574"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"415"
    ,"Station_Code":"Q2 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Đối diện Esstella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802925
    ,"Long":106.747948
    ,"Polyline":"[106.75814056,10.82057571] ; [106.75713348,10.81518078] ; [106.75663757,10.81246185] ; [106.75612640,10.80967999] ; [106.75566101,10.80860519] ; [106.75509644,10.80751896] ; [106.75412750,10.80622292] ; [106.75299072,10.80510616] ; [106.75171661,10.80434704] ; [106.75036621,10.80364132] ; [106.74915314,10.80320930] ; [106.74794769,10.80292511]"
    ,"Distance":"2460"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"416"
    ,"Station_Code":"Q2 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"655, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802134
    ,"Long":106.7434
    ,"Polyline":"[106.74794769,10.80292511] ; [106.74340057,10.80213356]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"417"
    ,"Station_Code":"Q2 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Thảo Đi ền"
    ,"Station_Address":"Ngã ba Thảo Điền, đư ờng Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801309
    ,"Long":106.738762
    ,"Polyline":"[106.74340057,10.80213356] ; [106.73876190,10.80130863]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"418"
    ,"Station_Code":"Q2 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"Đối diện Cầu Đen, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800451
    ,"Long":106.73436
    ,"Polyline":"[106.73876190,10.80130863] ; [106.73435974,10.80045128]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2701"
    ,"Station_Code":"QBTH 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Công viên Cầu Sài Gòn"
    ,"Station_Address":"Đối diện 31N2 (Đd396), đường Ung Văn Khiêm, Quận Bình Thạnh"
    ,"Lat":10.798941
    ,"Long":106.722715
    ,"Polyline":"[106.73435974,10.80045128] ; [106.72842407,10.79920387] ; [106.72506714,10.79860878] ; [106.72282410,10.79816055] ; [106.72246552,10.79809761] ; [106.72209167,10.79806042] ; [106.72190857,10.79804993] ; [106.72171021,10.79804993] ; [106.72159576,10.79807663] ; [106.72148895,10.79814529] ; [106.72142792,10.79822922] ; [106.72138214,10.79832458] ; [106.72137451,10.79842949] ; [106.72139740,10.79851913] ; [106.72143555,10.79859257] ; [106.72151947,10.79866123] ; [106.72163391,10.79874039] ; [106.72176361,10.79879856] ; [106.72194672,10.79885674] ; [106.72213745,10.79889297] ; [106.72271729,10.79894066]"
    ,"Distance":"1640"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2699"
    ,"Station_Code":"QBTH 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Cây Xăng Hoàng Nguyên"
    ,"Station_Address":"113, đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.795267
    ,"Long":106.718094
    ,"Polyline":"[106.72271729,10.79894066] ; [106.72335815,10.79897785] ; [106.72365570,10.79898262] ; [106.72379303,10.79894638] ; [106.72386932,10.79890347] ; [106.72392273,10.79885101] ; [106.72401428,10.79864025] ; [106.72407532,10.79837704] ; [106.72409058,10.79812908] ; [106.72406006,10.79790783] ; [106.72396851,10.79776573] ; [106.72383118,10.79768658] ; [106.72359467,10.79761791] ; [106.72331238,10.79760742] ; [106.72256470,10.79761791] ; [106.72085571,10.79767132] ; [106.72053528,10.79768181] ; [106.72027588,10.79763412] ; [106.72002411,10.79746056] ; [106.71913147,10.79646969] ; [106.71865845,10.79598999] ; [106.71829224,10.79567909] ; [106.71809387,10.79526711]"
    ,"Distance":"1030"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2702"
    ,"Station_Code":"QBTH 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Hồ Bơi Hải Quân"
    ,"Station_Address":"22, đường Nguyễn Hữu Cảnh, Quận Bình Th ạnh"
    ,"Lat":10.789477
    ,"Long":106.710522
    ,"Polyline":"[106.71809387,10.79526711] ; [106.71802521,10.79107857] ; [106.71786499,10.79060459] ; [106.71755219,10.79019356] ; [106.71706390,10.78982449] ; [106.71641541,10.78951931] ; [106.71566772,10.78926563] ; [106.71530151,10.78920269] ; [106.71491241,10.78923416] ; [106.71334839,10.78952980] ; [106.71250153,10.78963470] ; [106.71209717,10.78974056] ; [106.71168518,10.78979301] ; [106.71108246,10.78967667] ; [106.71052551,10.78947735]"
    ,"Distance":"1386"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2703"
    ,"Station_Code":"Q1 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"1, đường Nguyễn Hữu Cảnh,  Quận 1"
    ,"Lat":10.784149
    ,"Long":106.707555
    ,"Polyline":"[106.71052551,10.78947735] ; [106.71001434,10.78901291] ; [106.70967865,10.78841209] ; [106.70911407,10.78686333] ; [106.70857239,10.78548241] ; [106.70825958,10.78494453] ; [106.70755768,10.78414917]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1192"
    ,"Station_Code":"Q1 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngô Văn Năm"
    ,"Station_Address":"3C, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.779807
    ,"Long":106.707609
    ,"Polyline":"[106.70755768,10.78414917] ; [106.70757294,10.78411007] ; [106.70607758,10.78238010.06.70619965] ; [10.78227043,106.70699310] ; [10.78147030,106.70745087] ; [10.78104973,106.70790863] ; [10.78063011,106.70786285] ; [10.78038979,106.70761108]"
    ,"Distance":"635"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn  Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70762634,10.77964020] ; [106.70726013,10.77820969] ; [106.70699310,10.77702999] ; [106.70681000,10.77632046] ; [106.70671844,10.77598000] ; [106.70652771,10.77583027] ; [106.70642853,10.77583027] ; [106.70635223,10.77583027] ; [106.70619965,10.77577972] ; [106.70610046,10.77571011] ; [106.70600128,10.77560997] ; [106.70594025,10.77550030] ; [106.70590210,10.77538967] ; [106.70588684,10.77521038] ; [106.70594025,10.77505016] ; [106.70606232,10.77488995] ; [106.70619202,10.77478981] ; [106.70629883,10.77474976] ; [106.70644379,10.77474976] ; [106.70648956,10.77476025] ; [106.70658112,10.77460003] ; [106.70646667,10.77322006]"
    ,"Distance":"859"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Cục Hải Quan Thành Phố"
    ,"Station_Address":"2-4, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70635986,10.77329922] ; [106.70623779,10.77154922] ; [106.70623779,10.77100086] ; [106.70613098,10.77089024] ; [106.70597076,10.77084827] ; [106.70555115,10.77088547]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84, đường Hàm Nghi, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70555115,10.77088547] ; [106.70302582,10.77097988]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122,  đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70302582,10.77097988] ; [106.70166016,10.77104759]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70166016,10.77104759] ; [106.69935608,10.77116299]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"118"
    ,"Station_Code":"Q1TC1B"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bến Thành B"
    ,"Station_Address":"Bến Thành, đường  Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77084
    ,"Long":106.698532
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69912720,10.77113247] ; [106.69895172,10.77103806] ; [106.69853210,10.77083969]"
    ,"Distance":"98"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"120"
    ,"Station_Code":"Q1 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"8, đường Tr ần Hưng Đạo, Quận 1"
    ,"Lat":10.768772
    ,"Long":106.695923
    ,"Polyline":"[106.69853210,10.77083969] ; [106.69739532,10.77031040] ; [106.69592285,10.76877213]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"121"
    ,"Station_Code":"Q1 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"10, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767363
    ,"Long":106.694695
    ,"Polyline":"[106.69592285,10.76877213] ; [106.69469452,10.76736259]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"122"
    ,"Station_Code":"Q1 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Rạp Hưng Đạo"
    ,"Station_Address":"112, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765832
    ,"Long":106.693375
    ,"Polyline":"[106.69469452,10.76736259] ; [106.69337463,10.76583195]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2976"
    ,"Station_Code":"Q1 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Nguyễn Cư Trinh"
    ,"Station_Address":"34 - 36, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.76471
    ,"Long":106.691933
    ,"Polyline":"[106.69337463,10.76583195] ; [106.69344330,10.76578045] ; [106.69265747,10.76488972] ; [106.69193268,10.76471043]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2973"
    ,"Station_Code":"Q1 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Cống Quỳnh"
    ,"Station_Address":"118, đường Nguy ễn Cư Trinh, Quận 1"
    ,"Lat":10.763884
    ,"Long":106.689842
    ,"Polyline":"[106.69193268,10.76471043] ; [106.69106293,10.76430988] ; [106.69072723,10.76422024] ; [106.69023132,10.76395988] ; [106.68984222,10.76388359]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2975"
    ,"Station_Code":"Q1 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"184, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.763081
    ,"Long":106.687935
    ,"Polyline":"[106.68984222,10.76388359] ; [106.68937683,10.76365471] ; [106.68888855,10.76346016] ; [106.68793488,10.76308060]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1021"
    ,"Station_Code":"Q1 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Nguyễn Tr ãi"
    ,"Station_Address":"Đối diện số 205 - 207, đư ờng Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.760314
    ,"Long":106.683769
    ,"Polyline":"[106.68793488,10.76308060] ; [106.68795776,10.76303005] ; [106.68682098,10.76255035] ; [106.68656158,10.76245022] ; [106.68588257,10.76130009] ; [106.68524170,10.76016998] ; [106.68495941,10.75986958] ; [106.68486023,10.75979042] ; [106.68399048,10.75940037] ; [106.68376923,10.76031399]"
    ,"Distance":"733"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"426"
    ,"Station_Code":"Q5 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Đại học Sư Phạm"
    ,"Station_Address":"280, đường An  Dương Vương, Quận 5"
    ,"Lat":10.76103
    ,"Long":106.68267
    ,"Polyline":"[106.68376923,10.76031399] ; [106.68341827,10.76130390] ; [106.68267059,10.76103020]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"429"
    ,"Station_Code":"Q5 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"370, đường An Dương Vương, Quận 5"
    ,"Lat":10.759407
    ,"Long":106.678764
    ,"Polyline":"[106.68267059,10.76103020] ; [106.67876434,10.75940704]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"427"
    ,"Station_Code":"Q5 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"526, đường An Dương Vương, Quận 5"
    ,"Lat":10.757984
    ,"Long":106.675272
    ,"Polyline":"[106.67876434,10.75940704] ; [106.67527008,10.75798416]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"430"
    ,"Station_Code":"Q5 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"Đối diện số 5, đường An Dương Vương, Qu ận 5"
    ,"Lat":10.757536
    ,"Long":106.673534
    ,"Polyline":"[106.67527008,10.75798416] ; [106.67478180,10.75777340] ; [106.67424011,10.75758362] ; [106.67418671,10.75762558] ; [106.67412567,10.75764179] ; [106.67405701,10.75763130] ; [106.67398071,10.75759983] ; [106.67353058,10.75753593]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"428"
    ,"Station_Code":"Q5 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"102C-D, đường An Dương Vương, Quận 5"
    ,"Lat":10.756967
    ,"Long":106.670653
    ,"Polyline":"[106.67353058,10.75753593] ; [106.67065430,10.75696659]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường Nguyễn Tri Ph ương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.67065430,10.75696659] ; [106.66966248,10.75674534] ; [106.66961670,10.75715065]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"431"
    ,"Station_Code":"Q5 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"116A, đường Hùng Vương, Quận 5"
    ,"Lat":10.757257
    ,"Long":106.668566
    ,"Polyline":"[106.66961670,10.75715065] ; [106.66950226,10.75739956] ; [106.66941071,10.75765038] ; [106.66856384,10.75725746]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bệnh vi ện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66856384,10.75725746] ; [106.66702271,10.75647640] ; [106.66451263,10.75589657]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Bệnh vi ện Hùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66451263,10.75589657] ; [106.66236877,10.75539017] ; [106.66107178,10.75519562]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Bệnh vi ện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107178,10.75519562] ; [106.66039276,10.75501156] ; [106.65950012,10.75487518]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"397"
    ,"Station_Code":"Q5 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Rạp Đại  Quang"
    ,"Station_Address":"81, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752445
    ,"Long":106.658792
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65823364,10.75456905] ; [106.65821075,10.75424194] ; [106.65859985,10.75310421] ; [106.65879059,10.75244522]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.65879059,10.75244522] ; [106.65889740,10.75138092]"
    ,"Distance":"120"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"138"
    ,"Station_Code":"Q5 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Hải Thượng Lãn Ông"
    ,"Station_Address":"210-212, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750948
    ,"Long":106.658358
    ,"Polyline":"[106.65889740,10.75138092] ; [106.65906525,10.75086403] ; [106.65835571,10.75094795]"
    ,"Distance":"139"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"139"
    ,"Station_Code":"Q5 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"5, đường Trang  Tử, Quận 5"
    ,"Lat":10.751128
    ,"Long":106.655086
    ,"Polyline":"[106.65835571,10.75094795] ; [106.65741730,10.75097466] ; [106.65646362,10.75107479] ; [106.65576935,10.75105953] ; [106.65508270,10.75112820]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65508270,10.75112820] ; [106.65508270,10.75112820] ; [106.65386963,10.75115395] ; [106.65341949,10.75160694] ; [106.65335083,10.75166035] ; [106.65324402,10.75166035] ; [106.65296936,10.75132275] ; [106.65256500,10.75125313]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27 , đường Tháp Mười, Quận 6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65203857,10.75116444] ; [106.65194702,10.75102234] ; [106.65099335,10.75097466] ; [106.65003967,10.75107002] ; [106.64955139,10.75079060] ; [106.64944458,10.74973106.06.65254211] ; [10.75026989,106.65255737]"
    ,"Distance":"816"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2393"
    ,"Station_Code":"Q6 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tháp Mười"
    ,"Station_Address":"13C-13D, đường Tháp Mười, Quận 6"
    ,"Lat":10.750326
    ,"Long":106.653036
    ,"Polyline":"[106.65255737,10.75023174] ; [106.65255737,10.75023174] ; [106.65280151,10.75029469] ; [106.65303802,10.75032616] ; [106.65303802,10.75032616]"
    ,"Distance":"54"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2"
    ,"Station_Code":"Q5 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"11-12, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750732
    ,"Long":106.655075
    ,"Polyline":"[106.65303040,10.75035954] ; [106.65453339,10.75069046] ; [106.65473175,10.75078964] ; [106.65503693,10.75078011]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"14-16, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65503693,10.75078964] ; [106.65592957,10.75074005] ; [106.65647888,10.75080013] ; [106.65741730,10.75070953] ; [106.65840912,10.75067997] ; [106.65899658,10.75065994] ; [106.65908051,10.75065994] ; [106.65914917,10.75061989] ; [106.65920258,10.75061989] ; [106.65926361,10.75065041] ; [106.65930939,10.75070953] ; [106.65930939,10.75078964] ; [106.65926361,10.75086975] ; [106.65921021,10.75088978] ; [106.65918732,10.75105000] ; [106.65914154,10.75135994]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"5"
    ,"Station_Code":"Q5 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"68, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752566
    ,"Long":106.658937
    ,"Polyline":"[106.65920258,10.75136757] ; [106.65914154,10.75135994] ; [106.65905762,10.75183964] ; [106.65903473,10.75201321] ; [106.65896606,10.75246048] ; [106.65892792,10.75256634]"
    ,"Distance":"144"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65892792,10.75256634] ; [106.65887451,10.75283527] ; [106.65841675,10.75444984] ; [106.65857697,10.75446892] ; [106.65921783,10.75457001] ; [106.65923309,10.75451756]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Đại học Y  Dược"
    ,"Station_Address":"217, đường Hồng B àng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.65923309,10.75455284] ; [106.66319275,10.75535965]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bệnh viện Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66319275,10.75535965] ; [106.66468048,10.75567055]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"465"
    ,"Station_Code":"Q5 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"121, đường An Dương Vương, Qu ận 5"
    ,"Lat":10.756714
    ,"Long":106.670492
    ,"Polyline":"[106.66470337,10.75564003] ; [106.66841125,10.75642014] ; [106.67047882,10.75685978]"
    ,"Distance":"666"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"469"
    ,"Station_Code":"Q5 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"59C, đường An Dương Vương, Quận 5"
    ,"Lat":10.757057
    ,"Long":106.672182
    ,"Polyline":"[106.67047882,10.75685978] ; [106.67209625,10.75716972]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"466"
    ,"Station_Code":"Q5 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"439, đường An Dương Vương, Quận 5"
    ,"Lat":10.758374
    ,"Long":106.676576
    ,"Polyline":"[106.67218018,10.75705719] ; [106.67407227,10.75745678] ; [106.67657471,10.75837421]"
    ,"Distance":"504"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"472"
    ,"Station_Code":"Q5 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"373, đường An Dương Vương, Quận 5"
    ,"Lat":10.759138
    ,"Long":106.678453
    ,"Polyline":"[106.67657471,10.75837421] ; [106.67845154,10.75913811]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"467"
    ,"Station_Code":"Q5 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại học  Sài Gòn"
    ,"Station_Address":"273-275, đường  An Dương Vương, Quận 5"
    ,"Lat":10.760735
    ,"Long":106.682289
    ,"Polyline":"[106.67845154,10.75913811] ; [106.68228912,10.76073456]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1051"
    ,"Station_Code":"Q5 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bộ Công an"
    ,"Station_Address":"211-213, đường Nguy ễn Văn Cừ, Quận 5"
    ,"Lat":10.760672
    ,"Long":106.683453
    ,"Polyline":"[106.68226624,10.76074982] ; [106.68334961,10.76117039] ; [106.68351746,10.76070023]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1052"
    ,"Station_Code":"Q1 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Báo An Ninh Thế Giới"
    ,"Station_Address":"371A, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.759869
    ,"Long":106.685104
    ,"Polyline":"[106.68351746,10.76070023] ; [106.68399048,10.75940037] ; [106.68469238,10.75969982] ; [106.68492889,10.75984001] ; [106.68501282,10.75990963] ; [106.68509674,10.75984955]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1053"
    ,"Station_Code":"Q1 151"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà Khách Bộ Công An"
    ,"Station_Address":"333, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.762006
    ,"Long":106.686394
    ,"Polyline":"[106.68509674,10.75984955] ; [106.68501282,10.75990963] ; [106.68515015,10.76006031] ; [106.68537903,10.76039982] ; [106.68586731,10.76130009] ; [106.68628693,10.76206017]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2974"
    ,"Station_Code":"Q1 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"173 - 173B,  đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.76303
    ,"Long":106.688217
    ,"Polyline":"[106.68628693,10.76206017] ; [106.68652344,10.76249027] ; [106.68679810,10.76259041] ; [106.68753052,10.76288986] ; [106.68817902,10.76313972]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2971"
    ,"Station_Code":"Q1 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trần Hưng Đạo"
    ,"Station_Address":"37, đường Nguyễn Cư Trinh, Quận 1"
    ,"Lat":10.764468
    ,"Long":106.69178
    ,"Polyline":"[106.68817902,10.76311970] ; [106.68875885,10.76334953] ; [106.69023132,10.76395988] ; [106.69072723,10.76422024] ; [106.69106293,10.76430988] ; [106.69174194,10.76455975]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"25"
    ,"Station_Code":"Q1 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Rạp Trần Hưng Đạo"
    ,"Station_Address":"227 - 229, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765213
    ,"Long":106.693069
    ,"Polyline":"[106.69174194,10.76455975] ; [106.69265747,10.76488972] ; [106.69300079,10.76527023]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"26"
    ,"Station_Code":"Q1 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"135, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767064
    ,"Long":106.694824
    ,"Polyline":"[106.69300079,10.76527023] ; [106.69467163,10.76718998]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"27"
    ,"Station_Code":"Q1 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"71C, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768327
    ,"Long":106.695847
    ,"Polyline":"[106.69467163,10.76718998] ; [106.69525909,10.76788044] ; [106.69538879,10.76801014] ; [106.69573975,10.76842022]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường  Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69573975,10.76842022] ; [106.69744873,10.77035046] ; [106.69753265,10.77021980] ; [106.69841766,10.77056980]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69845581,10.77047157] ; [106.69841766,10.77056980] ; [106.69907379,10.77081966] ; [106.69922638,10.77089024] ; [106.69956207,10.77093029] ; [106.69956207,10.77094269]"
    ,"Distance":"146"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956970,10.77095985] ; [106.70192719,10.77085972]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi , Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70192719,10.77085972] ; [106.70407104,10.77072239]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"B ến thủy nội địa Thủ Thiêm, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70407104,10.77072239] ; [106.70415497,10.77060318] ; [106.70417786,10.77072144] ; [106.70450592,10.77070618] ; [106.70455933,10.77058983] ; [106.70513153,10.76945972] ; [106.70516205,10.76939011] ; [106.70529175,10.76941967] ; [106.70593262,10.76953983] ; [106.70606995,10.76959991] ; [106.70616150,10.76972961] ; [106.70639038,10.77054977] ; [106.70635986,10.77071953] ; [106.70633698,10.77099037] ; [106.70639038,10.77120972] ; [106.70636749,10.77126026] ; [106.70639038,10.77161789] ; [106.70652008,10.77293015] ; [106.70661163,10.77388668] ; [106.70664978,10.77387810]"
    ,"Distance":"822"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1092"
    ,"Station_Code":"Q1 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Bảo tàng Tôn Đức Thắng"
    ,"Station_Address":"Đối diện số 5, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.777367
    ,"Long":106.707115
    ,"Polyline":"[106.70652008,10.77388954] ; [106.70658112,10.77460003] ; [106.70667267,10.77488041] ; [106.70671844,10.77563953] ; [106.70674896,10.77591038] ; [106.70671844,10.77598000] ; [106.70687866,10.77655983] ; [106.70702362,10.77717018]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1093"
    ,"Station_Code":"Q1 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngô Văn Năm"
    ,"Station_Address":"Đối diện số 3C, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.779949
    ,"Long":106.707818
    ,"Polyline":"[106.70711517,10.77736664] ; [106.70781708,10.77994919]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1094"
    ,"Station_Code":"Q1 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ba Son"
    ,"Station_Address":"2, đường Tôn Đức  Thắng, Quận 1"
    ,"Lat":10.781804
    ,"Long":106.706922
    ,"Polyline":"[106.70771790,10.77991962] ; [106.70787811,10.78044987] ; [106.70790863,10.78067017] ; [106.70783997,10.78085995] ; [106.70681000,10.78180981]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2572"
    ,"Station_Code":"Q1 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Nguyễn Hữu Cảnh"
    ,"Station_Address":"Cây xanh số 17, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.78328
    ,"Long":106.707222
    ,"Polyline":"[106.70681000,10.78180981] ; [106.70622253,10.78238010.06.70646667] ; [10.78262043,106.70690155]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2573"
    ,"Station_Code":"Q1 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"2A, đường Nguy ễn Hữu Cảnh, Quận 1"
    ,"Lat":10.785077
    ,"Long":106.708628
    ,"Polyline":"[106.70722198,10.78328037] ; [106.70783997,10.78421974] ; [106.70816040,10.78458977] ; [106.70848083,10.78501034] ; [106.70851135,10.78505993] ; [106.70862579,10.78507710]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2579"
    ,"Station_Code":"QBTH 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Hồ Bơi Hải Quân"
    ,"Station_Address":"18, đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.789113
    ,"Long":106.710779
    ,"Polyline":"[106.70851135,10.78505993] ; [106.70870972,10.78546047] ; [106.70983124,10.78827953] ; [106.71009064,10.78870964] ; [106.71025085,10.78890038] ; [106.71041870,10.78903961] ; [106.71066284,10.78921032] ; [106.71082306,10.78929996]"
    ,"Distance":"581"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2574"
    ,"Station_Code":"QBTH 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chung cư Manor"
    ,"Station_Address":"176E, đường Nguyễn Hữu Cảnh, Quận Bình  Thạnh"
    ,"Lat":10.793266
    ,"Long":106.718445
    ,"Polyline":"[106.71074677,10.78925991] ; [106.71108246,10.78940010.06.71128845] ; [10.78946018,106.71164703] ; [10.78950977,106.71182251] ; [10.78950977,106.71240234] ; [10.78944969,106.71350861] ; [10.78929043,106.71402740] ; [10.78917980,106.71463013] ; [10.78899956,106.71515656] ; [10.78894043,106.71562195] ; [10.78897953,106.71598053] ; [10.78905010.06.71627808,10.78917980] ; [106.71652222,10.78925037] ; [106.71656036,10.78925037] ; [106.71662903,10.78927994] ; [106.71666718,10.78932953] ; [106.71666718,10.78938007] ; [106.71732330,10.78969955] ; [106.71753693,10.78983974] ; [106.71772766,10.78999996] ; [106.71784973,10.79012966] ; [106.71798706,10.79032040] ; [106.71813965,10.79057026] ; [106.71820831,10.79073048] ; [106.71829987,10.79106998] ; [106.71830750,10.79144001] ; [106.71826935,10.79168987] ; [106.71826935,10.79327011]"
    ,"Distance":"1226"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"2581"
    ,"Station_Code":"QBTH 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Tân Cảng"
    ,"Station_Address":"220 , đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.796601
    ,"Long":106.719909
    ,"Polyline":"[106.71826935,10.79327011] ; [106.71827698,10.79432011] ; [106.71830750,10.79496956] ; [106.71839905,10.79529953] ; [106.71851349,10.79555035] ; [106.71874237,10.79586029] ; [106.71913147,10.79621029] ; [106.71980286,10.79671955]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"477"
    ,"Station_Code":"Q2 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"794, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.799978
    ,"Long":106.7342
    ,"Polyline":"[106.71980286,10.79671955] ; [106.72029877,10.79710007] ; [106.72084808,10.79745007] ; [106.72093964,10.79755974] ; [106.72110748,10.79771042] ; [106.72122955,10.79782009] ; [106.72141266,10.79780960] ; [106.72203064,10.79780006] ; [106.72306824,10.79790020] ; [106.72850037,10.79891968] ; [106.73149872,10.79944992] ; [106.73317719,10.79986954] ; [106.73417664,10.80008984]"
    ,"Distance":"1670"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"478"
    ,"Station_Code":"Q2 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Đối diện ngã 3 Thảo Điền, đường Xa Lộ Hà N ội, Quận 2"
    ,"Lat":10.800838
    ,"Long":106.738899
    ,"Polyline":"[106.73419952,10.79997826] ; [106.73553467,10.80037403] ; [106.73753357,10.80075359] ; [106.73889923,10.80083847]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"480"
    ,"Station_Code":"Q2 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"170, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801584
    ,"Long":106.742928
    ,"Polyline":"[106.73889923,10.80083847] ; [106.74015808,10.80118561] ; [106.74160767,10.80151272] ; [106.74292755,10.80158424]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"479"
    ,"Station_Code":"Q2 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Khu  dân cư Estella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802592
    ,"Long":106.748089
    ,"Polyline":"[106.74292755,10.80158424] ; [106.74306488,10.80175972] ; [106.74376678,10.80189037] ; [106.74430084,10.80200958] ; [106.74456787,10.80204010.06.74524689] ; [10.80206966,106.74575806] ; [10.80202961,106.74610901] ; [10.80202007,106.74642181] ; [10.80206966,106.74662781] ; [10.80214024,106.74687958] ; [10.80226040,106.74725342] ; [10.80241966,106.74761963] ; [10.80255032,106.74806213] ; [10.80268955,106.74809265]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"482"
    ,"Station_Code":"Q9 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Xi măng  hà tiên - trạm thu phí"
    ,"Station_Address":"249B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.819206
    ,"Long":106.758394
    ,"Polyline":"[106.74806213,10.80266953] ; [106.74839020,10.80274010.06.74859619] ; [10.80278015,106.74897003] ; [10.80292034,106.74938202] ; [10.80301952,106.74983215] ; [10.80315971,106.75074005] ; [10.80352020,106.75142670] ; [10.80387974,106.75209045] ; [10.80432034,106.75256348] ; [10.80461979,106.75302124] ; [10.80500984,106.75366974] ; [10.80558968,106.75424194] ; [10.80618000,106.75460052] ; [10.80661964,106.75485229] ; [10.80694962,106.75514221] ; [10.80733013,106.75559235] ; [10.80803967,106.75594330] ; [10.80877018,106.75621796] ; [10.80947018,106.75650787] ; [10.81050968,106.75662994] ; [10.81101990,106.75669098] ; [10.81138992,106.75765228] ; [10.81647015,106.75775909] ; [10.81698036,106.75784302] ; [10.81725025,106.75814056] ; [10.81892967,106.75833130] ; [10.81906033,106.75836945]"
    ,"Distance":"2350"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"481"
    ,"Station_Code":"Q9 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"185A, đường Xa Lộ Hà Nội, Qu ận 9"
    ,"Lat":10.825972
    ,"Long":106.760775
    ,"Polyline":"[106.75836945,10.81912041] ; [106.75858307,10.82100868] ; [106.75972748,10.82420158] ; [106.76068115,10.82600975]"
    ,"Distance":"836"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"485"
    ,"Station_Code":"Q9 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm xây dựng"
    ,"Station_Address":"354A , đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.829955
    ,"Long":106.76312
    ,"Polyline":"[106.76077271,10.82597160] ; [106.76112366,10.82678032] ; [106.76235962,10.82892036] ; [106.76312256,10.82995510]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"483"
    ,"Station_Code":"Q9 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Khu QLGTDT số 2"
    ,"Station_Address":"Khu QLGTĐT s ố 2, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.833249
    ,"Long":106.764778
    ,"Polyline":"[106.76312256,10.82995510.06.76312256] ; [10.82995510.06.76359558,10.83101940] ; [106.76416016,10.83214664] ; [106.76477814,10.83325005] ; [106.76477814,10.83324909] ; [106.76477814,10.83324909]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"486"
    ,"Station_Code":"QTD 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Công ty Sanofi  Aventis"
    ,"Station_Address":"Kế 50, đường Đặng  Văn Bi, Quận Thủ Đức"
    ,"Lat":10.841652
    ,"Long":106.764175
    ,"Polyline":"[106.76477814,10.83324909] ; [106.76914978,10.84081173] ; [106.77155304,10.84512901] ; [106.77419281,10.84900665] ; [106.77335358,10.84951210.06.77213287] ; [10.84963894,106.76635742] ; [10.83944893,106.76601410] ; [10.84029198,106.76576996] ; [10.84064007,106.76417542]"
    ,"Distance":"3931"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"489"
    ,"Station_Code":"QTD 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Công ty may Sài Gòn"
    ,"Station_Address":"Đối diện 139, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.843897
    ,"Long":106.762466
    ,"Polyline":"[106.76417542,10.84165192] ; [106.76382446,10.84188366] ; [106.76351929,10.84215736] ; [106.76312256,10.84275818] ; [106.76246643,10.84389687]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"491"
    ,"Station_Code":"QTD 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trường mầm non Vành Khuyên"
    ,"Station_Address":"Trường mầm non Họa Mi, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.847888
    ,"Long":106.760056
    ,"Polyline":"[106.76246643,10.84389687] ; [106.76206970,10.84443378] ; [106.76169586,10.84499168] ; [106.76157379,10.84523392] ; [106.76153564,10.84557152] ; [106.76141357,10.84591961] ; [106.76123047,10.84638309] ; [106.76091003,10.84685707] ; [106.76005554,10.84788799]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"488"
    ,"Station_Code":"QTD 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Làng trẻ em SOS"
    ,"Station_Address":"238-240, đường  Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.850015
    ,"Long":106.758781
    ,"Polyline":"[106.76005554,10.84788799] ; [106.75920105,10.84873295] ; [106.75887299,10.84923840] ; [106.75877380,10.84962845] ; [106.75878143,10.85001469]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"493"
    ,"Station_Code":"QTD 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"100, đường V õ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850503
    ,"Long":106.759998
    ,"Polyline":"[106.75878143,10.85001469] ; [106.75865173,10.85063457] ; [106.75999451,10.85050297]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"490"
    ,"Station_Code":"QTD 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Cao đẳng xây dựng 2"
    ,"Station_Address":"190, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.85065
    ,"Long":106.764439
    ,"Polyline":"[106.75999451,10.85050297] ; [106.76196289,10.85041904] ; [106.76279449,10.85080814] ; [106.76444244,10.85064983]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"492"
    ,"Station_Code":"QTD 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Siêu th ị Nguyễn Kim"
    ,"Station_Address":"274-276, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849686
    ,"Long":106.769112
    ,"Polyline":"[106.76444244,10.85064983] ; [106.76705170,10.85042381] ; [106.76720428,10.85037136] ; [106.76731873,10.85028648] ; [106.76765442,10.84988117] ; [106.76774597,10.84980774] ; [106.76821899,10.84971809] ; [106.76911163,10.84968567]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"497"
    ,"Station_Code":"QTD 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Trường ĐHSP Kỹ Thuật"
    ,"Station_Address":"368, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849597
    ,"Long":106.771917
    ,"Polyline":"[106.76911163,10.84968567] ; [106.76909637,10.84974003] ; [106.77034760,10.84969711] ; [106.77155304,10.84966564] ; [106.77178955,10.84963322] ; [106.77191925,10.84959698]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1502"
    ,"Station_Code":"Q9 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Siêu thị Coopmark"
    ,"Station_Address":"4-6 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.848192
    ,"Long":106.775032
    ,"Polyline":"[106.77191925,10.84959698] ; [106.77297974,10.84951782] ; [106.77327728,10.84950161] ; [106.77342987,10.84943867] ; [106.77423096,10.84878540] ; [106.77503204,10.84819221]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1504"
    ,"Station_Code":"Q9 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Bệnh viện 7C-Trường Quân y 2"
    ,"Station_Address":"50, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846262
    ,"Long":106.778124
    ,"Polyline":"[106.77503204,10.84819221] ; [106.77578735,10.84763718] ; [106.77704620,10.84693050] ; [106.77812195,10.84626198]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1495"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Nhà sách Thành Nghĩa"
    ,"Station_Address":"142-144, đường Lê Văn Việt , Quận 9"
    ,"Lat":10.84486
    ,"Long":106.780563
    ,"Polyline":"[106.77812195,10.84626198] ; [106.77872467,10.84596634] ; [106.77935028,10.84560299] ; [106.78007507,10.84519768] ; [106.78056335,10.84486008]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1497"
    ,"Station_Code":"Q9 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Cổng Đình Phong Phú"
    ,"Station_Address":"188 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844114
    ,"Long":106.782028
    ,"Polyline":"[106.78056335,10.84486008] ; [106.78083801,10.84472847] ; [106.78125000,10.84444427] ; [106.78202820,10.84411430]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1499"
    ,"Station_Code":"Q9 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Chợ nhỏ"
    ,"Station_Address":"278 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844128
    ,"Long":106.784261
    ,"Polyline":"[106.78202820,10.84411430] ; [106.78250122,10.84399605] ; [106.78273773,10.84397507] ; [106.78426361,10.84412766]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1506"
    ,"Station_Code":"Q9 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Chợ Tăng Nhơn Phú- Trường Trần  Quốc Toản"
    ,"Station_Address":"424A-424B, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844439
    ,"Long":106.788939
    ,"Polyline":"[106.78426361,10.84412766] ; [106.78539276,10.84439659] ; [106.78614044,10.84486008] ; [106.78636932,10.84500217] ; [106.78668213,10.84509754] ; [106.78742218,10.84511852] ; [106.78823853,10.84476566] ; [106.78865814,10.84458065] ; [106.78894043,10.84443855]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1501"
    ,"Station_Code":"Q9 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Bệnh viện Quận 9"
    ,"Station_Address":"Đối diện Bệnh viện Quận 9, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.8446
    ,"Long":106.790977
    ,"Polyline":"[106.78894043,10.84443855] ; [106.78928375,10.84434891] ; [106.78955078,10.84431744] ; [106.79040527,10.84450722] ; [106.79097748,10.84459972]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"1508"
    ,"Station_Code":"Q9 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Đại Học GTVT"
    ,"Station_Address":"Đối diện 451, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845276
    ,"Long":106.793922
    ,"Polyline":"[106.79097748,10.84459972] ; [106.79285431,10.84507656] ; [106.79392242,10.84527588]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"76"
    ,"Station_Id":"3186"
    ,"Station_Code":"BX31"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"KTX Đại học Sư phạm kỹ thuật"
    ,"Station_Address":"KTX Đại học Sư phạm kỹ thuật, đường Lê Văn Việt, Qu ận 9"
    ,"Lat":10.845909
    ,"Long":106.797581
    ,"Polyline":"[106.79392242,10.84527588] ; [106.79738617,10.84616661] ; [106.79758453,10.84590912]"
    ,"Distance":"428"
  }]