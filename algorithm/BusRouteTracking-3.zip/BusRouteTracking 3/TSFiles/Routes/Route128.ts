export const Route128 =[

  {
     "Route_Id":"128"
    ,"Station_Id":"4019"
    ,"Station_Code":"BX27"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Chợ Long Phước"
    ,"Station_Address":"ĐẦU BẾN CHỢ LONG PHƯỚC, đường Long  Phước, Quận 9"
    ,"Lat":10.808298
    ,"Long":106.85936
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3695"
    ,"Station_Code":"Q9 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Long Phước"
    ,"Station_Address":"Chợ Long Ph ước, đường Long Phước, Quận 9"
    ,"Lat":10.808594
    ,"Long":106.859583
    ,"Polyline":"[106.85935974,10.80829811] ; [106.85959625,10.80836773] ; [106.85958099,10.80859375]"
    ,"Distance":"52"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3694"
    ,"Station_Code":"Q9 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Nhà bia tưởng niệm"
    ,"Station_Address":"Nhà bia tưởng niệm, đường Long Phước,  Quận 9"
    ,"Lat":10.81038
    ,"Long":106.859411
    ,"Polyline":"[106.85958099,10.80859375] ; [106.85920715,10.80937958] ; [106.85916138,10.80957031] ; [106.85916138,10.80976963] ; [106.85932159,10.81040001] ; [106.85941315,10.81037998]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3696"
    ,"Station_Code":"Q9 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã 3 Long Phước"
    ,"Station_Address":"281 , đường Long Thuận, Quận 9"
    ,"Lat":10.812077
    ,"Long":106.859041
    ,"Polyline":"[106.85941315,10.81037998] ; [106.85935211,10.81038570] ; [106.85992432,10.81209278] ; [106.85903931,10.81207657]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3698"
    ,"Station_Code":"Q9 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trại nhím"
    ,"Station_Address":"Đối diện 216, đường Long Thuận, Quận 9"
    ,"Lat":10.811729
    ,"Long":106.853371
    ,"Polyline":"[106.85903931,10.81207657] ; [106.85789490,10.81199837] ; [106.85478973,10.81175613] ; [106.85337067,10.81172943]"
    ,"Distance":"621"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3697"
    ,"Station_Code":"Q9 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"phim tr ường"
    ,"Station_Address":"Đối diện 168, đường Long Thuận, Quận 9"
    ,"Lat":10.81146
    ,"Long":106.846359
    ,"Polyline":"[106.85337067,10.81172943] ; [106.84737396,10.81129169] ; [106.84642029,10.81139755] ; [106.84635925,10.81145954]"
    ,"Distance":"772"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3700"
    ,"Station_Code":"Q9 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu Trường Phước"
    ,"Station_Address":"Đối diện 116/A, đường Long Thuận, Quận 9"
    ,"Lat":10.812019
    ,"Long":106.842964
    ,"Polyline":"[106.84635925,10.81145954] ; [106.84574127,10.81147099] ; [106.84340668,10.81190300] ; [106.84296417,10.81201935]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3699"
    ,"Station_Code":"Q9 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Long Thuận"
    ,"Station_Address":"51, đường Long Thuận, Quận 9"
    ,"Lat":10.814543
    ,"Long":106.834939
    ,"Polyline":"[106.84296417,10.81201935] ; [106.84288025,10.81200981] ; [106.84224701,10.81215000] ; [106.84097290,10.81285000] ; [106.83957672,10.81371021] ; [106.83924103,10.81396008] ; [106.83851624,10.81470013] ; [106.83837128,10.81478977] ; [106.83818817,10.81484985] ; [106.83801270,10.81486988] ; [106.83782959,10.81488037] ; [106.83493805,10.81454277]"
    ,"Distance":"978"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4047"
    ,"Station_Code":"Q9 164"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cầu Võ Khế"
    ,"Station_Address":"1757-1759 , đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.810649
    ,"Long":106.83172
    ,"Polyline":"[106.83466339,10.81443024] ; [106.83412933,10.81435966] ; [106.83403015,10.81396008] ; [106.83387756,10.81355953] ; [106.83303070,10.81159019] ; [106.83286285,10.81122017] ; [106.83268738,10.81107044] ; [106.83226776,10.81081009] ; [106.83174896,10.81054974]"
    ,"Distance":"623"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4043"
    ,"Station_Code":"Q9 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm y tế"
    ,"Station_Address":"Trạm y tế, đường Nguyễn  Duy Trinh, Quận 9"
    ,"Lat":10.809522
    ,"Long":106.829612
    ,"Polyline":"[106.83174896,10.81054974] ; [106.82965088,10.80945015]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4015"
    ,"Station_Code":"Q9 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã 3 Tam Đa"
    ,"Station_Address":"1565, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.807756
    ,"Long":106.826511
    ,"Polyline":"[106.82961273,10.80952168] ; [106.82760620,10.80839920] ; [106.82691193,10.80797768] ; [106.82650757,10.80775642]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"1518"
    ,"Station_Code":"Q9 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Chợ Long  Trường"
    ,"Station_Address":"Đối diện Chợ Long Trường, đường Nguyễn Duy  Trinh, Quận 9"
    ,"Lat":10.806213
    ,"Long":106.821077
    ,"Polyline":"[106.82630157,10.80753040] ; [106.82566833,10.80712032] ; [106.82505035,10.80694962] ; [106.82183838,10.80618000] ; [106.82157135,10.80617046]"
    ,"Distance":"632"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4046"
    ,"Station_Code":"Q9 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"UBND phường Long Trường"
    ,"Station_Address":"UBND phường  Long Trường, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.805327
    ,"Long":106.816721
    ,"Polyline":"[106.82107544,10.80621338] ; [106.81738281,10.80563259] ; [106.81671906,10.80532742]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4044"
    ,"Station_Code":"Q9 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đường S ố 6"
    ,"Station_Address":"1249-1251, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.803857
    ,"Long":106.814532
    ,"Polyline":"[106.81671906,10.80532742] ; [106.81673431,10.80527973] ; [106.81457520,10.80379391] ; [106.81452942,10.80385685]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4048"
    ,"Station_Code":"Q9 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường Long Trường"
    ,"Station_Address":"1153 , đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.801997
    ,"Long":106.811973
    ,"Polyline":"[106.81452942,10.80385685] ; [106.81457520,10.80378342] ; [106.81279755,10.80254459] ; [106.81202698,10.80193424] ; [106.81197357,10.80199718]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4049"
    ,"Station_Code":"Q9 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Đường S ố 1"
    ,"Station_Address":"1091, đường Nguyễn Duy  Trinh, Quận 9"
    ,"Lat":10.799568
    ,"Long":106.809082
    ,"Polyline":"[106.81197357,10.80199718] ; [106.80908203,10.79956818]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4051"
    ,"Station_Code":"Q9 159"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cao Tốc Dầu Giây"
    ,"Station_Address":"999, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.794067
    ,"Long":106.807167
    ,"Polyline":"[106.80908203,10.79956818] ; [106.80869293,10.79911995] ; [106.80787659,10.79684353] ; [106.80716705,10.79406738]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4050"
    ,"Station_Code":"Q9 158"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Huyện Thanh"
    ,"Station_Address":"Kế 981C, đường  Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.792222
    ,"Long":106.804233
    ,"Polyline":"[106.80724335,10.79405022] ; [106.80696106,10.79286003] ; [106.80690002,10.79277992] ; [106.80673981,10.79269028] ; [106.80600739,10.79251003] ; [106.80426788,10.79214001]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4054"
    ,"Station_Code":"Q9 157"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà Thờ Phú Hữu"
    ,"Station_Address":"933-935, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.791521
    ,"Long":106.800311
    ,"Polyline":"[106.80426788,10.79214001] ; [106.80151367,10.79154015] ; [106.80113983,10.79148960] ; [106.80033112,10.79143047] ; [106.80030823,10.79143047]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4052"
    ,"Station_Code":"Q9 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"UBND P.Phú Hữu"
    ,"Station_Address":"877, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.791405
    ,"Long":106.79786
    ,"Polyline":"[106.80030823,10.79143047] ; [106.79785919,10.79129982]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4053"
    ,"Station_Code":"Q9 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Trường Hoa Hồng Đỏ"
    ,"Station_Address":"835, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.791205
    ,"Long":106.794625
    ,"Polyline":"[106.79785919,10.79129982] ; [106.79694366,10.79125977] ; [106.79496002,10.79109955] ; [106.79463196,10.79109001]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4055"
    ,"Station_Code":"Q9 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"vành đai trong"
    ,"Station_Address":"817, đường Nguyễn Duy Trinh , Quận 9"
    ,"Lat":10.790968
    ,"Long":106.790682
    ,"Polyline":"[106.79463196,10.79113674] ; [106.79427338,10.79114151] ; [106.79297638,10.79106808] ; [106.79290771,10.79117870] ; [106.79286194,10.79123688] ; [106.79282379,10.79129505] ; [106.79277802,10.79136372] ; [106.79264832,10.79139996] ; [106.79253387,10.79140568] ; [106.79243469,10.79137897] ; [106.79235840,10.79132652] ; [106.79230499,10.79126358] ; [106.79222870,10.79110527] ; [106.79220581,10.79099464] ; [106.79177856,10.79098034] ; [106.79175568,10.79099751]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4056"
    ,"Station_Code":"Q9 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu xây dựng"
    ,"Station_Address":"787, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.790826
    ,"Long":106.788027
    ,"Polyline":"[106.79067993,10.79096794] ; [106.78802490,10.79082584]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4059"
    ,"Station_Code":"Q9 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Công ty Thành Công"
    ,"Station_Address":"761, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.790662
    ,"Long":106.784459
    ,"Polyline":"[106.78781128,10.79073048] ; [106.78449249,10.79055977]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4057"
    ,"Station_Code":"Q9 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã 3 Đỗ Xuân Hợp"
    ,"Station_Address":"741D-741H, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.790562
    ,"Long":106.782281
    ,"Polyline":"[106.78446198,10.79066181] ; [106.78227997,10.79056168]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4062"
    ,"Station_Code":"Q2 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đỗ Xuân Hợp"
    ,"Station_Address":"953-955, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.789751
    ,"Long":106.779674
    ,"Polyline":"[106.78227997,10.79056168] ; [106.78119659,10.79045677] ; [106.77967072,10.78975105]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4058"
    ,"Station_Code":"Q2 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường Nguyễn Văn Trỗi"
    ,"Station_Address":"Đối diện 618, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.788671
    ,"Long":106.777557
    ,"Polyline":"[106.77967072,10.78975105] ; [106.77755737,10.78867054]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4064"
    ,"Station_Code":"Q2 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường s ố 6"
    ,"Station_Address":"Đối diện 560, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.78818
    ,"Long":106.775613
    ,"Polyline":"[106.77755737,10.78867054] ; [106.77651215,10.78811169] ; [106.77614594,10.78806973] ; [106.77561188,10.78818035]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4066"
    ,"Station_Code":"Q2 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nhà Sách Nguyễn Văn Cừ"
    ,"Station_Address":"587-589, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.788402
    ,"Long":106.773167
    ,"Polyline":"[106.77561188,10.78818035] ; [106.77317047,10.78840160]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4068"
    ,"Station_Code":"Q2 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Lê Văn Thịnh"
    ,"Station_Address":"531, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.788639
    ,"Long":106.770764
    ,"Polyline":"[106.77317047,10.78840160] ; [106.77076721,10.78863907]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4060"
    ,"Station_Code":"Q2 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Công ty Bình An"
    ,"Station_Address":"305, đường Nguy ễn Duy Trinh, Quận 2"
    ,"Lat":10.787859
    ,"Long":106.765501
    ,"Polyline":"[106.77076721,10.78863907] ; [106.77010345,10.78864384] ; [106.76955414,10.78865433] ; [106.76795959,10.78833866] ; [106.76609039,10.78806496] ; [106.76550293,10.78785896]"
    ,"Distance":"585"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4061"
    ,"Station_Code":"Q2 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Nhà thiếu nhi Quận 2"
    ,"Station_Address":"201, đường Nguy ễn Duy Trinh, Quận 2"
    ,"Lat":10.787904
    ,"Long":106.761909
    ,"Polyline":"[106.76550293,10.78785896] ; [106.76510620,10.78762150] ; [106.76190948,10.78790379]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4063"
    ,"Station_Code":"Q2 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Giồng Ông Tố"
    ,"Station_Address":"111, đường Nguy ễn Duy Trinh, Quận 2"
    ,"Lat":10.788291
    ,"Long":106.75849
    ,"Polyline":"[106.76190948,10.78790379] ; [106.75878906,10.78813839] ; [106.75849152,10.78829098]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2476"
    ,"Station_Code":"Q2 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Áo Cưới Thanh Điền"
    ,"Station_Address":"12, đường Nguyễn Thị Định, Quận 2"
    ,"Lat":10.790673
    ,"Long":106.75415
    ,"Polyline":"[106.75849152,10.78829098] ; [106.75770569,10.78851795] ; [106.75716400,10.78863335] ; [106.75609589,10.78873920] ; [106.75512695,10.78868675] ; [106.75415039,10.79067326]"
    ,"Distance":"619"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2977"
    ,"Station_Code":"Q2 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Phòng Đào tạo Quận 2"
    ,"Station_Address":"365A, đường Lương Định Của, Quận 2"
    ,"Lat":10.791985
    ,"Long":106.749424
    ,"Polyline":"[106.75415039,10.79067326] ; [106.75356293,10.79152107] ; [106.75295258,10.79219055] ; [106.75288391,10.79235935] ; [106.75294495,10.79248524] ; [106.75340271,10.79264927] ; [106.75596619,10.79354477] ; [106.75604248,10.79368210.06.75600433] ; [10.79383469,106.75586700] ; [10.79391861,106.75569153] ; [10.79394531,106.75391388] ; [10.79329681,106.75307465] ; [10.79307556,106.75222778] ; [10.79254341,106.74942780]"
    ,"Distance":"1398"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2980"
    ,"Station_Code":"Q2 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"Đối diện siêu thị điện máy Chợ Lớn, đường Lương Định Của, Quận 2"
    ,"Lat":10.791052
    ,"Long":106.745251
    ,"Polyline":"[106.74942780,10.79198456] ; [106.74525452,10.79105186]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4065"
    ,"Station_Code":"Q2 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà hàng Ca Dao"
    ,"Station_Address":"333, đường Lương Định Của, Quận 2"
    ,"Lat":10.790178
    ,"Long":106.741211
    ,"Polyline":"[106.74525452,10.79105186] ; [106.74121094,10.79017830]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4070"
    ,"Station_Code":"Q2 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa Huệ Nghiêm"
    ,"Station_Address":"Kế 22/4B, đường Lương Định Của, Quận 2"
    ,"Lat":10.789572
    ,"Long":106.738459
    ,"Polyline":"[106.74121094,10.79017830] ; [106.74050140,10.78996658] ; [106.73845673,10.78957176]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2981"
    ,"Station_Code":"Q2 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"Cột điện UD21 , đường Lương Định Của, Quận 2"
    ,"Lat":10.788312
    ,"Long":106.735268
    ,"Polyline":"[106.73827362,10.78948021] ; [106.73732758,10.78925037] ; [106.73693085,10.78909969] ; [106.73651886,10.78888035] ; [106.73538208,10.78827953]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2984"
    ,"Station_Code":"Q2 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Đình Bình  Khánh"
    ,"Station_Address":"16/2, đường Lương  Định Của, Quận 2"
    ,"Lat":10.78709
    ,"Long":106.73295
    ,"Polyline":"[106.73526764,10.78831196] ; [106.73294830,10.78709030]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2983"
    ,"Station_Code":"Q2 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trần Não"
    ,"Station_Address":"F2, đường Lương Định Của, Quận 2"
    ,"Lat":10.785555
    ,"Long":106.730072
    ,"Polyline":"[106.73294830,10.78709030] ; [106.73244476,10.78674221] ; [106.73159027,10.78628826] ; [106.73065186,10.78580379] ; [106.73007202,10.78555489]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2702"
    ,"Station_Code":"QBTH 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Hồ Bơi Hải Quân"
    ,"Station_Address":"22, đường Nguyễn  Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.789477
    ,"Long":106.710522
    ,"Polyline":"[106.73007202,10.78555489] ; [106.72116852,10.78078175] ; [106.71677399,10.78919220] ; [106.71648407,10.78937149] ; [106.71627808,10.78940296] ; [106.71608734,10.78937626] ; [106.71566772,10.78925514] ; [106.71520233,10.78919220] ; [106.71456909,10.78927135] ; [106.71382141,10.78943443] ; [106.71205902,10.78973007] ; [106.71134186,10.78973007] ; [106.71052551,10.78947735]"
    ,"Distance":"2863"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2703"
    ,"Station_Code":"Q1 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"1, đường Nguy ễn Hữu Cảnh, Quận 1"
    ,"Lat":10.784149
    ,"Long":106.707555
    ,"Polyline":"[106.71064758,10.78936958] ; [106.71035767,10.78917027] ; [106.71006012,10.78888988] ; [106.70986938,10.78862953] ; [106.70970154,10.78831959] ; [106.70908356,10.78676033] ; [106.70854187,10.78544044] ; [106.70836639,10.78511047] ; [106.70816803,10.78481007] ; [106.70790863,10.78450966] ; [106.70757294,10.78411007]"
    ,"Distance":"709"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"1192"
    ,"Station_Code":"Q1 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngô Văn Năm"
    ,"Station_Address":"3C, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.779807
    ,"Long":106.707609
    ,"Polyline":"[106.70755768,10.78414917] ; [106.70757294,10.78411007] ; [106.70607758,10.78238010.06.70619965] ; [10.78227043,106.70699310] ; [10.78147030,106.70745087] ; [10.78104973,106.70790863] ; [10.78063011,106.70786285] ; [10.78038979,106.70761108]"
    ,"Distance":"635"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70762634,10.77964020] ; [106.70726013,10.77820969] ; [106.70699310,10.77702999] ; [106.70681000,10.77632046] ; [106.70671844,10.77598000] ; [106.70652771,10.77583027] ; [106.70642853,10.77583027] ; [106.70635223,10.77583027] ; [106.70619965,10.77577972] ; [106.70610046,10.77571011] ; [106.70600128,10.77560997] ; [106.70594025,10.77550030] ; [106.70590210,10.77538967] ; [106.70588684,10.77521038] ; [106.70594025,10.77505016] ; [106.70606232,10.77488995] ; [106.70619202,10.77478981] ; [106.70629883,10.77474976] ; [106.70644379,10.77474976] ; [106.70648956,10.77476025] ; [106.70658112,10.77460003] ; [106.70646667,10.77322006]"
    ,"Distance":"859"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Cục Hải  Quan Thành Phố"
    ,"Station_Address":"2-4, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70635986,10.77329922] ; [106.70639801,10.77322292] ; [106.70622253,10.77144909] ; [106.70620728,10.77126408] ; [106.70621490,10.77121735] ; [106.70620728,10.77097988] ; [106.70614624,10.77083969] ; [106.70607758,10.77079964] ; [106.70598602,10.77084827] ; [106.70564270,10.77093887] ; [106.70555115,10.77088547]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84, đường Hàm Nghi, Quận  1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70555115,10.77088547] ; [106.70302582,10.77097988]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70302582,10.77097988] ; [106.70166016,10.77104759]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70166016,10.77104759] ; [106.69935608,10.77116299]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bến Tha ̀nh A"
    ,"Station_Address":"Bến Thành, đường Ph ạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69853973,10.77089596]"
    ,"Distance":"94"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Qu ận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853973,10.77089596] ; [106.69595337,10.76980972]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường L ê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.69238281,10.76828003] ; [106.68976593,10.76723862] ; [106.68936157,10.76767635]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68907166,10.76811028] ; [106.68920898,10.76819992] ; [106.68995667,10.76846981] ; [106.69026184,10.76858997]"
    ,"Distance":"141"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76858997] ; [106.69268036,10.76959038] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69458008,10.77031040] ; [106.69667053,10.77118015] ; [106.69673157,10.77120972] ; [106.69676971,10.77109146]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đ ường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69673920,10.77118874] ; [106.69673157,10.77120972] ; [106.69785309,10.77165985] ; [106.69799805,10.77161217] ; [106.69804382,10.77145386] ; [106.69809723,10.77129078] ; [106.69819641,10.77119637] ; [106.69835663,10.77114296] ; [106.69850922,10.77114868] ; [106.69865417,10.77120113] ; [106.69884491,10.77105904] ; [106.69897461,10.77101707] ; [106.69906616,10.77086926] ; [106.69933319,10.77043152] ; [106.69810486,10.76937771] ; [106.69739532,10.77025318] ; [106.69843292,10.77056980] ; [106.69844818,10.77054024]"
    ,"Distance":"799"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69843292,10.77056980] ; [106.69908142,10.77086449] ; [106.69956207,10.77093029] ; [106.69956207,10.77094269]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm  Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77093029] ; [106.70192719,10.77085972]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi , Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70192719,10.77085972] ; [106.70407104,10.77072239]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"Bến thủy nội địa Thủ Thiêm , đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70417023,10.77075958] ; [106.70461273,10.77073002] ; [106.70455933,10.77058983] ; [106.70513153,10.76945972] ; [106.70516205,10.76939011] ; [106.70529175,10.76941967] ; [106.70593262,10.76953983] ; [106.70606995,10.76959991] ; [106.70616150,10.76972961] ; [106.70639038,10.77054977] ; [106.70635986,10.77071953] ; [106.70630646,10.77134037] ; [106.70632935,10.77157021] ; [106.70635223,10.77178955] ; [106.70652008,10.77388954]"
    ,"Distance":"801"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"1092"
    ,"Station_Code":"Q1 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bảo tàng Tôn Đức Thắng"
    ,"Station_Address":"Đối diện số 5, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.777367
    ,"Long":106.707115
    ,"Polyline":"[106.70652008,10.77388954] ; [106.70658112,10.77460003] ; [106.70667267,10.77488041] ; [106.70671844,10.77563953] ; [106.70674896,10.77591038] ; [106.70671844,10.77598000] ; [106.70687866,10.77655983] ; [106.70702362,10.77717018]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"1093"
    ,"Station_Code":"Q1 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngô Văn Năm"
    ,"Station_Address":"Đối diện số 3C, đường Tôn Đức Thắng, Qu ận 1"
    ,"Lat":10.779949
    ,"Long":106.707818
    ,"Polyline":"[106.70711517,10.77736664] ; [106.70726013,10.77820969] ; [106.70755005,10.77939034] ; [106.70771790,10.77991962] ; [106.70781708,10.77994919]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"1094"
    ,"Station_Code":"Q1 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ba Son"
    ,"Station_Address":"2, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.781804
    ,"Long":106.706922
    ,"Polyline":"[106.70781708,10.77994919] ; [106.70787811,10.78044987] ; [106.70790863,10.78067017] ; [106.70783997,10.78085995] ; [106.70692444,10.78180408]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2572"
    ,"Station_Code":"Q1 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn  Hữu Cảnh"
    ,"Station_Address":"Cây xanh số 17, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.78328
    ,"Long":106.707222
    ,"Polyline":"[106.70681000,10.78180981] ; [106.70622253,10.78238010.06.70646667] ; [10.78262043,106.70690155]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2573"
    ,"Station_Code":"Q1 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"2A, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.785077
    ,"Long":106.708628
    ,"Polyline":"[106.70722198,10.78328037] ; [106.70715332,10.78334332] ; [106.70862579,10.78507710]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2579"
    ,"Station_Code":"QBTH 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Hồ Bơi Hải Quân"
    ,"Station_Address":"18, đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.789113
    ,"Long":106.710779
    ,"Polyline":"[106.70851135,10.78505993] ; [106.70870972,10.78546047] ; [106.70967102,10.78787994] ; [106.70983124,10.78827953] ; [106.71009064,10.78870964] ; [106.71025085,10.78890038] ; [106.71041870,10.78903961] ; [106.71066284,10.78921032] ; [106.71074677,10.78925991]"
    ,"Distance":"537"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3989"
    ,"Station_Code":"Q2 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Khu đô thị Sala"
    ,"Station_Address":"Đối diện Khu đô thị Sala, đường Mai Chí Thọ, Quận 2"
    ,"Lat":10.773183
    ,"Long":106.721642
    ,"Polyline":"[106.71074677,10.78925991] ; [106.71108246,10.78940010.06.71128845] ; [10.78946018,106.71164703] ; [10.78950977,106.71182251] ; [10.78950977,106.71240234] ; [10.78944969,106.71350861] ; [10.78929043,106.71402740] ; [10.78917980,106.71463013] ; [10.78899956,106.71515656] ; [10.78894043,106.71562195] ; [10.78897953,106.71598053] ; [10.78905010.06.71623230,10.78907967] ; [106.71640015,10.78903961] ; [106.71672058,10.78884029] ; [106.71871948,10.78505993] ; [106.72035217,10.78211975] ; [106.72106934,10.78077984] ; [106.72136688,10.78094006] ; [106.72280121,10.78168964]"
    ,"Distance":"1902"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3994"
    ,"Station_Code":"Q2 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Công An phường An Phú"
    ,"Station_Address":"Đối diện 244  , đường Nguyễn Hoàng, Quận 2"
    ,"Lat":10.79227
    ,"Long":106.745878
    ,"Polyline":"[106.72280121,10.78168964] ; [106.72413635,10.78238964] ; [106.72560120,10.78310966] ; [106.72692871,10.78380966]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2939"
    ,"Station_Code":"Q2 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trần Não"
    ,"Station_Address":"8B, đường Lương Định Của, Quận 2"
    ,"Lat":10.785556
    ,"Long":106.730418
    ,"Polyline":"[106.72692871,10.78380966] ; [106.72814941,10.78444958] ; [106.72946930,10.78516006] ; [106.72982025,10.78532028] ; [106.73036957,10.78563976]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2941"
    ,"Station_Code":"Q2 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Đình Bình Khánh"
    ,"Station_Address":"6/4, đường Lương Định Của, Quận 2"
    ,"Lat":10.786663
    ,"Long":106.732553
    ,"Polyline":"[106.73036957,10.78563976] ; [106.73130798,10.78610992] ; [106.73249054,10.78674984]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3990"
    ,"Station_Code":"Q2 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đường S ố 8"
    ,"Station_Address":"Đối diện 21/2, đường Lương  Định Của, Quận 2"
    ,"Lat":10.788528
    ,"Long":106.736094
    ,"Polyline":"[106.73249054,10.78674984] ; [106.73400116,10.78754997] ; [106.73467255,10.78792953] ; [106.73500061,10.78808022] ; [106.73583221,10.78851032] ; [106.73603821,10.78862000]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3995"
    ,"Station_Code":"Q2 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Chùa Huệ Nghiêm"
    ,"Station_Address":"Đối diện 22/4B, đường Lương Định Của,  Quận 2"
    ,"Lat":10.789487
    ,"Long":106.738856
    ,"Polyline":"[106.73603821,10.78862000] ; [106.73677826,10.78901958] ; [106.73706818,10.78915024] ; [106.73745728,10.78927994] ; [106.73773193,10.78934956] ; [106.73883057,10.78960037]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3991"
    ,"Station_Code":"Q2 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà hàng Ca Dao"
    ,"Station_Address":"Cột điện UEB33, đường Lương Định Của, Quận 2"
    ,"Lat":10.790099
    ,"Long":106.741667
    ,"Polyline":"[106.73883057,10.78960037] ; [106.74173737,10.79018974]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2944"
    ,"Station_Code":"Q2 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"Cột điện UEB38A, đường Lương Định Của, Quận 2"
    ,"Lat":10.79072
    ,"Long":106.744548
    ,"Polyline":"[106.74173737,10.79018974] ; [106.74452209,10.79080009]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"2945"
    ,"Station_Code":"Q2 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Phòng Đào tạo Quận 2"
    ,"Station_Address":"Đối diện 369A, đường Lương Định Của, Quận 2"
    ,"Lat":10.791917
    ,"Long":106.749902
    ,"Polyline":"[106.74452209,10.79080009] ; [106.74640656,10.79121971] ; [106.74774170,10.79156017] ; [106.74858856,10.79174042] ; [106.74989319,10.79199982]"
    ,"Distance":"602"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3998"
    ,"Station_Code":"Q2 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường  Giồng Ông tố"
    ,"Station_Address":"112-114, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.787994
    ,"Long":106.758804
    ,"Polyline":"[106.74990082,10.79191685] ; [106.75153351,10.79239655] ; [106.75220490,10.79252243] ; [106.75232697,10.79240131] ; [106.75248718,10.79234314] ; [106.75270081,10.79226971] ; [106.75291443,10.79215908] ; [106.75325012,10.79183769] ; [106.75377655,10.79120541] ; [106.75424957,10.79035187] ; [106.75507355,10.78864384] ; [106.75611115,10.78872871] ; [106.75706482,10.78864384] ; [106.75795746,10.78838062] ; [106.75861359,10.78813839] ; [106.75880432,10.78799438]"
    ,"Distance":"1234"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4000"
    ,"Station_Code":"Q2 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà thiếu nhi Quận 2"
    ,"Station_Address":"Nhà thiếu nhi Quận 2, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.787743
    ,"Long":106.762085
    ,"Polyline":"[106.75881958,10.78806019] ; [106.75911713,10.78800011] ; [106.75942993,10.78798008] ; [106.76170349,10.78779984] ; [106.76209259,10.78775978]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3993"
    ,"Station_Code":"Q2 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công ty Bình An"
    ,"Station_Address":"246, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.787539
    ,"Long":106.76458
    ,"Polyline":"[106.76209259,10.78775978] ; [106.76441956,10.78759956] ; [106.76458740,10.78757000]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4002"
    ,"Station_Code":"Q2 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Lê Văn  Thịnh"
    ,"Station_Address":"396A (400), đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.788514
    ,"Long":106.77021
    ,"Polyline":"[106.76458740,10.78757000] ; [106.76490021,10.78754044] ; [106.76505280,10.78754997] ; [106.76529694,10.78765011] ; [106.76574707,10.78785038] ; [106.76605988,10.78796005] ; [106.76753998,10.78822994] ; [106.76863861,10.78841019] ; [106.76909637,10.78849030] ; [106.76921844,10.78853035] ; [106.76963806,10.78861046] ; [106.77021790,10.78857040]"
    ,"Distance":"642"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4004"
    ,"Station_Code":"Q2 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Nhà Sách Nguyễn Văn Cừ"
    ,"Station_Address":"478, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.788264
    ,"Long":106.772842
    ,"Polyline":"[106.77021790,10.78857040] ; [106.77285004,10.78831005]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3996"
    ,"Station_Code":"Q2 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Đường số 6"
    ,"Station_Address":"548-550, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.788046
    ,"Long":106.7752
    ,"Polyline":"[106.77285004,10.78831005] ; [106.77401733,10.78818989] ; [106.77462769,10.78814030] ; [106.77519989,10.78808975]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3997"
    ,"Station_Code":"Q2 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường Nguyễn Văn Trỗi"
    ,"Station_Address":"630, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.788806
    ,"Long":106.778122
    ,"Polyline":"[106.77519989,10.78808975] ; [106.77603149,10.78800011] ; [106.77635193,10.78800964] ; [106.77657318,10.78808975] ; [106.77696228,10.78829956] ; [106.77790070,10.78872967] ; [106.77810669,10.78884029]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4006"
    ,"Station_Code":"Q2 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Đỗ Xuân Hợp"
    ,"Station_Address":"672-674, đường Nguyễn Duy Trinh, Quận 2"
    ,"Lat":10.789444
    ,"Long":106.779427
    ,"Polyline":"[106.77810669,10.78884029] ; [106.77941132,10.78948021]"
    ,"Distance":"168"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4008"
    ,"Station_Code":"Q9 179"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã 3 Đỗ Xuân Hợp"
    ,"Station_Address":"754-756, đường  Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.790394
    ,"Long":106.782153
    ,"Polyline":"[106.77941132,10.78948021] ; [106.78095245,10.79032993] ; [106.78130341,10.79039955] ; [106.78157806,10.79041004] ; [106.78204346,10.79043961]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3999"
    ,"Station_Code":"Q9 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Công ty Thành Công"
    ,"Station_Address":"Đối diện 763, đường Nguyễn Duy Trinh , Quận 9"
    ,"Lat":10.790518
    ,"Long":106.784744
    ,"Polyline":"[106.78204346,10.79043961] ; [106.78473663,10.79057980]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4010"
    ,"Station_Code":"Q9 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"cầu Xây Dựng"
    ,"Station_Address":"Cột điện EB67, đường Nguyễn Duy Trinh, Qu ận 9"
    ,"Lat":10.790678
    ,"Long":106.788322
    ,"Polyline":"[106.78473663,10.79057980] ; [106.78814697,10.79074955]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4001"
    ,"Station_Code":"Q9 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Vành đai trong"
    ,"Station_Address":"36, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.790784
    ,"Long":106.790736
    ,"Polyline":"[106.78832245,10.79067802] ; [106.79073334,10.79078388]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4003"
    ,"Station_Code":"Q9 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Trường Hoa Hồng Đỏ"
    ,"Station_Address":"816, đường Nguy ễn Duy Trinh, Quận 9"
    ,"Lat":10.791008
    ,"Long":106.794258
    ,"Polyline":"[106.79216003,10.79086018] ; [106.79238892,10.79076004] ; [106.79245758,10.79071999] ; [106.79261780,10.79069996] ; [106.79274750,10.79076004] ; [106.79277802,10.79080009] ; [106.79319763,10.79100037] ; [106.79425812,10.79106998]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4012"
    ,"Station_Code":"Q9 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"UBND P.Phú Hữu"
    ,"Station_Address":"846-848, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.791205
    ,"Long":106.798019
    ,"Polyline":"[106.79425812,10.79106998] ; [106.79496002,10.79109955] ; [106.79685974,10.79125023] ; [106.79781342,10.79129982] ; [106.79801178,10.79131031]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4005"
    ,"Station_Code":"Q9 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà Thờ Phú Hữu"
    ,"Station_Address":"916, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.791374
    ,"Long":106.800596
    ,"Polyline":"[106.79801178,10.79131031] ; [106.80050659,10.79144001]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4014"
    ,"Station_Code":"Q9 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu Huyện Thanh"
    ,"Station_Address":"Kế 976, đường  Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.791969
    ,"Long":106.803943
    ,"Polyline":"[106.80059814,10.79137421] ; [106.80065155,10.79143143] ; [106.80113983,10.79148960] ; [106.80151367,10.79154015] ; [106.80393219,10.79205990] ; [106.80393982,10.79196930]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4007"
    ,"Station_Code":"Q9 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cao Tốc Dầu Giây"
    ,"Station_Address":"992, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.793239
    ,"Long":106.807172
    ,"Polyline":"[106.80393219,10.79205990] ; [106.80600739,10.79251003] ; [106.80673981,10.79269028] ; [106.80690002,10.79277992] ; [106.80696106,10.79286003] ; [106.80706024,10.79327011]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4009"
    ,"Station_Code":"Q9 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đường Số 1"
    ,"Station_Address":"1042, đường Nguyễn Duy Trinh , Quận 9"
    ,"Lat":10.799141
    ,"Long":106.808846
    ,"Polyline":"[106.80706024,10.79327011] ; [106.80735779,10.79459953] ; [106.80766296,10.79607964] ; [106.80786896,10.79693985] ; [106.80853271,10.79872036] ; [106.80857086,10.79887009] ; [106.80873871,10.79913044] ; [106.80880737,10.79918957]"
    ,"Distance":"710"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4011"
    ,"Station_Code":"Q9 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Trường Long Trường"
    ,"Station_Address":"Đối diện 1149, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.801476
    ,"Long":106.811668
    ,"Polyline":"[106.80880737,10.79918957] ; [106.80927277,10.79957008] ; [106.80976868,10.80004025] ; [106.81089020,10.80097008] ; [106.81159210,10.80156040]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4013"
    ,"Station_Code":"Q9 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Đường Số 6"
    ,"Station_Address":"1236, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.803749
    ,"Long":106.814781
    ,"Polyline":"[106.81159210,10.80156040] ; [106.81227875,10.80210972] ; [106.81259918,10.80239010.06.81324768] ; [10.80284023,106.81420135] ; [10.80342007,106.81474304]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4016"
    ,"Station_Code":"Q9 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"UBND phường Long Trường"
    ,"Station_Address":"1392, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.805082
    ,"Long":106.816673
    ,"Polyline":"[106.81474304,10.80379963] ; [106.81664276,10.80513000]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"1516"
    ,"Station_Code":"Q9 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Chợ Long  Trường"
    ,"Station_Address":"Chợ Long Trường, đường Nguyễn Duy Trinh, Qu ận 9"
    ,"Lat":10.806039
    ,"Long":106.821106
    ,"Polyline":"[106.81664276,10.80513000] ; [106.81719208,10.80550957] ; [106.81762695,10.80562019] ; [106.81965637,10.80589962] ; [106.82109070,10.80611992]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4130"
    ,"Station_Code":"Q9 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"1610, Nguyễn Duy Trinh"
    ,"Station_Address":"1610, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.807619
    ,"Long":106.826604
    ,"Polyline":"[106.82110596,10.80603886] ; [106.82273102,10.80634975] ; [106.82550812,10.80704498] ; [106.82660675,10.80761909]"
    ,"Distance":"631"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4017"
    ,"Station_Code":"Q9 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Trạm y  tế"
    ,"Station_Address":"1786 (Đối diện Trạm y tế), đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.809566
    ,"Long":106.830009
    ,"Polyline":"[106.82660675,10.80761909] ; [106.82745361,10.80821991] ; [106.83000946,10.80956650]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4018"
    ,"Station_Code":"Q9 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Cầu Võ Khế"
    ,"Station_Address":"1732, đường  Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.810623
    ,"Long":106.832054
    ,"Polyline":"[106.82997894,10.80963039] ; [106.83202362,10.81068039]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3761"
    ,"Station_Code":"Q9 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Ngã 3 Long Thuận"
    ,"Station_Address":"Cột điện 6, đường Long Thuận, Quận 9"
    ,"Lat":10.814425
    ,"Long":106.834999
    ,"Polyline":"[106.83202362,10.81068039] ; [106.83226776,10.81081009] ; [106.83268738,10.81107044] ; [106.83286285,10.81122017] ; [106.83387756,10.81355953] ; [106.83403015,10.81396008] ; [106.83412933,10.81435966] ; [106.83499146,10.81447029]"
    ,"Distance":"594"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3763"
    ,"Station_Code":"Q9 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Cầu Trường Phước"
    ,"Station_Address":"116/A, đường Long Thuận, Quận 9"
    ,"Lat":10.811874
    ,"Long":106.843163
    ,"Polyline":"[106.83499908,10.81442451] ; [106.83499146,10.81447029] ; [106.83782959,10.81488037] ; [106.83801270,10.81486988] ; [106.83818817,10.81484985] ; [106.83837128,10.81478977] ; [106.83851624,10.81470013] ; [106.83924103,10.81396008] ; [106.83957672,10.81371021] ; [106.84097290,10.81285000] ; [106.84222412,10.81210327] ; [106.84264374,10.81198215] ; [106.84316254,10.81194019] ; [106.84317017,10.81194019] ; [106.84316254,10.81187439]"
    ,"Distance":"1012"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3762"
    ,"Station_Code":"Q9 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"phim tr ường"
    ,"Station_Address":"Cột điện PDA40, đường Long  Thuận, Quận 9"
    ,"Lat":10.811287
    ,"Long":106.84671
    ,"Polyline":"[106.84316254,10.81187439] ; [106.84317017,10.81194019] ; [106.84409332,10.81175995] ; [106.84562683,10.81147099] ; [106.84671783,10.81134987] ; [106.84671021,10.81128693]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3764"
    ,"Station_Code":"Q9 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Trại nhím"
    ,"Station_Address":"220, đường Long Thu ận, Quận 9"
    ,"Lat":10.811619
    ,"Long":106.853827
    ,"Polyline":"[106.84671021,10.81128693] ; [106.84671783,10.81134987] ; [106.84745789,10.81124020] ; [106.84803772,10.81128025] ; [106.85271454,10.81159782] ; [106.85379028,10.81161022] ; [106.85379791,10.81152916]"
    ,"Distance":"802"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3766"
    ,"Station_Code":"Q9 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngã 3 Long Phước"
    ,"Station_Address":"322-324, đường Long Thuận, Quận 9"
    ,"Lat":10.811961
    ,"Long":106.859035
    ,"Polyline":"[106.85379791,10.81152916] ; [106.85379028,10.81161022] ; [106.85778046,10.81193447] ; [106.85897827,10.81194973] ; [106.85898590,10.81188488]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"3765"
    ,"Station_Code":"Q9 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trường tiểu học Long Phước"
    ,"Station_Address":"Tr ường Tiểu học Long Phước, đường Long Phước, Quận 9"
    ,"Lat":10.811131
    ,"Long":106.859474
    ,"Polyline":"[106.85903168,10.81196117] ; [106.85981750,10.81200981] ; [106.85968781,10.81161976] ; [106.85954285,10.81110954] ; [106.85947418,10.81113052]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"128"
    ,"Station_Id":"4019"
    ,"Station_Code":"BX27"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Chợ Long Phước"
    ,"Station_Address":"ĐẦU BẾN CHỢ LONG  PHƯỚC, đường Long Phước, Quận 9"
    ,"Lat":10.808298
    ,"Long":106.85936
    ,"Polyline":"[106.85954285,10.81110954] ; [106.85929871,10.81033039] ; [106.85916138,10.80976963] ; [106.85916138,10.80957031] ; [106.85942078,10.80877018] ; [106.85955048,10.80836010]"
    ,"Distance":"348"
  }]