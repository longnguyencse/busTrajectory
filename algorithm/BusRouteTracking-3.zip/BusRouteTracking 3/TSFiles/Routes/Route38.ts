export const Route38 =[

  {
     "Route_Id":"38"
    ,"Station_Id":"1979"
    ,"Station_Code":"BX49"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Trạm Điều hành Tân Phú (0,55ha)"
    ,"Station_Address":"Bến xe Tân Phú, đường Tr ường Chinh, Quận Tân Phú"
    ,"Lat":10.808563
    ,"Long":106.634095
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Tr ường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63409424,10.80856323] ; [106.63416290,10.80856228] ; [106.63426208,10.80820942]"
    ,"Distance":"48"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63426208,10.80820942] ; [106.63507843,10.80599689] ; [106.63516998,10.80601215] ; [106.63494873,10.80675030] ; [106.63490295,10.80696583] ; [106.63487244,10.80716133] ; [106.63488007,10.80736637] ; [106.63490295,10.80753994] ; [106.63467407,10.80803871]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63467407,10.80803871] ; [106.63349915,10.81169510]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2653"
    ,"Station_Code":"QTP 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"TT vh Tân Phú"
    ,"Station_Address":"Đối diện 90, đường Dương Đức Hiền, Qu ận Tân Phú"
    ,"Lat":10.810605
    ,"Long":106.626991
    ,"Polyline":"[106.63349915,10.81169510.06.63290405] ; [10.81377888,106.63266754] ; [10.81367397,106.63282776] ; [10.81259918,106.62933350] ; [10.81212997,106.62844849] ; [10.81198215,106.62738800] ; [10.81158733,106.62696838] ; [10.81138134,106.62699127]"
    ,"Distance":"1136"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2655"
    ,"Station_Code":"QTP 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Lê Trọng Tấn"
    ,"Station_Address":"Đối diện 14 (Công ty may), đường Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.807312
    ,"Long":106.627266
    ,"Polyline":"[106.62700653,10.81060982] ; [106.62703705,10.80980015] ; [106.62712097,10.80891037] ; [106.62728882,10.80731010]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2000"
    ,"Station_Code":"QTP 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"188, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806785
    ,"Long":106.625366
    ,"Polyline":"[106.62726593,10.80731201] ; [106.62739563,10.80634403] ; [106.62536621,10.80678463]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2005"
    ,"Station_Code":"QTP 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Bờ Bao  Tân Thắng"
    ,"Station_Address":"284, đường L ê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.807464
    ,"Long":106.622177
    ,"Polyline":"[106.62536621,10.80678463] ; [106.62217712,10.80746365]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2002"
    ,"Station_Code":"QTP 214"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Sơn Kỳ"
    ,"Station_Address":"Đối diện chợ Sơn kỳ, đường Bờ Bao tân  Thắng, Quận Tân Phú"
    ,"Lat":10.805852
    ,"Long":106.62188
    ,"Polyline":"[106.62217712,10.80746365] ; [106.62176514,10.80753994] ; [106.62172699,10.80722427] ; [106.62174988,10.80665016] ; [106.62174225,10.80636501] ; [106.62187958,10.80585194]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1971"
    ,"Station_Code":"QTP 212"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ủy ban phường Sơn Kỳ"
    ,"Station_Address":"Ủy ban phường Sơn Kỳ, đường Bờ Bao tân Thắng, Quận Tân Ph ú"
    ,"Lat":10.803288
    ,"Long":106.622078
    ,"Polyline":"[106.62187958,10.80585194] ; [106.62242126,10.80383110.06.62245178] ; [10.80368805,106.62243652] ; [10.80355167,106.62207794]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2003"
    ,"Station_Code":"BBTT06"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu thị Aeon"
    ,"Station_Address":"Siêu thị Aeon, đường Bờ Bao tân Thắng, Quận Tân Phú"
    ,"Lat":10.801151275634766
    ,"Long":106.61847686767578
    ,"Polyline":"[106.62207794,10.80328846] ; [106.62024689,10.80146980] ; [106.61945343,10.80136967] ; [106.61878204,10.80133343] ; [106.61847687,10.80115128]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2004"
    ,"Station_Code":"QTP 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Tân Quý"
    ,"Station_Address":"Kế 410, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798983
    ,"Long":106.618134
    ,"Polyline":"[106.61847687,10.80115128] ; [106.61830902,10.80113792] ; [106.61805725,10.80090618] ; [106.61816406,10.80072689] ; [106.61820984,10.80056858] ; [106.61834717,10.79911423] ; [106.61813354,10.79898262]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2007"
    ,"Station_Code":"QTP 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường Tiểu Học Tân Quý"
    ,"Station_Address":"3/1B, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798385
    ,"Long":106.616493
    ,"Polyline":"[106.61813354,10.79898262] ; [106.61649323,10.79838467]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2009"
    ,"Station_Code":"QTP 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Bình Long"
    ,"Station_Address":"520-522, đường  Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.797263
    ,"Long":106.614571
    ,"Polyline":"[106.61649323,10.79838467] ; [106.61621857,10.79821968] ; [106.61566925,10.79790020] ; [106.61459351,10.79726028] ; [106.61457062,10.79726315]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2008"
    ,"Station_Code":"QBT 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Lò Thiêu"
    ,"Station_Address":"Đối diện Th ành Minh Trương Tế, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.795939
    ,"Long":106.612221
    ,"Polyline":"[106.61457062,10.79726315] ; [106.61229706,10.79590034] ; [106.61222076,10.79593945]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1804"
    ,"Station_Code":"QBT 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"UBND Phường Bình Hưng Hòa"
    ,"Station_Address":"Đối diện Ủy ban nhân dân phường Bình Hưng Hòa, đường Tân Kỳ Tân Quý, Quận B ình Tân"
    ,"Lat":10.794702
    ,"Long":106.610229
    ,"Polyline":"[106.61222076,10.79593945] ; [106.61224365,10.79586887] ; [106.61022949,10.79470158]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1808"
    ,"Station_Code":"QBT 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Phòng khám Đa khoa"
    ,"Station_Address":"722, đường Tân Kỳ Tân Quý , Quận Bình Tân"
    ,"Lat":10.792528
    ,"Long":106.606636
    ,"Polyline":"[106.61022949,10.79470158] ; [106.60951233,10.79424572] ; [106.60922241,10.79406643] ; [106.60887146,10.79385090] ; [106.60805511,10.79335499] ; [106.60746765,10.79298115] ; [106.60663605,10.79252815]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1810"
    ,"Station_Code":"QBT 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bưu điện"
    ,"Station_Address":"928, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.788981
    ,"Long":106.6007
    ,"Polyline":"[106.60663605,10.79252815] ; [106.60604095,10.79220104] ; [106.60524750,10.79171085] ; [106.60374451,10.79075241] ; [106.60333252,10.79045963] ; [106.60278320,10.79013538] ; [106.60234070,10.78985023] ; [106.60108185,10.78918743] ; [106.60070038,10.78898144]"
    ,"Distance":"760"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2011"
    ,"Station_Code":"QBT 260"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 3 Ao Đôi"
    ,"Station_Address":"339, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.775607
    ,"Long":106.600991
    ,"Polyline":"[106.60070038,10.78898144] ; [106.59856415,10.78763199] ; [106.59794617,10.78709507] ; [106.59782410,10.78692627] ; [106.59783936,10.78666306] ; [106.59847260,10.78461838] ; [106.60099030,10.77560711]"
    ,"Distance":"1699"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2010"
    ,"Station_Code":"QBT 261"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Công ty  Đại Càng Phát"
    ,"Station_Address":"239, đường  Mã Lò, Quận Bình Tân"
    ,"Lat":10.77235
    ,"Long":106.601849
    ,"Polyline":"[106.60099030,10.77560711] ; [106.60185242,10.77235031]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2013"
    ,"Station_Code":"QBT 262"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Phòng tiếp dân"
    ,"Station_Address":"201, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.768224
    ,"Long":106.60311
    ,"Polyline":"[106.60185242,10.77235031] ; [106.60311127,10.76822376]"
    ,"Distance":"480"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1866"
    ,"Station_Code":"QBT 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Thạch cao Thanh Tài"
    ,"Station_Address":"737, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.766184
    ,"Long":106.605835
    ,"Polyline":"[106.60311127,10.76822376] ; [106.60332489,10.76769161] ; [106.60388947,10.76521492] ; [106.60491180,10.76585770] ; [106.60583496,10.76618385]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2012"
    ,"Station_Code":"QBT 205"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đất Mới"
    ,"Station_Address":"245, đường Đất Mới, Quận Bình Tân"
    ,"Lat":10.766664
    ,"Long":106.609535
    ,"Polyline":"[106.60583496,10.76618385] ; [106.60964203,10.76793385] ; [106.60968781,10.76676369] ; [106.60953522,10.76666355]"
    ,"Distance":"610"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2015"
    ,"Station_Code":"QBT 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Quán Cau Xanh"
    ,"Station_Address":"177, đường Đất Mới, Quận Bình Tân"
    ,"Lat":10.765465
    ,"Long":106.609634
    ,"Polyline":"[106.60953522,10.76666355] ; [106.60953522,10.76666355] ; [106.60975647,10.76664257] ; [106.60980225,10.76550961] ; [106.60963440,10.76546478] ; [106.60963440,10.76546478]"
    ,"Distance":"170"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2014"
    ,"Station_Code":"QBT 203"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Bình  Trị Đông cũ"
    ,"Station_Address":"107, đường Đ ất Mới, Quận Bình Tân"
    ,"Lat":10.762595
    ,"Long":106.609863
    ,"Polyline":"[106.60963440,10.76546478] ; [106.60977173,10.76517200] ; [106.60984802,10.76422977] ; [106.60991669,10.76344967] ; [106.60990906,10.76294899] ; [106.60986328,10.76259518]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2017"
    ,"Station_Code":"QBT 196"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Bình Trị Đông mới"
    ,"Station_Address":"108, đường Trương Phước Phan, Quận Bình Tân"
    ,"Lat":10.76277
    ,"Long":106.613121
    ,"Polyline":"[106.60986328,10.76259518] ; [106.60998535,10.76255322] ; [106.61005402,10.76158905] ; [106.61274719,10.76188374] ; [106.61312103,10.76276970]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2016"
    ,"Station_Code":"QBT 195"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Làng nướng Tây Nguyên"
    ,"Station_Address":"40, đường Trương Phước Phan, Quận Bình Tân"
    ,"Lat":10.765926
    ,"Long":106.613251
    ,"Polyline":"[106.61312103,10.76276970] ; [106.61310577,10.76549911] ; [106.61325073,10.76592636]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2021"
    ,"Station_Code":"QBT 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Lê Thái"
    ,"Station_Address":"2, đường Trương Phước Phan, Quận Bình Tân"
    ,"Lat":10.767774
    ,"Long":106.613541
    ,"Polyline":"[106.61325073,10.76592636] ; [106.61354065,10.76777363]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2018"
    ,"Station_Code":"QBT 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Tân Khai"
    ,"Station_Address":"499, đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.768714
    ,"Long":106.614445
    ,"Polyline":"[106.61354065,10.76777363] ; [106.61373901,10.76938820] ; [106.61444855,10.76871395]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2022"
    ,"Station_Code":"QBT 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Mỹ Hảo"
    ,"Station_Address":"423, đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.767049
    ,"Long":106.616274
    ,"Polyline":"[106.61444855,10.76871395] ; [106.61627197,10.76704884]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2019"
    ,"Station_Code":"QBT 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ao cá C ây Bàng"
    ,"Station_Address":"379, đường Tân H òa Đông, Quận Bình Tân"
    ,"Lat":10.765296
    ,"Long":106.618065
    ,"Polyline":"[106.61627197,10.76704884] ; [106.61806488,10.76529598]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2024"
    ,"Station_Code":"QBT 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Bình Trị Đông"
    ,"Station_Address":"331, đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.763444
    ,"Long":106.62011
    ,"Polyline":"[106.61806488,10.76529598] ; [106.62010956,10.76344395]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2020"
    ,"Station_Code":"QBT 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Ấp Chiến Lược"
    ,"Station_Address":"275, đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.761963
    ,"Long":106.62181
    ,"Polyline":"[106.62010956,10.76344395] ; [106.62181091,10.76196289]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2025"
    ,"Station_Code":"Q6 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"An Dương Vương"
    ,"Station_Address":"243, đường T ân Hòa Đông, Quận 6"
    ,"Lat":10.759565
    ,"Long":106.627711
    ,"Polyline":"[106.62181091,10.76196289] ; [106.62308502,10.76080322] ; [106.62355804,10.76050282] ; [106.62400055,10.76031876] ; [106.62770844,10.75956535]"
    ,"Distance":"719"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2023"
    ,"Station_Code":"Q6 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Tân Hòa Đông"
    ,"Station_Address":"191, đường Tân Hòa Đông, Quận 6"
    ,"Lat":10.75801
    ,"Long":106.630812
    ,"Polyline":"[106.62770844,10.75956535] ; [106.62929535,10.75959682] ; [106.62947845,10.75950718] ; [106.62960052,10.75941277] ; [106.63081360,10.75800991]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2026"
    ,"Station_Code":"Q6 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ  Phú Lâm"
    ,"Station_Address":"55-57, đường Tân Hòa Đông, Quận 6"
    ,"Lat":10.756783
    ,"Long":106.631847
    ,"Polyline":"[106.63081360,10.75800991] ; [106.63184357,10.75678253]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2027"
    ,"Station_Code":"Q6 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Coop Mart  Phú Lâm"
    ,"Station_Address":"Đối diện 06, đ ường Tân Hòa Đông, Quận 6"
    ,"Lat":10.754616
    ,"Long":106.633875
    ,"Polyline":"[106.63184357,10.75678253] ; [106.63387299,10.75461578]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"724"
    ,"Station_Code":"Q6 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Cầu Ông Buông"
    ,"Station_Address":"963, đường Hồng B àng, Quận 6"
    ,"Lat":10.754548
    ,"Long":106.637995
    ,"Polyline":"[106.63387299,10.75461578] ; [106.63426971,10.75424767] ; [106.63419342,10.75408936] ; [106.63417816,10.75392056] ; [106.63423920,10.75377369] ; [106.63433838,10.75368881] ; [106.63442993,10.75366211] ; [106.63452148,10.75366783] ; [106.63462067,10.75369930] ; [106.63468170,10.75374126] ; [106.63477325,10.75387383] ; [106.63481903,10.75404167] ; [106.63522339,10.75434780] ; [106.63539124,10.75441647] ; [106.63555908,10.75443745] ; [106.63629150,10.75442123] ; [106.63713837,10.75452137] ; [106.63777161,10.75463772] ; [106.63799286,10.75454807]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"719"
    ,"Station_Code":"Q6 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngân hàng ACB"
    ,"Station_Address":"871, đường Hồng B àng, Quận 6"
    ,"Lat":10.754295
    ,"Long":106.641245
    ,"Polyline":"[106.63799286,10.75454807] ; [106.63947296,10.75455856] ; [106.64124298,10.75429535]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"721"
    ,"Station_Code":"Q6 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường Nguyễn Đức Cảnh"
    ,"Station_Address":"799, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754021
    ,"Long":106.644003
    ,"Polyline":"[106.64124298,10.75429535] ; [106.64400482,10.75402069]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"723"
    ,"Station_Code":"Q6 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chùa Nam Phổ Đà"
    ,"Station_Address":"735, đường Hồng B àng, Quận 6"
    ,"Lat":10.753789
    ,"Long":106.645955
    ,"Polyline":"[106.64400482,10.75402069] ; [106.64417267,10.75405216] ; [106.64587402,10.75384140] ; [106.64595795,10.75378895]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"722"
    ,"Station_Code":"Q6 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"647, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753647
    ,"Long":106.647323
    ,"Polyline":"[106.64595795,10.75378895] ; [106.64732361,10.75364685]"
    ,"Distance":"151"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.64732361,10.75364685] ; [106.65086365,10.75338840] ; [106.65110779,10.75326157] ; [106.65183258,10.75306129] ; [106.65180969,10.75150204] ; [106.65106964,10.75118542]"
    ,"Distance":"763"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Qu ận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"620"
    ,"Station_Code":"Q11 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Cây Mai"
    ,"Station_Address":"384, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753689
    ,"Long":106.64926
    ,"Polyline":"[106.65106964,10.75118542] ; [106.65087128,10.75102711] ; [106.65047455,10.75107002] ; [106.65080261,10.75354671] ; [106.64926147,10.75368881]"
    ,"Distance":"518"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"622"
    ,"Station_Code":"Q11 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"508, đường Hồng  Bàng, Quận 11"
    ,"Lat":10.753952
    ,"Long":106.646787
    ,"Polyline":"[106.64926147,10.75368881] ; [106.64678955,10.75395203]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"624"
    ,"Station_Code":"Q11 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"638-640, đường Hồng Bàng, Quận 11"
    ,"Lat":10.754232
    ,"Long":106.644368
    ,"Polyline":"[106.64678955,10.75395203] ; [106.64437103,10.75423241]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"625"
    ,"Station_Code":"Q11 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Huê Lâm"
    ,"Station_Address":"690 (138), đường Hồng Bàng, Quận 11"
    ,"Lat":10.754558
    ,"Long":106.641229
    ,"Polyline":"[106.64437103,10.75423241] ; [106.64122772,10.75455761]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"623"
    ,"Station_Code":"Q11 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"786, đường Hồng Bàng, Quận 11"
    ,"Lat":10.75477
    ,"Long":106.638428
    ,"Polyline":"[106.64122772,10.75455761] ; [106.64076996,10.75456333] ; [106.63912201,10.75476360] ; [106.63842773,10.75477028]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"626"
    ,"Station_Code":"Q6 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Mạc Đỉnh Chi"
    ,"Station_Address":"832-834 , đường Hồng Bàng, Quận 6"
    ,"Lat":10.754732
    ,"Long":106.635574
    ,"Polyline":"[106.63842773,10.75477028] ; [106.63758850,10.75483799] ; [106.63707733,10.75475883] ; [106.63665009,10.75481701] ; [106.63594818,10.75479031] ; [106.63557434,10.75473213]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"4219"
    ,"Station_Code":"Q6 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Coop mart Phú Lâm"
    ,"Station_Address":"6, đường Tân  Hòa Đông, Quận 6"
    ,"Lat":10.754664
    ,"Long":106.633971
    ,"Polyline":"[106.63557434,10.75473213] ; [106.63488770,10.75432682] ; [106.63467407,10.75426292] ; [106.63455200,10.75429535] ; [106.63443756,10.75432682] ; [106.63436127,10.75426865] ; [106.63345337,10.75523281]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1948"
    ,"Station_Code":"Q6 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Phú Lâm"
    ,"Station_Address":"78, đường Tân Hòa Đông, Quận 6"
    ,"Lat":10.75674
    ,"Long":106.63204
    ,"Polyline":"[106.63345337,10.75523281] ; [106.63204193,10.75673962]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1955"
    ,"Station_Code":"Q6 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Tân Hòa Đông"
    ,"Station_Address":"142A-146A, đường Tân Hòa Đông, Quận 6"
    ,"Lat":10.757947
    ,"Long":106.631016
    ,"Polyline":"[106.63204193,10.75673962] ; [106.63110352,10.75783634] ; [106.63101959,10.75794697]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1949"
    ,"Station_Code":"Q6 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"An Dương Vương"
    ,"Station_Address":"172B, đường Tân Hòa Đông, Quận 6"
    ,"Lat":10.759428
    ,"Long":106.629664
    ,"Polyline":"[106.63101959,10.75794697] ; [106.62982178,10.75923347] ; [106.62966156,10.75942802]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1956"
    ,"Station_Code":"QBT 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ấp Chiến Lược"
    ,"Station_Address":"224, đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.761136
    ,"Long":106.622792
    ,"Polyline":"[106.62966156,10.75942802] ; [106.62944794,10.75958061] ; [106.62933350,10.75960159] ; [106.62928009,10.75961781] ; [106.62868500,10.75962830] ; [106.62839508,10.75965977] ; [106.62776184,10.75967026] ; [106.62710571,10.75974941] ; [106.62584686,10.75997066] ; [106.62471771,10.76014996] ; [106.62432861,10.76025581] ; [106.62375641,10.76045036] ; [106.62344360,10.76060867] ; [106.62320709,10.76075077] ; [106.62281036,10.76117229]"
    ,"Distance":"799"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1950"
    ,"Station_Code":"QBT 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Phường Bình Trị Đông"
    ,"Station_Address":"284-D18/36,  đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.763223
    ,"Long":106.620499
    ,"Polyline":"[106.62281036,10.76117229] ; [106.62178040,10.76208973] ; [106.62093353,10.76285362] ; [106.62049866,10.76322269]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1958"
    ,"Station_Code":"QBT 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ao cá C ây Bàng"
    ,"Station_Address":"334, đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.76497
    ,"Long":106.618546
    ,"Polyline":"[106.62049866,10.76322269] ; [106.61959839,10.76405525] ; [106.61878967,10.76477242] ; [106.61854553,10.76496983]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1952"
    ,"Station_Code":"QBT 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Mỹ Hảo"
    ,"Station_Address":"378, đường Tân H òa Đông, Quận Bình Tân"
    ,"Lat":10.766564
    ,"Long":106.616918
    ,"Polyline":"[106.61854553,10.76496983] ; [106.61854553,10.76496983] ; [106.61835480,10.76515675] ; [106.61756897,10.76592636] ; [106.61692047,10.76656437]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1954"
    ,"Station_Code":"QBT 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Tân Khai"
    ,"Station_Address":"470, đường Tân Hòa Đông, Quận Bình Tân"
    ,"Lat":10.768761
    ,"Long":106.614504
    ,"Polyline":"[106.61692047,10.76656437] ; [106.61450195,10.76876068]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1960"
    ,"Station_Code":"QBT 199"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Lê Thái"
    ,"Station_Address":"9, đường Trương Phước Phan, Quận Bình Tân"
    ,"Lat":10.767929
    ,"Long":106.613487
    ,"Polyline":"[106.61450195,10.76876068] ; [106.61376953,10.76937294] ; [106.61348724,10.76792908]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1957"
    ,"Station_Code":"QBT 198"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Làng nướng Tây Nguyên"
    ,"Station_Address":"83, đường Trương Phước Phan, Quận Bình Tân"
    ,"Lat":10.765879
    ,"Long":106.613136
    ,"Polyline":"[106.61348724,10.76792908] ; [106.61313629,10.76587868]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1959"
    ,"Station_Code":"QBT 200"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Bình Trị Đông cũ"
    ,"Station_Address":"Đối diện 95, đường Đất Mới, Qu ận Bình Tân"
    ,"Lat":10.762324
    ,"Long":106.610107
    ,"Polyline":"[106.61313629,10.76587868] ; [106.61296082,10.76197910.06.61005402] ; [10.76161003,106.61010742]"
    ,"Distance":"835"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1961"
    ,"Station_Code":"QBT 201"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Quán Cau Xanh"
    ,"Station_Address":"132, đường Đất M ới, Quận Bình Tân"
    ,"Lat":10.765223
    ,"Long":106.609901
    ,"Polyline":"[106.61010742,10.76232433] ; [106.60998535,10.76387119] ; [106.60990143,10.76522255]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1964"
    ,"Station_Code":"QBT 202"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đất Mới"
    ,"Station_Address":"192, đường Đất Mới, Quận B ình Tân"
    ,"Lat":10.76687
    ,"Long":106.609825
    ,"Polyline":"[106.60990143,10.76522255] ; [106.60987854,10.76607895] ; [106.60982513,10.76686954]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1783"
    ,"Station_Code":"QBT 245"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"620, đường Hương lộ 2, Quận B ình Tân"
    ,"Lat":10.767813
    ,"Long":106.609231
    ,"Polyline":"[106.60982513,10.76686954] ; [106.60970306,10.76797104] ; [106.60923004,10.76781273]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1784"
    ,"Station_Code":"QBT 244"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Hương lộ 2"
    ,"Station_Address":"964, đường Hương lộ 2, Quận Bình Tân"
    ,"Lat":10.766664
    ,"Long":106.606607
    ,"Polyline":"[106.60923004,10.76781273] ; [106.60660553,10.76666355]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1963"
    ,"Station_Code":"QBT 267"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Phòng tiếp dân"
    ,"Station_Address":"156 VP tiếp Dân, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.768097
    ,"Long":106.603239
    ,"Polyline":"[106.60660553,10.76666355] ; [106.60491180,10.76585770] ; [106.60387421,10.76524639] ; [106.60353851,10.76703835] ; [106.60324097,10.76809692]"
    ,"Distance":"664"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1966"
    ,"Station_Code":"QBT 265"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Công ty  Đại Càng Phát"
    ,"Station_Address":"290, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.771929
    ,"Long":106.602053
    ,"Polyline":"[106.60324097,10.76809692] ; [106.60228729,10.77092743] ; [106.60205078,10.77192879]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1968"
    ,"Station_Code":"QBT 243"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã 3 Áo  Đôi"
    ,"Station_Address":"330, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.774817
    ,"Long":106.601547
    ,"Polyline":"[106.60205078,10.77192879] ; [106.60136414,10.77467918] ; [106.60154724,10.77481747]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1739"
    ,"Station_Code":"QBT 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Mã Lò"
    ,"Station_Address":"973, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.78817
    ,"Long":106.599548
    ,"Polyline":"[106.60154724,10.77481747] ; [106.59776306,10.78680992] ; [106.59791565,10.78707409] ; [106.59833527,10.78743744] ; [106.59954834,10.78816986]"
    ,"Distance":"1648"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1742"
    ,"Station_Code":"QBT 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cầu Kinh mới"
    ,"Station_Address":"753-755, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.791951
    ,"Long":106.605995
    ,"Polyline":"[106.59954834,10.78816986] ; [106.60599518,10.79195118]"
    ,"Distance":"821"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1741"
    ,"Station_Code":"QBT 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ủy ban phường Bình Hưng Hòa"
    ,"Station_Address":"Ủy ban phường Bình Hưng Hòa, đường Tân Kỳ Tân Quý, Quận Bình Tân"
    ,"Lat":10.794422
    ,"Long":106.6101
    ,"Polyline":"[106.60599518,10.79195118] ; [106.61009979,10.79442215]"
    ,"Distance":"526"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1965"
    ,"Station_Code":"QBT 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Nghĩa trang Bình Hưng Hòa"
    ,"Station_Address":"Đối diện văn phòng nghĩa trang, đường Tân Kỳ Tân Quý,  Quận Bình Tân"
    ,"Lat":10.795908
    ,"Long":106.612541
    ,"Polyline":"[106.61009979,10.79442215] ; [106.61014557,10.79450893] ; [106.61254120,10.79590797]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1967"
    ,"Station_Code":"QTP 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trạm Bình Long"
    ,"Station_Address":"595-597, đường Tân Kỳ Tân Quý, Quận Tân Ph ú"
    ,"Lat":10.797259
    ,"Long":106.614601
    ,"Polyline":"[106.61254120,10.79590797] ; [106.61460114,10.79725933]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1970"
    ,"Station_Code":"QTP 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Tiểu Học Tân Quý"
    ,"Station_Address":"545, đường Tân K ỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798479
    ,"Long":106.616829
    ,"Polyline":"[106.61460114,10.79725933] ; [106.61598206,10.79803944] ; [106.61682892,10.79847908]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1973"
    ,"Station_Code":"QTP 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Tân Quý"
    ,"Station_Address":"457-459, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799005
    ,"Long":106.618256
    ,"Polyline":"[106.61682892,10.79847908] ; [106.61825562,10.79900455]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1969"
    ,"Station_Code":"QTP 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Siêu thị Aeon"
    ,"Station_Address":"Đối diện siêu thị Aeon, đường Bờ Bao tân Thắng, Quận Tân Phú"
    ,"Lat":10.801159
    ,"Long":106.618538
    ,"Polyline":"[106.61825562,10.79900455] ; [106.61837769,10.79909325] ; [106.61818695,10.80072212] ; [106.61808014,10.80090618] ; [106.61831665,10.80112743] ; [106.61853790,10.80115891]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1972"
    ,"Station_Code":"QTP 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Sơn Kỳ"
    ,"Station_Address":"Chợ Sơn kỳ, đường Bờ Bao t ân Thắng, Quận Tân Phú"
    ,"Lat":10.805882
    ,"Long":106.621895
    ,"Polyline":"[106.61853790,10.80115891] ; [106.61853790,10.80115891] ; [106.61874390,10.80133343] ; [106.61937714,10.80135918] ; [106.62023926,10.80145454] ; [106.62144470,10.80257130] ; [106.62244415,10.80353546] ; [106.62242889,10.80377769] ; [106.62213135,10.80492687] ; [106.62189484,10.80588245] ; [106.62189484,10.80588245]"
    ,"Distance":"797"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1974"
    ,"Station_Code":"QTP 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm Bờ Bao Tân Thắng"
    ,"Station_Address":"271, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.80731
    ,"Long":106.622368
    ,"Polyline":"[106.62189484,10.80588245] ; [106.62177277,10.80616474] ; [106.62174225,10.80721378] ; [106.62176514,10.80745125] ; [106.62236786,10.80731010]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1975"
    ,"Station_Code":"QTP 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"Đối diện 220, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806767
    ,"Long":106.624886
    ,"Polyline":"[106.62236786,10.80731010.06.62488556]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2604"
    ,"Station_Code":"QTP 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Lê Trọng Tấn"
    ,"Station_Address":"Kế 16, đường Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.807407
    ,"Long":106.627289
    ,"Polyline":"[106.62488556,10.80676746] ; [106.62741852,10.80622864] ; [106.62728882,10.80740738]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"2599"
    ,"Station_Code":"QTP 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"TT vh Tân Phú"
    ,"Station_Address":"72, đường  Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.810604
    ,"Long":106.627022
    ,"Polyline":"[106.62728882,10.80740738] ; [106.62702179,10.81060410]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"38"
    ,"Station_Id":"1979"
    ,"Station_Code":"BX49"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm Điều hành  Tân Phú (0,55ha)"
    ,"Station_Address":"Bến xe Tân Ph ú, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808563
    ,"Long":106.634095
    ,"Polyline":"[106.62702179,10.81060410.06.62696838] ; [10.81136608,106.62738037] ; [10.81159210.06.62841797,10.81196690] ; [106.63287354,10.81265163] ; [106.63409424,10.80856323]"
    ,"Distance":"1225"
  }]