export const Route48 =[

  {
     "Route_Id":"48"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"171"
    ,"Station_Code":"Q12 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"601, đường Trường Chinh, Quận 12"
    ,"Lat":10.841209
    ,"Long":106.615925
    ,"Polyline":"[106.61337280,10.84373760] ; [106.61334229,10.84383774] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61504364,10.84255981] ; [106.61511993,10.84243011] ; [106.61530304,10.84235001] ; [106.61535645,10.84234047] ; [106.61546326,10.84218979] ; [106.61605835,10.84127045] ; [106.61599731,10.84123516]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"167"
    ,"Station_Code":"Q12 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"487, đường Trường Chinh, Quận 12"
    ,"Lat":10.837863
    ,"Long":106.618044
    ,"Polyline":"[106.61605835,10.84127045] ; [106.61820221,10.83794975]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"172"
    ,"Station_Code":"Q12 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Lạc  Quang"
    ,"Station_Address":"257, đường Trường  Chinh, Quận 12"
    ,"Lat":10.834623
    ,"Long":106.620163
    ,"Polyline":"[106.61820221,10.83794975] ; [106.62029266,10.83471012]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"168"
    ,"Station_Code":"Q12 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"Chùa Vĩnh Phước, đường Trường Chinh , Quận 12"
    ,"Lat":10.831836
    ,"Long":106.621928
    ,"Polyline":"[106.62029266,10.83471012] ; [106.62207794,10.83191967]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"170"
    ,"Station_Code":"Q12 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"113, đường Trường Chinh, Quận 12"
    ,"Lat":10.82898
    ,"Long":106.623768
    ,"Polyline":"[106.62207794,10.83191967] ; [106.62387848,10.82913017]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đư ờng Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62387848,10.82913017] ; [106.62487793,10.82758999] ; [106.62512207,10.82730007] ; [106.62560272,10.82676029] ; [106.62599182,10.82637978]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trư ờng Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62599182,10.82637978] ; [106.62699890,10.82542038] ; [106.62803650,10.82446957] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"664"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm KCN Tân Bình"
    ,"Station_Address":"881, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63089752,10.81947041]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chế Lan  Viên"
    ,"Station_Address":"28/7B, đường Trường  Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"597"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2292"
    ,"Station_Code":"QTP 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm Nhà Hàng Thượng Uyển"
    ,"Station_Address":"1/1, đường Trường Chinh, Qu ận Tân Phú"
    ,"Lat":10.806212
    ,"Long":106.634773
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63448334,10.80760002] ; [106.63481903,10.80665016] ; [106.63497925,10.80636978]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2291"
    ,"Station_Code":"QTP 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"33/24 (659-661 ), đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.8048
    ,"Long":106.635269
    ,"Polyline":"[106.63500977,10.80628967] ; [106.63530731,10.80535984] ; [106.63545990,10.80486012]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2294"
    ,"Station_Code":"QTP 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm Bà  Quẹo"
    ,"Station_Address":"593A, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.80215
    ,"Long":106.63633
    ,"Polyline":"[106.63545990,10.80486012] ; [106.63601685,10.80313015] ; [106.63610840,10.80288029] ; [106.63636780,10.80230999] ; [106.63642883,10.80220985]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2392"
    ,"Station_Code":"QTP 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trạm Ngã ba Bà Quẹo"
    ,"Station_Address":"971, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.800893
    ,"Long":106.63678
    ,"Polyline":"[106.63632965,10.80214977] ; [106.63642883,10.80220985] ; [106.63665771,10.80179691] ; [106.63670349,10.80161953] ; [106.63681793,10.80111980] ; [106.63687134,10.80091953] ; [106.63677979,10.80089283]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2395"
    ,"Station_Code":"QTP 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trạm chợ Võ Thành Trang"
    ,"Station_Address":"885-887, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.798211
    ,"Long":106.637497
    ,"Polyline":"[106.63687134,10.80091953] ; [106.63760376,10.79823971]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2394"
    ,"Station_Code":"QTP 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trạm Lũy Bán Bích"
    ,"Station_Address":"825, đường Âu  Cơ, Quận Tân Phú"
    ,"Lat":10.794283
    ,"Long":106.638618
    ,"Polyline":"[106.63760376,10.79823971] ; [106.63825989,10.79592991] ; [106.63829041,10.79561996] ; [106.63841248,10.79545021] ; [106.63874817,10.79432011]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2396"
    ,"Station_Code":"QTP 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nguyễn Hồng Đào"
    ,"Station_Address":"Đối diện 794 , đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.790561
    ,"Long":106.639969
    ,"Polyline":"[106.63874817,10.79432011] ; [106.63928223,10.79267979] ; [106.64002228,10.79057980]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2299"
    ,"Station_Code":"QTP 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trạm Ngã 4 Thoại Ngọc Hầu"
    ,"Station_Address":"647, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.787243
    ,"Long":106.640915
    ,"Polyline":"[106.64002228,10.79057980] ; [106.64080811,10.78824043] ; [106.64095306,10.78775024] ; [106.64109802,10.78730965]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2300"
    ,"Station_Code":"QTP 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Trạm Nh à Hàng Bạch Kim"
    ,"Station_Address":"577 (1004-1008A), đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.784081
    ,"Long":106.642113
    ,"Polyline":"[106.64109802,10.78730965] ; [106.64199066,10.78509045] ; [106.64231873,10.78413963]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2397"
    ,"Station_Code":"QTP 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bông Bạch Tuyết"
    ,"Station_Address":"523, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.780623
    ,"Long":106.6437
    ,"Polyline":"[106.64232635,10.78411007] ; [106.64292145,10.78227997] ; [106.64318085,10.78166962] ; [106.64334106,10.78137970] ; [106.64380646,10.78069019]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2399"
    ,"Station_Code":"QTP 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm Chợ Trần Văn Quang"
    ,"Station_Address":"425, đường Âu  Cơ, Quận Tân Phú"
    ,"Lat":10.778094
    ,"Long":106.645332
    ,"Polyline":"[106.64380646,10.78069019] ; [106.64488220,10.77910995] ; [106.64544678,10.77830982] ; [106.64550781,10.77822018]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2398"
    ,"Station_Code":"QTP 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trạm Nhà Thiếu Nhi Q.TB"
    ,"Station_Address":"309, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.775459
    ,"Long":106.64724
    ,"Polyline":"[106.64550781,10.77822018] ; [106.64624786,10.77717018] ; [106.64662170,10.77667999] ; [106.64694977,10.77618980] ; [106.64737701,10.77565002]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2401"
    ,"Station_Code":"Q11 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Phạm Ngọc Thạch"
    ,"Station_Address":"185-189, đường Âu Cơ, Quận 11"
    ,"Lat":10.77333
    ,"Long":106.648863
    ,"Polyline":"[106.64723969,10.77545929] ; [106.64742279,10.77558994] ; [106.64803314,10.77474022] ; [106.64888000,10.77350998] ; [106.64887238,10.77350044] ; [106.64886475,10.77332973]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2400"
    ,"Station_Code":"Q11 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Tân Phú"
    ,"Station_Address":"105, đường  Âu Cơ, Quận 11"
    ,"Lat":10.770953
    ,"Long":106.650436
    ,"Polyline":"[106.64886475,10.77332973] ; [106.65043640,10.77095318]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2404"
    ,"Station_Code":"Q11 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Bình Thới"
    ,"Station_Address":"27P , đường Âu Cơ, Quận 11"
    ,"Lat":10.769483
    ,"Long":106.651524
    ,"Polyline":"[106.65043640,10.77095318] ; [106.65050507,10.77097988] ; [106.65160370,10.76951981] ; [106.65152740,10.76948261]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2402"
    ,"Station_Code":"Q11 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường Đua Phú Thọ"
    ,"Station_Address":"407, đường L ê Đại Hành, Quận 11"
    ,"Lat":10.767281
    ,"Long":106.653358
    ,"Polyline":"[106.65160370,10.76951981] ; [106.65190125,10.76912022] ; [106.65189362,10.76910019] ; [106.65186310,10.76904011] ; [106.65186310,10.76896954] ; [106.65190125,10.76887989] ; [106.65196228,10.76883984] ; [106.65206146,10.76881981] ; [106.65216064,10.76879025] ; [106.65225220,10.76873016] ; [106.65235901,10.76871014] ; [106.65242767,10.76873016] ; [106.65264130,10.76852989] ; [106.65289307,10.76813984] ; [106.65337372,10.76733017]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2406"
    ,"Station_Code":"Q11 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Parkson"
    ,"Station_Address":"321, đường Lê Đại Hành, Quận 11"
    ,"Lat":10.765484
    ,"Long":106.654617
    ,"Polyline":"[106.65338898,10.76729965] ; [106.65466309,10.76550961]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2403"
    ,"Station_Code":"Q11 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Đường 3/2"
    ,"Station_Address":"157, đường Lê Đại Hành, Quận 11"
    ,"Lat":10.763117
    ,"Long":106.656319
    ,"Polyline":"[106.65466309,10.76550961] ; [106.65634155,10.76313019]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"155"
    ,"Station_Code":"Q11 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trung t âm chăm sóc sức khỏe sinh sản"
    ,"Station_Address":"957 , đường Đường 3/2, Quận 11"
    ,"Lat":10.76245
    ,"Long":106.657539
    ,"Polyline":"[106.65631866,10.76311684] ; [106.65634155,10.76313019] ; [106.65698242,10.76220989] ; [106.65724945,10.76227379] ; [106.65751648,10.76249027] ; [106.65753937,10.76245022]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"156"
    ,"Station_Code":"Q10 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"781, đường Đường 3/2, Quận 10"
    ,"Lat":10.76434
    ,"Long":106.661078
    ,"Polyline":"[106.65751648,10.76249027] ; [106.65869141,10.76311970] ; [106.66000366,10.76381016] ; [106.66017914,10.76393032] ; [106.66055298,10.76412964]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"157"
    ,"Station_Code":"Q10 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Nhà thờ tin lành Nguyễn Tri Phương"
    ,"Station_Address":"635, đường Đường 3/2, Quận 10"
    ,"Lat":10.766232
    ,"Long":106.664627
    ,"Polyline":"[106.66057587,10.76408386] ; [106.66462708,10.76623154]"
    ,"Distance":"504"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1397"
    ,"Station_Code":"Q10 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bệnh vi ện nhi đồng 1"
    ,"Station_Address":"359, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767765
    ,"Long":106.67038
    ,"Polyline":"[106.66462708,10.76623154] ; [106.66462708,10.76623154] ; [106.66780090,10.76791286] ; [106.66902161,10.76774120] ; [106.66902161,10.76774120]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1398"
    ,"Station_Code":"Q10 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ P10, Q10"
    ,"Station_Address":"183, đường Lý Thái Tổ, Qu ận 10"
    ,"Lat":10.767623
    ,"Long":106.673357
    ,"Polyline":"[106.66903687,10.76793003] ; [106.67002869,10.76786995] ; [106.67153931,10.76782036] ; [106.67336273,10.76772022]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1404"
    ,"Station_Code":"Q10 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Hồ Thị Kỳ"
    ,"Station_Address":"93 (27B), đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767207
    ,"Long":106.67554
    ,"Polyline":"[106.67336273,10.76772022] ; [106.67415619,10.76768017] ; [106.67417145,10.76764965] ; [106.67417908,10.76760006] ; [106.67423248,10.76751995] ; [106.67429352,10.76747036] ; [106.67434692,10.76745033] ; [106.67447662,10.76747036] ; [106.67456055,10.76753044] ; [106.67459106,10.76756954] ; [106.67460632,10.76758957] ; [106.67460632,10.76760960] ; [106.67636871,10.76708984] ; [106.67707062,10.76686954]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1402"
    ,"Station_Code":"Q10 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà Khách Chính Phủ"
    ,"Station_Address":"Đối diện 180 (1B), đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.766522
    ,"Long":106.677799
    ,"Polyline":"[106.67707062,10.76686954] ; [106.67859650,10.76640034]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1406"
    ,"Station_Code":"Q10 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã 6 Cộng Hòa"
    ,"Station_Address":"Đối diện 30-32, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.76571
    ,"Long":106.680449
    ,"Polyline":"[106.67857361,10.76630592] ; [106.68026733,10.76574707]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2405"
    ,"Station_Code":"Q1 143"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà Sách Minh Khai"
    ,"Station_Address":"59-61, đường Phạm Viết Chánh , Quận 1"
    ,"Lat":10.76602
    ,"Long":106.6828
    ,"Polyline":"[106.68026733,10.76574707] ; [106.68125916,10.76549435] ; [106.68136597,10.76530933] ; [106.68146515,10.76521492] ; [106.68153381,10.76518822] ; [106.68170166,10.76520443] ; [106.68180084,10.76528835] ; [106.68184662,10.76539421] ; [106.68182373,10.76550484] ; [106.68196869,10.76568413] ; [106.68200684,10.76577854] ; [106.68271637,10.76608944] ; [106.68280029,10.76601982]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2407"
    ,"Station_Code":"Q1 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bệnh viện Truyền máu huyết học"
    ,"Station_Address":"19-21, đường Phạm Viết Chánh, Quận 1"
    ,"Lat":10.767591
    ,"Long":106.685135
    ,"Polyline":"[106.68274689,10.76609039] ; [106.68508911,10.76766014]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"164"
    ,"Station_Code":"Q1 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Thái Bình"
    ,"Station_Address":"A43 , đường Cống Quỳnh, Quận 1"
    ,"Lat":10.766863
    ,"Long":106.687653
    ,"Polyline":"[106.68513489,10.76759148] ; [106.68544769,10.76790237] ; [106.68757629,10.76695919] ; [106.68765259,10.76686287]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.68765259,10.76686287] ; [106.68800354,10.76677990] ; [106.68818665,10.76673222] ; [106.68824005,10.76661682] ; [106.68836212,10.76660633] ; [106.68843079,10.76670647] ; [106.68840027,10.76680088] ; [106.68835449,10.76689529] ; [106.68852997,10.76730156] ; [106.68878937,10.76771832] ; [106.68899536,10.76800728] ; [106.68925476,10.76813412] ; [106.68975830,10.76835537] ; [106.68997192,10.76842403] ; [106.69023132,10.76795483] ; [106.69044495,10.76758575] ; [106.69002533,10.76739597] ; [106.68980408,10.76730156] ; [106.68958282,10.76776028] ; [106.68936157,10.76767635]"
    ,"Distance":"649"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"86"
    ,"Station_Code":"Q1 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Nhà thờ Huyện Sỹ"
    ,"Station_Address":"206Bis, đường Nguyễn Trãi, Qu ận 1"
    ,"Lat":10.767692
    ,"Long":106.688591
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68923187,10.76812935] ; [106.68917847,10.76817608] ; [106.68892670,10.76807117] ; [106.68875885,10.76784992] ; [106.68869019,10.76774979] ; [106.68859100,10.76769161]"
    ,"Distance":"147"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"88"
    ,"Station_Code":"Q1 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Chợ Thái Bình"
    ,"Station_Address":"244, đường Cống Quỳnh, Quận 1"
    ,"Lat":10.766943
    ,"Long":106.687793
    ,"Polyline":"[106.68859100,10.76769161] ; [106.68838501,10.76721764] ; [106.68827820,10.76699543] ; [106.68823242,10.76689053] ; [106.68804169,10.76682758] ; [106.68778992,10.76694298]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"89"
    ,"Station_Code":"Q3 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Hội Chữ thập đỏ thành phố"
    ,"Station_Address":"464 - 466, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.767691
    ,"Long":106.683693
    ,"Polyline":"[106.68779755,10.76690960] ; [106.68627167,10.76760960] ; [106.68547058,10.76791000] ; [106.68466949,10.76828957] ; [106.68435669,10.76828003] ; [106.68421173,10.76813030] ; [106.68374634,10.76764011]"
    ,"Distance":"519"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"90"
    ,"Station_Code":"Q3 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà sách Minh Khai"
    ,"Station_Address":"488, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.766416
    ,"Long":106.682428
    ,"Polyline":"[106.68369293,10.76769066] ; [106.68244934,10.76632404]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1409"
    ,"Station_Code":"Q3 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà hàng Sinh Đôi"
    ,"Station_Address":"120, đường Lý Thái Tổ, Quận 3"
    ,"Lat":10.765963
    ,"Long":106.680363
    ,"Polyline":"[106.68244934,10.76632404] ; [106.68183899,10.76573658] ; [106.68163300,10.76566982] ; [106.68155670,10.76564980] ; [106.68148041,10.76560020] ; [106.68102264,10.76571560] ; [106.68022156,10.76593685] ; [106.68010712,10.76596642]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1413"
    ,"Station_Code":"Q3 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"170, đường Lý Thái Tổ, Quận 3"
    ,"Lat":10.76668
    ,"Long":106.678099
    ,"Polyline":"[106.68010712,10.76596642] ; [106.67829132,10.76652908]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1416"
    ,"Station_Code":"Q3 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hồ Thị Kỷ"
    ,"Station_Address":"306, đường L ý Thái Tổ, Quận 3"
    ,"Lat":10.767423
    ,"Long":106.675664
    ,"Polyline":"[106.67829132,10.76652908] ; [106.67582703,10.76730824]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1411"
    ,"Station_Code":"Q10 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Phường 10, Quận 10"
    ,"Station_Address":"430, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767865
    ,"Long":106.673051
    ,"Polyline":"[106.67582703,10.76730824] ; [106.67462158,10.76770020] ; [106.67459106,10.76778984] ; [106.67449188,10.76788044] ; [106.67439270,10.76790047] ; [106.67433929,10.76788998] ; [106.67426300,10.76784992] ; [106.67421722,10.76782036] ; [106.67417908,10.76776028] ; [106.67313385,10.76779747]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1412"
    ,"Station_Code":"Q10 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bện viện Nhi Đồng 1"
    ,"Station_Address":"Bệnh viện Nhi đồng 1, đường Lý Thái T ổ, Quận 10"
    ,"Lat":10.768029
    ,"Long":106.669739
    ,"Polyline":"[106.67313385,10.76779747] ; [106.67151642,10.76790714] ; [106.66973877,10.76802921]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"98"
    ,"Station_Code":"Q10 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"626-628, đường Đường 3/2, Quận 10"
    ,"Lat":10.764972
    ,"Long":106.661743
    ,"Polyline":"[106.66973877,10.76802921] ; [106.66973877,10.76802921] ; [106.66973877,10.76802921] ; [106.66789246,10.76815510.06.66174316] ; [10.76497173,106.66174316]"
    ,"Distance":"963"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"100"
    ,"Station_Code":"Q11 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà sách Phú Thọ"
    ,"Station_Address":"940 (6B), đường Đường 3/2, Quận 11"
    ,"Lat":10.763115
    ,"Long":106.658409
    ,"Polyline":"[106.66174316,10.76497173] ; [106.66174316,10.76497173] ; [106.66155243,10.76479340] ; [106.66086578,10.76443481] ; [106.66018677,10.76409721] ; [106.65999603,10.76394939] ; [106.65886688,10.76338100] ; [106.65840912,10.76311493] ; [106.65840912,10.76311493]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2410"
    ,"Station_Code":"Q11 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Parkson"
    ,"Station_Address":"Đối diện 195 (155), đường  Lê Đại Hành, Quận 11"
    ,"Lat":10.763328
    ,"Long":106.656303
    ,"Polyline":"[106.65840912,10.76311493] ; [106.65741730,10.76253986] ; [106.65715790,10.76257038] ; [106.65688324,10.76273251] ; [106.65634155,10.76334953] ; [106.65630341,10.76332760]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2413"
    ,"Station_Code":"Q11 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Tôn Thất Hiệp"
    ,"Station_Address":"Đối diện 281 (265 ), đường Lê Đại Hành, Quận 11"
    ,"Lat":10.765531
    ,"Long":106.6548
    ,"Polyline":"[106.65634155,10.76334953] ; [106.65535736,10.76474953] ; [106.65479279,10.76552010]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2412"
    ,"Station_Code":"Q11 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường Đua Phú Thọ"
    ,"Station_Address":"Đối diện 349, đường Lê Đại Hành, Quận 11"
    ,"Lat":10.767344
    ,"Long":106.653616
    ,"Polyline":"[106.65480042,10.76553059] ; [106.65479279,10.76552010.06.65374756] ; [10.76709557,106.65361786]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2415"
    ,"Station_Code":"Q11 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Siêu thị Coormark"
    ,"Station_Address":"2, đường Lê Đại Hành, Quận 11"
    ,"Lat":10.768466
    ,"Long":106.652902
    ,"Polyline":"[106.65361786,10.76734447] ; [106.65324402,10.76783371] ; [106.65290070,10.76846600]"
    ,"Distance":"148"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2414"
    ,"Station_Code":"QTB 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Vòng xoay Lê Đại Hành"
    ,"Station_Address":"52, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.769663
    ,"Long":106.651543
    ,"Polyline":"[106.65290070,10.76846600] ; [106.65278625,10.76859760] ; [106.65249634,10.76906204] ; [106.65235138,10.76908970] ; [106.65222168,10.76910019] ; [106.65197754,10.76914978] ; [106.65191650,10.76919365] ; [106.65154266,10.76966286]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2417"
    ,"Station_Code":"QTB 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Chợ Tân Phước"
    ,"Station_Address":"130, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.77181
    ,"Long":106.650063
    ,"Polyline":"[106.65154266,10.76966286] ; [106.65057373,10.77110672] ; [106.65006256,10.77180958]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2416"
    ,"Station_Code":"QTB 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã tư Lạc Long Quân"
    ,"Station_Address":"274 (260), đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.77401
    ,"Long":106.648605
    ,"Polyline":"[106.65006256,10.77180958] ; [106.64920044,10.77309895] ; [106.64860535,10.77400970]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2419"
    ,"Station_Code":"QTB 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ủy ban nhân dân Phường 10"
    ,"Station_Address":"290 (Ủy ban nh ân dân phường 10), đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.775586
    ,"Long":106.647543
    ,"Polyline":"[106.64860535,10.77400970] ; [106.64818573,10.77470589] ; [106.64774323,10.77526474] ; [106.64743805,10.77566242]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2418"
    ,"Station_Code":"QTB 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Trần  Văn Quang"
    ,"Station_Address":"402, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.777093
    ,"Long":106.646378
    ,"Polyline":"[106.64743805,10.77566242] ; [106.64677429,10.77656555] ; [106.64646149,10.77694035] ; [106.64637756,10.77709293]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2421"
    ,"Station_Code":"QTB 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty Bông Bạch Tuyết"
    ,"Station_Address":"548 (Công ty Bạch Tuyết), đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.780487
    ,"Long":106.644046
    ,"Polyline":"[106.64637756,10.77709293] ; [106.64485168,10.77932453]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2199"
    ,"Station_Code":"QTB 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh Viện Tân Phú"
    ,"Station_Address":"584-590, đường  Âu Cơ, Quận Tân Bình"
    ,"Lat":10.78299
    ,"Long":106.642785
    ,"Polyline":"[106.64485168,10.77932453] ; [106.64476776,10.77927017] ; [106.64386749,10.78069782] ; [106.64344025,10.78138256] ; [106.64290619,10.78274727]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2195"
    ,"Station_Code":"QTB 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã tư Thoại Ngọc Hầu"
    ,"Station_Address":"678, đường  Âu Cơ, Quận Tân Bình"
    ,"Lat":10.785272
    ,"Long":106.642052
    ,"Polyline":"[106.64290619,10.78274727] ; [106.64212799,10.78487682] ; [106.64205170,10.78527164]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2196"
    ,"Station_Code":"QTB 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Bàu Cát 9"
    ,"Station_Address":"722, đường Âu Cơ, Quận Tân  Bình"
    ,"Lat":10.78729
    ,"Long":106.641182
    ,"Polyline":"[106.64205170,10.78527164] ; [106.64130402,10.78706360] ; [106.64118195,10.78728962]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2420"
    ,"Station_Code":"QTB 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Bàu Cát"
    ,"Station_Address":"794, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.790254
    ,"Long":106.640167
    ,"Polyline":"[106.64118195,10.78728962] ; [106.64112091,10.78726959] ; [106.64082336,10.78845406] ; [106.64051819,10.78923416] ; [106.64027405,10.78997231] ; [106.64016724,10.79025364]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2423"
    ,"Station_Code":"QTB 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công ty Giấy Mai Lan"
    ,"Station_Address":"129 (Công ty Mai Lan), đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.793479
    ,"Long":106.639076
    ,"Polyline":"[106.64016724,10.79025364] ; [106.63907623,10.79347897]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2422"
    ,"Station_Code":"QTB 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm Ba Vân"
    ,"Station_Address":"928, đường Âu  Cơ, Quận Tân Bình"
    ,"Lat":10.796295
    ,"Long":106.638214
    ,"Polyline":"[106.63907623,10.79347897] ; [106.63841248,10.79545021] ; [106.63825989,10.79592991] ; [106.63816071,10.79627991] ; [106.63821411,10.79629517]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2425"
    ,"Station_Code":"QTB 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Võ Thành Trang"
    ,"Station_Address":"988-990, đư ờng Âu Cơ, Quận Tân Bình"
    ,"Lat":10.79878
    ,"Long":106.63752
    ,"Polyline":"[106.63821411,10.79629517] ; [106.63816071,10.79627991] ; [106.63751984,10.79878044]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2424"
    ,"Station_Code":"QTB 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã ba Bà Quẹo"
    ,"Station_Address":"1064, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.80068
    ,"Long":106.636986
    ,"Polyline":"[106.63751984,10.79878044] ; [106.63698578,10.80068016]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1302"
    ,"Station_Code":"QTB 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"638, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.804626
    ,"Long":106.635656
    ,"Polyline":"[106.63698578,10.80068016] ; [106.63694000,10.80066967] ; [106.63681793,10.80111980] ; [106.63670349,10.80161953] ; [106.63671875,10.80169964] ; [106.63672638,10.80177975] ; [106.63642883,10.80220985] ; [106.63610840,10.80288029] ; [106.63565826,10.80420017] ; [106.63553619,10.80459976] ; [106.63560486,10.80461597]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"2202"
    ,"Station_Code":"QTB 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.806202
    ,"Long":106.635184
    ,"Polyline":"[106.63560486,10.80461597] ; [106.63511658,10.80619907]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63511658,10.80619907] ; [106.63507080,10.80640221] ; [106.63497925,10.80676556] ; [106.63491821,10.80712414] ; [106.63486481,10.80760384] ; [106.63477325,10.80784607] ; [106.63467407,10.80803871]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B , đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63467407,10.80803871] ; [106.63456726,10.80841541] ; [106.63439941,10.80878925] ; [106.63424683,10.80929470] ; [106.63360596,10.81142902] ; [106.63349915,10.81169510]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Trường Chinh , Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63349915,10.81169510.06.63258362]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63258362,10.81463814] ; [106.63169098,10.81754112]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63169098,10.81754112] ; [106.63044739,10.82164383]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63044739,10.82164383] ; [106.62984467,10.82299995] ; [106.62889862,10.82407475] ; [106.62714386,10.82559204] ; [106.62597656,10.82664108]"
    ,"Distance":"752"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"273"
    ,"Station_Code":"Q12 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Siêu th ị Chợ Lớn"
    ,"Station_Address":"189/4, đường Trường Chinh, Quận 12"
    ,"Lat":10.828843
    ,"Long":106.624482
    ,"Polyline":"[106.62595367,10.82662010.06.62528229] ; [10.82740974,106.62447357] ; [10.82857037,106.62435913]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"274"
    ,"Station_Code":"Q12 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"258, đường Trường Chinh, Quận 12"
    ,"Lat":10.832547
    ,"Long":106.622116
    ,"Polyline":"[106.62437439,10.82875347] ; [106.62435913,10.82874012] ; [106.62198639,10.83245468]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"275"
    ,"Station_Code":"Q12 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chùa Lạc Quang"
    ,"Station_Address":"408, đường Trường Chinh, Quận 12"
    ,"Lat":10.83514
    ,"Long":106.620464
    ,"Polyline":"[106.62193298,10.83242035] ; [106.62024689,10.83504009]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"277"
    ,"Station_Code":"Q12 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"640, đường Trường Chinh, Quận 12"
    ,"Lat":10.83819
    ,"Long":106.618495
    ,"Polyline":"[106.62024689,10.83504009] ; [106.61829376,10.83808041]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"276"
    ,"Station_Code":"Q12 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"774A, đường Trường Chinh, Quận 12"
    ,"Lat":10.841436
    ,"Long":106.616457
    ,"Polyline":"[106.61833191,10.83811092] ; [106.61625671,10.84133816]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Qu ốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61621094,10.84130955] ; [106.61564636,10.84220028] ; [106.61560059,10.84230995] ; [106.61559296,10.84243965] ; [106.61566162,10.84257984] ; [106.61566162,10.84274006] ; [106.61560822,10.84286022] ; [106.61556244,10.84292984] ; [106.61546326,10.84298992] ; [106.61534119,10.84300995] ; [106.61528015,10.84300041] ; [106.61518097,10.84311962] ; [106.61475372,10.84370995] ; [106.61396027,10.84490967]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"48"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61401367,10.84493923] ; [106.61396027,10.84490967] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61237335,10.84720993] ; [106.61244202,10.84710026] ; [106.61327362,10.84582043] ; [106.61369324,10.84515953] ; [106.61405182,10.84459972] ; [106.61413574,10.84444904] ; [106.61367035,10.84412766] ; [106.61328125,10.84385395] ; [106.61337280,10.84373760]"
    ,"Distance":"819"
  }]