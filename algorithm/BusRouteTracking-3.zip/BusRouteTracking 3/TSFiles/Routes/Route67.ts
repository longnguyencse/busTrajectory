export const Route67 =[

  {
     "Route_Id":"67"
    ,"Station_Id":"2989"
    ,"Station_Code":"BX 22"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Mễ Cốc"
    ,"Station_Address":"ĐẦU BẾN BẾN MỄ CỐC, đường Lưu Hữu Phước, Qu ận 8"
    ,"Lat":10.712879
    ,"Long":106.626114
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2991"
    ,"Station_Code":"Q8 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Cầu Rạch Cát"
    ,"Station_Address":"Đối diện 320, đường Lưu Hữu Phước, Quận 8"
    ,"Lat":10.716231
    ,"Long":106.630341
    ,"Polyline":"[106.62615204,10.71300983] ; [106.62635040,10.71298981] ; [106.62650299,10.71304989] ; [106.62764740,10.71380043] ; [106.62821960,10.71426010.06.62879944] ; [10.71479988,106.62960815] ; [10.71562958,106.62988281] ; [10.71594048,106.63020325]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2992"
    ,"Station_Code":"Q8 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"KTX trường Công nghệ thực phẩm"
    ,"Station_Address":"Đ/d Trường TH CNTP , đường Lưu Hữu Phước, Quận 8"
    ,"Lat":10.719056
    ,"Long":106.632019
    ,"Polyline":"[106.63020325,10.71632957] ; [106.63088226,10.71724987] ; [106.63120270,10.71780968] ; [106.63146210,10.71831989] ; [106.63185120,10.71914005]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2993"
    ,"Station_Code":"Q8 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Số 3"
    ,"Station_Address":"Đối diện 19, đường Bình Đức, Quận 8"
    ,"Lat":10.724591
    ,"Long":106.63123
    ,"Polyline":"[106.63192749,10.71910286] ; [106.63261414,10.72038460] ; [106.63311768,10.72134876] ; [106.63350677,10.72243977] ; [106.63372803,10.72290421] ; [106.63383484,10.72310925] ; [106.63373566,10.72327805] ; [106.63246918,10.72385788] ; [106.63182831,10.72416878] ; [106.63162994,10.72425842] ; [106.63146210,10.72442245] ; [106.63117981,10.72452259]"
    ,"Distance":"829"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2996"
    ,"Station_Code":"Q8 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nguyễn S ĩ Cố"
    ,"Station_Address":"Đối diện 261B, đường Lưu H ữu Phước, Quận 8"
    ,"Lat":10.726077
    ,"Long":106.635361
    ,"Polyline":"[106.63117981,10.72452259] ; [106.63117981,10.72452259] ; [106.63086700,10.72472763] ; [106.63061523,10.72463799] ; [106.63031006,10.72396374] ; [106.63016510,10.72362041] ; [106.63000488,10.72319412] ; [106.62985992,10.72299385] ; [106.62981415,10.72280884] ; [106.62967682,10.72260857] ; [106.62977600,10.72248268] ; [106.63050842,10.72412682] ; [106.63071442,10.72460651] ; [106.63117981,10.72567081] ; [106.63182068,10.72689438] ; [106.63211823,10.72746277] ; [106.63197327,10.72735214] ; [106.63162994,10.72674084] ; [106.63130188,10.72605610.06.63103485] ; [10.72561359,106.63116455] ; [10.72535992,106.63130951] ; [10.72514439,106.63161469] ; [10.72505951,106.63189697] ; [10.72503376,106.63291931] ; [10.72460079,106.63385773] ; [10.72416878,106.63426971] ; [10.72401047,106.63480377] ; [10.72509670,106.63529205] ; [10.72617626,106.63529205]"
    ,"Distance":"1863"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2994"
    ,"Station_Code":"Q8 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Phường 15"
    ,"Station_Address":"Đối diện 213, đường Lưu Hữu Phước, Quận 8"
    ,"Lat":10.729872
    ,"Long":106.637458
    ,"Polyline":"[106.63529205,10.72618008] ; [106.63626862,10.72823048] ; [106.63693237,10.72931957] ; [106.63739777,10.72996044]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2995"
    ,"Station_Code":"Q8 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"UBND Phư ờng 15"
    ,"Station_Address":"Đối diện 183, đường Lưu Hữu Phước, Quận 8"
    ,"Lat":10.733103
    ,"Long":106.640596
    ,"Polyline":"[106.63739777,10.72996044] ; [106.63820648,10.73101044] ; [106.63864899,10.73157024] ; [106.63896942,10.73192024] ; [106.63951874,10.73235035] ; [106.63995361,10.73270035] ; [106.64025116,10.73293018] ; [106.64048004,10.73309040]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2997"
    ,"Station_Code":"Q8 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Lương Văn Can"
    ,"Station_Address":"35, đường Lư ơng Văn Can, Quận 8"
    ,"Lat":10.735058
    ,"Long":106.639845
    ,"Polyline":"[106.64048004,10.73309040] ; [106.64079285,10.73334026] ; [106.64031982,10.73402977] ; [106.63977051,10.73491001] ; [106.63961792,10.73515034]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2998"
    ,"Station_Code":"Q8 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"cầu Kinh Ngang Số 2"
    ,"Station_Address":"Cạnh cây xanh 155, đường Bến Bình Đông, Quận 8"
    ,"Lat":10.739833
    ,"Long":106.64506
    ,"Polyline":"[106.63961792,10.73515034] ; [106.63899994,10.73620987] ; [106.63926697,10.73639011] ; [106.63986206,10.73674965] ; [106.64050293,10.73717022] ; [106.64082336,10.73738003] ; [106.64173126,10.73793030] ; [106.64243317,10.73836040] ; [106.64285278,10.73861980] ; [106.64325714,10.73890018] ; [106.64353180,10.73902988] ; [106.64418030,10.73945999] ; [106.64501190,10.73995972]"
    ,"Distance":"915"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2999"
    ,"Station_Code":"Q8 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Kho 289"
    ,"Station_Address":"289, đường Bến Bình Đông, Quận 8"
    ,"Lat":10.74129
    ,"Long":106.647415
    ,"Polyline":"[106.64501190,10.73995972] ; [106.64659119,10.74088955] ; [106.64739227,10.74133968]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3000"
    ,"Station_Code":"Q8 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Cầu số 1"
    ,"Station_Address":"Cạnh cây xanh 107, đường Bến Bình Đông, Qu ận 8"
    ,"Lat":10.743056
    ,"Long":106.650406
    ,"Polyline":"[106.64739227,10.74133968] ; [106.64939880,10.74250984] ; [106.64978790,10.74277973] ; [106.65038300,10.74310970]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3002"
    ,"Station_Code":"Q8 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Coop Mart Tuy Lý Vương"
    ,"Station_Address":"99-101, đường Tuy Lúy Vương, Quận 8"
    ,"Lat":10.743918
    ,"Long":106.655177
    ,"Polyline":"[106.65040588,10.74305630] ; [106.65150452,10.74379158] ; [106.65270996,10.74453449] ; [106.65312195,10.74382782] ; [106.65350342,10.74314785] ; [106.65410614,10.74349594] ; [106.65457916,10.74371719] ; [106.65500641,10.74387455]"
    ,"Distance":"662"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"542"
    ,"Station_Code":"Q8 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Tùng Thi ện Vương"
    ,"Station_Address":"487, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.744513
    ,"Long":106.656802
    ,"Polyline":"[106.65498352,10.74392033] ; [106.65557861,10.74423027] ; [106.65596008,10.74437046] ; [106.65602112,10.74423981] ; [106.65647888,10.74448013]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"501"
    ,"Station_Code":"Q8 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Xóm Củi"
    ,"Station_Address":"337, đường Tùng Thiện Vương , Quận 8"
    ,"Lat":10.746073
    ,"Long":106.659763
    ,"Polyline":"[106.65647888,10.74448013] ; [106.65854645,10.74563980] ; [106.65904999,10.74584961] ; [106.65960693,10.74612045]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3001"
    ,"Station_Code":"Q8 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Dã Tượng"
    ,"Station_Address":"797, đường Hưng Phú, Quận  8"
    ,"Lat":10.74542
    ,"Long":106.665273
    ,"Polyline":"[106.65960693,10.74612045] ; [106.66024780,10.74643993] ; [106.66036224,10.74650955] ; [106.66045380,10.74662971] ; [106.66063690,10.74654007] ; [106.66074371,10.74631023] ; [106.66094971,10.74594975] ; [106.66114044,10.74577045] ; [106.66137695,10.74565029] ; [106.66211700,10.74536991] ; [106.66255951,10.74514008] ; [106.66300964,10.74520016] ; [106.66393280,10.74538040] ; [106.66435242,10.74545002] ; [106.66500854,10.74553967]"
    ,"Distance":"677"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3004"
    ,"Station_Code":"Q8 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Lưu Quý Kỳ"
    ,"Station_Address":"723-725 , đường Hưng Phú, Quận 8"
    ,"Lat":10.745894
    ,"Long":106.667815
    ,"Polyline":"[106.66500854,10.74553967] ; [106.66638947,10.74575043] ; [106.66710663,10.74586964] ; [106.66780853,10.74600983]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3003"
    ,"Station_Code":"Q8 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Phạm Hùng"
    ,"Station_Address":"627/1N, đường Hưng Phú, Quận 8"
    ,"Lat":10.746179
    ,"Long":106.669393
    ,"Polyline":"[106.66780853,10.74600983] ; [106.66947937,10.74635029]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3005"
    ,"Station_Code":"Q8 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường TH Hưng Phú A"
    ,"Station_Address":"545, đường Hưng Phú, Quận 8"
    ,"Lat":10.746685
    ,"Long":106.671635
    ,"Polyline":"[106.66947937,10.74635029] ; [106.67086792,10.74666023]"
    ,"Distance":"155"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3006"
    ,"Station_Code":"Q8 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Lý Thánh Tông"
    ,"Station_Address":"435 , đường Hưng Phú, Quận 8"
    ,"Lat":10.746843
    ,"Long":106.672472
    ,"Polyline":"[106.67086792,10.74666023] ; [106.67198944,10.74687004]"
    ,"Distance":"124"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3008"
    ,"Station_Code":"Q8 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Lê Quang Kim"
    ,"Station_Address":"365, đường Hưng Phú, Quận 8"
    ,"Lat":10.747907
    ,"Long":106.67531
    ,"Polyline":"[106.67198944,10.74687004] ; [106.67343140,10.74713039] ; [106.67420197,10.74728966] ; [106.67443085,10.74738979] ; [106.67501831,10.74775982]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3007"
    ,"Station_Code":"Q8 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Viện Y tế Cộng đồng"
    ,"Station_Address":"Đối  diện 260, đường Hưng Phú, Quận 8"
    ,"Lat":10.749678
    ,"Long":106.678265
    ,"Polyline":"[106.67501831,10.74775982] ; [106.67556000,10.74816036] ; [106.67579651,10.74835014] ; [106.67677307,10.74909973] ; [106.67751312,10.74956036] ; [106.67807770,10.74983978]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3010"
    ,"Station_Code":"Q8 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Công an  Phường 8"
    ,"Station_Address":"105, đường Hưng Phú, Quận 8"
    ,"Lat":10.750711
    ,"Long":106.682439
    ,"Polyline":"[106.67807770,10.74983978] ; [106.67836761,10.74993992] ; [106.67900848,10.75012016] ; [106.67993164,10.75037003] ; [106.68038940,10.75049973] ; [106.68054962,10.75053978] ; [106.68161011,10.75069046]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1438"
    ,"Station_Code":"Q8 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Công viên Ph ường 2"
    ,"Station_Address":"231-233, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.749104
    ,"Long":106.683533
    ,"Polyline":"[106.68161011,10.75069046] ; [106.68361664,10.75095367] ; [106.68428040,10.74975204] ; [106.68482208,10.74869823] ; [106.68406677,10.74825001] ; [106.68366241,10.74834442] ; [106.68325043,10.74903011] ; [106.68322754,10.74909592] ; [106.68382263,10.74938965]"
    ,"Distance":"816"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3009"
    ,"Station_Code":"Q5 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chung cư 109 Nguyễn Biểu"
    ,"Station_Address":"64, đường Nguyễn Biểu, Quận 5"
    ,"Lat":10.755424
    ,"Long":106.683945
    ,"Polyline":"[106.68382263,10.74938965] ; [106.68432617,10.74965763] ; [106.68546295,10.75016308] ; [106.68578339,10.74924564] ; [106.68489838,10.74868774] ; [106.68367004,10.75091171] ; [106.68405914,10.75267220] ; [106.68428040,10.75379944] ; [106.68428040,10.75438976] ; [106.68389130,10.75539970]"
    ,"Distance":"1218"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3012"
    ,"Station_Code":"Q5 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường THCS Ba Đình"
    ,"Station_Address":"230, đường Nguyễn Biểu, Quận  5"
    ,"Lat":10.75819
    ,"Long":106.682927
    ,"Polyline":"[106.68389130,10.75539970] ; [106.68366241,10.75599957] ; [106.68316650,10.75737953] ; [106.68292236,10.75806046]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1052"
    ,"Station_Code":"Q1 150"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Báo An Ninh Thế Giới"
    ,"Station_Address":"371A , đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.759869
    ,"Long":106.685104
    ,"Polyline":"[106.68292236,10.75806046] ; [106.68260956,10.75891972] ; [106.68399048,10.75940037] ; [106.68469238,10.75969982] ; [106.68492889,10.75984001] ; [106.68501282,10.75990963] ; [106.68498230,10.75988960] ; [106.68508911,10.75983047]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1053"
    ,"Station_Code":"Q1 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà Khách Bộ Công An"
    ,"Station_Address":"333, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.762006
    ,"Long":106.686394
    ,"Polyline":"[106.68508911,10.75983047] ; [106.68498230,10.75988960] ; [106.68501282,10.75990963] ; [106.68515015,10.76006031] ; [106.68537903,10.76039982] ; [106.68631744,10.76204967]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1056"
    ,"Station_Code":"Q1 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chùa Lâm Tế"
    ,"Station_Address":"217, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.765754
    ,"Long":106.688004
    ,"Polyline":"[106.68631744,10.76204967] ; [106.68656158,10.76245022] ; [106.68662262,10.76261997] ; [106.68682098,10.76298046] ; [106.68701935,10.76336002] ; [106.68742371,10.76441002] ; [106.68791199,10.76578045]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68791199,10.76578045] ; [106.68814850,10.76644993] ; [106.68826294,10.76663971] ; [106.68823242,10.76667023] ; [106.68821716,10.76671028] ; [106.68824768,10.76675034] ; [106.68829346,10.76677036] ; [106.68830872,10.76677036] ; [106.68836212,10.76702023] ; [106.68849945,10.76739025] ; [106.68874359,10.76776028] ; [106.68895721,10.76799965] ; [106.68920898,10.76819992] ; [106.69026184,10.76860046]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Nguyễn Th ị Nghĩa"
    ,"Station_Address":"Đối diện 96, đư ờng Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76860046] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69445801,10.77024174] ; [106.69562531,10.77070045] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69756317,10.77144909] ; [106.69785309,10.77160168] ; [106.69808197,10.77148056] ; [106.69812775,10.77124882] ; [106.69790649,10.77092171] ; [106.69759369,10.77053165] ; [106.69739532,10.77031612] ; [106.69670105,10.77005291] ; [106.69595337,10.76980972]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1451"
    ,"Station_Code":"Q1 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trần Hưng  Đạo"
    ,"Station_Address":"197, đường Nguyễn Thái Học, Quận 1"
    ,"Lat":10.768461
    ,"Long":106.694984
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69467163,10.76920033] ; [106.69498444,10.76846123]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1344"
    ,"Station_Code":"Q1 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Cầu Ông  Lãnh"
    ,"Station_Address":"65G, đường Nguyễn Thái Học , Quận 1"
    ,"Lat":10.766576
    ,"Long":106.696129
    ,"Polyline":"[106.69498444,10.76846123] ; [106.69520569,10.76826572] ; [106.69538879,10.76801014] ; [106.69579315,10.76729012] ; [106.69596100,10.76704025] ; [106.69612885,10.76657581]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1196"
    ,"Station_Code":"Q4 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"K48-K50, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.760429
    ,"Long":106.699428
    ,"Polyline":"[106.69621277,10.76661968] ; [106.69669342,10.76585960] ; [106.69722748,10.76494980] ; [106.69761658,10.76428986] ; [106.69786835,10.76395988] ; [106.69799805,10.76381969] ; [106.69863892,10.76319027] ; [106.69959259,10.76220036] ; [106.69986725,10.76181984] ; [106.70011139,10.76146030] ; [106.70023346,10.76126003] ; [106.70041656,10.76099968] ; [106.69986725,10.76062012] ; [106.69950104,10.76035023]"
    ,"Distance":"926"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3011"
    ,"Station_Code":"Q4 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chùa Long Bửu"
    ,"Station_Address":"Hông Chùa Long Bửu, đường Khánh Hội, Quận 4"
    ,"Lat":10.760487
    ,"Long":106.697942
    ,"Polyline":"[106.69942474,10.76042938] ; [106.69892883,10.75992012] ; [106.69851685,10.75963974] ; [106.69822693,10.76000977] ; [106.69794464,10.76048660]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3014"
    ,"Station_Code":"Q4 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Trung t âm văn hóa Quận 4"
    ,"Station_Address":"Đối diện 226, đường Bến Vân Đồn, Quận  4"
    ,"Lat":10.760109
    ,"Long":106.69606
    ,"Polyline":"[106.69794464,10.76048660] ; [106.69756317,10.76093960] ; [106.69716644,10.76136971] ; [106.69622803,10.76018047] ; [106.69606018,10.76010895]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3013"
    ,"Station_Code":"Q4 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Nguyễn Khoái"
    ,"Station_Address":"Đối diện 310, đường Bến Vân Đồn, Quận 4"
    ,"Lat":10.758469
    ,"Long":106.693554
    ,"Polyline":"[106.69606018,10.76010895] ; [106.69583130,10.75979996] ; [106.69570160,10.75973988] ; [106.69518280,10.75940990] ; [106.69412994,10.75876045] ; [106.69355774,10.75846863]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3016"
    ,"Station_Code":"Q4 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm xăng Nguyễn Khoái"
    ,"Station_Address":"123, đường Nguy ễn Khoái, Quận 4"
    ,"Lat":10.757124
    ,"Long":106.693169
    ,"Polyline":"[106.69355774,10.75846863] ; [106.69281006,10.75794983] ; [106.69286346,10.75788021] ; [106.69316864,10.75712395]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3015"
    ,"Station_Code":"Q4 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trung tâm Giáo dục thường xuy ên Quận 4"
    ,"Station_Address":"9, đường Nguyễn Khoái, Quận 4"
    ,"Lat":10.75517
    ,"Long":106.694235
    ,"Polyline":"[106.69316864,10.75712395] ; [106.69356537,10.75653458] ; [106.69397736,10.75583363] ; [106.69423676,10.75516987]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3017"
    ,"Station_Code":"Q4 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Tôn Thất Thuyết"
    ,"Station_Address":"13, đường Nguyễn Khoái, Quận 4"
    ,"Lat":10.753584
    ,"Long":106.69511
    ,"Polyline":"[106.69423676,10.75516987] ; [106.69456482,10.75471687] ; [106.69488525,10.75414753] ; [106.69510651,10.75358391]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3018"
    ,"Station_Code":"Q4 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bệnh viện Phước an"
    ,"Station_Address":"Đối diện 197 , đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.752988
    ,"Long":106.700678
    ,"Polyline":"[106.69512177,10.75360966] ; [106.69542694,10.75304031] ; [106.69673157,10.75302982] ; [106.69918823,10.75302029] ; [106.70068359,10.75304985]"
    ,"Distance":"657"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2783"
    ,"Station_Code":"BX 12"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Cảng Quận 4"
    ,"Station_Address":"BÃI XE BUÝT CẦU MUỐI, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.752977
    ,"Long":106.701675
    ,"Polyline":"[106.70067596,10.75298786] ; [106.70117950,10.75305080] ; [106.70167542,10.75297737]"
    ,"Distance":"110"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2783"
    ,"Station_Code":"BX 12"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Cảng Quận 4"
    ,"Station_Address":"BÃI XE BUÝT CẦU MUỐI, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.752977
    ,"Long":106.701675
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3067"
    ,"Station_Code":"Q4 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bệnh viện Phước An"
    ,"Station_Address":"196, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.75312
    ,"Long":106.700297
    ,"Polyline":"[106.70166779,10.75306034] ; [106.70028687,10.75304031]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3070"
    ,"Station_Code":"Q4T021"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Chợ Tôn Thất Thuyết"
    ,"Station_Address":"8,  đường Nguyễn Khoái, Quận 4"
    ,"Lat":10.753548
    ,"Long":106.695229
    ,"Polyline":"[106.70028687,10.75304031] ; [106.69918823,10.75302029] ; [106.69673157,10.75302982] ; [106.69542694,10.75304031] ; [106.69516754,10.75352001]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3074"
    ,"Station_Code":"Q4 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trung tâm Giáo dục thường xuy ên Quận 4"
    ,"Station_Address":"66, đường Nguy ễn Khoái, Quận 4"
    ,"Lat":10.755054
    ,"Long":106.694428
    ,"Polyline":"[106.69516754,10.75352001] ; [106.69435883,10.75502014]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3072"
    ,"Station_Code":"Q4 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm xăng Nguyễn Khoái"
    ,"Station_Address":"144, đường Nguyễn Khoái, Quận 4"
    ,"Lat":10.757113
    ,"Long":106.693321
    ,"Polyline":"[106.69435883,10.75502014] ; [106.69326782,10.75708961]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3075"
    ,"Station_Code":"Q4 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nguyễn Khoái"
    ,"Station_Address":"310, đường Bến Vân Đồn, Qu ận 4"
    ,"Lat":10.758128
    ,"Long":106.693512
    ,"Polyline":"[106.69326782,10.75708961] ; [106.69286346,10.75788021] ; [106.69303131,10.75798988] ; [106.69344330,10.75823975]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3073"
    ,"Station_Code":"Q4 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trung tâm văn hóa Quận 4"
    ,"Station_Address":"236, đường Bến Vân Đồn, Quận 4"
    ,"Lat":10.759825
    ,"Long":106.69606
    ,"Polyline":"[106.69344330,10.75823975] ; [106.69526672,10.75936031] ; [106.69577789,10.75969982] ; [106.69596100,10.75986004] ; [106.69599915,10.75990009]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3077"
    ,"Station_Code":"Q4 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Chùa Long Bửu"
    ,"Station_Address":"C30 Cư xá Vĩnh Hội, đường Khánh Hội, Quận 4"
    ,"Lat":10.760477
    ,"Long":106.697797
    ,"Polyline":"[106.69599915,10.75990009] ; [106.69627380,10.76014996] ; [106.69663239,10.76060963] ; [106.69721985,10.76132011] ; [106.69756317,10.76093960] ; [106.69776917,10.76064968] ; [106.69785309,10.76051998]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1253"
    ,"Station_Code":"Q4 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chung cư H3"
    ,"Station_Address":"303-305, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.760066
    ,"Long":106.699294
    ,"Polyline":"[106.69785309,10.76051998] ; [106.69822693,10.76000977] ; [106.69851685,10.75963974] ; [106.69892883,10.75992012] ; [106.69918823,10.76012039]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1379"
    ,"Station_Code":"Q1 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"82 - 84, đường Nguyễn Thái Học, Quận 1"
    ,"Lat":10.766109
    ,"Long":106.696686
    ,"Polyline":"[106.69918823,10.76012039] ; [106.69972992,10.76053047] ; [106.70041656,10.76099968] ; [106.69986725,10.76181984] ; [106.69959259,10.76220036] ; [106.69931793,10.76249027] ; [106.69872284,10.76309967] ; [106.69805145,10.76377010.06.69786835] ; [10.76395988,106.69760895] ; [10.76432037,106.69657135]"
    ,"Distance":"871"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1385"
    ,"Station_Code":"Q1 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường Nguyễn Thái Học"
    ,"Station_Address":"141-149, đường Lê Thị Hồng Gấm, Quận 1"
    ,"Lat":10.767635
    ,"Long":106.696281
    ,"Polyline":"[106.69668579,10.76610947] ; [106.69583130,10.76731968] ; [106.69628143,10.76763535]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"84"
    ,"Station_Code":"Q1 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện số 26, đường Nguyễn Thị Nghĩa, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.693779
    ,"Polyline":"[106.69628143,10.76763535] ; [106.69691467,10.76828194] ; [106.69665527,10.76883030] ; [106.69639587,10.76938820] ; [106.69618225,10.76984215] ; [106.69541168,10.76951504] ; [106.69470215,10.76934624] ; [106.69371796,10.77099228]"
    ,"Distance":"675"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"85"
    ,"Station_Code":"Q1 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 6 Ph ù Đổng"
    ,"Station_Address":"22, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.77097
    ,"Long":106.69268
    ,"Polyline":"[106.69371796,10.77099228] ; [106.69371796,10.77099228] ; [106.69371796,10.77099228] ; [106.69371796,10.77099228] ; [106.69361115,10.77111149] ; [106.69352722,10.77121162] ; [106.69344330,10.77134991] ; [106.69342804,10.77143288] ; [106.69335175,10.77149105] ; [106.69327545,10.77152824] ; [106.69317627,10.77151775] ; [106.69313049,10.77144909] ; [106.69306946,10.77138615] ; [106.69306183,10.77132225] ; [106.69309235,10.77124977] ; [106.69268036,10.77097034] ; [106.69268036,10.77097034] ; [106.69268036,10.77097034] ; [106.69268036,10.77097034]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"87"
    ,"Station_Code":"Q1 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"136, đường Nguyễn  Trãi, Quận 1"
    ,"Lat":10.769646
    ,"Long":106.690788
    ,"Polyline":"[106.69268036,10.77097034] ; [106.69203186,10.77046967] ; [106.69078827,10.76964569]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"86"
    ,"Station_Code":"Q1 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà thờ Huyện Sỹ"
    ,"Station_Address":"206Bis, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.767692
    ,"Long":106.688591
    ,"Polyline":"[106.69078827,10.76964569] ; [106.69078827,10.76964569] ; [106.69017029,10.76919842] ; [106.68968964,10.76871967] ; [106.68936157,10.76838970] ; [106.68920898,10.76819992] ; [106.68895721,10.76799965] ; [106.68874359,10.76776028] ; [106.68859100,10.76769161] ; [106.68859100,10.76769161]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1012"
    ,"Station_Code":"Q1 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chùa Lâm Tế"
    ,"Station_Address":"Đối diện 211 (212A), đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.765736
    ,"Long":106.687798
    ,"Polyline":"[106.68859100,10.76769161] ; [106.68849945,10.76739025] ; [106.68836212,10.76702023] ; [106.68830872,10.76677036] ; [106.68829346,10.76677036] ; [106.68824768,10.76675034] ; [106.68821716,10.76671028] ; [106.68826294,10.76663971] ; [106.68814850,10.76644993] ; [106.68779755,10.76573563]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"1019"
    ,"Station_Code":"Q1 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"City plaza"
    ,"Station_Address":"230, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.764556
    ,"Long":106.687385
    ,"Polyline":"[106.68779755,10.76573563] ; [106.68708038,10.76375198]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3076"
    ,"Station_Code":"Q5 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường  Đại học Sài Gòn"
    ,"Station_Address":"4, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.759333
    ,"Long":106.68341
    ,"Polyline":"[106.68715668,10.76371956] ; [106.68698120,10.76327991] ; [106.68666077,10.76268005] ; [106.68656158,10.76245022] ; [106.68537903,10.76039982] ; [106.68515015,10.76006031] ; [106.68501282,10.75990963] ; [106.68492889,10.75984001] ; [106.68469238,10.75969982] ; [106.68399048,10.75940037] ; [106.68347168,10.75922012]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3079"
    ,"Station_Code":"Q5 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường THCS  Ba Đình"
    ,"Station_Address":"257, đường Nguyễn Biểu, Quận 5"
    ,"Lat":10.758242
    ,"Long":106.682788
    ,"Polyline":"[106.68344879,10.75927067] ; [106.68260956,10.75891972] ; [106.68275452,10.75823116]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3078"
    ,"Station_Code":"Q5 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chung c ư 109 Nguyễn Biểu"
    ,"Station_Address":"109, đường Nguyễn Biểu, Quận 5"
    ,"Lat":10.755565
    ,"Long":106.683769
    ,"Polyline":"[106.68275452,10.75823116] ; [106.68316650,10.75737953] ; [106.68373871,10.75556374]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3082"
    ,"Station_Code":"Q8 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Công an  Phường 8"
    ,"Station_Address":"138, đường Hưng Phú, Quận 8"
    ,"Lat":10.750664
    ,"Long":106.681066
    ,"Polyline":"[106.68380737,10.75559044] ; [106.68418884,10.75463009] ; [106.68427277,10.75436974] ; [106.68430328,10.75401974] ; [106.68428802,10.75384998] ; [106.68424988,10.75372982] ; [106.68388367,10.75187969] ; [106.68367767,10.75096035] ; [106.68271637,10.75084972] ; [106.68170166,10.75070000] ; [106.68123627,10.75063992]"
    ,"Distance":"812"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3084"
    ,"Station_Code":"Q8 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Viện Y tế C ộng đồng"
    ,"Station_Address":"290, đường Hưng Ph ú, Quận 8"
    ,"Lat":10.749984
    ,"Long":106.678416
    ,"Polyline":"[106.68124390,10.75065899] ; [106.68054962,10.75053978] ; [106.68038940,10.75049973] ; [106.67993164,10.75037003] ; [106.67841339,10.74995041] ; [106.67841339,10.74995232]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3081"
    ,"Station_Code":"Q8 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Lê Quang Kim"
    ,"Station_Address":"348, đường Hưng Phú, Quận 8"
    ,"Lat":10.747688
    ,"Long":106.674797
    ,"Polyline":"[106.67841339,10.74995232] ; [106.67841339,10.74995041] ; [106.67813110,10.74985981] ; [106.67751312,10.74956036] ; [106.67677307,10.74909973] ; [106.67645264,10.74886036] ; [106.67579651,10.74835014] ; [106.67556000,10.74816036] ; [106.67479706,10.74768829]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3083"
    ,"Station_Code":"Q8 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Đình An Hòa"
    ,"Station_Address":"452, đường Hưng Phú, Quận 8"
    ,"Lat":10.746987
    ,"Long":106.67244
    ,"Polyline":"[106.67479706,10.74768829] ; [106.67453766,10.74744987] ; [106.67430115,10.74732971] ; [106.67379761,10.74720001] ; [106.67331696,10.74711037] ; [106.67266083,10.74697971] ; [106.67243958,10.74698734]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3085"
    ,"Station_Code":"Q8 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường TH  Hưng Phú A"
    ,"Station_Address":"492, đường Hưng Phú, Quận 8"
    ,"Lat":10.746716
    ,"Long":106.671036
    ,"Polyline":"[106.67243958,10.74698734] ; [106.67220306,10.74691963] ; [106.67147827,10.74676991] ; [106.67103577,10.74671555]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3086"
    ,"Station_Code":"Q8 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Phạm Hùng"
    ,"Station_Address":"580, đường Hưng Phú, Quận 8"
    ,"Lat":10.746448
    ,"Long":106.669701
    ,"Polyline":"[106.67103577,10.74671555] ; [106.66970062,10.74644756]"
    ,"Distance":"149"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3088"
    ,"Station_Code":"Q8 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Lưu Quý  Kỳ"
    ,"Station_Address":"700-702, đường Hưng Phú, Quận 8"
    ,"Lat":10.745995
    ,"Long":106.667488
    ,"Polyline":"[106.66970062,10.74644756] ; [106.66863251,10.74617004] ; [106.66748810,10.74599457]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3087"
    ,"Station_Code":"Q8 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Dã Tượng"
    ,"Station_Address":"842, đường Hưng Phú, Quận  8"
    ,"Lat":10.745457
    ,"Long":106.664238
    ,"Polyline":"[106.66748810,10.74599457] ; [106.66677856,10.74582958] ; [106.66564178,10.74565029] ; [106.66471863,10.74549961] ; [106.66423798,10.74543953] ; [106.66423798,10.74545670]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3090"
    ,"Station_Code":"Q8 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Xóm Củi"
    ,"Station_Address":"91, đường Xóm Củi, Quận 8"
    ,"Lat":10.746155
    ,"Long":106.660904
    ,"Polyline":"[106.66423798,10.74543953] ; [106.66393280,10.74538040] ; [106.66300964,10.74520016] ; [106.66255951,10.74514008] ; [106.66211700,10.74536991] ; [106.66137695,10.74565029] ; [106.66114044,10.74577045] ; [106.66094971,10.74594975] ; [106.66085052,10.74612999]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3089"
    ,"Station_Code":"Q8 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu số 1"
    ,"Station_Address":"Đối diện 707, đường Bến Bình Đông, Quận 8"
    ,"Lat":10.744113
    ,"Long":106.651899
    ,"Polyline":"[106.66090393,10.74615479] ; [106.66053009,10.74668503] ; [106.66053009,10.74702168] ; [106.66017914,10.74697971] ; [106.65970612,10.74675846] ; [106.65949249,10.74651623] ; [106.65888977,10.74580956] ; [106.65763092,10.74513531] ; [106.65676117,10.74469280] ; [106.65601349,10.74433422] ; [106.65592957,10.74439716] ; [106.65468597,10.74380684] ; [106.65357971,10.74322701] ; [106.65305328,10.74393368] ; [106.65267944,10.74453449] ; [106.65174866,10.74398613]"
    ,"Distance":"1293"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3091"
    ,"Station_Code":"Q8 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Kho 289"
    ,"Station_Address":"Đối diện 289, đường Bến Bình Đông, Quận 8"
    ,"Lat":10.741151
    ,"Long":106.646841
    ,"Polyline":"[106.65174866,10.74398613] ; [106.64699554,10.74118233]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3092"
    ,"Station_Code":"Q8 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"cầu Kinh  Ngang Số 2"
    ,"Station_Address":"Đối diện 301C, đường Bến Bình Đông, Quận 8"
    ,"Lat":10.739736
    ,"Long":106.644524
    ,"Polyline":"[106.64699554,10.74118233] ; [106.64644623,10.74081039] ; [106.64504242,10.73997021] ; [106.64452362,10.73973560]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3093"
    ,"Station_Code":"Q8 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Lương Văn Cang"
    ,"Station_Address":"Đối diện 19,  đường Lương Văn Can, Quận 8"
    ,"Lat":10.734302
    ,"Long":106.64006
    ,"Polyline":"[106.64454651,10.73968983] ; [106.64353180,10.73902988] ; [106.64325714,10.73890018] ; [106.64285278,10.73861980] ; [106.64243317,10.73836040] ; [106.64173126,10.73793030] ; [106.64082336,10.73738003] ; [106.64050293,10.73717022] ; [106.63986206,10.73674965] ; [106.63926697,10.73639011] ; [106.63899994,10.73620987] ; [106.63977051,10.73491001] ; [106.64012146,10.73433971]"
    ,"Distance":"975"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3097"
    ,"Station_Code":"Q8 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Phường 15"
    ,"Station_Address":"184, đường Lưu Hữu Phước, Quận 8"
    ,"Lat":10.73305
    ,"Long":106.640317
    ,"Polyline":"[106.64006042,10.73430157] ; [106.64051056,10.73383522] ; [106.64079285,10.73334026] ; [106.64070892,10.73326969] ; [106.64031982,10.73297977] ; [106.64035797,10.73301220]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3094"
    ,"Station_Code":"Q8 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Phường 15"
    ,"Station_Address":"220, đường Lưu Hữu Phước, Quận 8"
    ,"Lat":10.729919
    ,"Long":106.637308
    ,"Polyline":"[106.64035797,10.73301220] ; [106.64031982,10.73297977] ; [106.64002991,10.73278999] ; [106.63983917,10.73260975] ; [106.63905334,10.73198986] ; [106.63887024,10.73182964] ; [106.63842010,10.73126030] ; [106.63796997,10.73071003] ; [106.63758087,10.73019981] ; [106.63734436,10.72988319]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3095"
    ,"Station_Code":"Q8 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nguyễn S ĩ Cố"
    ,"Station_Address":"264, đường Lưu Hữu Phước,  Quận 8"
    ,"Lat":10.72614
    ,"Long":106.635205
    ,"Polyline":"[106.63734436,10.72988319] ; [106.63719940,10.72968006] ; [106.63693237,10.72931957] ; [106.63662720,10.72883987] ; [106.63617706,10.72805023] ; [106.63523865,10.72608662]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3096"
    ,"Station_Code":"Q8 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Số 3"
    ,"Station_Address":"14, đường Bình Đức, Quận 8"
    ,"Lat":10.723937
    ,"Long":106.631958
    ,"Polyline":"[106.63523865,10.72608662] ; [106.63523865,10.72608662] ; [106.63513184,10.72583961] ; [106.63449860,10.72459030] ; [106.63421631,10.72401047] ; [106.63417816,10.72399998] ; [106.63410187,10.72401047] ; [106.63265991,10.72471046] ; [106.63198090,10.72504044] ; [106.63184357,10.72506046] ; [106.63159180,10.72506046] ; [106.63136292,10.72515011] ; [106.63124847,10.72519970] ; [106.63121033,10.72525024] ; [106.63124084,10.72557640] ; [106.63147736,10.72607136] ; [106.63166809,10.72640419] ; [106.63188171,10.72681999] ; [106.63204193,10.72726822] ; [106.63195801,10.72721004] ; [106.63175201,10.72679424] ; [106.63152313,10.72639370] ; [106.63131714,10.72595596] ; [106.63111877,10.72551823] ; [106.63088226,10.72508049] ; [106.63032532,10.72373199] ; [106.62999725,10.72308350] ; [106.62966919,10.72243977] ; [106.62976837,10.72242451] ; [106.63002777,10.72291946] ; [106.63043976,10.72380543] ; [106.63085938,10.72469044] ; [106.63098145,10.72467995] ; [106.63134766,10.72449017] ; [106.63152313,10.72430992] ; [106.63195801,10.72393703] ; [106.63195801,10.72393703]"
    ,"Distance":"1902"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3098"
    ,"Station_Code":"Q8 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"KTX trư ờng Công nghệ thực phẩm"
    ,"Station_Address":"KTX Trường TH CNTP, đường  Lưu Hữu Phước, Quận 8"
    ,"Lat":10.71903
    ,"Long":106.631847
    ,"Polyline":"[106.63195801,10.72393703] ; [106.63253784,10.72381592] ; [106.63311005,10.72354984] ; [106.63365936,10.72329998] ; [106.63377380,10.72323990] ; [106.63378143,10.72321033] ; [106.63378143,10.72309971] ; [106.63175964,10.71893978] ; [106.63172913,10.71895981]"
    ,"Distance":"747"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"3099"
    ,"Station_Code":"Q8 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Cầu Rạch Cát"
    ,"Station_Address":"322, đường Lưu H ữu Phước, Quận 8"
    ,"Lat":10.715419
    ,"Long":106.629428
    ,"Polyline":"[106.63172913,10.71895981] ; [106.63111115,10.71765041] ; [106.63088226,10.71724987] ; [106.63046265,10.71669006] ; [106.63002014,10.71609974] ; [106.62988281,10.71594048] ; [106.62920380,10.71547222]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"67"
    ,"Station_Id":"2989"
    ,"Station_Code":"BX 22"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Mễ Cốc"
    ,"Station_Address":"ĐẦU BẾN BẾN MỄ CỐC, đường Lưu Hữu Phước, Quận 8"
    ,"Lat":10.712879
    ,"Long":106.626114
    ,"Polyline":"[106.62920380,10.71547222] ; [106.62879944,10.71479988] ; [106.62821960,10.71426010.06.62764740] ; [10.71380043,106.62635040] ; [10.71298981,106.62621307] ; [10.71298981,106.62615204] ; [10.71300983,106.62611389]"
    ,"Distance":"460"
  }]