export const Route101 =[
  {
     "Route_Id":"101"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"BÃI XE BUÝT ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT ĐẦM SEN, đường Hòa  Bình, Quận 11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1616"
    ,"Station_Code":"Q11 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường Hòa Bình"
    ,"Station_Address":"72, đường H òa Bình, Quận 11"
    ,"Lat":10.768496
    ,"Long":106.639137
    ,"Polyline":"[106.63967133,10.76786041] ; [106.63976288,10.76801872] ; [106.63913727,10.76849556]"
    ,"Distance":"107"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1604"
    ,"Station_Code":"QTP 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Đầm Sen"
    ,"Station_Address":"45 (Đối diện công viên nư ớc Đầm Sen), đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769367
    ,"Long":106.63707
    ,"Polyline":"[106.63913727,10.76849556] ; [106.63913727,10.76849556] ; [106.63863373,10.76860332] ; [106.63778687,10.76895618] ; [106.63738251,10.76910400] ; [106.63706970,10.76936722] ; [106.63706970,10.76936722]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1617"
    ,"Station_Code":"QTP 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Hu ệ Quang"
    ,"Station_Address":"116, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769747
    ,"Long":106.635246
    ,"Polyline":"[106.63706970,10.76936722] ; [106.63706970,10.76936722] ; [106.63706970,10.76936722] ; [106.63665009,10.76941490] ; [106.63596344,10.76963043] ; [106.63524628,10.76974678] ; [106.63524628,10.76974678] ; [106.63524628,10.76974678]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1619"
    ,"Station_Code":"QTP 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"126, đường H òa Bình, Quận Tân Phú"
    ,"Lat":10.77
    ,"Long":106.633362
    ,"Polyline":"[106.63524628,10.76974678] ; [106.63524628,10.76974678] ; [106.63452148,10.76955223] ; [106.63336182,10.77000046] ; [106.63336182,10.77000046]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4315"
    ,"Station_Code":"QTPT232"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"264, Lũy Bán Bích"
    ,"Station_Address":"264, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.7706848586522
    ,"Long":106.631915803614
    ,"Polyline":"[106.63336182,10.77000046] ; [106.63336182,10.77000046] ; [106.63185883,10.77027893] ; [106.63191223,10.77068520] ; [106.63191223,10.77068520]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4316"
    ,"Station_Code":"QTPT233"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"332, Lũy Bán Bích"
    ,"Station_Address":"314, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.7736781543893
    ,"Long":106.632484431926
    ,"Polyline":"[106.63191223,10.77068520] ; [106.63191223,10.77068520] ; [106.63191223,10.77068520] ; [106.63222504,10.77232933] ; [106.63248444,10.77367783] ; [106.63248444,10.77367783] ; [106.63248444,10.77367783]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4317"
    ,"Station_Code":"QTP 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Thạch Lam"
    ,"Station_Address":"394, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.77606
    ,"Long":106.633788
    ,"Polyline":"[106.63248444,10.77367783] ; [106.63248444,10.77367783] ; [106.63248444,10.77367783] ; [106.63289642,10.77477932] ; [106.63340759,10.77554321] ; [106.63378906,10.77606010.06.63378906] ; [10.77606010.06.63378906,10.77606010]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4318"
    ,"Station_Code":"QTP 205"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây xăng  Bình An"
    ,"Station_Address":"464, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.778395
    ,"Long":106.635204
    ,"Polyline":"[106.63378906,10.77606010.06.63378906] ; [10.77606010.06.63378906,10.77606010.06.63452911] ; [10.77719879,106.63520050] ; [10.77839470,106.63520050] ; [10.77839470,106.63520050]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4319"
    ,"Station_Code":"QTPT236"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Công vi ên Ủy ban Quận Tân Phú"
    ,"Station_Address":"Kế 556, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.780972
    ,"Long":106.635987
    ,"Polyline":"[106.63520050,10.77839470] ; [106.63520050,10.77839470] ; [106.63520050,10.77839470] ; [106.63564301,10.77968597] ; [106.63598633,10.78097153] ; [106.63598633,10.78097153] ; [106.63598633,10.78097153]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4320"
    ,"Station_Code":"QTP 207"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu thị Coopmart"
    ,"Station_Address":"Đối diện 564, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.784639
    ,"Long":106.636545
    ,"Polyline":"[106.63598633,10.78097153] ; [106.63598633,10.78097153] ; [106.63598633,10.78097153] ; [106.63627625,10.78283691] ; [106.63654327,10.78463936] ; [106.63654327,10.78463936] ; [106.63654327,10.78463936]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4321"
    ,"Station_Code":"QTPT239"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Vườn Lài"
    ,"Station_Address":"624, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.787638
    ,"Long":106.637028
    ,"Polyline":"[106.63654327,10.78463936] ; [106.63703156,10.78763771]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4322"
    ,"Station_Code":"QTP 209"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Độc Lập"
    ,"Station_Address":"672, đường Lũy  Bán Bích, Quận Tân Phú"
    ,"Lat":10.791189
    ,"Long":106.637591
    ,"Polyline":"[106.63703156,10.78763771] ; [106.63758850,10.79118919]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4323"
    ,"Station_Code":"QTP 210"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"Kios 07, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.794481
    ,"Long":106.63808
    ,"Polyline":"[106.63758850,10.79118919] ; [106.63807678,10.79448128]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4698"
    ,"Station_Code":"T0059"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"Âu Cơ, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.7956171034784
    ,"Long":106.638294383883
    ,"Polyline":"[106.63807678,10.79448128] ; [106.63829803,10.79561710]"
    ,"Distance":"129"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2715"
    ,"Station_Code":"QTB 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Cư xá Tân Sơn Nhì"
    ,"Station_Address":"133, đường Ba Vân, Quận Tân Bình"
    ,"Lat":10.796006
    ,"Long":106.639529
    ,"Polyline":"[106.63829803,10.79561710.06.63845825] ; [10.79565239,106.63869476] ; [10.79574203,106.63908386] ; [10.79596901,106.63941956] ; [10.79604244,106.63952637]"
    ,"Distance":"146"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4333"
    ,"Station_Code":"QTB 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Bàu C át 2"
    ,"Station_Address":"160, đường Trương Công Định, Quận Tân Bình"
    ,"Lat":10.794641
    ,"Long":106.640488
    ,"Polyline":"[106.63952637,10.79600620] ; [106.64079285,10.79556847] ; [106.64048767,10.79464054]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4338"
    ,"Station_Code":"QTB 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã t ư Nguyễn Hồng Đào"
    ,"Station_Address":"60, đường Bàu Cát, Quận Tân Bình"
    ,"Lat":10.792915
    ,"Long":106.640968
    ,"Polyline":"[106.64048767,10.79464054] ; [106.64013672,10.79328156] ; [106.64096832,10.79291534]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3163"
    ,"Station_Code":"QTB 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Ph ương Nam"
    ,"Station_Address":"146-148 (154),  đường Bàu Cát, Quận Tân Bình"
    ,"Lat":10.791997
    ,"Long":106.643219
    ,"Polyline":"[106.64096832,10.79291534] ; [106.64321899,10.79199696]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1825"
    ,"Station_Code":"QTB 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường Tr ần Quốc Toản"
    ,"Station_Address":"113, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.792459
    ,"Long":106.644325
    ,"Polyline":"[106.64321899,10.79199696] ; [106.64324188,10.79205036] ; [106.64386749,10.79179955] ; [106.64400482,10.79174232] ; [106.64417267,10.79226017] ; [106.64427185,10.79248047] ; [106.64432526,10.79245853]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1824"
    ,"Station_Code":"QTB 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường  Đồng Đen"
    ,"Station_Address":"45, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.794153
    ,"Long":106.644974
    ,"Polyline":"[106.64427185,10.79248047] ; [106.64469147,10.79356956] ; [106.64485168,10.79399014] ; [106.64491272,10.79417992]"
    ,"Distance":"215"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1828"
    ,"Station_Code":"QTB 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Hội chữ thập đỏ Tân Bình"
    ,"Station_Address":"1 , đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.796401
    ,"Long":106.645736
    ,"Polyline":"[106.64497375,10.79415321] ; [106.64491272,10.79417992] ; [106.64538574,10.79541016] ; [106.64565277,10.79617977] ; [106.64573669,10.79640102]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1392"
    ,"Station_Code":"QTB 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Hoàng Hoa  Thám"
    ,"Station_Address":"233, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796426
    ,"Long":106.646553
    ,"Polyline":"[106.64573669,10.79640102] ; [106.64586639,10.79681206] ; [106.64655304,10.79642582]"
    ,"Distance":"134"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1826"
    ,"Station_Code":"QTB 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà th ờ Đắc Lộ"
    ,"Station_Address":"97 (đối diện 160B ), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794978
    ,"Long":106.64926
    ,"Polyline":"[106.64655304,10.79642582] ; [106.64927673,10.79499626]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1830"
    ,"Station_Code":"QTB 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã t ư Bảy Hiền"
    ,"Station_Address":"67, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.793856
    ,"Long":106.651368
    ,"Polyline":"[106.64927673,10.79499626] ; [106.65143585,10.79382420]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65154266,10.79377842] ; [106.65280914,10.79319668] ; [106.65324402,10.79296494] ; [106.65344238,10.79289150] ; [106.65374756,10.79316521] ; [106.65419769,10.79370308] ; [106.65456390,10.79416656] ; [106.65505981,10.79458714]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"555"
    ,"Station_Code":"QTB 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà hàng Đông Phương"
    ,"Station_Address":"431, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.798622
    ,"Long":106.659286
    ,"Polyline":"[106.65505981,10.79458714] ; [106.65928650,10.79862213]"
    ,"Distance":"645"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65928650,10.79862213] ; [106.65958405,10.79899311] ; [106.65992737,10.79936218] ; [106.66082764,10.80021095] ; [106.66098785,10.80022144] ; [106.66110992,10.80030060] ; [106.66119385,10.80037975] ; [106.66128540,10.80045795] ; [106.66149902,10.80059052] ; [106.66166687,10.80063725] ; [106.66183472,10.80065823] ; [106.66266632,10.80061626] ; [106.66303253,10.80058002] ; [106.66330719,10.80050278]"
    ,"Distance":"535"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80050278] ; [106.66480255,10.80043221] ; [106.66635132,10.80023193]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"511"
    ,"Station_Code":"QPN 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"241, đường Hoàng Văn Thụ, Quận Phú Nhu ận"
    ,"Lat":10.799905
    ,"Long":106.6698
    ,"Polyline":"[106.66635132,10.80023193] ; [106.66703033,10.80025291] ; [106.66793060,10.80015850] ; [106.66875458,10.79998875]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"556"
    ,"Station_Code":"QPN 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Khách Sạn Tân Sơn Nhất"
    ,"Station_Address":"217, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799805
    ,"Long":106.670873
    ,"Polyline":"[106.66979980,10.79990482] ; [106.67087555,10.79980469]"
    ,"Distance":"118"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"512"
    ,"Station_Code":"QPN 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Công an Phú Nhuận"
    ,"Station_Address":"189, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799552
    ,"Long":106.673684
    ,"Polyline":"[106.67087555,10.79980469] ; [106.67368317,10.79955196]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"232"
    ,"Station_Code":"QPN 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"59, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799094
    ,"Long":106.679247
    ,"Polyline":"[106.67368317,10.79955196] ; [106.67924500,10.79913139]"
    ,"Distance":"614"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"558"
    ,"Station_Code":"QPN 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"171, đường Phan Đăng Lưu,  Quận Phú Nhuận"
    ,"Lat":10.800241
    ,"Long":106.681541
    ,"Polyline":"[106.67924500,10.79913139] ; [106.68005371,10.79914093] ; [106.68052673,10.79931450] ; [106.68154144,10.80024147]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"513"
    ,"Station_Code":"QPN 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"141 - 143, đường Phan Đăng Lưu, Quận  Phú Nhuận"
    ,"Lat":10.802197
    ,"Long":106.683619
    ,"Polyline":"[106.68154144,10.80024147] ; [106.68361664,10.80219746]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"514"
    ,"Station_Code":"QPN 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"109, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803841
    ,"Long":106.686156
    ,"Polyline":"[106.68361664,10.80219746] ; [106.68480682,10.80349922] ; [106.68496704,10.80365658] ; [106.68515778,10.80379391] ; [106.68536377,10.80388832] ; [106.68560028,10.80393124] ; [106.68590546,10.80392551] ; [106.68615723,10.80384064]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"515"
    ,"Station_Code":"QPN 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bệnh Viện Phước An"
    ,"Station_Address":"81 - 83, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.80362
    ,"Long":106.687744
    ,"Polyline":"[106.68615723,10.80384064] ; [106.68733215,10.80369949] ; [106.68774414,10.80362034]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"516"
    ,"Station_Code":"QBTH 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Công an PCCC"
    ,"Station_Address":"45, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803188
    ,"Long":106.691371
    ,"Polyline":"[106.68774414,10.80362034] ; [106.69136810,10.80318832]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2039"
    ,"Station_Code":"QBTH 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"2, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803488
    ,"Long":106.695013
    ,"Polyline":"[106.69136810,10.80318832] ; [106.69496155,10.80270863] ; [106.69501495,10.80348778]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2035"
    ,"Station_Code":"QBTH 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"48, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.806076
    ,"Long":106.695083
    ,"Polyline":"[106.69501495,10.80348778] ; [106.69508362,10.80607605]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1650"
    ,"Station_Code":"QBTH 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"124, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809732
    ,"Long":106.695158
    ,"Polyline":"[106.69508362,10.80607605] ; [106.69515991,10.80973244]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2746"
    ,"Station_Code":"QBTH 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã 5  Bình Hòa"
    ,"Station_Address":"170L, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.811745
    ,"Long":106.695925
    ,"Polyline":"[106.69515991,10.80973244] ; [106.69518280,10.80993271] ; [106.69521332,10.81029606] ; [106.69526672,10.81058025] ; [106.69550323,10.81120014] ; [106.69587708,10.81175041] ; [106.69592285,10.81174469]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2748"
    ,"Station_Code":"QBTH 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Siêu  thị Satra Food"
    ,"Station_Address":"244-246, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.813811
    ,"Long":106.69754
    ,"Polyline":"[106.69592285,10.81174469] ; [106.69615173,10.81208229] ; [106.69684601,10.81294632] ; [106.69754028,10.81381130]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2747"
    ,"Station_Code":"QBTH 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Nhà văn hóa Lao Động"
    ,"Station_Address":"290, đường Nơ Trang Long, Quận Bình Th ạnh"
    ,"Lat":10.816245
    ,"Long":106.697931
    ,"Polyline":"[106.69754028,10.81381130] ; [106.69754028,10.81381130] ; [106.69770050,10.81408978] ; [106.69789124,10.81448555] ; [106.69794464,10.81529140] ; [106.69792938,10.81624508] ; [106.69792938,10.81624508]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2750"
    ,"Station_Code":"QBTH 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Trường Trung cấp xây dựng Tp. HCM"
    ,"Station_Address":"380, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.81889
    ,"Long":106.70078
    ,"Polyline":"[106.69792938,10.81624508] ; [106.69786072,10.81681442] ; [106.69787598,10.81712532] ; [106.69795990,10.81740952] ; [106.69807434,10.81761551] ; [106.69820404,10.81781006] ; [106.69867706,10.81828976] ; [106.69893646,10.81851101] ; [106.69939423,10.81879520] ; [106.69957733,10.81885815] ; [106.69976807,10.81890106.06.70078278]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2749"
    ,"Station_Code":"QBTH 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"UBND Phường 13, Quận Bình Thạnh"
    ,"Station_Address":"450-452, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.819697
    ,"Long":106.70327
    ,"Polyline":"[106.70078278,10.81888962] ; [106.70078278,10.81888962] ; [106.70153046,10.81911182] ; [106.70268250,10.81947517] ; [106.70316315,10.81966019] ; [106.70326996,10.81969738] ; [106.70326996,10.81969738]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2899"
    ,"Station_Code":"QBTH 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Ngã Tư Nơ Trang Long"
    ,"Station_Address":"225 , đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.81859
    ,"Long":106.704685
    ,"Polyline":"[106.70326996,10.81969738] ; [106.70399475,10.82001209] ; [106.70407104,10.81962299] ; [106.70433044,10.81910610.06.70468140]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2900"
    ,"Station_Code":"QBTH 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Nhà S ách Miền Đông"
    ,"Station_Address":"79/5B, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.815729
    ,"Long":106.707357
    ,"Polyline":"[106.70468140,10.81859016] ; [106.70602417,10.81719398] ; [106.70735931,10.81572914]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2905"
    ,"Station_Code":"QBTH 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Ngã Tư Đinh Bộ Lĩnh"
    ,"Station_Address":"153 , đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.813679
    ,"Long":106.709127
    ,"Polyline":"[106.70735931,10.81572914] ; [106.70912933,10.81367874]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1408"
    ,"Station_Code":"QBTH 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Ngã n ăm Liệt Sĩ"
    ,"Station_Address":"222/4 Ter, đ ường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.81204
    ,"Long":106.710624
    ,"Polyline":"[106.70912933,10.81367874] ; [106.71062469,10.81204033]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Siêu th ị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71062469,10.81204033] ; [106.71235657,10.81014347] ; [106.71240997,10.81079102]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128 , đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71260834,10.81231976]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Bến xe  Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71260834,10.81231976] ; [106.71260834,10.81231976] ; [106.71260834,10.81231976] ; [106.71269226,10.81306744] ; [106.71279144,10.81385326] ; [106.71279144,10.81385326] ; [106.71279144,10.81385326]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh,  Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71272278,10.81385994] ; [106.71285248,10.81464291] ; [106.71298218,10.81557083] ; [106.71313477,10.81710911] ; [106.71311951,10.81738281] ; [106.71269226,10.81735134] ; [106.71208191,10.81720448] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71052551,10.81531811] ; [106.71003723,10.81440067] ; [106.70980072,10.81379986] ; [106.71015930,10.81397915] ; [106.71044922,10.81452751] ; [106.71067810,10.81497002] ; [106.71129608,10.81473255]"
    ,"Distance":"1222"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2890"
    ,"Station_Code":"QBTH 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã Tư Đinh Bộ Lĩnh"
    ,"Station_Address":"134, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.813647
    ,"Long":106.709282
    ,"Polyline":"[106.71073914,10.81503010.06.71019745] ; [10.81396961,106.71009827] ; [10.81390953,106.70989227] ; [10.81398964,106.70986176] ; [10.81394005,106.70954132] ; [10.81330013,106.70928192]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2893"
    ,"Station_Code":"QBTH 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nhà Sách Miền Đông"
    ,"Station_Address":"Đối diện 79/5B, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.81585
    ,"Long":106.707367
    ,"Polyline":"[106.70928192,10.81359959] ; [106.70728302,10.81577969]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2895"
    ,"Station_Code":"QBTH 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã Tư Nơ Trang Long"
    ,"Station_Address":"292, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.818669
    ,"Long":106.704739
    ,"Polyline":"[106.70728302,10.81577969] ; [106.70613861,10.81702995] ; [106.70545959,10.81777954] ; [106.70527649,10.81795025] ; [106.70526123,10.81799984] ; [106.70509338,10.81822968] ; [106.70481110,10.81859970]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2550"
    ,"Station_Code":"QBTH 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"UBND Phường 13, Quận Bình Thạnh"
    ,"Station_Address":"363, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.819649
    ,"Long":106.702915
    ,"Polyline":"[106.70481110,10.81859970] ; [106.70442200,10.81914043] ; [106.70416260,10.81962013] ; [106.70403290,10.82005978] ; [106.70394897,10.82001972] ; [106.70369720,10.81989002] ; [106.70307922,10.81962967] ; [106.70294189,10.81958961]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2541"
    ,"Station_Code":"QBTH 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Trung cấp xây dựng Tp. HCM"
    ,"Station_Address":"327, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.818959
    ,"Long":106.700345
    ,"Polyline":"[106.70294189,10.81958961] ; [106.70160675,10.81921959] ; [106.70097351,10.81900978] ; [106.70065308,10.81892967] ; [106.70053101,10.81890011] ; [106.70043945,10.81890965] ; [106.70034790,10.81892014]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2543"
    ,"Station_Code":"QBTH 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhà văn hóa Lao Động"
    ,"Station_Address":"217, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.816113
    ,"Long":106.69784
    ,"Polyline":"[106.70034790,10.81892014] ; [106.69985962,10.81896019] ; [106.69966125,10.81896019] ; [106.69954681,10.81892014] ; [106.69944000,10.81888008] ; [106.69914246,10.81865025] ; [106.69889069,10.81849957] ; [106.69841766,10.81812954] ; [106.69806671,10.81779003] ; [106.69795227,10.81756020] ; [106.69779205,10.81711960] ; [106.69780731,10.81684017] ; [106.69785309,10.81661034] ; [106.69786835,10.81610966]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2545"
    ,"Station_Code":"QBTH 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Siêu thị Satra Food"
    ,"Station_Address":"167, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.813605
    ,"Long":106.697266
    ,"Polyline":"[106.69786835,10.81610966] ; [106.69790649,10.81536961] ; [106.69788361,10.81472969] ; [106.69776917,10.81431007] ; [106.69734955,10.81363964] ; [106.69731140,10.81357956]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2552"
    ,"Station_Code":"QBTH 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã Năm Bình Hòa"
    ,"Station_Address":"131, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.811719
    ,"Long":106.69578
    ,"Polyline":"[106.69731140,10.81357956] ; [106.69635010,10.81237984] ; [106.69583130,10.81167984]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1768"
    ,"Station_Code":"QBTH 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"89, đường Nơ  Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809833
    ,"Long":106.695061
    ,"Polyline":"[106.69583130,10.81167984] ; [106.69557190,10.81130981] ; [106.69528198,10.81079006] ; [106.69515228,10.81042957] ; [106.69510651,10.81021976] ; [106.69509888,10.80982971]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2107"
    ,"Station_Code":"QBTH 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"27, đường N ơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.805712
    ,"Long":106.694965
    ,"Polyline":"[106.69509888,10.80982971] ; [106.69503784,10.80665970] ; [106.69500732,10.80570030]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2110"
    ,"Station_Code":"QBTH 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh Vi ện Gia Định"
    ,"Station_Address":"1, đường Nơ  Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803583
    ,"Long":106.694906
    ,"Polyline":"[106.69500732,10.80570030] ; [106.69493866,10.80356026]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"594"
    ,"Station_Code":"QBTH 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"10, đường Phan  Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803088
    ,"Long":106.693586
    ,"Polyline":"[106.69493866,10.80356026] ; [106.69492340,10.80282021] ; [106.69358063,10.80300045]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"593"
    ,"Station_Code":"QBTH 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Công an PCCC, Quận Bình Th ạnh"
    ,"Station_Address":"14-16, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803362
    ,"Long":106.691473
    ,"Polyline":"[106.69358063,10.80300045] ; [106.69243622,10.80313015] ; [106.69143677,10.80327034]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"595"
    ,"Station_Code":"QPN 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh vi ện Phước An"
    ,"Station_Address":"36A, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803894
    ,"Long":106.687535
    ,"Polyline":"[106.69143677,10.80327034] ; [106.68968964,10.80350018] ; [106.68791199,10.80370998] ; [106.68756866,10.80375004]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"596"
    ,"Station_Code":"QPN 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"68, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.804063
    ,"Long":106.686269
    ,"Polyline":"[106.68756866,10.80375004] ; [106.68601227,10.80395985]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"597"
    ,"Station_Code":"QPN 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"124, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802629
    ,"Long":106.683689
    ,"Polyline":"[106.68601227,10.80395985] ; [106.68576050,10.80399036] ; [106.68560028,10.80397987] ; [106.68544006,10.80395031] ; [106.68515778,10.80383015] ; [106.68492889,10.80364037] ; [106.68470764,10.80344963] ; [106.68376160,10.80249977]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"598"
    ,"Station_Code":"QPN 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"172, đường Phan Đăng Lưu, Quận Phú Nhu ận"
    ,"Lat":10.800854
    ,"Long":106.681833
    ,"Polyline":"[106.68376160,10.80249977] ; [106.68286133,10.80163956] ; [106.68202209,10.80080032]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"599"
    ,"Station_Code":"QPN 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"24, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.79931
    ,"Long":106.679354
    ,"Polyline":"[106.68202209,10.80080032] ; [106.68138885,10.80014992] ; [106.68048096,10.79924011] ; [106.68028259,10.79920006] ; [106.68000793,10.79918957] ; [106.67967987,10.79920959]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"601"
    ,"Station_Code":"QPN 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"202, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.800153
    ,"Long":106.669559
    ,"Polyline":"[106.67967987,10.79920959] ; [106.67832947,10.79928970] ; [106.67685699,10.79942989] ; [106.67536926,10.79955959] ; [106.67299652,10.79973030] ; [106.66980743,10.80000019]"
    ,"Distance":"1082"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu  7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66980743,10.80000019] ; [106.66771698,10.80020046] ; [106.66683960,10.80072021] ; [106.66658783,10.80090046]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"257"
    ,"Station_Code":"QTB 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Công vi ên Hoàng Văn Thụ"
    ,"Station_Address":"Công viên Ho àng Văn Thụ, đường Phan Thúc Duyện, Quận Tân Bình"
    ,"Lat":10.802403
    ,"Long":106.664221
    ,"Polyline":"[106.66658783,10.80090046] ; [106.66603851,10.80126953] ; [106.66593933,10.80126953] ; [106.66577911,10.80134010.06.66486359] ; [10.80189037,106.66413879]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66413879,10.80231953] ; [106.66355896,10.80266953] ; [106.66342163,10.80245972] ; [106.66262817,10.80158997] ; [106.66233826,10.80132008]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"600"
    ,"Station_Code":"QTB 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"216, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.799836
    ,"Long":106.660385
    ,"Polyline":"[106.66233826,10.80132008] ; [106.66194153,10.80095959] ; [106.66171265,10.80080986] ; [106.66152191,10.80070019] ; [106.66134644,10.80066013] ; [106.66101074,10.80058956] ; [106.66092682,10.80056953] ; [106.66085052,10.80051041] ; [106.66081238,10.80045986] ; [106.66082001,10.80033970] ; [106.66074371,10.80012035] ; [106.66063690,10.80002975] ; [106.66040039,10.79981995]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"602"
    ,"Station_Code":"QTB 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Công an Quận Tân Bình"
    ,"Station_Address":"340H , đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.796577
    ,"Long":106.656952
    ,"Polyline":"[106.66037750,10.79979992] ; [106.65936279,10.79885960] ; [106.65862274,10.79810047] ; [106.65837860,10.79788017] ; [106.65699005,10.79654026]"
    ,"Distance":"518"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Hội Ch ợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đường Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65699005,10.79654026] ; [106.65577698,10.79539013] ; [106.65515900,10.79603958]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62), đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65515900,10.79603958] ; [106.65464783,10.79654980] ; [106.65390778,10.79584026]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường  Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65390778,10.79584026] ; [106.65238190,10.79434013]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1719"
    ,"Station_Code":"QTB 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"106, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794182
    ,"Long":106.651191
    ,"Polyline":"[106.65238190,10.79434013] ; [106.65184021,10.79384041] ; [106.65178680,10.79374027] ; [106.65145111,10.79391003] ; [106.65113068,10.79407978]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1720"
    ,"Station_Code":"QTB 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Nhà Thở Đắc Lộ"
    ,"Station_Address":"150, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794973
    ,"Long":106.649743
    ,"Polyline":"[106.65113068,10.79407978] ; [106.64964294,10.79487038]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1301"
    ,"Station_Code":"QTB 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"162T,  đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796137
    ,"Long":106.647565
    ,"Polyline":"[106.64964294,10.79487038] ; [106.64749146,10.79603004]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1723"
    ,"Station_Code":"QTB 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Hội Ch ữ thập đỏ Tân Bình"
    ,"Station_Address":"32, đường Đồng Đen, Quận Tân Bình"
    ,"Lat":10.796322
    ,"Long":106.645591
    ,"Polyline":"[106.64749146,10.79603004] ; [106.64584351,10.79693985] ; [106.64563751,10.79633045]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1724"
    ,"Station_Code":"QTB 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường  Trần Quốc Toản"
    ,"Station_Address":"96 (L8-L10), đường Đồng Đen, Quận Tân  Bình"
    ,"Lat":10.792597
    ,"Long":106.644241
    ,"Polyline":"[106.64563751,10.79633045] ; [106.64517975,10.79493999] ; [106.64485168,10.79399014] ; [106.64469147,10.79356956] ; [106.64430237,10.79257011]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3159"
    ,"Station_Code":"QTB 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm Phương Nam"
    ,"Station_Address":"185, đường Bàu Cát, Quận Tân Bình"
    ,"Lat":10.792167
    ,"Long":106.643333
    ,"Polyline":"[106.64430237,10.79257011] ; [106.64395905,10.79179001] ; [106.64392090,10.79187012] ; [106.64344788,10.79205990] ; [106.64331818,10.79211998]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4337"
    ,"Station_Code":"QTB 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã tư Nguyễn Hồng Đào"
    ,"Station_Address":"37, đường Bàu Cát, Quận Tân Bình"
    ,"Lat":10.793079
    ,"Long":106.641102
    ,"Polyline":"[106.64333344,10.79216671] ; [106.64110565,10.79307938]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4336"
    ,"Station_Code":"QTB 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Bàu C át 2"
    ,"Station_Address":"61, đường Trương Công Định, Quận Tân Bình"
    ,"Lat":10.794844
    ,"Long":106.640657
    ,"Polyline":"[106.64110565,10.79307938] ; [106.64021301,10.79340267] ; [106.64065552,10.79484367]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"2715"
    ,"Station_Code":"QTB 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cư xá  Tân Sơn Nhì"
    ,"Station_Address":"133, đường Ba Vân, Quận Tân Bình"
    ,"Lat":10.796006
    ,"Long":106.639529
    ,"Polyline":"[106.64065552,10.79484367] ; [106.64082336,10.79562092] ; [106.63950348,10.79603958]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4698"
    ,"Station_Code":"T0059"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"Âu Cơ, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.7956171034784
    ,"Long":106.638294383883
    ,"Polyline":"[106.63950348,10.79603958] ; [106.63920593,10.79607964] ; [106.63890839,10.79593754] ; [106.63829803,10.79561710]"
    ,"Distance":"145"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4312"
    ,"Station_Code":"QTP 186"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngã 3 Dân Tộc"
    ,"Station_Address":"1033, đ ường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.794408
    ,"Long":106.638026
    ,"Polyline":"[106.63829803,10.79561710.06.63802338]"
    ,"Distance":"138"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4313"
    ,"Station_Code":"QTP 187"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Độc Lập"
    ,"Station_Address":"903, đường Lũy Bán Bích , Quận Tân Phú"
    ,"Lat":10.791274
    ,"Long":106.637441
    ,"Polyline":"[106.63802338,10.79440784] ; [106.63744354,10.79127407]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"4314"
    ,"Station_Code":"QTP 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Vườn Lài"
    ,"Station_Address":"821, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.787764
    ,"Long":106.636889
    ,"Polyline":"[106.63744354,10.79127407] ; [106.63688660,10.78776360]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3574"
    ,"Station_Code":"QTP 189"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Siêu thị Coopmart"
    ,"Station_Address":"254 (Coop mart), đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.78475
    ,"Long":106.636421
    ,"Polyline":"[106.63688660,10.78776360] ; [106.63642120,10.78474998]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3575"
    ,"Station_Code":"QTP 190"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm Thoại Ngọc Hầu"
    ,"Station_Address":"721, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.781077
    ,"Long":106.635857
    ,"Polyline":"[106.63648224,10.78474045] ; [106.63593292,10.78106976]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3576"
    ,"Station_Code":"QTP 191"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trạm Cây Xăng Bình An"
    ,"Station_Address":"611 , đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.778568
    ,"Long":106.635117
    ,"Polyline":"[106.63593292,10.78106976] ; [106.63581085,10.78044987] ; [106.63555908,10.77958965] ; [106.63524628,10.77875996] ; [106.63516998,10.77855015]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3577"
    ,"Station_Code":"QTPT220"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Trạm Th ạch Lam"
    ,"Station_Address":"531, đường Lũy B án Bích, Quận Tân Phú"
    ,"Lat":10.776239395141602
    ,"Long":106.6336898803711
    ,"Polyline":"[106.63516998,10.77855015] ; [106.63487244,10.77789021] ; [106.63468933,10.77756023] ; [106.63436890,10.77709007] ; [106.63413239,10.77670002] ; [106.63377380,10.77618980]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3578"
    ,"Station_Code":"QTP 193"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trạm B ùi Thế Mỹ"
    ,"Station_Address":"425, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.773767
    ,"Long":106.632378
    ,"Polyline":"[106.63377380,10.77618980] ; [106.63308716,10.77515984] ; [106.63287354,10.77474976] ; [106.63269806,10.77439022] ; [106.63244629,10.77373981]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"3579"
    ,"Station_Code":"QTP 194"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Cây Keo"
    ,"Station_Address":"295-297 , đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.770796
    ,"Long":106.63179
    ,"Polyline":"[106.63244629,10.77373981] ; [106.63220978,10.77299023] ; [106.63210297,10.77237988] ; [106.63195038,10.77141953] ; [106.63185883,10.77079010]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1570"
    ,"Station_Code":"QTP 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Ngã 4  Hòa Bình"
    ,"Station_Address":"69, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769694
    ,"Long":106.633057
    ,"Polyline":"[106.63185883,10.77079010.06.63179779] ; [10.77029037,106.63313293]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1567"
    ,"Station_Code":"QTP 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Cây X ăng Hòa Bình"
    ,"Station_Address":"176/26, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769394
    ,"Long":106.63533
    ,"Polyline":"[106.63313293,10.76990032] ; [106.63390350,10.76963043] ; [106.63421631,10.76949978] ; [106.63432312,10.76947021] ; [106.63439941,10.76947975] ; [106.63446045,10.76947975] ; [106.63500977,10.76953030] ; [106.63530731,10.76955986]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1571"
    ,"Station_Code":"Q11 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Thuỷ Tạ"
    ,"Station_Address":"đd 90 (nhà hàng Thủy Tạ Đầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.768719
    ,"Long":106.637909
    ,"Polyline":"[106.63530731,10.76955986] ; [106.63571167,10.76959038] ; [106.63597870,10.76955986] ; [106.63630676,10.76949024] ; [106.63687134,10.76930046] ; [106.63793182,10.76887035] ; [106.63796234,10.76885033]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1569"
    ,"Station_Code":"Q11 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"7B (Bến xe bu ýt Đầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.767916
    ,"Long":106.639511
    ,"Polyline":"[106.63796234,10.76885033] ; [106.63893890,10.76850033] ; [106.63918304,10.76838970] ; [106.63963318,10.76807976]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"101"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"BÃI XE BU ÝT ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT  ĐẦM SEN, đường Hòa Bình, Quận 11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":"[106.63963318,10.76807976] ; [106.63961029,10.76809978]"
    ,"Distance":"65"
  }]