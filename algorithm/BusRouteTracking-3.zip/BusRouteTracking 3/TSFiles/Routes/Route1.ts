export const Route1 =[
  {
     "Route_Id":"1"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27, đường Tháp Mười, Quận  6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65222168,10.75123787] ; [106.65202332,10.75113773] ; [106.65194702,10.75102711] ; [106.65097046,10.75101185] ; [106.64955139,10.75115395] ; [106.64939117,10.74969387] ; [106.65100098,10.74996281] ; [106.65184784,10.75012112] ; [106.65255737,10.75023174] ; [106.65255737,10.75023174]"
    ,"Distance":"855"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"2393"
    ,"Station_Code":"Q6 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Tháp Mười"
    ,"Station_Address":"13C-13D, đường Tháp Mười, Quận 6"
    ,"Lat":10.750326
    ,"Long":106.653036
    ,"Polyline":"[106.65255737,10.75023174] ; [106.65303802,10.75032616]"
    ,"Distance":"54"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"2"
    ,"Station_Code":"Q5 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"11-12, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750732
    ,"Long":106.655075
    ,"Polyline":"[106.65303802,10.75032616] ; [106.65452576,10.75070572] ; [106.65475464,10.75080585] ; [106.65507507,10.75073242]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"14-16, đường  Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65507507,10.75073242] ; [106.65589905,10.75072670] ; [106.65647125,10.75079536] ; [106.65744019,10.75071621] ; [106.65901947,10.75066376] ; [106.65911102,10.75059509] ; [106.65921783,10.75058460] ; [106.65930939,10.75062656] ; [106.65935516,10.75071621] ; [106.65933228,10.75082684] ; [106.65927124,10.75092220] ; [106.65921783,10.75115967] ; [106.65920258,10.75136757]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"5"
    ,"Station_Code":"Q5 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"68, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752566
    ,"Long":106.658937
    ,"Polyline":"[106.65920258,10.75136757] ; [106.65893555,10.75256634]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"4"
    ,"Station_Code":"Q5 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Lương Nhữ Học"
    ,"Station_Address":"727, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.752962
    ,"Long":106.660418
    ,"Polyline":"[106.65893555,10.75256634] ; [106.65889740,10.75298786] ; [106.66041565,10.75296211]"
    ,"Distance":"214"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"7"
    ,"Station_Code":"Q5 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Triệu Quang Phục"
    ,"Station_Address":"695, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.753088
    ,"Long":106.662081
    ,"Polyline":"[106.66041565,10.75296211] ; [106.66207886,10.75308800]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"9"
    ,"Station_Code":"Q5 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Đại học Sư ph ạm Thể dục thể thao"
    ,"Station_Address":"639, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.753341
    ,"Long":106.663486
    ,"Polyline":"[106.66207886,10.75308800] ; [106.66287231,10.75327778] ; [106.66348267,10.75334072]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"12"
    ,"Station_Code":"Q5 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Siêu thị Điện máy Chợ Lớn"
    ,"Station_Address":"635B, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.753626
    ,"Long":106.664913
    ,"Polyline":"[106.66348267,10.75334072] ; [106.66414642,10.75349903] ; [106.66490936,10.75362587]"
    ,"Distance":"159"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"6"
    ,"Station_Code":"Q5 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngô Quyền"
    ,"Station_Address":"593, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.754
    ,"Long":106.666882
    ,"Polyline":"[106.66490936,10.75362587] ; [106.66590118,10.75383091] ; [106.66688538,10.75399971]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"10"
    ,"Station_Code":"Q5 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Chung cư Nguy ễn Trãi"
    ,"Station_Address":"549, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.754337
    ,"Long":106.668572
    ,"Polyline":"[106.66688538,10.75399971] ; [106.66777039,10.75421047] ; [106.66857147,10.75433731]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"11"
    ,"Station_Code":"Q5 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Siêu thị Điện  máy"
    ,"Station_Address":"99, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.754023
    ,"Long":106.669418
    ,"Polyline":"[106.66857147,10.75433731] ; [106.66857147,10.75433731] ; [106.66950226,10.75456333] ; [106.66941833,10.75402260] ; [106.66941833,10.75402260]"
    ,"Distance":"166"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"14"
    ,"Station_Code":"Q5 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà Văn hóa Quận 5"
    ,"Station_Address":"388, đường Trần Phú, Quận 5"
    ,"Lat":10.753025
    ,"Long":106.668588
    ,"Polyline":"[106.66941833,10.75402260] ; [106.66941833,10.75402260] ; [106.66944885,10.75344086] ; [106.66858673,10.75302505] ; [106.66858673,10.75302505]"
    ,"Distance":"170"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"16"
    ,"Station_Code":"Q5 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Đồng Khánh"
    ,"Station_Address":"41, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.752677
    ,"Long":106.670412
    ,"Polyline":"[106.66858673,10.75302505] ; [106.66858673,10.75302505] ; [106.66774750,10.75253963] ; [106.66938019,10.75265598] ; [106.67041016,10.75267696] ; [106.67041016,10.75267696]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"17"
    ,"Station_Code":"Q5 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"An Bình"
    ,"Station_Address":"1149, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.752977
    ,"Long":106.672837
    ,"Polyline":"[106.67041016,10.75267696] ; [106.67105103,10.75276661] ; [106.67214203,10.75285053] ; [106.67283630,10.75297737]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"13"
    ,"Station_Code":"Q5 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Rạp Đồng Tháp"
    ,"Station_Address":"981 , đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.753784
    ,"Long":106.675937
    ,"Polyline":"[106.67283630,10.75297737] ; [106.67283630,10.75297737] ; [106.67440796,10.75340462] ; [106.67593384,10.75378418] ; [106.67593384,10.75378418]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"15"
    ,"Station_Code":"Q5 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Chấn Thương Chỉnh hình"
    ,"Station_Address":"929, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.754421
    ,"Long":106.678271
    ,"Polyline":"[106.67593384,10.75378418] ; [106.67703247,10.75411606] ; [106.67826843,10.75442123]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"19"
    ,"Station_Code":"Q5 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trần Bình Tr ọng"
    ,"Station_Address":"813, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.754912
    ,"Long":106.680041
    ,"Polyline":"[106.67826843,10.75442123] ; [106.67826843,10.75442123] ; [106.67913055,10.75467968] ; [106.68003845,10.75491238] ; [106.68003845,10.75491238]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"20"
    ,"Station_Code":"Q5 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nguyễn Biểu"
    ,"Station_Address":"651, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.756066
    ,"Long":106.68437
    ,"Polyline":"[106.68003845,10.75491238] ; [106.68437195,10.75606632]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"18"
    ,"Station_Code":"Q1 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Nanci"
    ,"Station_Address":"563-565, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.75699
    ,"Long":106.685883
    ,"Polyline":"[106.68437195,10.75606632] ; [106.68525696,10.75639820] ; [106.68588257,10.75699043]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"22"
    ,"Station_Code":"Q1 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Tổng Cty Samco"
    ,"Station_Address":"449, đường Trần Hưng Đạo , Quận 1"
    ,"Lat":10.759426
    ,"Long":106.688011
    ,"Polyline":"[106.68588257,10.75699043] ; [106.68801117,10.75942612]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"21"
    ,"Station_Code":"Q1 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Sở PCCC"
    ,"Station_Address":"359, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.760656
    ,"Long":106.689096
    ,"Polyline":"[106.68801117,10.75942612] ; [106.68909454,10.76065636]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"23"
    ,"Station_Code":"Q1 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Hồ Hảo Hớn"
    ,"Station_Address":"301F, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.762395
    ,"Long":106.690636
    ,"Polyline":"[106.68909454,10.76065636] ; [106.69063568,10.76239491]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"24"
    ,"Station_Code":"Q1 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bệnh Viện R ăng Hàm Mặt"
    ,"Station_Address":"263, đường Tr ần Hưng Đạo, Quận 1"
    ,"Lat":10.763567
    ,"Long":106.691612
    ,"Polyline":"[106.69063568,10.76239491] ; [106.69161224,10.76356697]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"25"
    ,"Station_Code":"Q1 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Rạp Trần Hưng Đạo"
    ,"Station_Address":"227 - 229, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765213
    ,"Long":106.693069
    ,"Polyline":"[106.69161224,10.76356697] ; [106.69306946,10.76521301]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"26"
    ,"Station_Code":"Q1 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"135, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767064
    ,"Long":106.694824
    ,"Polyline":"[106.69306946,10.76521301] ; [106.69306946,10.76521301] ; [106.69454956,10.76687431] ; [106.69482422,10.76706409] ; [106.69482422,10.76706409]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"27"
    ,"Station_Code":"Q1 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"71C, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768327
    ,"Long":106.695847
    ,"Polyline":"[106.69482422,10.76706409] ; [106.69482422,10.76706409] ; [106.69502258,10.76739597] ; [106.69584656,10.76832676] ; [106.69584656,10.76832676]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69584656,10.76832676] ; [106.69744110,10.77022076] ; [106.69844818,10.77054024]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69921112,10.77097511] ; [106.69956207,10.77094269]"
    ,"Distance":"135"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm  Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77094269] ; [106.70195770,10.77082157]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70407104,10.77072239]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"Bến thủy nội địa Thủ Thiêm, đường Tôn  Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70407104,10.77072239] ; [106.70454407,10.77069569] ; [106.70513916,10.76943016] ; [106.70533752,10.76943016] ; [106.70589447,10.76954651] ; [106.70611572,10.76965237] ; [106.70623779,10.76989937] ; [106.70635986,10.77037430] ; [106.70636749,10.77057934] ; [106.70636749,10.77079010.06.70645905] ; [10.77232361,106.70664978]"
    ,"Distance":"795"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"34"
    ,"Station_Code":"Q1 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"2, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.776048
    ,"Long":106.705719
    ,"Polyline":"[106.70664978,10.77387810.06.70666504] ; [10.77486897,106.70671082] ; [10.77536488,106.70672607] ; [10.77561188,106.70666504] ; [10.77585983,106.70630646] ; [10.77584934,106.70605469] ; [10.77569675,106.70571899]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"33"
    ,"Station_Code":"BX 06"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Công Trường  Mê Linh"
    ,"Station_Address":"Công trường Mê Linh, đường Thi Sách, Quận 1"
    ,"Lat":10.77679
    ,"Long":106.705856
    ,"Polyline":"[106.70571899,10.77604771] ; [106.70510101,10.77655029] ; [106.70575714,10.77721977] ; [106.70585632,10.77678967]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"33"
    ,"Station_Code":"BX 06"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"Công trường Mê Linh, đường Thi  Sách, Quận 1"
    ,"Lat":10.77679
    ,"Long":106.705856
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn Đức Thắng, Qu ận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70585632,10.77678967] ; [106.70629120,10.77581787] ; [106.70614624,10.77576542] ; [106.70605469,10.77569103] ; [106.70595551,10.77552223] ; [106.70594788,10.77534389] ; [106.70597076,10.77518559] ; [106.70603180,10.77501678] ; [106.70626831,10.77483749] ; [106.70648193,10.77477455] ; [106.70635986,10.77329922]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cục Hải Quan Thành Phố"
    ,"Station_Address":"2-4, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70635986,10.77329922] ; [106.70621490,10.77102184] ; [106.70616150,10.77092743] ; [106.70605469,10.77086449] ; [106.70555115,10.77088547]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84, đường Hàm Nghi , Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70555115,10.77088547] ; [106.70302582,10.77097988]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70302582,10.77097988] ; [106.70166016,10.77104759]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70166016,10.77104759] ; [106.69935608,10.77116299]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"118"
    ,"Station_Code":"Q1TC1B"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bến Thành  B"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77084
    ,"Long":106.698532
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69912720,10.77113247] ; [106.69895172,10.77103806] ; [106.69853210,10.77083969]"
    ,"Distance":"98"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"120"
    ,"Station_Code":"Q1 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"8, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768772
    ,"Long":106.695923
    ,"Polyline":"[106.69853210,10.77083969] ; [106.69739532,10.77031040] ; [106.69592285,10.76877213]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"121"
    ,"Station_Code":"Q1 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"10,  đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767363
    ,"Long":106.694695
    ,"Polyline":"[106.69592285,10.76877213] ; [106.69469452,10.76736259]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"122"
    ,"Station_Code":"Q1 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Rạp Hưng Đạo"
    ,"Station_Address":"112, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765832
    ,"Long":106.693375
    ,"Polyline":"[106.69469452,10.76736259] ; [106.69337463,10.76583195]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"123"
    ,"Station_Code":"Q1 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Bệnh viện Răng Hàm Mặt"
    ,"Station_Address":"150, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.763918
    ,"Long":106.691696
    ,"Polyline":"[106.69337463,10.76583195] ; [106.69169617,10.76391792]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"124"
    ,"Station_Code":"Q1 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"210 - 212 , đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.762262
    ,"Long":106.690247
    ,"Polyline":"[106.69169617,10.76391792] ; [106.69024658,10.76226234]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"125"
    ,"Station_Code":"Q1 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Tổng Cty Samco"
    ,"Station_Address":"262, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.759409
    ,"Long":106.687798
    ,"Polyline":"[106.69024658,10.76226234] ; [106.68779755,10.75940895]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"126"
    ,"Station_Code":"Q1 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Nanci"
    ,"Station_Address":"290, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.757467
    ,"Long":106.686035
    ,"Polyline":"[106.68779755,10.75940895] ; [106.68603516,10.75746727]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"127"
    ,"Station_Code":"Q5 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nguyễn Biểu"
    ,"Station_Address":"454, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.755887
    ,"Long":106.68283
    ,"Polyline":"[106.68603516,10.75746727] ; [106.68603516,10.75746727] ; [106.68521118,10.75650883] ; [106.68283081,10.75588703] ; [106.68283081,10.75588703]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"128"
    ,"Station_Code":"Q5 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Cao đẳng Kinh tế Đối ngoại"
    ,"Station_Address":"520, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.755623
    ,"Long":106.681833
    ,"Polyline":"[106.68283081,10.75588703] ; [106.68183136,10.75562286]"
    ,"Distance":"113"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"129"
    ,"Station_Code":"Q5 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trần Bình Trọng"
    ,"Station_Address":"564, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.755064
    ,"Long":106.679794
    ,"Polyline":"[106.68183136,10.75562286] ; [106.67979431,10.75506401]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"130"
    ,"Station_Code":"Q5 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Ch ấn thương Chỉnh hình"
    ,"Station_Address":"696 , đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.754537
    ,"Long":106.677847
    ,"Polyline":"[106.67979431,10.75506401] ; [106.67784882,10.75453663]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"131"
    ,"Station_Code":"Q5 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Rạp Đồng Tháp"
    ,"Station_Address":"780, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.753984
    ,"Long":106.675825
    ,"Polyline":"[106.67784882,10.75453663] ; [106.67582703,10.75398445]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"134"
    ,"Station_Code":"Q5 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Rạp Đống Đa"
    ,"Station_Address":"882, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.753573
    ,"Long":106.674237
    ,"Polyline":"[106.67582703,10.75398445] ; [106.67424011,10.75357342]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"132"
    ,"Station_Code":"Q5 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đồng Khánh"
    ,"Station_Address":"18, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.752983
    ,"Long":106.67149
    ,"Polyline":"[106.67424011,10.75357342] ; [106.67424011,10.75357342] ; [106.67202759,10.75300407] ; [106.67149353,10.75298309] ; [106.67149353,10.75298309]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"14"
    ,"Station_Code":"Q5 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà Văn hóa Quận 5"
    ,"Station_Address":"388, đường Trần Ph ú, Quận 5"
    ,"Lat":10.753025
    ,"Long":106.668588
    ,"Polyline":"[106.67149353,10.75298309] ; [106.66946411,10.75272465] ; [106.66952515,10.75345707] ; [106.66858673,10.75302505]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"136"
    ,"Station_Code":"Q5 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngô Quyền"
    ,"Station_Address":"212, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.752477
    ,"Long":106.666174
    ,"Polyline":"[106.66858673,10.75302505] ; [106.66858673,10.75302505] ; [106.66774750,10.75257206] ; [106.66617584,10.75247669] ; [106.66617584,10.75247669]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"133"
    ,"Station_Code":"Q5 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Tản Đà"
    ,"Station_Address":"274, đường Trần  Hưng Đạo, Quận 5"
    ,"Lat":10.752292
    ,"Long":106.663706
    ,"Polyline":"[106.66617584,10.75247669] ; [106.66370392,10.75229168]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"135"
    ,"Station_Code":"Q5 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Triệu Quang Phục"
    ,"Station_Address":"346, đường Trần Hưng Đạo, Quận 5"
    ,"Lat":10.752161
    ,"Long":106.662017
    ,"Polyline":"[106.66370392,10.75229168] ; [106.66201782,10.75216103]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.66201782,10.75216103] ; [106.66201782,10.75216103] ; [106.66139984,10.75210762] ; [106.65884399,10.75203896] ; [106.65889740,10.75138092] ; [106.65889740,10.75138092]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"138"
    ,"Station_Code":"Q5 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Hải Thượng Lãn Ông"
    ,"Station_Address":"210-212, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750948
    ,"Long":106.658358
    ,"Polyline":"[106.65889740,10.75138092] ; [106.65908813,10.75084305] ; [106.65835571,10.75094795]"
    ,"Distance":"144"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"139"
    ,"Station_Code":"Q5 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"5, đường Trang Tử, Quận 5"
    ,"Lat":10.751128
    ,"Long":106.655086
    ,"Polyline":"[106.65835571,10.75094795] ; [106.65799713,10.75094795] ; [106.65733337,10.75099564] ; [106.65645599,10.75107002] ; [106.65594482,10.75106430] ; [106.65548706,10.75109100] ; [106.65524292,10.75111675] ; [106.65508270,10.75112820]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"1"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung,  Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65508270,10.75112820] ; [106.65508270,10.75112820] ; [106.65386963,10.75115395] ; [106.65341949,10.75160694] ; [106.65335083,10.75166035] ; [106.65324402,10.75166035] ; [106.65296936,10.75132275] ; [106.65256500,10.75125313]"
    ,"Distance":"318"
  }]