export const Route11 =[

  {
     "Route_Id":"11"
    ,"Station_Id":"771"
    ,"Station_Code":"QCCT206"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Cầu Tân Thái"
    ,"Station_Address":"Đối diện 87, đường Tỉnh lộ 7, Huyện Củ Chi"
    ,"Lat":10.992086410522461
    ,"Long":106.37188720703125
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"772"
    ,"Station_Code":"HCC 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 3 Dương Văn Lầu"
    ,"Station_Address":"108, đường Ti ̉nh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.99375
    ,"Long":106.374535
    ,"Polyline":"[106.37188721,10.99208641] ; [106.37263489,10.99385643] ; [106.37453461,10.99374962]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"774"
    ,"Station_Code":"HCC 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Kim Tiền"
    ,"Station_Address":"186, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.993333
    ,"Long":106.379936
    ,"Polyline":"[106.37453461,10.99374962] ; [106.37993622,10.99333286]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"773"
    ,"Station_Code":"HCC 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ông Cống"
    ,"Station_Address":"252, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.992433
    ,"Long":106.3853
    ,"Polyline":"[106.37993622,10.99333286] ; [106.38481903,10.99256039] ; [106.38529968,10.99243259]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"776"
    ,"Station_Code":"QCCT210"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Đông Dương"
    ,"Station_Address":"Đối diện 299, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.991783142089844
    ,"Long":106.38945007324219
    ,"Polyline":"[106.38529968,10.99243259] ; [106.38818359,10.99203014] ; [106.38945007,10.99178314]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"775"
    ,"Station_Code":"HCC 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trương Thị Kiện"
    ,"Station_Address":"326, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.991267
    ,"Long":106.393181
    ,"Polyline":"[106.38945007,10.99178314] ; [106.39144135,10.99147987] ; [106.39250946,10.99129009] ; [106.39318085,10.99126720]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"777"
    ,"Station_Code":"HCC 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ấp văn hóa Bình Thuận"
    ,"Station_Address":"402, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.99125
    ,"Long":106.399315
    ,"Polyline":"[106.39318085,10.99126720] ; [106.39601135,10.99125957] ; [106.39907837,10.99125957] ; [106.39931488,10.99125004]"
    ,"Distance":"670"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"778"
    ,"Station_Code":"HCC 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm y tế Thái Mỹ"
    ,"Station_Address":"480, đường Tỉnh lộ 7 Củ Chi, Huyện  Củ Chi"
    ,"Lat":10.99115
    ,"Long":106.405479
    ,"Polyline":"[106.40122986,10.99127960] ; [106.40441132,10.99127007] ; [106.40515137,10.99122047]"
    ,"Distance":"675"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"780"
    ,"Station_Code":"QCCT214"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Nguyễn Văn Sơ"
    ,"Station_Address":"530, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.991032600402832
    ,"Long":106.41093444824219
    ,"Polyline":"[106.40547943,10.99114990] ; [106.40728760,10.99108028] ; [106.40975952,10.99090958] ; [106.41078186,10.99084377] ; [106.41093445,10.99103260]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"779"
    ,"Station_Code":"HCC 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường mẫu giáo"
    ,"Station_Address":"Đối diện 599, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.992946
    ,"Long":106.414383
    ,"Polyline":"[106.41093445,10.99103260] ; [106.41438293,10.99294567]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"786"
    ,"Station_Code":"HCC 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Minh Hà"
    ,"Station_Address":"608A, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.99415
    ,"Long":106.416519
    ,"Polyline":"[106.41438293,10.99294567] ; [106.41651917,10.99415016]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"781"
    ,"Station_Code":"HCC 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm xăng 59"
    ,"Station_Address":"Xăng dầu 59,  đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.00035
    ,"Long":106.422363
    ,"Polyline":"[106.41793060,10.99501038] ; [106.42043304,10.99645996] ; [106.42050934,10.99650955] ; [106.42089844,10.99755001] ; [106.42102051,10.99777985]"
    ,"Distance":"983"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"782"
    ,"Station_Code":"HCC 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Út Sơ"
    ,"Station_Address":"782, đường Ti ̉nh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.004783
    ,"Long":106.4263
    ,"Polyline":"[106.42236328,11.00035000] ; [106.42426300,11.00392437] ; [106.42630005,11.00478268]"
    ,"Distance":"691"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"790"
    ,"Station_Code":"HCC 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm y tế xã Phước Thạnh"
    ,"Station_Address":"Trạm y tế xã Phước Thạnh ( Đối diện 830 ), đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":11.005567
    ,"Long":106.428069
    ,"Polyline":"[106.42630005,11.00478268] ; [106.42713165,11.00513077] ; [106.42742920,11.00593090] ; [106.42808533,11.00564957]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"784"
    ,"Station_Code":"HCC 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Xã Phước Hiệp"
    ,"Station_Address":"585 , đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.996617
    ,"Long":106.44487
    ,"Polyline":"[106.42808533,11.00564957] ; [106.43528748,11.00329304] ; [106.44228363,10.99937439] ; [106.44487000,10.99661732]"
    ,"Distance":"2127"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"792"
    ,"Station_Code":"HCC 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường tiểu  học Phước Hiệp"
    ,"Station_Address":"499, đư ờng Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.9928
    ,"Long":106.448334
    ,"Polyline":"[106.44487000,10.99661732] ; [106.44833374,10.99279976]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"794"
    ,"Station_Code":"HCC 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 3 Cây Trôm"
    ,"Station_Address":"Trạm y tế Nguyễn Thị Rành, đường Quốc  lộ 22, Huyện Củ Chi"
    ,"Lat":10.989567
    ,"Long":106.451263
    ,"Polyline":"[106.44833374,10.99279976] ; [106.45126343,10.98956680]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"785"
    ,"Station_Code":"HCC 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cây xăng Phước Hiệp 1"
    ,"Station_Address":"281, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.982883
    ,"Long":106.461014
    ,"Polyline":"[106.45126343,10.98956680] ; [106.46101379,10.98288345]"
    ,"Distance":"1300"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"796"
    ,"Station_Code":"HCC 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Công ty sinh hóa Củ Chi"
    ,"Station_Address":"121, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.977784
    ,"Long":106.469632
    ,"Polyline":"[106.46101379,10.98288345] ; [106.46965027,10.97784996]"
    ,"Distance":"1098"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"787"
    ,"Station_Code":"HCC 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã 3 Nguyễn Thị Rành"
    ,"Station_Address":"55, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.976109
    ,"Long":106.472717
    ,"Polyline":"[106.46965027,10.97784996] ; [106.47273254,10.97614956]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"788"
    ,"Station_Code":"HCC 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Bệnh viện Củ Chi"
    ,"Station_Address":"991, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.973655
    ,"Long":106.477443
    ,"Polyline":"[106.47273254,10.97614956] ; [106.47747040,10.97373295]"
    ,"Distance":"583"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"963"
    ,"Station_Code":"HCC 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bệnh vi ện Củ Chi"
    ,"Station_Address":"907, đường Qu ốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.972091
    ,"Long":106.48049
    ,"Polyline":"[106.47747040,10.97373295] ; [106.48051453,10.97213268]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":"[106.48051453,10.97213268] ; [106.48102570,10.97177505] ; [106.48171997,10.97117519] ; [106.48210144,10.97161674]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"734"
    ,"Station_Code":"HCC 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"926, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.972533
    ,"Long":106.480347
    ,"Polyline":"[106.48210144,10.97161674] ; [106.48178101,10.97131157] ; [106.48034668,10.97253323]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"733"
    ,"Station_Code":"HCC 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Bệnh viện Củ Chi"
    ,"Station_Address":"18, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.974417
    ,"Long":106.476402
    ,"Polyline":"[106.48034668,10.97253323] ; [106.47640228,10.97441673]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"738"
    ,"Station_Code":"HCC 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm xăng"
    ,"Station_Address":"86, đường Quốc lộ 22, Huy ện Củ Chi"
    ,"Lat":10.976133
    ,"Long":106.473129
    ,"Polyline":"[106.47640228,10.97441673] ; [106.47640228,10.97441673] ; [106.47583771,10.97461987] ; [106.47341919,10.97589970] ; [106.47312927,10.97613335] ; [106.47312927,10.97613335]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"735"
    ,"Station_Code":"HCC 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà máy Sinh hóa Củ Chi"
    ,"Station_Address":"128, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.978179
    ,"Long":106.469455
    ,"Polyline":"[106.47312927,10.97613335] ; [106.46943665,10.97816658]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"741"
    ,"Station_Code":"HCC 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trạm xăng Phước Hiệp 1"
    ,"Station_Address":"282, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.98305
    ,"Long":106.461232
    ,"Polyline":"[106.46943665,10.97816658] ; [106.46116638,10.98296738]"
    ,"Distance":"1050"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"736"
    ,"Station_Code":"HCC 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trạm y tế Nguyễn Thị Rành"
    ,"Station_Address":"Đối diện trạm y tế Nguyễn Thị Rành, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.991035
    ,"Long":106.450378
    ,"Polyline":"[106.45317841,10.98816967] ; [106.45253754,10.98861027] ; [106.45195007,10.98906040] ; [106.45111847,10.98991966] ; [106.45024109,10.99090958]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"743"
    ,"Station_Code":"HCC 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã 3 Ba Sa"
    ,"Station_Address":"508, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.993072
    ,"Long":106.448448
    ,"Polyline":"[106.45037842,10.99103546] ; [106.44837952,10.99295044]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"737"
    ,"Station_Code":"HCC 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây xăng  Phước Thạnh 2"
    ,"Station_Address":"580, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.996789
    ,"Long":106.445058
    ,"Polyline":"[106.44837952,10.99295044] ; [106.44631958,10.99518967] ; [106.44515228,10.99648952] ; [106.44496918,10.99673271]"
    ,"Distance":"563"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"745"
    ,"Station_Code":"HCC 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"UBND xã Phước Thạnh"
    ,"Station_Address":"UBND xã Phước Thạnh, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":11.00463
    ,"Long":106.431969
    ,"Polyline":"[106.44336700,10.99845028] ; [106.44286346,10.99899960] ; [106.44242859,10.99940014] ; [106.44203949,10.99971008] ; [106.44156647,11.00002956] ; [106.44090271,11.00041008] ; [106.43900299,11.00142956] ; [106.43641663,11.00282001] ; [106.43560028,11.00325012] ; [106.43491364,11.00356007] ; [106.43373871,11.00397015]"
    ,"Distance":"1227"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"739"
    ,"Station_Code":"QCCT028"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Phước Thạnh"
    ,"Station_Address":"892, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":11.005766868591309
    ,"Long":106.42814636230469
    ,"Polyline":"[106.43373871,11.00397015] ; [106.42878723,11.00553036]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"746"
    ,"Station_Code":"HCC 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Cổng chào"
    ,"Station_Address":"771 , đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.005048
    ,"Long":106.426697
    ,"Polyline":"[106.42814636,11.00576687] ; [106.42739105,11.00597954] ; [106.42716217,11.00535011] ; [106.42704773,11.00516987] ; [106.42669678,11.00504780]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"789"
    ,"Station_Code":"HCC 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường Quang  Trung"
    ,"Station_Address":"Đối diện trường PTTH Quang Trung, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.0029
    ,"Long":106.423553
    ,"Polyline":"[106.42669678,11.00504780] ; [106.42427063,11.00393486] ; [106.42355347,11.00290012]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"742"
    ,"Station_Code":"HCC 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà thờ"
    ,"Station_Address":"Đối diện xăng dầu 59, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.998549
    ,"Long":106.421326
    ,"Polyline":"[106.42355347,11.00290012] ; [106.42226410,10.99967003] ; [106.42132568,10.99854946]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"748"
    ,"Station_Code":"HCC 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Minh Hà"
    ,"Station_Address":"631, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.993867
    ,"Long":106.415817
    ,"Polyline":"[106.42132568,10.99854946] ; [106.42137909,10.99847031] ; [106.42110443,10.99758434] ; [106.42095947,10.99701595] ; [106.42050934,10.99650955] ; [106.41864014,10.99542046] ; [106.41581726,10.99386692]"
    ,"Distance":"845"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"750"
    ,"Station_Code":"HCC 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Nguyễn Văn Sơ"
    ,"Station_Address":"593, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.992767
    ,"Long":106.413902
    ,"Polyline":"[106.41581726,10.99386692] ; [106.41496277,10.99332047] ; [106.41390228,10.99276733]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"744"
    ,"Station_Code":"HCC 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Xã Thái Mỹ"
    ,"Station_Address":"553, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.990917
    ,"Long":106.409935
    ,"Polyline":"[106.41390228,10.99276733] ; [106.41233063,10.99184036] ; [106.41059113,10.99087048] ; [106.41014862,10.99088001] ; [106.40993500,10.99091721]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"752"
    ,"Station_Code":"HCC 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ấp Bình Thượng 1"
    ,"Station_Address":"493, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.991251
    ,"Long":106.405235
    ,"Polyline":"[106.40902710,10.99096012] ; [106.40576172,10.99118996]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"754"
    ,"Station_Code":"HCC 152"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trương Thị Kiện 2"
    ,"Station_Address":"399A, đường Tỉnh lộ 7 Củ Chi , Huyện Củ Chi"
    ,"Lat":10.991267
    ,"Long":106.398468
    ,"Polyline":"[106.40523529,10.99125099] ; [106.40441132,10.99127007] ; [106.40090942,10.99127007] ; [106.40045166,10.99127007] ; [106.39846802,10.99126720]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"756"
    ,"Station_Code":"HCC 153"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đông Dương"
    ,"Station_Address":"337A, đường Tỉnh  lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.991308
    ,"Long":106.393829
    ,"Polyline":"[106.39846802,10.99126720] ; [106.39646149,10.99125957] ; [106.39382935,10.99130821]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"747"
    ,"Station_Code":"HCC 154"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã 3 Ông Cống"
    ,"Station_Address":"305, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.991721
    ,"Long":106.390312
    ,"Polyline":"[106.39382935,10.99130821] ; [106.39250946,10.99129009] ; [106.39186859,10.99139977] ; [106.39031219,10.99172115]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"749"
    ,"Station_Code":"HCC 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Kim Tiền"
    ,"Station_Address":"253, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.992471
    ,"Long":106.385681
    ,"Polyline":"[106.39031219,10.99172115] ; [106.38986969,10.99176025] ; [106.38884735,10.99192047] ; [106.38568115,10.99247074]"
    ,"Distance":"513"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"758"
    ,"Station_Code":"HCC 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Dương Lầu"
    ,"Station_Address":"179, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.99345
    ,"Long":106.379433
    ,"Polyline":"[106.38568115,10.99247074] ; [106.38529205,10.99248981] ; [106.37943268,10.99345016]"
    ,"Distance":"692"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"751"
    ,"Station_Code":"HCC 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Dương Văn Lầu"
    ,"Station_Address":"Đối diện 96, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.9938
    ,"Long":106.374397
    ,"Polyline":"[106.37943268,10.99345016] ; [106.37439728,10.99380016]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"11"
    ,"Station_Id":"760"
    ,"Station_Code":"HCC 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Tỉnh lộ 6"
    ,"Station_Address":"97, đường T ỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":10.993782
    ,"Long":106.371063
    ,"Polyline":"[106.37439728,10.99380016] ; [106.37106323,10.99378204]"
    ,"Distance":"364"
  }]