export const Route114 =[

  {
     "Route_Id":"114"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huy ện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1387"
    ,"Station_Code":"HCC 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Tỉnh lộ 7"
    ,"Station_Address":"607 , đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.967041
    ,"Long":106.48903
    ,"Polyline":"[106.48226166,10.97154999] ; [106.48220062,10.97148037] ; [106.48210144,10.97142029] ; [106.48197937,10.97140026] ; [106.48181152,10.97138977] ; [106.48175049,10.97136021] ; [106.48169708,10.97130013] ; [106.48171234,10.97119999] ; [106.48179626,10.97111034] ; [106.48238373,10.97064018] ; [106.48377991,10.96965027] ; [106.48397064,10.96947956] ; [106.48429871,10.96924973] ; [106.48493195,10.96887016] ; [106.48567200,10.96842957] ; [106.48581696,10.96829987] ; [106.48596191,10.96819019] ; [106.48612976,10.96817970] ; [106.48735809,10.96770954] ; [106.48777008,10.96757984]"
    ,"Distance":"865"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3650"
    ,"Station_Code":"HCC 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Quán Tư R âu"
    ,"Station_Address":"517, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.965524
    ,"Long":106.492994
    ,"Polyline":"[106.48777008,10.96757984] ; [106.48816681,10.96747971] ; [106.48885345,10.96724033] ; [106.49011230,10.96677017] ; [106.49182129,10.96611023]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3652"
    ,"Station_Code":"HCC 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Xuân Quế"
    ,"Station_Address":"457, đường Quốc lộ 22, Huy ện Củ Chi"
    ,"Lat":10.963449
    ,"Long":106.49735
    ,"Polyline":"[106.49182129,10.96611023] ; [106.49282837,10.96570969] ; [106.49446869,10.96506023] ; [106.49529266,10.96471024] ; [106.49582672,10.96442986] ; [106.49593353,10.96440029] ; [106.49662781,10.96397972] ; [106.49745178,10.96350956]"
    ,"Distance":"681"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1383"
    ,"Station_Code":"HCC 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà thiếu nhi Củ Chi"
    ,"Station_Address":"Nhà thiếu nhi Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.959167
    ,"Long":106.50515
    ,"Polyline":"[106.49745178,10.96350956] ; [106.50052643,10.96172047] ; [106.50166321,10.96107960] ; [106.50247192,10.96065044] ; [106.50273895,10.96049976]"
    ,"Distance":"668"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3649"
    ,"Station_Code":"HCC 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Sài Gòn Cáp"
    ,"Station_Address":"299, đường Quốc lộ 22, Huy ện Củ Chi"
    ,"Lat":10.956818
    ,"Long":106.509694
    ,"Polyline":"[106.50273895,10.96049976] ; [106.50653076,10.95855999] ; [106.50898743,10.95730019] ; [106.51039124,10.95654011] ; [106.51136780,10.95592022] ; [106.51216888,10.95538044] ; [106.51300812,10.95479965] ; [106.51515961,10.95335007]"
    ,"Distance":"1576"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3651"
    ,"Station_Code":"HCC 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Cây Dương"
    ,"Station_Address":"223, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.953068
    ,"Long":106.515434
    ,"Polyline":"[106.51515961,10.95335007] ; [106.51885986,10.95081997]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3653"
    ,"Station_Code":"HCC 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Hồng Đào"
    ,"Station_Address":"157, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.950651
    ,"Long":106.518974
    ,"Polyline":"[106.51885986,10.95081997] ; [106.52230072,10.94847012]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3654"
    ,"Station_Code":"HCC 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã tư Quân Đội"
    ,"Station_Address":"97, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.947954
    ,"Long":106.522923
    ,"Polyline":"[106.52230072,10.94847012] ; [106.52382660,10.94742966] ; [106.52480316,10.94678974] ; [106.52580261,10.94626045] ; [106.52793884,10.94521999] ; [106.52835083,10.94501972]"
    ,"Distance":"766"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3655"
    ,"Station_Code":"HCC 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Đường 84"
    ,"Station_Address":"Đối diện 455A (Đ/d 450), đường Quốc lộ 22 , Huyện Củ Chi"
    ,"Lat":10.943678
    ,"Long":106.530776
    ,"Polyline":"[106.52835083,10.94501972] ; [106.53191376,10.94332027] ; [106.53244781,10.94309044] ; [106.53343964,10.94260025]"
    ,"Distance":"618"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3656"
    ,"Station_Code":"HCC 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thờ xuyên Lộc"
    ,"Station_Address":"351, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.941083
    ,"Long":106.536346
    ,"Polyline":"[106.53343964,10.94260025] ; [106.53791046,10.94042969]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1384"
    ,"Station_Code":"HCC 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"trường THCS Tân Phú Trung"
    ,"Station_Address":"Đối diện Trường Tân Phú Trung, đ ường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.93925
    ,"Long":106.540154
    ,"Polyline":"[106.53791046,10.94042969] ; [106.54200745,10.93844986]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3657"
    ,"Station_Code":"HCC 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Nhà thờ Bắc Đoàn"
    ,"Station_Address":"215, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.937505
    ,"Long":106.54371
    ,"Polyline":"[106.54200745,10.93844986] ; [106.54440308,10.93729019]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1391"
    ,"Station_Code":"HCC 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Mũi Tàu Tân Phú"
    ,"Station_Address":"135, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.9345
    ,"Long":106.549934
    ,"Polyline":"[106.54440308,10.93729019] ; [106.54676056,10.93614960] ; [106.54840851,10.93535995] ; [106.54910278,10.93500042] ; [106.54927826,10.93490982]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3658"
    ,"Station_Code":"HCC 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Chiếu"
    ,"Station_Address":"85C, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.931917
    ,"Long":106.552808
    ,"Polyline":"[106.54927826,10.93490982] ; [106.54998016,10.93457985] ; [106.55075073,10.93408966] ; [106.55101013,10.93391991] ; [106.55135345,10.93360996] ; [106.55197906,10.93297958] ; [106.55300140,10.93185043] ; [106.55368042,10.93111992]"
    ,"Distance":"646"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3660"
    ,"Station_Code":"HCC 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trạm xăng Ngọc Sương"
    ,"Station_Address":"Đối  diện cây xăng Ngọc Sương, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.928133
    ,"Long":106.555969
    ,"Polyline":"[106.55368042,10.93111992] ; [106.55403900,10.93072987] ; [106.55451965,10.93019962] ; [106.55502319,10.92957973] ; [106.55577850,10.92852020] ; [106.55658722,10.92737961] ; [106.55699158,10.92679024] ; [106.55870056,10.92436981] ; [106.55895996,10.92399979]"
    ,"Distance":"981"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1388"
    ,"Station_Code":"HHM 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu An Hạ"
    ,"Station_Address":"Giáo xứ Tân Thịnh, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.916294
    ,"Long":106.563708
    ,"Polyline":"[106.55895996,10.92399979] ; [106.55995178,10.92257977] ; [106.56098175,10.92109013] ; [106.56327820,10.91779041] ; [106.56387329,10.91691971] ; [106.56374359,10.91681957] ; [106.56324768,10.91656971]"
    ,"Distance":"1031"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1389"
    ,"Station_Code":"HHM 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công ty thoát nước đô thị"
    ,"Station_Address":"Đối diện Cty thoát nước đô thị, đường Quốc lộ  22, Huyện Hóc Môn"
    ,"Lat":10.911801
    ,"Long":106.567345
    ,"Polyline":"[106.56324768,10.91656971] ; [106.56374359,10.91681957] ; [106.56387329,10.91691971] ; [106.56427765,10.91635036] ; [106.56474304,10.91571045] ; [106.56566620,10.91438007] ; [106.56736755,10.91195965]"
    ,"Distance":"750"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1390"
    ,"Station_Code":"HHM 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 3 Hồng Châu"
    ,"Station_Address":"1/147, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.898163
    ,"Long":106.576899
    ,"Polyline":"[106.56736755,10.91195965] ; [106.57068634,10.90719032] ; [106.57290649,10.90402031] ; [106.57405853,10.90242004] ; [106.57473755,10.90143967] ; [106.57540894,10.90048981] ; [106.57572174,10.90003014] ; [106.57698822,10.89822006]"
    ,"Distance":"1856"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3659"
    ,"Station_Code":"HHM 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Thành"
    ,"Station_Address":"48/10A, đường  Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.895788
    ,"Long":106.578568
    ,"Polyline":"[106.57698822,10.89822006] ; [106.57865143,10.89585972]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1393"
    ,"Station_Code":"HHM 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Nguyễn Ảnh Thủ"
    ,"Station_Address":"30/10B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854628
    ,"Long":106.607476
    ,"Polyline":"[106.57865143,10.89585972] ; [106.57997894,10.89396000] ; [106.58090973,10.89260006] ; [106.58135986,10.89196968]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"2328"
    ,"Station_Code":"HHM 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bích Phương"
    ,"Station_Address":"64/4, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.886943
    ,"Long":106.584758
    ,"Polyline":"[106.58135986,10.89196968] ; [106.58258820,10.89023018] ; [106.58371735,10.88860989] ; [106.58482361,10.88702011]"
    ,"Distance":"668"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1395"
    ,"Station_Code":"HHM 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà hàng Hương Cau"
    ,"Station_Address":"47/6, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.883018
    ,"Long":106.587424
    ,"Polyline":"[106.58482361,10.88702011] ; [106.58754730,10.88311005]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1230"
    ,"Station_Code":"HHM 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Cây xăng Thành Công"
    ,"Station_Address":"Cây xăng Thành Công, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.877018
    ,"Long":106.591635
    ,"Polyline":"[106.58754730,10.88311005] ; [106.58873749,10.88142967] ; [106.58956909,10.88022041] ; [106.59021759,10.87932014] ; [106.59081268,10.87845993] ; [106.59133148,10.87769985] ; [106.59172821,10.87714958]"
    ,"Distance":"805"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1232"
    ,"Station_Code":"HHM 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Miểu Con Mèo"
    ,"Station_Address":"42/7B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.871902
    ,"Long":106.595306
    ,"Polyline":"[106.59172821,10.87714958] ; [106.59541321,10.87197018]"
    ,"Distance":"703"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1231"
    ,"Station_Code":"HHM 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã 3 Bùi Môn"
    ,"Station_Address":"43/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.868887
    ,"Long":106.597473
    ,"Polyline":"[106.59541321,10.87197018] ; [106.59622955,10.87077045] ; [106.59658051,10.87028980] ; [106.59755707,10.86894035]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1235"
    ,"Station_Code":"HHM 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường học Tân Xuân"
    ,"Station_Address":"58/6, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.865924
    ,"Long":106.599602
    ,"Polyline":"[106.59755707,10.86894035] ; [106.59967804,10.86596966]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1233"
    ,"Station_Code":"HHM 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Xí nghiệp phân bón Hóc Môn"
    ,"Station_Address":"114, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.861867
    ,"Long":106.602356
    ,"Polyline":"[106.59967804,10.86596966] ; [106.60241699,10.86209011] ; [106.60250854,10.86196041]"
    ,"Distance":"543"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1234"
    ,"Station_Code":"HHM 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã 3 Củ Cải"
    ,"Station_Address":"13/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.859233
    ,"Long":106.604295
    ,"Polyline":"[106.60250854,10.86196041] ; [106.60305786,10.86112022] ; [106.60491943,10.85857010]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1236"
    ,"Station_Code":"HHM 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã ba Nguyễn Thị Sóc"
    ,"Station_Address":"43/5, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.857373
    ,"Long":106.605669
    ,"Polyline":"[106.60491943,10.85857010.06.60587311] ; [10.85721970,106.60704041]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1237"
    ,"Station_Code":"QHMT229"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Quán ăn xuyên Á, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854108810424805
    ,"Long":106.60777282714844
    ,"Polyline":"[106.60704041,10.85546970] ; [106.60787964,10.85418034]"
    ,"Distance":"170"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1238"
    ,"Station_Code":"HHM 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"3A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.850092
    ,"Long":106.610395
    ,"Polyline":"[106.60787964,10.85418034] ; [106.61047363,10.85015011]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61047363,10.85015011] ; [106.61290741,10.84638023] ; [106.61396027,10.84473038]"
    ,"Distance":"713"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bến xe An  Sương"
    ,"Station_Address":"Bến xe An Sương,  đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61396030,10.84473038] ; [106.61405180,10.84459972] ; [106.61408930,10.84450118] ; [106.61406240,10.84441844] ; [106.61400330,10.84434624] ; [106.61393350,10.84428457] ; [106.61365630,10.84405216] ; [106.61343970,10.84385818] ; [106.61328200,10.84374541] ; [106.61298540,10.84354619]"
    ,"Distance":"160"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An  Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61515045,10.84292984] ; [106.61528015,10.84300041] ; [106.61485291,10.84356976] ; [106.61396027,10.84490967]"
    ,"Distance":"649"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1116"
    ,"Station_Code":"Q12 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm c ây xăng"
    ,"Station_Address":"128, đường Quốc  lộ 22, Quận 12"
    ,"Lat":10.845487
    ,"Long":106.61371
    ,"Polyline":"[106.61396027,10.84490967] ; [106.61361694,10.84545040]"
    ,"Distance":"70"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1117"
    ,"Station_Code":"Q12 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"7C, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.845845
    ,"Long":106.613474
    ,"Polyline":"[106.61361694,10.84545040] ; [106.61338806,10.84578991]"
    ,"Distance":"45"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1151"
    ,"Station_Code":"Q12 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cây xăng Quân Đội"
    ,"Station_Address":"2, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.850034
    ,"Long":106.610845
    ,"Polyline":"[106.61338806,10.84578991] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61106110,10.84941959] ; [106.61073303,10.84994030]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1689"
    ,"Station_Code":"Q12 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cảnh s át giao thông số 5"
    ,"Station_Address":"Kế ca ̉nh sát giao thông số 5, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.851009
    ,"Long":106.610186
    ,"Polyline":"[106.61073303,10.84994030] ; [106.61007690,10.85095024]"
    ,"Distance":"133"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1152"
    ,"Station_Code":"Q12 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Trung tâm văn hóa Quận 12, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.854892
    ,"Long":106.607718
    ,"Polyline":"[106.61007690,10.85095024] ; [106.60819244,10.85389042] ; [106.60761261,10.85480976]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1154"
    ,"Station_Code":"HHM 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Liên đoàn lao động Hóc Môn"
    ,"Station_Address":"69/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.855756
    ,"Long":106.607198
    ,"Polyline":"[106.60761261,10.85480976] ; [106.60710144,10.85558987]"
    ,"Distance":"103"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1153"
    ,"Station_Code":"HHM 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây xăng Củ Cải"
    ,"Station_Address":"33/4, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.859054
    ,"Long":106.604869
    ,"Polyline":"[106.60710144,10.85558987] ; [106.60597229,10.85727978] ; [106.60545349,10.85801029] ; [106.60475159,10.85900974]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1156"
    ,"Station_Code":"HHM 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 3 Củ Cải"
    ,"Station_Address":"8/6B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.861856
    ,"Long":106.602844
    ,"Polyline":"[106.60475159,10.85900974] ; [106.60276031,10.86180973]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1155"
    ,"Station_Code":"HHM 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường học Tân Xuân"
    ,"Station_Address":"44A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.865945
    ,"Long":106.599972
    ,"Polyline":"[106.60276031,10.86180973] ; [106.60131836,10.86382008] ; [106.59986877,10.86587048]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1158"
    ,"Station_Code":"HHM 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã 3 Bùi Môn"
    ,"Station_Address":"1/1, đư ờng Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.869901
    ,"Long":106.597206
    ,"Polyline":"[106.59986877,10.86587048] ; [106.59706879,10.86981010]"
    ,"Distance":"534"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1160"
    ,"Station_Code":"HHM 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 3 Bùi  Môn"
    ,"Station_Address":"3/19, đường Quốc l ộ 22, Huyện Hóc Môn"
    ,"Lat":10.872535
    ,"Long":106.595305
    ,"Polyline":"[106.59706879,10.86981010.06.59520721]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1157"
    ,"Station_Code":"HHM 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cây xăng Thành Công - Ngã t ư Giếng Nước"
    ,"Station_Address":"3/88C, đường  Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.877313
    ,"Long":106.591855
    ,"Polyline":"[106.59520721,10.87244987] ; [106.59176636,10.87730980]"
    ,"Distance":"658"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1303"
    ,"Station_Code":"HHM 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã tư Hóc Môn"
    ,"Station_Address":"206, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.884705
    ,"Long":106.586678
    ,"Polyline":"[106.59176636,10.87730980] ; [106.59127808,10.87800026] ; [106.58991241,10.87992954] ; [106.58820343,10.88237953] ; [106.58689117,10.88428020] ; [106.58661652,10.88465977]"
    ,"Distance":"993"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"2270"
    ,"Station_Code":"HHM 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bích Phương"
    ,"Station_Address":"58/2, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.886817
    ,"Long":106.58522
    ,"Polyline":"[106.58661652,10.88465977] ; [106.58515167,10.88677025]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"2263"
    ,"Station_Code":"HHM 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 3 Lam Sơn"
    ,"Station_Address":"65/5C, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.891747
    ,"Long":106.581384
    ,"Polyline":"[106.58515167,10.88677025] ; [106.58425140,10.88809013] ; [106.58394623,10.88846970] ; [106.58370972,10.88881016] ; [106.58181000,10.89153004]"
    ,"Distance":"643"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3636"
    ,"Station_Code":"HHM 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Doanh  trại Quân Đội"
    ,"Station_Address":"Doanh trai Quân đội, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.895219
    ,"Long":106.579329
    ,"Polyline":"[106.58181000,10.89153004] ; [106.58090210,10.89280987] ; [106.57926178,10.89517975]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1305"
    ,"Station_Code":"HHM 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 3 Hồng Châu"
    ,"Station_Address":"2/63, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.898753
    ,"Long":106.576899
    ,"Polyline":"[106.57926178,10.89517975] ; [106.57682037,10.89869022]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3634"
    ,"Station_Code":"HHM 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Xí nghiệp"
    ,"Station_Address":"186, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.904305
    ,"Long":106.572956
    ,"Polyline":"[106.57682037,10.89869022] ; [106.57570648,10.90028000] ; [106.57338715,10.90353012] ; [106.57288361,10.90425014]"
    ,"Distance":"754"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3637"
    ,"Station_Code":"HHM 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cây xăng Hoàng Anh 2"
    ,"Station_Address":"428, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.90903
    ,"Long":106.569663
    ,"Polyline":"[106.57288361,10.90425014] ; [106.56955719,10.90898991]"
    ,"Distance":"640"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1304"
    ,"Station_Code":"HHM 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty thoát nước đô thị"
    ,"Station_Address":"Công ty thoát nước đô thị, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.912675
    ,"Long":106.56712
    ,"Polyline":"[106.56955719,10.90898991] ; [106.56701660,10.91261959]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3635"
    ,"Station_Code":"HHM 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Chùa Linh Sơn"
    ,"Station_Address":"G68A, đ ường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.85554
    ,"Long":106.606779
    ,"Polyline":"[106.56701660,10.91261959] ; [106.56407928,10.91681004]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3639"
    ,"Station_Code":"HCC 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cây xăng  Ngọc Sương"
    ,"Station_Address":"cây xăng Ngọc Sương, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.927367
    ,"Long":106.556831
    ,"Polyline":"[106.56407928,10.91681004] ; [106.56002808,10.92263031] ; [106.55825806,10.92514038]"
    ,"Distance":"1124"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1307"
    ,"Station_Code":"HCC 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Chiếu Tân Phú"
    ,"Station_Address":"102, đường Qu ốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.931733
    ,"Long":106.553352
    ,"Polyline":"[106.55825806,10.92514038] ; [106.55677795,10.92726994] ; [106.55612183,10.92819977] ; [106.55509949,10.92961979] ; [106.55452728,10.93031979]"
    ,"Distance":"706"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3638"
    ,"Station_Code":"HCC 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Mũi tàu Hương lộ 2"
    ,"Station_Address":"158, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.934983
    ,"Long":106.549553
    ,"Polyline":"[106.55452728,10.93031979] ; [106.55383301,10.93109989] ; [106.55258179,10.93245983] ; [106.55151367,10.93360043] ; [106.55117035,10.93391037] ; [106.55068207,10.93428040] ; [106.55004883,10.93465996] ; [106.54968262,10.93484974] ; [106.54853821,10.93542004]"
    ,"Distance":"876"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3640"
    ,"Station_Code":"HCC 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà thờ Bắc Đoàn"
    ,"Station_Address":"Kế 254, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.937979
    ,"Long":106.543425
    ,"Polyline":"[106.54853821,10.93542004] ; [106.54541779,10.93692017]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1306"
    ,"Station_Code":"HCC 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường trung học cơ sở Tân Phú Trung"
    ,"Station_Address":"Trường Tân Phú Trung, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.9395
    ,"Long":106.540184
    ,"Polyline":"[106.54541779,10.93692017] ; [106.54148865,10.93881989]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3642"
    ,"Station_Code":"HCC 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Nhà thờ xuyên Lộc"
    ,"Station_Address":"366, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.941383
    ,"Long":106.536301
    ,"Polyline":"[106.54148865,10.93881989] ; [106.53993225,10.93955040] ; [106.53675079,10.94110012]"
    ,"Distance":"576"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3641"
    ,"Station_Code":"HCC 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Đường 85"
    ,"Station_Address":"444A, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.944
    ,"Long":106.530952
    ,"Polyline":"[106.53675079,10.94110012] ; [106.53603363,10.94143963] ; [106.53388977,10.94246960] ; [106.53260803,10.94309044]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1309"
    ,"Station_Code":"HCC 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã tư Quán Đôi"
    ,"Station_Address":"40, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.947133
    ,"Long":106.524635
    ,"Polyline":"[106.53260803,10.94309044] ; [106.52751923,10.94554043]"
    ,"Distance":"619"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3643"
    ,"Station_Code":"HCC 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Hồng Đào"
    ,"Station_Address":"140, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.95085
    ,"Long":106.519135
    ,"Polyline":"[106.52751923,10.94554043] ; [106.52664948,10.94596958] ; [106.52532196,10.94662952] ; [106.52478027,10.94692039] ; [106.52372742,10.94762993] ; [106.52326965,10.94793034]"
    ,"Distance":"536"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3644"
    ,"Station_Code":"HCC 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường  cây Dương"
    ,"Station_Address":"206, đường Qu ốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.9534
    ,"Long":106.51535
    ,"Polyline":"[106.52326965,10.94793034] ; [106.51988220,10.95024967]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1308"
    ,"Station_Code":"HCC 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Công ty Sài Gòn Cáp"
    ,"Station_Address":"270, đường Qu ốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.95705
    ,"Long":106.509834
    ,"Polyline":"[106.51988220,10.95024967] ; [106.51763153,10.95176029] ; [106.51403809,10.95421028]"
    ,"Distance":"775"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3645"
    ,"Station_Code":"HCC 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Nhà thờ Tân Thông"
    ,"Station_Address":"Nhà thờ Tân Thông, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.95925
    ,"Long":106.505569
    ,"Polyline":"[106.51403809,10.95421028] ; [106.51277924,10.95506954] ; [106.51107025,10.95625019] ; [106.51019287,10.95678997] ; [106.50900269,10.95740032]"
    ,"Distance":"656"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3648"
    ,"Station_Code":"HCC 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Điện lực Củ Chi"
    ,"Station_Address":"400, đường Quốc l ộ 22, Huyện Củ Chi"
    ,"Lat":10.961317
    ,"Long":106.501617
    ,"Polyline":"[106.50900269,10.95740032] ; [106.50626373,10.95880032] ; [106.50537109,10.95925999] ; [106.50392914,10.95998955]"
    ,"Distance":"624"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3646"
    ,"Station_Code":"HCC 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Xuân Quế"
    ,"Station_Address":"550, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.96355
    ,"Long":106.497749
    ,"Polyline":"[106.50392914,10.95998955] ; [106.50235748,10.96082020] ; [106.50060272,10.96179008] ; [106.49874878,10.96286011]"
    ,"Distance":"650"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"3647"
    ,"Station_Code":"HCC 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Bò Tơ  Xuân Đào"
    ,"Station_Address":"632, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.9658
    ,"Long":106.49308
    ,"Polyline":"[106.49874878,10.96286011] ; [106.49572754,10.96459007] ; [106.49507141,10.96492004] ; [106.49426270,10.96523952] ; [106.49323273,10.96564960]"
    ,"Distance":"679"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"1311"
    ,"Station_Code":"HCC 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Cầu vượt Củ Chi"
    ,"Station_Address":"734, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.96765
    ,"Long":106.488319
    ,"Polyline":"[106.49323273,10.96564960] ; [106.48915100,10.96724033] ; [106.48838806,10.96751976]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"114"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":"[106.48838806,10.96751976] ; [106.48782349,10.96770954] ; [106.48709869,10.96796036] ; [106.48600769,10.96842957] ; [106.48512268,10.96889973] ; [106.48442841,10.96934032] ; [106.48410034,10.96955967] ; [106.48394775,10.96969032] ; [106.48284912,10.97043991] ; [106.48211670,10.97099018] ; [106.48178101,10.97126961] ; [106.48169708,10.97130013] ; [106.48175049,10.97136021] ; [106.48181152,10.97138977] ; [106.48197937,10.97140026] ; [106.48210144,10.97142029] ; [106.48220062,10.97148037] ; [106.48226166,10.97154999]"
    ,"Distance":"920"
  }]