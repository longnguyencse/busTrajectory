export const Route112 =[

  {
     "Route_Id":"112"
    ,"Station_Id":"1088"
    ,"Station_Code":"BX 71"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hiệp Phước"
    ,"Station_Address":"Bến Hiệp Phước, đường Nguyễn Văn Tạo,  Huyện Nhà Bè"
    ,"Lat":10.602154
    ,"Long":106.741635
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1118"
    ,"Station_Code":"HNB 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Nhà Tưởng niệm Liệt sỹ Nhà B è"
    ,"Station_Address":"Đối diện Nghĩa trang liệt sỹ Nhà Bè, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.604342
    ,"Long":106.741276
    ,"Polyline":"[106.74163818,10.60215378] ; [106.74170685,10.60250187] ; [106.74127960,10.60434246]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1119"
    ,"Station_Code":"HNB 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công an Huyện Nhà Bè"
    ,"Station_Address":"1095  (Cầy tơ Duy Nhất), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.609815
    ,"Long":106.740101
    ,"Polyline":"[106.74127960,10.60434246] ; [106.74070740,10.60649872] ; [106.74060822,10.60785866] ; [106.74021149,10.60905075] ; [106.74010468,10.60981464]"
    ,"Distance":"625"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1121"
    ,"Station_Code":"HNB 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Phước Linh"
    ,"Station_Address":"1244 (Cửa sắt Ba Thủy), đường Nguyễn V ăn Tạo, Huyện Nhà Bè"
    ,"Lat":10.617645
    ,"Long":106.739157
    ,"Polyline":"[106.74010468,10.60981464] ; [106.73965454,10.61234570] ; [106.73950195,10.61525631] ; [106.73928070,10.61644745] ; [106.73915863,10.61764526]"
    ,"Distance":"879"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1120"
    ,"Station_Code":"HNB 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường PTTH Long Thới"
    ,"Station_Address":"Kế 919 (1733), đường Nguyễn Văn Tạo , Huyện Nhà Bè"
    ,"Lat":10.622153
    ,"Long":106.738159
    ,"Polyline":"[106.73915863,10.61764526] ; [106.73815918,10.62215328]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1123"
    ,"Station_Code":"HNB 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Đồng Điền"
    ,"Station_Address":"921, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.631169
    ,"Long":106.736104
    ,"Polyline":"[106.73815918,10.62215328] ; [106.73777771,10.62384033] ; [106.73751831,10.62543201] ; [106.73610687,10.63116932]"
    ,"Distance":"1029"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1125"
    ,"Station_Code":"HNB 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trung tâm dạy nghề Nhà Bè"
    ,"Station_Address":"635 (26), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.63477
    ,"Long":106.735337
    ,"Polyline":"[106.73610687,10.63116932] ; [106.73533630,10.63477039]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1126"
    ,"Station_Code":"HNB 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trung t âm dạy nghề Nhà Bè"
    ,"Station_Address":"189, đường Nguy ễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.643133
    ,"Long":106.732651
    ,"Polyline":"[106.73533630,10.63477039] ; [106.73505402,10.63599300] ; [106.73464966,10.63725281] ; [106.73387909,10.63976288] ; [106.73350525,10.64061165] ; [106.73265076,10.64313316]"
    ,"Distance":"977"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1129"
    ,"Station_Code":"HNB 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Bà Chồi"
    ,"Station_Address":"334B (92), đường Nguyễn Văn Tạo, Huyện Nh à Bè"
    ,"Lat":10.647133
    ,"Long":106.731369
    ,"Polyline":"[106.73265076,10.64313316] ; [106.73136902,10.64713287]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1130"
    ,"Station_Code":"HNB 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà máy Đại Sơn"
    ,"Station_Address":"77, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.65008
    ,"Long":106.730488
    ,"Polyline":"[106.73136902,10.64713287] ; [106.73049164,10.65007973]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1127"
    ,"Station_Code":"HNB 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"UBND Xã Long Thới"
    ,"Station_Address":"Kế 205 (155), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.653433
    ,"Long":106.729385
    ,"Polyline":"[106.73044586,10.64991093] ; [106.72938538,10.65343285]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1128"
    ,"Station_Code":"HNB 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Công an Huyện Nhà Bè"
    ,"Station_Address":"Đối diện CA H.Nhà Bè, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.657133
    ,"Long":106.728203
    ,"Polyline":"[106.72938538,10.65343285] ; [106.72820282,10.65713310]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1131"
    ,"Station_Code":"HNB 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Hàng Tre"
    ,"Station_Address":"91, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.663555
    ,"Long":106.726186
    ,"Polyline":"[106.72820282,10.65713310.06.72618866]"
    ,"Distance":"748"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1132"
    ,"Station_Code":"HNB 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Vòng xoay Long Thới"
    ,"Station_Address":"24C-17 , đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.66775
    ,"Long":106.72477
    ,"Polyline":"[106.72618866,10.66355515] ; [106.72476959,10.66775036]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3629"
    ,"Station_Code":"HNB 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Cầu B à Chiêm"
    ,"Station_Address":"Trụ đèn số 7, đường Nguyễn Hữu Thọ, Huyện  Nhà Bè"
    ,"Lat":10.673497
    ,"Long":106.723836
    ,"Polyline":"[106.72476959,10.66775036] ; [106.72457123,10.66852570] ; [106.72477722,10.66909504] ; [106.72470093,10.66970730] ; [106.72383881,10.67349720]"
    ,"Distance":"657"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3626"
    ,"Station_Code":"HNB 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"Ngã tư Phạm Hữu Lầu, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.696834
    ,"Long":106.717941
    ,"Polyline":"[106.72383881,10.67349720] ; [106.72125244,10.68426704] ; [106.71896362,10.69168949] ; [106.71849060,10.69487286] ; [106.71794128,10.69683361]"
    ,"Distance":"2680"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3631"
    ,"Station_Code":"HNB 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Nguyễn Hữu Thọ"
    ,"Station_Address":"92, đường Nguyễn Hữu Thọ,  Huyện Nhà Bè"
    ,"Lat":10.704319
    ,"Long":106.712984
    ,"Polyline":"[106.71794128,10.69683361] ; [106.71722412,10.69837284] ; [106.71630096,10.69974327] ; [106.71298218,10.70431900]"
    ,"Distance":"997"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3627"
    ,"Station_Code":"HNB 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện huyện Nhà Bè"
    ,"Station_Address":"Đối diện khu nhà ở Thái Sơn, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.707966
    ,"Long":106.710441
    ,"Polyline":"[106.71298218,10.70431900] ; [106.71163940,10.70612717] ; [106.71099091,10.70704365] ; [106.71044159,10.70796585]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3630"
    ,"Station_Code":"HNB 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Park Premier"
    ,"Station_Address":"Làng ĐH Khu B, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.715514
    ,"Long":106.704798
    ,"Polyline":"[106.71044159,10.70796585] ; [106.70753479,10.71173000] ; [106.70479584,10.71551418]"
    ,"Distance":"1043"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3632"
    ,"Station_Code":"HNB 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Làng Đại học Khu C"
    ,"Station_Address":"Cột đèn 146, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.717559
    ,"Long":106.703258
    ,"Polyline":"[106.70479584,10.71551418] ; [106.70325470,10.71755886]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3633"
    ,"Station_Code":"HNB 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Hoàng Anh Gia Lai 3"
    ,"Station_Address":"Đối diện Hoàng Anh Gia Lai 3, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.720395
    ,"Long":106.701815
    ,"Polyline":"[106.70325470,10.71755886] ; [106.70289612,10.71806049] ; [106.70244598,10.71880817] ; [106.70192719,10.71995258] ; [106.70181274,10.72039509]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1244"
    ,"Station_Code":"Q7 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"291/8, đường  Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.729324
    ,"Long":106.700522
    ,"Polyline":"[106.70181274,10.72039509] ; [106.70159149,10.72103786] ; [106.70135498,10.72260857] ; [106.70106506,10.72484875] ; [106.70052338,10.72932434]"
    ,"Distance":"1006"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1246"
    ,"Station_Code":"Q7 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"ĐH Tôn Đức Thắng"
    ,"Station_Address":"568, đường Nguy ễn Hữu Thọ, Quận 7"
    ,"Lat":10.731859
    ,"Long":106.700152
    ,"Polyline":"[106.70052338,10.72932434] ; [106.70033264,10.73059368] ; [106.70014954,10.73185921]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1245"
    ,"Station_Code":"Q7 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Đại học Cảnh sát"
    ,"Station_Address":"Đối diện 36, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.734273
    ,"Long":106.700029
    ,"Polyline":"[106.70014954,10.73185921] ; [106.69997406,10.73306561] ; [106.69998932,10.73371983] ; [106.70002747,10.73427296]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1247"
    ,"Station_Code":"Q7 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Siêu thị Lotte"
    ,"Station_Address":"Siêu thị Lotte, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74085
    ,"Long":106.701134
    ,"Polyline":"[106.70002747,10.73427296] ; [106.70050812,10.73752499] ; [106.70113373,10.74085045]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1249"
    ,"Station_Code":"Q7 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đường 15"
    ,"Station_Address":"458B, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.743865
    ,"Long":106.701665
    ,"Polyline":"[106.70113373,10.74085045] ; [106.70137787,10.74236870] ; [106.70166779,10.74386501]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1251"
    ,"Station_Code":"Q7 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cầu Kinh  Tẻ"
    ,"Station_Address":"Đối diện 44/9, đường  Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.748524
    ,"Long":106.702443
    ,"Polyline":"[106.70166779,10.74386501] ; [106.70244598,10.74852371]"
    ,"Distance":"526"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1248"
    ,"Station_Code":"Q4T015"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Hồ Bơi Quận 4"
    ,"Station_Address":"120-122, đường Khánh Hội, Quận 4"
    ,"Lat":10.756855
    ,"Long":106.700691
    ,"Polyline":"[106.70244598,10.74852371] ; [106.70251465,10.75023651] ; [106.70201111,10.75519085] ; [106.70069122,10.75685501]"
    ,"Distance":"980"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1250"
    ,"Station_Code":"Q4 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chung c ư Tân Vĩnh"
    ,"Station_Address":"202-204, đường  Khánh Hội, Quận 4"
    ,"Lat":10.758848
    ,"Long":106.699213
    ,"Polyline":"[106.70069122,10.75685501] ; [106.69921112,10.75884819]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1253"
    ,"Station_Code":"Q4 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chung cư H3"
    ,"Station_Address":"303-305, đường Ho àng Diệu, Quận 4"
    ,"Lat":10.760066
    ,"Long":106.699294
    ,"Polyline":"[106.69921112,10.75884819] ; [106.69861603,10.75960159] ; [106.69929504,10.76006603]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1379"
    ,"Station_Code":"Q1 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"82 - 84, đường Nguyễn Thái Học, Quận 1"
    ,"Lat":10.766109
    ,"Long":106.696686
    ,"Polyline":"[106.69929504,10.76006603] ; [106.70055389,10.76102543] ; [106.69992065,10.76194763] ; [106.69959259,10.76236916] ; [106.69873810,10.76320171] ; [106.69790649,10.76402855] ; [106.69758606,10.76453972] ; [106.69728088,10.76505661] ; [106.69668579,10.76610947]"
    ,"Distance":"886"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1385"
    ,"Station_Code":"Q1 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Nguyễn Thái Học"
    ,"Station_Address":"141-149, đường Lê Thị Hồng Gấm, Quận 1"
    ,"Lat":10.767635
    ,"Long":106.696281
    ,"Polyline":"[106.69668579,10.76610947] ; [106.69592285,10.76737022] ; [106.69628143,10.76763535]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103 , đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69628143,10.76763535] ; [106.69692230,10.76822948] ; [106.69618988,10.76987839] ; [106.69595337,10.76980972]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"240"
    ,"Station_Code":"Q1 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Thái Bình"
    ,"Station_Address":"Đối diện 361, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.767365
    ,"Long":106.689831
    ,"Polyline":"[106.69398499,10.76903534] ; [106.68983459,10.76736546]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.68983459,10.76736546] ; [106.68949127,10.76724911] ; [106.68936157,10.76767635]"
    ,"Distance":"89"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài  Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất  Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68922424,10.76811886] ; [106.69033813,10.76855087]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Th ị Nghĩa"
    ,"Station_Address":"Đối diện 96, đư ờng Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1451"
    ,"Station_Code":"Q1 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trần Hưng Đạo"
    ,"Station_Address":"197, đường Nguyễn  Thái Học, Quận 1"
    ,"Lat":10.768461
    ,"Long":106.694984
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69411469,10.77005291] ; [106.69498444,10.76846123]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1344"
    ,"Station_Code":"Q1 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"65G, đường Nguyễn  Thái Học, Quận 1"
    ,"Lat":10.766576
    ,"Long":106.696129
    ,"Polyline":"[106.69498444,10.76846123] ; [106.69557953,10.76751804] ; [106.69612885,10.76657581]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1196"
    ,"Station_Code":"Q4 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"K48-K50, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.760429
    ,"Long":106.699428
    ,"Polyline":"[106.69612885,10.76657581] ; [106.69774628,10.76397133] ; [106.69799805,10.76368141] ; [106.69963837,10.76209450] ; [106.70031738,10.76104069] ; [106.69942474,10.76042938]"
    ,"Distance":"892"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1194"
    ,"Station_Code":"Q4 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chung cư Tân Vĩnh"
    ,"Station_Address":"Đối diện 220, đường Khánh Hội, Quận 4"
    ,"Lat":10.758864
    ,"Long":106.698972
    ,"Polyline":"[106.69942474,10.76042938] ; [106.69847870,10.75967598] ; [106.69897461,10.75886440]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1198"
    ,"Station_Code":"Q4 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trung tâm TDTT Quận 4"
    ,"Station_Address":"149, đường Khánh  Hội, Quận 4"
    ,"Lat":10.756725
    ,"Long":106.700581
    ,"Polyline":"[106.69897461,10.75886440] ; [106.69979858,10.75780487] ; [106.70058441,10.75672531]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1197"
    ,"Station_Code":"Q7 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cầu Kinh Tẻ"
    ,"Station_Address":"44/7, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74845
    ,"Long":106.702196
    ,"Polyline":"[106.70058441,10.75672531] ; [106.70181274,10.75519085] ; [106.70233154,10.75015259] ; [106.70219421,10.74845028]"
    ,"Distance":"971"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1201"
    ,"Station_Code":"Q7 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Đường 15"
    ,"Station_Address":"2, đường Nguyễn Hữu Thọ , Quận 7"
    ,"Lat":10.743765
    ,"Long":106.701375
    ,"Polyline":"[106.70219421,10.74845028] ; [106.70137787,10.74376488]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1199"
    ,"Station_Code":"Q7 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu thị Lotte"
    ,"Station_Address":"Đối diện siêu thị Lotte, đường Nguyễn Hữu  Thọ, Quận 7"
    ,"Lat":10.74084
    ,"Long":106.700866
    ,"Polyline":"[106.70137787,10.74376488] ; [106.70086670,10.74083996]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1202"
    ,"Station_Code":"Q7 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Đại học Cảnh sát"
    ,"Station_Address":"Đối diện B10, đường Nguyễn Hữu Thọ, Qu ận 7"
    ,"Lat":10.734373
    ,"Long":106.699793
    ,"Polyline":"[106.70086670,10.74083996] ; [106.69979095,10.73437309]"
    ,"Distance":"729"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1200"
    ,"Station_Code":"Q7 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"ĐH Tôn Đức Thắng"
    ,"Station_Address":"Đối diện 568, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.731752
    ,"Long":106.699959
    ,"Polyline":"[106.69979095,10.73437309] ; [106.69981384,10.73361969] ; [106.69982147,10.73305035] ; [106.69995880,10.73175240]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1204"
    ,"Station_Code":"Q7 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Nguyễn  Văn Linh"
    ,"Station_Address":"645, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.729419
    ,"Long":106.700243
    ,"Polyline":"[106.69995880,10.73175240] ; [106.70019531,10.73017788] ; [106.70024109,10.72941875]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3621"
    ,"Station_Code":"HNB 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Hoàng  Anh Gia Lai 3"
    ,"Station_Address":"Chung cư HAGL 3, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.720084
    ,"Long":106.701332
    ,"Polyline":"[106.70024109,10.72941875] ; [106.70040131,10.72807980] ; [106.70043945,10.72770023] ; [106.70033264,10.72732067] ; [106.70061493,10.72470665] ; [106.70090485,10.72239304] ; [106.70108795,10.72123814] ; [106.70133209,10.72008419]"
    ,"Distance":"1050"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3622"
    ,"Station_Code":"HNB 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"KDC Làng Đại Học khu C"
    ,"Station_Address":"Khu dân cư làng đại học, đường Nguyễn  Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.717486
    ,"Long":106.702663
    ,"Polyline":"[106.70133209,10.72008419] ; [106.70195770,10.71872997] ; [106.70265961,10.71748638]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3624"
    ,"Station_Code":"HNB 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Park Premier"
    ,"Station_Address":"Đối diện Park Premier , đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.715219
    ,"Long":106.704288
    ,"Polyline":"[106.70265961,10.71748638] ; [106.70351410,10.71636868] ; [106.70428467,10.71521854]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3623"
    ,"Station_Code":"HNB 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh vi ện huyện Nhà Bè"
    ,"Station_Address":"Bệnh viện huyện Nhà Bè, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.707524
    ,"Long":106.709862
    ,"Polyline":"[106.70428467,10.71521854] ; [106.70709229,10.71138191] ; [106.70986176,10.70752430]"
    ,"Distance":"1051"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3628"
    ,"Station_Code":"HNB 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Bình Xuyên 2"
    ,"Station_Address":"Bình Xuyên 2, đường Nguyễn Hữu Thọ, Huy ện Nhà Bè"
    ,"Lat":10.69753
    ,"Long":106.716964
    ,"Polyline":"[106.70986176,10.70752430] ; [106.71368408,10.70252705] ; [106.71655273,10.69860458] ; [106.71696472,10.69752979]"
    ,"Distance":"1361"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"3625"
    ,"Station_Code":"HNB 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"Ngã tư Phạm Hữu Lầu, đường Nguyễn Hữu Thọ, Huyện Nhà Bè"
    ,"Lat":10.693376
    ,"Long":106.718144
    ,"Polyline":"[106.71696472,10.69752979] ; [106.71741486,10.69680214] ; [106.71781158,10.69553661] ; [106.71799469,10.69446182] ; [106.71814728,10.69337559]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1078"
    ,"Station_Code":"HNB 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Phước Kiểng"
    ,"Station_Address":"74, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.667213
    ,"Long":106.724828
    ,"Polyline":"[106.71814728,10.69337559] ; [106.71839905,10.69192123] ; [106.72064972,10.68444633] ; [106.72168732,10.68030262] ; [106.72483063,10.66721344]"
    ,"Distance":"3004"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1074"
    ,"Station_Code":"HNB 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nguyễn  Văn Tạo"
    ,"Station_Address":"Đối diện 206, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.663817
    ,"Long":106.725929
    ,"Polyline":"[106.72483063,10.66721344] ; [106.72534180,10.66581154] ; [106.72592926,10.66381741]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1076"
    ,"Station_Code":"HNB 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Công an Nhà Bè"
    ,"Station_Address":"Công an  huyện Nhà Bè, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.65675
    ,"Long":106.728203
    ,"Polyline":"[106.72592926,10.66381741] ; [106.72820282,10.65674973]"
    ,"Distance":"825"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1077"
    ,"Station_Code":"HNB 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cửa hàng vật liệu xây dựng"
    ,"Station_Address":"288 (239), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.6529
    ,"Long":106.729431
    ,"Polyline":"[106.72820282,10.65674973] ; [106.72943115,10.65289974]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1080"
    ,"Station_Code":"HNB 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ B à Chồi"
    ,"Station_Address":"372 (Chợ Bà Chồi), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.650047
    ,"Long":106.730347
    ,"Polyline":"[106.72943115,10.65289974] ; [106.73021698,10.65055943] ; [106.73034668,10.65004730]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1079"
    ,"Station_Code":"HNB 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Đại Sơn"
    ,"Station_Address":"482B, đường Nguy ễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.647767
    ,"Long":106.731064
    ,"Polyline":"[106.73034668,10.65004730] ; [106.73106384,10.64776707]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1081"
    ,"Station_Code":"HNB 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trung tâm dạy nghề"
    ,"Station_Address":"568 (Đ/d Trung tâm dạy nghề Nhà Bè ) , đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.642867
    ,"Long":106.732651
    ,"Polyline":"[106.73106384,10.64776707] ; [106.73265076,10.64286709]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1083"
    ,"Station_Code":"HNB 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngân h àng"
    ,"Station_Address":"568 (134), đường Nguy ễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.642867
    ,"Long":106.732651
    ,"Polyline":"[106.73265076,10.64286709] ; [106.73265076,10.64286709]"
    ,"Distance":"0"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1082"
    ,"Station_Code":"HNB 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Dịch vụ cầm đồ số 4"
    ,"Station_Address":"718, đường Nguy ễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.634776
    ,"Long":106.735222
    ,"Polyline":"[106.73265076,10.64286709] ; [106.73402405,10.63882351] ; [106.73522186,10.63477612]"
    ,"Distance":"944"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1085"
    ,"Station_Code":"HNB 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Đức Mỹ"
    ,"Station_Address":"780 (116/5), đường Nguyễn  Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.630992
    ,"Long":106.736023
    ,"Polyline":"[106.73522186,10.63477612] ; [106.73558044,10.63287640] ; [106.73602295,10.63099194]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1084"
    ,"Station_Code":"HNB 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Đồng Điền"
    ,"Station_Address":"CHVLXD Thành Công, đường Nguyễn Văn T ạo, Huyện Nhà Bè"
    ,"Lat":10.626165
    ,"Long":106.737118
    ,"Polyline":"[106.73602295,10.63099194] ; [106.73712158,10.62616539]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1087"
    ,"Station_Code":"HNB 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã Tư Long Hậu"
    ,"Station_Address":"Kế 280 (Cửa sắt Hoàng Cẩn), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.622538
    ,"Long":106.737912
    ,"Polyline":"[106.73712158,10.62616539] ; [106.73738098,10.62546349] ; [106.73759460,10.62399864] ; [106.73791504,10.62253761]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1086"
    ,"Station_Code":"HNB 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ba Thủy"
    ,"Station_Address":"Đối diện cửa hàng Ba Thủy, đường Nguyễn V ăn Tạo, Huyện Nhà Bè"
    ,"Lat":10.617386
    ,"Long":106.739017
    ,"Polyline":"[106.73791504,10.62253761] ; [106.73851013,10.61995983] ; [106.73889160,10.61832523] ; [106.73901367,10.61738586]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1089"
    ,"Station_Code":"HNB 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Công an Huyện Nhà Bè"
    ,"Station_Address":"Cột điện 141P, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.609572
    ,"Long":106.739951
    ,"Polyline":"[106.73901367,10.61738586] ; [106.73930359,10.61537266] ; [106.73944855,10.61245155] ; [106.73995209,10.60957241]"
    ,"Distance":"877"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1091"
    ,"Station_Code":"HNB 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Nhà Tưởng niệm Liệt sỹ Nhà Bè"
    ,"Station_Address":"1/58A, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.604458
    ,"Long":106.74104
    ,"Polyline":"[106.73995209,10.60957241] ; [106.74046326,10.60788536] ; [106.74055481,10.60650349] ; [106.74104309,10.60445786]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"112"
    ,"Station_Id":"1088"
    ,"Station_Code":"BX 71"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Hiệp Phước"
    ,"Station_Address":"Bến Hiệp Phước, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.602154
    ,"Long":106.741635
    ,"Polyline":"[106.74104309,10.60445786] ; [106.74124146,10.60389328] ; [106.74137115,10.60330868] ; [106.74154663,10.60270691] ; [106.74163818,10.60215378]"
    ,"Distance":"265"
  }]