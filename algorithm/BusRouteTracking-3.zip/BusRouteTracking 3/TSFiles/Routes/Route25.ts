export const Route25 =[

  {
     "Route_Id":"25"
    ,"Station_Id":"1054"
    ,"Station_Code":"BX 18"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Phú Xuân"
    ,"Station_Address":"Bến Phú Xuân, đường Đường số 15B, Quận 7"
    ,"Lat":10.703697
    ,"Long":106.732317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1057"
    ,"Station_Code":"Q7 169"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"63-65, đường Phạm Hữu Lầu, Quận 7"
    ,"Lat":10.704788
    ,"Long":106.735198
    ,"Polyline":"[106.73227692,10.70392036] ; [106.73238373,10.70456028] ; [106.73522949,10.70489979]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1364"
    ,"Station_Code":"Q7 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"1697, đường Huỳnh Tấn Phát , Quận 7"
    ,"Lat":10.705547
    ,"Long":106.737649
    ,"Polyline":"[106.73522949,10.70489311] ; [106.73763275,10.70519352] ; [106.73749542,10.70611382] ; [106.73749542,10.70611382]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1363"
    ,"Station_Code":"Q7 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Pháp Hoa"
    ,"Station_Address":"1611, đường Huỳnh Tấn Phát, Qu ận 7"
    ,"Lat":10.708926
    ,"Long":106.737381
    ,"Polyline":"[106.73742676,10.70610046] ; [106.73734283,10.70683956] ; [106.73725891,10.70855999]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1367"
    ,"Station_Code":"Q7 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"An Chánh Dương"
    ,"Station_Address":"1543, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.711134
    ,"Long":106.737242
    ,"Polyline":"[106.73725128,10.70860004] ; [106.73715973,10.71053028]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1365"
    ,"Station_Code":"Q7 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Ngô Quyền"
    ,"Station_Address":"1503/7, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.712795
    ,"Long":106.737177
    ,"Polyline":"[106.73715973,10.71053028] ; [106.73703766,10.71273041]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1370"
    ,"Station_Code":"Q7 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ủy ban phường Phú Mỹ"
    ,"Station_Address":"Ủy ban phường Phú Mỹ, đường Hoàng Quốc Việt, Quận 7"
    ,"Lat":10.713991
    ,"Long":106.734817
    ,"Polyline":"[106.73712158,10.71273613] ; [106.73712158,10.71273613] ; [106.73699951,10.71439171] ; [106.73484039,10.71393585]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1368"
    ,"Station_Code":"Q7 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Mầm non Cánh Thiên Thần"
    ,"Station_Address":"120M (Ngân hàng Agribank), đường Hoàng Quốc Việt, Qu ận 7"
    ,"Lat":10.713469
    ,"Long":106.732655
    ,"Polyline":"[106.73484039,10.71393585] ; [106.73267365,10.71345901]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1372"
    ,"Station_Code":"Q7 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Mỹ Khang"
    ,"Station_Address":"SD4-1, Lô S19-2 , đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.715599
    ,"Long":106.730096
    ,"Polyline":"[106.73267365,10.71345901] ; [106.73173523,10.71317959] ; [106.73149872,10.71320534] ; [106.73003387,10.71549034]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1369"
    ,"Station_Code":"Q7 164"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nam Viên"
    ,"Station_Address":"Trường tiểu học Việt Pháp, đường Nguy ễn Lương Bằng, Quận 7"
    ,"Lat":10.71825
    ,"Long":106.728476
    ,"Polyline":"[106.73003387,10.71549034] ; [106.72841644,10.71818924]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1240"
    ,"Station_Code":"Q7 165"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Mỹ Thái 2"
    ,"Station_Address":"Đ/d Chung cư Riverside, đường Nguyễn Lương Bằng, Qu ận 7"
    ,"Lat":10.721022
    ,"Long":106.726738
    ,"Polyline":"[106.72841644,10.71818924] ; [106.72635651,10.72158146]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1241"
    ,"Station_Code":"Q7 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường Nam Sài Gòn"
    ,"Station_Address":"Đối diện trường Nam Sài Gòn, đường Nguyễn Lương Bằng , Quận 7"
    ,"Lat":10.725255
    ,"Long":106.724174
    ,"Polyline":"[106.72635651,10.72158146] ; [106.72419739,10.72506237]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1371"
    ,"Station_Code":"Q7 167"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Tân Trào"
    ,"Station_Address":"Đối diện VP Đội Bảo vệ, đường Nguyễn Lương Bằng, Qu ận 7"
    ,"Lat":10.728538
    ,"Long":106.722114
    ,"Polyline":"[106.72419739,10.72506237] ; [106.72187805,10.72875214]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1375"
    ,"Station_Code":"Q7 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Bệnh viện Việt Pháp"
    ,"Station_Address":"Đối diện bệnh viện tim Tâm Đức, đường Nguyễn Lương  Bằng, Quận 7"
    ,"Lat":10.733488
    ,"Long":106.71904
    ,"Polyline":"[106.72187805,10.72875214] ; [106.71888733,10.73364449]"
    ,"Distance":"635"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1377"
    ,"Station_Code":"Q7 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Tân Mỹ"
    ,"Station_Address":"29, đường Tân Mỹ, Quận 7"
    ,"Lat":10.737343
    ,"Long":106.71833
    ,"Polyline":"[106.71891022,10.73357010.06.71846771] ; [10.73429012,106.71824646] ; [10.73464966,106.71820068] ; [10.73478031,106.71817017] ; [10.73486996,106.71820831] ; [10.73581028,106.71817780] ; [10.73596954,106.71826172] ; [10.73696041,106.71827698]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1373"
    ,"Station_Code":"Q7 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"222, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738384
    ,"Long":106.717485
    ,"Polyline":"[106.71827698,10.73735046] ; [106.71833038,10.73822021] ; [106.71804810,10.73822975] ; [106.71672058,10.73832035]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1374"
    ,"Station_Code":"Q7 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Mai Văn Vĩnh"
    ,"Station_Address":"326, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738621
    ,"Long":106.713333
    ,"Polyline":"[106.71672058,10.73832035] ; [106.71266174,10.73857975]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1378"
    ,"Station_Code":"Q7 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Đường số 38"
    ,"Station_Address":"392, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738964
    ,"Long":106.710484
    ,"Polyline":"[106.71266174,10.73857975] ; [106.71201324,10.73863983] ; [106.71121216,10.73875999] ; [106.71011353,10.73892975]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1376"
    ,"Station_Code":"Q7 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Khu dân cư Tân Quy Đông"
    ,"Station_Address":"450, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.739401
    ,"Long":106.707614
    ,"Polyline":"[106.71011353,10.73892975] ; [106.70751190,10.73931026]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1380"
    ,"Station_Code":"Q7 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Lotte Mark"
    ,"Station_Address":"359, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.740208
    ,"Long":106.70369
    ,"Polyline":"[106.70751190,10.73934937] ; [106.70363617,10.73994923] ; [106.70368958,10.74020767]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1382"
    ,"Station_Code":"Q7 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường số 15"
    ,"Station_Address":"265, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744471
    ,"Long":106.70432
    ,"Polyline":"[106.70361328,10.74022007] ; [106.70401001,10.74250984] ; [106.70423126,10.74417973]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1251"
    ,"Station_Code":"Q7 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Kinh T ẻ"
    ,"Station_Address":"Đối diện 44/9, đường Nguy ễn Hữu Thọ, Quận 7"
    ,"Lat":10.748524
    ,"Long":106.702443
    ,"Polyline":"[106.70423126,10.74417973] ; [106.70433044,10.74499035] ; [106.70250702,10.74522972] ; [106.70230865,10.74538040] ; [106.70217896,10.74551010.06.70207214] ; [10.74571991,106.70201111] ; [10.74592972,106.70200348] ; [10.74627018,106.70211792] ; [10.74703026,106.70237732]"
    ,"Distance":"714"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"4424"
    ,"Station_Code":"Q4 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trung tâm TDTT Quận 4"
    ,"Station_Address":"120-122, đư ờng Khánh Hội, Quận 4"
    ,"Lat":10.75683
    ,"Long":106.700732
    ,"Polyline":"[106.70246124,10.74862385] ; [106.70209503,10.75481129] ; [106.70072937,10.75683022]"
    ,"Distance":"960"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1250"
    ,"Station_Code":"Q4 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chung cư Tân Vĩnh"
    ,"Station_Address":"202-204, đường Khánh Hội, Quận 4"
    ,"Lat":10.758848
    ,"Long":106.699213
    ,"Polyline":"[106.70072937,10.75683022] ; [106.69921112,10.75884819]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1253"
    ,"Station_Code":"Q4 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chung cư H3"
    ,"Station_Address":"303-305, đường Hoàng Diệu , Quận 4"
    ,"Lat":10.760066
    ,"Long":106.699294
    ,"Polyline":"[106.69914246,10.75887012] ; [106.69864655,10.75953007] ; [106.69851685,10.75963974] ; [106.69918823,10.76012039]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1379"
    ,"Station_Code":"Q1 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"82 - 84, đường Nguyễn Thái  Học, Quận 1"
    ,"Lat":10.766109
    ,"Long":106.696686
    ,"Polyline":"[106.69918823,10.76012039] ; [106.69972992,10.76053047] ; [106.70041656,10.76099968] ; [106.69986725,10.76181984] ; [106.69959259,10.76220036] ; [106.69931793,10.76249027] ; [106.69872284,10.76309967] ; [106.69805145,10.76377010.06.69786835] ; [10.76395988,106.69760895] ; [10.76432037,106.69657135]"
    ,"Distance":"899"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1385"
    ,"Station_Code":"Q1 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường Nguyễn Thái Học"
    ,"Station_Address":"141-149, đư ờng Lê Thị Hồng Gấm, Quận 1"
    ,"Lat":10.767635
    ,"Long":106.696281
    ,"Polyline":"[106.69668579,10.76610947] ; [106.69583130,10.76731968] ; [106.69628143,10.76763535]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"120"
    ,"Station_Code":"Q1 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"8, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768772
    ,"Long":106.695923
    ,"Polyline":"[106.69628143,10.76763535] ; [106.69628143,10.76763535] ; [106.69689941,10.76825047] ; [106.69637299,10.76919842] ; [106.69592285,10.76877213] ; [106.69592285,10.76877213]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"121"
    ,"Station_Code":"Q1 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"10, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767363
    ,"Long":106.694695
    ,"Polyline":"[106.69592285,10.76877213] ; [106.69592285,10.76877213] ; [106.69599152,10.76871014] ; [106.69474792,10.76731968] ; [106.69469452,10.76736259] ; [106.69469452,10.76736259]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"122"
    ,"Station_Code":"Q1 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Rạp Hưng Đạo"
    ,"Station_Address":"112, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765832
    ,"Long":106.693375
    ,"Polyline":"[106.69469452,10.76736259] ; [106.69469452,10.76736259] ; [106.69474792,10.76731968] ; [106.69344330,10.76578045] ; [106.69337463,10.76583195] ; [106.69337463,10.76583195]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"123"
    ,"Station_Code":"Q1 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Bệnh viện  Răng Hàm Mặt"
    ,"Station_Address":"150, đường  Trần Hưng Đạo, Quận 1"
    ,"Lat":10.763918
    ,"Long":106.691696
    ,"Polyline":"[106.69337463,10.76583195] ; [106.69169617,10.76391792]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"124"
    ,"Station_Code":"Q1 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"210 - 212, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.762262
    ,"Long":106.690247
    ,"Polyline":"[106.69169617,10.76391792] ; [106.69024658,10.76226234]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"125"
    ,"Station_Code":"Q1 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Tổng Cty Samco"
    ,"Station_Address":"262, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.759409
    ,"Long":106.687798
    ,"Polyline":"[106.69029999,10.76220989] ; [106.68784332,10.75938034]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"126"
    ,"Station_Code":"Q1 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Nanci"
    ,"Station_Address":"290, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.757467
    ,"Long":106.686035
    ,"Polyline":"[106.68784332,10.75938034] ; [106.68657684,10.75798035] ; [106.68608856,10.75741959]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1381"
    ,"Station_Code":"Q1 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nhà Sách Nguy ễn Văn Cừ"
    ,"Station_Address":"110-112, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.757567
    ,"Long":106.684937
    ,"Polyline":"[106.68603516,10.75746727] ; [106.68608856,10.75741959] ; [106.68524170,10.75657177] ; [106.68483734,10.75753117] ; [106.68493652,10.75756741]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1021"
    ,"Station_Code":"Q1 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Nguyễn Trãi"
    ,"Station_Address":"Đối diện số 205 - 207, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.760314
    ,"Long":106.683769
    ,"Polyline":"[106.68493652,10.75756741] ; [106.68376923,10.76031399]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"426"
    ,"Station_Code":"Q5 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Đại học Sư Phạm"
    ,"Station_Address":"280, đường An Dương Vương, Quận 5"
    ,"Lat":10.76103
    ,"Long":106.68267
    ,"Polyline":"[106.68376923,10.76031399] ; [106.68334961,10.76117039] ; [106.68268585,10.76096058]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"429"
    ,"Station_Code":"Q5 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"370, đường An Dương Vương, Quận 5"
    ,"Lat":10.759407
    ,"Long":106.678764
    ,"Polyline":"[106.68268585,10.76096058] ; [106.68268585,10.76096058] ; [106.67877197,10.75938129] ; [106.67877197,10.75938129]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"427"
    ,"Station_Code":"Q5 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"526, đường An Dương Vương , Quận 5"
    ,"Lat":10.757984
    ,"Long":106.675272
    ,"Polyline":"[106.67877197,10.75938129] ; [106.67877197,10.75938129] ; [106.67867279,10.75933838] ; [106.67813110,10.75911045] ; [106.67580414,10.75820065] ; [106.67552185,10.75808430] ; [106.67527008,10.75799942] ; [106.67527008,10.75799942]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"430"
    ,"Station_Code":"Q5 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"Đối diện số 5, đường An Dương Vương, Quận 5"
    ,"Lat":10.757536
    ,"Long":106.673534
    ,"Polyline":"[106.67527008,10.75798416] ; [106.67420959,10.75758839] ; [106.67414856,10.75764179] ; [106.67404175,10.75761509] ; [106.67353058,10.75753593]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"428"
    ,"Station_Code":"Q5 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"102C-D, đường An Dương Vương, Quận 5"
    ,"Lat":10.756967
    ,"Long":106.670653
    ,"Polyline":"[106.67356110,10.75745678] ; [106.67356110,10.75743961] ; [106.67298889,10.75734997] ; [106.67246246,10.75722980] ; [106.67175293,10.75712013] ; [106.67083740,10.75697231] ; [106.67066956,10.75693417]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.67066956,10.75693417] ; [106.67066956,10.75693417] ; [106.67049408,10.75689888] ; [106.66963196,10.75672436] ; [106.66954041,10.75706196] ; [106.66951752,10.75715446] ; [106.66951752,10.75715446]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"431"
    ,"Station_Code":"Q5 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"116A, đường Hùng Vương, Quận 5"
    ,"Lat":10.757257
    ,"Long":106.668566
    ,"Polyline":"[106.66951752,10.75715446] ; [106.66951752,10.75715446] ; [106.66951752,10.75715351] ; [106.66939545,10.75766754] ; [106.66857147,10.75730896] ; [106.66857147,10.75730896] ; [106.66857147,10.75730896]"
    ,"Distance":"174"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Bệnh viện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66857147,10.75730896] ; [106.66851044,10.75724125] ; [106.66710663,10.75650024] ; [106.66667938,10.75634956] ; [106.66623688,10.75624466] ; [106.66468048,10.75592327] ; [106.66451263,10.75588226]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"132 , đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66451263,10.75588226] ; [106.66433716,10.75582314] ; [106.66336060,10.75557041] ; [106.66236877,10.75539017] ; [106.66139221,10.75520134] ; [106.66107941,10.75520515]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107941,10.75520515] ; [106.66094208,10.75514317] ; [106.65982819,10.75493240] ; [106.65961456,10.75492668]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"435"
    ,"Station_Code":"Q5 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Thuận Kiều  Plaza"
    ,"Station_Address":"Đối diện 385, đư ờng Hồng Bàng, Quận 5"
    ,"Lat":10.75458
    ,"Long":106.657934
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65793610,10.75457954]"
    ,"Distance":"174"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"438"
    ,"Station_Code":"Q5 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Dương Tử Giang"
    ,"Station_Address":"Đối diện 455-457, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754158
    ,"Long":106.65552
    ,"Polyline":"[106.65793610,10.75457954] ; [106.65551758,10.75415802]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1010"
    ,"Station_Code":"Q5 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"266, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753657
    ,"Long":106.652559
    ,"Polyline":"[106.65551758,10.75415802] ; [106.65255737,10.75365734]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"620"
    ,"Station_Code":"Q11 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Cây Mai"
    ,"Station_Address":"384, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753689
    ,"Long":106.64926
    ,"Polyline":"[106.65255737,10.75365734] ; [106.65180206,10.75356197] ; [106.65081024,10.75356197] ; [106.64926147,10.75368881]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"622"
    ,"Station_Code":"Q11 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"508, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753952
    ,"Long":106.646787
    ,"Polyline":"[106.64923859,10.75364971] ; [106.64682770,10.75389957]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"624"
    ,"Station_Code":"Q11 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"638-640, đường  Hồng Bàng, Quận 11"
    ,"Lat":10.754232
    ,"Long":106.644368
    ,"Polyline":"[106.64682770,10.75389957] ; [106.64438629,10.75417042]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"625"
    ,"Station_Code":"Q11 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Chùa Huê Lâm"
    ,"Station_Address":"690 (138), đường Hồng Bàng, Quận 11"
    ,"Lat":10.754558
    ,"Long":106.641229
    ,"Polyline":"[106.64437103,10.75423241] ; [106.64122772,10.75455761]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"623"
    ,"Station_Code":"Q11 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"786 , đường Hồng Bàng, Quận 11"
    ,"Lat":10.75477
    ,"Long":106.638428
    ,"Polyline":"[106.64122772,10.75455761] ; [106.63961029,10.75467968] ; [106.63886261,10.75473976] ; [106.63842010,10.75475979] ; [106.63842773,10.75477028]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"626"
    ,"Station_Code":"Q6 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Trường Mạc Đỉnh Chi"
    ,"Station_Address":"832-834, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754732
    ,"Long":106.635574
    ,"Polyline":"[106.63842773,10.75477028] ; [106.63762665,10.75485897] ; [106.63706207,10.75478554] ; [106.63634491,10.75484276] ; [106.63557434,10.75473213]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"627"
    ,"Station_Code":"Q6 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"528, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.753346
    ,"Long":106.633365
    ,"Polyline":"[106.63557434,10.75473213] ; [106.63557434,10.75473213] ; [106.63470459,10.75426292] ; [106.63449860,10.75430012] ; [106.63428497,10.75424767] ; [106.63415527,10.75408459] ; [106.63415527,10.75385761] ; [106.63336182,10.75334644]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"629"
    ,"Station_Code":"Q6 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"94-96, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.749589
    ,"Long":106.628435
    ,"Polyline":"[106.63336182,10.75334644] ; [106.62843323,10.74958897]"
    ,"Distance":"683"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1386"
    ,"Station_Code":"Q6 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Công Viên Phú Lâm"
    ,"Station_Address":"Đối diện 907, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.746384
    ,"Long":106.624525
    ,"Polyline":"[106.62844086,10.74954987] ; [106.62677002,10.74822044] ; [106.62452698,10.74639034]"
    ,"Distance":"559"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường Kinh Dương Vương, Quận  Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62452698,10.74638367] ; [106.62452698,10.74639320] ; [106.62393188,10.74570465] ; [106.62380981,10.74572563] ; [106.62369537,10.74569416] ; [106.62348938,10.74558353] ; [106.62247467,10.74474621] ; [106.62247467,10.74474621]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62039948,10.74309158]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"4150"
    ,"Station_Code":"QBT 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"428, Kinh Dương Vương"
    ,"Station_Address":"428, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.741383
    ,"Long":106.618377
    ,"Polyline":"[106.62039948,10.74309158] ; [106.62039948,10.74309158] ; [106.62039948,10.74309158] ; [106.62023163,10.74286366] ; [106.61849213,10.74146748] ; [106.61837769,10.74138260]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61842346,10.74136162] ; [106.61828613,10.74120903] ; [106.61775208,10.74074459] ; [106.61791992,10.74060822] ; [106.61809540,10.74043369] ; [106.61825562,10.74057102] ; [106.61831665,10.74070454]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây,  đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"4149"
    ,"Station_Code":"QBT 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"49-51 (317 ), Kinh Dương Vương"
    ,"Station_Address":"49-51 (317), đường Kinh Dương  Vương, Quận Bình Tân"
    ,"Lat":10.743396
    ,"Long":106.62136
    ,"Polyline":"[106.61831665,10.74070454] ; [106.61927795,10.74153042] ; [106.61914825,10.74167824] ; [106.62128448,10.74347210.06.62136078]"
    ,"Distance":"480"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Quận Bình  Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.62128400,10.74347200] ; [106.62307700,10.74498500]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"718"
    ,"Station_Code":"Q6 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cư xá Phú Lâm"
    ,"Station_Address":"799 (209), đường Kinh Dương V ương, Quận 6"
    ,"Lat":10.74776
    ,"Long":106.626332
    ,"Polyline":"[106.62307739,10.74498463] ; [106.62307739,10.74498463] ; [106.62366486,10.74528313] ; [106.62394714,10.74537754] ; [106.62397003,10.74564075] ; [106.62609100,10.74755955] ; [106.62633514,10.74775982]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"715"
    ,"Station_Code":"Q6 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"685 (157), đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.748877
    ,"Long":106.627727
    ,"Polyline":"[106.62633514,10.74775982] ; [106.62647247,10.74790192] ; [106.62755585,10.74875069] ; [106.62772369,10.74887657]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"720"
    ,"Station_Code":"Q6 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"93, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.751201
    ,"Long":106.630753
    ,"Polyline":"[106.62772369,10.74887657] ; [106.62799072,10.74909878] ; [106.63078308,10.75117493] ; [106.63075256,10.75120068]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"717"
    ,"Station_Code":"Q6 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Vòng xoay Ph ú Lâm"
    ,"Station_Address":"21A-21B, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.753246
    ,"Long":106.633521
    ,"Polyline":"[106.63075256,10.75120068] ; [106.63078308,10.75117493] ; [106.63323975,10.75313568] ; [106.63338470,10.75320911]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"724"
    ,"Station_Code":"Q6 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Ông Buông"
    ,"Station_Address":"963, đường Hồng B àng, Quận 6"
    ,"Lat":10.754548
    ,"Long":106.637995
    ,"Polyline":"[106.63338470,10.75320911] ; [106.63339233,10.75316048] ; [106.63367462,10.75338840] ; [106.63392639,10.75355721] ; [106.63420105,10.75375748] ; [106.63439178,10.75370026] ; [106.63448334,10.75368023] ; [106.63458252,10.75370979] ; [106.63468933,10.75378036] ; [106.63474274,10.75389957] ; [106.63474274,10.75401020] ; [106.63475037,10.75403976] ; [106.63488007,10.75415993] ; [106.63516998,10.75430965] ; [106.63539886,10.75438976] ; [106.63567352,10.75438023] ; [106.63620758,10.75440025] ; [106.63723755,10.75452995] ; [106.63781738,10.75463009] ; [106.63818359,10.75461960] ; [106.63816833,10.75453663]"
    ,"Distance":"621"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"719"
    ,"Station_Code":"Q6 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngân hàng ACB"
    ,"Station_Address":"871, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754295
    ,"Long":106.641245
    ,"Polyline":"[106.63816833,10.75453663] ; [106.63819122,10.75461006] ; [106.63948059,10.75452709] ; [106.64076996,10.75438023] ; [106.64128876,10.75432014] ; [106.64124298,10.75429535]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"721"
    ,"Station_Code":"Q6 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Nguyễn Đức Cảnh"
    ,"Station_Address":"799, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754021
    ,"Long":106.644003
    ,"Polyline":"[106.64124298,10.75429535] ; [106.64400482,10.75402069]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"723"
    ,"Station_Code":"Q6 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chùa Nam Phổ Đà"
    ,"Station_Address":"735, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753789
    ,"Long":106.645955
    ,"Polyline":"[106.64412689,10.75405025] ; [106.64515686,10.75391960] ; [106.64595032,10.75384998]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"722"
    ,"Station_Code":"Q6 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"647, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753647
    ,"Long":106.647323
    ,"Polyline":"[106.64595032,10.75384998] ; [106.64732361,10.75370979]"
    ,"Distance":"165"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.64732361,10.75370979] ; [106.64865112,10.75356007] ; [106.64975739,10.75343990] ; [106.65072632,10.75337029] ; [106.65086365,10.75333977] ; [106.65180206,10.75333023] ; [106.65232849,10.75339031]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"470"
    ,"Station_Code":"Q5 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"399, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754111
    ,"Long":106.656749
    ,"Polyline":"[106.65232849,10.75339317] ; [106.65672302,10.75413895]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh viện  Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65674591,10.75411129] ; [106.65672302,10.75413895] ; [106.65826416,10.75442123] ; [106.65923309,10.75455284]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"217, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.65921783,10.75459957] ; [106.66153717,10.75502014] ; [106.66317749,10.75535011]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bệnh viện Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66319275,10.75535965] ; [106.66320038,10.75547028] ; [106.66464996,10.75573921] ; [106.66468048,10.75567055]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"465"
    ,"Station_Code":"Q5 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"121, đường An Dư ơng Vương, Quận 5"
    ,"Lat":10.756714
    ,"Long":106.670492
    ,"Polyline":"[106.66470337,10.75564003] ; [106.66841125,10.75642014] ; [106.67047882,10.75685978]"
    ,"Distance":"666"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"469"
    ,"Station_Code":"Q5 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"59C, đường An Dương Vương, Quận 5"
    ,"Lat":10.757057
    ,"Long":106.672182
    ,"Polyline":"[106.67047882,10.75685978] ; [106.67209625,10.75716972]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"466"
    ,"Station_Code":"Q5 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"439, đường An Dương Vương, Quận 5"
    ,"Lat":10.758374
    ,"Long":106.676576
    ,"Polyline":"[106.67218018,10.75705719] ; [106.67407227,10.75745678] ; [106.67657471,10.75837421]"
    ,"Distance":"504"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"472"
    ,"Station_Code":"Q5 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"373, đường An Dương Vương, Quận 5"
    ,"Lat":10.759138
    ,"Long":106.678453
    ,"Polyline":"[106.67657471,10.75837421] ; [106.67845154,10.75913811]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"467"
    ,"Station_Code":"Q5 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Đại học Sài Gòn"
    ,"Station_Address":"273-275 , đường An Dương Vương, Quận 5"
    ,"Lat":10.760735
    ,"Long":106.682289
    ,"Polyline":"[106.67845154,10.75913811] ; [106.68228912,10.76073456]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1051"
    ,"Station_Code":"Q5 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bộ Công an"
    ,"Station_Address":"211-213, đư ờng Nguyễn Văn Cừ, Quận 5"
    ,"Lat":10.760672
    ,"Long":106.683453
    ,"Polyline":"[106.68226624,10.76074982] ; [106.68334961,10.76117039] ; [106.68351746,10.76070023]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1347"
    ,"Station_Code":"Q5 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Phan Văn Trị"
    ,"Station_Address":"165A-167, đường Nguy ễn Văn Cừ, Quận 5"
    ,"Lat":10.758169
    ,"Long":106.684381
    ,"Polyline":"[106.68351746,10.76070023] ; [106.68399048,10.75940037] ; [106.68447876,10.75819016]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"18"
    ,"Station_Code":"Q1 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Nanci"
    ,"Station_Address":"563-565 , đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.75699
    ,"Long":106.685883
    ,"Polyline":"[106.68447876,10.75819016] ; [106.68515015,10.75646019] ; [106.68536377,10.75658989] ; [106.68579102,10.75706959]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"22"
    ,"Station_Code":"Q1 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Tổng Cty Samco"
    ,"Station_Address":"449, đường Trần H ưng Đạo, Quận 1"
    ,"Lat":10.759426
    ,"Long":106.688011
    ,"Polyline":"[106.68579102,10.75706959] ; [106.68657684,10.75798035] ; [106.68794250,10.75949001]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"21"
    ,"Station_Code":"Q1 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Sở PCCC"
    ,"Station_Address":"359, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.760656
    ,"Long":106.689096
    ,"Polyline":"[106.68801117,10.75942612] ; [106.68905640,10.76070404]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"23"
    ,"Station_Code":"Q1 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Hồ Hảo Hớn"
    ,"Station_Address":"301F, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.762395
    ,"Long":106.690636
    ,"Polyline":"[106.68905640,10.76070404] ; [106.69058228,10.76240158]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"24"
    ,"Station_Code":"Q1 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Bệnh Viện  Răng Hàm Mặt"
    ,"Station_Address":"263, đường  Trần Hưng Đạo, Quận 1"
    ,"Lat":10.763567
    ,"Long":106.691612
    ,"Polyline":"[106.69058228,10.76240158] ; [106.69161224,10.76356697]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"25"
    ,"Station_Code":"Q1 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Rạp Trần Hưng Đạo"
    ,"Station_Address":"227 - 229, đường Trần Hưng Đạo, Quận  1"
    ,"Lat":10.765213
    ,"Long":106.693069
    ,"Polyline":"[106.69161224,10.76356697] ; [106.69306946,10.76521301]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"26"
    ,"Station_Code":"Q1 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"135, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767064
    ,"Long":106.694824
    ,"Polyline":"[106.69300079,10.76527023] ; [106.69467163,10.76718998]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1344"
    ,"Station_Code":"Q1 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"65G, đường Nguyễn Thái Học, Quận 1"
    ,"Lat":10.766576
    ,"Long":106.696129
    ,"Polyline":"[106.69482422,10.76706409] ; [106.69482422,10.76706409] ; [106.69474030,10.76711750] ; [106.69538116,10.76792336] ; [106.69612885,10.76657581] ; [106.69612885,10.76657581]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1196"
    ,"Station_Code":"Q4 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cầu Ông L ãnh"
    ,"Station_Address":"K48-K50, đường Hoàng Diệu , Quận 4"
    ,"Lat":10.760429
    ,"Long":106.699428
    ,"Polyline":"[106.69621277,10.76661968] ; [106.69669342,10.76585960] ; [106.69722748,10.76494980] ; [106.69761658,10.76428986] ; [106.69786835,10.76395988] ; [106.69799805,10.76381969] ; [106.69863892,10.76319027] ; [106.69959259,10.76220036] ; [106.69986725,10.76181984] ; [106.70011139,10.76146030] ; [106.70023346,10.76126003] ; [106.70041656,10.76099968] ; [106.69986725,10.76062012] ; [106.69950104,10.76035023]"
    ,"Distance":"926"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1194"
    ,"Station_Code":"Q4 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chung cư Tân Vĩnh"
    ,"Station_Address":"Đối diện 220, đường Khánh Hội, Quận 4"
    ,"Lat":10.758864
    ,"Long":106.698972
    ,"Polyline":"[106.69950104,10.76035023] ; [106.69892883,10.75992012] ; [106.69851685,10.75963974] ; [106.69857025,10.75949001] ; [106.69902039,10.75889969]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1198"
    ,"Station_Code":"Q4 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Trung tâm TDTT Quận 4"
    ,"Station_Address":"149, đường Khánh Hội, Quận 4"
    ,"Lat":10.756725
    ,"Long":106.700581
    ,"Polyline":"[106.69897461,10.75886917] ; [106.70059204,10.75677109]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1197"
    ,"Station_Code":"Q7 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Cầu Kinh Tẻ"
    ,"Station_Address":"44/7, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74845
    ,"Long":106.702196
    ,"Polyline":"[106.70060730,10.75679016] ; [106.70114899,10.75607967] ; [106.70162964,10.75549030] ; [106.70181274,10.75527000] ; [106.70191193,10.75510025] ; [106.70195770,10.75491047] ; [106.70204163,10.75397015] ; [106.70223236,10.75174046] ; [106.70237732,10.74991035] ; [106.70236969,10.74905968] ; [106.70230103,10.74845028]"
    ,"Distance":"1003"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1346"
    ,"Station_Code":"Q7 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Chung cư Minh  Thành"
    ,"Station_Address":"222, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744576
    ,"Long":106.704216
    ,"Polyline":"[106.70216370,10.74847126] ; [106.70230103,10.74845028] ; [106.70207977,10.74702740] ; [106.70200348,10.74627018] ; [106.70185852,10.74576759] ; [106.70179749,10.74535656] ; [106.70220184,10.74529362] ; [106.70250702,10.74522972] ; [106.70433044,10.74499035] ; [106.70427704,10.74456978] ; [106.70421600,10.74457645]"
    ,"Distance":"699"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1348"
    ,"Station_Code":"Q7 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Nguyễn Th ị Thập"
    ,"Station_Address":"593, đường Nguyễn  Thị Thập, Quận 7"
    ,"Lat":10.739607
    ,"Long":106.704696
    ,"Polyline":"[106.70427704,10.74456978] ; [106.70401001,10.74250984] ; [106.70375061,10.74096966] ; [106.70355225,10.73991966] ; [106.70451355,10.73974991] ; [106.70462036,10.73972988]"
    ,"Distance":"655"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1350"
    ,"Station_Code":"Q7 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Khu dân cư Tân Quy Đông"
    ,"Station_Address":"507, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.739164
    ,"Long":106.707743
    ,"Polyline":"[106.70461273,10.73967552] ; [106.70813751,10.73914051]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1349"
    ,"Station_Code":"Q7 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Đường số 38"
    ,"Station_Address":"449, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738716
    ,"Long":106.710747
    ,"Polyline":"[106.70813751,10.73915005] ; [106.71154022,10.73863983]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1351"
    ,"Station_Code":"Q7 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Mai Văn Vĩnh"
    ,"Station_Address":"351, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738368
    ,"Long":106.714003
    ,"Polyline":"[106.71154022,10.73863983] ; [106.71240234,10.73851967] ; [106.71366882,10.73845005] ; [106.71440125,10.73841000]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1352"
    ,"Station_Code":"Q7 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"269-271, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738152
    ,"Long":106.717522
    ,"Polyline":"[106.71440125,10.73841000] ; [106.71781158,10.73818970]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1354"
    ,"Station_Code":"Q7 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Tân Mỹ"
    ,"Station_Address":"8, đường Tân Mỹ, Quận 7"
    ,"Lat":10.737562
    ,"Long":106.718203
    ,"Polyline":"[106.71781158,10.73816872] ; [106.71827698,10.73815727] ; [106.71822357,10.73768806]"
    ,"Distance":"103"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1353"
    ,"Station_Code":"Q7 151"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Bệnh viện  Việt Pháp"
    ,"Station_Address":"Bệnh viện Việt Pháp, đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.733045
    ,"Long":106.718928
    ,"Polyline":"[106.71829987,10.73768044] ; [106.71817780,10.73596954] ; [106.71810913,10.73581028] ; [106.71804047,10.73480034] ; [106.71810150,10.73466015] ; [106.71824646,10.73435974] ; [106.71878815,10.73351002]"
    ,"Distance":"500"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1355"
    ,"Station_Code":"Q7 154"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Tân Trào"
    ,"Station_Address":"Văn phòng Đội Bảo vệ, đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.728222
    ,"Long":106.721873
    ,"Polyline":"[106.71875763,10.73349857] ; [106.72146606,10.72904205]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1261"
    ,"Station_Code":"Q7 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trường Nam Sài Gòn"
    ,"Station_Address":"Tr ường Nam Sài Gòn, đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.725118
    ,"Long":106.723793
    ,"Polyline":"[106.72146606,10.72904205] ; [106.72386932,10.72519398]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1258"
    ,"Station_Code":"Q7 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Mỹ Thái 2"
    ,"Station_Address":"176 (Riverside  Block E), đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.720885
    ,"Long":106.726454
    ,"Polyline":"[106.72386932,10.72519398] ; [106.72592926,10.72181034]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1356"
    ,"Station_Code":"Q7 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Nam Viên"
    ,"Station_Address":"Đối diện trường tiểu học  Việt Pháp, đường Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.718065
    ,"Long":106.728192
    ,"Polyline":"[106.72592926,10.72181034] ; [106.72805023,10.71838951]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1357"
    ,"Station_Code":"Q7 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Nam Khang"
    ,"Station_Address":"SC 9-1 Nam Khang, đường  Nguyễn Lương Bằng, Quận 7"
    ,"Lat":10.715451
    ,"Long":106.729807
    ,"Polyline":"[106.72805023,10.71838951] ; [106.72979736,10.71568298]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1359"
    ,"Station_Code":"Q7 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Mầm non Cánh Thiên Thần"
    ,"Station_Address":"Đối diện ngân hàng Agribank, đường Hoàng Quốc Việt, Quận 7"
    ,"Lat":10.713271
    ,"Long":106.732742
    ,"Polyline":"[106.72979736,10.71568298] ; [106.73109436,10.71351147] ; [106.73146057,10.71317387] ; [106.73181152,10.71308994] ; [106.73274231,10.71327114]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1361"
    ,"Station_Code":"Q7 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Ủy ban phường Phú Mỹ"
    ,"Station_Address":"43N, đường Hoàng Quốc Việt, Quận 7"
    ,"Lat":10.713764
    ,"Long":106.734973
    ,"Polyline":"[106.73274231,10.71327114] ; [106.73486328,10.71378326]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1362"
    ,"Station_Code":"Q7 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Trường Ngô Quyền"
    ,"Station_Address":"1360, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.712974
    ,"Long":106.736904
    ,"Polyline":"[106.73486328,10.71378326] ; [106.73692322,10.71426487] ; [106.73696136,10.71294212] ; [106.73696136,10.71294212]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1358"
    ,"Station_Code":"Q7 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"An Chánh Dương"
    ,"Station_Address":"1400, đường Huỳnh Tấn Phát , Quận 7"
    ,"Lat":10.711002
    ,"Long":106.737016
    ,"Polyline":"[106.73696136,10.71294212] ; [106.73696136,10.71269417] ; [106.73703003,10.71166134] ; [106.73704529,10.71141148]"
    ,"Distance":"171"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1360"
    ,"Station_Code":"Q7 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Chùa Pháp Hoa"
    ,"Station_Address":"1452, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.708958
    ,"Long":106.737152
    ,"Polyline":"[106.73710632,10.71140957] ; [106.73722839,10.70895958]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1366"
    ,"Station_Code":"Q7 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"1520-1522, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.705626
    ,"Long":106.737427
    ,"Polyline":"[106.73722839,10.70895958] ; [106.73737335,10.70650959] ; [106.73750305,10.70563984]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1149"
    ,"Station_Code":"Q7 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"Trường Tiểu học Phú Mỹ, đ ường Phạm Hữu Lầu, Quận 7"
    ,"Lat":10.704941
    ,"Long":106.735246
    ,"Polyline":"[106.73742676,10.70562553] ; [106.73742676,10.70562649] ; [106.73756409,10.70519352] ; [106.73538208,10.70492744]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1057"
    ,"Station_Code":"Q7 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"63-65, đường Phạm Hữu Lầu, Quận 7"
    ,"Lat":10.704788
    ,"Long":106.735198
    ,"Polyline":"[106.73538208,10.70492744] ; [106.73522949,10.70489311]"
    ,"Distance":"17.1223799043294"
  },
  {
     "Route_Id":"25"
    ,"Station_Id":"1054"
    ,"Station_Code":"BX 18"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Phú Xuân"
    ,"Station_Address":"Bến Phú Xuân, đường Đường số 15B, Quận 7"
    ,"Lat":10.703697
    ,"Long":106.732317
    ,"Polyline":"[106.73522949,10.70489311] ; [106.73445129,10.70479870] ; [106.73329926,10.70468807] ; [106.73256683,10.70461369] ; [106.73234558,10.70456696] ; [106.73222351,10.70392895]"
    ,"Distance":"345.875891799465"
  }]