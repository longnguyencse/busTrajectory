export const Route5 =[
  {
     "Route_Id":"5"
    ,"Station_Id":"334"
    ,"Station_Code":"QTD 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Big C"
    ,"Station_Address":"Kế 251, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.887349
    ,"Long":106.774583
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"335"
    ,"Station_Code":"QTD 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chùa Từ Quang"
    ,"Station_Address":"231, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.885494
    ,"Long":106.772271
    ,"Polyline":"[106.77468109,10.88729954] ; [106.77378082,10.88665962] ; [106.77297211,10.88607979] ; [106.77292633,10.88601017] ; [106.77262878,10.88570976] ; [106.77234650,10.88543034]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"336"
    ,"Station_Code":"QTD 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"167, đường Quốc l ộ 1K, Quận Thủ Đức"
    ,"Lat":10.882096
    ,"Long":106.769396
    ,"Polyline":"[106.77234650,10.88543034] ; [106.77198029,10.88504982] ; [106.77159882,10.88457012] ; [106.77041626,10.88317966] ; [106.76947021,10.88206005]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"338"
    ,"Station_Code":"QTD 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Thành thất Cao Đài Linh Xuân"
    ,"Station_Address":"Thành thất Cao Đài Linh Xuân, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.880158
    ,"Long":106.767744
    ,"Polyline":"[106.76947021,10.88206005] ; [106.76882935,10.88131046] ; [106.76840973,10.88078976] ; [106.76777649,10.88004971]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"337"
    ,"Station_Code":"QTD 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Linh Xuân"
    ,"Station_Address":"Chợ Linh Xuân, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.877611
    ,"Long":106.766403
    ,"Polyline":"[106.76777649,10.88004971] ; [106.76734924,10.87956047] ; [106.76692200,10.87905979] ; [106.76679993,10.87889004] ; [106.76667023,10.87862015] ; [106.76653290,10.87810993] ; [106.76647186,10.87761021]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"340"
    ,"Station_Code":"QTD 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu vượt Linh Xuân"
    ,"Station_Address":"13-15, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.874279
    ,"Long":106.765366
    ,"Polyline":"[106.76647186,10.87761021] ; [106.76644135,10.87705040] ; [106.76634216,10.87662029] ; [106.76603699,10.87584972] ; [106.76550293,10.87465954] ; [106.76551056,10.87446976] ; [106.76541901,10.87425995]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"339"
    ,"Station_Code":"QTD 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu vượt Linh Xuân"
    ,"Station_Address":"559, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.874474
    ,"Long":106.762095
    ,"Polyline":"[106.76541901,10.87425995] ; [106.76525879,10.87384033] ; [106.76509857,10.87347031] ; [106.76495361,10.87351036] ; [106.76477814,10.87355995] ; [106.76435852,10.87368965] ; [106.76364899,10.87394047] ; [106.76332092,10.87403965] ; [106.76293182,10.87407970] ; [106.76203918,10.87438011]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"341"
    ,"Station_Code":"QTD 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Giày da Thái Bình"
    ,"Station_Address":"467B, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875454
    ,"Long":106.758689
    ,"Polyline":"[106.76203918,10.87438011] ; [106.76026917,10.87495041] ; [106.75898743,10.87526989] ; [106.75866699,10.87534046]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"343"
    ,"Station_Code":"QTD 189"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến xe Lam Hồng"
    ,"Station_Address":"Đối diện 20B/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875738
    ,"Long":106.757305
    ,"Polyline":"[106.75866699,10.87534046] ; [106.75726318,10.87561035]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"342"
    ,"Station_Code":"QTD 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Cầu vượt Sóng Thần"
    ,"Station_Address":"12/28, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.876049
    ,"Long":106.755631
    ,"Polyline":"[106.75726318,10.87561035] ; [106.75557709,10.87592983]"
    ,"Distance":"187"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"344"
    ,"Station_Code":"QTD 191"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Cầu vượt Sóng Thần"
    ,"Station_Address":"275, đường Quốc lộ 1, Quận Th ủ Đức"
    ,"Lat":10.874115
    ,"Long":106.746528
    ,"Polyline":"[106.75553131,10.87594032] ; [106.75489807,10.87605953] ; [106.75421906,10.87615967] ; [106.75382996,10.87617016] ; [106.75346375,10.87615013] ; [106.75312805,10.87609959] ; [106.75231934,10.87590027] ; [106.75132751,10.87557030] ; [106.74655151,10.87399960]"
    ,"Distance":"1021"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"346"
    ,"Station_Code":"QTD 192"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Chợ Tam Hà"
    ,"Station_Address":"251B, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.873373
    ,"Long":106.744291
    ,"Polyline":"[106.74655151,10.87399960] ; [106.74433136,10.87327957]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"345"
    ,"Station_Code":"QTD 193"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"179, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.872177
    ,"Long":106.739913
    ,"Polyline":"[106.74433136,10.87327957] ; [106.74176788,10.87244987] ; [106.74092102,10.87224007] ; [106.73993683,10.87207031]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"348"
    ,"Station_Code":"QTD 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Tam Bình"
    ,"Station_Address":"Đối diện Bưu điện Tam Bình, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870828
    ,"Long":106.734474
    ,"Polyline":"[106.73993683,10.87207031] ; [106.73837280,10.87187004] ; [106.73751068,10.87174988] ; [106.73639679,10.87148952] ; [106.73533630,10.87110996] ; [106.73451233,10.87073994]"
    ,"Distance":"615"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"347"
    ,"Station_Code":"QTD 195"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ đầu mối nông sản Thủ Đức"
    ,"Station_Address":"Chợ đầu mối nông sản Thủ  Đức, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86812
    ,"Long":106.729158
    ,"Polyline":"[106.73451233,10.87073994] ; [106.73307800,10.87003994] ; [106.73204041,10.86952972] ; [106.72882080,10.86787033]"
    ,"Distance":"699"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"349"
    ,"Station_Code":"QTD 214"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã 4 Bình  Phước"
    ,"Station_Address":"777, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.863809
    ,"Long":106.72451
    ,"Polyline":"[106.72882080,10.86787033] ; [106.72811127,10.86750031] ; [106.72702026,10.86693001] ; [106.72646332,10.86676979] ; [106.72441864,10.86573029] ; [106.72399139,10.86561012] ; [106.72377777,10.86565018] ; [106.72368622,10.86561966] ; [106.72361755,10.86555958] ; [106.72355652,10.86544991] ; [106.72354889,10.86542034] ; [106.72355652,10.86528015] ; [106.72361755,10.86515045] ; [106.72366333,10.86507034] ; [106.72380066,10.86495018] ; [106.72390747,10.86491013] ; [106.72409058,10.86472034] ; [106.72431946,10.86429024] ; [106.72454834,10.86388969] ; [106.72457123,10.86384010]"
    ,"Distance":"862"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"350"
    ,"Station_Code":"QTD 215"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Hồ bơi Mèo Mun"
    ,"Station_Address":"Đối diện 782, đường Quốc lộ 13, Quận Th ủ Đức"
    ,"Lat":10.861345
    ,"Long":106.724396
    ,"Polyline":"[106.72457123,10.86384010.06.72473907] ; [10.86353016,106.72483826] ; [10.86318016,106.72486877] ; [10.86281967,106.72486877] ; [10.86262989,106.72482300] ; [10.86233997,106.72450256] ; [10.86145020,106.72444916]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"353"
    ,"Station_Code":"QTD 216"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"UBND P.Hiệp Bình Phước"
    ,"Station_Address":"715 , đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.859791
    ,"Long":106.723782
    ,"Polyline":"[106.72444916,10.86131954] ; [106.72419739,10.86071014] ; [106.72392273,10.85991001] ; [106.72386932,10.85978031]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"351"
    ,"Station_Code":"QTD 217"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm y tế P . Hiệp Bình Phước"
    ,"Station_Address":"645, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.856024
    ,"Long":106.722343
    ,"Polyline":"[106.72386932,10.85978031] ; [106.72328186,10.85824966] ; [106.72283936,10.85709000] ; [106.72255707,10.85641003] ; [106.72241211,10.85599995]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"355"
    ,"Station_Code":"QTD 218"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã 3 Đường Hiệp Bình"
    ,"Station_Address":"607, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852579
    ,"Long":106.720719
    ,"Polyline":"[106.72241211,10.85599995] ; [106.72168732,10.85418034] ; [106.72133636,10.85344028] ; [106.72078705,10.85254002]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"352"
    ,"Station_Code":"QTD 219"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã 3 Hiệp Bình"
    ,"Station_Address":"557A, đường Quốc  lộ 13, Quận Thủ Đức"
    ,"Lat":10.848727
    ,"Long":106.718346
    ,"Polyline":"[106.72078705,10.85254002] ; [106.71970367,10.85097980] ; [106.71938324,10.85054016] ; [106.71903229,10.84994030] ; [106.71888733,10.84965992] ; [106.71858978,10.84904957] ; [106.71842194,10.84869957]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"358"
    ,"Station_Code":"QTD 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cân Nhơn Hòa"
    ,"Station_Address":"447-449, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.844473
    ,"Long":106.718086
    ,"Polyline":"[106.71842194,10.84869957] ; [106.71826172,10.84827995] ; [106.71816254,10.84772968] ; [106.71811676,10.84702969] ; [106.71813965,10.84626007] ; [106.71816254,10.84447956] ; [106.71816254,10.84447002]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"354"
    ,"Station_Code":"QTD 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"385, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.84109
    ,"Long":106.716858
    ,"Polyline":"[106.71816254,10.84447002] ; [106.71817780,10.84362030] ; [106.71814728,10.84313011] ; [106.71807098,10.84270000] ; [106.71791077,10.84232998] ; [106.71782684,10.84216976] ; [106.71765137,10.84193993] ; [106.71736145,10.84158993] ; [106.71691895,10.84103966]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"359"
    ,"Station_Code":"QTD 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"327-329, đ ường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.83877
    ,"Long":106.714915
    ,"Polyline":"[106.71691895,10.84103966] ; [106.71498871,10.83872032]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"356"
    ,"Station_Code":"QTD 223"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"261, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.835822
    ,"Long":106.713745
    ,"Polyline":"[106.71498871,10.83872032] ; [106.71470642,10.83839035] ; [106.71434784,10.83794022] ; [106.71421814,10.83777046] ; [106.71411133,10.83755970] ; [106.71394348,10.83718967] ; [106.71386719,10.83691978] ; [106.71382904,10.83662033] ; [106.71382904,10.83598995] ; [106.71383667,10.83582973]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"357"
    ,"Station_Code":"QTD 224"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"173, đường Quốc l ộ 13, Quận Thủ Đức"
    ,"Lat":10.83294
    ,"Long":106.71389
    ,"Polyline":"[106.71383667,10.83582973] ; [106.71389008,10.83508968] ; [106.71392822,10.83368015] ; [106.71396637,10.83294010]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"360"
    ,"Station_Code":"QTD 225"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"UBND P.Hiệp Bình Chánh"
    ,"Station_Address":"328/5 (Đại h ọc Luật), đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.830039
    ,"Long":106.714027
    ,"Polyline":"[106.71396637,10.83294010.06.71407318] ; [10.83065033,106.71411133]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Bến xe Mi ền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71411133,10.83003998] ; [106.71411896,10.82958984] ; [106.71415710,10.82874012] ; [106.71425629,10.82705975] ; [106.71425629,10.82693958] ; [106.71420288,10.82653999] ; [106.71414185,10.82635975] ; [106.71408081,10.82625008] ; [106.71392822,10.82616997] ; [106.71382904,10.82604980] ; [106.71379089,10.82590961] ; [106.71381378,10.82575989] ; [106.71388245,10.82563972] ; [106.71392822,10.82559013] ; [106.71395874,10.82542038] ; [106.71392059,10.82497978] ; [106.71382904,10.82460022] ; [106.71369934,10.82392025] ; [106.71360779,10.82361031] ; [106.71346283,10.82227993] ; [106.71327972,10.82102013] ; [106.71291351,10.81877041] ; [106.71280670,10.81807041] ; [106.71273804,10.81783962] ; [106.71254730,10.81760979] ; [106.71222687,10.81737995] ; [106.71204376,10.81717968] ; [106.71183777,10.81707954] ; [106.71160889,10.81692028] ; [106.71140289,10.81672955] ; [106.71128845,10.81663990]"
    ,"Distance":"1601"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã Tư Nguy ễn Xí"
    ,"Station_Address":"291-293, đường Đinh Bộ Lĩnh , Quận Bình Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71128845,10.81663990] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71038818,10.81499958] ; [106.70954132,10.81330013] ; [106.70925140,10.81260014]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70925140,10.81260014] ; [106.70919037,10.81247044] ; [106.70913696,10.81227016] ; [106.70912933,10.81159019] ; [106.70913696,10.81058025] ; [106.70919037,10.80980968]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85 , đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70919037,10.80980968] ; [106.70926666,10.80805969] ; [106.70937347,10.80710983] ; [106.70938873,10.80690956]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm xăng  dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70938873,10.80690956] ; [106.70948792,10.80566978] ; [106.70947266,10.80506039] ; [106.70944214,10.80442047]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70944214,10.80442047] ; [106.70935059,10.80296993] ; [106.71051025,10.80290985]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"221, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71051025,10.80290985] ; [106.71114349,10.80286026] ; [106.71138763,10.80284023] ; [106.71137238,10.80249977] ; [106.71132660,10.80160999] ; [106.71128082,10.80160046] ; [106.71121979,10.80156994] ; [106.71115875,10.80150032] ; [106.71115112,10.80144024] ; [106.71115875,10.80136967] ; [106.71118164,10.80132008] ; [106.71125031,10.80126953] ; [106.71128082,10.80125046] ; [106.71130371,10.80125046] ; [106.71128082,10.80101967] ; [106.71122742,10.80066967] ; [106.71115875,10.79998016] ; [106.71115112,10.79981041]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trường TH Hồng Hà"
    ,"Station_Address":"153, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71115112,10.79981041] ; [106.71102905,10.79864025] ; [106.71092987,10.79813004] ; [106.71070862,10.79736042] ; [106.71057892,10.79699993] ; [106.71047211,10.79671955]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"369"
    ,"Station_Code":"QBTH 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Siêu Thị Điện máy tự do"
    ,"Station_Address":"151, đường Xô Viết Nghệ T ĩnh, Quận Bình Thạnh"
    ,"Lat":10.794978
    ,"Long":106.709368
    ,"Polyline":"[106.71047211,10.79671955] ; [106.70999146,10.79553986] ; [106.70974731,10.79522038] ; [106.70942688,10.79487991]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"373"
    ,"Station_Code":"QBTH 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"79, đường Xô Viết Nghệ Tĩnh, Quận Bình  Thạnh"
    ,"Lat":10.793534
    ,"Long":106.707979
    ,"Polyline":"[106.70942688,10.79487991] ; [106.70806122,10.79343987]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"370"
    ,"Station_Code":"Q1 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"2A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790694
    ,"Long":106.705259
    ,"Polyline":"[106.70806122,10.79343987] ; [106.70539093,10.79061031]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Đài truyền hình"
    ,"Station_Address":"Đối diện 9, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70539093,10.79061031] ; [106.70334625,10.78841972] ; [106.70207977,10.78709984]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"371"
    ,"Station_Code":"Q1 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"nhà thờ Mạc Ti Nho"
    ,"Station_Address":"16A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.786397
    ,"Long":106.701294
    ,"Polyline":"[106.70207977,10.78709984] ; [106.70136261,10.78633976]"
    ,"Distance":"115"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"372"
    ,"Station_Code":"Q1 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Phùng Khắc Khoan"
    ,"Station_Address":"2 - 4, đường Phùng Khắc Khoan, Quận 1"
    ,"Lat":10.784048
    ,"Long":106.698586
    ,"Polyline":"[106.70136261,10.78633976] ; [106.70050812,10.78544998] ; [106.69966125,10.78454018] ; [106.69882202,10.78369999] ; [106.69880676,10.78372002] ; [106.69851685,10.78398037]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"378"
    ,"Station_Code":"Q3 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Hồ Con Rùa"
    ,"Station_Address":"24 - 26, đường Trần Cao Vân, Quận 3"
    ,"Lat":10.783314
    ,"Long":106.696411
    ,"Polyline":"[106.69848633,10.78402042] ; [106.69779968,10.78466988] ; [106.69700623,10.78380966] ; [106.69647980,10.78324986]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"375"
    ,"Station_Code":"Q3 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Sân Phan Đình Phùng"
    ,"Station_Address":"8,  đường Võ Văn Tần, Quận 3"
    ,"Lat":10.781172
    ,"Long":106.694402
    ,"Polyline":"[106.69647980,10.78324986] ; [106.69615936,10.78291988] ; [106.69612122,10.78295040] ; [106.69602203,10.78299046] ; [106.69592285,10.78300953] ; [106.69580841,10.78299999] ; [106.69570160,10.78295040] ; [106.69560242,10.78287029] ; [106.69553375,10.78277016] ; [106.69550323,10.78262997] ; [106.69553375,10.78246021] ; [106.69561005,10.78232956] ; [106.69450378,10.78110981]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"377"
    ,"Station_Code":"Q3 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Bảo tàng chiến tranh"
    ,"Station_Address":"28, đường Võ Văn Tần, Quận 3"
    ,"Lat":10.779143
    ,"Long":106.69254
    ,"Polyline":"[106.69450378,10.78110981] ; [106.69397736,10.78050041] ; [106.69287109,10.77931976] ; [106.69230652,10.77869987]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"376"
    ,"Station_Code":"Q3 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Trần Quốc  Thảo"
    ,"Station_Address":"44, đường Võ Văn T ần, Quận 3"
    ,"Lat":10.777889
    ,"Long":106.691365
    ,"Polyline":"[106.69230652,10.77869987] ; [106.69140625,10.77772045]"
    ,"Distance":"146"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"379"
    ,"Station_Code":"Q3 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Đại học Mở thành phố HCM"
    ,"Station_Address":"62, đường V õ Văn Tần, Quận 3"
    ,"Lat":10.776418
    ,"Long":106.69004
    ,"Polyline":"[106.69140625,10.77772045] ; [106.69065857,10.77690029] ; [106.68974304,10.77595043]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"381"
    ,"Station_Code":"Q3 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Nguyễn Thị Minh Khai"
    ,"Station_Address":"17, đường B à Huyện Thanh Quan, Quận 3"
    ,"Lat":10.775102
    ,"Long":106.690186
    ,"Polyline":"[106.68974304,10.77595043] ; [106.68953705,10.77575016] ; [106.69020844,10.77513027]"
    ,"Distance":"131"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"380"
    ,"Station_Code":"Q3 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Cách Mạng tháng 8"
    ,"Station_Address":"284, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.773112
    ,"Long":106.688812
    ,"Polyline":"[106.69020844,10.77513027] ; [106.69053650,10.77482986] ; [106.68971252,10.77394009] ; [106.68943787,10.77363014] ; [106.68887329,10.77305984]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"383"
    ,"Station_Code":"Q3 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"414, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.77079
    ,"Long":106.686634
    ,"Polyline":"[106.68887329,10.77305984] ; [106.68713379,10.77124023] ; [106.68678284,10.77085972]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"382"
    ,"Station_Code":"Q3 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bệnh viện Từ Dũ"
    ,"Station_Address":"436, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.768946
    ,"Long":106.684883
    ,"Polyline":"[106.68675995,10.77083969] ; [106.68493652,10.76889992]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"89"
    ,"Station_Code":"Q3 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Hội Chữ thập đỏ thành phố"
    ,"Station_Address":"464 - 466, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.767691
    ,"Long":106.683693
    ,"Polyline":"[106.68493652,10.76889992] ; [106.68374634,10.76764011]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"90"
    ,"Station_Code":"Q3 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Nhà sách  Minh Khai"
    ,"Station_Address":"488, đường Nguy ễn Thị Minh Khai, Quận 3"
    ,"Lat":10.766416
    ,"Long":106.682428
    ,"Polyline":"[106.68374634,10.76764011] ; [106.68248749,10.76628017]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"385"
    ,"Station_Code":"Q10 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Công viên Âu Lạc"
    ,"Station_Address":"Đối diện số 1 , đường Hùng Vương, Quận 10"
    ,"Lat":10.764877
    ,"Long":106.680443
    ,"Polyline":"[106.68248749,10.76628017] ; [106.68229675,10.76607990] ; [106.68202972,10.76572037] ; [106.68186188,10.76556015] ; [106.68182373,10.76560974] ; [106.68177032,10.76564026] ; [106.68163300,10.76566982] ; [106.68155670,10.76564980] ; [106.68148041,10.76560020] ; [106.68141937,10.76548958] ; [106.68141174,10.76541042] ; [106.68141174,10.76535988] ; [106.68122864,10.76531982] ; [106.68122101,10.76531029] ; [106.68048096,10.76482964]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"384"
    ,"Station_Code":"Q10 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Trần Bình Trọng"
    ,"Station_Address":"Kế số 2, đường Hùng Vương, Quận 10"
    ,"Lat":10.763913
    ,"Long":106.678963
    ,"Polyline":"[106.68048096,10.76482964] ; [106.67900848,10.76385021]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"387"
    ,"Station_Code":"Q10 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Lê Hồng Phong"
    ,"Station_Address":"88, đường Hùng Vương, Quận 10"
    ,"Lat":10.762756
    ,"Long":106.677193
    ,"Polyline":"[106.67900848,10.76385021] ; [106.67780304,10.76305962] ; [106.67723083,10.76270008]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"386"
    ,"Station_Code":"Q10 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Chợ Lê Hồng Phong"
    ,"Station_Address":"400, đường Lê Hồng  Phong, Quận 10"
    ,"Lat":10.764429
    ,"Long":106.67569
    ,"Polyline":"[106.67723083,10.76270008] ; [106.67643738,10.76220989] ; [106.67598724,10.76338005] ; [106.67571259,10.76410961]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"388"
    ,"Station_Code":"Q10 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Hòa Hảo"
    ,"Station_Address":"222, đường Ngô Gia Tự, Qu ận 10"
    ,"Lat":10.763286
    ,"Long":106.671168
    ,"Polyline":"[106.67571259,10.76410961] ; [106.67523956,10.76533985] ; [106.67519379,10.76544952] ; [106.67420959,10.76523018] ; [106.67228699,10.76469994] ; [106.67160034,10.76371002] ; [106.67131042,10.76327991]"
    ,"Distance":"678"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"390"
    ,"Station_Code":"Q10 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Trường khiếm thị Nguyễn Đình Chiểu"
    ,"Station_Address":"446, đường Ng ô Gia Tự, Quận 10"
    ,"Lat":10.760857
    ,"Long":106.669525
    ,"Polyline":"[106.67131042,10.76327991] ; [106.67047119,10.76204014] ; [106.66957855,10.76080990]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"389"
    ,"Station_Code":"Q10 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Nguyễn Tiểu La"
    ,"Station_Address":"292, đường Nguyễn Chí Thanh, Quận 10"
    ,"Lat":10.759739
    ,"Long":106.667976
    ,"Polyline":"[106.66957855,10.76080990] ; [106.66898346,10.75998020] ; [106.66896057,10.75998974] ; [106.66889954,10.76000977] ; [106.66880035,10.75996017] ; [106.66876984,10.75992012] ; [106.66876221,10.75990009] ; [106.66797638,10.75973034]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"392"
    ,"Station_Code":"Q10 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Ngô Quyền"
    ,"Station_Address":"440, đường Nguyễn Chí Thanh , Quận 10"
    ,"Lat":10.759228
    ,"Long":106.665171
    ,"Polyline":"[106.66797638,10.75973034] ; [106.66631317,10.75938988]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"391"
    ,"Station_Code":"Q10 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Nhà máy bia sài gòn"
    ,"Station_Address":"Đối diện nhà máy bia Sài Gòn, đường Nguy ễn Chí Thanh, Quận 10"
    ,"Lat":10.759078
    ,"Long":106.66452
    ,"Polyline":"[106.66631317,10.75938988] ; [106.66452789,10.75903034]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"393"
    ,"Station_Code":"Q11 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"BV Răng Hàm Mặt"
    ,"Station_Address":"598, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.758364
    ,"Long":106.660828
    ,"Polyline":"[106.66452789,10.75903034] ; [106.66274261,10.75866032] ; [106.66149139,10.75844955] ; [106.66084290,10.75831032]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"395"
    ,"Station_Code":"Q5 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Bệnh viện  Chợ Rẫy"
    ,"Station_Address":"Đối diện 30-32, đường Thuận Kiều, Quận 5"
    ,"Lat":10.755381
    ,"Long":106.658369
    ,"Polyline":"[106.66084290,10.75831032] ; [106.65827942,10.75778961] ; [106.65840149,10.75646019] ; [106.65840912,10.75580025] ; [106.65841675,10.75537014]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"397"
    ,"Station_Code":"Q5 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"81, đường Châu Văn Liêm, Quận  5"
    ,"Lat":10.752445
    ,"Long":106.658792
    ,"Polyline":"[106.65841675,10.75537014] ; [106.65843964,10.75463009] ; [106.65840149,10.75444984] ; [106.65837097,10.75434017] ; [106.65849304,10.75378990] ; [106.65878296,10.75296974] ; [106.65886688,10.75245953]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15 , đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.65886688,10.75245953] ; [106.65895081,10.75201035] ; [106.65892029,10.75181961] ; [106.65897369,10.75139046]"
    ,"Distance":"120"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"138"
    ,"Station_Code":"Q5 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"65"
    ,"Station_Name":"Hải Thượng Lãn Ông"
    ,"Station_Address":"210-212, đư ờng Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750948
    ,"Long":106.658358
    ,"Polyline":"[106.65897369,10.75139046] ; [106.65902710,10.75084019] ; [106.65836334,10.75088024]"
    ,"Distance":"134"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"139"
    ,"Station_Code":"Q5 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"66"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"5, đường Trang Tử, Quận 5"
    ,"Lat":10.751128
    ,"Long":106.655086
    ,"Polyline":"[106.65836334,10.75088024] ; [106.65743256,10.75090981] ; [106.65646362,10.75100040] ; [106.65596008,10.75098991] ; [106.65547180,10.75102043] ; [106.65509033,10.75104046]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"67"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.65509033,10.75104046] ; [106.65386200,10.75109005] ; [106.65332794,10.75109005] ; [106.65193939,10.75100040] ; [106.65107727,10.75096035]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B,  đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27, đường Tháp Mười, Quận 6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.65107727,10.75096035] ; [106.65097046,10.75094986] ; [106.65100098,10.74999046] ; [106.65168762,10.75012016] ; [106.65254211,10.75026989]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"280"
    ,"Station_Code":"Q5T017"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Công viên Cửu Long"
    ,"Station_Address":"327, đường Tháp Mười, Quận 5"
    ,"Lat":10.750512
    ,"Long":106.654167
    ,"Polyline":"[106.65254211,10.75026989] ; [106.65415192,10.75061035]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"2"
    ,"Station_Code":"Q5 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"11-12, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750732
    ,"Long":106.655075
    ,"Polyline":"[106.65415192,10.75061035] ; [106.65453339,10.75069046] ; [106.65473175,10.75078964] ; [106.65503693,10.75078011]"
    ,"Distance":"100"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"14-16, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65503693,10.75078011] ; [106.65596771,10.75076008] ; [106.65647888,10.75080013] ; [106.65741730,10.75070953] ; [106.65840912,10.75067997] ; [106.65904236,10.75065041] ; [106.65911102,10.75061989] ; [106.65917206,10.75063038] ; [106.65921783,10.75065041] ; [106.65927124,10.75070953] ; [106.65926361,10.75078964] ; [106.65923309,10.75084972] ; [106.65917206,10.75088024] ; [106.65911102,10.75135994]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"5"
    ,"Station_Code":"Q5 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"68, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752566
    ,"Long":106.658937
    ,"Polyline":"[106.65911102,10.75135994] ; [106.65904999,10.75183010.06.65895081] ; [10.75201035,106.65885162]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"279"
    ,"Station_Code":"Q5 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"Đối diện 59C, đường Thuận Ki ều, Quận 5"
    ,"Lat":10.757109
    ,"Long":106.65839
    ,"Polyline":"[106.65885162,10.75255013] ; [106.65878296,10.75296974] ; [106.65849304,10.75378990] ; [106.65837097,10.75434017] ; [106.65840149,10.75444984] ; [106.65843964,10.75463009] ; [106.65840912,10.75580025] ; [106.65840149,10.75646019] ; [106.65834045,10.75710964]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"281"
    ,"Station_Code":"Q5 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"201A , đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758079
    ,"Long":106.660128
    ,"Polyline":"[106.65834045,10.75710964] ; [106.65827942,10.75778961] ; [106.65953064,10.75802994] ; [106.66010284,10.75815010]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"282"
    ,"Station_Code":"Q5 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Lý Thường Kiệt"
    ,"Station_Address":"195B, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758443
    ,"Long":106.662006
    ,"Polyline":"[106.66010284,10.75815010.06.66062164] ; [10.75825977,106.66149139] ; [10.75844955,106.66195679]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"283"
    ,"Station_Code":"Q5 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chung cư 155 Nguyễn Chí Thanh"
    ,"Station_Address":"153-155, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.759281
    ,"Long":106.666056
    ,"Polyline":"[106.66195679,10.75852966] ; [106.66274261,10.75866032] ; [106.66557312,10.75924969] ; [106.66605377,10.75934029]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"284"
    ,"Station_Code":"Q5 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường Kinh tế Công nghệ"
    ,"Station_Address":"131, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.759649
    ,"Long":106.668019
    ,"Polyline":"[106.66605377,10.75934029] ; [106.66800690,10.75973988]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"285"
    ,"Station_Code":"Q10 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường khiếm thị Nguyễn Đình Chiểu"
    ,"Station_Address":"417, đường Ngô Gia Tự, Quận 10"
    ,"Lat":10.760582
    ,"Long":106.669511
    ,"Polyline":"[106.66800690,10.75973988] ; [106.66876221,10.75990009] ; [106.66874695,10.75988007] ; [106.66876221,10.75981998] ; [106.66883087,10.75973034] ; [106.66893005,10.75971985] ; [106.66902161,10.75977993] ; [106.66905212,10.75983047] ; [106.66903687,10.75990009] ; [106.66898346,10.75998020] ; [106.66945648,10.76064014]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"286"
    ,"Station_Code":"Q10 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Hòa Hảo"
    ,"Station_Address":"277, đường Ngô Gia Tự, Quận 10"
    ,"Lat":10.762933
    ,"Long":106.671093
    ,"Polyline":"[106.66945648,10.76064014] ; [106.67067719,10.76235008] ; [106.67108154,10.76294041]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"288"
    ,"Station_Code":"Q10 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Lê Hồng Phong"
    ,"Station_Address":"419, đường L ê Hồng Phong, Quận 10"
    ,"Lat":10.764703
    ,"Long":106.675444
    ,"Polyline":"[106.67108154,10.76294041] ; [106.67228699,10.76469994] ; [106.67295074,10.76554012] ; [106.67350769,10.76638985] ; [106.67405701,10.76718044] ; [106.67426300,10.76749039] ; [106.67427826,10.76747990] ; [106.67430878,10.76747036] ; [106.67433167,10.76745987] ; [106.67440033,10.76745033] ; [106.67446899,10.76745987] ; [106.67514801,10.76556015] ; [106.67542267,10.76484966]"
    ,"Distance":"947"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"287"
    ,"Station_Code":"Q1 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Phạm Viết Chánh"
    ,"Station_Address":"Đối diện 492, đư ờng Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.766214
    ,"Long":106.682533
    ,"Polyline":"[106.67542267,10.76484966] ; [106.67703247,10.76049232] ; [106.68152618,10.76520920] ; [106.68176270,10.76522541] ; [106.68190765,10.76536751] ; [106.68186951,10.76557827] ; [106.68247986,10.76626015]"
    ,"Distance":"1408"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"290"
    ,"Station_Code":"Q1 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện Tù D ũ"
    ,"Station_Address":"Đối diện 446, đường Nguy ễn Thị Minh Khai, Quận 1"
    ,"Lat":10.768709
    ,"Long":106.685024
    ,"Polyline":"[106.68247986,10.76626015] ; [106.68479156,10.76875019]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"289"
    ,"Station_Code":"Q1 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"99, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.77185
    ,"Long":106.687943
    ,"Polyline":"[106.68479156,10.76875019] ; [106.68753815,10.77167034]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"292"
    ,"Station_Code":"Q1 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Sở Y Tế"
    ,"Station_Address":"Đối diện 214-216, đường Nguy ễn Thị Minh Khai, Quận 1"
    ,"Lat":10.774179
    ,"Long":106.690158
    ,"Polyline":"[106.68753815,10.77167034] ; [106.68811035,10.77227020] ; [106.68943787,10.77363014] ; [106.68997192,10.77422047]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"242"
    ,"Station_Code":"Q1 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà Văn Hóa Lao Động"
    ,"Station_Address":"Đối diện số 138, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.777097
    ,"Long":106.692757
    ,"Polyline":"[106.68997192,10.77422047] ; [106.69270325,10.77715015]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"291"
    ,"Station_Code":"Q1 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Pasteur"
    ,"Station_Address":"43  - 45 - 47, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.781031
    ,"Long":106.696434
    ,"Polyline":"[106.69270325,10.77715015] ; [106.69384766,10.77840996] ; [106.69582367,10.78050041] ; [106.69637299,10.78108978]"
    ,"Distance":"594"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"294"
    ,"Station_Code":"Q1 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Mạc Đỉnh  Chi"
    ,"Station_Address":"21, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.784191
    ,"Long":106.699503
    ,"Polyline":"[106.69637299,10.78108978] ; [106.69882202,10.78369999] ; [106.69941711,10.78429985]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"296"
    ,"Station_Code":"Q1 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Đinh Tiên Hoa ̀ng"
    ,"Station_Address":"15C-15D, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.786146
    ,"Long":106.70137
    ,"Polyline":"[106.69941711,10.78429985] ; [106.70015717,10.78509045] ; [106.70084381,10.78581047] ; [106.70127106,10.78625011]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"293"
    ,"Station_Code":"Q1 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"3, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.789598
    ,"Long":106.70459
    ,"Polyline":"[106.70127106,10.78625011] ; [106.70334625,10.78841972] ; [106.70446777,10.78962994]"
    ,"Distance":"513"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"295"
    ,"Station_Code":"Q1 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cầu Thị Nghè"
    ,"Station_Address":"1A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790669
    ,"Long":106.705597
    ,"Polyline":"[106.70451355,10.78966999] ; [106.70552063,10.79074001]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"298"
    ,"Station_Code":"QBTH 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nhà Thờ Th ị Nghè"
    ,"Station_Address":"22 B, đường Xô Vi ết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793445
    ,"Long":106.70814
    ,"Polyline":"[106.70552063,10.79074001] ; [106.70809174,10.79347038]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trung tâm Dưỡng Lão"
    ,"Station_Address":"138, đường Xô Viết Nghệ Tĩnh, Quận Bình  Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70809174,10.79347038] ; [106.70974731,10.79522038] ; [106.70999146,10.79553986] ; [106.71012878,10.79586029] ; [106.71057892,10.79699993] ; [106.71076202,10.79751968]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"246, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71076202,10.79751968] ; [106.71092987,10.79813004] ; [106.71101379,10.79852962] ; [106.71112061,10.79951000] ; [106.71114349,10.79975986]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ T ĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71114349,10.79975986] ; [106.71124268,10.80076027] ; [106.71130371,10.80125046] ; [106.71134949,10.80123997] ; [106.71141052,10.80125999] ; [106.71148682,10.80130959] ; [106.71153259,10.80138016] ; [106.71153259,10.80148029] ; [106.71147919,10.80154991] ; [106.71141815,10.80158997] ; [106.71134186,10.80160999] ; [106.71132660,10.80160999] ; [106.71135712,10.80218983] ; [106.71138763,10.80284023] ; [106.71141815,10.80298042] ; [106.71143341,10.80377960] ; [106.71147919,10.80475044]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Th ạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71147919,10.80475044] ; [106.71151733,10.80535984] ; [106.71154022,10.80655003] ; [106.71154022,10.80681992] ; [106.71156311,10.80747032] ; [106.71161652,10.80797005] ; [106.71167755,10.80821037] ; [106.71177673,10.80848980] ; [106.71190643,10.80883980] ; [106.71202850,10.80918026]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222 /13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71202850,10.80918026] ; [106.71212006,10.80941010.06.71227264] ; [10.81005001,106.71235657]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bến xe Mi ền Đông"
    ,"Station_Address":"126-128, đường Qu ốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71235657,10.81079960] ; [106.71253967,10.81233025]"
    ,"Distance":"171"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71253967,10.81233025] ; [106.71272278,10.81385994]"
    ,"Distance":"171"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"304"
    ,"Station_Code":"QTD 198"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường TH Bình Triệu"
    ,"Station_Address":"136, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.829247
    ,"Long":106.71434
    ,"Polyline":"[106.71272278,10.81385994] ; [106.71293640,10.81564045] ; [106.71305084,10.81651974] ; [106.71320343,10.81752968] ; [106.71324158,10.81793976] ; [106.71360016,10.82091999] ; [106.71389771,10.82341957] ; [106.71395111,10.82402992] ; [106.71395874,10.82425976] ; [106.71408081,10.82483006] ; [106.71418762,10.82528019] ; [106.71424866,10.82542038] ; [106.71430969,10.82551003] ; [106.71439362,10.82555008] ; [106.71452332,10.82567024] ; [106.71456146,10.82575035] ; [106.71457672,10.82583046] ; [106.71456909,10.82598972] ; [106.71450043,10.82612038] ; [106.71440887,10.82625008] ; [106.71437836,10.82647991] ; [106.71437836,10.82715034] ; [106.71430969,10.82845974] ; [106.71427917,10.82911015] ; [106.71427155,10.82923985]"
    ,"Distance":"1744"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"309"
    ,"Station_Code":"QTD 199"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"64/1, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.832655
    ,"Long":106.714149
    ,"Polyline":"[106.71427155,10.82923985] ; [106.71415710,10.83108997] ; [106.71408844,10.83248043] ; [106.71408081,10.83265018]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"306"
    ,"Station_Code":"QTD 200"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"416, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.836135
    ,"Long":106.714012
    ,"Polyline":"[106.71408081,10.83265018] ; [106.71398926,10.83428955] ; [106.71394348,10.83520031] ; [106.71394348,10.83563042] ; [106.71392059,10.83613014]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"310"
    ,"Station_Code":"QTD 201"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"486, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.838815
    ,"Long":106.715317
    ,"Polyline":"[106.71391296,10.83619022] ; [106.71391296,10.83650970] ; [106.71394348,10.83681011] ; [106.71401215,10.83708000] ; [106.71412659,10.83742046] ; [106.71427917,10.83771038] ; [106.71449280,10.83800030] ; [106.71515656,10.83878040] ; [106.71524048,10.83887959]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"312"
    ,"Station_Code":"QTD 202"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"510, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.841072
    ,"Long":106.71714
    ,"Polyline":"[106.71524048,10.83887959] ; [106.71601105,10.83979988] ; [106.71708679,10.84111023]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"307"
    ,"Station_Code":"QTD 203"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cân Nhơn H òa"
    ,"Station_Address":"Cân Nhơn Hòa, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.844687
    ,"Long":106.718307
    ,"Polyline":"[106.71708679,10.84111023] ; [106.71772003,10.84187984] ; [106.71788025,10.84210014] ; [106.71803284,10.84237957] ; [106.71814728,10.84270954] ; [106.71823120,10.84305954] ; [106.71826172,10.84362984] ; [106.71824646,10.84469032]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"308"
    ,"Station_Code":"QTD 204"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngã 3 Hiệp Bình"
    ,"Station_Address":"1/42A, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.848944
    ,"Long":106.718704
    ,"Polyline":"[106.71824646,10.84469032] ; [106.71823120,10.84589958] ; [106.71822357,10.84700966] ; [106.71823120,10.84759998] ; [106.71832275,10.84811974] ; [106.71843719,10.84848976] ; [106.71864319,10.84897995]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"314"
    ,"Station_Code":"QTD 205"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã 3 Đường Hiệp Bình"
    ,"Station_Address":"620, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852921
    ,"Long":106.721222
    ,"Polyline":"[106.71864319,10.84897995] ; [106.71903992,10.84974957] ; [106.71926880,10.85019016] ; [106.71974945,10.85093975] ; [106.72103119,10.85272980] ; [106.72116089,10.85295010]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"316"
    ,"Station_Code":"QTD 206"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm y tế Hiệp Bình Phước"
    ,"Station_Address":"702, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.855787
    ,"Long":106.722504
    ,"Polyline":"[106.72116089,10.85295010.06.72158813] ; [10.85377026,106.72202301] ; [10.85478020,106.72242737]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"311"
    ,"Station_Code":"QTD 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"UBND P.Hiệp Bình Phước"
    ,"Station_Address":"750, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.858809
    ,"Long":106.723663
    ,"Polyline":"[106.72242737,10.85581017] ; [106.72274017,10.85661030] ; [106.72328949,10.85807037] ; [106.72358704,10.85883045]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"313"
    ,"Station_Code":"QTD 208"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"784, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.861172
    ,"Long":106.724564
    ,"Polyline":"[106.72358704,10.85883045] ; [106.72450256,10.86120033]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"318"
    ,"Station_Code":"QTD 209"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngã 4 Bình Phước"
    ,"Station_Address":"828, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.863845
    ,"Long":106.724792
    ,"Polyline":"[106.72450256,10.86120033] ; [106.72486115,10.86213017] ; [106.72496033,10.86248016] ; [106.72498322,10.86283016] ; [106.72495270,10.86308956] ; [106.72486877,10.86340046] ; [106.72470093,10.86380005]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"315"
    ,"Station_Code":"QTD 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Chợ Đầu Mối"
    ,"Station_Address":"120, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86689
    ,"Long":106.727425
    ,"Polyline":"[106.72470093,10.86380005] ; [106.72431946,10.86454964] ; [106.72418213,10.86485004] ; [106.72416687,10.86505985] ; [106.72418976,10.86513042] ; [106.72427368,10.86524010.06.72438049] ; [10.86532974,106.72454834] ; [10.86540985,106.72463989] ; [10.86544991,106.72666168] ; [10.86645985,106.72680664] ; [10.86657047,106.72705841] ; [10.86676025,106.72728729] ; [10.86688042,106.72740173]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"320"
    ,"Station_Code":"QTD 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Chợ Đầu Mối"
    ,"Station_Address":"160, đường  Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86831
    ,"Long":106.730198
    ,"Polyline":"[106.72740173,10.86693001] ; [106.73017120,10.86837959]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"317"
    ,"Station_Code":"QTD 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Chợ Tam Bình"
    ,"Station_Address":"Chợ Tam Bình, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.87086
    ,"Long":106.73538
    ,"Polyline":"[106.73017120,10.86837959] ; [106.73184967,10.86923027] ; [106.73319244,10.86993027] ; [106.73468781,10.87067986] ; [106.73535919,10.87098026]"
    ,"Distance":"637"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"322"
    ,"Station_Code":"QTD 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"376, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871766
    ,"Long":106.739666
    ,"Polyline":"[106.73535919,10.87098026] ; [106.73597717,10.87121964] ; [106.73674774,10.87143993] ; [106.73748779,10.87160969] ; [106.73834991,10.87172985] ; [106.73964691,10.87189960]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"319"
    ,"Station_Code":"QTD 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Chợ Tam H ải"
    ,"Station_Address":"450, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.872935
    ,"Long":106.744081
    ,"Polyline":"[106.73964691,10.87189960] ; [106.74082184,10.87207985] ; [106.74160767,10.87226963] ; [106.74257660,10.87257004] ; [106.74403381,10.87304974]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"321"
    ,"Station_Code":"QTD 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Cầu vượt Sóng Thần"
    ,"Station_Address":"Đối diện 275, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.873905
    ,"Long":106.747128
    ,"Polyline":"[106.74403381,10.87304974] ; [106.74707794,10.87403011]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"323"
    ,"Station_Code":"QTD 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Bến xe Lam Hồng"
    ,"Station_Address":"6/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875706
    ,"Long":106.75562
    ,"Polyline":"[106.74707794,10.87403011] ; [106.74913025,10.87469006] ; [106.75228119,10.87574005] ; [106.75308990,10.87596035] ; [106.75370026,10.87602043] ; [106.75434113,10.87600994] ; [106.75489807,10.87592983] ; [106.75566101,10.87580013]"
    ,"Distance":"974"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"325"
    ,"Station_Code":"QTD 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Giày da Thái Bình"
    ,"Station_Address":"20/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875353
    ,"Long":106.757466
    ,"Polyline":"[106.75566101,10.87580013] ; [106.75749969,10.87545013]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"326"
    ,"Station_Code":"QTDT176"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Bình Đường"
    ,"Station_Address":"50/8, đường Quốc lộ 1A (Không có), Quận Thủ Đức"
    ,"Lat":10.875032
    ,"Long":106.759239
    ,"Polyline":"[106.75749969,10.87545013] ; [106.75924683,10.87508965]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"328"
    ,"Station_Code":"QTD 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Linh Xuân"
    ,"Station_Address":"54/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.874474
    ,"Long":106.76091
    ,"Polyline":"[106.75924683,10.87508965] ; [106.76019287,10.87485027] ; [106.76094055,10.87462044]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"324"
    ,"Station_Code":"QTD 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Cầu vượt Linh  Xuân"
    ,"Station_Address":"Kho 856, đường Qu ốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.873973
    ,"Long":106.762476
    ,"Polyline":"[106.76094055,10.87462044] ; [106.76249695,10.87411022]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"330"
    ,"Station_Code":"QTD 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Cầu vượt Linh Xuân"
    ,"Station_Address":"4, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.874434
    ,"Long":106.765579
    ,"Polyline":"[106.76249695,10.87411022] ; [106.76289368,10.87397957] ; [106.76309204,10.87384033] ; [106.76499176,10.87318993] ; [106.76525879,10.87384033] ; [106.76551056,10.87446976]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"327"
    ,"Station_Code":"QTD 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Chợ Linh Xuân"
    ,"Station_Address":"Đối diện Chợ Linh Xuân, đường Quốc lộ 1K, Quận Thủ  Đức"
    ,"Lat":10.877382
    ,"Long":106.766628
    ,"Polyline":"[106.76553345,10.87448978] ; [106.76564789,10.87458992] ; [106.76580811,10.87504959] ; [106.76628876,10.87623024] ; [106.76644135,10.87664032] ; [106.76651764,10.87709045] ; [106.76654053,10.87738037]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"329"
    ,"Station_Code":"QTD 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Thánh thất Cao Đài Linh Xuân"
    ,"Station_Address":"160, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.88015
    ,"Long":106.768066
    ,"Polyline":"[106.76654053,10.87738037] ; [106.76657104,10.87773037] ; [106.76660919,10.87810040] ; [106.76670074,10.87843037] ; [106.76685333,10.87876987] ; [106.76699066,10.87901020] ; [106.76754761,10.87965965] ; [106.76804352,10.88018036]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"332"
    ,"Station_Code":"QTD 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"202-204, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.881807
    ,"Long":106.769487
    ,"Polyline":"[106.76804352,10.88018036] ; [106.76856995,10.88086033] ; [106.76940918,10.88185024]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"331"
    ,"Station_Code":"QTD 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Chùa Từ Quang"
    ,"Station_Address":"Chùa Từ Quang, đường Quốc lộ 1K, Quận Thủ Đức"
    ,"Lat":10.885452
    ,"Long":106.772568
    ,"Polyline":"[106.76940918,10.88185024] ; [106.77101135,10.88374043] ; [106.77243805,10.88541985] ; [106.77252197,10.88549995]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"5"
    ,"Station_Id":"333"
    ,"Station_Code":"QTD 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Big C"
    ,"Station_Address":"57/8, đường Quốc lộ 1K, Qu ận Thủ Đức"
    ,"Lat":10.887267
    ,"Long":106.774879
    ,"Polyline":"[106.77252197,10.88549995] ; [106.77285004,10.88582039] ; [106.77326202,10.88615036] ; [106.77419281,10.88685036] ; [106.77484131,10.88731956]"
    ,"Distance":"324"
  }]