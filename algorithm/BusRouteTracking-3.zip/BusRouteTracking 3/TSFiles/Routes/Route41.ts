export const Route41 =[

  {
     "Route_Id":"41"
    ,"Station_Id":"538"
    ,"Station_Code":"BX87"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Đại học Quốc gia"
    ,"Station_Address":"Bến xe buýt Khu A Đô thị Quốc gia, đường  Đường nội bộ Đại học Quốc gia, Quận Thủ Đức"
    ,"Lat":10.873805046081543
    ,"Long":106.8020248413086
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"572"
    ,"Station_Code":"QTD 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"621-Ngã 3 Lâm Viên"
    ,"Station_Address":"Nhà máy Tiến Thành, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871128
    ,"Long":106.806979
    ,"Polyline":"[106.80200195,10.87359047] ; [106.80274963,10.87351036] ; [106.80330658,10.87353039] ; [106.80415344,10.87364006] ; [106.80455017,10.87378979] ; [106.80496216,10.87419033] ; [106.80516815,10.87467003] ; [106.80522919,10.87506008] ; [106.80531311,10.87502003] ; [106.80535889,10.87504005] ; [106.80538177,10.87506008] ; [106.80654144,10.87452984] ; [106.80673981,10.87444019] ; [106.80734253,10.87413025] ; [106.80787659,10.87378979] ; [106.80809784,10.87347031] ; [106.80850983,10.87308979] ; [106.80766296,10.87189960] ; [106.80683899,10.87077999]"
    ,"Distance":"1227"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo dục Quốc phòng, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80683899,10.87077999] ; [106.80651855,10.87038040] ; [106.80586243,10.86958027] ; [106.80507660,10.86878967] ; [106.80455017,10.86830044] ; [106.80441284,10.86816978]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"574"
    ,"Station_Code":"QTD 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Khu DL Suối Tiên"
    ,"Station_Address":"9/29, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86605
    ,"Long":106.801116
    ,"Polyline":"[106.80436707,10.86821556] ; [106.80441284,10.86816978] ; [106.80362701,10.86754036] ; [106.80290985,10.86711407] ; [106.80229950,10.86674500] ; [106.80139160,10.86617661] ; [106.80114746,10.86603260]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"4560"
    ,"Station_Code":"QTD 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"18/1, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.865613
    ,"Long":106.800381
    ,"Polyline":"[106.80114746,10.86603260] ; [106.80038452,10.86561298]"
    ,"Distance":"96"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2145"
    ,"Station_Code":"QTD 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Thảo Nguyên"
    ,"Station_Address":"35B, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.865335
    ,"Long":106.793938
    ,"Polyline":"[106.80038452,10.86561298] ; [106.80038452,10.86561298] ; [106.79933167,10.86490631] ; [106.79801178,10.86447430] ; [106.79593658,10.86462212] ; [106.79489136,10.86480141] ; [106.79393768,10.86533546] ; [106.79393768,10.86533546]"
    ,"Distance":"755"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"500"
    ,"Station_Code":"QTD 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Đối diện 1026-1028, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.866961
    ,"Long":106.791101
    ,"Polyline":"[106.79393768,10.86533546] ; [106.79380798,10.86546516] ; [106.79353333,10.86562824] ; [106.79322052,10.86575031] ; [106.79306030,10.86583042] ; [106.79264832,10.86610031] ; [106.79223633,10.86635017] ; [106.79171753,10.86668777] ; [106.79132843,10.86684036] ; [106.79108429,10.86692429]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1101"
    ,"Station_Code":"QTD 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"Kế 21, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867404
    ,"Long":106.787265
    ,"Polyline":"[106.79108429,10.86692429] ; [106.79060364,10.86705589] ; [106.79019928,10.86717224] ; [106.78983307,10.86722469] ; [106.78916168,10.86727715] ; [106.78829193,10.86734104] ; [106.78670502,10.86738396]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1102"
    ,"Station_Code":"QTD 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty điện tử Samsung"
    ,"Station_Address":"Kế 59/6, đường Quốc lộ 1,  Quận Thủ Đức"
    ,"Lat":10.867867
    ,"Long":106.782201
    ,"Polyline":"[106.78669739,10.86732006] ; [106.78428650,10.86742020] ; [106.78352356,10.86748028] ; [106.78308105,10.86754990] ; [106.78215790,10.86775970]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1103"
    ,"Station_Code":"QTD 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Đại học Kinh tế -Luật"
    ,"Station_Address":"Đại học Kinh tế -Luật, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.869274
    ,"Long":106.777909
    ,"Polyline":"[106.78215790,10.86775970] ; [106.78076935,10.86818981] ; [106.77931976,10.86865044] ; [106.77787018,10.86913967]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2142"
    ,"Station_Code":"QTD 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trung tâm kho vận Linh Xuân"
    ,"Station_Address":"Trung tâm kho vận Linh Xuân, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870254
    ,"Long":106.774932
    ,"Polyline":"[106.77789307,10.86920547] ; [106.77770233,10.86928463] ; [106.77612305,10.86979008] ; [106.77548218,10.86999035] ; [106.77510071,10.87010670] ; [106.77489471,10.87017918]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2147"
    ,"Station_Code":"QTD 185"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nghĩa trang Thành phố"
    ,"Station_Address":"Cột điện NG/1, đường Quốc lộ 1, Quận Th ủ Đức"
    ,"Lat":10.870912
    ,"Long":106.772878
    ,"Polyline":"[106.77489471,10.87017918] ; [106.77470398,10.87025928] ; [106.77286530,10.87084293]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2143"
    ,"Station_Code":"QTD 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Công ty Nissan"
    ,"Station_Address":"Đối diện công ty Nissan, đường Quốc lộ 1, Quận Thủ  Đức"
    ,"Lat":10.871571
    ,"Long":106.770823
    ,"Polyline":"[106.77286530,10.87084293] ; [106.77080536,10.87153435]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"339"
    ,"Station_Code":"QTD 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu vượt Linh Xuân"
    ,"Station_Address":"559, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.874474
    ,"Long":106.762095
    ,"Polyline":"[106.77078247,10.87147045] ; [106.76754761,10.87252998] ; [106.76730347,10.87269974] ; [106.76686859,10.87285042] ; [106.76580811,10.87322998] ; [106.76458740,10.87362003] ; [106.76332092,10.87403965] ; [106.76293182,10.87407970] ; [106.76233673,10.87427998] ; [106.76203918,10.87438011]"
    ,"Distance":"1025"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"341"
    ,"Station_Code":"QTD 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Giày da Thái Bình"
    ,"Station_Address":"467B, đường Qu ốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875454
    ,"Long":106.758689
    ,"Polyline":"[106.76203918,10.87438011] ; [106.76026917,10.87495041] ; [106.75898743,10.87526989] ; [106.75866699,10.87534046]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"343"
    ,"Station_Code":"QTD 189"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bến xe Lam Hồng"
    ,"Station_Address":"Đối diện 20B/8, đường Quốc lộ 1, Quận  Thủ Đức"
    ,"Lat":10.875738
    ,"Long":106.757305
    ,"Polyline":"[106.75866699,10.87534046] ; [106.75726318,10.87561035]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"342"
    ,"Station_Code":"QTD 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu vượt Sóng Thần"
    ,"Station_Address":"12/28, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.876049
    ,"Long":106.755631
    ,"Polyline":"[106.75726318,10.87561035] ; [106.75557709,10.87592983]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"344"
    ,"Station_Code":"QTD 191"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu vượt Sóng Thần"
    ,"Station_Address":"275, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.874115
    ,"Long":106.746528
    ,"Polyline":"[106.75553131,10.87594032] ; [106.75489807,10.87605953] ; [106.75421906,10.87615967] ; [106.75382996,10.87617016] ; [106.75346375,10.87615013] ; [106.75312805,10.87609959] ; [106.75231934,10.87590027] ; [106.75132751,10.87557030] ; [106.74655151,10.87399960]"
    ,"Distance":"1034"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"346"
    ,"Station_Code":"QTD 192"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Tam  Hà"
    ,"Station_Address":"251B, đường Quốc lộ  1, Quận Thủ Đức"
    ,"Lat":10.873373
    ,"Long":106.744291
    ,"Polyline":"[106.74655151,10.87399960] ; [106.74433136,10.87327957]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"345"
    ,"Station_Code":"QTD 193"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"179 , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.872177
    ,"Long":106.739913
    ,"Polyline":"[106.74433136,10.87327957] ; [106.74176788,10.87244987] ; [106.74092102,10.87224007] ; [106.73993683,10.87207985]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"348"
    ,"Station_Code":"QTD 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Tam Bình"
    ,"Station_Address":"Đối diện Bưu điện Tam Bình , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870828
    ,"Long":106.734474
    ,"Polyline":"[106.73993683,10.87207985] ; [106.73837280,10.87187004] ; [106.73751068,10.87174988] ; [106.73639679,10.87148952] ; [106.73533630,10.87110996] ; [106.73451233,10.87073994]"
    ,"Distance":"626"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"347"
    ,"Station_Code":"QTD 195"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ đầu mối  nông sản Thủ Đức"
    ,"Station_Address":"Chợ đầu mối nông sản Thủ Đức, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86812
    ,"Long":106.729158
    ,"Polyline":"[106.73451233,10.87073994] ; [106.73307800,10.87003994] ; [106.73204041,10.86952972] ; [106.72882080,10.86787033]"
    ,"Distance":"716"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"349"
    ,"Station_Code":"QTD 214"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã 4 Bình Phước"
    ,"Station_Address":"777, đường Quốc l ộ 13, Quận Thủ Đức"
    ,"Lat":10.863809
    ,"Long":106.72451
    ,"Polyline":"[106.72882080,10.86787033] ; [106.72811127,10.86750031] ; [106.72702026,10.86693001] ; [106.72646332,10.86676979] ; [106.72441864,10.86573029] ; [106.72399139,10.86561012] ; [106.72377777,10.86565018] ; [106.72368622,10.86561966] ; [106.72361755,10.86555958] ; [106.72355652,10.86544991] ; [106.72354889,10.86542034] ; [106.72355652,10.86528015] ; [106.72361755,10.86515045] ; [106.72366333,10.86507034] ; [106.72380066,10.86495018] ; [106.72390747,10.86491013] ; [106.72409058,10.86472034] ; [106.72431946,10.86429024] ; [106.72454834,10.86388969] ; [106.72457123,10.86384010]"
    ,"Distance":"882"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"350"
    ,"Station_Code":"QTD 215"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Hồ bơi Mèo Mun"
    ,"Station_Address":"Đối diện 782, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.861345
    ,"Long":106.724396
    ,"Polyline":"[106.72457123,10.86384010.06.72473907] ; [10.86353016,106.72483826] ; [10.86318016,106.72486877] ; [10.86281967,106.72486877] ; [10.86262989,106.72482300] ; [10.86233997,106.72450256] ; [10.86145020,106.72444916]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"353"
    ,"Station_Code":"QTD 216"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"UBND P.Hi ệp Bình Phước"
    ,"Station_Address":"715, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.859791
    ,"Long":106.723782
    ,"Polyline":"[106.72444916,10.86131954] ; [106.72419739,10.86071014] ; [106.72392273,10.85991001] ; [106.72386932,10.85978031]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"351"
    ,"Station_Code":"QTD 217"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm y tế P. Hiệp Bình Phước"
    ,"Station_Address":"645 , đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.856024
    ,"Long":106.722343
    ,"Polyline":"[106.72386932,10.85978031] ; [106.72328186,10.85824966] ; [106.72283936,10.85709000] ; [106.72255707,10.85641003] ; [106.72241211,10.85599995]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"355"
    ,"Station_Code":"QTD 218"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã 3 Đường  Hiệp Bình"
    ,"Station_Address":"607, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852579
    ,"Long":106.720719
    ,"Polyline":"[106.72241211,10.85599995] ; [106.72168732,10.85418034] ; [106.72133636,10.85344028] ; [106.72078705,10.85254002]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"352"
    ,"Station_Code":"QTD 219"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã 3 Hiệp Bình"
    ,"Station_Address":"557A, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.848727
    ,"Long":106.718346
    ,"Polyline":"[106.72078705,10.85254002] ; [106.71970367,10.85097980] ; [106.71938324,10.85054016] ; [106.71903229,10.84994030] ; [106.71888733,10.84965992] ; [106.71858978,10.84904957] ; [106.71842194,10.84869957]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"358"
    ,"Station_Code":"QTD 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cân Nhơn Hòa"
    ,"Station_Address":"447-449, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.844473
    ,"Long":106.718086
    ,"Polyline":"[106.71842194,10.84869957] ; [106.71826172,10.84827995] ; [106.71816254,10.84772968] ; [106.71811676,10.84702969] ; [106.71813965,10.84626007] ; [106.71816254,10.84447956] ; [106.71816254,10.84447002]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"354"
    ,"Station_Code":"QTD 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"385, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.84109
    ,"Long":106.716858
    ,"Polyline":"[106.71816254,10.84447002] ; [106.71817780,10.84362030] ; [106.71814728,10.84313011] ; [106.71807098,10.84270000] ; [106.71791077,10.84232998] ; [106.71782684,10.84216976] ; [106.71765137,10.84193993] ; [106.71736145,10.84158993] ; [106.71691895,10.84103966]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"359"
    ,"Station_Code":"QTD 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"327-329, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.83877
    ,"Long":106.714915
    ,"Polyline":"[106.71691895,10.84103966] ; [106.71498871,10.83872032]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"356"
    ,"Station_Code":"QTD 223"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"261, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.835822
    ,"Long":106.713745
    ,"Polyline":"[106.71498871,10.83872032] ; [106.71470642,10.83839035] ; [106.71434784,10.83794022] ; [106.71421814,10.83777046] ; [106.71411133,10.83755970] ; [106.71394348,10.83718967] ; [106.71386719,10.83691978] ; [106.71382904,10.83662033] ; [106.71382904,10.83598995] ; [106.71383667,10.83582973]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"357"
    ,"Station_Code":"QTD 224"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"173, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.83294
    ,"Long":106.71389
    ,"Polyline":"[106.71383667,10.83582973] ; [106.71389008,10.83508968] ; [106.71392822,10.83368015] ; [106.71396637,10.83294010]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"360"
    ,"Station_Code":"QTD 225"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"UBND P.Hiệp Bình Chánh"
    ,"Station_Address":"328/5 (Đại học Luật), đường Quốc lộ 13, Quận Thủ Đ ức"
    ,"Lat":10.830039
    ,"Long":106.714027
    ,"Polyline":"[106.71396637,10.83294010.06.71407318] ; [10.83065033,106.71411133]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71411133,10.83003998] ; [106.71411896,10.82958984] ; [106.71415710,10.82874012] ; [106.71423340,10.82748985] ; [106.71427155,10.82697964] ; [106.71427917,10.82686043] ; [106.71420288,10.82660961] ; [106.71407318,10.82623005] ; [106.71395111,10.82618046] ; [106.71385956,10.82606983] ; [106.71382141,10.82596016] ; [106.71382141,10.82581043] ; [106.71388245,10.82565975] ; [106.71394348,10.82559013] ; [106.71389771,10.82511997] ; [106.71379089,10.82446957] ; [106.71375275,10.82433033] ; [106.71369171,10.82413006] ; [106.71338654,10.82229996] ; [106.71288300,10.81877995] ; [106.71279907,10.81809044] ; [106.71273804,10.81783962] ; [106.71263885,10.81770992] ; [106.71254730,10.81760979] ; [106.71222687,10.81737995] ; [106.71204376,10.81717968] ; [106.71183777,10.81707954] ; [106.71160889,10.81692028] ; [106.71128845,10.81663990]"
    ,"Distance":"1612"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1408"
    ,"Station_Code":"QBTH 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã năm Liệt Sĩ"
    ,"Station_Address":"222/4 Ter, đường Nguyễn Xí, Quận Bình Thạnh"
    ,"Lat":10.81204
    ,"Long":106.710624
    ,"Polyline":"[106.71128845,10.81663990] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71038818,10.81499958] ; [106.70954132,10.81330013] ; [106.71063995,10.81206989]"
    ,"Distance":"609"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1410"
    ,"Station_Code":"QBTH 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chợ Phường 25"
    ,"Station_Address":"đối diện 134 /4A, đường Ung Văn Khiêm, Quận Bình Thạnh"
    ,"Lat":10.808304
    ,"Long":106.714674
    ,"Polyline":"[106.71062469,10.81204033] ; [106.71059418,10.81202984] ; [106.71063995,10.81206989] ; [106.71228790,10.81021976] ; [106.71260834,10.80994987] ; [106.71311188,10.80943966] ; [106.71337891,10.80918980] ; [106.71417999,10.80860996] ; [106.71440887,10.80843639] ; [106.71467590,10.80830383]"
    ,"Distance":"622"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1405"
    ,"Station_Code":"QBTH 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Đại học  Ngoại Thương"
    ,"Station_Address":"8A, đường Đường D2, Quận Bình Thạnh"
    ,"Lat":10.806444
    ,"Long":106.716042
    ,"Polyline":"[106.71467590,10.80830383] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71452332,10.80814362] ; [106.71557617,10.80785656] ; [106.71628571,10.80765057] ; [106.71600342,10.80644417] ; [106.71600342,10.80644417] ; [106.71604156,10.80644417]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1407"
    ,"Station_Code":"QBTH 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trường ĐH Giao thông Vận tải Tp. HCM"
    ,"Station_Address":"74 Cư xá Văn  Thánh Bắc, đường Đường D2, Quận Bình Thạnh"
    ,"Lat":10.804057
    ,"Long":106.715843
    ,"Polyline":"[106.71607208,10.80642986] ; [106.71597290,10.80599976] ; [106.71595001,10.80583954] ; [106.71589661,10.80473995] ; [106.71588135,10.80438042]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường  Hutech"
    ,"Station_Address":"483, đường Điện Bi ên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71584320,10.80405712] ; [106.71584320,10.80405712] ; [106.71578217,10.80307961] ; [106.71571350,10.80268955] ; [106.71565247,10.80245018] ; [106.71533203,10.80154991] ; [106.71520233,10.80117512] ; [106.71496582,10.80119610.06.71485901] ; [10.80122757,106.71485901]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"419, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71485901,10.80122757] ; [106.71471405,10.80127525] ; [106.71443939,10.80134869] ; [106.71388245,10.80146503] ; [106.71343231,10.80159092] ; [106.71300507,10.80169678] ; [106.71281433,10.80164433] ; [106.71244812,10.80163860]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Vòng xoay  Hàng Xanh"
    ,"Station_Address":"221, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71244812,10.80163860] ; [106.71281433,10.80160427] ; [106.71281433,10.80160427] ; [106.71281433,10.80160427] ; [106.71281433,10.80160427] ; [106.71158600,10.80160713] ; [106.71154785,10.80167007] ; [106.71141052,10.80174446] ; [106.71130371,10.80173397] ; [106.71119690,10.80172348] ; [106.71112061,10.80161285] ; [106.71104431,10.80141735] ; [106.71118927,10.80123806] ; [106.71119690,10.80095863] ; [106.71113586,10.79981041] ; [106.71113586,10.79981041] ; [106.71113586,10.79981041] ; [106.71113586,10.79981041] ; [106.71107483,10.79983711]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trường TH Hồng Hà"
    ,"Station_Address":"153, đường Xô Viết Nghệ Tĩnh , Quận Bình Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71113586,10.79981041] ; [106.71113586,10.79981041] ; [106.71092224,10.79819298] ; [106.71046448,10.79672241] ; [106.71046448,10.79672241]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"369"
    ,"Station_Code":"QBTH 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Siêu Thị Điện máy tự do"
    ,"Station_Address":"151, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.794978
    ,"Long":106.709368
    ,"Polyline":"[106.71041107,10.79673767] ; [106.71046448,10.79672241] ; [106.71046448,10.79672241] ; [106.71046448,10.79672241] ; [106.71001434,10.79565811] ; [106.70941925,10.79488182] ; [106.70941925,10.79488182] ; [106.70945740,10.79485130] ; [106.70945740,10.79485226] ; [106.70945740,10.79485321] ; [106.70945740,10.79485321] ; [106.70945740,10.79485130] ; [106.70945740,10.79485226] ; [106.70945740,10.79485321] ; [106.70945740,10.79485512] ; [106.70944977,10.79485893] ; [106.70944214,10.79486656] ; [106.70941925,10.79488182] ; [106.70936584,10.79497814]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"373"
    ,"Station_Code":"QBTH 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà Th ờ Thị Nghè"
    ,"Station_Address":"79, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793534
    ,"Long":106.707979
    ,"Polyline":"[106.70936584,10.79497814] ; [106.70927429,10.79483604] ; [106.70810699,10.79368210.06.70797729]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"370"
    ,"Station_Code":"Q1 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"2A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790694
    ,"Long":106.705259
    ,"Polyline":"[106.70797729,10.79353428] ; [106.70780182,10.79333401] ; [106.70533752,10.79065609] ; [106.70533752,10.79065609]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Đài truyền hình"
    ,"Station_Address":"Đối diện 9, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70533752,10.79065609] ; [106.70201111,10.78715706]"
    ,"Distance":"533"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1190"
    ,"Station_Code":"Q1 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"43, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785716
    ,"Long":106.702385
    ,"Polyline":"[106.70201111,10.78715706] ; [106.70186615,10.78698921] ; [106.70152283,10.78659916] ; [106.70243835,10.78577995] ; [106.70238495,10.78571606]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2146"
    ,"Station_Code":"Q1 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Cty Xổ S ố Kiến Thiết"
    ,"Station_Address":"Đối diện Central Plaza, đường Lê Duẩn, Quận 1"
    ,"Lat":10.78428
    ,"Long":106.702118
    ,"Polyline":"[106.70243835,10.78577995] ; [106.70307922,10.78518009] ; [106.70217896,10.78421974]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"237"
    ,"Station_Code":"Q1 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"115Bis, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.779385
    ,"Long":106.701744
    ,"Polyline":"[106.70217896,10.78421974] ; [106.69959259,10.78149033] ; [106.70184326,10.77947998]"
    ,"Distance":"772"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"238"
    ,"Station_Code":"Q1 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Nhà Hát Thành Phố"
    ,"Station_Address":"101 , đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.777873
    ,"Long":106.70351
    ,"Polyline":"[106.70184326,10.77947998] ; [106.70368195,10.77779961]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"239"
    ,"Station_Code":"Q1 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"Đối diện 2, đường Hai Bà Trưng, Quận  1"
    ,"Lat":10.775807
    ,"Long":106.705734
    ,"Polyline":"[106.70368195,10.77779961] ; [106.70583344,10.77591038]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21,  đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70583344,10.77591038] ; [106.70606995,10.77569008] ; [106.70603943,10.77565956] ; [106.70600128,10.77560997] ; [106.70594025,10.77550030] ; [106.70590210,10.77538967] ; [106.70588684,10.77530003] ; [106.70590973,10.77513027] ; [106.70599365,10.77497005] ; [106.70613098,10.77484035] ; [106.70619202,10.77478981] ; [106.70629883,10.77474976] ; [106.70644379,10.77474976] ; [106.70648956,10.77476025] ; [106.70658112,10.77460003] ; [106.70646667,10.77322006]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Cục Hải Quan Thành Phố"
    ,"Station_Address":"2-4, đường H àm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70635986,10.77329922] ; [106.70639801,10.77322292] ; [106.70622253,10.77144909] ; [106.70620728,10.77126408] ; [106.70621490,10.77121735] ; [106.70620728,10.77097988] ; [106.70614624,10.77083969] ; [106.70607758,10.77079964] ; [106.70598602,10.77084827] ; [106.70564270,10.77093887] ; [106.70555115,10.77088547]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84 , đường Hàm Nghi, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70564270,10.77085972] ; [106.70468140,10.77091026] ; [106.70339203,10.77093983] ; [106.70317078,10.77095032]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70302582,10.77097988] ; [106.70281982,10.77097511] ; [106.70269012,10.77099037] ; [106.70172119,10.77103043] ; [106.70172119,10.77106953] ; [106.70166016,10.77104759]"
    ,"Distance":"154"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70172119,10.77103043] ; [106.69934845,10.77112007]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"202"
    ,"Station_Code":"Q1TC1C"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Bến Thành C"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận  1"
    ,"Lat":10.770787
    ,"Long":106.698532
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69935608,10.77116299] ; [106.69934845,10.77110958] ; [106.69922638,10.77124310.06.69894409] ; [10.77102184,106.69888306] ; [10.77096462,106.69873810] ; [10.77085876,106.69853210] ; [10.77078724,106.69853210]"
    ,"Distance":"119"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853210,10.77078724] ; [106.69850159,10.77085018] ; [106.69744873,10.77035046] ; [106.69626617,10.76992035] ; [106.69595337,10.76980972]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ng ũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69577789,10.76972771] ; [106.69577789,10.76972771] ; [106.69493103,10.76938725] ; [106.69409180,10.76904678] ; [106.69409180,10.76904678]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.69398499,10.76903534] ; [106.69384003,10.76895618] ; [106.69238281,10.76828003] ; [106.69049072,10.76753044] ; [106.68981171,10.76729584] ; [106.68961334,10.76770687] ; [106.68936157,10.76767635] ; [106.68936157,10.76767635]"
    ,"Distance":"575"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài  Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất T ùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai , Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68927002,10.76795006] ; [106.68923187,10.76815510.06.68986511] ; [10.76839256,106.69018555] ; [10.76849747,106.69033813]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai , Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69264984,10.76946735] ; [106.69343567,10.76977825]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69458008,10.77031040] ; [106.69673157,10.77120972] ; [106.69676971,10.77109146]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69673920,10.77118874] ; [106.69673157,10.77120972] ; [106.69786835,10.77167034] ; [106.69803619,10.77159977] ; [106.69802094,10.77149010.06.69802094] ; [10.77138042,106.69805908] ; [10.77128983,106.69812775] ; [10.77122021,106.69740295] ; [10.77032661,106.69618988] ; [10.76984692,106.69650269] ; [10.76918793,106.69753265] ; [10.77025318,106.69838715] ; [10.77060032,106.69845581] ; [10.77047157,106.69845581]"
    ,"Distance":"847"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69845581,10.77047157] ; [106.69841766,10.77056980] ; [106.69907379,10.77081966] ; [106.69931793,10.77093792] ; [106.69956207,10.77093029] ; [106.69956207,10.77094269]"
    ,"Distance":"147"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956970,10.77095985] ; [106.70192719,10.77085972]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70192719,10.77081966] ; [106.70416260,10.77068996]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến Bạch  Đằng"
    ,"Station_Address":"Bến thủy nội địa Thủ Thiêm, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70407104,10.77072239] ; [106.70415497,10.77060318] ; [106.70417786,10.77072144] ; [106.70450592,10.77070618] ; [106.70455933,10.77058983] ; [106.70513153,10.76945972] ; [106.70516205,10.76939011] ; [106.70529175,10.76941967] ; [106.70593262,10.76953983] ; [106.70606995,10.76959991] ; [106.70616150,10.76972961] ; [106.70639038,10.77054977] ; [106.70635986,10.77071953] ; [106.70633698,10.77099037] ; [106.70639038,10.77120972] ; [106.70636749,10.77126026] ; [106.70639038,10.77161789] ; [106.70652008,10.77293015] ; [106.70661163,10.77388668] ; [106.70664978,10.77387810]"
    ,"Distance":"822"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"34"
    ,"Station_Code":"Q1 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"2, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.776048
    ,"Long":106.705719
    ,"Polyline":"[106.70664978,10.77387810.06.70661163] ; [10.77388668,106.70665741] ; [10.77413177,106.70665741] ; [10.77458954,106.70667267] ; [10.77488041,106.70671844] ; [10.77563953,106.70661926] ; [10.77577972,106.70652771] ; [10.77583027,106.70635223] ; [10.77583027,106.70619965] ; [10.77577972,106.70610046] ; [10.77571011,106.70606995] ; [10.77569008,106.70571899] ; [10.77604771,106.70571899]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"42"
    ,"Station_Code":"Q1 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà Hát Thành Phố"
    ,"Station_Address":"74/A2-74 /A4, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.778031
    ,"Long":106.703559
    ,"Polyline":"[106.70571899,10.77604771] ; [106.70353699,10.77799702]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"44"
    ,"Station_Code":"Q1 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh viện Nhi  Đồng 2"
    ,"Station_Address":"Đối diện 115Ter , đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.779881
    ,"Long":106.701536
    ,"Polyline":"[106.70353699,10.77799702] ; [106.70155334,10.77987862]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"39"
    ,"Station_Code":"Q1 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bưu Điện Thành Phố"
    ,"Station_Address":"86, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.780645
    ,"Long":106.700673
    ,"Polyline":"[106.70155334,10.77987862] ; [106.70067596,10.78061485]"
    ,"Distance":"131"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2028"
    ,"Station_Code":"Q1T083"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Tòa Nhà Kumho"
    ,"Station_Address":"Kumho  Asiana Plaza, đường Lê Duẩn, Quận 1"
    ,"Lat":10.782015
    ,"Long":106.700243
    ,"Polyline":"[106.70067596,10.78064537] ; [106.70054626,10.78075504] ; [106.69972992,10.78152466] ; [106.70018005,10.78211021] ; [106.70022583,10.78207588]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2029"
    ,"Station_Code":"Q1 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Cty Xổ S ố Kiến Thiết"
    ,"Station_Address":"Sofitel Plaza , đường Lê Duẩn, Quận 1"
    ,"Lat":10.78417
    ,"Long":106.702303
    ,"Polyline":"[106.70018005,10.78211021] ; [106.70230103,10.78433990]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1096"
    ,"Station_Code":"Q1 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đại học Khoa học xã hội nhân v ăn"
    ,"Station_Address":"10, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785778
    ,"Long":106.702663
    ,"Polyline":"[106.70235443,10.78428841] ; [106.70230103,10.78433990] ; [106.70320129,10.78520870] ; [106.70280457,10.78563499] ; [106.70265961,10.78577805]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"293"
    ,"Station_Code":"Q1 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"3 , đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.789598
    ,"Long":106.70459
    ,"Polyline":"[106.70259857,10.78563023] ; [106.70159149,10.78658009] ; [106.70256805,10.78761005] ; [106.70334625,10.78841972] ; [106.70446777,10.78962994]"
    ,"Distance":"647"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"295"
    ,"Station_Code":"Q1 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Thị Ngh è"
    ,"Station_Address":"1A, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.790669
    ,"Long":106.705597
    ,"Polyline":"[106.70458984,10.78959846] ; [106.70559692,10.79066944]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"298"
    ,"Station_Code":"QBTH 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"22 B, đường Xô Viết Nghệ Tĩnh, Quận B ình Thạnh"
    ,"Lat":10.793445
    ,"Long":106.70814
    ,"Polyline":"[106.70559692,10.79066944] ; [106.70809937,10.79346752]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trung tâm Dưỡng Lão"
    ,"Station_Address":"138, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70809937,10.79346848] ; [106.70809937,10.79346752] ; [106.71005249,10.79543114] ; [106.71076965,10.79752064] ; [106.71076965,10.79752064]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"246, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71076965,10.79752064] ; [106.71115112,10.79976082]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ Tĩnh, Quận Bình Th ạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71114349,10.79971027] ; [106.71131134,10.80123806] ; [106.71146393,10.80128002] ; [106.71153259,10.80138874] ; [106.71151733,10.80150700] ; [106.71143341,10.80159378] ; [106.71132660,10.80161762] ; [106.71138763,10.80284977] ; [106.71141815,10.80299473] ; [106.71142578,10.80356503] ; [106.71144867,10.80414677] ; [106.71147919,10.80471039]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71147919,10.80471039] ; [106.71151733,10.80535984] ; [106.71154022,10.80655003] ; [106.71154022,10.80681992] ; [106.71156311,10.80747032] ; [106.71161652,10.80797005] ; [106.71167755,10.80821037] ; [106.71177673,10.80848980] ; [106.71190643,10.80883980] ; [106.71198273,10.80906963]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71215820,10.80955029] ; [106.71228790,10.81021976] ; [106.71240997,10.81079102]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"522"
    ,"Station_Code":"QBTH 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"100-102, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.811666
    ,"Long":106.712532
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71244049,10.81123924] ; [106.71253204,10.81166553]"
    ,"Distance":"99"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71253204,10.81166553] ; [106.71253204,10.81200314] ; [106.71260834,10.81231976]"
    ,"Distance":"74"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71260834,10.81231976] ; [106.71262360,10.81297302] ; [106.71267700,10.81343651] ; [106.71279144,10.81385326]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"304"
    ,"Station_Code":"QTD 198"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường TH Bình Triệu"
    ,"Station_Address":"136, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.829247
    ,"Long":106.71434
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71293640,10.81564045] ; [106.71305084,10.81651974] ; [106.71320343,10.81752968] ; [106.71324158,10.81793976] ; [106.71360016,10.82091999] ; [106.71389771,10.82341957] ; [106.71399689,10.82431984] ; [106.71410370,10.82481956] ; [106.71417236,10.82497978] ; [106.71441650,10.82561016] ; [106.71452332,10.82575035] ; [106.71454620,10.82586002] ; [106.71454620,10.82596016] ; [106.71446991,10.82612991] ; [106.71440887,10.82618046] ; [106.71440125,10.82682037] ; [106.71437836,10.82715034] ; [106.71437836,10.82752991] ; [106.71427155,10.82923985] ; [106.71434021,10.82924747]"
    ,"Distance":"1745"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"309"
    ,"Station_Code":"QTD 199"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"64/1, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.832655
    ,"Long":106.714149
    ,"Polyline":"[106.71427155,10.82923985] ; [106.71415710,10.83108997] ; [106.71408844,10.83248043] ; [106.71408081,10.83265018]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"306"
    ,"Station_Code":"QTD 200"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"416, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.836135
    ,"Long":106.714012
    ,"Polyline":"[106.71408081,10.83265018] ; [106.71398926,10.83428955] ; [106.71394348,10.83520031] ; [106.71394348,10.83563042] ; [106.71392059,10.83613014]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"310"
    ,"Station_Code":"QTD 201"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"486, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.838815
    ,"Long":106.715317
    ,"Polyline":"[106.71391296,10.83619022] ; [106.71391296,10.83650970] ; [106.71394348,10.83681011] ; [106.71401215,10.83708000] ; [106.71412659,10.83742046] ; [106.71427917,10.83771038] ; [106.71449280,10.83800030] ; [106.71515656,10.83878040] ; [106.71524048,10.83887959]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"312"
    ,"Station_Code":"QTD 202"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"510, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.841072
    ,"Long":106.71714
    ,"Polyline":"[106.71524048,10.83887959] ; [106.71601105,10.83979988] ; [106.71708679,10.84111023]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"307"
    ,"Station_Code":"QTD 203"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cân Nhơn Hòa"
    ,"Station_Address":"Cân Nhơn Hòa, đường Quốc lộ 13, Quận Th ủ Đức"
    ,"Lat":10.844687
    ,"Long":106.718307
    ,"Polyline":"[106.71708679,10.84111023] ; [106.71772003,10.84187984] ; [106.71788025,10.84210014] ; [106.71803284,10.84237957] ; [106.71814728,10.84270954] ; [106.71823120,10.84305954] ; [106.71826172,10.84362984] ; [106.71824646,10.84469032]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"308"
    ,"Station_Code":"QTD 204"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 3 Hiệp Bình"
    ,"Station_Address":"1/42A, đường Quốc lộ 13, Qu ận Thủ Đức"
    ,"Lat":10.848944
    ,"Long":106.718704
    ,"Polyline":"[106.71824646,10.84469032] ; [106.71823120,10.84589958] ; [106.71822357,10.84700966] ; [106.71823120,10.84759998] ; [106.71832275,10.84811974] ; [106.71843719,10.84848976] ; [106.71864319,10.84897995]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"314"
    ,"Station_Code":"QTD 205"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã 3 Đường Hiệp Bình"
    ,"Station_Address":"620, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852921
    ,"Long":106.721222
    ,"Polyline":"[106.71864319,10.84897995] ; [106.71903992,10.84974957] ; [106.71926880,10.85019016] ; [106.71974945,10.85093975] ; [106.72103119,10.85272980] ; [106.72116089,10.85295010]"
    ,"Distance":"537"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"316"
    ,"Station_Code":"QTD 206"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm y tế Hiệp Bình Phước"
    ,"Station_Address":"702, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.855787
    ,"Long":106.722504
    ,"Polyline":"[106.72116089,10.85295010.06.72158813] ; [10.85377026,106.72202301] ; [10.85478020,106.72242737]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"311"
    ,"Station_Code":"QTD 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"UBND P.Hiệp Bình Phước"
    ,"Station_Address":"750, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.858809
    ,"Long":106.723663
    ,"Polyline":"[106.72242737,10.85581017] ; [106.72274017,10.85661030] ; [106.72328949,10.85807037] ; [106.72358704,10.85883045]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"313"
    ,"Station_Code":"QTD 208"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"784, đường Quốc lộ 13, Qu ận Thủ Đức"
    ,"Lat":10.861172
    ,"Long":106.724564
    ,"Polyline":"[106.72358704,10.85883045] ; [106.72450256,10.86120033]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"318"
    ,"Station_Code":"QTD 209"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngã 4 Bình Phước"
    ,"Station_Address":"828, đường Quốc l ộ 13, Quận Thủ Đức"
    ,"Lat":10.863845
    ,"Long":106.724792
    ,"Polyline":"[106.72450256,10.86120033] ; [106.72486115,10.86213017] ; [106.72496033,10.86248016] ; [106.72498322,10.86283016] ; [106.72495270,10.86308956] ; [106.72486877,10.86340046] ; [106.72470093,10.86380005]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"315"
    ,"Station_Code":"QTD 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Đầu Mối"
    ,"Station_Address":"120, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86689
    ,"Long":106.727425
    ,"Polyline":"[106.72470093,10.86380005] ; [106.72431946,10.86454964] ; [106.72418213,10.86485004] ; [106.72416687,10.86505985] ; [106.72418976,10.86513042] ; [106.72427368,10.86524010.06.72438049] ; [10.86532974,106.72454834] ; [10.86540985,106.72463989] ; [10.86544991,106.72666168] ; [10.86645985,106.72680664] ; [10.86657047,106.72705841] ; [10.86676025,106.72728729] ; [10.86688042,106.72740173]"
    ,"Distance":"585"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"320"
    ,"Station_Code":"QTD 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Đầu Mối"
    ,"Station_Address":"160, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86831
    ,"Long":106.730198
    ,"Polyline":"[106.72737885,10.86697006] ; [106.73014069,10.86841965]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"317"
    ,"Station_Code":"QTD 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ Tam Bình"
    ,"Station_Address":"Chợ Tam Bình , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.87086
    ,"Long":106.73538
    ,"Polyline":"[106.73014069,10.86841965] ; [106.73095703,10.86884022] ; [106.73193359,10.86931038] ; [106.73319244,10.86993027] ; [106.73468781,10.87067986] ; [106.73535919,10.87098026]"
    ,"Distance":"666"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"322"
    ,"Station_Code":"QTD 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"376, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871766
    ,"Long":106.739666
    ,"Polyline":"[106.73535919,10.87098026] ; [106.73597717,10.87121964] ; [106.73674774,10.87143993] ; [106.73748779,10.87160969] ; [106.73834991,10.87172985] ; [106.73964691,10.87189960]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"319"
    ,"Station_Code":"QTD 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Chợ Tam Hải"
    ,"Station_Address":"450 , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.872935
    ,"Long":106.744081
    ,"Polyline":"[106.73964691,10.87189960] ; [106.74082184,10.87207985] ; [106.74160767,10.87226963] ; [106.74257660,10.87257004] ; [106.74403381,10.87304974]"
    ,"Distance":"512"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"321"
    ,"Station_Code":"QTD 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Cầu vượt S óng Thần"
    ,"Station_Address":"Đối diện 275,  đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.873905
    ,"Long":106.747128
    ,"Polyline":"[106.74403381,10.87304974] ; [106.74707794,10.87403011]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"323"
    ,"Station_Code":"QTD 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe Lam Hồng"
    ,"Station_Address":"6/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875706
    ,"Long":106.75562
    ,"Polyline":"[106.74707794,10.87403011] ; [106.74913025,10.87469006] ; [106.75228119,10.87574005] ; [106.75308990,10.87596035] ; [106.75370026,10.87602043] ; [106.75434113,10.87600994] ; [106.75489807,10.87592983] ; [106.75566101,10.87580013]"
    ,"Distance":"988"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"325"
    ,"Station_Code":"QTD 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Giày da  Thái Bình"
    ,"Station_Address":"20/8, đường Qu ốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875353
    ,"Long":106.757466
    ,"Polyline":"[106.75566101,10.87580013] ; [106.75749969,10.87545013]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"328"
    ,"Station_Code":"QTD 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Linh Xuân"
    ,"Station_Address":"54/8, đường Quốc lộ 1, Qu ận Thủ Đức"
    ,"Lat":10.874474
    ,"Long":106.76091
    ,"Polyline":"[106.75748444,10.87539387] ; [106.75913239,10.87507439] ; [106.76092529,10.87457085]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"324"
    ,"Station_Code":"QTD 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Cầu vượt Linh Xuân"
    ,"Station_Address":"Kho 856, đường Quốc lộ 1, Quận Thủ Đ ức"
    ,"Lat":10.873973
    ,"Long":106.762476
    ,"Polyline":"[106.76094055,10.87462044] ; [106.76249695,10.87411022]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2083"
    ,"Station_Code":"QTD 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Vietcombank"
    ,"Station_Address":"Ngân hàng Vietcombank, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871597
    ,"Long":106.769643
    ,"Polyline":"[106.76248169,10.87404919] ; [106.76249695,10.87411022] ; [106.76289368,10.87397957] ; [106.76309204,10.87384033] ; [106.76686859,10.87255001] ; [106.76715088,10.87246037] ; [106.76751709,10.87233448] ; [106.76966095,10.87170982] ; [106.76964569,10.87165546]"
    ,"Distance":"842"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"2084"
    ,"Station_Code":"QTD 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Nghĩa trang TP"
    ,"Station_Address":"Cổng nghĩa trang thành phố, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870507
    ,"Long":106.773039
    ,"Polyline":"[106.76966095,10.87170982] ; [106.77307129,10.87059975]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1040"
    ,"Station_Code":"QTD 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"ĐH Kinh tế Luật"
    ,"Station_Address":"Đối diện 665, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.869306
    ,"Long":106.776724
    ,"Polyline":"[106.77307129,10.87059975] ; [106.77645874,10.86948967]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1041"
    ,"Station_Code":"QTD 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Công ty điện tử Samsung"
    ,"Station_Address":"Công ty điện tử Samsung, đường Quốc lộ 1, Quận Thủ  Đức"
    ,"Lat":10.868691
    ,"Long":106.778656
    ,"Polyline":"[106.77645111,10.86942005] ; [106.77646637,10.86948013] ; [106.77748108,10.86913967] ; [106.77867889,10.86874962]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"1042"
    ,"Station_Code":"QTD 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"Cột điện SI 2, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867122
    ,"Long":106.787277
    ,"Polyline":"[106.77867889,10.86874962] ; [106.78009033,10.86828041] ; [106.78092194,10.86802959] ; [106.78225708,10.86762047] ; [106.78260803,10.86752033] ; [106.78318787,10.86740017] ; [106.78382111,10.86732960] ; [106.78704071,10.86719036] ; [106.78727722,10.86717987]"
    ,"Distance":"977"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"396"
    ,"Station_Code":"QTD 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"1030, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.866912
    ,"Long":106.790283
    ,"Polyline":"[106.78727722,10.86717987] ; [106.78822327,10.86713028] ; [106.78961182,10.86707020] ; [106.79029846,10.86695957]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"4559"
    ,"Station_Code":"QTD 197"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Câu vượt Trạm 2"
    ,"Station_Address":"Câu vượt Trạm 2, đường Quốc lộ 1, Quận Th ủ Đức"
    ,"Lat":10.863432
    ,"Long":106.797345
    ,"Polyline":"[106.79028320,10.86691189] ; [106.79133606,10.86658192] ; [106.79249573,10.86586571] ; [106.79345703,10.86521244] ; [106.79412842,10.86455917] ; [106.79494476,10.86329460] ; [106.79605865,10.86154556] ; [106.79579926,10.86091328] ; [106.79539490,10.86068153] ; [106.79508972,10.86072350] ; [106.79471588,10.86093426] ; [106.79456329,10.86140823] ; [106.79473877,10.86193562] ; [106.79513550,10.86221981] ; [106.79734802,10.86343193]"
    ,"Distance":"1553"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"537"
    ,"Station_Code":"Q9 223"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"Suối Tiên, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.866498
    ,"Long":106.802377
    ,"Polyline":"[106.79734802,10.86343193] ; [106.80251312,10.86662579]"
    ,"Distance":"668"
  },
  {
     "Route_Id":"41"
    ,"Station_Id":"538"
    ,"Station_Code":"BX87"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Đại học Quốc gia"
    ,"Station_Address":"Bến xe buýt Khu A Đô thị Quốc gia, đường Đường nội bộ Đại học Qu ốc gia, Quận Thủ Đức"
    ,"Lat":10.873805046081543
    ,"Long":106.8020248413086
    ,"Polyline":"[106.80251312,10.86662579] ; [106.80248260,10.86666965] ; [106.80357361,10.86740971] ; [106.80422211,10.86791039] ; [106.80460358,10.86822987] ; [106.80522156,10.86880016] ; [106.80615997,10.86979008] ; [106.80673218,10.87049007] ; [106.80814362,10.87240028] ; [106.80860138,10.87300968] ; [106.80850983,10.87308979] ; [106.80809784,10.87347031] ; [106.80787659,10.87378979] ; [106.80734253,10.87413025] ; [106.80677032,10.87444019] ; [106.80657959,10.87452030] ; [106.80560303,10.87496853] ; [106.80529785,10.87528992] ; [106.80516815,10.87565899] ; [106.80484009,10.87599659] ; [106.80450439,10.87617493] ; [106.80363464,10.87649155] ; [106.80331421,10.87651253] ; [106.80322266,10.87661266] ; [106.80314636,10.87649632] ; [106.80307770,10.87635994] ; [106.80294800,10.87627029] ; [106.80261993,10.87619591] ; [106.80216980,10.87608051] ; [106.80174255,10.87593269] ; [106.80142975,10.87589073] ; [106.80078125,10.87581730] ; [106.80030823,10.87574291] ; [106.79987335,10.87551689] ; [106.79998779,10.87484264] ; [106.80010223,10.87445831] ; [106.80101013,10.87390995] ; [106.80197144,10.87363625] ; [106.80202484,10.87380505]"
    ,"Distance":"2489"
  }]