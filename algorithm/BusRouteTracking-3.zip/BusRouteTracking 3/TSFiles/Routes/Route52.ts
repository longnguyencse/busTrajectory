export const Route52 =[

  {
     "Route_Id":"52"
    ,"Station_Id":"2535"
    ,"Station_Code":"BX94"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu dân cư Bình Lợi"
    ,"Station_Address":"Khu dân cư Bình Lợi, đường Bình Lợi,  Quận Bình Thạnh"
    ,"Lat":10.835313
    ,"Long":106.702893
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2544"
    ,"Station_Code":"QBTH 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Liên Minh"
    ,"Station_Address":"443, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.834102
    ,"Long":106.704111
    ,"Polyline":"[106.70289612,10.83531284] ; [106.70359802,10.83471012] ; [106.70391083,10.83440685] ; [106.70413971,10.83409023] ; [106.70410919,10.83410168]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2537"
    ,"Station_Code":"QBTH 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Liên Minh"
    ,"Station_Address":"447, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.831899
    ,"Long":106.705173
    ,"Polyline":"[106.70410919,10.83410168] ; [106.70474243,10.83303165] ; [106.70494080,10.83271599] ; [106.70516968,10.83189869]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2546"
    ,"Station_Code":"QBTH 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trung tâm bảo trợ xã hội"
    ,"Station_Address":"465, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.828459
    ,"Long":106.705951
    ,"Polyline":"[106.70516968,10.83189869] ; [106.70542908,10.83113003] ; [106.70594788,10.82845879]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2539"
    ,"Station_Code":"QBTH 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Đường ray xe lửa"
    ,"Station_Address":"119, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.82623
    ,"Long":106.706418
    ,"Polyline":"[106.70594788,10.82845879] ; [106.70619965,10.82734680] ; [106.70642090,10.82623005]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2548"
    ,"Station_Code":"QBTH 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Bình Lợi"
    ,"Station_Address":"255, đường Nơ Trang Long,  Quận Bình Thạnh"
    ,"Lat":10.823053
    ,"Long":106.707008
    ,"Polyline":"[106.70642090,10.82623005] ; [106.70678711,10.82466507] ; [106.70697784,10.82385921] ; [106.70700836,10.82305336]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2550"
    ,"Station_Code":"QBTH 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"UBND Phường 13, Quận Bình Thạnh"
    ,"Station_Address":"363, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.819649
    ,"Long":106.702915
    ,"Polyline":"[106.70700836,10.82305336] ; [106.70690918,10.82229424] ; [106.70397186,10.82009125] ; [106.70291138,10.81964874]"
    ,"Distance":"615"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2541"
    ,"Station_Code":"QBTH 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Trung cấp xây dựng Tp. HCM"
    ,"Station_Address":"327, đường Nơ Trang Long,  Quận Bình Thạnh"
    ,"Lat":10.818959
    ,"Long":106.700345
    ,"Polyline":"[106.70291138,10.81964874] ; [106.70160675,10.81921959] ; [106.70065308,10.81892967] ; [106.70034790,10.81895924]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2543"
    ,"Station_Code":"QBTH 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà văn hóa Lao Động"
    ,"Station_Address":"217, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.816113
    ,"Long":106.69784
    ,"Polyline":"[106.70034790,10.81895924] ; [106.69975281,10.81899548] ; [106.69936371,10.81888008] ; [106.69873047,10.81844711] ; [106.69812775,10.81786823] ; [106.69790649,10.81752014] ; [106.69778442,10.81711960] ; [106.69783783,10.81611347]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2545"
    ,"Station_Code":"QBTH 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Siêu thị Satra Food"
    ,"Station_Address":"167, đường Nơ Trang Long, Qu ận Bình Thạnh"
    ,"Lat":10.813605
    ,"Long":106.697266
    ,"Polyline":"[106.69783783,10.81611347] ; [106.69785309,10.81611156] ; [106.69786072,10.81611061] ; [106.69786835,10.81610966] ; [106.69786835,10.81610966] ; [106.69786835,10.81610966] ; [106.69786835,10.81610966] ; [106.69786835,10.81610966] ; [106.69786835,10.81610966] ; [106.69787598,10.81507015] ; [106.69781494,10.81451130] ; [106.69757080,10.81404305] ; [106.69726563,10.81360531]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2552"
    ,"Station_Code":"QBTH 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã Năm Bình Hòa"
    ,"Station_Address":"131, đường N ơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.811719
    ,"Long":106.69578
    ,"Polyline":"[106.69726563,10.81360531] ; [106.69633484,10.81238270] ; [106.69577789,10.81171894]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1768"
    ,"Station_Code":"QBTH 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"89, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809833
    ,"Long":106.695061
    ,"Polyline":"[106.69577789,10.81171894] ; [106.69541168,10.81127071] ; [106.69514465,10.81055450] ; [106.69506073,10.80983257]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2107"
    ,"Station_Code":"QBTH 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"27, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.805712
    ,"Long":106.694965
    ,"Polyline":"[106.69506073,10.80983257] ; [106.69503784,10.80665970] ; [106.69496155,10.80571175]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2110"
    ,"Station_Code":"QBTH 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"1,  đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803583
    ,"Long":106.694906
    ,"Polyline":"[106.69496155,10.80571175] ; [106.69490814,10.80358315]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2037"
    ,"Station_Code":"QBTH 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Lăng Ông  Bà Chiểu"
    ,"Station_Address":"129, đường Đinh Ti ên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.801391
    ,"Long":106.696456
    ,"Polyline":"[106.69490814,10.80358315] ; [106.69490814,10.80358315] ; [106.69487000,10.80274010.06.69651794] ; [10.80251312,106.69645691] ; [10.80139065,106.69645691]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2034"
    ,"Station_Code":"QBTH 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"95, đường Đinh Tiên Hoàng, Quận Bình  Thạnh"
    ,"Lat":10.798625
    ,"Long":106.696279
    ,"Polyline":"[106.69645691,10.80139065] ; [106.69628143,10.79862499]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2112"
    ,"Station_Code":"QBTH 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"51, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.79423
    ,"Long":106.695968
    ,"Polyline":"[106.69628143,10.79862499] ; [106.69596863,10.79423046]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"4269"
    ,"Station_Code":"Q1 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Đa Kao"
    ,"Station_Address":"30, đường Trần Quang Khải, Quận 1"
    ,"Lat":10.792622
    ,"Long":106.695195
    ,"Polyline":"[106.69596863,10.79423046] ; [106.69596863,10.79423046] ; [106.69588470,10.79272842] ; [106.69519806,10.79262161] ; [106.69519806,10.79262161] ; [106.69519806,10.79262161]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"4270"
    ,"Station_Code":"Q1 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nguyễn Hữu  Cầu"
    ,"Station_Address":"124, đường Trần Quang  Khải, Quận 1"
    ,"Lat":10.792072
    ,"Long":106.692088
    ,"Polyline":"[106.69519806,10.79262161] ; [106.69208527,10.79207230]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"234"
    ,"Station_Code":"Q3 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Tân Định"
    ,"Station_Address":"Đối diện 274, đường Hai Bà Trưng, Quận 3"
    ,"Lat":10.788972
    ,"Long":106.690445
    ,"Polyline":"[106.69208527,10.79207230] ; [106.69208527,10.79207230] ; [106.69143677,10.79194260] ; [106.69143677,10.79176903] ; [106.69121552,10.79128456] ; [106.68995667,10.78940868] ; [106.69044495,10.78897190] ; [106.69044495,10.78897190]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"233"
    ,"Station_Code":"Q3 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Công viên  Lê Văn Tám"
    ,"Station_Address":"243, đường Hai  Bà Trưng, Quận 3"
    ,"Lat":10.787174
    ,"Long":106.692653
    ,"Polyline":"[106.69044495,10.78897190] ; [106.69044495,10.78897190] ; [106.69123840,10.78835392] ; [106.69268799,10.78725338] ; [106.69264984,10.78717422] ; [106.69264984,10.78717422]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1881"
    ,"Station_Code":"Q3 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Đại học Kinh tế"
    ,"Station_Address":"138B, đường Nguy ễn Đình Chiểu, Quận 3"
    ,"Lat":10.782981
    ,"Long":106.694191
    ,"Polyline":"[106.69264984,10.78717422] ; [106.69593811,10.78467083] ; [106.69419098,10.78298092]"
    ,"Distance":"722"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"195"
    ,"Station_Code":"Q3 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Coop Mart Nguyễn Đình Chiểu"
    ,"Station_Address":"145, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.78113
    ,"Long":106.693152
    ,"Polyline":"[106.69419098,10.78298092] ; [106.69425964,10.78291988] ; [106.69290161,10.78145981] ; [106.69320679,10.78114510.06.69315338]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"197"
    ,"Station_Code":"Q3 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"Đối diện 166 - 168, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.779777
    ,"Long":106.694626
    ,"Polyline":"[106.69315338,10.78112984] ; [106.69315338,10.78112984] ; [106.69320679,10.78116131] ; [106.69393158,10.78046608] ; [106.69465637,10.77979660] ; [106.69462585,10.77977657] ; [106.69462585,10.77977657]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"200"
    ,"Station_Code":"Q1 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Tòa Án Thành Phố"
    ,"Station_Address":"131, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.776052
    ,"Long":106.698647
    ,"Polyline":"[106.69462585,10.77977657] ; [106.69462585,10.77977657] ; [106.69839478,10.77634430] ; [106.69864655,10.77612877] ; [106.69864655,10.77605247] ; [106.69864655,10.77605247]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"199"
    ,"Station_Code":"Q1 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Chùa Ông"
    ,"Station_Address":"Đối diện 96A, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.773957
    ,"Long":106.699722
    ,"Polyline":"[106.69864655,10.77605247] ; [106.69864655,10.77605247] ; [106.69864655,10.77605247] ; [106.69869995,10.77607632] ; [106.69901276,10.77581787] ; [106.69919586,10.77543831] ; [106.69934082,10.77505875] ; [106.69976807,10.77400494] ; [106.69972229,10.77395725] ; [106.69972229,10.77395725] ; [106.69972229,10.77395725]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"201"
    ,"Station_Code":"Q1 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường CĐKT Cao Thắng"
    ,"Station_Address":"Đối diện 86, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.771416
    ,"Long":106.700851
    ,"Polyline":"[106.69972229,10.77395725] ; [106.70030975,10.77276134] ; [106.70085144,10.77141571]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70085144,10.77141571] ; [106.70106506,10.77109623] ; [106.69935608,10.77116299]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Bến Thành A"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69909668,10.77116489] ; [106.69853973,10.77089596]"
    ,"Distance":"96"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ng ũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853973,10.77089596] ; [106.69853973,10.77089596] ; [106.69725800,10.77032661] ; [106.69595337,10.76980972] ; [106.69595337,10.76980972]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1451"
    ,"Station_Code":"Q1 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trần Hưng Đạo"
    ,"Station_Address":"197, đường Nguyễn Thái Học, Quận 1"
    ,"Lat":10.768461
    ,"Long":106.694984
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69595337,10.76980972] ; [106.69456482,10.76927280] ; [106.69498444,10.76846123] ; [106.69498444,10.76846123]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1344"
    ,"Station_Code":"Q1 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"65G, đường Nguy ễn Thái Học, Quận 1"
    ,"Lat":10.766576
    ,"Long":106.696129
    ,"Polyline":"[106.69498444,10.76846123] ; [106.69498444,10.76846123] ; [106.69498444,10.76846123] ; [106.69501495,10.76847172] ; [106.69557953,10.76753902] ; [106.69618225,10.76656914] ; [106.69612885,10.76657581] ; [106.69612885,10.76657581] ; [106.69612885,10.76657581]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1252"
    ,"Station_Code":"Q4 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường THCS Vân Đồn"
    ,"Station_Address":"243, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.761768
    ,"Long":106.701724
    ,"Polyline":"[106.69612885,10.76657581] ; [106.69776154,10.76387596] ; [106.69950104,10.76218987] ; [106.70041656,10.76086140] ; [106.70172119,10.76176834]"
    ,"Distance":"970"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1254"
    ,"Station_Code":"Q4 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chùa Anh Linh"
    ,"Station_Address":"177, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.763006
    ,"Long":106.703414
    ,"Polyline":"[106.70172119,10.76176834] ; [106.70341492,10.76300621]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"856"
    ,"Station_Code":"Q4 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Xóm Chi ếu"
    ,"Station_Address":"51-53, đường Hoàng Diệu, Qu ận 4"
    ,"Lat":10.764703
    ,"Long":106.706504
    ,"Polyline":"[106.70341492,10.76300621] ; [106.70341492,10.76300621] ; [106.70337677,10.76305962] ; [106.70469666,10.76398659] ; [106.70635223,10.76465130] ; [106.70635223,10.76465130]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"855"
    ,"Station_Code":"Q4 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bưu Điện Quận 4"
    ,"Station_Address":"136-138, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.76385
    ,"Long":106.70763
    ,"Polyline":"[106.70635223,10.76465130] ; [106.70635223,10.76465130] ; [106.70635223,10.76465130] ; [106.70633698,10.76468277] ; [106.70714569,10.76506138] ; [106.70777130,10.76365471] ; [106.70774078,10.76363373] ; [106.70774078,10.76363373] ; [106.70774078,10.76363373]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"857"
    ,"Station_Code":"Q4 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Đại học Nguyễn Tất Thành"
    ,"Station_Address":"276, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.7618
    ,"Long":106.70932
    ,"Polyline":"[106.70774078,10.76363373] ; [106.70828247,10.76246929] ; [106.70932007,10.76179981]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"858"
    ,"Station_Code":"Q4 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường Nguyễn Trãi"
    ,"Station_Address":"428, đường Nguyễn Tất Thành,  Quận 4"
    ,"Lat":10.759423
    ,"Long":106.713359
    ,"Polyline":"[106.70932007,10.76179981] ; [106.70932007,10.76179981] ; [106.71113586,10.76081944] ; [106.71272278,10.75982857] ; [106.71272278,10.75982857]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"860"
    ,"Station_Code":"Q4 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Cảng Sài Gòn"
    ,"Station_Address":"456, đường Nguyễn Tất Thành,  Quận 4"
    ,"Lat":10.7579
    ,"Long":106.715977
    ,"Polyline":"[106.71272278,10.75982857] ; [106.71272278,10.75982857] ; [106.71272278,10.75982857] ; [106.71418762,10.75901222] ; [106.71546936,10.75819969] ; [106.71546936,10.75819969] ; [106.71546936,10.75819969]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"859"
    ,"Station_Code":"Q7 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu Tân Thuận 2"
    ,"Station_Address":"46/14 (chân cầu Tân Thuận 2), đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752424
    ,"Long":106.723927
    ,"Polyline":"[106.71546936,10.75819969] ; [106.71807861,10.75689888] ; [106.72103882,10.75466347] ; [106.72254181,10.75355721] ; [106.72393036,10.75242424]"
    ,"Distance":"1131"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"862"
    ,"Station_Code":"Q7 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Sân bóng CLB cảng SG"
    ,"Station_Address":"144-146, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.751697
    ,"Long":106.724088
    ,"Polyline":"[106.72393036,10.75242424] ; [106.72413635,10.75232887] ; [106.72427368,10.75220299] ; [106.72434235,10.75205517] ; [106.72433472,10.75192833] ; [106.72427368,10.75181770] ; [106.72409058,10.75169659]"
    ,"Distance":"116"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"4125"
    ,"Station_Code":"Q7 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ủy ban Phường Tân Thuận Tây"
    ,"Station_Address":"Ủy ban Phường Tân  Thuận Tây, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.747807
    ,"Long":106.721728
    ,"Polyline":"[106.72409058,10.75169659] ; [106.72335815,10.75102711] ; [106.72272491,10.75026894] ; [106.72237396,10.74969959] ; [106.72210693,10.74910927] ; [106.72188568,10.74847698] ; [106.72172546,10.74780655]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"866"
    ,"Station_Code":"Q7 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Cầu Lý Ph ục Man"
    ,"Station_Address":"636, đường Nguyễn  Văn Linh, Quận 7"
    ,"Lat":10.742521
    ,"Long":106.721508
    ,"Polyline":"[106.72172546,10.74780655] ; [106.72150421,10.74252129]"
    ,"Distance":"590"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"863"
    ,"Station_Code":"Q7 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Nguyễn Thị Thập"
    ,"Station_Address":"340A, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.739585
    ,"Long":106.721444
    ,"Polyline":"[106.72150421,10.74252129] ; [106.72160339,10.74254227] ; [106.72154236,10.73959064] ; [106.72144318,10.73958492]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2063"
    ,"Station_Code":"Q7 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nguyễn Th ị Thập"
    ,"Station_Address":"154, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.73821
    ,"Long":106.720027
    ,"Polyline":"[106.72144318,10.73958492] ; [106.72148895,10.73929596] ; [106.72150421,10.73810959] ; [106.72002411,10.73820972]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1373"
    ,"Station_Code":"Q7 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"222, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738384
    ,"Long":106.717485
    ,"Polyline":"[106.72002411,10.73820972] ; [106.71874237,10.73828888] ; [106.71748352,10.73838425]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1374"
    ,"Station_Code":"Q7 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Mai Văn Vĩnh"
    ,"Station_Address":"326, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738621
    ,"Long":106.713333
    ,"Polyline":"[106.71748352,10.73838425] ; [106.71333313,10.73862076]"
    ,"Distance":"455"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1378"
    ,"Station_Code":"Q7 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Đường số 38"
    ,"Station_Address":"392, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738964
    ,"Long":106.710484
    ,"Polyline":"[106.71333313,10.73862076] ; [106.71191406,10.73875237] ; [106.71048737,10.73896408]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1376"
    ,"Station_Code":"Q7 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Khu dân c ư Tân Quy Đông"
    ,"Station_Address":"450, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.739401
    ,"Long":106.707614
    ,"Polyline":"[106.71048737,10.73896408] ; [106.71048737,10.73896408] ; [106.70761108,10.73940086] ; [106.70761108,10.73940086]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2547"
    ,"Station_Code":"BX 17"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Khu dân cư Tân Quy Đông"
    ,"Station_Address":"ĐẦU BẾN KDC TÂN QUY, đường  Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738441
    ,"Long":106.706589
    ,"Polyline":"[106.70761108,10.73940086] ; [106.70680237,10.73952770] ; [106.70671082,10.73888493] ; [106.70658875,10.73844147]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2547"
    ,"Station_Code":"BX 17"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu dân cư Tân Quy Đông"
    ,"Station_Address":"ĐẦU BẾN KDC TÂN QUY, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738441
    ,"Long":106.706589
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1350"
    ,"Station_Code":"Q7 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Khu dân cư Tân Quy Đông"
    ,"Station_Address":"507, đường Nguyễn Thị Thập, Qu ận 7"
    ,"Lat":10.739164
    ,"Long":106.707743
    ,"Polyline":"[106.70658875,10.73844147] ; [106.70671082,10.73842049] ; [106.70686340,10.73932171] ; [106.70774078,10.73916435]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1349"
    ,"Station_Code":"Q7 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Đường số 38"
    ,"Station_Address":"449, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738716
    ,"Long":106.710747
    ,"Polyline":"[106.70774078,10.73916435] ; [106.71074677,10.73871613]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1351"
    ,"Station_Code":"Q7 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Mai Văn Vĩnh"
    ,"Station_Address":"351, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738368
    ,"Long":106.714003
    ,"Polyline":"[106.71074677,10.73871613] ; [106.71236420,10.73851013] ; [106.71400452,10.73836803]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1352"
    ,"Station_Code":"Q7 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"269-271, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738152
    ,"Long":106.717522
    ,"Polyline":"[106.71400452,10.73836803] ; [106.71752167,10.73815155]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1996"
    ,"Station_Code":"Q7 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nguyễn Văn  Linh"
    ,"Station_Address":"195A, đường Nguyễn  Thị Thập, Quận 7"
    ,"Lat":10.737989
    ,"Long":106.720027
    ,"Polyline":"[106.71752167,10.73815155] ; [106.72002411,10.73798943]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"840"
    ,"Station_Code":"Q7 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu Đa Khoa"
    ,"Station_Address":"Đối diện 354, đường Nguyễn  Văn Linh, Quận 7"
    ,"Lat":10.738937
    ,"Long":106.721798
    ,"Polyline":"[106.72002411,10.73798943] ; [106.72177887,10.73793030] ; [106.72180176,10.73893738]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"842"
    ,"Station_Code":"Q7 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Lý Phục Man"
    ,"Station_Address":"Đối diện 404, đường Nguyễn Văn Linh, Quận  7"
    ,"Lat":10.742031
    ,"Long":106.721862
    ,"Polyline":"[106.72180176,10.73893738] ; [106.72186279,10.74203110]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"841"
    ,"Station_Code":"Q7 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"UBND P. Tân Thuận Tây"
    ,"Station_Address":"Đối diện UBND P. Tân Thuận Tây, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.746975
    ,"Long":106.721991
    ,"Polyline":"[106.72186279,10.74203110.06.72185516] ; [10.74328041,106.72187805] ; [10.74451828,106.72190857] ; [10.74577808,106.72199249]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"844"
    ,"Station_Code":"Q7 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cầu Tân Thuận 2"
    ,"Station_Address":"Đối diện 41, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.751307
    ,"Long":106.724174
    ,"Polyline":"[106.72199249,10.74697495] ; [106.72208405,10.74789715] ; [106.72216797,10.74833965] ; [106.72231293,10.74876118] ; [106.72262573,10.74943542] ; [106.72293854,10.75001049] ; [106.72331238,10.75052643] ; [106.72373199,10.75093746] ; [106.72417450,10.75130653]"
    ,"Distance":"557"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"843"
    ,"Station_Code":"Q7 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"KCX Tân Thu ận"
    ,"Station_Address":"Đối diện 49/2, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752498
    ,"Long":106.727414
    ,"Polyline":"[106.72417450,10.75130653] ; [106.72483063,10.75182343] ; [106.72525787,10.75204945] ; [106.72570038,10.75222874] ; [106.72612762,10.75236607] ; [106.72655487,10.75244999] ; [106.72741699,10.75249767]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"846"
    ,"Station_Code":"Q7 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Kho 18"
    ,"Station_Address":"267, đường Hu ỳnh Tấn Phát, Quận 7"
    ,"Lat":10.7549
    ,"Long":106.726204
    ,"Polyline":"[106.72741699,10.75249767] ; [106.72855377,10.75261879] ; [106.72855377,10.75299835] ; [106.72848511,10.75357342] ; [106.72841644,10.75386238] ; [106.72822571,10.75419998] ; [106.72793579,10.75438976] ; [106.72763824,10.75453758] ; [106.72711182,10.75471115] ; [106.72620392,10.75489998] ; [106.72620392,10.75489998]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"845"
    ,"Station_Code":"Q7 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Vòng xoay Tân Thuận"
    ,"Station_Address":"135, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.755423
    ,"Long":106.723946
    ,"Polyline":"[106.72620392,10.75489998] ; [106.72394562,10.75542259]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"848"
    ,"Station_Code":"Q4 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cảng Sài Gòn"
    ,"Station_Address":"Đối diện 466, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.758443
    ,"Long":106.7155
    ,"Polyline":"[106.72394562,10.75542259] ; [106.72394562,10.75542259] ; [106.72333527,10.75553894] ; [106.72261047,10.75505924] ; [106.72245026,10.75503826] ; [106.72227478,10.75509644] ; [106.71977234,10.75627613] ; [106.71646118,10.75783634] ; [106.71549988,10.75844288] ; [106.71549988,10.75844288]"
    ,"Distance":"1032"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"847"
    ,"Station_Code":"Q4 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà thờ Thánh An Tôn"
    ,"Station_Address":"Đối diện 448, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.759771
    ,"Long":106.713241
    ,"Polyline":"[106.71549988,10.75844288] ; [106.71324158,10.75977135]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"850"
    ,"Station_Code":"Q4 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đại học Nguyễn Tất Thành"
    ,"Station_Address":"Đối diện 300A, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.761557
    ,"Long":106.710194
    ,"Polyline":"[106.71324158,10.75977135] ; [106.71019745,10.76155663]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"849"
    ,"Station_Code":"Q4 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bưu Điện Qu ận 4"
    ,"Station_Address":"75-83, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.707941
    ,"Polyline":"[106.71019745,10.76155663] ; [106.70841217,10.76253700] ; [106.70793915,10.76374435]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"852"
    ,"Station_Code":"Q4 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Chợ Xóm Chi ếu"
    ,"Station_Address":"34, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.764983
    ,"Long":106.706471
    ,"Polyline":"[106.70793915,10.76374435] ; [106.70721436,10.76522541] ; [106.70647430,10.76498318]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"851"
    ,"Station_Code":"Q4 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Đoàn Văn Bơ"
    ,"Station_Address":"106-108, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.704031
    ,"Polyline":"[106.70647430,10.76498318] ; [106.70455933,10.76411343] ; [106.70403290,10.76374435]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1195"
    ,"Station_Code":"Q4 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chùa Anh Linh"
    ,"Station_Address":"160-162, đường Hoàng Di ệu, Quận 4"
    ,"Lat":10.76308
    ,"Long":106.703183
    ,"Polyline":"[106.70403290,10.76374435] ; [106.70318604,10.76307964]"
    ,"Distance":"119"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1193"
    ,"Station_Code":"Q4 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trường THCS Vân Đồn"
    ,"Station_Address":"Đối diện 243 , đường Hoàng Diệu, Quận 4"
    ,"Lat":10.761879
    ,"Long":106.701488
    ,"Polyline":"[106.70318604,10.76307964] ; [106.70214081,10.76229477] ; [106.70148468,10.76187897]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1379"
    ,"Station_Code":"Q1 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"82 - 84, đường Nguy ễn Thái Học, Quận 1"
    ,"Lat":10.766109
    ,"Long":106.696686
    ,"Polyline":"[106.70148468,10.76187897] ; [106.70046234,10.76116753] ; [106.69979095,10.76215267] ; [106.69861603,10.76334858] ; [106.69821930,10.76370716] ; [106.69781494,10.76413918] ; [106.69668579,10.76610947]"
    ,"Distance":"830"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"27"
    ,"Station_Code":"Q1 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"71C, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768327
    ,"Long":106.695847
    ,"Polyline":"[106.69668579,10.76610947] ; [106.69668579,10.76610947] ; [106.69596863,10.76735401] ; [106.69554901,10.76795483] ; [106.69584656,10.76832676] ; [106.69584656,10.76832676]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69584656,10.76832676] ; [106.69584656,10.76832676] ; [106.69663239,10.76927757] ; [106.69750977,10.77020550] ; [106.69844818,10.77054024] ; [106.69844818,10.77054024]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2721"
    ,"Station_Code":"Q1 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Bệnh viện Đa khoa Sài Gòn"
    ,"Station_Address":"125, đường Lê Lợi, Quận 1"
    ,"Lat":10.772139
    ,"Long":106.699219
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69902039,10.77083206] ; [106.69894409,10.77121735] ; [106.69886017,10.77142811] ; [106.69886780,10.77158070] ; [106.69884491,10.77173901] ; [106.69907379,10.77203369] ; [106.69921875,10.77213860]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2723"
    ,"Station_Code":"Q1 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Sài Gòn Centre"
    ,"Station_Address":"Đối diện 58, đường Lê Lợi, Quận 1"
    ,"Lat":10.773594
    ,"Long":106.700587
    ,"Polyline":"[106.69921875,10.77213860] ; [106.70058441,10.77359390]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2724"
    ,"Station_Code":"Q1 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Lê Thánh T ôn"
    ,"Station_Address":"144, đường Pasteur, Quận 1"
    ,"Lat":10.775088
    ,"Long":106.700768
    ,"Polyline":"[106.70058441,10.77359390] ; [106.70109558,10.77425766] ; [106.70076752,10.77508831]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"4272"
    ,"Station_Code":"Q1 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Lý Tự Trọng"
    ,"Station_Address":"158, đường Pasteur, Quận 1"
    ,"Lat":10.777089
    ,"Long":106.699657
    ,"Polyline":"[106.70076752,10.77508831] ; [106.69995117,10.77685070] ; [106.69965363,10.77708912]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"4273"
    ,"Station_Code":"Q1 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Công viên 30/4"
    ,"Station_Address":"178, đường Pasteur, Quận 1"
    ,"Lat":10.778307999999999
    ,"Long":106.698333
    ,"Polyline":"[106.69965363,10.77708912] ; [106.69833374,10.77830791]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"291"
    ,"Station_Code":"Q1 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Pasteur"
    ,"Station_Address":"43 - 45 - 47, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.781031
    ,"Long":106.696434
    ,"Polyline":"[106.69833374,10.77830791] ; [106.69833374,10.77830791] ; [106.69696808,10.77952766] ; [106.69592285,10.78051853] ; [106.69643402,10.78103065] ; [106.69643402,10.78103065]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"41"
    ,"Station_Code":"Q1 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Sở Công Thương"
    ,"Station_Address":"142, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.784297
    ,"Long":106.696526
    ,"Polyline":"[106.69643402,10.78103065] ; [106.69818115,10.78288937] ; [106.69652557,10.78429699]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"43"
    ,"Station_Code":"Q1 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Công viên  Lê Văn Tám"
    ,"Station_Address":"Đối diện 245 , đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.787427
    ,"Long":106.692599
    ,"Polyline":"[106.69652557,10.78429699] ; [106.69259644,10.78742695]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"46"
    ,"Station_Code":"Q1 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Nhà thờ Tân Định"
    ,"Station_Address":"298, đường Hai B à Trưng, Quận 1"
    ,"Lat":10.789215
    ,"Long":106.690399
    ,"Polyline":"[106.69259644,10.78742695] ; [106.69142914,10.78834343] ; [106.69039917,10.78921509]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"47"
    ,"Station_Code":"Q1 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Tân Định"
    ,"Station_Address":"372-374, đường Hai  Bà Trưng, Quận 1"
    ,"Lat":10.790456
    ,"Long":106.688843
    ,"Polyline":"[106.69039917,10.78921509] ; [106.69006348,10.78941917] ; [106.68884277,10.79045582]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2728"
    ,"Station_Code":"Q1 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Bà Lê Chân"
    ,"Station_Address":"151Bis, đường Trần Quang Khải, Quận 1"
    ,"Lat":10.79162
    ,"Long":106.690231
    ,"Polyline":"[106.68884277,10.79045582] ; [106.68884277,10.79045582] ; [106.68885040,10.79046249] ; [106.68884277,10.79045868] ; [106.68884277,10.79045582] ; [106.68775177,10.79127884] ; [106.69013214,10.79168987] ; [106.69023132,10.79162025] ; [106.69023132,10.79162025] ; [106.69023132,10.79162025]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2726"
    ,"Station_Code":"Q1 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ Dakao"
    ,"Station_Address":"45-47, đường Trần Quang Kh ải, Quận 1"
    ,"Lat":10.79239
    ,"Long":106.694878
    ,"Polyline":"[106.69023132,10.79162025] ; [106.69033813,10.79172134] ; [106.69467163,10.79245949] ; [106.69487762,10.79238987]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2033"
    ,"Station_Code":"QBTH 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"96, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.796032
    ,"Long":106.696225
    ,"Polyline":"[106.69487762,10.79238987] ; [106.69487762,10.79238987] ; [106.69509125,10.79252243] ; [106.69532013,10.79258060] ; [106.69594574,10.79267025] ; [106.69611359,10.79435158] ; [106.69616699,10.79551601] ; [106.69622803,10.79603195] ; [106.69622803,10.79603195]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2727"
    ,"Station_Code":"QBTH 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"114 , đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.798066
    ,"Long":106.696376
    ,"Polyline":"[106.69622803,10.79603195] ; [106.69622803,10.79603195] ; [106.69624329,10.79703331] ; [106.69637299,10.79806614] ; [106.69637299,10.79806614]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2109"
    ,"Station_Code":"QBTH 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Lăng Ông  Bà Chiểu"
    ,"Station_Address":"Đối diện 129,  đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.80147
    ,"Long":106.696569
    ,"Polyline":"[106.69637299,10.79806614] ; [106.69657135,10.80146980]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"UBND Qu ận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69657135,10.80146980] ; [106.69663239,10.80270863] ; [106.69578552,10.80281925]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2039"
    ,"Station_Code":"QBTH 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"2, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803488
    ,"Long":106.695013
    ,"Polyline":"[106.69578552,10.80281925] ; [106.69578552,10.80281925] ; [106.69537354,10.80283451] ; [106.69498444,10.80291367] ; [106.69496155,10.80318832] ; [106.69501495,10.80348778] ; [106.69501495,10.80348778]"
    ,"Distance":"153"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2035"
    ,"Station_Code":"QBTH 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"48, đường  Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.806076
    ,"Long":106.695083
    ,"Polyline":"[106.69501495,10.80348778] ; [106.69508362,10.80607605]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"1650"
    ,"Station_Code":"QBTH 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Nhà thờ Bình  Hòa"
    ,"Station_Address":"124, đường Nơ Trang  Long, Quận Bình Thạnh"
    ,"Lat":10.809732
    ,"Long":106.695158
    ,"Polyline":"[106.69508362,10.80607605] ; [106.69515991,10.80973244]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2746"
    ,"Station_Code":"QBTH 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngã 5 Bình Hòa"
    ,"Station_Address":"170L, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.811745
    ,"Long":106.695925
    ,"Polyline":"[106.69509888,10.80978012] ; [106.69510651,10.81023979] ; [106.69519043,10.81058979] ; [106.69550323,10.81120014] ; [106.69587708,10.81175041]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2748"
    ,"Station_Code":"QBTH 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Siêu thị Satra Food"
    ,"Station_Address":"244-246, đường Nơ Trang Long , Quận Bình Thạnh"
    ,"Lat":10.813811
    ,"Long":106.69754
    ,"Polyline":"[106.69592285,10.81174469] ; [106.69615173,10.81208229] ; [106.69684601,10.81294632] ; [106.69754028,10.81381130]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2747"
    ,"Station_Code":"QBTH 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Nhà văn hóa Lao Động"
    ,"Station_Address":"290, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.816245
    ,"Long":106.697931
    ,"Polyline":"[106.69754028,10.81381130] ; [106.69776917,10.81431007] ; [106.69783783,10.81455040] ; [106.69788361,10.81472969] ; [106.69789124,10.81482983] ; [106.69790649,10.81536961] ; [106.69789124,10.81577969] ; [106.69792938,10.81624508]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2750"
    ,"Station_Code":"QBTH 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Trường Trung cấp xây dựng Tp. HCM"
    ,"Station_Address":"380, đường Nơ Trang Long, Quận Bình Th ạnh"
    ,"Lat":10.81889
    ,"Long":106.70078
    ,"Polyline":"[106.69792938,10.81624508] ; [106.69786072,10.81681442] ; [106.69787598,10.81712532] ; [106.69795990,10.81740952] ; [106.69807434,10.81761551] ; [106.69820404,10.81781006] ; [106.69867706,10.81828976] ; [106.69893646,10.81851101] ; [106.69939423,10.81879520] ; [106.69957733,10.81885815] ; [106.69976807,10.81890106.06.70078278]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2749"
    ,"Station_Code":"QBTH 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"UBND Phường 13, Quận Bình Thạnh"
    ,"Station_Address":"450-452, đường  Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.819697
    ,"Long":106.70327
    ,"Polyline":"[106.70078278,10.81888962] ; [106.70098114,10.81898499] ; [106.70112610,10.81905842] ; [106.70149231,10.81917953] ; [106.70265961,10.81951046] ; [106.70316315,10.81966019] ; [106.70326996,10.81969738]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2752"
    ,"Station_Code":"QBTH 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Bình Lợi"
    ,"Station_Address":"444, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.823148
    ,"Long":106.707126
    ,"Polyline":"[106.70326996,10.81970024] ; [106.70394897,10.82001972] ; [106.70417023,10.82015991] ; [106.70458984,10.82046986] ; [106.70561218,10.82120037] ; [106.70684052,10.82209969] ; [106.70702362,10.82238007] ; [106.70704651,10.82252026] ; [106.70706177,10.82314968]"
    ,"Distance":"605"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2751"
    ,"Station_Code":"QBTH 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Đường ray xe lửa"
    ,"Station_Address":"424, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.826098
    ,"Long":106.706536
    ,"Polyline":"[106.70706177,10.82314968] ; [106.70706940,10.82374001] ; [106.70697784,10.82409954] ; [106.70691681,10.82425022] ; [106.70671844,10.82513046] ; [106.70664978,10.82538033] ; [106.70651245,10.82600975]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2754"
    ,"Station_Code":"QBTH 141"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Trung tâm bảo trợ xã hội"
    ,"Station_Address":"456, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.827932
    ,"Long":106.706155
    ,"Polyline":"[106.70653534,10.82609844] ; [106.70615387,10.82793236]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2753"
    ,"Station_Code":"QBTH 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Chùa Diệu Pháp"
    ,"Station_Address":"464, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.831688
    ,"Long":106.705329
    ,"Polyline":"[106.70615387,10.82793236] ; [106.70574188,10.83001804] ; [106.70555115,10.83098793] ; [106.70532990,10.83168793]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2756"
    ,"Station_Code":"QBTH 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Liên Minh"
    ,"Station_Address":"196, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.834075
    ,"Long":106.704229
    ,"Polyline":"[106.70532990,10.83168793] ; [106.70503998,10.83267879] ; [106.70487976,10.83293724] ; [106.70423126,10.83407497]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"52"
    ,"Station_Id":"2535"
    ,"Station_Code":"BX94"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Khu dân cư Bình Lợi"
    ,"Station_Address":"Khu dân cư Bình Lợi, đường Bình Lợi, Quận Bình Thạnh"
    ,"Lat":10.835313
    ,"Long":106.702893
    ,"Polyline":"[106.70423126,10.83407497] ; [106.70401764,10.83439159] ; [106.70338440,10.83501339] ; [106.70310211,10.83522892] ; [106.70289612,10.83531284]"
    ,"Distance":"204"
  }]