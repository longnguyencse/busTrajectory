export const Route60 =[

  {
     "Route_Id":"60"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vư ơng, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"630"
    ,"Station_Code":"QBT 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"480, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739675
    ,"Long":106.616392
    ,"Polyline":"[106.61846161,10.74116039] ; [106.61834717,10.74106979] ; [106.61823273,10.74118996] ; [106.61666107,10.73987961] ; [106.61640930,10.73966026]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"631"
    ,"Station_Code":"QBT 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"548, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.735138
    ,"Long":106.613144
    ,"Polyline":"[106.61643219,10.73968792] ; [106.61525726,10.73853683] ; [106.61314392,10.73513794]"
    ,"Distance":"625"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"632"
    ,"Station_Code":"QBT 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"SinCo"
    ,"Station_Address":"Đối diện nhà trọ  Thanh Trường, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.731674
    ,"Long":106.611028
    ,"Polyline":"[106.61314392,10.73513794] ; [106.61314392,10.73513794] ; [106.61107635,10.73165607] ; [106.61107635,10.73165607] ; [106.61107635,10.73165607]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"633"
    ,"Station_Code":"QBT 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Hoa hồng"
    ,"Station_Address":"620, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729014
    ,"Long":106.608276
    ,"Polyline":"[106.61107635,10.73165607] ; [106.61107635,10.73165035] ; [106.61047363,10.73066807] ; [106.61006927,10.73023987] ; [106.60946655,10.72978973] ; [106.60827637,10.72900963] ; [106.60827637,10.72901440]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"1799"
    ,"Station_Code":"QBT 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ Khu phố 2"
    ,"Station_Address":"515, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.726019
    ,"Long":106.608459
    ,"Polyline":"[106.60827637,10.72901440] ; [106.60827637,10.72901440] ; [106.60745239,10.72836494] ; [106.60728455,10.72820663] ; [106.60797119,10.72712040] ; [106.60845947,10.72601891] ; [106.60845947,10.72601891] ; [106.60845947,10.72601891]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"1798"
    ,"Station_Code":"QBT 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Sùng Quang"
    ,"Station_Address":"76, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.723284
    ,"Long":106.610566
    ,"Polyline":"[106.60845947,10.72601891] ; [106.60845947,10.72601891] ; [106.60950470,10.72466469] ; [106.60997772,10.72395802] ; [106.61022949,10.72324371] ; [106.61022949,10.72324371]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2873"
    ,"Station_Code":"QBT 231"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Phú Định"
    ,"Station_Address":"298/2, đường Võ Văn Kiệt, Quận Bình T ân"
    ,"Lat":10.722883
    ,"Long":106.613485
    ,"Polyline":"[106.61022949,10.72324371] ; [106.61022949,10.72324371] ; [106.61077881,10.72273540] ; [106.61132813,10.72195530] ; [106.61368561,10.72303009]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2874"
    ,"Station_Code":"Q8 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"An Dương Vương"
    ,"Station_Address":"Trạm  biến điện RMU, đường Võ Văn Kiệt, Quận 8"
    ,"Lat":10.726825
    ,"Long":106.621215
    ,"Polyline":"[106.61368561,10.72303009] ; [106.61742401,10.72493839] ; [106.62118530,10.72652721] ; [106.62118530,10.72652721]"
    ,"Distance":"909"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2875"
    ,"Station_Code":"Q8 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Carina Plaza"
    ,"Station_Address":"Đối diện Carina Plaza, đư ờng Võ Văn Kiệt, Quận 8"
    ,"Lat":10.728686
    ,"Long":106.624675
    ,"Polyline":"[106.62118530,10.72652721] ; [106.62118530,10.72652721] ; [106.62241364,10.72746849] ; [106.62409973,10.72842407] ; [106.62578583,10.72938061] ; [106.62578583,10.72938061]"
    ,"Distance":"596"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2877"
    ,"Station_Code":"Q6 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Cầu Rạch Cây"
    ,"Station_Address":"Đối diện 7/51A, đường Võ Văn Kiệt, Quận 6"
    ,"Lat":10.732797
    ,"Long":106.632013
    ,"Polyline":"[106.62578583,10.72938061] ; [106.63201904,10.73278618]"
    ,"Distance":"780"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2876"
    ,"Station_Code":"Q6 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cầu Lò Gốm"
    ,"Station_Address":"Đối diện 610, đường Võ Văn Kiệt, Quận 6"
    ,"Lat":10.736516
    ,"Long":106.638214
    ,"Polyline":"[106.63201904,10.73278618] ; [106.63821411,10.73651600]"
    ,"Distance":"795"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2879"
    ,"Station_Code":"Q6 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Bình Tiên"
    ,"Station_Address":"Đối diện 1550A, đường Võ Văn Kiệt, Quận 6"
    ,"Lat":10.738576
    ,"Long":106.641624
    ,"Polyline":"[106.63821411,10.73651600] ; [106.64162445,10.73857594]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2878"
    ,"Station_Code":"Q6 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Phạm Phú Thứ"
    ,"Station_Address":"Đối diện  1484-1486, đường Võ Văn Kiệt, Quận 6"
    ,"Lat":10.741669
    ,"Long":106.646698
    ,"Polyline":"[106.64162445,10.73857594] ; [106.64669800,10.74166870]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2881"
    ,"Station_Code":"Q6 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"Đối diện 1396, đường Võ  Văn Kiệt, Quận 6"
    ,"Lat":10.745531
    ,"Long":106.653305
    ,"Polyline":"[106.64669800,10.74166870] ; [106.65332031,10.74552155]"
    ,"Distance":"844"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2880"
    ,"Station_Code":"Q5 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Hải Thượng Lãn Ông"
    ,"Station_Address":"Đối diện 1182 , đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.750416
    ,"Long":106.664795
    ,"Polyline":"[106.65330505,10.74553108] ; [106.65332031,10.74552155] ; [106.65624237,10.74722195] ; [106.65793610,10.74806595] ; [106.66132355,10.74922466] ; [106.66481781,10.75035858] ; [106.66481781,10.75035858]"
    ,"Distance":"1376"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2883"
    ,"Station_Code":"Q5 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu Nguyễn Tri Phương"
    ,"Station_Address":"Đối diện 1042 , đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.749984
    ,"Long":106.670364
    ,"Polyline":"[106.66481781,10.75035858] ; [106.66481781,10.75035858] ; [106.66558075,10.75058460] ; [106.66636658,10.75058460] ; [106.66787720,10.75036335] ; [106.67036438,10.74998379] ; [106.67036438,10.74998379]"
    ,"Distance":"615"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2882"
    ,"Station_Code":"Q5 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"An Bình"
    ,"Station_Address":"Đối diện 830, đường Võ Văn  Kiệt, Quận 5"
    ,"Lat":10.749046
    ,"Long":106.674677
    ,"Polyline":"[106.67036438,10.74998379] ; [106.67036438,10.74998379] ; [106.67087555,10.74996281] ; [106.67212677,10.74946785] ; [106.67335510,10.74907780] ; [106.67467499,10.74896717] ; [106.67467499,10.74896717]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2885"
    ,"Station_Code":"Q5 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Bệnh viện Nhiệt Đới"
    ,"Station_Address":"Đối diện 764, đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.752092
    ,"Long":106.679279
    ,"Polyline":"[106.67467499,10.74896717] ; [106.67467499,10.74896717] ; [106.67555237,10.74945736] ; [106.67617035,10.75020504] ; [106.67660522,10.75130177] ; [106.67696381,10.75170231] ; [106.67774963,10.75205994] ; [106.67928314,10.75205517] ; [106.67928314,10.75205517]"
    ,"Distance":"671"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2884"
    ,"Station_Code":"Q5 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà đèn Chợ Quán"
    ,"Station_Address":"Đối diện 638-640, đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.752471
    ,"Long":106.686081
    ,"Polyline":"[106.67928314,10.75205517] ; [106.67928314,10.75205517] ; [106.67996216,10.75221825] ; [106.68078613,10.75235558] ; [106.68178558,10.75221825] ; [106.68284607,10.75191307] ; [106.68397522,10.75161743] ; [106.68469238,10.75155449] ; [106.68537903,10.75179672] ; [106.68607330,10.75247669] ; [106.68607330,10.75247669]"
    ,"Distance":"793"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2887"
    ,"Station_Code":"Q1 164"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Nguyễn Văn Cừ"
    ,"Station_Address":"Đối diện 610, đường Võ Văn Kiệt, Quận 1"
    ,"Lat":10.754898
    ,"Long":106.68824
    ,"Polyline":"[106.68607330,10.75247669] ; [106.68607330,10.75247669] ; [106.68649292,10.75316715] ; [106.68717957,10.75403118] ; [106.68824005,10.75489807] ; [106.68824005,10.75489807]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2886"
    ,"Station_Code":"Q1 165"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Hồ Hảo Hớn"
    ,"Station_Address":"Đối diện 414 , đường Võ Văn Kiệt, Quận 1"
    ,"Lat":10.759746
    ,"Long":106.694519
    ,"Polyline":"[106.68824005,10.75489807] ; [106.68824005,10.75489807] ; [106.68945313,10.75632954] ; [106.69181824,10.75810051] ; [106.69451904,10.75974560] ; [106.69451904,10.75974560]"
    ,"Distance":"880"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2889"
    ,"Station_Code":"Q1 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Chợ Nga"
    ,"Station_Address":"Đối diện 324, đường Võ Văn  Kiệt, Quận 1"
    ,"Lat":10.7618
    ,"Long":106.696692
    ,"Polyline":"[106.69451904,10.75974560] ; [106.69451904,10.75974560] ; [106.69502258,10.76010799] ; [106.69563293,10.76060295] ; [106.69606781,10.76117802] ; [106.69658661,10.76174450] ; [106.69658661,10.76174355]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2888"
    ,"Station_Code":"Q1 168"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Dân Sinh"
    ,"Station_Address":"98, đường Ký Con, Quận 1"
    ,"Lat":10.767259
    ,"Long":106.698505
    ,"Polyline":"[106.69658661,10.76174355] ; [106.69658661,10.76174450] ; [106.69786835,10.76374912] ; [106.69887543,10.76440334] ; [106.69995117,10.76503563] ; [106.70014191,10.76533031] ; [106.69934845,10.76623726] ; [106.69846344,10.76719570] ; [106.69846344,10.76719570]"
    ,"Distance":"849"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69846344,10.76719570] ; [106.69750977,10.76823997] ; [106.69657135,10.76920891] ; [106.69694519,10.76967335] ; [106.69745636,10.77022076] ; [106.69757843,10.77031612] ; [106.69844818,10.77054024]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Ernst  Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69841766,10.77060986] ; [106.69879150,10.77074814] ; [106.69897461,10.77104282] ; [106.69899750,10.77133846] ; [106.69879150,10.77168083] ; [106.69861603,10.77187061] ; [106.69839478,10.77194405] ; [106.69818878,10.77182865] ; [106.69807434,10.77163887] ; [106.69808960,10.77136421] ; [106.69815826,10.77121735] ; [106.69797516,10.77099037] ; [106.69768524,10.77070045] ; [106.69746399,10.77039528] ; [106.69717407,10.77021027] ; [106.69649506,10.76999474] ; [106.69613647,10.76985264] ; [106.69577789,10.76972771]"
    ,"Distance":"640"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Qu ận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"199.361852221807"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"240"
    ,"Station_Code":"Q1 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chợ Thái Bình"
    ,"Station_Address":"Đối diện 361, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.767365
    ,"Long":106.689831
    ,"Polyline":"[106.69398499,10.76903534] ; [106.68983459,10.76736546]"
    ,"Distance":"522.166024651263"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai , Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.68983459,10.76736546] ; [106.68949127,10.76724911] ; [106.68936157,10.76767635]"
    ,"Distance":"57.0448566331153"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204 , đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68923950,10.76806545] ; [106.68922424,10.76815510.06.68995667] ; [10.76846981,106.69026184] ; [10.76858997,106.69029999]"
    ,"Distance":"188"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường  Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69029999,10.76851273] ; [106.69029999,10.76851273] ; [106.69026184,10.76860046] ; [106.69181824,10.76918316] ; [106.69329834,10.76982021] ; [106.69333649,10.76973057] ; [106.69333649,10.76973057]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Bến Thành A"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69333649,10.76973057] ; [106.69570160,10.77071667] ; [106.69707489,10.77127552] ; [106.69779968,10.77160168] ; [106.69802094,10.77153301] ; [106.69807434,10.77133846] ; [106.69832611,10.77118587] ; [106.69869232,10.77120113] ; [106.69890594,10.77102757] ; [106.69853973,10.77089596]"
    ,"Distance":"724"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2854"
    ,"Station_Code":"Q1 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Dân Sinh"
    ,"Station_Address":"125-127, đường Ký Con, Quận 1"
    ,"Lat":10.767312
    ,"Long":106.698242
    ,"Polyline":"[106.69853973,10.77089596] ; [106.69857788,10.77079010.06.69767761] ; [10.77053738,106.69643402] ; [10.76925659,106.69654846] ; [10.76926708,106.69829559] ; [10.76734447,106.69829559]"
    ,"Distance":"611"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2857"
    ,"Station_Code":"Q1 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ Nga"
    ,"Station_Address":"324, đường Võ Văn Kiệt, Quận 1"
    ,"Lat":10.761784
    ,"Long":106.696118
    ,"Polyline":"[106.69829559,10.76734447] ; [106.69854736,10.76706409] ; [106.69924164,10.76632118] ; [106.70003510,10.76545715] ; [106.69889832,10.76476097] ; [106.69797516,10.76410770] ; [106.69615173,10.76173019] ; [106.69613647,10.76174068]"
    ,"Distance":"888"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2856"
    ,"Station_Code":"Q1 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường tiểu học Chương Dương"
    ,"Station_Address":"490 , đường Võ Văn Kiệt, Quận 1"
    ,"Lat":10.75852
    ,"Long":106.691841
    ,"Polyline":"[106.69615173,10.76173019] ; [106.69570923,10.76113987] ; [106.69537354,10.76076984] ; [106.69480896,10.76031017] ; [106.69410706,10.75990009] ; [106.69373322,10.75967026] ; [106.69268036,10.75903988] ; [106.69185638,10.75850010]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2858"
    ,"Station_Code":"Q5 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Nhà Đèn Chợ Quán"
    ,"Station_Address":"628-630 (8), đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.753272
    ,"Long":106.686287
    ,"Polyline":"[106.69185638,10.75850010.06.69152832] ; [10.75827980,106.69116211] ; [10.75800037,106.69072723] ; [10.75763988,106.68974304] ; [10.75685978,106.68868256] ; [10.75584984,106.68816376] ; [10.75533962,106.68733215] ; [10.75450993,106.68695068] ; [10.75422955,106.68675232] ; [10.75407982,106.68657684] ; [10.75393009,106.68649292] ; [10.75382042,106.68637848] ; [10.75366020,106.68620300]"
    ,"Distance":"863"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2859"
    ,"Station_Code":"Q5 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trần Bình Trọng"
    ,"Station_Address":"682-686 (60-62), đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.751929
    ,"Long":106.683228
    ,"Polyline":"[106.68628693,10.75327206] ; [106.68620300,10.75333977] ; [106.68598938,10.75290012] ; [106.68585205,10.75257015] ; [106.68576050,10.75240993] ; [106.68566132,10.75228024] ; [106.68550873,10.75216007] ; [106.68533325,10.75203991] ; [106.68509674,10.75191021] ; [106.68492126,10.75185966] ; [106.68460846,10.75179005] ; [106.68428040,10.75177956] ; [106.68386078,10.75185966] ; [106.68354034,10.75193024] ; [106.68322754,10.75192928]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2860"
    ,"Station_Code":"Q5 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh viện Nhiệt Đới"
    ,"Station_Address":"764, đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.752234
    ,"Long":106.678795
    ,"Polyline":"[106.68269348,10.75218010.06.68213654] ; [10.75234985,106.68183136] ; [10.75242043,106.68144989] ; [10.75251961,106.68125153] ; [10.75255013,106.68093872] ; [10.75255966,106.68045807] ; [10.75253010.06.67997742,10.75245953] ; [106.67906952,10.75232029] ; [106.67878723,10.75228977]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2861"
    ,"Station_Code":"Q5 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Hòa Bình"
    ,"Station_Address":"794, đường V õ Văn Kiệt, Quận 5"
    ,"Lat":10.751644
    ,"Long":106.676651
    ,"Polyline":"[106.67879486,10.75223446] ; [106.67878723,10.75228977] ; [106.67812347,10.75228024] ; [106.67781830,10.75226974] ; [106.67751312,10.75220966] ; [106.67715454,10.75201321] ; [106.67697144,10.75195980] ; [106.67655945,10.75170040] ; [106.67657471,10.75168610]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2862"
    ,"Station_Code":"Q5 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Đại Thế Giới"
    ,"Station_Address":"1114, đường Võ V ăn Kiệt, Quận 5"
    ,"Lat":10.750508
    ,"Long":106.668167
    ,"Polyline":"[106.67655945,10.75170040] ; [106.67617798,10.75123978] ; [106.67606354,10.75096989] ; [106.67601776,10.75086975] ; [106.67598724,10.75072002] ; [106.67588043,10.75024986] ; [106.67578125,10.75002956] ; [106.67565155,10.74983978] ; [106.67542267,10.74964046] ; [106.67513275,10.74944973] ; [106.67485046,10.74934006] ; [106.67439270,10.74925995] ; [106.67388916,10.74927998] ; [106.67346191,10.74934006] ; [106.67305756,10.74948978] ; [106.67273712,10.74956989] ; [106.67179871,10.74991035] ; [106.67092896,10.75020981] ; [106.67056274,10.75028992] ; [106.66941833,10.75043964] ; [106.66941833,10.75037003] ; [106.66921234,10.75037956] ; [106.66815948,10.75047970]"
    ,"Distance":"1104"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2863"
    ,"Station_Code":"Q5 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Hải Thượng Lãn Ông"
    ,"Station_Address":"1182, đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.750342
    ,"Long":106.663926
    ,"Polyline":"[106.66816711,10.75050831] ; [106.66815948,10.75047970] ; [106.66694641,10.75065041] ; [106.66616058,10.75072956] ; [106.66549683,10.75072002] ; [106.66481781,10.75061035] ; [106.66420746,10.75041962] ; [106.66390228,10.75037956] ; [106.66390228,10.75037956]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2864"
    ,"Station_Code":"Q5 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu Chà Và"
    ,"Station_Address":"1268, đường Võ Văn Kiệt, Quận 5"
    ,"Lat":10.749186
    ,"Long":106.660614
    ,"Polyline":"[106.66390228,10.75037956] ; [106.66390228,10.75037956] ; [106.66362762,10.75025845] ; [106.66348267,10.75016022] ; [106.66216278,10.74969959] ; [106.66062164,10.74917030] ; [106.66061401,10.74918556]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2865"
    ,"Station_Code":"Q6 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"1378, đường Võ Văn Kiệt, Quận 6"
    ,"Lat":10.746189
    ,"Long":106.65404
    ,"Polyline":"[106.66061401,10.74918556] ; [106.66062164,10.74917030] ; [106.66023254,10.74909306] ; [106.65882874,10.74862957] ; [106.65763092,10.74820042] ; [106.65701294,10.74792957] ; [106.65666962,10.74777031] ; [106.65524292,10.74693966] ; [106.65428162,10.74639034] ; [106.65428162,10.74633980] ; [106.65406036,10.74621964] ; [106.65403748,10.74619484]"
    ,"Distance":"803"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2867"
    ,"Station_Code":"Q6 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Mai Xuân Thưởng"
    ,"Station_Address":"1454, đường Võ Văn Kiệt, Quận 6"
    ,"Lat":10.743786
    ,"Long":106.64992
    ,"Polyline":"[106.65403748,10.74619484] ; [106.65406036,10.74621964] ; [106.65397644,10.74617004] ; [106.65393066,10.74619007] ; [106.65332794,10.74582005] ; [106.65189362,10.74505043] ; [106.65091705,10.74435520] ; [106.64994049,10.74374962] ; [106.64990997,10.74379444]"
    ,"Distance":"540"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2866"
    ,"Station_Code":"Q6 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bình Tiên"
    ,"Station_Address":"1534A , đường Võ Văn Kiệt, Quận 6"
    ,"Lat":10.739564
    ,"Long":106.642817
    ,"Polyline":"[106.64994049,10.74374962] ; [106.64924622,10.74335003] ; [106.64849091,10.74293041] ; [106.64681244,10.74193954] ; [106.64394379,10.74024010.06.64385986] ; [10.74015999,106.64282227]"
    ,"Distance":"921"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2868"
    ,"Station_Code":"Q6 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Lò Gốm"
    ,"Station_Address":"1610, đường Võ Văn Kiệt, Qu ận 6"
    ,"Lat":10.736434
    ,"Long":106.637684
    ,"Polyline":"[106.64282227,10.73952961] ; [106.64112091,10.73847961] ; [106.63770294,10.73639965]"
    ,"Distance":"670"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2869"
    ,"Station_Code":"Q6 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Cầu Rạch Cây"
    ,"Station_Address":"7/51A, đường Võ Văn Kiệt, Qu ận 6"
    ,"Lat":10.732523
    ,"Long":106.631042
    ,"Polyline":"[106.63770294,10.73639965] ; [106.63693237,10.73593044] ; [106.63630676,10.73561001] ; [106.63432312,10.73439980] ; [106.63377380,10.73404026] ; [106.63188934,10.73295021] ; [106.63105774,10.73248959]"
    ,"Distance":"856"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2870"
    ,"Station_Code":"Q8 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Carina Plaza"
    ,"Station_Address":"Carina Plaza, đường Võ Văn Ki ệt, Quận 8"
    ,"Lat":10.729503
    ,"Long":106.625512
    ,"Polyline":"[106.63105774,10.73248959] ; [106.62766266,10.73058033] ; [106.62545013,10.72941017]"
    ,"Distance":"717"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2871"
    ,"Station_Code":"QBT 229"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường số 1B"
    ,"Station_Address":"Tủ điện 6-3, đường  Võ Văn Kiệt, Quận Bình Tân"
    ,"Lat":10.725624
    ,"Long":106.617897
    ,"Polyline":"[106.62553406,10.72945595] ; [106.62545013,10.72941017] ; [106.62213898,10.72758961] ; [106.62135315,10.72716045] ; [106.62055206,10.72677040] ; [106.61791229,10.72560024] ; [106.61789703,10.72562408]"
    ,"Distance":"942"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"2872"
    ,"Station_Code":"QBT 230"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Hồ Học Lãm"
    ,"Station_Address":"Trạm tủ điện P8.1, đường Võ Văn Kiệt, Quận Bình Tân"
    ,"Lat":10.722957
    ,"Long":106.612541
    ,"Polyline":"[106.61789703,10.72562408] ; [106.61579132,10.72440052] ; [106.61351013,10.72344971] ; [106.61254120,10.72296047] ; [106.61254120,10.72295666]"
    ,"Distance":"658"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"1850"
    ,"Station_Code":"QBT 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Chùa Sùng Quang"
    ,"Station_Address":"324, đường H ồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.72283
    ,"Long":106.610577
    ,"Polyline":"[106.61254120,10.72295666] ; [106.61254120,10.72296047] ; [106.61183929,10.72258282] ; [106.61109161,10.72225094] ; [106.61075592,10.72292519]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"1851"
    ,"Station_Code":"QBT 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Khu phố 2"
    ,"Station_Address":"35, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.725845
    ,"Long":106.608775
    ,"Polyline":"[106.61075592,10.72292519] ; [106.60882568,10.72586632]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"709"
    ,"Station_Code":"QBT 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"703, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72832
    ,"Long":106.607605
    ,"Polyline":"[106.60882568,10.72586632] ; [106.60768890,10.72754002] ; [106.60732269,10.72815037] ; [106.60761261,10.72832966] ; [106.60761261,10.72832489] ; [106.60760498,10.72832012]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"714"
    ,"Station_Code":"QBT 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ủy ban"
    ,"Station_Address":"631-637, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729977
    ,"Long":106.610255
    ,"Polyline":"[106.60760498,10.72832012] ; [106.61019135,10.73007774]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"710"
    ,"Station_Code":"QBT 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Lâm Thành"
    ,"Station_Address":"289(561), đ ường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.734278
    ,"Long":106.61298
    ,"Polyline":"[106.61019135,10.73007774] ; [106.61285400,10.73427963]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"716"
    ,"Station_Code":"QBT 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"251(511), đường Kinh Dư ơng Vương, Quận Bình Tân"
    ,"Lat":10.737541
    ,"Long":106.614906
    ,"Polyline":"[106.61285400,10.73427963] ; [106.61484528,10.73754978]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"713"
    ,"Station_Code":"QBT 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"Bệnh viện Triều An, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739665
    ,"Long":106.61687
    ,"Polyline":"[106.61484528,10.73754978] ; [106.61484528,10.73754978] ; [106.61555481,10.73862076] ; [106.61680603,10.73975658] ; [106.61680603,10.73975658]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"60"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61679840,10.73976040] ; [106.61814880,10.74088955]"
    ,"Distance":"222"
  }]