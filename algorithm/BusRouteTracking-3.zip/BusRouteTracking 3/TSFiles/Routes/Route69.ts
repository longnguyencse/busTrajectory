export const Route69 =[

  {
     "Route_Id":"69"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguyễn Ảnh Thủ, Quận  12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1618"
    ,"Station_Code":"Q12 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"Trường Mau gi áo Họa Mi 2, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877224
    ,"Long":106.641283
    ,"Polyline":"[106.64203644,10.87744999] ; [106.64181519,10.87709713] ; [106.64128113,10.87722397]"
    ,"Distance":"106"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2054"
    ,"Station_Code":"Q12 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Đông Bắc"
    ,"Station_Address":"288, đường Tô Ký, Quận 12"
    ,"Lat":10.855729
    ,"Long":106.623039
    ,"Polyline":"[106.64128113,10.87722397] ; [106.64112854,10.87714481] ; [106.64044952,10.87604904] ; [106.63969421,10.87483215] ; [106.63811493,10.87242985] ; [106.63719177,10.87102795] ; [106.63650513,10.86979580] ; [106.63629150,10.86922169] ; [106.63529205,10.86711407] ; [106.63464355,10.86569691] ; [106.63388062,10.86432743] ; [106.63276672,10.86262035] ; [106.63221741,10.86167717] ; [106.63182068,10.86109257] ; [106.63120270,10.86040211] ; [106.62940979,10.85842133] ; [106.62936401,10.85815239] ; [106.62935638,10.85781574] ; [106.62512207,10.85743046] ; [106.62489319,10.85736275] ; [106.62353516,10.85552883] ; [106.62303925,10.85572910]"
    ,"Distance":"3347"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2055"
    ,"Station_Code":"Q12 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Điện lực Hóc Môn"
    ,"Station_Address":"Điền lực Hóc Môn, đường  Tô Ký, Quận 12"
    ,"Lat":10.856714
    ,"Long":106.620909
    ,"Polyline":"[106.62303925,10.85572910.06.62194061] ; [10.85615063,106.62091064]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2058"
    ,"Station_Code":"Q12 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chiếc nón Kỳ Diệu"
    ,"Station_Address":"312, đường T ô Ký, Quận 12"
    ,"Lat":10.857816
    ,"Long":106.619294
    ,"Polyline":"[106.62091064,10.85671425] ; [106.62006378,10.85716724] ; [106.61929321,10.85781574]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2059"
    ,"Station_Code":"Q12 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"chợ Tân Chánh Hiệp"
    ,"Station_Address":"414, đường T ô Ký, Quận 12"
    ,"Lat":10.859275
    ,"Long":106.617867
    ,"Polyline":"[106.61929321,10.85781574] ; [106.61788177,10.85888004] ; [106.61786652,10.85927486]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2060"
    ,"Station_Code":"Q12 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Doanh trại Quân Đội"
    ,"Station_Address":"A49, đường Tô Ký, Quận 12"
    ,"Lat":10.86154
    ,"Long":106.617427
    ,"Polyline":"[106.61786652,10.85927486] ; [106.61742401,10.86153984]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2061"
    ,"Station_Code":"Q12 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Đại học Lao động Xã hội"
    ,"Station_Address":"72, đường Tô Ký, Quận 12"
    ,"Lat":10.863368
    ,"Long":106.616945
    ,"Polyline":"[106.61742401,10.86153984] ; [106.61694336,10.86336803]"
    ,"Distance":"210"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1635"
    ,"Station_Code":"QHMT250"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây xăng Minh Luân"
    ,"Station_Address":"Trường Nguyễn Hữu Cầu, đường Nguyễn Ánh Thủ, Huyện  Hóc Môn"
    ,"Lat":10.86644458770752
    ,"Long":106.61473846435547
    ,"Polyline":"[106.61694336,10.86336803] ; [106.61550903,10.86739349] ; [106.61473846,10.86644459]"
    ,"Distance":"610"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1634"
    ,"Station_Code":"QHMT116"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Nguyễn Trãi"
    ,"Station_Address":"74/4, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.864206314086914
    ,"Long":106.61312103271484
    ,"Polyline":"[106.61473846,10.86644459] ; [106.61476898,10.86630821] ; [106.61401367,10.86528111] ; [106.61325073,10.86421108] ; [106.61312103,10.86420631]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1636"
    ,"Station_Code":"QHMT117"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã tư Nước Đá"
    ,"Station_Address":"127/1, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.860050201416016
    ,"Long":106.61029815673828
    ,"Polyline":"[106.61312103,10.86420631] ; [106.61029816,10.86005020]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1637"
    ,"Station_Code":"QHMT118"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường CĐ GTVT"
    ,"Station_Address":"150A/1, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.857827186584473
    ,"Long":106.60880279541016
    ,"Polyline":"[106.61029816,10.86005020] ; [106.60880280,10.85782719]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1638"
    ,"Station_Code":"QHMT119"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã tư Trung Chánh"
    ,"Station_Address":"155/4, đường Nguyễn Ánh Thủ, Huyện Hóc  Môn"
    ,"Lat":10.85592269897461
    ,"Long":106.60757446289062
    ,"Polyline":"[106.60880280,10.85782719] ; [106.60881805,10.85776806] ; [106.60757446,10.85592270]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3141"
    ,"Station_Code":"HHM 172"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Xuyên Á"
    ,"Station_Address":"23/4, đường Nguyễn Ánh Th ủ, Huyện Hóc Môn"
    ,"Lat":10.854733
    ,"Long":106.606667
    ,"Polyline":"[106.60757446,10.85592270] ; [106.60736084,10.85543442] ; [106.60666656,10.85473347]"
    ,"Distance":"168"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3140"
    ,"Station_Code":"HHM 173"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Nguyễn Thị Sóc"
    ,"Station_Address":"15/5B, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.851709
    ,"Long":106.603957
    ,"Polyline":"[106.60666656,10.85473347] ; [106.60395813,10.85170937]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3145"
    ,"Station_Code":"HHM 174"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Hậu Lân, Bà Điểm"
    ,"Station_Address":"11/6A, đường Nguyễn Ánh Th ủ, Huyện Hóc Môn"
    ,"Lat":10.849033
    ,"Long":106.601784
    ,"Polyline":"[106.60395813,10.85170937] ; [106.60340118,10.85103989] ; [106.60178375,10.84903336]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3142"
    ,"Station_Code":"HHM 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"trường Phan Công Hớn"
    ,"Station_Address":"88/2, đường  Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.846233
    ,"Long":106.60022
    ,"Polyline":"[106.60178375,10.84903336] ; [106.60079193,10.84745789] ; [106.60021973,10.84623337]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3146"
    ,"Station_Code":"HHM 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"Đ/d T. Phan Công Hớn, đường  Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.8411
    ,"Long":106.59922
    ,"Polyline":"[106.60021210,10.84620953] ; [106.60025024,10.84619999] ; [106.60005951,10.84552002] ; [106.59992218,10.84480000] ; [106.59983826,10.84436989] ; [106.59983063,10.84418011] ; [106.59985352,10.84385967] ; [106.59989929,10.84331989] ; [106.59990692,10.84292984] ; [106.59986115,10.84230042] ; [106.59976959,10.84187984] ; [106.59958649,10.84150028] ; [106.59954834,10.84136009] ; [106.59925842,10.84105015]"
    ,"Distance":"611"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2284"
    ,"Station_Code":"HHM 202"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Bà Điểm"
    ,"Station_Address":"17/7, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.839502
    ,"Long":106.59996
    ,"Polyline":"[106.59922028,10.84109974] ; [106.59881592,10.84061909] ; [106.59993744,10.83963871] ; [106.59996033,10.83950233]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3143"
    ,"Station_Code":"HHM 157"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"36/2D, đường Phan Văn Đối , Huyện Hóc Môn"
    ,"Lat":10.83751
    ,"Long":106.59928
    ,"Polyline":"[106.59996033,10.83950233] ; [106.60007477,10.83953381] ; [106.60029602,10.83934879] ; [106.60000610,10.83880138] ; [106.59942627,10.83754253] ; [106.59928131,10.83751011]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3144"
    ,"Station_Code":"HHM 158"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"35 /1B, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.834549
    ,"Long":106.597509
    ,"Polyline":"[106.59928131,10.83751011] ; [106.59873199,10.83645630] ; [106.59807587,10.83537102] ; [106.59751129,10.83454895]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3147"
    ,"Station_Code":"HHM 159"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"26/2M, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.831367
    ,"Long":106.595997
    ,"Polyline":"[106.59751129,10.83454895] ; [106.59677124,10.83286381] ; [106.59600067,10.83136654]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3148"
    ,"Station_Code":"HHM 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"Kế 34/11D, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.829154
    ,"Long":106.594634
    ,"Polyline":"[106.59600067,10.83136654] ; [106.59556580,10.83028126] ; [106.59463501,10.82915401]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3150"
    ,"Station_Code":"QBT 191"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"công ty Cholimex"
    ,"Station_Address":"Đối diện công ty Cholimex, đường Phan Văn Đối, Quận Bình Tân"
    ,"Lat":10.826043
    ,"Long":106.592354
    ,"Polyline":"[106.59463501,10.82915401] ; [106.59424591,10.82837391] ; [106.59315491,10.82697296] ; [106.59235382,10.82604313]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3152"
    ,"Station_Code":"QBT 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Công ty Jonton"
    ,"Station_Address":"Công ty Jonton, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.824625
    ,"Long":106.591202
    ,"Polyline":"[106.59235382,10.82604313] ; [106.59120178,10.82462502]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3154"
    ,"Station_Code":"QBT 189"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"KCN Vĩnh Lộc"
    ,"Station_Address":"Đối diện 330, đường Nguyễn  Cửu Phú, Quận Bình Tân"
    ,"Lat":10.822679
    ,"Long":106.589425
    ,"Polyline":"[106.59120178,10.82462502] ; [106.59083557,10.82409096] ; [106.59037781,10.82359505] ; [106.58942413,10.82267857]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3149"
    ,"Station_Code":"QBT 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Quỳnh Tiên"
    ,"Station_Address":"F9/18B1, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.820919
    ,"Long":106.587616
    ,"Polyline":"[106.58942413,10.82267857] ; [106.58761597,10.82091904]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3151"
    ,"Station_Code":"QBT 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"xã Nhị Bình"
    ,"Station_Address":"F9/6B, đường Phan Văn Đối, Quận Bình Tân"
    ,"Lat":10.818777
    ,"Long":106.585533
    ,"Polyline":"[106.58763123,10.82091045] ; [106.58731842,10.82061005] ; [106.58728790,10.82050037] ; [106.58728790,10.82040024] ; [106.58706665,10.82017994] ; [106.58554077,10.81877041]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2439"
    ,"Station_Code":"HBC 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nguyễn Thị Tú"
    ,"Station_Address":"D7/15, đường Nguyễn Thị Tú, Huyện Bình Chánh"
    ,"Lat":10.813832
    ,"Long":106.580488
    ,"Polyline":"[106.58554077,10.81877041] ; [106.58489227,10.81818008] ; [106.58332825,10.81684971] ; [106.58245850,10.81606007] ; [106.58210754,10.81579018] ; [106.58116913,10.81499958] ; [106.57962036,10.81387997] ; [106.57956696,10.81379032] ; [106.57969666,10.81377029] ; [106.58016205,10.81385994]"
    ,"Distance":"935"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2441"
    ,"Station_Code":"QBT 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Thép Quốc  Thái"
    ,"Station_Address":"507, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.814548
    ,"Long":106.584091
    ,"Polyline":"[106.58016968,10.81377411] ; [106.58396912,10.81461143] ; [106.58409119,10.81454754]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2443"
    ,"Station_Code":"QBT 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Công ty Th ịnh Khang"
    ,"Station_Address":"415-419, đường Nguyễn Thị Tú, Quận Bình T ân"
    ,"Lat":10.81497
    ,"Long":106.586288
    ,"Polyline":"[106.58409119,10.81454754] ; [106.58410645,10.81469631] ; [106.58586884,10.81512833] ; [106.58628082,10.81513309] ; [106.58628845,10.81497002]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2442"
    ,"Station_Code":"QBT 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Cafe Gia Nguyễn"
    ,"Station_Address":"355, đường Nguyễn Thị Tú,  Quận Bình Tân"
    ,"Lat":10.81516
    ,"Long":106.589607
    ,"Polyline":"[106.58630371,10.81517029] ; [106.58895874,10.81525040] ; [106.58959961,10.81529999]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2445"
    ,"Station_Code":"QBT 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Nhà hàng tiệc cưới Thịnh Phước"
    ,"Station_Address":"255B, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815407
    ,"Long":106.592563
    ,"Polyline":"[106.58960724,10.81515980] ; [106.58967590,10.81523323] ; [106.59255981,10.81540680]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2444"
    ,"Station_Code":"QBT 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Công ty B ảo Ngọc Châu"
    ,"Station_Address":"117, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.81555
    ,"Long":106.594913
    ,"Polyline":"[106.59255981,10.81540680] ; [106.59483337,10.81563950] ; [106.59490967,10.81554985]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2447"
    ,"Station_Code":"QBT 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Thị Tú"
    ,"Station_Address":"810-814, đường  Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.815718
    ,"Long":106.602783
    ,"Polyline":"[106.59490967,10.81554985] ; [106.59505463,10.81564426] ; [106.59930420,10.81600285] ; [106.60037994,10.81637192] ; [106.60250092,10.81586552] ; [106.60278320,10.81571770]"
    ,"Distance":"883"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2446"
    ,"Station_Code":"QBT 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Từ bảo Nghi"
    ,"Station_Address":"692, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.814411
    ,"Long":106.60495
    ,"Polyline":"[106.60278320,10.81571770] ; [106.60305786,10.81570244] ; [106.60499573,10.81460667] ; [106.60494995,10.81441116]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2451"
    ,"Station_Code":"QBT 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Đường CN1"
    ,"Station_Address":"642, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.813337
    ,"Long":106.607063
    ,"Polyline":"[106.60494995,10.81441116] ; [106.60503387,10.81454277] ; [106.60552979,10.81426907] ; [106.60571289,10.81422710.06.60706329]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3153"
    ,"Station_Code":"QTP 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Công Ty bánh Givral"
    ,"Station_Address":"541, đường L ê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.811735
    ,"Long":106.609238
    ,"Polyline":"[106.60706329,10.81333733] ; [106.60791779,10.81285191] ; [106.60934448,10.81196117] ; [106.60923767,10.81173515]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3156"
    ,"Station_Code":"QTP 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm Đường CN 13"
    ,"Station_Address":"473, đường L ê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.809837
    ,"Long":106.613106
    ,"Polyline":"[106.60939026,10.81198025] ; [106.61038971,10.81142044] ; [106.61087036,10.81114960] ; [106.61148071,10.81085968] ; [106.61260223,10.81031990] ; [106.61282349,10.81021976] ; [106.61319733,10.81005001]"
    ,"Distance":"526"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3155"
    ,"Station_Code":"QTP 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm Kênh 19/5"
    ,"Station_Address":"443, đường Lê Tr ọng Tấn, Quận Tân Phú"
    ,"Lat":10.808721
    ,"Long":106.615913
    ,"Polyline":"[106.61319733,10.81005001] ; [106.61486816,10.80928040] ; [106.61598206,10.80895996]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2924"
    ,"Station_Code":"QTP 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Tây Thạnh"
    ,"Station_Address":"363 , đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.807646
    ,"Long":106.61982
    ,"Polyline":"[106.61598206,10.80895996] ; [106.61824036,10.80832005] ; [106.61923981,10.80803967] ; [106.61988068,10.80788040]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1974"
    ,"Station_Code":"QTP 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Bờ Bao  Tân Thắng"
    ,"Station_Address":"271, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.80731
    ,"Long":106.622368
    ,"Polyline":"[106.61981964,10.80764580] ; [106.61988068,10.80788040] ; [106.62236786,10.80731010]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1975"
    ,"Station_Code":"QTP 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"Đối diện 220,  đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806767
    ,"Long":106.624886
    ,"Polyline":"[106.62236786,10.80731010.06.62488556]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2604"
    ,"Station_Code":"QTP 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Lê Trọng  Tấn"
    ,"Station_Address":"Kế 16, đường Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.807407
    ,"Long":106.627289
    ,"Polyline":"[106.62488556,10.80676746] ; [106.62741852,10.80622864] ; [106.62728882,10.80740738]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2599"
    ,"Station_Code":"QTP 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"TT vh Tân  Phú"
    ,"Station_Address":"72, đường Dương Đức  Hiền, Quận Tân Phú"
    ,"Lat":10.810604
    ,"Long":106.627022
    ,"Polyline":"[106.62728882,10.80740738] ; [106.62702179,10.81060410]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1979"
    ,"Station_Code":"BX49"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Trạm Điều hành Tân Phú (0,55ha)"
    ,"Station_Address":"Bến xe Tân Phú, đường Trường Chinh, Qu ận Tân Phú"
    ,"Lat":10.808563
    ,"Long":106.634095
    ,"Polyline":"[106.62702179,10.81060410.06.62696838] ; [10.81136608,106.62738037] ; [10.81159210.06.62841797,10.81196690] ; [106.63287354,10.81265163] ; [106.63409424,10.80856323]"
    ,"Distance":"1225"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1979"
    ,"Station_Code":"BX49"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Trạm Điều hành Tân Phú (0,55ha)"
    ,"Station_Address":"Bến xe Tân Phú, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808563
    ,"Long":106.634095
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63409424,10.80856323] ; [106.63414764,10.80856228] ; [106.63426208,10.80820942]"
    ,"Distance":"47"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2292"
    ,"Station_Code":"QTP 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm Nhà Hàng Thượng Uyển"
    ,"Station_Address":"1/1, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.806212
    ,"Long":106.634773
    ,"Polyline":"[106.63426208,10.80820942] ; [106.63486481,10.80639648] ; [106.63477325,10.80621243]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2602"
    ,"Station_Code":"QTP 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường Cao Đẳng Công Nghệ Thực Phẩm"
    ,"Station_Address":"142-144, đường Lê Trọng Tấn, Quận Tân  Phú"
    ,"Lat":10.806065
    ,"Long":106.628586
    ,"Polyline":"[106.63477325,10.80621243] ; [106.63492584,10.80620766] ; [106.63505554,10.80590725] ; [106.63285828,10.80579090] ; [106.63273621,10.80583286] ; [106.63261414,10.80597496] ; [106.63213348,10.80601788] ; [106.63209534,10.80532169] ; [106.63220978,10.80497456] ; [106.63199615,10.80454731] ; [106.63140869,10.80517960] ; [106.63117981,10.80535889] ; [106.63089752,10.80552197] ; [106.63042450,10.80568027] ; [106.62952423,10.80589104] ; [106.62858582,10.80606461]"
    ,"Distance":"975"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2000"
    ,"Station_Code":"QTP 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"188, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806785
    ,"Long":106.625366
    ,"Polyline":"[106.62858582,10.80606461] ; [106.62536621,10.80678463]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2005"
    ,"Station_Code":"QTP 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trạm Bờ Bao Tân Thắng"
    ,"Station_Address":"284, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.807464
    ,"Long":106.622177
    ,"Polyline":"[106.62536621,10.80678463] ; [106.62217712,10.80746365]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2917"
    ,"Station_Code":"QTP 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trạm Tây Thạnh"
    ,"Station_Address":"386, đ ường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.808257
    ,"Long":106.619133
    ,"Polyline":"[106.62217712,10.80746365] ; [106.61913300,10.80825710]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3101"
    ,"Station_Code":"QTP 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Kênh 19 /5"
    ,"Station_Address":"456, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.809163
    ,"Long":106.616302
    ,"Polyline":"[106.61913300,10.80825710.06.61913300] ; [10.80825710.06.61633301,10.80902100] ; [106.61630249,10.80916309] ; [106.61630249,10.80916309]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3100"
    ,"Station_Code":"QTP 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm Đường CN 13"
    ,"Station_Address":"510, đường Lê Tr ọng Tấn, Quận Tân Phú"
    ,"Lat":10.810217
    ,"Long":106.61351
    ,"Polyline":"[106.61624908,10.80897999] ; [106.61493683,10.80935955] ; [106.61396027,10.80982018] ; [106.61344147,10.81007004]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3103"
    ,"Station_Code":"QTP 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công Ty bánh Givral"
    ,"Station_Address":"592, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.812114
    ,"Long":106.609673
    ,"Polyline":"[106.61344147,10.81007004] ; [106.61267853,10.81040955] ; [106.61192322,10.81079006] ; [106.61134338,10.81105995] ; [106.61020660,10.81163979] ; [106.60958862,10.81198978]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2504"
    ,"Station_Code":"QBT 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngoại ngữ tin học Đại Tây Dương"
    ,"Station_Address":"597 (688/11), đường Lê Trọng Tấn, Quận  Bình Tân"
    ,"Lat":10.81341
    ,"Long":106.607353
    ,"Polyline":"[106.60967255,10.81211376] ; [106.60955811,10.81201363] ; [106.60800171,10.81294155] ; [106.60783386,10.81297302] ; [106.60732269,10.81328392] ; [106.60735321,10.81340981]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2505"
    ,"Station_Code":"QBT 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Gò Mây"
    ,"Station_Address":"665, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.814612
    ,"Long":106.605427
    ,"Polyline":"[106.60727692,10.81328964] ; [106.60588074,10.81414032] ; [106.60571289,10.81424999] ; [106.60568237,10.81431007] ; [106.60536194,10.81451988]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2521"
    ,"Station_Code":"QBT 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngân hàng Á Châu"
    ,"Station_Address":"787-745, đường Lê Trọng Tấn, Quận Bình Tân"
    ,"Lat":10.815971
    ,"Long":106.603043
    ,"Polyline":"[106.60532379,10.81453991] ; [106.60404968,10.81529045] ; [106.60323334,10.81577015] ; [106.60299683,10.81587029]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2520"
    ,"Station_Code":"QBT 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Công ty Bảo Châu"
    ,"Station_Address":"88, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815697
    ,"Long":106.594925
    ,"Polyline":"[106.60304260,10.81597137] ; [106.60279083,10.81592846] ; [106.60118866,10.81622410.06.60029602] ; [10.81637192,106.59935760] ; [10.81601334,106.59492493]"
    ,"Distance":"901"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2511"
    ,"Station_Code":"QBT 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà hàng Thịnh Phước"
    ,"Station_Address":"Đối diện 255B, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815518
    ,"Long":106.592453
    ,"Polyline":"[106.59492493,10.81569672] ; [106.59245300,10.81551838]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2518"
    ,"Station_Code":"QBT 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Công ty Gia Nguyễn"
    ,"Station_Address":"210, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815318
    ,"Long":106.589088
    ,"Polyline":"[106.59245300,10.81551838] ; [106.59078979,10.81537056] ; [106.58908844,10.81531811]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2513"
    ,"Station_Code":"QBT 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Công ty Thịnh Khang"
    ,"Station_Address":"264 , đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.815228
    ,"Long":106.586555
    ,"Polyline":"[106.58908844,10.81531811] ; [106.58655548,10.81522846]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2516"
    ,"Station_Code":"QBT 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Thép Quốc  Thái"
    ,"Station_Address":"D1/1B, đường Nguyễn Thị Tú, Quận Bình Tân"
    ,"Lat":10.814812
    ,"Long":106.58387
    ,"Polyline":"[106.58655548,10.81522846] ; [106.58589172,10.81515980] ; [106.58391571,10.81470680] ; [106.58386993,10.81481171]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2517"
    ,"Station_Code":"HBC 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 5 Vĩnh Lộc"
    ,"Station_Address":"1, đường Nguyễn Thị Tú, Huyện Bình Chánh"
    ,"Lat":10.8139
    ,"Long":106.580215
    ,"Polyline":"[106.58386993,10.81481171] ; [106.58385468,10.81468582] ; [106.57985687,10.81381607]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3102"
    ,"Station_Code":"QBT 182"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trạm giữa Vĩnh Lộc"
    ,"Station_Address":"Đối diện F9/6 (Châu Phú Mỹ),  đường Phan Văn Đối, Quận Bình Tân"
    ,"Lat":10.818697
    ,"Long":106.58548
    ,"Polyline":"[106.57985687,10.81381607] ; [106.57945251,10.81370544] ; [106.58229828,10.81592846] ; [106.58547974,10.81869698]"
    ,"Distance":"908"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3105"
    ,"Station_Code":"QBT 183"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường li ên ấp 5-6"
    ,"Station_Address":"288, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.820539
    ,"Long":106.587676
    ,"Polyline":"[106.58547974,10.81869698] ; [106.58731079,10.82039165] ; [106.58750916,10.82042885] ; [106.58767700,10.82053947]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3104"
    ,"Station_Code":"QBT 184"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Chốt 2 KCN Vĩnh Lộc"
    ,"Station_Address":"330, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.822362
    ,"Long":106.58957
    ,"Polyline":"[106.58767700,10.82053947] ; [106.58956909,10.82236195]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3107"
    ,"Station_Code":"QBT 185"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Kho vật tư thiết bị"
    ,"Station_Address":"Kho  vật tư thiết bị, đường Nguyễn Cửu Phú, Quận Bình Tân"
    ,"Lat":10.824402
    ,"Long":106.591393
    ,"Polyline":"[106.58956909,10.82236195] ; [106.59139252,10.82440186]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3106"
    ,"Station_Code":"QBT 186"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Công ty Cholimex"
    ,"Station_Address":"Công  ty Cholimex, đường Phan Văn Đối, Quận Bình Tân"
    ,"Lat":10.826073
    ,"Long":106.59269
    ,"Polyline":"[106.59139252,10.82440186] ; [106.59268951,10.82607269]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3109"
    ,"Station_Code":"HHM 153"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Cây xăng  Quang Trung"
    ,"Station_Address":"43/11C, đư ờng Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.828746
    ,"Long":106.59462
    ,"Polyline":"[106.59268951,10.82607269] ; [106.59461975,10.82874584]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3108"
    ,"Station_Code":"HHM 154"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"43/1, đường Phan Văn Đối, Huyện Hóc M ôn"
    ,"Lat":10.831306
    ,"Long":106.596176
    ,"Polyline":"[106.59461975,10.82874584] ; [106.59617615,10.83130646]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3110"
    ,"Station_Code":"HHM 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"31/3C, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.834866
    ,"Long":106.598015
    ,"Polyline":"[106.59617615,10.83130646] ; [106.59671021,10.83262634] ; [106.59684753,10.83302116] ; [106.59789276,10.83489704] ; [106.59801483,10.83486557]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3111"
    ,"Station_Code":"HHM 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Hóc Môn"
    ,"Station_Address":"42/1B, đường Phan Văn Đối, Huyện Hóc Môn"
    ,"Lat":10.837942
    ,"Long":106.599861
    ,"Polyline":"[106.59801483,10.83486557] ; [106.59818268,10.83541393] ; [106.59947968,10.83758450] ; [106.59986115,10.83794212]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2211"
    ,"Station_Code":"HHM 179"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Bà Điểm"
    ,"Station_Address":"Chợ Bà Điểm, đường Phan Văn Hớn, Huyện  Hóc Môn"
    ,"Lat":10.839987
    ,"Long":106.599693
    ,"Polyline":"[106.59986115,10.83794212] ; [106.59967041,10.83800602] ; [106.60033417,10.83938122] ; [106.59969330,10.83998680]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3113"
    ,"Station_Code":"HHM 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã 3 Nguyễn Thị Sóc - Nguyễn Ảnh  Thủ"
    ,"Station_Address":"19/1B , đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.840803
    ,"Long":106.599119
    ,"Polyline":"[106.59969330,10.83998680] ; [106.59881592,10.84061337] ; [106.59912109,10.84080315]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3112"
    ,"Station_Code":"HHM 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Công ty tr à Tân Lam"
    ,"Station_Address":"60/8A (Đối diện 135), đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.846567
    ,"Long":106.600464
    ,"Polyline":"[106.59912109,10.84080315] ; [106.59951782,10.84130383] ; [106.59979248,10.84187317] ; [106.59992218,10.84292698] ; [106.59984589,10.84431744] ; [106.60009766,10.84545517] ; [106.60029602,10.84620380] ; [106.60046387,10.84656715]"
    ,"Distance":"674"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3115"
    ,"Station_Code":"HHM 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cây xăng Hưng Lân"
    ,"Station_Address":"13/5 , đường Nguy ễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.849428
    ,"Long":106.602294
    ,"Polyline":"[106.60046387,10.84656715] ; [106.60052490,10.84687805] ; [106.60211945,10.84931183] ; [106.60229492,10.84942818]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3114"
    ,"Station_Code":"HHM 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Khúc Giao Mùa"
    ,"Station_Address":"32/4 , đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.852083
    ,"Long":106.604569
    ,"Polyline":"[106.60229492,10.84942818] ; [106.60240173,10.84973335] ; [106.60338593,10.85096645] ; [106.60443878,10.85206223] ; [106.60456848,10.85208321]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"3117"
    ,"Station_Code":"HHM 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã tư Trung Chánh"
    ,"Station_Address":"26/7C (27/11B), đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.854383
    ,"Long":106.606552
    ,"Polyline":"[106.60456848,10.85208321] ; [106.60655212,10.85438347]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1690"
    ,"Station_Code":"Q12 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Trung tâm Văn hóa quận 12"
    ,"Station_Address":"Hông Trung tâm văn hóa Quận 12, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.855634
    ,"Long":106.607578
    ,"Polyline":"[106.60655212,10.85438347] ; [106.60757446,10.85563374]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1691"
    ,"Station_Code":"Q12 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường Cao đẳng Giao thông vận tải"
    ,"Station_Address":"8, đường Nguyễn Ảnh Thủ, Qu ận 12"
    ,"Lat":10.857552
    ,"Long":106.608839
    ,"Polyline":"[106.60757446,10.85563374] ; [106.60818481,10.85666180] ; [106.60884094,10.85755157]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1692"
    ,"Station_Code":"Q12 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà thờ Trung Chánh"
    ,"Station_Address":"349, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.859981
    ,"Long":106.610422
    ,"Polyline":"[106.60884094,10.85755157] ; [106.61042023,10.85998058]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1693"
    ,"Station_Code":"Q12 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Chợ Vạn Hạnh"
    ,"Station_Address":"7, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.862873
    ,"Long":106.612412
    ,"Polyline":"[106.61042023,10.85998058] ; [106.61241150,10.86287308]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1694"
    ,"Station_Code":"Q12 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà sách Nguyễn Hữu Cầu"
    ,"Station_Address":"1C, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.865112
    ,"Long":106.614016
    ,"Polyline":"[106.61241150,10.86287308] ; [106.61401367,10.86511230]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2062"
    ,"Station_Code":"Q12 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường ĐH  GTVT TPHCM"
    ,"Station_Address":"Đối diện 12/8, đường Tô Ký, Quận 12"
    ,"Lat":10.866608
    ,"Long":106.615684
    ,"Polyline":"[106.61401367,10.86511230] ; [106.61549377,10.86730862] ; [106.61568451,10.86660767]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2085"
    ,"Station_Code":"Q12 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Doanh trại Quân Đội"
    ,"Station_Address":"583, đường Tô Ký, Quận 12"
    ,"Lat":10.862852
    ,"Long":106.616821
    ,"Polyline":"[106.61568451,10.86660767] ; [106.61634827,10.86484337] ; [106.61682129,10.86285210]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2086"
    ,"Station_Code":"Q12 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ Tân Chánh Hiệp"
    ,"Station_Address":"Trung tâm thể dục thể thao Q.12, đường Tô Ký, Quận 12"
    ,"Lat":10.859354
    ,"Long":106.617696
    ,"Polyline":"[106.61682129,10.86285210.06.61705780] ; [10.86245155,106.61769867]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2087"
    ,"Station_Code":"Q12 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Chiếc nón Kỳ Diệu"
    ,"Station_Address":"535, đường Tô Ký, Quận 12"
    ,"Lat":10.857837
    ,"Long":106.619026
    ,"Polyline":"[106.61769867,10.85935402] ; [106.61786652,10.85888481] ; [106.61902618,10.85783672]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"2088"
    ,"Station_Code":"Q12 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"điện lực Hóc Môn"
    ,"Station_Address":"Đối diện điện lực Hóc Môn, đường  Tô Ký, Quận 12"
    ,"Lat":10.856309
    ,"Long":106.621429
    ,"Polyline":"[106.61902618,10.85783672] ; [106.61911011,10.85783100] ; [106.61971283,10.85738850] ; [106.62075806,10.85671425] ; [106.62142944,10.85630894]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"69"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":"[106.62143707,10.85634518] ; [106.62143707,10.85634995] ; [106.62286377,10.85571957] ; [106.62348938,10.85544014] ; [106.62370300,10.85568047] ; [106.62390137,10.85601044] ; [106.62399292,10.85610962] ; [106.62480927,10.85723972] ; [106.62496185,10.85739040] ; [106.62519836,10.85743999] ; [106.62712097,10.85756969] ; [106.62853241,10.85770035] ; [106.62933350,10.85779953] ; [106.62937164,10.85813999] ; [106.62940979,10.85828972] ; [106.62950134,10.85842991] ; [106.62980652,10.85881996] ; [106.63126373,10.86042023] ; [106.63188934,10.86114025] ; [106.63240051,10.86194611] ; [106.63304138,10.86304188] ; [106.63341522,10.86357403] ; [106.63379669,10.86417484] ; [106.63416290,10.86480141] ; [106.63446808,10.86538124] ; [106.63464355,10.86563873] ; [106.63475800,10.86593914] ; [106.63506317,10.86663437] ; [106.63556671,10.86771965] ; [106.63621521,10.86896324] ; [106.63681793,10.87037468] ; [106.63800812,10.87226105] ; [106.63929749,10.87418938] ; [106.64048004,10.87602234] ; [106.64102173,10.87691784] ; [106.64125061,10.87717056] ; [106.64174652,10.87704468] ; [106.64196014,10.87713909] ; [106.64203644,10.87744999]"
    ,"Distance":"3655"
  }]