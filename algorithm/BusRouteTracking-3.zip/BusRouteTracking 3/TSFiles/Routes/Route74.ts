export const Route74 =[
  {
     "Route_Id":"74"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận  5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27, đường Tháp Mười, Quận 6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65203857,10.75116444] ; [106.65194702,10.75102234] ; [106.65099335,10.75097466] ; [106.65003967,10.75107002] ; [106.64955139,10.75079060] ; [106.64944458,10.74973106.06.65254211] ; [10.75026989,106.65255737]"
    ,"Distance":"816"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2393"
    ,"Station_Code":"Q6 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Tháp Mười"
    ,"Station_Address":"13C-13D, đường Tháp Mười, Quận 6"
    ,"Lat":10.750326
    ,"Long":106.653036
    ,"Polyline":"[106.65255737,10.75023174] ; [106.65255737,10.75023174] ; [106.65280151,10.75029469] ; [106.65303802,10.75032616] ; [106.65303802,10.75032616]"
    ,"Distance":"54"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3165"
    ,"Station_Code":"Q5 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Nhà thờ Cha Tam"
    ,"Station_Address":"Đối diện 946, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.752719
    ,"Long":106.653975
    ,"Polyline":"[106.65303040,10.75035954] ; [106.65338898,10.75043011] ; [106.65335846,10.75067997] ; [106.65332794,10.75109005] ; [106.65329742,10.75150013] ; [106.65325928,10.75164032] ; [106.65334320,10.75209045] ; [106.65357208,10.75275040] ; [106.65397644,10.75275993]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3167"
    ,"Station_Code":"Q5 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Châu Văn  Liêm"
    ,"Station_Address":"813, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.752883
    ,"Long":106.658111
    ,"Polyline":"[106.65397644,10.75275993] ; [106.65527344,10.75282955] ; [106.65615845,10.75288010.06.65744019] ; [10.75290966,106.65809631]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"4"
    ,"Station_Code":"Q5 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Lương Nhữ Học"
    ,"Station_Address":"727, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.752962
    ,"Long":106.660418
    ,"Polyline":"[106.65809631,10.75294018] ; [106.65940094,10.75300026]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"7"
    ,"Station_Code":"Q5 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Triệu Quang  Phục"
    ,"Station_Address":"695, đường Nguyễn Trãi, Qu ận 5"
    ,"Lat":10.753088
    ,"Long":106.662081
    ,"Polyline":"[106.66041565,10.75296211] ; [106.66069794,10.75304985] ; [106.66143036,10.75304985] ; [106.66168976,10.75308037] ; [106.66204834,10.75314999] ; [106.66207886,10.75308800]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"9"
    ,"Station_Code":"Q5 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Đại học Sư phạm Thể dục thể thao"
    ,"Station_Address":"639, đường Nguy ễn Trãi, Quận 5"
    ,"Lat":10.753341
    ,"Long":106.663486
    ,"Polyline":"[106.66204834,10.75314999] ; [106.66282654,10.75329971] ; [106.66348267,10.75339985]"
    ,"Distance":"174"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"12"
    ,"Station_Code":"Q5 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Siêu thị Điện máy Chợ Lớn"
    ,"Station_Address":"635B, đường  Nguyễn Trãi, Quận 5"
    ,"Lat":10.753626
    ,"Long":106.664913
    ,"Polyline":"[106.66348267,10.75339985] ; [106.66414642,10.75352001] ; [106.66490173,10.75368977]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"6"
    ,"Station_Code":"Q5 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngô Quyền"
    ,"Station_Address":"593 , đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.754
    ,"Long":106.666882
    ,"Polyline":"[106.66490173,10.75368977] ; [106.66555786,10.75382996] ; [106.66658020,10.75399971] ; [106.66687012,10.75405979]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"10"
    ,"Station_Code":"Q5 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chung cư Nguyễn Trãi"
    ,"Station_Address":"549, đường Nguyễn Trãi, Quận 5"
    ,"Lat":10.754337
    ,"Long":106.668572
    ,"Polyline":"[106.66687012,10.75405979] ; [106.66854858,10.75440025]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3166"
    ,"Station_Code":"Q5 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"493, đường Nguyễn Trãi, Quận  5"
    ,"Lat":10.754638
    ,"Long":106.670149
    ,"Polyline":"[106.66854858,10.75440025] ; [106.66951752,10.75456047] ; [106.67012787,10.75469017]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3169"
    ,"Station_Code":"Q5 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cây Xăng dầu"
    ,"Station_Address":"309 , đường Trần Phú, Quận 5"
    ,"Lat":10.755939
    ,"Long":106.672837
    ,"Polyline":"[106.67012787,10.75469017] ; [106.67189026,10.75504017] ; [106.67234039,10.75549984] ; [106.67279053,10.75597954]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3170"
    ,"Station_Code":"Q5 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"An Đông"
    ,"Station_Address":"251B, đường Trần Phú, Quận 5"
    ,"Lat":10.758427
    ,"Long":106.675186
    ,"Polyline":"[106.67279053,10.75597954] ; [106.67394257,10.75720024] ; [106.67417145,10.75753021] ; [106.67446899,10.75771999] ; [106.67476654,10.75802994] ; [106.67523193,10.75850964]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3172"
    ,"Station_Code":"Q5 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Thanh tra Sở Giao thông Vận tải"
    ,"Station_Address":"286, đường Lê Hồng Phong, Quận 5"
    ,"Lat":10.761678
    ,"Long":106.676742
    ,"Polyline":"[106.67523193,10.75850964] ; [106.67636108,10.75975037] ; [106.67701721,10.76047039] ; [106.67700958,10.76068974] ; [106.67665863,10.76169968]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"386"
    ,"Station_Code":"Q10 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Lê  Hồng Phong"
    ,"Station_Address":"400, đường L ê Hồng Phong, Quận 10"
    ,"Lat":10.764429
    ,"Long":106.67569
    ,"Polyline":"[106.67674255,10.76167774] ; [106.67575073,10.76413155]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3171"
    ,"Station_Code":"Q10 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 7 Lý Thái Tổ"
    ,"Station_Address":"516, đường Lê Hồng Phong, Quận 10"
    ,"Lat":10.766764
    ,"Long":106.674827
    ,"Polyline":"[106.67571259,10.76412010.06.67497253]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1909"
    ,"Station_Code":"Q3 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã 7 Lý Thái Tổ"
    ,"Station_Address":"647, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.768703
    ,"Long":106.675224
    ,"Polyline":"[106.67497253,10.76607037] ; [106.67446899,10.76745987] ; [106.67447662,10.76747036] ; [106.67450714,10.76747990] ; [106.67455292,10.76751041] ; [106.67460632,10.76758957] ; [106.67462158,10.76770020] ; [106.67459106,10.76778984] ; [106.67455292,10.76784039] ; [106.67453003,10.76784992] ; [106.67450714,10.76786041] ; [106.67500305,10.76848984] ; [106.67526245,10.76883984]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"92"
    ,"Station_Code":"Q3 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cao Thắng"
    ,"Station_Address":"503, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.771249
    ,"Long":106.677505
    ,"Polyline":"[106.67526245,10.76883984] ; [106.67579651,10.76959038] ; [106.67671967,10.77056980] ; [106.67742920,10.77132034]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1911"
    ,"Station_Code":"Q3 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cư Xá Đô Thành"
    ,"Station_Address":"399, đường Đi ện Biên Phủ, Quận 3"
    ,"Lat":10.773248
    ,"Long":106.67981
    ,"Polyline":"[106.67742920,10.77132034] ; [106.67758179,10.77147007] ; [106.67807770,10.77190018] ; [106.67839813,10.77215958] ; [106.67903900,10.77270985] ; [106.67974091,10.77332020]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1912"
    ,"Station_Code":"Q3 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Bệnh viện Bình Dân"
    ,"Station_Address":"371, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.774641
    ,"Long":106.68145
    ,"Polyline":"[106.67974091,10.77332020] ; [106.68138885,10.77470970]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"731"
    ,"Station_Code":"Q3 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cách Mạng tháng 8"
    ,"Station_Address":"303, đường Đi ện Biên Phủ, Quận 3"
    ,"Lat":10.777009
    ,"Long":106.684145
    ,"Polyline":"[106.68138885,10.77470970] ; [106.68270111,10.77581978] ; [106.68357849,10.77657986] ; [106.68399048,10.77696037]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1913"
    ,"Station_Code":"Q3 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh viện Mắt"
    ,"Station_Address":"291, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.778255
    ,"Long":106.685471
    ,"Polyline":"[106.68414307,10.77700901] ; [106.68431854,10.77726173] ; [106.68491364,10.77779388] ; [106.68547058,10.77825546] ; [106.68547058,10.77825546]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1917"
    ,"Station_Code":"Q3 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Sở Khoa học và Công nghệ"
    ,"Station_Address":"273, đường Điện Biên Phủ,  Quận 3"
    ,"Lat":10.780286
    ,"Long":106.687621
    ,"Polyline":"[106.68547058,10.77825546] ; [106.68608856,10.77890587] ; [106.68683624,10.77962208] ; [106.68757629,10.78028488]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1914"
    ,"Station_Code":"Q3 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Marie Curie"
    ,"Station_Address":"Đối diện số 206 (247), đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.782872
    ,"Long":106.690369
    ,"Polyline":"[106.68757629,10.78028488] ; [106.68894196,10.78161430] ; [106.69029999,10.78293991] ; [106.69036865,10.78287220]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1920"
    ,"Station_Code":"Q3 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Phạm Ngọc Thạch"
    ,"Station_Address":"209, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.784965
    ,"Long":106.692375
    ,"Polyline":"[106.69036865,10.78287220] ; [106.69075012,10.78342152] ; [106.69158173,10.78423882] ; [106.69237518,10.78496456]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1915"
    ,"Station_Code":"Q1 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Công Viên Lê Văn Tám"
    ,"Station_Address":"179 - 181, đường Điện Biên Phủ, Quận 1"
    ,"Lat":10.786934
    ,"Long":106.694313
    ,"Polyline":"[106.69237518,10.78496456] ; [106.69329834,10.78595638] ; [106.69431305,10.78693390]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1924"
    ,"Station_Code":"Q1 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đinh Tiên Hoàng"
    ,"Station_Address":"87, đường Điện Bi ên Phủ, Quận 1"
    ,"Lat":10.789477
    ,"Long":106.696783
    ,"Polyline":"[106.69431305,10.78693390] ; [106.69530487,10.78809643] ; [106.69609833,10.78888702] ; [106.69678497,10.78947735]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2033"
    ,"Station_Code":"QBTH 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"96, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.796032
    ,"Long":106.696225
    ,"Polyline":"[106.69682312,10.78964043] ; [106.69754028,10.79038048] ; [106.69725037,10.79063129] ; [106.69675446,10.79109192] ; [106.69588470,10.79181671] ; [106.69612885,10.79576015]"
    ,"Distance":"846"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2727"
    ,"Station_Code":"QBTH 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"114, đường Đinh Ti ên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.798066
    ,"Long":106.696376
    ,"Polyline":"[106.69622803,10.79603195] ; [106.69628143,10.79808998] ; [106.69637299,10.79806614]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2109"
    ,"Station_Code":"QBTH 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"Đối diện 129, đường Đinh Tiên Hoàng,  Quận Bình Thạnh"
    ,"Lat":10.80147
    ,"Long":106.696569
    ,"Polyline":"[106.69637299,10.79806614] ; [106.69657135,10.80146980]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"UBND Quận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69657135,10.80146980] ; [106.69657898,10.80259800] ; [106.69630432,10.80272388] ; [106.69578552,10.80281925]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2039"
    ,"Station_Code":"QBTH 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"2, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803488
    ,"Long":106.695013
    ,"Polyline":"[106.69573212,10.80272007] ; [106.69492340,10.80282021] ; [106.69492340,10.80292034] ; [106.69493866,10.80342960]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3173"
    ,"Station_Code":"QBTH 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã Ba Nơ Trang Long"
    ,"Station_Address":"Đối diện 40, đường Nguyễn Huy Lượng, Qu ận Bình Thạnh"
    ,"Lat":10.80547
    ,"Long":106.695834
    ,"Polyline":"[106.69493866,10.80348015] ; [106.69499969,10.80537033] ; [106.69583893,10.80554008]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1771"
    ,"Station_Code":"QBTH 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trường TH Nguyễn Đình Chiểu"
    ,"Station_Address":"1A, đường Lê Quang Định, Qu ận Bình Thạnh"
    ,"Lat":10.803278
    ,"Long":106.698366
    ,"Polyline":"[106.69583893,10.80554008] ; [106.69738007,10.80587959] ; [106.69776154,10.80541039] ; [106.69795227,10.80506039] ; [106.69808197,10.80467987] ; [106.69843292,10.80307961]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"473C, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69836426,10.80327797] ; [106.69849396,10.80280876] ; [106.69856262,10.80256653] ; [106.69955444,10.80296135]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Tòa Án  nhân dân Quận Bình Thạnh"
    ,"Station_Address":"449 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69955444,10.80296135] ; [106.69955444,10.80296135] ; [106.70026398,10.80331421] ; [106.70071411,10.80349922] ; [106.70117950,10.80362511] ; [106.70117950,10.80362511]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa B ồ Đề"
    ,"Station_Address":"375, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70117950,10.80362511] ; [106.70153809,10.80381489] ; [106.70172882,10.80383968] ; [106.70278168,10.80356026] ; [106.70324707,10.80346012] ; [106.70365143,10.80342007] ; [106.70372009,10.80341434] ; [106.70398712,10.80329323]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70398712,10.80329323] ; [106.70473480,10.80331421] ; [106.70602417,10.80322456] ; [106.70671082,10.80307674]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70670319,10.80317020] ; [106.70815277,10.80307007] ; [106.70899200,10.80300045] ; [106.70997620,10.80294991] ; [106.71053314,10.80290031]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71053314,10.80290031] ; [106.71114349,10.80286026] ; [106.71138763,10.80284023] ; [106.71141815,10.80298042] ; [106.71143341,10.80377960] ; [106.71145630,10.80453014] ; [106.71147919,10.80471039]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Đài Li ệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71166229,10.80680275] ; [106.71163177,10.80777264] ; [106.71178436,10.80830956] ; [106.71196747,10.80883121]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71215820,10.80955029] ; [106.71228790,10.81021976] ; [106.71240997,10.81079102]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"522"
    ,"Station_Code":"QBTH 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"100-102, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.811666
    ,"Long":106.712532
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71244049,10.81123924] ; [106.71253204,10.81166553]"
    ,"Distance":"99"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71253204,10.81166553] ; [106.71253204,10.81200314] ; [106.71260834,10.81231976]"
    ,"Distance":"74"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71260834,10.81231976] ; [106.71262360,10.81297302] ; [106.71267700,10.81343651] ; [106.71279144,10.81385326]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78 /3, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71293640,10.81564045] ; [106.71305084,10.81651974] ; [106.71318054,10.81737041] ; [106.71308136,10.81737995] ; [106.71288300,10.81739044] ; [106.71269989,10.81735992] ; [106.71225739,10.81723976] ; [106.71196747,10.81715012] ; [106.71172333,10.81700039] ; [106.71150208,10.81682014] ; [106.71125793,10.81666088]"
    ,"Distance":"625"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Bến xe Mi ền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71128845,10.81663990] ; [106.71118927,10.81653786] ; [106.71108246,10.81636906] ; [106.71044159,10.81512260] ; [106.70987701,10.81399250] ; [106.71009064,10.81390858] ; [106.71020508,10.81397915] ; [106.71073914,10.81503010]"
    ,"Distance":"577"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông , đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã Tư  Nguyễn Xí"
    ,"Station_Address":"291-293, đường  Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71129608,10.81473255] ; [106.71073914,10.81513882] ; [106.71109772,10.81586552] ; [106.71094513,10.81610775] ; [106.70978546,10.81393719] ; [106.70922089,10.81262493]"
    ,"Distance":"628"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70925140,10.81260014] ; [106.70919037,10.81247044] ; [106.70913696,10.81227016] ; [106.70912933,10.81159019] ; [106.70913696,10.81058025] ; [106.70919037,10.80980968]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85 , đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70919037,10.80980968] ; [106.70926666,10.80805969] ; [106.70937347,10.80710983] ; [106.70938873,10.80690956]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm x ăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70938873,10.80690956] ; [106.70948792,10.80566978] ; [106.70947266,10.80506039] ; [106.70944214,10.80442047]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường Bạch Đằng, Quận Bình  Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.70944214,10.80442047] ; [106.70935059,10.80296993] ; [106.70806885,10.80307007] ; [106.70797729,10.80307961]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70797729,10.80307961] ; [106.70393372,10.80338955]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"288, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70393372,10.80338955] ; [106.70324707,10.80346012] ; [106.70278168,10.80356026] ; [106.70172882,10.80383968] ; [106.70149231,10.80385017] ; [106.70104980,10.80370045]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"368, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70104980,10.80370045] ; [106.69934845,10.80301952]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"1648"
    ,"Station_Code":"QBTH 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường TH Nguyễn Đình Chiểu"
    ,"Station_Address":"22-24, đường Lê Quang Định , Quận Bình Thạnh"
    ,"Lat":10.803241
    ,"Long":106.698462
    ,"Polyline":"[106.69934845,10.80301952] ; [106.69903564,10.80289268] ; [106.69860077,10.80267906] ; [106.69849396,10.80284309] ; [106.69841003,10.80317974]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3174"
    ,"Station_Code":"QBTH 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã Ba Lê Quang Định"
    ,"Station_Address":"19, đường Nguy ễn Huy Lượng, Quận Bình Thạnh"
    ,"Lat":10.805823
    ,"Long":106.69695
    ,"Polyline":"[106.69841003,10.80317974] ; [106.69802856,10.80484962] ; [106.69786072,10.80523014] ; [106.69776154,10.80541039] ; [106.69740295,10.80585003] ; [106.69738007,10.80587959] ; [106.69696808,10.80578041]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2110"
    ,"Station_Code":"QBTH 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"1, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803583
    ,"Long":106.694906
    ,"Polyline":"[106.69696808,10.80578041] ; [106.69499969,10.80537033] ; [106.69496918,10.80436993] ; [106.69493866,10.80356026]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2037"
    ,"Station_Code":"QBTH 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"129, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.801391
    ,"Long":106.696456
    ,"Polyline":"[106.69490814,10.80358315] ; [106.69490051,10.80276108] ; [106.69655609,10.80254459] ; [106.69645691,10.80139065]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2034"
    ,"Station_Code":"QBTH 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"95, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.798625
    ,"Long":106.696279
    ,"Polyline":"[106.69645691,10.80139065] ; [106.69628143,10.79862499]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2112"
    ,"Station_Code":"QBTH 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"51, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.79423
    ,"Long":106.695968
    ,"Polyline":"[106.69631195,10.79862022] ; [106.69606018,10.79461956]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"726"
    ,"Station_Code":"Q1 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đền Trần Hưng Đạo"
    ,"Station_Address":"18, đường Võ Thị Sáu, Quận 1"
    ,"Lat":10.791369
    ,"Long":106.695238
    ,"Polyline":"[106.69596863,10.79423046] ; [106.69601440,10.79412460] ; [106.69597626,10.79330730] ; [106.69592285,10.79263306] ; [106.69588470,10.79181099] ; [106.69528961,10.79125023] ; [106.69523621,10.79136944]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2111"
    ,"Station_Code":"Q1 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Công viên Lê Văn Tám"
    ,"Station_Address":"78, đường Võ Thị Sáu, Quận 1"
    ,"Lat":10.788896
    ,"Long":106.692818
    ,"Polyline":"[106.69525146,10.79128838] ; [106.69426727,10.79024982] ; [106.69281769,10.78889561]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3176"
    ,"Station_Code":"Q3 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Phạm Ngọc Thạch"
    ,"Station_Address":"158A - 156B, đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.786916
    ,"Long":106.690918
    ,"Polyline":"[106.69281769,10.78889561] ; [106.69193268,10.78787994] ; [106.69122314,10.78713036] ; [106.69091797,10.78691578]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"246"
    ,"Station_Code":"Q3 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Viện Pasteur"
    ,"Station_Address":"Đối diện 153 A-B, đường Võ Thị Sáu, Qu ận 3"
    ,"Lat":10.785583
    ,"Long":106.689613
    ,"Polyline":"[106.69091797,10.78691578] ; [106.69052124,10.78641987] ; [106.68997192,10.78584003] ; [106.68961334,10.78558254]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2491"
    ,"Station_Code":"Q3 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Bảo tàng Phụ Nữ"
    ,"Station_Address":"200, đường Võ Thị Sáu, Qu ận 3"
    ,"Lat":10.783535
    ,"Long":106.687561
    ,"Polyline":"[106.68961334,10.78558254] ; [106.68860626,10.78451252] ; [106.68756104,10.78353500]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"727"
    ,"Station_Code":"Q3 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trần Quốc Thảo"
    ,"Station_Address":"232 Võ Thị Sáu, đường Võ Th ị Sáu, Quận 3"
    ,"Lat":10.782294
    ,"Long":106.686242
    ,"Polyline":"[106.68756104,10.78353500] ; [106.68702698,10.78297901] ; [106.68641663,10.78237629]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"2708"
    ,"Station_Code":"Q3 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Dân Chủ"
    ,"Station_Address":"274 , đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.778625
    ,"Long":106.682671
    ,"Polyline":"[106.68641663,10.78237629] ; [106.68532562,10.78124523] ; [106.68311310,10.77893734] ; [106.68267059,10.77862453]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"568"
    ,"Station_Code":"Q10 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Maximark"
    ,"Station_Address":"54, đường Đường 3/2, Quận  10"
    ,"Lat":10.777162
    ,"Long":106.680771
    ,"Polyline":"[106.68267059,10.77862453] ; [106.68208313,10.77789974] ; [106.68195343,10.77785015] ; [106.68192291,10.77793980] ; [106.68189240,10.77799988] ; [106.68182373,10.77805996] ; [106.68167877,10.77810955] ; [106.68157196,10.77810001] ; [106.68142700,10.77799988] ; [106.68138885,10.77793026] ; [106.68137360,10.77785015] ; [106.68137360,10.77777958] ; [106.68138885,10.77772999] ; [106.68122101,10.77762032] ; [106.68061066,10.77689838]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"563"
    ,"Station_Code":"Q10 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"BV Bình Dân"
    ,"Station_Address":"172 , đường Đường 3/2, Quận 10"
    ,"Lat":10.774785
    ,"Long":106.678947
    ,"Polyline":"[106.68061066,10.77689838] ; [106.68009186,10.77585983] ; [106.67961884,10.77528000] ; [106.67905426,10.77485275]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"95"
    ,"Station_Code":"Q10 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Học viện hành chính quốc gia"
    ,"Station_Address":"10, đường Đường 3/2, Quận 10"
    ,"Lat":10.773457
    ,"Long":106.676951
    ,"Polyline":"[106.67905426,10.77485275] ; [106.67809296,10.77413654] ; [106.67765045,10.77383137] ; [106.67718506,10.77356243] ; [106.67671967,10.77335644]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"94"
    ,"Station_Code":"Q10 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Học viện hành chính quốc gia"
    ,"Station_Address":"Kế 10A, đường Đường 3/2, Qu ận 10"
    ,"Lat":10.772661
    ,"Long":106.675701
    ,"Polyline":"[106.67671967,10.77335644] ; [106.67645264,10.77304554] ; [106.67604065,10.77283478] ; [106.67572021,10.77264309]"
    ,"Distance":"137"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"97"
    ,"Station_Code":"Q10 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà hát Hòa Bình"
    ,"Station_Address":"240, đường Đường 3/2, Quận  10"
    ,"Lat":10.771712
    ,"Long":106.674202
    ,"Polyline":"[106.67572021,10.77264309] ; [106.67498016,10.77216530] ; [106.67420197,10.77171230]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3177"
    ,"Station_Code":"Q10 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Công An Phường 10, Quận 10"
    ,"Station_Address":"661, đường Lê Hồng Phong, Quận 10"
    ,"Lat":10.770045
    ,"Long":106.673393
    ,"Polyline":"[106.67424774,10.77165031] ; [106.67301178,10.77089977] ; [106.67320251,10.77073956] ; [106.67339325,10.77023983] ; [106.67346191,10.77007008]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3179"
    ,"Station_Code":"Q10 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã 7 Lý Thái Tổ"
    ,"Station_Address":"553-555, đường Lê Hồng Phong, Quận 10"
    ,"Lat":10.768566
    ,"Long":106.673995
    ,"Polyline":"[106.67346191,10.77007008] ; [106.67401123,10.76863956]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3178"
    ,"Station_Code":"Q10 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã 7 Lý Thái Tổ"
    ,"Station_Address":"505, đường Lê Hồng Phong, Quận 10"
    ,"Lat":10.766851
    ,"Long":106.674652
    ,"Polyline":"[106.67401123,10.76863956] ; [106.67430115,10.76788044] ; [106.67426300,10.76784992] ; [106.67421722,10.76782036] ; [106.67417145,10.76770020] ; [106.67417908,10.76760006] ; [106.67423248,10.76751995] ; [106.67429352,10.76747036] ; [106.67434692,10.76745033] ; [106.67442322,10.76745033] ; [106.67445374,10.76745987] ; [106.67446899,10.76745987] ; [106.67468262,10.76686001]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"288"
    ,"Station_Code":"Q10 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Chợ Lê Hồng Phong"
    ,"Station_Address":"419, đường Lê Hồng Phong, Quận 10"
    ,"Lat":10.764703
    ,"Long":106.675444
    ,"Polyline":"[106.67468262,10.76686001] ; [106.67542267,10.76484966]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3180"
    ,"Station_Code":"Q10 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trần Nhân Tông"
    ,"Station_Address":"126, đường Hùng Vương, Quận 10"
    ,"Lat":10.761752
    ,"Long":106.675621
    ,"Polyline":"[106.67542267,10.76484966] ; [106.67643738,10.76220989] ; [106.67565155,10.76169968]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3181"
    ,"Station_Code":"Q5 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Công Viên Hòa Bình"
    ,"Station_Address":"Đối diện 215, đường Hùng Vương, Quận 5"
    ,"Lat":10.760503
    ,"Long":106.673765
    ,"Polyline":"[106.67565155,10.76169968] ; [106.67503357,10.76128006] ; [106.67378998,10.76045990]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3182"
    ,"Station_Code":"Q5 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Bệnh viện 30/4"
    ,"Station_Address":"90, đường Hùng Vương, Quận 5"
    ,"Lat":10.759344
    ,"Long":106.672053
    ,"Polyline":"[106.67378998,10.76045990] ; [106.67209625,10.75936985]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"3183"
    ,"Station_Code":"Q5 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Tri  Phương"
    ,"Station_Address":"100H - 100G, đường Hùng Vương, Quận 5"
    ,"Lat":10.758108
    ,"Long":106.670074
    ,"Polyline":"[106.67209625,10.75936985] ; [106.67140198,10.75891018] ; [106.67012024,10.75804043]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"431"
    ,"Station_Code":"Q5 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Công vi ên Văn Lang"
    ,"Station_Address":"116A, đường Hùng Vương, Quận 5"
    ,"Lat":10.757257
    ,"Long":106.668566
    ,"Polyline":"[106.67012024,10.75804043] ; [106.66941071,10.75765038] ; [106.66860199,10.75724030]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Bệnh vi ện Phạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66856384,10.75725746] ; [106.66857147,10.75730896] ; [106.66788483,10.75687695] ; [106.66710663,10.75650024] ; [106.66667938,10.75634956] ; [106.66623688,10.75624466] ; [106.66451263,10.75588226] ; [106.66451263,10.75589657]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66451263,10.75588226] ; [106.66433716,10.75582314] ; [106.66336060,10.75557041] ; [106.66236877,10.75539017] ; [106.66139221,10.75520134] ; [106.66107941,10.75520515]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107941,10.75520515] ; [106.66094208,10.75514317] ; [106.65982819,10.75493240] ; [106.65961456,10.75492668]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"435"
    ,"Station_Code":"Q5 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"Đối diện 385, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75458
    ,"Long":106.657934
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65793610,10.75457954]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"438"
    ,"Station_Code":"Q5 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Dương Tử Giang"
    ,"Station_Address":"Đối di ện 455-457, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754158
    ,"Long":106.65552
    ,"Polyline":"[106.65793610,10.75457954] ; [106.65551758,10.75415802]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"74"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Bến xe Chợ L ớn"
    ,"Station_Address":"GA  HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65554810,10.75404835] ; [106.65554810,10.75404835] ; [106.65554810,10.75404835] ; [106.65554047,10.75407982] ; [106.65385437,10.75379944] ; [106.65376282,10.75377846] ; [106.65372467,10.75371552] ; [106.65373230,10.75359917] ; [106.65352631,10.75275612] ; [106.65337372,10.75208664] ; [106.65328217,10.75167084] ; [106.65316772,10.75150681] ; [106.65305328,10.75138569] ; [106.65267181,10.75127029] ; [106.65256500,10.75125313]"
    ,"Distance":"551"
  }]