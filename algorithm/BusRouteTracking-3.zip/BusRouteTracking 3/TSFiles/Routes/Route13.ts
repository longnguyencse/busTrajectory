export const Route13 =[
  {
     "Route_Id":"13"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vư ơng, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"630"
    ,"Station_Code":"QBT 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"480, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739675
    ,"Long":106.616392
    ,"Polyline":"[106.61846161,10.74116039] ; [106.61834717,10.74106979] ; [106.61823273,10.74118996] ; [106.61666107,10.73987961] ; [106.61640930,10.73966026]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"631"
    ,"Station_Code":"QBT 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"548, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.735138
    ,"Long":106.613144
    ,"Polyline":"[106.61640930,10.73966026] ; [106.61547852,10.73880959] ; [106.61511993,10.73832989] ; [106.61479187,10.73777962] ; [106.61315155,10.73511982]"
    ,"Distance":"622"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"632"
    ,"Station_Code":"QBT 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"SinCo"
    ,"Station_Address":"Đối diện nhà trọ Thanh Tr ường, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.731674
    ,"Long":106.611028
    ,"Polyline":"[106.61315155,10.73511982] ; [106.61231232,10.73375034] ; [106.61106873,10.73163033]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"633"
    ,"Station_Code":"QBT 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Hoa hồng"
    ,"Station_Address":"620, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729014
    ,"Long":106.608276
    ,"Polyline":"[106.61106873,10.73163033] ; [106.61049652,10.73066044] ; [106.61006927,10.73023987] ; [106.60946655,10.72978973] ; [106.60822296,10.72896957]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"634"
    ,"Station_Code":"QBT 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"676, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72733
    ,"Long":106.605751
    ,"Polyline":"[106.60822296,10.72896957] ; [106.60565948,10.72725964]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"635"
    ,"Station_Code":"QBT 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Thời trang"
    ,"Station_Address":"724, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.725466
    ,"Long":106.603027
    ,"Polyline":"[106.60565948,10.72725964] ; [106.60492706,10.72679043] ; [106.60443115,10.72642040] ; [106.60299683,10.72542953]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"636"
    ,"Station_Code":"HBC 362"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Bãi xe Phương Trang"
    ,"Station_Address":"B ãi xe Phương Trang, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.721333
    ,"Long":106.600379
    ,"Polyline":"[106.60302734,10.72546577] ; [106.60244751,10.72482300] ; [106.60195160,10.72420025] ; [106.60155487,10.72396851] ; [106.60127258,10.72390556] ; [106.60115814,10.72372627] ; [106.60115814,10.72348404] ; [106.60039520,10.72099400]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"637"
    ,"Station_Code":"HBC 363"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Hưng Nhơn"
    ,"Station_Address":"B1/5, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.71328
    ,"Long":106.598904
    ,"Polyline":"[106.60038757,10.72085953] ; [106.60025787,10.72002029] ; [106.60015869,10.71957016] ; [106.60009003,10.71942043]"
    ,"Distance":"164"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"638"
    ,"Station_Code":"HBC 364"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C3/4, đường Qu ốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.70706
    ,"Long":106.598089
    ,"Polyline":"[106.60009003,10.71942043] ; [106.60015869,10.71957016] ; [106.60016632,10.71944046] ; [106.60011292,10.71909046] ; [106.60002136,10.71850967] ; [106.59990692,10.71792984] ; [106.59985352,10.71765041] ; [106.59970856,10.71683979] ; [106.59966278,10.71656036] ; [106.59931946,10.71461964] ; [106.59915161,10.71341038] ; [106.59906006,10.71304035] ; [106.59877777,10.71166039] ; [106.59874725,10.71100998] ; [106.59870911,10.71033001] ; [106.59864807,10.70997047] ; [106.59855652,10.70942020]"
    ,"Distance":"1163"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"639"
    ,"Station_Code":"HBC 365"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"Kế E9/21, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.696064
    ,"Long":106.596496
    ,"Polyline":"[106.59855652,10.70942020] ; [106.59802246,10.70635986] ; [106.59790039,10.70590019] ; [106.59776306,10.70557022] ; [106.59739685,10.70468998] ; [106.59725952,10.70425987] ; [106.59722137,10.70396042] ; [106.59722137,10.70345974] ; [106.59722137,10.70205021] ; [106.59729004,10.70067978] ; [106.59732056,10.69997978] ; [106.59725189,10.69933033] ; [106.59700012,10.69777966] ; [106.59684753,10.69721985] ; [106.59671021,10.69676018] ; [106.59665680,10.69653988] ; [106.59651184,10.69604969] ; [106.59597778,10.69439030] ; [106.59559631,10.69316959] ; [106.59541321,10.69266987]"
    ,"Distance":"1913"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"813"
    ,"Station_Code":"HBC 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nguyễn V ăn Linh"
    ,"Station_Address":"Cột điện 358, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.689686
    ,"Long":106.595943
    ,"Polyline":"[106.59516144,10.69275379] ; [106.59460449,10.69019222] ; [106.59426880,10.69002342] ; [106.59426880,10.68974876] ; [106.59444427,10.68953800] ; [106.59478760,10.68957043] ; [106.59505463,10.68969631] ; [106.59584808,10.68983269]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"812"
    ,"Station_Code":"HBC 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"đường Ấp 2"
    ,"Station_Address":"Cột điện 332, đường Nguyễn  Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69152
    ,"Long":106.602321
    ,"Polyline":"[106.59809113,10.69052029] ; [106.60160828,10.69147968] ; [106.60353851,10.69202995] ; [106.60408783,10.69217968]"
    ,"Distance":"681"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"815"
    ,"Station_Code":"HBC 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Cột điện 307, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.693745
    ,"Long":106.610159
    ,"Polyline":"[106.60408783,10.69217968] ; [106.60903168,10.69355011]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"889"
    ,"Station_Code":"HBC 452"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Đối diện công ty bất động sản, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698468
    ,"Long":106.609279
    ,"Polyline":"[106.60945129,10.69351006] ; [106.60938263,10.69365025] ; [106.61045074,10.69394016] ; [106.61045074,10.69396019] ; [106.61032867,10.69449997] ; [106.61032104,10.69480991] ; [106.61000824,10.69594002] ; [106.60929871,10.69845963]"
    ,"Distance":"682"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"890"
    ,"Station_Code":"BX 60"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Đầu mối Bình Điền"
    ,"Station_Address":"ĐẦU BẾN CHỢ ĐM BÌNH ĐIỀN, đường Đường vào Chợ ĐM Bình Điền, Huy ện Bình Chánh"
    ,"Lat":10.7024
    ,"Long":106.608665
    ,"Polyline":"[106.60929871,10.69845963] ; [106.60823822,10.70228958]"
    ,"Distance":"504"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"891"
    ,"Station_Code":"HBC 453"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Quán ăn Chợ Bình Điền, đường Đường vào Ch ợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.702274
    ,"Long":106.608195
    ,"Polyline":"[106.60823822,10.70228958] ; [106.60823822,10.70228004]"
    ,"Distance":"61"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"893"
    ,"Station_Code":"HBC 451"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công ty bất  động sản"
    ,"Station_Address":"Công ty bất động sản, đường Đường vào Chợ  ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698684
    ,"Long":106.609113
    ,"Polyline":"[106.60823822,10.70228004] ; [106.60803223,10.70302963] ; [106.60791779,10.70298958] ; [106.60826874,10.70178986] ; [106.60910797,10.69869041]"
    ,"Distance":"621"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"817"
    ,"Station_Code":"HBC 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm thu ph í"
    ,"Station_Address":"Cột điện 291, đường Nguyễn  Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.694493
    ,"Long":106.613388
    ,"Polyline":"[106.60910797,10.69869041] ; [106.60958862,10.69699001] ; [106.60984802,10.69610023] ; [106.60990906,10.69583988] ; [106.61019135,10.69478989] ; [106.61032867,10.69449997] ; [106.61045074,10.69396019] ; [106.61045074,10.69394016] ; [106.61186981,10.69433022] ; [106.61483002,10.69515038]"
    ,"Distance":"1189"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"814"
    ,"Station_Code":"HBC 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu Cần Giuộc"
    ,"Station_Address":"Cột điện 277, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.696591
    ,"Long":106.620603
    ,"Polyline":"[106.61370850,10.69484043] ; [106.61791229,10.69598007]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"818"
    ,"Station_Code":"HBC 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Sập"
    ,"Station_Address":"Cột điện 258, đường Nguyễn  Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.698183
    ,"Long":106.626692
    ,"Polyline":"[106.61791229,10.69598007] ; [106.62406158,10.69764042] ; [106.62661743,10.69834042]"
    ,"Distance":"1004"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"816"
    ,"Station_Code":"HBC 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Kim Hằng"
    ,"Station_Address":"Cột điện 240, đường Nguyễn Văn Linh, Huyện Bình Ch ánh"
    ,"Lat":10.700144
    ,"Long":106.631413
    ,"Polyline":"[106.62661743,10.69834042] ; [106.62741852,10.69857025] ; [106.62834930,10.69884968] ; [106.62963867,10.69937038] ; [106.63060760,10.69983006] ; [106.63127899,10.70026016]"
    ,"Distance":"570"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"820"
    ,"Station_Code":"HBC 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trịnh Quang Nghị"
    ,"Station_Address":"C ột điện 230, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.702237
    ,"Long":106.634218
    ,"Polyline":"[106.63127899,10.70026016] ; [106.63160706,10.70046043] ; [106.63272095,10.70129013] ; [106.63362885,10.70199966]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"819"
    ,"Station_Code":"HBC 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Qua Trịnh Quang Nghị"
    ,"Station_Address":"C ột điện 213, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.705494
    ,"Long":106.638354
    ,"Polyline":"[106.63362885,10.70199966] ; [106.63742828,10.70497990]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"822"
    ,"Station_Code":"HBC 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Khu dân cư 13A"
    ,"Station_Address":"Cột đi ện 189, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.709337
    ,"Long":106.643343
    ,"Polyline":"[106.63742828,10.70497990] ; [106.64321136,10.70948982]"
    ,"Distance":"832"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"821"
    ,"Station_Code":"HBC 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Bà L ớn"
    ,"Station_Address":"Cột điện 175, đường Nguy ễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.711382
    ,"Long":106.645961
    ,"Polyline":"[106.64321136,10.70948982] ; [106.64585114,10.71152020]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"824"
    ,"Station_Code":"HBC 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"KĐT Hạnh Phúc"
    ,"Station_Address":"Cột điện 158, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.713791
    ,"Long":106.648997
    ,"Polyline":"[106.64585114,10.71152020] ; [106.64990234,10.71467972]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"823"
    ,"Station_Code":"HBC 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Quốc lộ 50"
    ,"Station_Address":"Cột điện 137, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.717971
    ,"Long":106.654356
    ,"Polyline":"[106.64990234,10.71467972] ; [106.65451813,10.71829987]"
    ,"Distance":"669"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"826"
    ,"Station_Code":"HBC 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Qua Quốc lộ 50"
    ,"Station_Address":"Cột điện 131, đư ờng Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.719436
    ,"Long":106.656303
    ,"Polyline":"[106.65458679,10.71821690] ; [106.65573120,10.71928978] ; [106.65621948,10.71948338]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"825"
    ,"Station_Code":"HBC 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Công ty  Phú Thịnh Hòa"
    ,"Station_Address":"Cột điện  117, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.722198
    ,"Long":106.659973
    ,"Polyline":"[106.65621948,10.71948338] ; [106.65988159,10.72224998]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"828"
    ,"Station_Code":"HBC 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Xóm  Củi"
    ,"Station_Address":"Cột điện 96, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.725107
    ,"Long":106.665359
    ,"Polyline":"[106.65988159,10.72224998] ; [106.66306305,10.72432041] ; [106.66393280,10.72476006] ; [106.66545105,10.72542000] ; [106.66531372,10.72518253]"
    ,"Distance":"736"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"830"
    ,"Station_Code":"HBC 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Sân bóng mi ni"
    ,"Station_Address":"C ột điện 76, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.727321
    ,"Long":106.673234
    ,"Polyline":"[106.66732025,10.72609043] ; [106.66874695,10.72653008] ; [106.67028809,10.72694969] ; [106.67194366,10.72727013]"
    ,"Distance":"906"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"827"
    ,"Station_Code":"HBC 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Phạm Hùng"
    ,"Station_Address":"Hai Nô, đường Nguyễn Văn Linh, Huyện B ình Chánh"
    ,"Lat":10.727517
    ,"Long":106.67675
    ,"Polyline":"[106.67323303,10.72736740] ; [106.67384338,10.72758007] ; [106.67534637,10.72764969] ; [106.67562103,10.72766972] ; [106.67675018,10.72751713]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"832"
    ,"Station_Code":"HBC 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Phúc Minh"
    ,"Station_Address":"Công ty Phúc Minh, đường Nguyễn Văn Linh , Huyện Bình Chánh"
    ,"Lat":10.727574
    ,"Long":106.680121
    ,"Polyline":"[106.67675018,10.72751713] ; [106.67887115,10.72776031] ; [106.68009949,10.72763348]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"829"
    ,"Station_Code":"HBC 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Ông Bé"
    ,"Station_Address":"Cột điện 47, đường  Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.727785
    ,"Long":106.684177
    ,"Polyline":"[106.68009949,10.72763348] ; [106.68228149,10.72789955] ; [106.68406677,10.72783279]"
    ,"Distance":"436"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"831"
    ,"Station_Code":"HBC 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trung S ơn"
    ,"Station_Address":"Cột điện 37, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.7279
    ,"Long":106.687416
    ,"Polyline":"[106.68406677,10.72783279] ; [106.68515778,10.72801971] ; [106.68596649,10.72801971] ; [106.68741608,10.72789955]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"833"
    ,"Station_Code":"Q7 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Đại học RMIT"
    ,"Station_Address":"Đối diện trạm thu phí, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728011
    ,"Long":106.695308
    ,"Polyline":"[106.68741608,10.72789955] ; [106.68757629,10.72803974] ; [106.68788910,10.72801971] ; [106.68849945,10.72805023] ; [106.69361877,10.72817039] ; [106.69479370,10.72821045] ; [106.69479370,10.72809601]"
    ,"Distance":"826"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"834"
    ,"Station_Code":"Q7 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Lê Văn Lương"
    ,"Station_Address":"Cạnh 38 Lê Văn Lương, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.727985
    ,"Long":106.699787
    ,"Polyline":"[106.69479370,10.72821045] ; [106.69689178,10.72826958] ; [106.69862366,10.72826958]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"835"
    ,"Station_Code":"Q7 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Phòng cháy chữa cháy Quận 7"
    ,"Station_Address":"Cạnh cột điện 39, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728106
    ,"Long":106.704031
    ,"Polyline":"[106.69862366,10.72820854] ; [106.69862366,10.72826958] ; [106.70020294,10.72824955] ; [106.70329285,10.72830963] ; [106.70384216,10.72821999]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"836"
    ,"Station_Code":"Q7 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Nguyễn Đức Cảnh"
    ,"Station_Address":"37, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728212
    ,"Long":106.709341
    ,"Polyline":"[106.70433807,10.72834969] ; [106.70909882,10.72846985]"
    ,"Distance":"583"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"837"
    ,"Station_Code":"Q7 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Co.op mart Phú Mỹ Hưng"
    ,"Station_Address":"Co.op mart Phú Mỹ Hưng, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728275
    ,"Long":106.711557
    ,"Polyline":"[106.70909882,10.72846985] ; [106.71188354,10.72852039]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"838"
    ,"Station_Code":"Q7 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Cầu Thầy Tiêu"
    ,"Station_Address":"Trung tâm truyền hình cáp, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728375
    ,"Long":106.714829
    ,"Polyline":"[106.71188354,10.72852039] ; [106.71482849,10.72856998]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"839"
    ,"Station_Code":"Q7 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"bệnh viện Việt Pháp"
    ,"Station_Address":"Đối diện bệnh viện Việt Pháp, đường Nguyễn Văn Linh, Qu ận 7"
    ,"Lat":10.730309
    ,"Long":106.719646
    ,"Polyline":"[106.71482849,10.72856998] ; [106.71540833,10.72863007] ; [106.71607971,10.72875977] ; [106.71652222,10.72885990] ; [106.71691895,10.72898006] ; [106.71713257,10.72904968] ; [106.71779633,10.72933960] ; [106.71843719,10.72966003] ; [106.71888733,10.72994995] ; [106.71929932,10.73025990] ; [106.71951294,10.73044014]"
    ,"Distance":"575"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"840"
    ,"Station_Code":"Q7 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Cầu Đa Khoa"
    ,"Station_Address":"Đối  diện 354, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.738937
    ,"Long":106.721798
    ,"Polyline":"[106.71951294,10.73044014] ; [106.71974182,10.73064041] ; [106.72016144,10.73106003] ; [106.72022247,10.73114967] ; [106.72006226,10.73145008] ; [106.71988678,10.73174953] ; [106.72000885,10.73186970] ; [106.72036743,10.73237991] ; [106.72059631,10.73276997] ; [106.72091675,10.73342991] ; [106.72122192,10.73447037] ; [106.72132874,10.73493004] ; [106.72144318,10.73575020] ; [106.72151184,10.73655033] ; [106.72152710,10.73674011] ; [106.72154999,10.73771954] ; [106.72152710,10.73803997] ; [106.72174072,10.73803043] ; [106.72170258,10.73824978] ; [106.72171021,10.73890018]"
    ,"Distance":"1058"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"842"
    ,"Station_Code":"Q7 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Cầu Lý Ph ục Man"
    ,"Station_Address":"Đối diện 404, đư ờng Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.742031
    ,"Long":106.721862
    ,"Polyline":"[106.72171021,10.73890018] ; [106.72177124,10.74203014]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"841"
    ,"Station_Code":"Q7 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"UBND P. Tân Thuận Tây"
    ,"Station_Address":"Đối diện UBND P. Tân Thuận Tây, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.746975
    ,"Long":106.721991
    ,"Polyline":"[106.72177124,10.74203014] ; [106.72178650,10.74322987] ; [106.72184753,10.74672985] ; [106.72187042,10.74699020]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"844"
    ,"Station_Code":"Q7 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Cầu Tân Thuận 2"
    ,"Station_Address":"Đối diện 41, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.751307
    ,"Long":106.724174
    ,"Polyline":"[106.72187042,10.74699020] ; [106.72196198,10.74767971] ; [106.72203064,10.74800014] ; [106.72218323,10.74855042] ; [106.72241211,10.74915028] ; [106.72284698,10.74999046] ; [106.72299957,10.75020981] ; [106.72331238,10.75063038] ; [106.72351837,10.75086021] ; [106.72374725,10.75107002]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"843"
    ,"Station_Code":"Q7 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 49/2, đường Nguyễn Văn Linh,  Quận 7"
    ,"Lat":10.752498
    ,"Long":106.727414
    ,"Polyline":"[106.72374725,10.75107002] ; [106.72411346,10.75139046] ; [106.72440338,10.75160027] ; [106.72483826,10.75189972] ; [106.72545624,10.75220013] ; [106.72586823,10.75234985] ; [106.72624207,10.75245953] ; [106.72669220,10.75255013] ; [106.72730255,10.75259972]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"846"
    ,"Station_Code":"Q7 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Kho 18"
    ,"Station_Address":"267, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.7549
    ,"Long":106.726204
    ,"Polyline":"[106.72730255,10.75259972] ; [106.72846985,10.75267029] ; [106.72843170,10.75319004] ; [106.72837830,10.75384045] ; [106.72827148,10.75407028] ; [106.72814941,10.75419998] ; [106.72798920,10.75434017] ; [106.72772980,10.75448036] ; [106.72766876,10.75450993] ; [106.72618866,10.75485039]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"845"
    ,"Station_Code":"Q7 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Vòng xoay Tân Thuận"
    ,"Station_Address":"135, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.755423
    ,"Long":106.723946
    ,"Polyline":"[106.72618866,10.75485039] ; [106.72393799,10.75537014]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"848"
    ,"Station_Code":"Q4 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Cảng Sài Gòn"
    ,"Station_Address":"Đối diện 466, đường Nguyễn Tất Thành,  Quận 4"
    ,"Lat":10.758443
    ,"Long":106.7155
    ,"Polyline":"[106.72393799,10.75537014] ; [106.72338104,10.75549984] ; [106.72335815,10.75547028] ; [106.72326660,10.75547028] ; [106.72316742,10.75543976] ; [106.72303772,10.75537968] ; [106.72296906,10.75531006] ; [106.72289276,10.75524044] ; [106.72277832,10.75510025] ; [106.72263336,10.75502968] ; [106.72250366,10.75500011] ; [106.72235107,10.75502968] ; [106.72106171,10.75564003] ; [106.71882629,10.75666046] ; [106.71794128,10.75710964] ; [106.71639252,10.75782967] ; [106.71546173,10.75837994]"
    ,"Distance":"1050"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"847"
    ,"Station_Code":"Q4 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Nhà thờ Thánh An Tôn"
    ,"Station_Address":"Đối diện 448, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.759771
    ,"Long":106.713241
    ,"Polyline":"[106.71546173,10.75837994] ; [106.71320343,10.75969982]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"850"
    ,"Station_Code":"Q4 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Đại học Nguyễn Tất Thành"
    ,"Station_Address":"Đối diện 300A, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.761557
    ,"Long":106.710194
    ,"Polyline":"[106.71320343,10.75969982] ; [106.70953369,10.76183033]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"849"
    ,"Station_Code":"Q4 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Bưu Điện Quận 4"
    ,"Station_Address":"75-83, đường Nguy ễn Tất Thành, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.707941
    ,"Polyline":"[106.70953369,10.76183033] ; [106.70847321,10.76245975] ; [106.70836639,10.76255989] ; [106.70783997,10.76373005]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"852"
    ,"Station_Code":"Q4 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Chợ Xóm Chiếu"
    ,"Station_Address":"34, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.764983
    ,"Long":106.706471
    ,"Polyline":"[106.70783997,10.76373005] ; [106.70745087,10.76461983] ; [106.70722961,10.76515961] ; [106.70713806,10.76511955] ; [106.70652771,10.76486969]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"851"
    ,"Station_Code":"Q4 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Đoàn Văn Bơ"
    ,"Station_Address":"106-108, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.704031
    ,"Polyline":"[106.70652771,10.76486969] ; [106.70552063,10.76445007] ; [106.70462799,10.76406956] ; [106.70432281,10.76383018] ; [106.70410156,10.76364994]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"854"
    ,"Station_Code":"Q1 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Lê Thị Hồng Gấm"
    ,"Station_Address":"134, đường Calmette , Quận 1"
    ,"Lat":10.769178
    ,"Long":106.698334
    ,"Polyline":"[106.70410156,10.76364994] ; [106.70378113,10.76340961] ; [106.70372772,10.76354027] ; [106.70362091,10.76362991] ; [106.70185852,10.76490974] ; [106.70159912,10.76513004] ; [106.70108795,10.76564980] ; [106.70088196,10.76589012] ; [106.69989014,10.76714039] ; [106.69975281,10.76721001] ; [106.69883728,10.76840973] ; [106.69828033,10.76912975]"
    ,"Distance":"942"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69828033,10.76912975] ; [106.69774628,10.76984978] ; [106.69744873,10.77035046] ; [106.69774628,10.77033997] ; [106.69841766,10.77060986]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69841766,10.77060986] ; [106.69905090,10.77084255] ; [106.69901276,10.77116489] ; [106.69885254,10.77136421] ; [106.69885254,10.77160168] ; [106.69872284,10.77182865] ; [106.69850159,10.77195454] ; [106.69823456,10.77188110.06.69808960] ; [10.77174377,106.69803619] ; [10.77149677,106.69813538] ; [10.77124882,106.69735718] ; [10.77028942,106.69595337]"
    ,"Distance":"640"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69577789,10.76972771] ; [106.69577789,10.76972771] ; [106.69493103,10.76938725] ; [106.69409180,10.76904678] ; [106.69409180,10.76904678]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường L ê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69409180,10.76904678] ; [106.69412994,10.76896954] ; [106.69238281,10.76828003] ; [106.69049072,10.76753044] ; [106.68980408,10.76724339] ; [106.68961334,10.76769161] ; [106.68936157,10.76767635]"
    ,"Distance":"614"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68904877,10.76807022] ; [106.68920898,10.76819992] ; [106.68988800,10.76844978] ; [106.69026184,10.76860046]"
    ,"Distance":"145"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76860046] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69329834,10.76982975] ; [106.69458008,10.77031040] ; [106.69673157,10.77118969]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"853"
    ,"Station_Code":"Q1 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Calmette"
    ,"Station_Address":"87, đường Calmette, Quận 1"
    ,"Lat":10.767768
    ,"Long":106.699219
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69673157,10.77118969] ; [106.69784546,10.77161217] ; [106.69805908,10.77160168] ; [106.69803619,10.77134895] ; [106.69814301,10.77120686] ; [106.69830322,10.77114296] ; [106.69859314,10.77125359] ; [106.69887543,10.77105904] ; [106.69891357,10.77095318] ; [106.69847107,10.77077961] ; [106.69808960,10.77063179] ; [106.69776154,10.77052116] ; [106.69716644,10.77021027] ; [106.69663239,10.77002048] ; [106.69617462,10.76984215] ; [106.69636536,10.76939392] ; [106.69664764,10.76912498] ; [106.69720459,10.76852989] ; [106.69779968,10.76911449] ; [106.69812012,10.76936245] ; [106.69872284,10.76859283] ; [106.69908142,10.76815033] ; [106.69921875,10.76776791]"
    ,"Distance":"1181"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"856"
    ,"Station_Code":"Q4 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ Xóm Chiếu"
    ,"Station_Address":"51-53, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.764703
    ,"Long":106.706504
    ,"Polyline":"[106.69921875,10.76776791] ; [106.69945526,10.76765442] ; [106.69975281,10.76721001] ; [106.69989014,10.76714039] ; [106.70033264,10.76657963] ; [106.70088196,10.76589012] ; [106.70108795,10.76564980] ; [106.70159912,10.76513004] ; [106.70185852,10.76490974] ; [106.70362091,10.76362991] ; [106.70385742,10.76345444] ; [106.70416260,10.76367569] ; [106.70465088,10.76404476] ; [106.70527649,10.76434994] ; [106.70577240,10.76455021] ; [106.70608521,10.76462936] ; [106.70635223,10.76465130]"
    ,"Distance":"1015"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"855"
    ,"Station_Code":"Q4 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bưu Điện Qu ận 4"
    ,"Station_Address":"136-138, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.76385
    ,"Long":106.70763
    ,"Polyline":"[106.70629883,10.76478004] ; [106.70713806,10.76511955] ; [106.70780182,10.76366043]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"857"
    ,"Station_Code":"Q4 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Đại học Nguy ễn Tất Thành"
    ,"Station_Address":"276, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.7618
    ,"Long":106.70932
    ,"Polyline":"[106.70780182,10.76366043] ; [106.70832062,10.76249027] ; [106.70842743,10.76241016] ; [106.70903778,10.76204014] ; [106.70935059,10.76185989]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"858"
    ,"Station_Code":"Q4 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường Nguyễn Trãi"
    ,"Station_Address":"428, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.759423
    ,"Long":106.713359
    ,"Polyline":"[106.70935059,10.76185989] ; [106.71275330,10.75986958]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"860"
    ,"Station_Code":"Q4 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cảng Sài Gòn"
    ,"Station_Address":"456, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.7579
    ,"Long":106.715977
    ,"Polyline":"[106.71275330,10.75986958] ; [106.71550751,10.75825977]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"859"
    ,"Station_Code":"Q7 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cầu Tân Thu ận 2"
    ,"Station_Address":"46/14 (chân cầu Tân Thuận 2), đường Nguyễn Văn Linh , Quận 7"
    ,"Lat":10.752424
    ,"Long":106.723927
    ,"Polyline":"[106.71550751,10.75825977] ; [106.71637726,10.75774956] ; [106.71768951,10.75714016] ; [106.71797943,10.75699997] ; [106.71816254,10.75687981] ; [106.71907043,10.75619984] ; [106.72042084,10.75518990] ; [106.72384644,10.75265026] ; [106.72412872,10.75242996]"
    ,"Distance":"1148"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"862"
    ,"Station_Code":"Q7 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Sân bóng CLB cảng SG"
    ,"Station_Address":"144-146 , đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.751697
    ,"Long":106.724088
    ,"Polyline":"[106.72412872,10.75242996] ; [106.72422791,10.75234032] ; [106.72435760,10.75214958] ; [106.72441101,10.75201988] ; [106.72440338,10.75191975] ; [106.72434998,10.75179958] ; [106.72418213,10.75160027] ; [106.72393036,10.75139046]"
    ,"Distance":"146"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"861"
    ,"Station_Code":"Q7 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ủy ban phư ờng Tân Thuận Tây"
    ,"Station_Address":"UBND phường Tân Thuận Tây, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.747691
    ,"Long":127.721756
    ,"Polyline":"[106.72393036,10.75139046] ; [106.72342682,10.75094986] ; [106.72325897,10.75076962] ; [106.72280121,10.75014973] ; [106.72248840,10.74964046] ; [106.72219086,10.74907017] ; [106.72202301,10.74855995] ; [106.72180939,10.74767971]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"866"
    ,"Station_Code":"Q7 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu Lý Phục Man"
    ,"Station_Address":"636, đường Nguyễn  Văn Linh, Quận 7"
    ,"Lat":10.742521
    ,"Long":106.721508
    ,"Polyline":"[106.72180939,10.74767971] ; [106.72174835,10.74736977] ; [106.72170258,10.74685955] ; [106.72164154,10.74361038]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"863"
    ,"Station_Code":"Q7 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nguyễn Thị Thập"
    ,"Station_Address":"340A, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.739585
    ,"Long":106.721444
    ,"Polyline":"[106.72164154,10.74361038] ; [106.72157288,10.73958969]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"867"
    ,"Station_Code":"Q7 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Tân Bình"
    ,"Station_Address":"452, đường Nguyễn Văn Linh , Quận 7"
    ,"Lat":10.73704
    ,"Long":106.721342
    ,"Polyline":"[106.72157288,10.73958969] ; [106.72152710,10.73803997] ; [106.72154999,10.73771954] ; [106.72154236,10.73696995]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"864"
    ,"Station_Code":"Q7 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Nguyễn Lương Bằng"
    ,"Station_Address":"Đối diện Manulife, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.732486
    ,"Long":106.720194
    ,"Polyline":"[106.72154236,10.73696995] ; [106.72144318,10.73575020] ; [106.72132874,10.73493004] ; [106.72122192,10.73447037] ; [106.72091675,10.73342991] ; [106.72067261,10.73291016]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"869"
    ,"Station_Code":"Q7 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Việt Pháp"
    ,"Station_Address":"Bệnh viện Việt Pháp, đường Nguyễn Văn  Linh, Quận 7"
    ,"Lat":10.731063
    ,"Long":106.718912
    ,"Polyline":"[106.72067261,10.73291016] ; [106.72036743,10.73237991] ; [106.72000885,10.73186970] ; [106.71988678,10.73174953] ; [106.71961975,10.73143005] ; [106.71923828,10.73106003] ; [106.71904755,10.73087025]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"865"
    ,"Station_Code":"Q7 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Hưng Vượng"
    ,"Station_Address":"Kế A001, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.729461
    ,"Long":106.714041
    ,"Polyline":"[106.71904755,10.73087025] ; [106.71848297,10.73042011] ; [106.71794128,10.73009014] ; [106.71694946,10.72966003] ; [106.71630096,10.72945023] ; [106.71585846,10.72935009] ; [106.71553040,10.72929955] ; [106.71508026,10.72926044] ; [106.71443939,10.72924042]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"872"
    ,"Station_Code":"Q7 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Sky Garden"
    ,"Station_Address":"1048 (Kế siêu thị Fivimart), đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.729234
    ,"Long":106.7049
    ,"Polyline":"[106.71443939,10.72924042] ; [106.70677185,10.72906017] ; [106.70377350,10.72900963]"
    ,"Distance":"1167"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"868"
    ,"Station_Code":"Q7 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đại học RMIT"
    ,"Station_Address":"Trường đại học RMIT, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728839
    ,"Long":106.695061
    ,"Polyline":"[106.70377350,10.72900963] ; [106.69962311,10.72887039] ; [106.69872284,10.72883987] ; [106.69767761,10.72883034] ; [106.69728088,10.72883034] ; [106.69586182,10.72873974] ; [106.69586182,10.72879028]"
    ,"Distance":"871"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"873"
    ,"Station_Code":"HBC 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trung Sơn"
    ,"Station_Address":"12-14 , đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.728649
    ,"Long":106.687267
    ,"Polyline":"[106.69586182,10.72879028] ; [106.69586182,10.72873974] ; [106.69461823,10.72869015] ; [106.69371796,10.72865009] ; [106.69168854,10.72856045] ; [106.68852234,10.72846985] ; [106.68782043,10.72846985] ; [106.68695831,10.72842026] ; [106.68602753,10.72840023]"
    ,"Distance":"1081"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"870"
    ,"Station_Code":"HBC 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Ông  Bé"
    ,"Station_Address":"Trụ điện  T NVL 14,  đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.728586
    ,"Long":106.68334
    ,"Polyline":"[106.68602753,10.72840023] ; [106.68283844,10.72834969]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"875"
    ,"Station_Code":"HBC 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Phạm Hùng"
    ,"Station_Address":"C10/56, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.728467
    ,"Long":106.678581
    ,"Polyline":"[106.68283844,10.72834969] ; [106.68032837,10.72832012] ; [106.67871857,10.72830963]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"871"
    ,"Station_Code":"HBC 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Phạm Hùng"
    ,"Station_Address":"Cột đèn A85 , đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.7284
    ,"Long":106.676537
    ,"Polyline":"[106.67871857,10.72830963] ; [106.67592621,10.72826958]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"877"
    ,"Station_Code":"HBC 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Xóm  Củi"
    ,"Station_Address":"Cột điện  T NVL 13T, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.725967
    ,"Long":106.665268
    ,"Polyline":"[106.67592621,10.72826958] ; [106.67510986,10.72824955] ; [106.67311096,10.72799969] ; [106.67208099,10.72776031]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"874"
    ,"Station_Code":"HBC 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chùa Viên Minh"
    ,"Station_Address":"Cột đèn A124 (Chùa Viên Minh), đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.723442
    ,"Long":106.660316
    ,"Polyline":"[106.67208099,10.72776031] ; [106.66912842,10.72702026] ; [106.66805267,10.72671986] ; [106.66696930,10.72640991] ; [106.66570282,10.72595024]"
    ,"Distance":"726"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"876"
    ,"Station_Code":"HBC 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Quốc lộ 50"
    ,"Station_Address":"Cột đèn 138, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.720595
    ,"Long":106.656497
    ,"Polyline":"[106.66570282,10.72595024] ; [106.66522217,10.72577953] ; [106.66339111,10.72498989] ; [106.66211700,10.72436047] ; [106.66056824,10.72338009] ; [106.65976715,10.72284985] ; [106.65898132,10.72226048]"
    ,"Distance":"845"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"879"
    ,"Station_Code":"HBC 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Sau Quốc lộ 50"
    ,"Station_Address":"Cột đèn 144, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.718972
    ,"Long":106.654415
    ,"Polyline":"[106.65898132,10.72226048] ; [106.65704346,10.72082043] ; [106.65479279,10.71905994]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"881"
    ,"Station_Code":"HBC 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Hoa Kiểng Phú Vinh"
    ,"Station_Address":"Cột đèn 156, đường Nguyễn Văn Linh, Huy ện Bình Chánh"
    ,"Lat":10.714903
    ,"Long":106.649158
    ,"Polyline":"[106.65479279,10.71905994] ; [106.65184021,10.71677017]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"884"
    ,"Station_Code":"HBC 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Xây dựng Tân Bình"
    ,"Station_Address":"Cột đèn 172, đường Nguyễn Văn Linh, Huy ện Bình Chánh"
    ,"Lat":10.71174
    ,"Long":106.645103
    ,"Polyline":"[106.65184021,10.71677017] ; [106.64900970,10.71455002]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"878"
    ,"Station_Code":"HBC 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chung cư Conic"
    ,"Station_Address":"Cột đèn 184, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.709506
    ,"Long":106.64227
    ,"Polyline":"[106.64900970,10.71455002] ; [106.64544678,10.71181011]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"880"
    ,"Station_Code":"HBC 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Khu dân cư 13A"
    ,"Station_Address":"Cột đèn 192, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.707397
    ,"Long":106.639502
    ,"Polyline":"[106.64544678,10.71181011] ; [106.64261627,10.70960045]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"882"
    ,"Station_Code":"HBC 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trịnh Quang Nghị"
    ,"Station_Address":"Cột đèn 210, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.703602
    ,"Long":106.634567
    ,"Polyline":"[106.64261627,10.70960045] ; [106.63945770,10.70713043] ; [106.63645935,10.70487976] ; [106.63538361,10.70403004]"
    ,"Distance":"1005"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"886"
    ,"Station_Code":"HBC 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Nhôm Kim Hằng"
    ,"Station_Address":"Cột đèn 216, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.701414
    ,"Long":106.631713
    ,"Polyline":"[106.63538361,10.70403004] ; [106.63371277,10.70273972] ; [106.63198090,10.70145035]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"887"
    ,"Station_Code":"HBC 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Cầu sập"
    ,"Station_Address":"C ột đèn 232, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69925
    ,"Long":106.627235
    ,"Polyline":"[106.63198090,10.70145035] ; [106.63110352,10.70079994] ; [106.63066864,10.70051003] ; [106.62970734,10.69997978] ; [106.62920380,10.69979954]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"883"
    ,"Station_Code":"HBC 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ba Tơ"
    ,"Station_Address":"Cột đèn 249, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.696855
    ,"Long":106.61828
    ,"Polyline":"[106.62920380,10.69979954] ; [106.62725830,10.69911957] ; [106.62541199,10.69863033]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"885"
    ,"Station_Code":"HBC 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cầu Cần Giuộc"
    ,"Station_Address":"Cột đèn  258, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.695133
    ,"Long":106.612183
    ,"Polyline":"[106.62541199,10.69863033] ; [106.62011719,10.69719982]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"888"
    ,"Station_Code":"HBC 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Khu dân  cư Nguyễn Minh"
    ,"Station_Address":"Cột đèn  265, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.6944
    ,"Long":106.60952
    ,"Polyline":"[106.62011719,10.69719982] ; [106.61502838,10.69579983]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"889"
    ,"Station_Code":"HBC 452"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Bình  Điền"
    ,"Station_Address":"Đối diện công ty bất động sản, đường Đường vào Chợ  ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698468
    ,"Long":106.609279
    ,"Polyline":"[106.61502838,10.69579983] ; [106.61032867,10.69449997] ; [106.61032104,10.69480991] ; [106.60997009,10.69608974] ; [106.60929871,10.69845963]"
    ,"Distance":"989"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"890"
    ,"Station_Code":"BX 60"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Đầu mối B ình Điền"
    ,"Station_Address":"ĐẦU BẾN CHỢ ĐM  BÌNH ĐIỀN, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.7024
    ,"Long":106.608665
    ,"Polyline":"[106.60929871,10.69845963] ; [106.60823822,10.70228958]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"891"
    ,"Station_Code":"HBC 453"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Quán ăn  Chợ Bình Điền, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.702274
    ,"Long":106.608195
    ,"Polyline":"[106.60823822,10.70228958] ; [106.60823822,10.70228004]"
    ,"Distance":"1"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"893"
    ,"Station_Code":"HBC 451"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Công ty bất động sản"
    ,"Station_Address":"Công  ty bất động sản, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698684
    ,"Long":106.609113
    ,"Polyline":"[106.60823822,10.70228004] ; [106.60803223,10.70302963] ; [106.60791779,10.70298958] ; [106.60826874,10.70178986] ; [106.60910797,10.69869041]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"892"
    ,"Station_Code":"HBC 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Căn hộ Hoàng Quân"
    ,"Station_Address":"Cột đèn 276, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69335
    ,"Long":106.605682
    ,"Polyline":"[106.60910797,10.69869041] ; [106.60958862,10.69699001] ; [106.60984802,10.69610023] ; [106.60990906,10.69583988] ; [106.61019135,10.69478989] ; [106.61032867,10.69449997] ; [106.60964966,10.69431973]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"894"
    ,"Station_Code":"HBC 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Ấp 2"
    ,"Station_Address":"Cột đèn 291, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.692048
    ,"Long":106.600937
    ,"Polyline":"[106.60964966,10.69431973] ; [106.60278320,10.69241047]"
    ,"Distance":"780"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"895"
    ,"Station_Code":"HBC 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Quốc lộ 1A"
    ,"Station_Address":"Cột đèn 302, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69075
    ,"Long":106.596169
    ,"Polyline":"[106.60278320,10.69241047] ; [106.59876251,10.69132042]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"704"
    ,"Station_Code":"HBC 389"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"45/2A, đường Quốc lộ 1A, Huyện Bình Ch ánh"
    ,"Lat":10.697161
    ,"Long":106.597059
    ,"Polyline":"[106.59876251,10.69132042] ; [106.59554291,10.69046974] ; [106.59535980,10.69044971] ; [106.59529114,10.69046974] ; [106.59519196,10.69052982] ; [106.59510803,10.69062042] ; [106.59506226,10.69071960] ; [106.59504700,10.69085026] ; [106.59520721,10.69136047] ; [106.59546661,10.69213009] ; [106.59552765,10.69237995] ; [106.59554291,10.69258022] ; [106.59558868,10.69277000]"
    ,"Distance":"667"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"705"
    ,"Station_Code":"HBC 390"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C14/17, đường Quốc lộ 1A,  Huyện Bình Chánh"
    ,"Lat":10.70658
    ,"Long":106.598266
    ,"Polyline":"[106.59558868,10.69277000] ; [106.59602356,10.69419003] ; [106.59683228,10.69678020] ; [106.59709930,10.69773960] ; [106.59738159,10.69943047] ; [106.59745789,10.70005989] ; [106.59745026,10.70018005]"
    ,"Distance":"852"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"707"
    ,"Station_Code":"HBC 391"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Cầu đi bộ Số 2"
    ,"Station_Address":"C12/3, đường Quốc  lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.713538
    ,"Long":106.599564
    ,"Polyline":"[106.59745026,10.70018005] ; [106.59741211,10.70102024] ; [106.59729767,10.70343018] ; [106.59731293,10.70405006] ; [106.59741974,10.70448017] ; [106.59786987,10.70557022] ; [106.59789276,10.70563030]"
    ,"Distance":"618"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"706"
    ,"Station_Code":"HBC 392"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Ngã tư An Lạc"
    ,"Station_Address":"591 cầu đi bộ, đường Quốc lộ 1A, Huyện Bình  Chánh"
    ,"Lat":10.71359
    ,"Long":106.599564
    ,"Polyline":"[106.59789276,10.70563030] ; [106.59800720,10.70592976] ; [106.59825897,10.70703983] ; [106.59864807,10.70938015] ; [106.59879303,10.71016026] ; [106.59886169,10.71051025] ; [106.59896851,10.71088982] ; [106.59912872,10.71144962] ; [106.59922791,10.71193981] ; [106.59953308,10.71360016]"
    ,"Distance":"906"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"711"
    ,"Station_Code":"HBC 393"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Trần Đại Nghĩa"
    ,"Station_Address":"591B (cầu bộ hành), đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.721333
    ,"Long":106.600948
    ,"Polyline":"[106.59953308,10.71360016] ; [106.59969330,10.71469975] ; [106.59992981,10.71605015] ; [106.60016632,10.71747017] ; [106.60060120,10.71994972] ; [106.60067749,10.72019005] ; [106.60079956,10.72087955] ; [106.60088348,10.72150040] ; [106.60089111,10.72161961]"
    ,"Distance":"905"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"708"
    ,"Station_Code":"QBT 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"849, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.724317
    ,"Long":106.602337
    ,"Polyline":"[106.60089111,10.72161961] ; [106.60089111,10.72192001] ; [106.60093689,10.72227955] ; [106.60102081,10.72253036] ; [106.60140991,10.72319031] ; [106.60164642,10.72360039] ; [106.60198975,10.72406960] ; [106.60218048,10.72430992]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"712"
    ,"Station_Code":"QBT 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Cầu An Lạc"
    ,"Station_Address":"771, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.726583
    ,"Long":106.605191
    ,"Polyline":"[106.60221863,10.72437954] ; [106.60260010,10.72484016] ; [106.60310364,10.72531986] ; [106.60366058,10.72572994] ; [106.60508728,10.72667980]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"709"
    ,"Station_Code":"QBT 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"703, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72832
    ,"Long":106.607605
    ,"Polyline":"[106.60508728,10.72667980] ; [106.60588837,10.72719002] ; [106.60732269,10.72815037] ; [106.60761261,10.72832966]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"714"
    ,"Station_Code":"QBT 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Ủy ban"
    ,"Station_Address":"631-637, đường Kinh Dương Vương, Quận  Bình Tân"
    ,"Lat":10.729977
    ,"Long":106.610255
    ,"Polyline":"[106.60761261,10.72832966] ; [106.60958099,10.72963047] ; [106.61019897,10.73009968]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"710"
    ,"Station_Code":"QBT 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Lâm Thành"
    ,"Station_Address":"289(561), đường Kinh Dương  Vương, Quận Bình Tân"
    ,"Lat":10.734278
    ,"Long":106.61298
    ,"Polyline":"[106.61019897,10.73009968] ; [106.61054230,10.73044968] ; [106.61067963,10.73062038] ; [106.61081696,10.73085976] ; [106.61161804,10.73217010.06.61219788] ; [10.73322010.06.61283875,10.73427010]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"716"
    ,"Station_Code":"QBT 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"251(511), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.737541
    ,"Long":106.614906
    ,"Polyline":"[106.61283875,10.73427010.06.61313629] ; [10.73480034,106.61419678] ; [10.73655033,106.61472321] ; [10.73733044,106.61483765]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"713"
    ,"Station_Code":"QBT 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"Bệnh viện Triều An, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739665
    ,"Long":106.61687
    ,"Polyline":"[106.61483765,10.73756027] ; [106.61524200,10.73818016] ; [106.61540985,10.73849964] ; [106.61576080,10.73888016] ; [106.61676788,10.73974991] ; [106.61683655,10.73980045]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"13"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61683655,10.73980045] ; [106.61834717,10.74106979] ; [106.61846161,10.74116039]"
    ,"Distance":"233"
  }]