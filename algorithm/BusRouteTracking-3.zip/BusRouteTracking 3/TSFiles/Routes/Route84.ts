export const Route84 =[
  {
     "Route_Id":"84"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"KCN LÊ MINH XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường  Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3343"
    ,"Station_Code":"HBC 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Gia Hưng"
    ,"Station_Address":"Gia Hưng, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.742237
    ,"Long":106.543667
    ,"Polyline":"[106.53951263,10.74421024] ; [106.54485321,10.74149036] ; [106.54592133,10.74096012]"
    ,"Distance":"788"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3347"
    ,"Station_Code":"HBC 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Đường sô 10"
    ,"Station_Address":"Trụ điện T TĐN 154, đường Trần Đại Ngh ĩa, Huyện Bình Chánh"
    ,"Lat":10.740466
    ,"Long":106.547202
    ,"Polyline":"[106.54592133,10.74096012] ; [106.54731750,10.74026012] ; [106.54763031,10.74013996] ; [106.54853058,10.73970985] ; [106.55033112,10.73880959]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3345"
    ,"Station_Code":"HBC 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Đảo"
    ,"Station_Address":"Cột điện 154, đường Trần  Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.738874
    ,"Long":106.550195
    ,"Polyline":"[106.55033112,10.73880959] ; [106.55149841,10.73822975] ; [106.55303192,10.73744011]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3346"
    ,"Station_Code":"HBC 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Phòng khám Đa khoa Lê Minh Xu ân"
    ,"Station_Address":"Đối diện G16/12, đường  Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.736829
    ,"Long":106.554208
    ,"Polyline":"[106.55303192,10.73744011] ; [106.55506134,10.73637962]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3349"
    ,"Station_Code":"HBC 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Công ty  Hòa Kỳ"
    ,"Station_Address":"B22/474, đường Tr ần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.734663
    ,"Long":106.55807
    ,"Polyline":"[106.55506134,10.73637962] ; [106.55716705,10.73503017]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3351"
    ,"Station_Code":"HBC 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ủy ban nhân dân"
    ,"Station_Address":"Văn phòng Ủy ban nhân dân, đường Trần  Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.73383
    ,"Long":106.561385
    ,"Polyline":"[106.55716705,10.73503017] ; [106.55757904,10.73480988] ; [106.55811310,10.73464966] ; [106.55964661,10.73431015] ; [106.56067657,10.73406982] ; [106.56107330,10.73398972]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3353"
    ,"Station_Code":"HBC 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Công ty bao bì Trang Tín"
    ,"Station_Address":"B19/399, đường Trần Đại Nghĩa, Huyện  Bình Chánh"
    ,"Lat":10.733034
    ,"Long":106.565205
    ,"Polyline":"[106.56107330,10.73398972] ; [106.56446838,10.73322964]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3348"
    ,"Station_Code":"HBC 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cơ sở khoang giếng"
    ,"Station_Address":"B19/403C, đường Trần Đại Nghĩa, Huyện  Bình Chánh"
    ,"Lat":10.732323
    ,"Long":106.568418
    ,"Polyline":"[106.56446838,10.73322964] ; [106.56877136,10.73229980]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3350"
    ,"Station_Code":"HBC 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Công ty ROBOT"
    ,"Station_Address":"Đối diện A7/19, đường Trần Đại Nghĩa, Huy ện Bình Chánh"
    ,"Lat":10.731501
    ,"Long":106.572146
    ,"Polyline":"[106.56877136,10.73229980] ; [106.57232666,10.73153019]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3352"
    ,"Station_Code":"HBC 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Đường Tân Tạo - Chợ Đệm"
    ,"Station_Address":"A7/13B, đường Trần Đại Nghĩa, Huyện B ình Chánh"
    ,"Lat":10.73072
    ,"Long":106.575553
    ,"Polyline":"[106.57232666,10.73153019] ; [106.57569122,10.73075962]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3355"
    ,"Station_Code":"HBC 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Công ty Chí Thành"
    ,"Station_Address":"611, đường Trần Đại Nghĩa, Huyện Bình  Chánh"
    ,"Lat":10.729846
    ,"Long":106.579598
    ,"Polyline":"[106.57569122,10.73075962] ; [106.57959747,10.72990036]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3354"
    ,"Station_Code":"HBC 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cầu Cái Trung"
    ,"Station_Address":"A3/20, đường Trần Đại Ngh ĩa, Huyện Bình Chánh"
    ,"Lat":10.729023
    ,"Long":106.582972
    ,"Polyline":"[106.57959747,10.72990036] ; [106.58145142,10.72954464] ; [106.58190155,10.72945976]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3356"
    ,"Station_Code":"HBC 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"B11/33, đường Trần Đại Nghĩa, Huyện Bình Ch ánh"
    ,"Lat":10.728665
    ,"Long":106.584361
    ,"Polyline":"[106.58190155,10.72945976] ; [106.58435059,10.72873020]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3357"
    ,"Station_Code":"HBC 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Khuất Văn Bức"
    ,"Station_Address":"B11/3B, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.727827
    ,"Long":106.58736
    ,"Polyline":"[106.58438110,10.72871971] ; [106.58513641,10.72850990] ; [106.58590698,10.72821045] ; [106.58721924,10.72782993] ; [106.58734131,10.72778988]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3358"
    ,"Station_Code":"HBC 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Nguyễn Hiệp"
    ,"Station_Address":"B6/7B, đường Trần Đại Nghĩa, Huyện Bình  Chánh"
    ,"Lat":10.72643
    ,"Long":106.591678
    ,"Polyline":"[106.58734131,10.72778988] ; [106.58815765,10.72751999] ; [106.58943939,10.72716999] ; [106.59004211,10.72698975] ; [106.59062958,10.72679043] ; [106.59088135,10.72667980] ; [106.59153748,10.72644997] ; [106.59155273,10.72644043]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3361"
    ,"Station_Code":"HBC 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Tứ Hưng"
    ,"Station_Address":"B6/5A, đường Trần Đại Nghĩa, Huyện Bình  Chánh"
    ,"Lat":10.72503
    ,"Long":106.595161
    ,"Polyline":"[106.59161377,10.72642040] ; [106.59393311,10.72550964] ; [106.59516907,10.72504044]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3359"
    ,"Station_Code":"HBC 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Kinh Dương Vương"
    ,"Station_Address":"B5/19K, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.723183
    ,"Long":106.59885
    ,"Polyline":"[106.59516907,10.72504044] ; [106.59590149,10.72476006] ; [106.59665680,10.72447014] ; [106.59825134,10.72352028] ; [106.59884644,10.72317982]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"708"
    ,"Station_Code":"QBT 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"849, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.724317
    ,"Long":106.602337
    ,"Polyline":"[106.59884644,10.72317982] ; [106.59966278,10.72274017] ; [106.59996033,10.72255993] ; [106.60018158,10.72247028] ; [106.60044861,10.72239017] ; [106.60066986,10.72233963] ; [106.60079956,10.72233963] ; [106.60083771,10.72235012] ; [106.60093689,10.72239017] ; [106.60095978,10.72239971] ; [106.60102081,10.72253036] ; [106.60140991,10.72319031] ; [106.60154724,10.72346973] ; [106.60162354,10.72354031] ; [106.60222626,10.72439003]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"712"
    ,"Station_Code":"QBT 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu An Lạc"
    ,"Station_Address":"771, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.726583
    ,"Long":106.605191
    ,"Polyline":"[106.60222626,10.72439003] ; [106.60260010,10.72484016] ; [106.60310364,10.72531986] ; [106.60366058,10.72572994] ; [106.60514832,10.72671986]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"709"
    ,"Station_Code":"QBT 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"703, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72832
    ,"Long":106.607605
    ,"Polyline":"[106.60514832,10.72671986] ; [106.60588837,10.72719002] ; [106.60732269,10.72815037] ; [106.60759735,10.72832966]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"714"
    ,"Station_Code":"QBT 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ủy ban"
    ,"Station_Address":"631-637, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729977
    ,"Long":106.610255
    ,"Polyline":"[106.60759735,10.72832966] ; [106.60958099,10.72963047] ; [106.61018372,10.73007965]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"710"
    ,"Station_Code":"QBT 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Lâm Thành"
    ,"Station_Address":"289(561), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.734278
    ,"Long":106.61298
    ,"Polyline":"[106.61018372,10.73007965] ; [106.61054230,10.73044968] ; [106.61067963,10.73062038] ; [106.61081696,10.73085976] ; [106.61161804,10.73217010.06.61219788] ; [10.73322010.06.61284637,10.73427963]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"716"
    ,"Station_Code":"QBT 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"251(511), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.737541
    ,"Long":106.614906
    ,"Polyline":"[106.61284637,10.73427963] ; [106.61313629,10.73480034] ; [106.61419678,10.73655033] ; [106.61482239,10.73756027]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"713"
    ,"Station_Code":"QBT 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"Bệnh  viện Triều An, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739665
    ,"Long":106.61687
    ,"Polyline":"[106.61482239,10.73756027] ; [106.61518097,10.73816013] ; [106.61540222,10.73845959] ; [106.61576080,10.73888016] ; [106.61676788,10.73974991]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"119"
    ,"Station_Code":"QBT 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.741035
    ,"Long":106.618468
    ,"Polyline":"[106.61679840,10.73976040] ; [106.61834717,10.74106979] ; [106.61840057,10.74110985]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.61840057,10.74110985] ; [106.62306976,10.74499035]"
    ,"Distance":"668"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"1589"
    ,"Station_Code":"Q6 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Lý Chiêu Hoàng"
    ,"Station_Address":"426, đường An Dương Vương, Quận 6"
    ,"Lat":10.740065
    ,"Long":106.623548
    ,"Polyline":"[106.62307739,10.74498463] ; [106.62307739,10.74498463] ; [106.62376404,10.74533558] ; [106.62364960,10.74320316] ; [106.62364960,10.74320316]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"761"
    ,"Station_Code":"Q6 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ An Dương Vương"
    ,"Station_Address":"421, đường An Dương Vương, Quận 6"
    ,"Lat":10.742985
    ,"Long":106.623602
    ,"Polyline":"[106.62364960,10.74320316] ; [106.62357330,10.74020100]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4571"
    ,"Station_Code":"Q6 TVK 2"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Đối diện 95/6, Trần Văn Kiểu"
    ,"Station_Address":"Đối diện 95/6, đường Trần Văn Kiểu, Quận  6"
    ,"Lat":10.7366498407992
    ,"Long":106.62717461586
    ,"Polyline":"[106.62357330,10.74020100] ; [106.62366486,10.73851585] ; [106.62377167,10.73703957] ; [106.62368774,10.73628044] ; [106.62574768,10.73581696] ; [106.62686157,10.73556423] ; [106.62717438,10.73664951]"
    ,"Distance":"920"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"811"
    ,"Station_Code":"Q6 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Metro Bình Phú"
    ,"Station_Address":"33, đường Đường Số 26, Quận 6"
    ,"Lat":10.741578
    ,"Long":106.63086
    ,"Polyline":"[106.62717438,10.73664951] ; [106.62744141,10.73883152] ; [106.62812805,10.74201488] ; [106.63085938,10.74165154]"
    ,"Distance":"908"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4354"
    ,"Station_Code":"Q6 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Phạm Văn Ch í"
    ,"Station_Address":"Đối diện 127, đường Nguyễn Văn Luông, Quận 6"
    ,"Lat":10.739016
    ,"Long":106.633564
    ,"Polyline":"[106.63085938,10.74165154] ; [106.63218689,10.74142456] ; [106.63358307,10.74101353] ; [106.63377380,10.74150944] ; [106.63428497,10.74224663] ; [106.63462830,10.74276352] ; [106.63478851,10.74328041]"
    ,"Distance":"594"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4608"
    ,"Station_Code":"Q6 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Cao  đẳng Kinh tế-Kỹ thuật TP.HCM"
    ,"Station_Address":"220C-222, đường Nguyễn Văn Luông, Quận 6"
    ,"Lat":10.743844
    ,"Long":106.634851
    ,"Polyline":"[106.63478851,10.74328041] ; [106.63484955,10.74384403]"
    ,"Distance":"63"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4217"
    ,"Station_Code":"Q6 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Hậu Giang"
    ,"Station_Address":"256B-256C, đường Nguyễn  Văn Luông, Quận 6"
    ,"Lat":10.747096
    ,"Long":106.635157
    ,"Polyline":"[106.63484955,10.74384403] ; [106.63515472,10.74709606]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"142"
    ,"Station_Code":"Q6 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Văn Luông"
    ,"Station_Address":"517-519, đường Hậu Giang, Quận 6"
    ,"Lat":10.74826
    ,"Long":106.636192
    ,"Polyline":"[106.63515472,10.74709606] ; [106.63516998,10.74760723] ; [106.63522339,10.74811840] ; [106.63619232,10.74825954]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"144"
    ,"Station_Code":"Q6 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ Hoa"
    ,"Station_Address":"411, đường Hậu Giang, Qu ận 6"
    ,"Lat":10.748814
    ,"Long":106.638359
    ,"Polyline":"[106.63617706,10.74831963] ; [106.63842773,10.74888039]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"729"
    ,"Station_Code":"Q6 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Coop mart"
    ,"Station_Address":"259 (Đối diện 186), đường Hậu Giang, Quận 6"
    ,"Lat":10.74971
    ,"Long":106.64283
    ,"Polyline":"[106.63842773,10.74888039] ; [106.63997650,10.74927044] ; [106.64154053,10.74965000] ; [106.64199066,10.74973011] ; [106.64234161,10.74977970] ; [106.64282990,10.74977016]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"2390"
    ,"Station_Code":"Q6 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngân hàng Thương Tín"
    ,"Station_Address":"131B, đường Hậu Giang, Quận 6"
    ,"Lat":10.749552
    ,"Long":106.648101
    ,"Polyline":"[106.64282990,10.74977016] ; [106.64391327,10.74975014] ; [106.64488983,10.74967003] ; [106.64626312,10.74960995] ; [106.64746857,10.74956036] ; [106.64768982,10.74958992] ; [106.64808655,10.74960995]"
    ,"Distance":"589"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.64808655,10.74960995] ; [106.64871979,10.74962997] ; [106.64965820,10.74973011] ; [106.65168762,10.75012016] ; [106.65220642,10.75024986] ; [106.65193939,10.75100040] ; [106.65107727,10.75096035]"
    ,"Distance":"672"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON,  đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"1778"
    ,"Station_Code":"Q6 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngân hàng  Thương Tín"
    ,"Station_Address":"30A, đường Hậu Giang, Quận 6"
    ,"Lat":10.749699
    ,"Long":106.648241
    ,"Polyline":"[106.65258026,10.75105953] ; [106.65193939,10.75100040] ; [106.65097046,10.75094986] ; [106.65000916,10.75105953] ; [106.64955139,10.75078011] ; [106.64942932,10.74969959] ; [106.64871979,10.74962997] ; [106.64858246,10.74964046] ; [106.64824677,10.74962044]"
    ,"Distance":"591"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"728"
    ,"Station_Code":"Q6 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Coop Mart Hậu Giang"
    ,"Station_Address":"148, đường Hậu Giang, Quận 6"
    ,"Lat":10.74981
    ,"Long":106.643584
    ,"Polyline":"[106.64824677,10.74962044] ; [106.64746857,10.74956036] ; [106.64488983,10.74967003] ; [106.64360809,10.74975014] ; [106.64315796,10.74975967]"
    ,"Distance":"557"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"111"
    ,"Station_Code":"Q6 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Hậu Giang"
    ,"Station_Address":"212A, đường Hậu Giang, Quận 6"
    ,"Lat":10.749736
    ,"Long":106.641503
    ,"Polyline":"[106.64315796,10.74975967] ; [106.64234161,10.74977970] ; [106.64212799,10.74973965] ; [106.64186096,10.74971008] ; [106.64153290,10.74964046]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"110"
    ,"Station_Code":"Q6 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Hoa"
    ,"Station_Address":"460-462, đường Hậu Giang, Quận 6"
    ,"Lat":10.748714
    ,"Long":106.637437
    ,"Polyline":"[106.64153290,10.74964046] ; [106.63947296,10.74915028] ; [106.63648224,10.74839973]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4217"
    ,"Station_Code":"Q6 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hậu Giang"
    ,"Station_Address":"256B-256C, đường Nguyễn Văn Luông, Quận 6"
    ,"Lat":10.747096
    ,"Long":106.635157
    ,"Polyline":"[106.63743591,10.74871445] ; [106.63520813,10.74811840] ; [106.63515472,10.74709606]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4609"
    ,"Station_Code":"Q6 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Cao đẳng Kinh tế-Kỹ thuật TP.HCM"
    ,"Station_Address":"Đối diện 220, đường Nguyễn Văn Luông, Quận 6"
    ,"Lat":10.744281
    ,"Long":106.634755
    ,"Polyline":"[106.63515472,10.74709606] ; [106.63475800,10.74428082]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"759"
    ,"Station_Code":"Q6 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Metro Bình Phú"
    ,"Station_Address":"Metro Bình Phú, đường Đường Số 26, Quận 6"
    ,"Lat":10.741673
    ,"Long":106.630994
    ,"Polyline":"[106.63475800,10.74428082] ; [106.63470459,10.74298477] ; [106.63404083,10.74186802] ; [106.63379669,10.74157238] ; [106.63356018,10.74109840] ; [106.63098907,10.74164677]"
    ,"Distance":"677"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4549"
    ,"Station_Code":"Q6 TVK"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"95/6, Trần Văn Kiểu"
    ,"Station_Address":"95/6, đường Trần Văn Kiểu, Quận 6"
    ,"Lat":10.7368501200226
    ,"Long":106.626949310303
    ,"Polyline":"[106.63098907,10.74164677] ; [106.62812805,10.74207878] ; [106.62695313,10.73684978]"
    ,"Distance":"913"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"4771"
    ,"Station_Code":"Q6 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Đường số 74"
    ,"Station_Address":"44-46 , đường Đường số 74, Quận 6"
    ,"Lat":10.733229
    ,"Long":106.625796
    ,"Polyline":"[106.62695313,10.73684978] ; [106.62683868,10.73498440] ; [106.62662506,10.73357201] ; [106.62657166,10.73301315] ; [106.62579346,10.73322868]"
    ,"Distance":"518"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"806"
    ,"Station_Code":"Q6 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Lý Chiêu Hoàng"
    ,"Station_Address":"369/F31, đường An  Dương Vương, Quận 6"
    ,"Lat":10.740239
    ,"Long":106.623715
    ,"Polyline":"[106.62579346,10.73322868] ; [106.62465668,10.73347664] ; [106.62519073,10.73594379] ; [106.62362671,10.73636532] ; [106.62385559,10.73720837] ; [106.62358093,10.73904228] ; [106.62370300,10.74023914]"
    ,"Distance":"1024"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"1591"
    ,"Station_Code":"Q6 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Chợ An Dương Vương"
    ,"Station_Address":"648-650, đường An Dương Vương, Quận 6"
    ,"Lat":10.743876
    ,"Long":106.623784
    ,"Polyline":"[106.62370300,10.74023914] ; [106.62377930,10.74334240]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62377930,10.74334240] ; [106.62377930,10.74334240] ; [106.62376404,10.74530411] ; [106.62394714,10.74547291] ; [106.62394714,10.74565220] ; [106.62374115,10.74569416] ; [106.62353516,10.74559879] ; [106.62247467,10.74474621] ; [106.62247467,10.74474621]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62039948,10.74309158]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"630"
    ,"Station_Code":"QBT 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"480 , đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739675
    ,"Long":106.616392
    ,"Polyline":"[106.62045288,10.74304008] ; [106.61643219,10.73968029]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"631"
    ,"Station_Code":"QBT 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Hàng D ương"
    ,"Station_Address":"548, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.735138
    ,"Long":106.613144
    ,"Polyline":"[106.61643219,10.73968792] ; [106.61525726,10.73853683] ; [106.61314392,10.73513794]"
    ,"Distance":"625"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"632"
    ,"Station_Code":"QBT 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"SinCo"
    ,"Station_Address":"Đối diện nhà trọ Thanh Tr ường, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.731674
    ,"Long":106.611028
    ,"Polyline":"[106.61314392,10.73513794] ; [106.61107635,10.73165607]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"633"
    ,"Station_Code":"QBT 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Hoa hồng"
    ,"Station_Address":"620 , đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729014
    ,"Long":106.608276
    ,"Polyline":"[106.61107635,10.73165607] ; [106.61107635,10.73165035] ; [106.61047363,10.73066807] ; [106.61006927,10.73023987] ; [106.60946655,10.72978973] ; [106.60827637,10.72900963] ; [106.60827637,10.72901440]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"634"
    ,"Station_Code":"QBT 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"676, đường Kinh Dương V ương, Quận Bình Tân"
    ,"Lat":10.72733
    ,"Long":106.605751
    ,"Polyline":"[106.60827637,10.72901440] ; [106.60575104,10.72733021]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"635"
    ,"Station_Code":"QBT 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Thời trang"
    ,"Station_Address":"724, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.725466
    ,"Long":106.603027
    ,"Polyline":"[106.60575104,10.72733021] ; [106.60302734,10.72546577]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3321"
    ,"Station_Code":"QBT 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu bộ hành"
    ,"Station_Address":"16, đường Trần Đại Nghĩa, Quận Bình Tân"
    ,"Lat":10.722946
    ,"Long":106.599526
    ,"Polyline":"[106.60304260,10.72546005] ; [106.60269928,10.72515011] ; [106.60244751,10.72488022] ; [106.60222626,10.72457981] ; [106.60188293,10.72414017] ; [106.60175323,10.72406960] ; [106.60157013,10.72401047] ; [106.60154724,10.72402000] ; [106.60150909,10.72404003] ; [106.60141754,10.72406960] ; [106.60127258,10.72406006] ; [106.60112000,10.72397041] ; [106.60105133,10.72383022] ; [106.60104370,10.72367001] ; [106.60105896,10.72362995] ; [106.60099792,10.72331047] ; [106.60089111,10.72278023] ; [106.60076141,10.72233009] ; [106.60054016,10.72235966] ; [106.60038757,10.72239971] ; [106.59996033,10.72255993] ; [106.59950256,10.72282028]"
    ,"Distance":"626"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3324"
    ,"Station_Code":"QBT 274"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Đường số 1"
    ,"Station_Address":"74, đường Trần Đại Nghĩa,  Quận Bình Tân"
    ,"Lat":10.724564
    ,"Long":106.59664
    ,"Polyline":"[106.59950256,10.72282028] ; [106.59860229,10.72331047] ; [106.59770203,10.72383976] ; [106.59662628,10.72447968]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3325"
    ,"Station_Code":"QBT 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Tứ Hưng"
    ,"Station_Address":"100A , đường Trần Đại Nghĩa, Quận Bình Tân"
    ,"Lat":10.726214
    ,"Long":106.59252
    ,"Polyline":"[106.59662628,10.72447968] ; [106.59590149,10.72476006] ; [106.59503174,10.72509003] ; [106.59248352,10.72607040]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3328"
    ,"Station_Code":"QBT 179"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"KCN Lê  Xuân An"
    ,"Station_Address":"112, đường Trần Đại Nghĩa, Quận Bình Tân"
    ,"Lat":10.727258
    ,"Long":106.589731
    ,"Polyline":"[106.59248352,10.72607040] ; [106.59161377,10.72642040] ; [106.59088135,10.72667980] ; [106.59040833,10.72688007] ; [106.58969879,10.72708988]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3326"
    ,"Station_Code":"QBT 180"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"KCN Nhân Tạo"
    ,"Station_Address":"202, đường Trần Đại Nghĩa, Quận Bình Tân"
    ,"Lat":10.728206
    ,"Long":106.586437
    ,"Polyline":"[106.58969879,10.72708988] ; [106.58943939,10.72716999] ; [106.58815765,10.72751999] ; [106.58721924,10.72782993] ; [106.58644104,10.72805023]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3327"
    ,"Station_Code":"QBT 181"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Đường số 8"
    ,"Station_Address":"258, đường Tr ần Đại Nghĩa, Quận Bình Tân"
    ,"Lat":10.729081
    ,"Long":106.583261
    ,"Polyline":"[106.58644104,10.72805023] ; [106.58590698,10.72821045] ; [106.58513641,10.72850990] ; [106.58435059,10.72873020] ; [106.58325958,10.72904968]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3329"
    ,"Station_Code":"HBC 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"cầu Cái Trung"
    ,"Station_Address":"Cột điện 70T, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.729893
    ,"Long":106.58
    ,"Polyline":"[106.58325958,10.72904968] ; [106.58174896,10.72951031] ; [106.58110046,10.72966003] ; [106.58000946,10.72982979]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3330"
    ,"Station_Code":"HBC 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Nhựa Chí Thành"
    ,"Station_Address":"Đối diện 611, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.730926
    ,"Long":106.575258
    ,"Polyline":"[106.58000946,10.72982979] ; [106.57969666,10.72988033] ; [106.57749939,10.73036957] ; [106.57531738,10.73083973]"
    ,"Distance":"614"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3331"
    ,"Station_Code":"HBC 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Công ty Mai Anh"
    ,"Station_Address":"Đối diện A7/17M, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.731706
    ,"Long":106.57191
    ,"Polyline":"[106.57531738,10.73083973] ; [106.57187653,10.73163033]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3332"
    ,"Station_Code":"HBC 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Công ty ROBOT"
    ,"Station_Address":"A7/17M, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.732465
    ,"Long":106.56852
    ,"Polyline":"[106.57187653,10.73163033] ; [106.56848145,10.73235989]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3333"
    ,"Station_Code":"HBC 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cơ sở Khoang giếng"
    ,"Station_Address":"B19/405K, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.733203
    ,"Long":106.565108
    ,"Polyline":"[106.56848145,10.73235989] ; [106.56504822,10.73311043]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3334"
    ,"Station_Code":"HBC 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Bao bì Trang Tín"
    ,"Station_Address":"B19/397, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.733936
    ,"Long":106.561552
    ,"Polyline":"[106.56504822,10.73311043] ; [106.56173706,10.73383045]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3335"
    ,"Station_Code":"HBC 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Công ty Hòa Kỳ"
    ,"Station_Address":"G16/82, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.734868
    ,"Long":106.557941
    ,"Polyline":"[106.56173706,10.73383045] ; [106.55921173,10.73441982] ; [106.55790710,10.73470020]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3336"
    ,"Station_Code":"HBC 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Phòng khám Đa khao Lê Minh Xuân"
    ,"Station_Address":"Đối diện B22/474, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.736903
    ,"Long":106.554508
    ,"Polyline":"[106.55790710,10.73470020] ; [106.55757904,10.73480988] ; [106.55737305,10.73491001] ; [106.55712128,10.73505974] ; [106.55608368,10.73573017] ; [106.55577850,10.73593044]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3337"
    ,"Station_Code":"HBC 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Đảo"
    ,"Station_Address":"G16/37, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.73909
    ,"Long":106.550243
    ,"Polyline":"[106.55577850,10.73593044] ; [106.55502319,10.73641014] ; [106.55365753,10.73711967]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3341"
    ,"Station_Code":"HBC 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Đường số 10"
    ,"Station_Address":"Đường số 10, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.740576
    ,"Long":106.547245
    ,"Polyline":"[106.55365753,10.73711967] ; [106.55149841,10.73822975] ; [106.55052185,10.73871040]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"3338"
    ,"Station_Code":"HBC 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Gia Hưng"
    ,"Station_Address":"Gia Hưng, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.742416
    ,"Long":106.543559
    ,"Polyline":"[106.55052185,10.73871040] ; [106.54794312,10.73999977] ; [106.54731750,10.74026012] ; [106.54615021,10.74083996]"
    ,"Distance":"536"
  },
  {
     "Route_Id":"84"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"KCN LÊ MINH XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường Trần Đại Ngh ĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":"[106.54615021,10.74083996] ; [106.54149628,10.74320030] ; [106.53951263,10.74421024]"
    ,"Distance":"819"
  }]