export const Route23 =[

    {
       "Route_Id":"23"
      ,"Station_Id":"1294"
      ,"Station_Code":"BX 66"
      ,"Station_Direction":"0"
      ,"Station_Order":"0"
      ,"Station_Name":"Bến xe Bình Mỹ"
      ,"Station_Address":"Chân cầu Phú Cường (Bình Mỹ), đường T ỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.979037
      ,"Long":106.64328
      ,"Polyline":""
      ,"Distance":""
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1313"
      ,"Station_Code":"HCC 248"
      ,"Station_Direction":"0"
      ,"Station_Order":"1"
      ,"Station_Name":"Ngã 3 Bến Đò"
      ,"Station_Address":"1976, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.97705
      ,"Long":106.6437
      ,"Polyline":"[106.64328003,10.97903728] ; [106.64340210,10.97905827] ; [106.64361572,10.97799969] ; [106.64373779,10.97705746] ; [106.64369965,10.97704983]"
      ,"Distance":"244"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1312"
      ,"Station_Code":"HCC 249"
      ,"Station_Direction":"0"
      ,"Station_Order":"2"
      ,"Station_Name":"Ngã 3 Bình Mỹ"
      ,"Station_Address":"Đối diện 2006 , đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.974117
      ,"Long":106.642334
      ,"Polyline":"[106.64369965,10.97704983] ; [106.64379120,10.97600365] ; [106.64373016,10.97478199] ; [106.64335632,10.97449780] ; [106.64233398,10.97411728]"
      ,"Distance":"424"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1315"
      ,"Station_Code":"QCCT350"
      ,"Station_Direction":"0"
      ,"Station_Order":"3"
      ,"Station_Name":"cầu Bà B ếp"
      ,"Station_Address":"1785 (Đối diện 1930), đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.973349571228027
      ,"Long":106.63815307617188
      ,"Polyline":"[106.64233398,10.97411728] ; [106.64066315,10.97348690] ; [106.63815308,10.97334957]"
      ,"Distance":"470"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1314"
      ,"Station_Code":"QCCT351"
      ,"Station_Direction":"0"
      ,"Station_Order":"4"
      ,"Station_Name":"Ngã 3 Cây Gòn"
      ,"Station_Address":"1730, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.973250389099121
      ,"Long":106.63304901123047
      ,"Polyline":"[106.63815308,10.97334957] ; [106.63549042,10.97323418] ; [106.63304901,10.97325039]"
      ,"Distance":"558"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1316"
      ,"Station_Code":"QCCT352"
      ,"Station_Direction":"0"
      ,"Station_Order":"5"
      ,"Station_Name":"UBND Hòa Phú"
      ,"Station_Address":"Đối diện 1728, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.973966598510742
      ,"Long":106.62844848632812
      ,"Polyline":"[106.63304901,10.97325039] ; [106.63187408,10.97339153] ; [106.62844849,10.97396660]"
      ,"Distance":"509"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1317"
      ,"Station_Code":"QCCT353"
      ,"Station_Direction":"0"
      ,"Station_Order":"6"
      ,"Station_Name":"Trường  Hòa Phú"
      ,"Station_Address":"1575, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.975850105285645
      ,"Long":106.62303161621094
      ,"Polyline":"[106.62844849,10.97396660] ; [106.62669373,10.97427654] ; [106.62496185,10.97495079] ; [106.62303162,10.97585011]"
      ,"Distance":"632"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1318"
      ,"Station_Code":"QCCT354"
      ,"Station_Direction":"0"
      ,"Station_Order":"7"
      ,"Station_Name":"Ngã 3 Lò Chén"
      ,"Station_Address":"1539, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.977717399597168
      ,"Long":106.62020111083984
      ,"Polyline":"[106.62303162,10.97585011] ; [106.62207794,10.97643566] ; [106.62020111,10.97771740]"
      ,"Distance":"373"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1319"
      ,"Station_Code":"QCCT355"
      ,"Station_Direction":"0"
      ,"Station_Order":"8"
      ,"Station_Name":"Ngã 3 Bù Na"
      ,"Station_Address":"1477 (1655), đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.978767395019531
      ,"Long":106.61833190917969
      ,"Polyline":"[106.62020111,10.97771740] ; [106.61833191,10.97876740]"
      ,"Distance":"235"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1320"
      ,"Station_Code":"QCCT356"
      ,"Station_Direction":"0"
      ,"Station_Order":"9"
      ,"Station_Name":"Cây xăng Phú Thịnh"
      ,"Station_Address":"1429C, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.98157024383545
      ,"Long":106.60431671142578
      ,"Polyline":"[106.60913849,10.98058033] ; [106.60430145,10.98145962]"
      ,"Distance":"1575"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1323"
      ,"Station_Code":"QCCT357"
      ,"Station_Direction":"0"
      ,"Station_Order":"10"
      ,"Station_Name":"Ngã 3 Trung An"
      ,"Station_Address":"1405, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.982413291931152
      ,"Long":106.59909057617188
      ,"Polyline":"[106.60431671,10.98157024] ; [106.60430145,10.98145962] ; [106.60044098,10.98220730] ; [106.59908295,10.98223019] ; [106.59909058,10.98241329]"
      ,"Distance":"611"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1321"
      ,"Station_Code":"QCCT358"
      ,"Station_Direction":"0"
      ,"Station_Order":"11"
      ,"Station_Name":"Công ty SEAWA"
      ,"Station_Address":"1339, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.982749938964844
      ,"Long":106.5931396484375
      ,"Polyline":"[106.59908295,10.98223019] ; [106.59481049,10.98246956] ; [106.59313202,10.98258018]"
      ,"Distance":"691"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1324"
      ,"Station_Code":"QCCT359"
      ,"Station_Direction":"0"
      ,"Station_Order":"12"
      ,"Station_Name":"Công ty Samho"
      ,"Station_Address":"Đối diện 1378 , đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.982950210571289
      ,"Long":106.5898666381836
      ,"Polyline":"[106.59313965,10.98274994] ; [106.59313202,10.98258018] ; [106.59150696,10.98272896] ; [106.58985138,10.98279953] ; [106.58986664,10.98295021]"
      ,"Distance":"395"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1322"
      ,"Station_Code":"QCCT360"
      ,"Station_Direction":"0"
      ,"Station_Order":"13"
      ,"Station_Name":"Trường PTTH Tân Phú Trung"
      ,"Station_Address":"749, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.983782768249512
      ,"Long":106.57693481445312
      ,"Polyline":"[106.58985138,10.98279953] ; [106.58725739,10.98301029] ; [106.58502960,10.98314953] ; [106.57692719,10.98367977]"
      ,"Distance":"1444"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1325"
      ,"Station_Code":"QCCT361"
      ,"Station_Direction":"0"
      ,"Station_Order":"14"
      ,"Station_Name":"Bến xe Tân Quy"
      ,"Station_Address":"30, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.983866691589355
      ,"Long":106.57569122314453
      ,"Polyline":"[106.57692719,10.98367977] ; [106.57569122,10.98377037]"
      ,"Distance":"158"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1326"
      ,"Station_Code":"QCCT362"
      ,"Station_Direction":"0"
      ,"Station_Order":"15"
      ,"Station_Name":"Chợ Tân Quy"
      ,"Station_Address":"120 (Lẩu dê Tài Ký), đường Tỉnh lộ 8, Củ Chi, Huyện C ủ Chi"
      ,"Lat":10.984108924865723
      ,"Long":106.57317352294922
      ,"Polyline":"[106.57569122,10.98377037] ; [106.57315826,10.98394012]"
      ,"Distance":"307"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1327"
      ,"Station_Code":"QCCT363"
      ,"Station_Direction":"0"
      ,"Station_Order":"16"
      ,"Station_Name":"Cây xăng Tân Thạnh"
      ,"Station_Address":"178-180, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.984267234802246
      ,"Long":106.56999206542969
      ,"Polyline":"[106.57317352,10.98410892] ; [106.57315826,10.98394012] ; [106.57149506,10.98407173] ; [106.56999207,10.98414040] ; [106.56999207,10.98426723]"
      ,"Distance":"380"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1328"
      ,"Station_Code":"QCCT364"
      ,"Station_Direction":"0"
      ,"Station_Order":"17"
      ,"Station_Name":"Xí nghiệp cá Chợ Lớn"
      ,"Station_Address":"252, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.984624862670898
      ,"Long":106.56585693359375
      ,"Polyline":"[106.56999207,10.98414040] ; [106.56584167,10.98445034]"
      ,"Distance":"488"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1329"
      ,"Station_Code":"QCCT365"
      ,"Station_Direction":"0"
      ,"Station_Order":"18"
      ,"Station_Name":"Trạm y tế xã Tân Thạnh Tây"
      ,"Station_Address":"420, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.984856605529785
      ,"Long":106.56282043457031
      ,"Polyline":"[106.56584167,10.98445034] ; [106.56279755,10.98468018]"
      ,"Distance":"373"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1330"
      ,"Station_Code":"QCCT366"
      ,"Station_Direction":"0"
      ,"Station_Order":"19"
      ,"Station_Name":"Trường trung học Tân Thạnh Tây"
      ,"Station_Address":"368A, đường Tỉnh lộ 8, Củ  Chi, Huyện Củ Chi"
      ,"Lat":10.985025405883789
      ,"Long":106.55884552001953
      ,"Polyline":"[106.56282043,10.98485661] ; [106.56279755,10.98468018] ; [106.56021118,10.98488045] ; [106.55978394,10.98492527] ; [106.55935669,10.98491955] ; [106.55886078,10.98488045] ; [106.55884552,10.98502541]"
      ,"Distance":"468"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1331"
      ,"Station_Code":"QCCT367"
      ,"Station_Direction":"0"
      ,"Station_Order":"20"
      ,"Station_Name":"Ấp VH T ân Thạnh Tây"
      ,"Station_Address":"Kế 428A, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.984330177307129
      ,"Long":106.55010223388672
      ,"Polyline":"[106.55886078,10.98488045] ; [106.55242157,10.98433971] ; [106.55045319,10.98416996] ; [106.55014801,10.98410988]"
      ,"Distance":"997"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1332"
      ,"Station_Code":"QCCT368"
      ,"Station_Direction":"0"
      ,"Station_Order":"21"
      ,"Station_Name":"Đình Tân Thạnh Tây"
      ,"Station_Address":"470B, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.985541343688965
      ,"Long":106.54344177246094
      ,"Polyline":"[106.55014801,10.98410988] ; [106.54821777,10.98369026] ; [106.54765320,10.98361015] ; [106.54733276,10.98361969] ; [106.54704285,10.98367977] ; [106.54650116,10.98388004] ; [106.54535675,10.98439026] ; [106.54422760,10.98491001] ; [106.54337311,10.98542023]"
      ,"Distance":"832"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1334"
      ,"Station_Code":"QCCT369"
      ,"Station_Direction":"0"
      ,"Station_Order":"22"
      ,"Station_Name":"Công viên nước Củ Chi"
      ,"Station_Address":"Đối diện cây xăng Thiện Nghĩa, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.985257148742676
      ,"Long":106.53321838378906
      ,"Polyline":"[106.54337311,10.98542023] ; [106.54268646,10.98577976] ; [106.54232025,10.98591042] ; [106.54178619,10.98602009] ; [106.54158020,10.98604012] ; [106.54118347,10.98602009] ; [106.53806305,10.98569965] ; [106.53736115,10.98561954] ; [106.53323364,10.98515034]"
      ,"Distance":"1155"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1333"
      ,"Station_Code":"QCCT370"
      ,"Station_Direction":"0"
      ,"Station_Order":"23"
      ,"Station_Name":"Ngã 3 Bù Giả"
      ,"Station_Address":"Cột điện PVA 84, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.98496150970459
      ,"Long":106.53040313720703
      ,"Polyline":"[106.53323364,10.98515034] ; [106.53043365,10.98480988]"
      ,"Distance":"338"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1338"
      ,"Station_Code":"QCCT371"
      ,"Station_Direction":"0"
      ,"Station_Order":"24"
      ,"Station_Name":"Ngã 4 Cây Bài"
      ,"Station_Address":"597, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.984624862670898
      ,"Long":106.5265121459961
      ,"Polyline":"[106.53043365,10.98480988] ; [106.52931976,10.98466969] ; [106.52768707,10.98451996] ; [106.52696228,10.98443985] ; [106.52651215,10.98445034]"
      ,"Distance":"467"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1335"
      ,"Station_Code":"QCCT372"
      ,"Station_Direction":"0"
      ,"Station_Order":"25"
      ,"Station_Name":"Trường mầm non Bông Sen 13"
      ,"Station_Address":"Trường mầm non Bông Sen 13, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.985393524169922
      ,"Long":106.522216796875
      ,"Polyline":"[106.52651215,10.98445034] ; [106.52615356,10.98451996] ; [106.52410889,10.98501968] ; [106.52301788,10.98530960] ; [106.52291107,10.98532009] ; [106.52258301,10.98530960] ; [106.52226257,10.98523045]"
      ,"Distance":"516"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1339"
      ,"Station_Code":"QCCT373"
      ,"Station_Direction":"0"
      ,"Station_Order":"26"
      ,"Station_Name":"Trường THCS PVA"
      ,"Station_Address":"521, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.98465633392334
      ,"Long":106.5196304321289
      ,"Polyline":"[106.52226257,10.98523045] ; [106.51966095,10.98456001]"
      ,"Distance":"324"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1336"
      ,"Station_Code":"QCCT374"
      ,"Station_Direction":"0"
      ,"Station_Order":"27"
      ,"Station_Name":"Cây xăng Hoàng Sơn"
      ,"Station_Address":"Đối diện 546, đường Tỉnh lộ 8, Củ Chi , Huyện Củ Chi"
      ,"Lat":10.983908653259277
      ,"Long":106.51656341552734
      ,"Polyline":"[106.51966095,10.98456001] ; [106.51721191,10.98392963] ; [106.51660919,10.98375034]"
      ,"Distance":"375"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1341"
      ,"Station_Code":"QCCT375"
      ,"Station_Direction":"0"
      ,"Station_Order":"28"
      ,"Station_Name":"Đồng Dù"
      ,"Station_Address":"399, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.978233337402344
      ,"Long":106.50348663330078
      ,"Polyline":"[106.51656342,10.98390865] ; [106.51660919,10.98375034] ; [106.51361084,10.98301983] ; [106.51073456,10.98231316] ; [106.50348663,10.97823334]"
      ,"Distance":"1593"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1343"
      ,"Station_Code":"QCCT380"
      ,"Station_Direction":"0"
      ,"Station_Order":"29"
      ,"Station_Name":"Trung tâm văn hóa Huyện Củ Chi"
      ,"Station_Address":"Trung tâm văn hóa Huyện Củ Chi, đường Tỉnh lộ 8, C ủ Chi, Huyện Củ Chi"
      ,"Lat":10.976451873779297
      ,"Long":106.50028991699219
      ,"Polyline":"[106.50348663,10.97823334] ; [106.50028992,10.97645187]"
      ,"Distance":"402"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1342"
      ,"Station_Code":"QCCT378"
      ,"Station_Direction":"0"
      ,"Station_Order":"30"
      ,"Station_Name":"Bưu điện  Củ Chi"
      ,"Station_Address":"Đối diện bưu  điện Củ Chi, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.973015785217285
      ,"Long":106.49436950683594
      ,"Polyline":"[106.50028992,10.97645187] ; [106.49436951,10.97301579]"
      ,"Distance":"752"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1340"
      ,"Station_Code":"QCCT379"
      ,"Station_Direction":"0"
      ,"Station_Order":"31"
      ,"Station_Name":"Trường mầm non Bông Hồng"
      ,"Station_Address":"Đối diện 116 (trường mầm non Bông Hồng), đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.971217155456543
      ,"Long":106.49118041992188
      ,"Polyline":"[106.49436951,10.97301579] ; [106.49118042,10.97121716]"
      ,"Distance":"402"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1345"
      ,"Station_Code":"QCCT377"
      ,"Station_Direction":"0"
      ,"Station_Order":"32"
      ,"Station_Name":"UBND Thị trấn Củ Chi"
      ,"Station_Address":"Trung tâm văn hóa Củ Chi (185-187), đường Tỉnh lộ 8, Củ Chi , Huyện Củ Chi"
      ,"Lat":10.969266891479492
      ,"Long":106.48780059814453
      ,"Polyline":"[106.49118042,10.97121716] ; [106.48780060,10.96926689]"
      ,"Distance":"428"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"732"
      ,"Station_Code":"BX 63"
      ,"Station_Direction":"0"
      ,"Station_Order":"33"
      ,"Station_Name":"Bến xe Củ Chi"
      ,"Station_Address":"Bến xe Củ Chi, đường Quốc  lộ 22, Huyện Củ Chi"
      ,"Lat":10.971617
      ,"Long":106.482099
      ,"Polyline":"[106.48780060,10.96926689] ; [106.48781586,10.96917915] ; [106.48647308,10.96865749] ; [106.48620605,10.96864700] ; [106.48601532,10.96868420] ; [106.48587036,10.96858883] ; [106.48506165,10.96904182] ; [106.48248291,10.97075844] ; [106.48181152,10.97130680] ; [106.48210144,10.97161674]"
      ,"Distance":"822"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"732"
      ,"Station_Code":"BX 63"
      ,"Station_Direction":"1"
      ,"Station_Order":"0"
      ,"Station_Name":"Bến xe Củ Chi"
      ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
      ,"Lat":10.971617
      ,"Long":106.482099
      ,"Polyline":""
      ,"Distance":""
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1263"
      ,"Station_Code":"HCC 211"
      ,"Station_Direction":"1"
      ,"Station_Order":"1"
      ,"Station_Name":"Ngã 3 Quảng Việt"
      ,"Station_Address":"12, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.9689
      ,"Long":106.487335
      ,"Polyline":"[106.48210144,10.97161674] ; [106.48178101,10.97136402] ; [106.48159790,10.97151184] ; [106.48146057,10.97137451] ; [106.48246765,10.97049522] ; [106.48453522,10.96907330] ; [106.48580170,10.96833611] ; [106.48614502,10.96818829] ; [106.48635864,10.96832561] ; [106.48636627,10.96849442] ; [106.48733521,10.96889973]"
      ,"Distance":"878"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1265"
      ,"Station_Code":"HCC 212"
      ,"Station_Direction":"1"
      ,"Station_Order":"2"
      ,"Station_Name":"Nhà truy ền thống"
      ,"Station_Address":"110, đường Tỉnh  lộ 8, Huyện Củ Chi"
      ,"Lat":10.970833
      ,"Long":106.490799
      ,"Polyline":"[106.48733521,10.96889973] ; [106.49079895,10.97083282]"
      ,"Distance":"435"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1259"
      ,"Station_Code":"HCC 213"
      ,"Station_Direction":"1"
      ,"Station_Order":"3"
      ,"Station_Name":"Bưu điện Củ Chi"
      ,"Station_Address":"Bưu điện Củ Chi, đường Tỉnh lộ 8, Cu ̉ Chi, Huyện Củ Chi"
      ,"Lat":10.972844
      ,"Long":106.494354
      ,"Polyline":"[106.49079895,10.97083282] ; [106.49435425,10.97284412]"
      ,"Distance":"448"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1262"
      ,"Station_Code":"HCC 214"
      ,"Station_Direction":"1"
      ,"Station_Order":"4"
      ,"Station_Name":"Ngã 3 Quảng Việt"
      ,"Station_Address":"274, đường Tỉnh lộ 8, Củ Chi, Huy ện Củ Chi"
      ,"Lat":10.975533
      ,"Long":106.499001
      ,"Polyline":"[106.49435425,10.97284412] ; [106.49900055,10.97553253]"
      ,"Distance":"589"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1264"
      ,"Station_Code":"HCC 216"
      ,"Station_Direction":"1"
      ,"Station_Order":"5"
      ,"Station_Name":"Trường dạy nghề"
      ,"Station_Address":"506, đường Tỉnh lộ 8, Củ Chi, Huyện Củ  Chi"
      ,"Lat":10.981067
      ,"Long":106.508751
      ,"Polyline":"[106.49900055,10.97553253] ; [106.50875092,10.98106670]"
      ,"Distance":"1231"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1270"
      ,"Station_Code":"HCC 217"
      ,"Station_Direction":"1"
      ,"Station_Order":"6"
      ,"Station_Name":"Đồng Dù"
      ,"Station_Address":"552, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.983466
      ,"Long":106.516159
      ,"Polyline":"[106.50875092,10.98106670] ; [106.51067352,10.98222828] ; [106.51615906,10.98346615]"
      ,"Distance":"862"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1272"
      ,"Station_Code":"HCC 218"
      ,"Station_Direction":"1"
      ,"Station_Order":"7"
      ,"Station_Name":"Cây xăng Hoàng Sơn"
      ,"Station_Address":"606B, đường T ỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.984257
      ,"Long":106.519234
      ,"Polyline":"[106.51615906,10.98346615] ; [106.51614380,10.98363495] ; [106.51921844,10.98441410.06.51923370]"
      ,"Distance":"384"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1266"
      ,"Station_Code":"QCCT320"
      ,"Station_Direction":"1"
      ,"Station_Order":"8"
      ,"Station_Name":"Trường cấp 2 Phước Vĩnh An"
      ,"Station_Address":"Đối diện 543A, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.984888076782227
      ,"Long":106.52173614501953
      ,"Polyline":"[106.51923370,10.98425674] ; [106.51918793,10.98443985] ; [106.52170563,10.98504066] ; [106.52173615,10.98488808]"
      ,"Distance":"321"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1274"
      ,"Station_Code":"HCC 220"
      ,"Station_Direction":"1"
      ,"Station_Order":"9"
      ,"Station_Name":"UBND Phước Vĩnh An"
      ,"Station_Address":"738, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.984414
      ,"Long":106.525749
      ,"Polyline":"[106.52173615,10.98488808] ; [106.52169037,10.98507977] ; [106.52278900,10.98532963] ; [106.52580261,10.98460960] ; [106.52574921,10.98441410]"
      ,"Distance":"507"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1267"
      ,"Station_Code":"QCCT322"
      ,"Station_Direction":"1"
      ,"Station_Order":"10"
      ,"Station_Name":"Ngã 3 C ây Bài"
      ,"Station_Address":"Kế 786, đường Tỉnh lộ 8, Củ Chi, Huyện Củ  Chi"
      ,"Lat":10.984593391418457
      ,"Long":106.5299301147461
      ,"Polyline":"[106.52574921,10.98441410.06.52578735] ; [10.98454571,106.52692413] ; [10.98436642,106.52988434] ; [10.98468304,106.52993011]"
      ,"Distance":"478"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1276"
      ,"Station_Code":"QCCT323"
      ,"Station_Direction":"1"
      ,"Station_Order":"11"
      ,"Station_Name":"Ngã 3 Bù Giả"
      ,"Station_Address":"Cột điện KCN/TQ 104, đường Tỉnh lộ 8, Củ Chi , Huyện Củ Chi"
      ,"Lat":10.985025405883789
      ,"Long":106.53369140625
      ,"Polyline":"[106.52990723,10.98474026] ; [106.53366852,10.98519993]"
      ,"Distance":"450"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1269"
      ,"Station_Code":"HCC 223"
      ,"Station_Direction":"1"
      ,"Station_Order":"12"
      ,"Station_Name":"Công viên nước Củ Chi"
      ,"Station_Address":"Đối diện 472, đường Tỉnh lộ 8, Củ Chi , Huyện Củ Chi"
      ,"Lat":10.985562
      ,"Long":106.542633
      ,"Polyline":"[106.53369141,10.98502541] ; [106.54116058,10.98593616] ; [106.54161072,10.98599434] ; [106.54228210,10.98587799] ; [106.54270935,10.98571968] ; [106.54263306,10.98556232]"
      ,"Distance":"1016"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1271"
      ,"Station_Code":"HCC 224"
      ,"Station_Direction":"1"
      ,"Station_Order":"13"
      ,"Station_Name":"Đình Tân Thạnh Tây"
      ,"Station_Address":"415, đường T ỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.984067
      ,"Long":106.550735
      ,"Polyline":"[106.54273987,10.98575974] ; [106.54309845,10.98558044] ; [106.54422760,10.98491001] ; [106.54535675,10.98439026] ; [106.54650116,10.98388004] ; [106.54704285,10.98367977] ; [106.54733276,10.98361969] ; [106.54765320,10.98361015] ; [106.54821777,10.98369026] ; [106.55045319,10.98416996] ; [106.55072784,10.98418999]"
      ,"Distance":"974"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1278"
      ,"Station_Code":"HCC 225"
      ,"Station_Direction":"1"
      ,"Station_Order":"14"
      ,"Station_Name":"Nhà máy chà lúa Tân Thạnh Tây"
      ,"Station_Address":"369, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.984719
      ,"Long":106.559448
      ,"Polyline":"[106.55072784,10.98418999] ; [106.55554199,10.98460960] ; [106.55944824,10.98491955]"
      ,"Distance":"992"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1273"
      ,"Station_Code":"HCC 226"
      ,"Station_Direction":"1"
      ,"Station_Order":"15"
      ,"Station_Name":"Ấp VH T ân Thạnh Tây"
      ,"Station_Address":"327, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.984499
      ,"Long":106.563255
      ,"Polyline":"[106.55944824,10.98491955] ; [106.56021118,10.98488045] ; [106.56136322,10.98478985] ; [106.56327057,10.98464012]"
      ,"Distance":"457"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1280"
      ,"Station_Code":"HCC 227"
      ,"Station_Direction":"1"
      ,"Station_Order":"16"
      ,"Station_Name":"Trường cấp 1 Tân Thạnh Tây"
      ,"Station_Address":"245-247, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.984224
      ,"Long":106.566597
      ,"Polyline":"[106.56327057,10.98464012] ; [106.56661224,10.98439980]"
      ,"Distance":"402"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1275"
      ,"Station_Code":"HCC 228"
      ,"Station_Direction":"1"
      ,"Station_Order":"17"
      ,"Station_Name":"UBND Tân Thạnh Tây"
      ,"Station_Address":"193, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.98394
      ,"Long":106.570595
      ,"Polyline":"[106.56661224,10.98439980] ; [106.57061005,10.98410034]"
      ,"Distance":"476"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1277"
      ,"Station_Code":"HCC 229"
      ,"Station_Direction":"1"
      ,"Station_Order":"18"
      ,"Station_Name":"Ngã 3 Cống Tân Thạnh Tây"
      ,"Station_Address":"113 - 115, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.983783
      ,"Long":106.572838
      ,"Polyline":"[106.57061005,10.98410034] ; [106.57285309,10.98396015]"
      ,"Distance":"283"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1279"
      ,"Station_Code":"HCC 230"
      ,"Station_Direction":"1"
      ,"Station_Order":"19"
      ,"Station_Name":"Cây xăng  Tân Thạnh"
      ,"Station_Address":"27, đường Tỉnh  lộ 8, Huyện Củ Chi"
      ,"Lat":10.983593
      ,"Long":106.575165
      ,"Polyline":"[106.57285309,10.98396015] ; [106.57518005,10.98379993]"
      ,"Distance":"298"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1281"
      ,"Station_Code":"HCC 231"
      ,"Station_Direction":"1"
      ,"Station_Order":"20"
      ,"Station_Name":"Chợ Tân Quy"
      ,"Station_Address":"739, đường Tỉnh l ộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.98333
      ,"Long":106.579628
      ,"Polyline":"[106.57518005,10.98379993] ; [106.57795715,10.98359966] ; [106.57964325,10.98349953]"
      ,"Distance":"531"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1283"
      ,"Station_Code":"HCC 232"
      ,"Station_Direction":"1"
      ,"Station_Order":"21"
      ,"Station_Name":"Trường PTTH Trung Phú"
      ,"Station_Address":"1392, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.983067
      ,"Long":106.583771
      ,"Polyline":"[106.57964325,10.98349953] ; [106.58377838,10.98324013]"
      ,"Distance":"491"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1282"
      ,"Station_Code":"QCCT334"
      ,"Station_Direction":"1"
      ,"Station_Order":"22"
      ,"Station_Name":"Bến xe Tân Quy"
      ,"Station_Address":"S ửa xe Khanh Chiến, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.982697486877441
      ,"Long":106.58916473388672
      ,"Polyline":"[106.58377838,10.98324013] ; [106.58576965,10.98309994] ; [106.58725739,10.98301029] ; [106.58917999,10.98285007]"
      ,"Distance":"628"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1284"
      ,"Station_Code":"HCC 235"
      ,"Station_Direction":"1"
      ,"Station_Order":"23"
      ,"Station_Name":"Công ty Samho"
      ,"Station_Address":"1504, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.982371
      ,"Long":106.593651
      ,"Polyline":"[106.58917999,10.98285007] ; [106.59176636,10.98266983] ; [106.59365845,10.98254013]"
      ,"Distance":"527"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1285"
      ,"Station_Code":"QCCT336"
      ,"Station_Direction":"1"
      ,"Station_Order":"24"
      ,"Station_Name":"Trường tiểu học Trung An"
      ,"Station_Address":"1556, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.982118606567383
      ,"Long":106.59819793701172
      ,"Polyline":"[106.59365845,10.98254013] ; [106.59821320,10.98227978]"
      ,"Distance":"535"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1286"
      ,"Station_Code":"HCC 237"
      ,"Station_Direction":"1"
      ,"Station_Order":"25"
      ,"Station_Name":"Trại hòm Huệ Tân"
      ,"Station_Address":"1606, đường Tỉnh  lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.981434
      ,"Long":106.603294
      ,"Polyline":"[106.59821320,10.98227978] ; [106.59986877,10.98219013] ; [106.60285950,10.98169994] ; [106.60333252,10.98161983]"
      ,"Distance":"604"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1287"
      ,"Station_Code":"QCCT338"
      ,"Station_Direction":"1"
      ,"Station_Order":"26"
      ,"Station_Name":"Ngã 3 Trung An"
      ,"Station_Address":"Đối diện 1533, đường Tỉnh lộ 8, Củ Chi, Huy ện Củ Chi"
      ,"Lat":10.980569839477539
      ,"Long":106.60810089111328
      ,"Polyline":"[106.60333252,10.98161983] ; [106.60813904,10.98075962]"
      ,"Distance":"577"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1288"
      ,"Station_Code":"QCCT339"
      ,"Station_Direction":"1"
      ,"Station_Order":"27"
      ,"Station_Name":"Cây xăng Phú Thuận"
      ,"Station_Address":"Đối diện 1567 , đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.979853630065918
      ,"Long":106.61223602294922
      ,"Polyline":"[106.60813904,10.98075962] ; [106.61135864,10.98019981] ; [106.61226654,10.98003006]"
      ,"Distance":"500"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1289"
      ,"Station_Code":"HCC 240"
      ,"Station_Direction":"1"
      ,"Station_Order":"28"
      ,"Station_Name":"Ngã 3 Bù Na"
      ,"Station_Address":"1722, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.97919
      ,"Long":106.615364
      ,"Polyline":"[106.61226654,10.98003006] ; [106.61463165,10.97959042] ; [106.61541748,10.97943974]"
      ,"Distance":"399"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1291"
      ,"Station_Code":"HCC 241"
      ,"Station_Direction":"1"
      ,"Station_Order":"29"
      ,"Station_Name":"Ngã 3 L ò Chén"
      ,"Station_Address":"1820, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.9771
      ,"Long":106.620903
      ,"Polyline":"[106.61541748,10.97943974] ; [106.61660004,10.97920036] ; [106.61724854,10.97904968] ; [106.61788177,10.97887993] ; [106.61856079,10.97861004] ; [106.61904144,10.97836018] ; [106.61962891,10.97803974] ; [106.62023926,10.97764969] ; [106.62075806,10.97727013]"
      ,"Distance":"693"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1295"
      ,"Station_Code":"HCC 242"
      ,"Station_Direction":"1"
      ,"Station_Order":"30"
      ,"Station_Name":"Ngã 3 Bến Đò"
      ,"Station_Address":"KCN Đông Nam cửa A (2010B), đường Tỉnh lộ 8, Cu ̉ Chi, Huyện Củ Chi"
      ,"Lat":10.975667
      ,"Long":106.623184
      ,"Polyline":"[106.62090302,10.97710037] ; [106.62217712,10.97620392] ; [106.62318420,10.97566700]"
      ,"Distance":"297"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1290"
      ,"Station_Code":"HCC 243"
      ,"Station_Direction":"1"
      ,"Station_Order":"31"
      ,"Station_Name":"UBND Hòa Phú"
      ,"Station_Address":"Đối diện 1781, đường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.974
      ,"Long":106.627769
      ,"Polyline":"[106.62318420,10.97566700] ; [106.62447357,10.97505569] ; [106.62660217,10.97418213] ; [106.62776947,10.97399998]"
      ,"Distance":"538"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1293"
      ,"Station_Code":"HCC 244"
      ,"Station_Direction":"1"
      ,"Station_Order":"32"
      ,"Station_Name":"cầu Bà B ếp"
      ,"Station_Address":"1926C, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.9731
      ,"Long":106.633865
      ,"Polyline":"[106.62776947,10.97399998] ; [106.63222504,10.97321320] ; [106.63386536,10.97309971]"
      ,"Distance":"675"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1292"
      ,"Station_Code":"HCC 245"
      ,"Station_Direction":"1"
      ,"Station_Order":"33"
      ,"Station_Name":"Ngã 3 Bình Mỹ"
      ,"Station_Address":"1960, đ ường Tỉnh lộ 8, Huyện Củ Chi"
      ,"Lat":10.973233
      ,"Long":106.638634
      ,"Polyline":"[106.63386536,10.97309971] ; [106.63863373,10.97323322]"
      ,"Distance":"521"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1310"
      ,"Station_Code":"HCC 247"
      ,"Station_Direction":"1"
      ,"Station_Order":"34"
      ,"Station_Name":"Cầu Phú Cường"
      ,"Station_Address":"2114, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
      ,"Lat":10.977467
      ,"Long":106.643768
      ,"Polyline":"[106.63863373,10.97323322] ; [106.64061737,10.97336006] ; [106.64388275,10.97470856] ; [106.64394379,10.97609901] ; [106.64376831,10.97746658]"
      ,"Distance":"913"
    },
    {
       "Route_Id":"23"
      ,"Station_Id":"1294"
      ,"Station_Code":"BX 66"
      ,"Station_Direction":"1"
      ,"Station_Order":"35"
      ,"Station_Name":"Bến xe Bình Mỹ"
      ,"Station_Address":"Chân cầu Phú Cường (Bình Mỹ), đường Tỉnh lộ 8, Củ Chi, Huyện C ủ Chi"
      ,"Lat":10.979037
      ,"Long":106.64328
      ,"Polyline":"[106.64376831,10.97746658] ; [106.64350128,10.97905827] ; [106.64328003,10.97903728]"
      ,"Distance":"204"
    }]