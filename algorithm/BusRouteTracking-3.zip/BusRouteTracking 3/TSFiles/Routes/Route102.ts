export const Route102 =[

  {
     "Route_Id":"102"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22 , Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"171"
    ,"Station_Code":"Q12 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"601, đường Trường Chinh, Quận 12"
    ,"Lat":10.841209
    ,"Long":106.615925
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61504364,10.84255981] ; [106.61511993,10.84243011] ; [106.61530304,10.84235001] ; [106.61535645,10.84234047] ; [106.61546326,10.84218979] ; [106.61605835,10.84127045]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"167"
    ,"Station_Code":"Q12 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"487, đường Trường Chinh, Quận 12"
    ,"Lat":10.837863
    ,"Long":106.618044
    ,"Polyline":"[106.61605835,10.84127045] ; [106.61820221,10.83794975]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"172"
    ,"Station_Code":"Q12 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa L ạc Quang"
    ,"Station_Address":"257, đường Trư ờng Chinh, Quận 12"
    ,"Lat":10.834623
    ,"Long":106.620163
    ,"Polyline":"[106.61820221,10.83794975] ; [106.62029266,10.83471012]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"168"
    ,"Station_Code":"Q12 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"Chùa Vĩnh Phước, đường Trường Chinh , Quận 12"
    ,"Lat":10.831836
    ,"Long":106.621928
    ,"Polyline":"[106.62029266,10.83471012] ; [106.62207794,10.83191967]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"170"
    ,"Station_Code":"Q12 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"113, đường Trường Chinh, Quận 12"
    ,"Lat":10.82898
    ,"Long":106.623768
    ,"Polyline":"[106.62207794,10.83191967] ; [106.62387848,10.82913017]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đư ờng Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62387848,10.82913017] ; [106.62487793,10.82758999] ; [106.62512207,10.82730007] ; [106.62560272,10.82676029] ; [106.62599182,10.82637978]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trư ờng Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62599182,10.82637978] ; [106.62699890,10.82542038] ; [106.62803650,10.82446957] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm KCN Tân Bình"
    ,"Station_Address":"881, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63089752,10.81947041]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chế Lan  Viên"
    ,"Station_Address":"28/7B, đường Trường  Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2292"
    ,"Station_Code":"QTP 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm Nhà Hàng Thượng Uyển"
    ,"Station_Address":"1/1, đường Trường Chinh, Qu ận Tân Phú"
    ,"Lat":10.806212
    ,"Long":106.634773
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63448334,10.80760002] ; [106.63481903,10.80665016] ; [106.63497925,10.80636978]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2291"
    ,"Station_Code":"QTP 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"33/24 (659-661 ), đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.8048
    ,"Long":106.635269
    ,"Polyline":"[106.63500977,10.80628967] ; [106.63530731,10.80535984] ; [106.63545990,10.80486012]"
    ,"Distance":"166"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2294"
    ,"Station_Code":"QTP 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm B à Quẹo"
    ,"Station_Address":"593A, đường Trường  Chinh, Quận Tân Phú"
    ,"Lat":10.80215
    ,"Long":106.63633
    ,"Polyline":"[106.63545990,10.80486012] ; [106.63601685,10.80313015] ; [106.63610840,10.80288029] ; [106.63636780,10.80230999] ; [106.63642883,10.80220985] ; [106.63632202,10.80216980]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2293"
    ,"Station_Code":"QTB 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Võ Thành Trang"
    ,"Station_Address":"541, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.801391
    ,"Long":106.637308
    ,"Polyline":"[106.63632202,10.80216980] ; [106.63642883,10.80220985] ; [106.63643646,10.80220032] ; [106.63672638,10.80177975] ; [106.63688660,10.80173016] ; [106.63787842,10.80119038] ; [106.63842773,10.80088997]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2296"
    ,"Station_Code":"QTB 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã ba Trương Công Định"
    ,"Station_Address":"403, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.799115
    ,"Long":106.641557
    ,"Polyline":"[106.63842773,10.80088997] ; [106.64115906,10.79942036] ; [106.64158630,10.79918957]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2559"
    ,"Station_Code":"QTB 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã ba Hồng Đào"
    ,"Station_Address":"351, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797666
    ,"Long":106.644266
    ,"Polyline":"[106.64158630,10.79918957] ; [106.64311218,10.79839039] ; [106.64376831,10.79806042] ; [106.64431763,10.79776001]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1392"
    ,"Station_Code":"QTB 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"233, đ ường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796426
    ,"Long":106.646553
    ,"Polyline":"[106.64431763,10.79776001] ; [106.64660645,10.79652023]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1826"
    ,"Station_Code":"QTB 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà th ờ Đắc Lộ"
    ,"Station_Address":"97 (đối diện 160B), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794978
    ,"Long":106.64926
    ,"Polyline":"[106.64660645,10.79652023] ; [106.64810944,10.79570007] ; [106.64930725,10.79504967]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1830"
    ,"Station_Code":"QTB 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"67, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.793856
    ,"Long":106.651368
    ,"Polyline":"[106.64930725,10.79504967] ; [106.65035248,10.79448032] ; [106.65145111,10.79391003] ; [106.65158081,10.79384995]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"996"
    ,"Station_Code":"QTB 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"1125 (đối diện 544), đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.792192
    ,"Long":106.654533
    ,"Polyline":"[106.65158081,10.79384995] ; [106.65337372,10.79290962] ; [106.65457153,10.79224968]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"998"
    ,"Station_Code":"QTB 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm Y tế Phường 4, Tân Bình"
    ,"Station_Address":"1057, đường Cách Mạng Tháng Tám, Quận  Tân Bình"
    ,"Lat":10.791463
    ,"Long":106.655885
    ,"Polyline":"[106.65457153,10.79224968] ; [106.65667725,10.79113007]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1000"
    ,"Station_Code":"QTB 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Hồ Bơi Cộng Hòa"
    ,"Station_Address":"1003, đường Cách Mạng Tháng Tám, Quận  Tân Bình"
    ,"Lat":10.790114
    ,"Long":106.65846
    ,"Polyline":"[106.65667725,10.79113007] ; [106.65721893,10.79082966] ; [106.65770721,10.79059029] ; [106.65856171,10.79014015] ; [106.65956879,10.78962040] ; [106.65995026,10.78942013]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1002"
    ,"Station_Code":"QTB 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Ông Tạ"
    ,"Station_Address":"907, đường Cách M ạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.789261
    ,"Long":106.660075
    ,"Polyline":"[106.65995026,10.78942013] ; [106.66063690,10.78903961] ; [106.66072845,10.78899002]"
    ,"Distance":"97"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1001"
    ,"Station_Code":"QTB 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bành Văn Trân"
    ,"Station_Address":"771, đường Cách Mạng Tháng Tám, Quận  Tân Bình"
    ,"Lat":10.78808
    ,"Long":106.662315
    ,"Polyline":"[106.66072845,10.78899002] ; [106.66233826,10.78812981]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1003"
    ,"Station_Code":"Q10 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Công Viên Lê Thị Riêng"
    ,"Station_Address":"Công Viên Lê Thị Riêng, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.786289
    ,"Long":106.665672
    ,"Polyline":"[106.66233826,10.78812981] ; [106.66381073,10.78738022] ; [106.66486359,10.78678989] ; [106.66570282,10.78633976]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2562"
    ,"Station_Code":"Q10 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Hội thánh tin lành Hòa Hưng"
    ,"Station_Address":"601 , đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.784818
    ,"Long":106.668411
    ,"Polyline":"[106.66567230,10.78628922] ; [106.66570282,10.78633976] ; [106.66651154,10.78588963] ; [106.66831970,10.78493023] ; [106.66841125,10.78481770]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2561"
    ,"Station_Code":"Q10 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Tô Hi ến Thành"
    ,"Station_Address":"513, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.782535
    ,"Long":106.672699
    ,"Polyline":"[106.66815948,10.78474998] ; [106.66831970,10.78493023] ; [106.66960144,10.78425026] ; [106.67092133,10.78355026] ; [106.67147064,10.78324986] ; [106.67209625,10.78289986] ; [106.67250061,10.78271008] ; [106.67272949,10.78258991]"
    ,"Distance":"574"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1399"
    ,"Station_Code":"Q10 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Bửu Đà"
    ,"Station_Address":"427, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.781446
    ,"Long":106.674698
    ,"Polyline":"[106.67272949,10.78258991] ; [106.67350769,10.78217983] ; [106.67450714,10.78162956]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2564"
    ,"Station_Code":"Q10 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Hòa Hưng"
    ,"Station_Address":"385, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.780435
    ,"Long":106.676575
    ,"Polyline":"[106.67450714,10.78162956] ; [106.67578125,10.78096008] ; [106.67662048,10.78052044]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1394"
    ,"Station_Code":"Q10 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã 6 Dân Chủ"
    ,"Station_Address":"Đối diện 132A, đ ường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.7783
    ,"Long":106.680604
    ,"Polyline":"[106.67662048,10.78052044] ; [106.67862701,10.77943993] ; [106.67958832,10.77892017] ; [106.68051910,10.77842999]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2563"
    ,"Station_Code":"Q3 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Công an Qu ận 3"
    ,"Station_Address":"243, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.777219
    ,"Long":106.68246
    ,"Polyline":"[106.68051910,10.77842999] ; [106.68141174,10.77797031] ; [106.68142700,10.77799988] ; [106.68150330,10.77807045] ; [106.68163300,10.77810955] ; [106.68173981,10.77810001] ; [106.68182373,10.77805996] ; [106.68189240,10.77799988] ; [106.68195343,10.77785015] ; [106.68193817,10.77777004] ; [106.68190002,10.77768993] ; [106.68251801,10.77735996]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1400"
    ,"Station_Code":"Q3 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bệnh viện Mắt"
    ,"Station_Address":"239, đư ờng Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.776202
    ,"Long":106.684338
    ,"Polyline":"[106.68251801,10.77735996] ; [106.68437195,10.77635956]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2477"
    ,"Station_Code":"Q3 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Thi ̣ Diệu"
    ,"Station_Address":"179D, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.77469
    ,"Long":106.687202
    ,"Polyline":"[106.68437195,10.77635956] ; [106.68598175,10.77546978] ; [106.68682098,10.77501011] ; [106.68727112,10.77478027]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1396"
    ,"Station_Code":"Q1 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"85, đường Cách  Mạng Tháng Tám, Quận 1"
    ,"Lat":10.772392
    ,"Long":106.691371
    ,"Polyline":"[106.68727112,10.77478027] ; [106.68858337,10.77406979] ; [106.68985748,10.77340031] ; [106.69113922,10.77270985] ; [106.69139862,10.77256012]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1401"
    ,"Station_Code":"Q1 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"26 - 32, đường Nguyễn Thị Nghĩa, Quận 1"
    ,"Lat":10.770854
    ,"Long":106.693588
    ,"Polyline":"[106.69139862,10.77256012] ; [106.69281769,10.77180004] ; [106.69315338,10.77161026] ; [106.69319916,10.77147961] ; [106.69322968,10.77147961] ; [106.69328308,10.77147961] ; [106.69335938,10.77145004] ; [106.69342804,10.77138996] ; [106.69342804,10.77130985] ; [106.69338226,10.77124977] ; [106.69352722,10.77110004] ; [106.69365692,10.77089024]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69365692,10.77089024] ; [106.69412994,10.77013969] ; [106.69458008,10.77031040] ; [106.69673157,10.77118969]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"118"
    ,"Station_Code":"Q1TC1B"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bến Thành B"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77084
    ,"Long":106.698532
    ,"Polyline":"[106.69673157,10.77118969] ; [106.69795227,10.77165985] ; [106.69806671,10.77159023] ; [106.69803619,10.77147007] ; [106.69805908,10.77134037] ; [106.69811249,10.77126026] ; [106.69819641,10.77120018] ; [106.69828796,10.77116966] ; [106.69841003,10.77116966] ; [106.69854736,10.77122021] ; [106.69860077,10.77124977] ; [106.69899750,10.77095032] ; [106.69856262,10.77077961]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường  Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69856262,10.77077961] ; [106.69744873,10.77035046] ; [106.69615173,10.76978970] ; [106.69580841,10.76966000]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69580841,10.76966000] ; [106.69412994,10.76898003]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"TĐH xe bu ýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt S ài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69412994,10.76898003] ; [106.69238281,10.76828003] ; [106.69052124,10.76753998] ; [106.68988800,10.76844978] ; [106.68920898,10.76819992] ; [106.68904877,10.76807022]"
    ,"Distance":"650"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe bu ýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai , Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68904877,10.76807022] ; [106.68923950,10.76813984] ; [106.69033813,10.76855087]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69673157,10.77118969] ; [106.69785309,10.77157021] ; [106.69799805,10.77154922] ; [106.69805145,10.77135658] ; [106.69811249,10.77125931] ; [106.69733429,10.77032089] ; [106.69609833,10.76985264] ; [106.69644928,10.76910400] ; [106.69750977,10.77021027] ; [106.69841766,10.77060986] ; [106.69844818,10.77054024]"
    ,"Distance":"850"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1944"
    ,"Station_Code":"Q1 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"40, đường Phạm Hồng Thái, Quận 1"
    ,"Lat":10.77129
    ,"Long":106.695824
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69841766,10.77060986] ; [106.69898987,10.77089024] ; [106.69863892,10.77126408] ; [106.69880676,10.77142811] ; [106.69877625,10.77161217] ; [106.69863129,10.77186489] ; [106.69837952,10.77187538] ; [106.69815826,10.77171803] ; [106.69804382,10.77158070] ; [106.69792938,10.77167034] ; [106.69669342,10.77118587] ; [106.69582367,10.77120972] ; [106.69582367,10.77128983]"
    ,"Distance":"557"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1297"
    ,"Station_Code":"Q1 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"Đối diện số 89, đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.773046
    ,"Long":106.690813
    ,"Polyline":"[106.69582367,10.77128983] ; [106.69512939,10.77128601] ; [106.69351959,10.77134895] ; [106.69324493,10.77147961] ; [106.69322205,10.77147961] ; [106.69320679,10.77147961] ; [106.69320679,10.77147961] ; [106.69319916,10.77147961] ; [106.69319916,10.77147961] ; [106.69319916,10.77147961] ; [106.69319916,10.77147961] ; [106.69319916,10.77147961] ; [106.69335175,10.77150726] ; [106.69319916,10.77147961] ; [106.69315338,10.77161026] ; [106.69281769,10.77180004] ; [106.69212341,10.77230835] ; [106.69126129,10.77272987] ; [106.69081116,10.77304554]"
    ,"Distance":"642"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"3478"
    ,"Station_Code":"Q3 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Võ Văn Tần"
    ,"Station_Address":"40 - 42, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.774068
    ,"Long":106.688946
    ,"Polyline":"[106.69081116,10.77304554] ; [106.68894958,10.77406788]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1296"
    ,"Station_Code":"Q3 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bệnh viện Mắt"
    ,"Station_Address":"108, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.776461
    ,"Long":106.684467
    ,"Polyline":"[106.68894958,10.77406788] ; [106.68446350,10.77646065]"
    ,"Distance":"558"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"3477"
    ,"Station_Code":"Q3 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã sáu Dân Chủ"
    ,"Station_Address":"126,  đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.77753
    ,"Long":106.682455
    ,"Polyline":"[106.68446350,10.77646065] ; [106.68245697,10.77752972]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1299"
    ,"Station_Code":"Q3 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu th ị Thiên Hòa"
    ,"Station_Address":"132C - 132D,  đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.778452
    ,"Long":106.680618
    ,"Polyline":"[106.68245697,10.77752972] ; [106.68193817,10.77781010.06.68193817] ; [10.77789974,106.68190765] ; [10.77797031,106.68184662] ; [10.77803993,106.68177795] ; [10.77807999,106.68166351] ; [10.77810955,106.68153381] ; [10.77807999,106.68147278] ; [10.77803993,106.68061829]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1298"
    ,"Station_Code":"Q3 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã Ba  Chí Hòa"
    ,"Station_Address":"276 Bis, đường  Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.780594
    ,"Long":106.676575
    ,"Polyline":"[106.68061829,10.77845192] ; [106.67657471,10.78059387]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2711"
    ,"Station_Code":"Q3 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chùa Bửu Đà"
    ,"Station_Address":"342 - 342A, đường Cách Mạng Tháng Tám, Qu ận 3"
    ,"Lat":10.78163
    ,"Long":106.674741
    ,"Polyline":"[106.67657471,10.78059387] ; [106.67474365,10.78162956]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2709"
    ,"Station_Code":"Q3 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Rạp hát Thanh Vân"
    ,"Station_Address":"360A, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.783738
    ,"Long":106.670755
    ,"Polyline":"[106.67474365,10.78162956] ; [106.67075348,10.78373814]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2712"
    ,"Station_Code":"Q3 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Cống Bà Xếp"
    ,"Station_Address":"442, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.784146
    ,"Long":106.669945
    ,"Polyline":"[106.67075348,10.78373814] ; [106.66994476,10.78414631]"
    ,"Distance":"100"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1300"
    ,"Station_Code":"Q3 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Công viên Lê Thị Riêng"
    ,"Station_Address":"542, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.785814
    ,"Long":106.66693
    ,"Polyline":"[106.66994476,10.78414631] ; [106.66693115,10.78581429]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"906"
    ,"Station_Code":"QTB 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bắc H ải"
    ,"Station_Address":"690, đường Cách Mạng  Tháng Tám, Quận Tân Bình"
    ,"Lat":10.787486
    ,"Long":106.663727
    ,"Polyline":"[106.66693115,10.78581429] ; [106.66372681,10.78748608]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"907"
    ,"Station_Code":"QTB 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bành Văn Trân"
    ,"Station_Address":"814, đường Cách Mạng Tháng Tám, Quận  Tân Bình"
    ,"Lat":10.788639
    ,"Long":106.661544
    ,"Polyline":"[106.66372681,10.78748608] ; [106.66154480,10.78863907]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"910"
    ,"Station_Code":"QTB 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Ông Tạ"
    ,"Station_Address":"962, đường Cách Mạng Tháng Tám, Quận Tân B ình"
    ,"Lat":10.789677
    ,"Long":106.659576
    ,"Polyline":"[106.66154480,10.78863907] ; [106.65957642,10.78967667]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"909"
    ,"Station_Code":"QTB 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trạm Y tế Phường 4"
    ,"Station_Address":"1130 (458), đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.791448
    ,"Long":106.656218
    ,"Polyline":"[106.65957642,10.78967667] ; [106.65621948,10.79144764]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"908"
    ,"Station_Code":"QTB 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"1236 (544), đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.792317
    ,"Long":106.654592
    ,"Polyline":"[106.65621948,10.79144764] ; [106.65459442,10.79231739]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65459442,10.79231739] ; [106.65349579,10.79290771] ; [106.65502167,10.79463959] ; [106.65505981,10.79458714]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20  (B9), đường Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65505981,10.79458714] ; [106.65502167,10.79463959] ; [106.65580750,10.79543686] ; [106.65515900,10.79603958] ; [106.65519714,10.79608059]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường  Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62), đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65519714,10.79608059] ; [106.65464783,10.79654980] ; [106.65387726,10.79585266]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65387726,10.79585266] ; [106.65390778,10.79584026] ; [106.65233612,10.79437923]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1719"
    ,"Station_Code":"QTB 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã t ư Bảy Hiền"
    ,"Station_Address":"106, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794182
    ,"Long":106.651191
    ,"Polyline":"[106.65233612,10.79437923] ; [106.65180206,10.79386139] ; [106.65119171,10.79418182]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1720"
    ,"Station_Code":"QTB 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà Thở Đắc Lộ"
    ,"Station_Address":"150, đ ường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794973
    ,"Long":106.649743
    ,"Polyline":"[106.65119171,10.79418182] ; [106.64974213,10.79497337]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1301"
    ,"Station_Code":"QTB 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Hoàng  Hoa Thám"
    ,"Station_Address":"162T, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.796137
    ,"Long":106.647565
    ,"Polyline":"[106.64974213,10.79497337] ; [106.64756775,10.79613686]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2713"
    ,"Station_Code":"QTB 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã ba Bình Giã"
    ,"Station_Address":"298, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797792
    ,"Long":106.644453
    ,"Polyline":"[106.64756775,10.79613686] ; [106.64445496,10.79779243]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2200"
    ,"Station_Code":"QTB 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã ba Ấp Bắc"
    ,"Station_Address":"366A, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.799642
    ,"Long":106.641036
    ,"Polyline":"[106.64445496,10.79779243] ; [106.64103699,10.79964161]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2205"
    ,"Station_Code":"QTB 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Chợ Võ Thành Trang"
    ,"Station_Address":"510, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.80147
    ,"Long":106.637608
    ,"Polyline":"[106.64103699,10.79964161] ; [106.63761139,10.80146980]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1302"
    ,"Station_Code":"QTB 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"638, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.804626
    ,"Long":106.635656
    ,"Polyline":"[106.63761139,10.80146980] ; [106.63672638,10.80195522] ; [106.63616943,10.80290318] ; [106.63565826,10.80462646]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"2202"
    ,"Station_Code":"QTB 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.806202
    ,"Long":106.635184
    ,"Polyline":"[106.63565826,10.80462646] ; [106.63518524,10.80620193]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63518524,10.80620193] ; [106.63494873,10.80690765] ; [106.63488007,10.80761909] ; [106.63469696,10.80807781]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63469696,10.80807781] ; [106.63349915,10.81169510]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63349915,10.81169510.06.63258362]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63258362,10.81463814] ; [106.63169098,10.81754112]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63169098,10.81754112] ; [106.63044739,10.82164383]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63044739,10.82164383] ; [106.63015747,10.82262039] ; [106.62973785,10.82322693] ; [106.62609863,10.82672977]"
    ,"Distance":"752"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"273"
    ,"Station_Code":"Q12 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"189/4, đường Trường Chinh, Quận 12"
    ,"Lat":10.828843
    ,"Long":106.624482
    ,"Polyline":"[106.62609863,10.82672977] ; [106.62535858,10.82745266] ; [106.62448120,10.82884312]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"274"
    ,"Station_Code":"Q12 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"258, đường Trường Chinh, Quận 12"
    ,"Lat":10.832547
    ,"Long":106.622116
    ,"Polyline":"[106.62448120,10.82884312] ; [106.62211609,10.83254719]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"275"
    ,"Station_Code":"Q12 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Chùa L ạc Quang"
    ,"Station_Address":"408, đường Trư ờng Chinh, Quận 12"
    ,"Lat":10.83514
    ,"Long":106.620464
    ,"Polyline":"[106.62211609,10.83254719] ; [106.62046051,10.83514023]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"277"
    ,"Station_Code":"Q12 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"640, đường Trường Chinh, Quận 12"
    ,"Lat":10.83819
    ,"Long":106.618495
    ,"Polyline":"[106.62046051,10.83514023] ; [106.61849213,10.83819008]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"276"
    ,"Station_Code":"Q12 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"774A, đường Trường Chinh, Quận 12"
    ,"Lat":10.841436
    ,"Long":106.616457
    ,"Polyline":"[106.61849213,10.83819008] ; [106.61645508,10.84143639]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe  An Sương"
    ,"Station_Address":"116, đường Quốc l ộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61645508,10.84143639] ; [106.61563110,10.84251022] ; [106.61566925,10.84265995] ; [106.61563873,10.84280968] ; [106.61560822,10.84286976] ; [106.61551666,10.84296036] ; [106.61540222,10.84300995] ; [106.61528015,10.84300041] ; [106.61489868,10.84359074] ; [106.61402893,10.84497070]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61402890,10.84497070] ; [106.61338040,10.84581375] ; [106.61292550,10.84655130] ; [106.61248140,10.84726778] ; [106.61235850,10.84719380] ; [106.61273210,10.84657268] ; [106.61313790,10.84595156] ; [106.61394420,10.84470931]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"102"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Bến xe An  Sương"
    ,"Station_Address":"Bến xe An Sương,  đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61396030,10.84473038] ; [106.61405180,10.84459972] ; [106.61408930,10.84450118] ; [106.61406240,10.84441844] ; [106.61400330,10.84434624] ; [106.61393350,10.84428457] ; [106.61365630,10.84405216] ; [106.61343970,10.84385818] ; [106.61328200,10.84374541] ; [106.61298540,10.84354619]"
    ,"Distance":"199"
  }]