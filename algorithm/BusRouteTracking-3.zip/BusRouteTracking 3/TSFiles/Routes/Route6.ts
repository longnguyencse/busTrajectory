export const Route6 =[
  {
     "Route_Id":"6"
    ,"Station_Id":"394"
    ,"Station_Code":"BX73"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Bến xe buýt ĐH Nông Lâm, đường Quốc lộ 1 , Quận Thủ Đức"
    ,"Lat":10.868183135986328
    ,"Long":106.78744506835938
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"396"
    ,"Station_Code":"QTD 174"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"1030, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.866912
    ,"Long":106.790283
    ,"Polyline":"[106.78744507,10.86818314] ; [106.78762817,10.86798286] ; [106.78774261,10.86777306] ; [106.78796387,10.86760426] ; [106.78816986,10.86741447] ; [106.78827667,10.86710835] ; [106.78931427,10.86708260] ; [106.78993988,10.86701393] ; [106.79028320,10.86691189]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"398"
    ,"Station_Code":"QTD 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Khu Công nghệ cao Q9"
    ,"Station_Address":"Đối diện Khu  công nghệ cao, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.860545
    ,"Long":106.791723
    ,"Polyline":"[106.79028320,10.86691189] ; [106.79064178,10.86686611] ; [106.79125977,10.86670876] ; [106.79180908,10.86647701] ; [106.79231262,10.86620235] ; [106.79270172,10.86591816] ; [106.79302216,10.86557007] ; [106.79333496,10.86517048] ; [106.79352570,10.86473846] ; [106.79365540,10.86404228] ; [106.79355621,10.86308384] ; [106.79331207,10.86204052] ; [106.79279327,10.86120796] ; [106.79230499,10.86079693] ; [106.79199219,10.86059761] ; [106.79172516,10.86054516]"
    ,"Distance":"1006"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"401"
    ,"Station_Code":"QTD 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Công ty Cocacola"
    ,"Station_Address":"Công  ty Cocacola, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.856483
    ,"Long":106.784964
    ,"Polyline":"[106.79172516,10.86054516] ; [106.78496552,10.85648346]"
    ,"Distance":"866"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"400"
    ,"Station_Code":"QTD 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường Đại  học Sư phạm Kỹ thuật"
    ,"Station_Address":"1, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849823
    ,"Long":106.772089
    ,"Polyline":"[106.78496552,10.85648346] ; [106.77600861,10.85109329] ; [106.77544403,10.85068226] ; [106.77499390,10.85033417] ; [106.77434540,10.84980774] ; [106.77409363,10.84972858] ; [106.77387238,10.84968662] ; [106.77333069,10.84968090] ; [106.77264404,10.84971809] ; [106.77230835,10.84974384] ; [106.77208710,10.84982300]"
    ,"Distance":"1630"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"402"
    ,"Station_Code":"QTD 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị Nguyễn Kim"
    ,"Station_Address":"312, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849805
    ,"Long":106.768837
    ,"Polyline":"[106.77208710,10.84982300] ; [106.77159119,10.84973335] ; [106.76883698,10.84980488]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"403"
    ,"Station_Code":"QTD 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhà thiếu nhi Thủ Đức"
    ,"Station_Address":"Nh à thiếu nhi, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850556
    ,"Long":106.766794
    ,"Polyline":"[106.76883698,10.84980488] ; [106.76853180,10.84978104] ; [106.76822662,10.84977627] ; [106.76796722,10.84982872] ; [106.76776886,10.84990788] ; [106.76754761,10.85013390] ; [106.76734924,10.85037136] ; [106.76722717,10.85044479] ; [106.76709747,10.85051346] ; [106.76679230,10.85055637]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"404"
    ,"Station_Code":"QTD 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Lê Qu ý Đôn"
    ,"Station_Address":"231, đường Võ Văn  Ngân, Quận Thủ Đức"
    ,"Lat":10.850808
    ,"Long":106.764101
    ,"Polyline":"[106.76679230,10.85055637] ; [106.76409912,10.85080814]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"405"
    ,"Station_Code":"QTD 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"95, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850679
    ,"Long":106.75943
    ,"Polyline":"[106.76409912,10.85080814] ; [106.76287079,10.85090351] ; [106.76270294,10.85087204] ; [106.76245117,10.85074520] ; [106.76221466,10.85060310.06.76194763] ; [10.85050297,106.76068878] ; [10.85057163,106.75942993]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"406"
    ,"Station_Code":"QTD 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Làng trẻ em  SOS"
    ,"Station_Address":"249, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.849723
    ,"Long":106.758698
    ,"Polyline":"[106.75942993,10.85067940] ; [106.75862122,10.85067177] ; [106.75869751,10.84972286]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"408"
    ,"Station_Code":"QTD 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường THPT  Quận Thủ Đức"
    ,"Station_Address":"229-231, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.848207
    ,"Long":106.759613
    ,"Polyline":"[106.75869751,10.84972286] ; [106.75875092,10.84960175] ; [106.75875854,10.84946537] ; [106.75880432,10.84929657] ; [106.75885773,10.84915447] ; [106.75893402,10.84900093] ; [106.75961304,10.84820747]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"407"
    ,"Station_Code":"QTD 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Công ty may Sài Gòn"
    ,"Station_Address":"Kế 145B, đường Đặng Văn Bi, Qu ận Thủ Đức"
    ,"Lat":10.844107
    ,"Long":106.762133
    ,"Polyline":"[106.75961304,10.84820747] ; [106.76051331,10.84720516] ; [106.76083374,10.84683609] ; [106.76111603,10.84643555] ; [106.76135254,10.84595108] ; [106.76147461,10.84551907] ; [106.76161957,10.84501266] ; [106.76191711,10.84454918] ; [106.76213074,10.84410667]"
    ,"Distance":"541"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"411"
    ,"Station_Code":"QTD 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Công ty Sanofi Aventis"
    ,"Station_Address":"15/6C, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.84132
    ,"Long":106.764354
    ,"Polyline":"[106.76213074,10.84410667] ; [106.76260376,10.84348488] ; [106.76312256,10.84254742] ; [106.76362610,10.84192562] ; [106.76435089,10.84132004]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"409"
    ,"Station_Code":"QTD 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Tu viện Quảng Đức"
    ,"Station_Address":"Tu viện Quảng Đức, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.839607
    ,"Long":106.766136
    ,"Polyline":"[106.76435089,10.84132004] ; [106.76473999,10.84113026] ; [106.76567841,10.84055042] ; [106.76595306,10.84022903] ; [106.76609802,10.83988094] ; [106.76613617,10.83960724]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"410"
    ,"Station_Code":"QTD 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Đối diện 592C, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.834945
    ,"Long":106.765244
    ,"Polyline":"[106.76613617,10.83960724] ; [106.76640320,10.83908081] ; [106.77210999,10.84947014] ; [106.77256012,10.84955502] ; [106.77298737,10.84953308] ; [106.77350616,10.84928036] ; [106.76524353,10.83494473]"
    ,"Distance":"3373"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"413"
    ,"Station_Code":"QTD 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Công ty truyền tải điện 4"
    ,"Station_Address":"Công ty truyền tải điện 4, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.831214
    ,"Long":106.763195
    ,"Polyline":"[106.76524353,10.83494473] ; [106.76319122,10.83121395]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"412"
    ,"Station_Code":"QTD 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"Nh à máy thép Thủ Đức, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.825366
    ,"Long":106.759998
    ,"Polyline":"[106.76319122,10.83121395] ; [106.75999451,10.82536602]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"414"
    ,"Station_Code":"QTD 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Xi măng Hà Tiên"
    ,"Station_Address":"Xi măng Hà Tiên 1, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.820576
    ,"Long":106.758142
    ,"Polyline":"[106.75999451,10.82536602] ; [106.75891113,10.82329464] ; [106.75814056,10.82057571]"
    ,"Distance":"574"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"415"
    ,"Station_Code":"Q2 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Đối diện Esstella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802925
    ,"Long":106.747948
    ,"Polyline":"[106.75814056,10.82057571] ; [106.75713348,10.81518078] ; [106.75663757,10.81246185] ; [106.75612640,10.80967999] ; [106.75566101,10.80860519] ; [106.75509644,10.80751896] ; [106.75412750,10.80622292] ; [106.75299072,10.80510616] ; [106.75171661,10.80434704] ; [106.75036621,10.80364132] ; [106.74915314,10.80320930] ; [106.74794769,10.80292511]"
    ,"Distance":"2460"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"416"
    ,"Station_Code":"Q2 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"655, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802134
    ,"Long":106.7434
    ,"Polyline":"[106.74794769,10.80292511] ; [106.74340057,10.80213356]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"417"
    ,"Station_Code":"Q2 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Ngã ba Thảo Điền, đường  Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801309
    ,"Long":106.738762
    ,"Polyline":"[106.74340057,10.80213356] ; [106.73876190,10.80130863]"
    ,"Distance":"516"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"418"
    ,"Station_Code":"Q2 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"Đối diện Cầu Đen, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800451
    ,"Long":106.73436
    ,"Polyline":"[106.73876190,10.80130863] ; [106.73435974,10.80045128]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"419"
    ,"Station_Code":"QBTH 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"24(597), đường Điện Biên Ph ủ, Quận Bình Thạnh"
    ,"Lat":10.79882
    ,"Long":106.719641
    ,"Polyline":"[106.73435974,10.80045128] ; [106.72284698,10.79813957] ; [106.72219849,10.79803467] ; [106.72155762,10.79800320] ; [106.72103119,10.79808712] ; [106.72053528,10.79827690] ; [106.72010040,10.79850864] ; [106.71964264,10.79881954]"
    ,"Distance":"1659"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"420"
    ,"Station_Code":"QBTH 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"152/72c(559), đường Điện Biên Phủ, Qu ận Bình Thạnh"
    ,"Lat":10.800153
    ,"Long":106.717442
    ,"Polyline":"[106.71964264,10.79881954] ; [106.71744537,10.80015278]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"483, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71744537,10.80015278] ; [106.71692657,10.80036354] ; [106.71661377,10.80043221] ; [106.71634674,10.80053711] ; [106.71596527,10.80072212] ; [106.71583557,10.80083752] ; [106.71567535,10.80092716] ; [106.71485901,10.80122757]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cây xăng  dầu"
    ,"Station_Address":"419, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71485901,10.80122757] ; [106.71370697,10.80155945] ; [106.71331024,10.80165482] ; [106.71292114,10.80166531] ; [106.71244812,10.80163860]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"221, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71244812,10.80163860] ; [106.71163940,10.80162811] ; [106.71137238,10.80173397] ; [106.71126556,10.80171776] ; [106.71115875,10.80167580] ; [106.71109009,10.80155945] ; [106.71108246,10.80142784] ; [106.71112061,10.80131245] ; [106.71118927,10.80120659] ; [106.71107483,10.79983711]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường TH Hồng Hà"
    ,"Station_Address":"153, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71107483,10.79983711] ; [106.71102142,10.79907799] ; [106.71088409,10.79831886] ; [106.71067810,10.79752827] ; [106.71041107,10.79673767]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"369"
    ,"Station_Code":"QBTH 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Siêu Thị  Điện máy tự do"
    ,"Station_Address":"151, đường Xô Viết Nghệ Tĩnh, Quận Bình  Thạnh"
    ,"Lat":10.794978
    ,"Long":106.709368
    ,"Polyline":"[106.71041107,10.79673767] ; [106.71023560,10.79620552] ; [106.70999908,10.79567337] ; [106.70968628,10.79529476] ; [106.70936584,10.79497814]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"373"
    ,"Station_Code":"QBTH 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"79, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793534
    ,"Long":106.707979
    ,"Polyline":"[106.70936584,10.79497814] ; [106.70797729,10.79353428]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"370"
    ,"Station_Code":"Q1 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"2A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790694
    ,"Long":106.705259
    ,"Polyline":"[106.70797729,10.79353428] ; [106.70526123,10.79069424]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Đài truyền hình"
    ,"Station_Address":"Đối di ện 9, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70526123,10.79069424] ; [106.70201111,10.78715706]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"371"
    ,"Station_Code":"Q1 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"nhà thờ Mạc  Ti Nho"
    ,"Station_Address":"16A, đường Nguy ễn Thị Minh Khai, Quận 1"
    ,"Lat":10.786397
    ,"Long":106.701294
    ,"Polyline":"[106.70201111,10.78715706] ; [106.70129395,10.78639698]"
    ,"Distance":"115"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"372"
    ,"Station_Code":"Q1 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Phùng Khắc Khoan"
    ,"Station_Address":"2 - 4, đường Phùng Khắc Khoan, Quận 1"
    ,"Lat":10.784048
    ,"Long":106.698586
    ,"Polyline":"[106.70129395,10.78639698] ; [106.69964600,10.78463936] ; [106.69886017,10.78384399] ; [106.69858551,10.78404808]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"378"
    ,"Station_Code":"Q3 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Hồ Con Rùa"
    ,"Station_Address":"24 - 26, đường Trần Cao Vân, Quận 3"
    ,"Lat":10.783314
    ,"Long":106.696411
    ,"Polyline":"[106.69858551,10.78404808] ; [106.69780731,10.78478146] ; [106.69641113,10.78331375]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"375"
    ,"Station_Code":"Q3 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Sân Phan Đ ình Phùng"
    ,"Station_Address":"8, đường Võ Văn Tần, Quận 3"
    ,"Lat":10.781172
    ,"Long":106.694402
    ,"Polyline":"[106.69641113,10.78331375] ; [106.69620514,10.78302670] ; [106.69605255,10.78308487] ; [106.69590759,10.78309536] ; [106.69575500,10.78305817] ; [106.69561768,10.78295326] ; [106.69554138,10.78281593] ; [106.69554138,10.78267384] ; [106.69556427,10.78253174] ; [106.69561005,10.78239441] ; [106.69492340,10.78166676] ; [106.69440460,10.78117180]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"377"
    ,"Station_Code":"Q3 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bảo tàng chiến tranh"
    ,"Station_Address":"28 , đường Võ Văn Tần, Quận 3"
    ,"Lat":10.779143
    ,"Long":106.69254
    ,"Polyline":"[106.69440460,10.78117180] ; [106.69254303,10.77914333]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"376"
    ,"Station_Code":"Q3 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trần Quốc Thảo"
    ,"Station_Address":"44, đường Võ Văn Tần, Quận 3"
    ,"Lat":10.777889
    ,"Long":106.691365
    ,"Polyline":"[106.69254303,10.77914333] ; [106.69136810,10.77788925]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"379"
    ,"Station_Code":"Q3 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Đại học Mở thành phố HCM"
    ,"Station_Address":"62, đường Võ Văn Tần, Quận 3"
    ,"Lat":10.776418
    ,"Long":106.69004
    ,"Polyline":"[106.69136810,10.77788925] ; [106.69004059,10.77641773]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"381"
    ,"Station_Code":"Q3 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Nguyễn Thị Minh Khai"
    ,"Station_Address":"17, đường Bà Huyện Thanh Quan, Quận 3"
    ,"Lat":10.775102
    ,"Long":106.690186
    ,"Polyline":"[106.69004059,10.77641773] ; [106.68952942,10.77579689] ; [106.69002533,10.77531719] ; [106.69018555,10.77510166]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"380"
    ,"Station_Code":"Q3 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cách Mạng tháng 8"
    ,"Station_Address":"284 , đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.773112
    ,"Long":106.688812
    ,"Polyline":"[106.69018555,10.77510166] ; [106.69034576,10.77502728] ; [106.69055176,10.77488518] ; [106.68881226,10.77311230]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"383"
    ,"Station_Code":"Q3 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Tôn Thất T ùng"
    ,"Station_Address":"414, đường Nguyễn Th ị Minh Khai, Quận 3"
    ,"Lat":10.77079
    ,"Long":106.686634
    ,"Polyline":"[106.68881226,10.77311230] ; [106.68663025,10.77079010]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"382"
    ,"Station_Code":"Q3 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Bệnh viện Từ Dũ"
    ,"Station_Address":"436, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.768946
    ,"Long":106.684883
    ,"Polyline":"[106.68663025,10.77079010.06.68488312]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"89"
    ,"Station_Code":"Q3 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Hội Chữ thập đỏ thành phố"
    ,"Station_Address":"464 - 466, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.767691
    ,"Long":106.683693
    ,"Polyline":"[106.68488312,10.76894569] ; [106.68369293,10.76769066]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"90"
    ,"Station_Code":"Q3 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà sách Minh Khai"
    ,"Station_Address":"488, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.766416
    ,"Long":106.682428
    ,"Polyline":"[106.68369293,10.76769066] ; [106.68242645,10.76641560]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"425"
    ,"Station_Code":"Q5 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Trường THPT Lê Hồng Phong"
    ,"Station_Address":"235, đường Nguyễn Văn Cừ,  Quận 5"
    ,"Lat":10.764456
    ,"Long":106.681946
    ,"Polyline":"[106.68242645,10.76641560] ; [106.68188477,10.76581573] ; [106.68171692,10.76570511] ; [106.68161011,10.76572037] ; [106.68150330,10.76569462] ; [106.68142700,10.76565742] ; [106.68137360,10.76560497] ; [106.68131256,10.76545143] ; [106.68134308,10.76530933] ; [106.68146515,10.76519871] ; [106.68164825,10.76516151] ; [106.68194580,10.76445580]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"424"
    ,"Station_Code":"Q5 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Đại học Khoa học Tự nhiên"
    ,"Station_Address":"227, đường Nguyễn Văn Cừ, Quận 5"
    ,"Lat":10.763354
    ,"Long":106.682388
    ,"Polyline":"[106.68194580,10.76445580] ; [106.68238831,10.76335430]"
    ,"Distance":"132"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"426"
    ,"Station_Code":"Q5 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Đại học Sư Phạm"
    ,"Station_Address":"280, đường An Dương Vương, Quận 5"
    ,"Lat":10.76103
    ,"Long":106.68267
    ,"Polyline":"[106.68238831,10.76335430] ; [106.68323517,10.76124096] ; [106.68267059,10.76103020]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"429"
    ,"Station_Code":"Q5 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"370, đường An Dương Vương, Quận 5"
    ,"Lat":10.759407
    ,"Long":106.678764
    ,"Polyline":"[106.68267059,10.76103020] ; [106.67876434,10.75940704]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"427"
    ,"Station_Code":"Q5 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"526, đư ờng An Dương Vương, Quận 5"
    ,"Lat":10.757984
    ,"Long":106.675272
    ,"Polyline":"[106.67876434,10.75940704] ; [106.67527008,10.75798416]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"430"
    ,"Station_Code":"Q5 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"Đối diện số 5, đường An Dương Vương, Quận 5"
    ,"Lat":10.757536
    ,"Long":106.673534
    ,"Polyline":"[106.67527008,10.75798416] ; [106.67478180,10.75777340] ; [106.67424011,10.75758362] ; [106.67418671,10.75762558] ; [106.67412567,10.75764179] ; [106.67405701,10.75763130] ; [106.67398071,10.75759983] ; [106.67353058,10.75753593]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"428"
    ,"Station_Code":"Q5 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bệnh viện Nguy ễn Tri Phương"
    ,"Station_Address":"102C-D, đ ường An Dương Vương, Quận 5"
    ,"Lat":10.756967
    ,"Long":106.670653
    ,"Polyline":"[106.67353058,10.75753593] ; [106.67065430,10.75696659]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường  Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.67065430,10.75696659] ; [106.66966248,10.75674534] ; [106.66961670,10.75715065]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"431"
    ,"Station_Code":"Q5 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"116A, đường Hùng Vương, Quận 5"
    ,"Lat":10.757257
    ,"Long":106.668566
    ,"Polyline":"[106.66961670,10.75715065] ; [106.66950226,10.75739956] ; [106.66941071,10.75765038] ; [106.66856384,10.75725746]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"433"
    ,"Station_Code":"Q5 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Bệnh viện Ph ạm Ngọc Thạch"
    ,"Station_Address":"120, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755897
    ,"Long":106.664511
    ,"Polyline":"[106.66856384,10.75725746] ; [106.66702271,10.75647640] ; [106.66451263,10.75589657]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Bệnh viện H ùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66451263,10.75589657] ; [106.66236877,10.75539017] ; [106.66107178,10.75519562]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Bệnh viện Ch ợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107178,10.75519562] ; [106.66039276,10.75501156] ; [106.65950012,10.75487518]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"435"
    ,"Station_Code":"Q5 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"Đối diện 385, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75458
    ,"Long":106.657934
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65891266,10.75471687] ; [106.65838623,10.75463963] ; [106.65793610,10.75457954]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"438"
    ,"Station_Code":"Q5 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Dương Tử Giang"
    ,"Station_Address":"Đối diện 455-457, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754158
    ,"Long":106.65552
    ,"Polyline":"[106.65793610,10.75457954] ; [106.65730286,10.75442123] ; [106.65667725,10.75429535] ; [106.65551758,10.75415802]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65551758,10.75415802] ; [106.65386963,10.75384140] ; [106.65376282,10.75381565] ; [106.65370178,10.75378418] ; [106.65370178,10.75367832] ; [106.65373993,10.75360966] ; [106.65340424,10.75216007] ; [106.65329742,10.75167084] ; [106.65311432,10.75143337] ; [106.65296173,10.75132751] ; [106.65256500,10.75125313]"
    ,"Distance":"543"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đ ường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Chợ L ớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65223694,10.75123787] ; [106.65206909,10.75116444] ; [106.65195465,10.75103760] ; [106.65100861,10.75098515] ; [106.65048981,10.75103283] ; [106.65079498,10.75337315] ; [106.65150452,10.75333023] ; [106.65233612,10.75333118]"
    ,"Distance":"667"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"470"
    ,"Station_Code":"Q5 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Thuận Kiều Plaza"
    ,"Station_Address":"399, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754111
    ,"Long":106.656749
    ,"Polyline":"[106.65233612,10.75333118] ; [106.65674591,10.75411129]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Bệnh viện Ch ợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng  Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65674591,10.75411129] ; [106.65923309,10.75455284]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"439"
    ,"Station_Code":"Q5 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"217, đường Hồng Bàng, Quận 5"
    ,"Lat":10.75536
    ,"Long":106.663191
    ,"Polyline":"[106.65923309,10.75455284] ; [106.66319275,10.75535965]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"440"
    ,"Station_Code":"Q5 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bệnh viện Đại học Y Dược"
    ,"Station_Address":"215, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755671
    ,"Long":106.664683
    ,"Polyline":"[106.66319275,10.75535965] ; [106.66468048,10.75567055]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"465"
    ,"Station_Code":"Q5 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"121, đường An Dương Vương, Quận 5"
    ,"Lat":10.756714
    ,"Long":106.670492
    ,"Polyline":"[106.66468048,10.75567055] ; [106.67049408,10.75671387]"
    ,"Distance":"646"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"469"
    ,"Station_Code":"Q5 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Chợ An Đông"
    ,"Station_Address":"59C, đường  An Dương Vương, Quận 5"
    ,"Lat":10.757057
    ,"Long":106.672182
    ,"Polyline":"[106.67049408,10.75671387] ; [106.67218018,10.75705719]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"466"
    ,"Station_Code":"Q5 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"439, đường An Dương Vương, Quận 5"
    ,"Lat":10.758374
    ,"Long":106.676576
    ,"Polyline":"[106.67218018,10.75705719] ; [106.67400360,10.75745678] ; [106.67409515,10.75742531] ; [106.67416382,10.75744152] ; [106.67422485,10.75747776] ; [106.67426300,10.75753593] ; [106.67479706,10.75771046] ; [106.67611694,10.75823212] ; [106.67657471,10.75837421]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"472"
    ,"Station_Code":"Q5 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"373, đường An Dương Vương, Quận 5"
    ,"Lat":10.759138
    ,"Long":106.678453
    ,"Polyline":"[106.67657471,10.75837421] ; [106.67758179,10.75883293] ; [106.67845154,10.75913811]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"467"
    ,"Station_Code":"Q5 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đại học Sài Gòn"
    ,"Station_Address":"273-275, đường An Dương Vương, Quận 5"
    ,"Lat":10.760735
    ,"Long":106.682289
    ,"Polyline":"[106.67845154,10.75913811] ; [106.68228912,10.76073456]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"474"
    ,"Station_Code":"Q1 141"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"ĐH Khoa Học Tự Nhiên"
    ,"Station_Address":"Đối diện số 217, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.762292
    ,"Long":106.683052
    ,"Polyline":"[106.68228912,10.76073456] ; [106.68344879,10.76123047] ; [106.68305206,10.76229191]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"471"
    ,"Station_Code":"Q1 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường Lê Hồng Phong"
    ,"Station_Address":"Đối diện số 235, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.764503
    ,"Long":106.68216
    ,"Polyline":"[106.68305206,10.76229191] ; [106.68215942,10.76450253]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"287"
    ,"Station_Code":"Q1 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Phạm Viết Chánh"
    ,"Station_Address":"Đối diện 492 , đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.766214
    ,"Long":106.682533
    ,"Polyline":"[106.68215942,10.76450253] ; [106.68215942,10.76450253] ; [106.68180084,10.76527214] ; [106.68184662,10.76533604] ; [106.68186188,10.76541519] ; [106.68185425,10.76552582] ; [106.68189240,10.76566219] ; [106.68197632,10.76577854] ; [106.68253326,10.76621437] ; [106.68253326,10.76621437]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"290"
    ,"Station_Code":"Q1 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh viện T ù Dũ"
    ,"Station_Address":"Đối diện 446, đường  Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.768709
    ,"Long":106.685024
    ,"Polyline":"[106.68253326,10.76621437] ; [106.68502045,10.76870918]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"289"
    ,"Station_Code":"Q1 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"99, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.77185
    ,"Long":106.687943
    ,"Polyline":"[106.68502045,10.76870918] ; [106.68794250,10.77184963]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"292"
    ,"Station_Code":"Q1 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Sở Y Tế"
    ,"Station_Address":"Đối diện 214-216, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.774179
    ,"Long":106.690158
    ,"Polyline":"[106.68794250,10.77184963] ; [106.69015503,10.77417946]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"242"
    ,"Station_Code":"Q1 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhà Văn Hóa Lao Động"
    ,"Station_Address":"Đối diện số 138, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.777097
    ,"Long":106.692757
    ,"Polyline":"[106.69015503,10.77417946] ; [106.69275665,10.77709675]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"291"
    ,"Station_Code":"Q1 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Pasteur"
    ,"Station_Address":"43 - 45 - 47, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.781031
    ,"Long":106.696434
    ,"Polyline":"[106.69275665,10.77709675] ; [106.69643402,10.78103065]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"294"
    ,"Station_Code":"Q1 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Mạc Đỉnh Chi"
    ,"Station_Address":"21, đư ờng Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.784191
    ,"Long":106.699503
    ,"Polyline":"[106.69643402,10.78103065] ; [106.69950104,10.78419113]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"296"
    ,"Station_Code":"Q1 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đinh Tiên Hoa ̀ng"
    ,"Station_Address":"15C-15D, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.786146
    ,"Long":106.70137
    ,"Polyline":"[106.69950104,10.78419113] ; [106.70041656,10.78521347] ; [106.70137024,10.78614616]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"293"
    ,"Station_Code":"Q1 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Thảo Cầm Vi ên"
    ,"Station_Address":"3, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.789598
    ,"Long":106.70459
    ,"Polyline":"[106.70137024,10.78614616] ; [106.70458984,10.78959846]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"295"
    ,"Station_Code":"Q1 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Thị Nghè"
    ,"Station_Address":"1A, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.790669
    ,"Long":106.705597
    ,"Polyline":"[106.70458984,10.78959846] ; [106.70516205,10.79027748] ; [106.70559692,10.79066944]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"298"
    ,"Station_Code":"QBTH 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"22 B, đường Xô Viết Nghệ Tĩnh, Quận B ình Thạnh"
    ,"Lat":10.793445
    ,"Long":106.70814
    ,"Polyline":"[106.70559692,10.79066944] ; [106.70813751,10.79344463]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trung tâm Dưỡng Lão"
    ,"Station_Address":"138, đường Xô Viết Nghệ T ĩnh, Quận Bình Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70813751,10.79344463] ; [106.71009827,10.79551601] ; [106.71087646,10.79750156]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"246, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71087646,10.79750156] ; [106.71112061,10.79859257] ; [106.71124268,10.79976845]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"476"
    ,"Station_Code":"QBTH 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"500-502, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.800864
    ,"Long":106.714287
    ,"Polyline":"[106.71124268,10.79976845] ; [106.71133423,10.80074787] ; [106.71142578,10.80095387] ; [106.71166229,10.80114365] ; [106.71186829,10.80124378] ; [106.71209717,10.80130672] ; [106.71279907,10.80128002] ; [106.71376038,10.80104828] ; [106.71428680,10.80086422]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"473"
    ,"Station_Code":"QBTH 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"600, đường Đi ện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799547
    ,"Long":106.717409
    ,"Polyline":"[106.71428680,10.80086422] ; [106.71595764,10.80044746] ; [106.71645355,10.80021572] ; [106.71740723,10.79954720]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"475"
    ,"Station_Code":"QBTH 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"658, đường Điện Bi ên Phủ, Quận Bình Thạnh"
    ,"Lat":10.798525
    ,"Long":106.719496
    ,"Polyline":"[106.71740723,10.79954720] ; [106.71919250,10.79871464] ; [106.71949768,10.79852486]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"477"
    ,"Station_Code":"Q2 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"794, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.799978
    ,"Long":106.7342
    ,"Polyline":"[106.71949768,10.79852486] ; [106.72050476,10.79802418] ; [106.72158051,10.79780293] ; [106.72290802,10.79781342] ; [106.72425079,10.79807663] ; [106.73419952,10.79997826]"
    ,"Distance":"1647"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"478"
    ,"Station_Code":"Q2 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Đối diện ngã 3 Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800838
    ,"Long":106.738899
    ,"Polyline":"[106.73419952,10.79997826] ; [106.73889923,10.80083847]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"480"
    ,"Station_Code":"Q2 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"170, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801584
    ,"Long":106.742928
    ,"Polyline":"[106.73889923,10.80083847] ; [106.74292755,10.80158424]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"479"
    ,"Station_Code":"Q2 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Khu dân cư Estella , đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802592
    ,"Long":106.748089
    ,"Polyline":"[106.74292755,10.80158424] ; [106.74378204,10.80184937] ; [106.74474335,10.80208683] ; [106.74542999,10.80209160] ; [106.74589539,10.80204487] ; [106.74630737,10.80203915] ; [106.74668121,10.80213451] ; [106.74716949,10.80239201] ; [106.74743652,10.80249786] ; [106.74771118,10.80257130] ; [106.74809265,10.80259228]"
    ,"Distance":"585"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"482"
    ,"Station_Code":"Q9 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Xi măng hà tiên - trạm thu phí"
    ,"Station_Address":"249B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.819206
    ,"Long":106.758394
    ,"Polyline":"[106.74809265,10.80259228] ; [106.75114441,10.80375671] ; [106.75232697,10.80453682] ; [106.75341797,10.80537987] ; [106.75453949,10.80656052] ; [106.75546265,10.80784607] ; [106.75601959,10.80887890] ; [106.75642395,10.80995369] ; [106.75839233,10.81920624]"
    ,"Distance":"2331"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"481"
    ,"Station_Code":"Q9 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"185A, đường Xa  Lộ Hà Nội, Quận 9"
    ,"Lat":10.825972
    ,"Long":106.760775
    ,"Polyline":"[106.75839233,10.81920624] ; [106.75850677,10.82070255] ; [106.75889587,10.82234669] ; [106.75972748,10.82437038] ; [106.76077271,10.82597160]"
    ,"Distance":"810"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"485"
    ,"Station_Code":"Q9 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm xây dựng"
    ,"Station_Address":"354A, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.829955
    ,"Long":106.76312
    ,"Polyline":"[106.76077271,10.82597160] ; [106.76312256,10.82995510]"
    ,"Distance":"512"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"483"
    ,"Station_Code":"Q9 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Khu QLGTDT số 2"
    ,"Station_Address":"Khu QLGTĐT số 2, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.833249
    ,"Long":106.764778
    ,"Polyline":"[106.76312256,10.82995510.06.76477814]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"497"
    ,"Station_Code":"QTD 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường ĐHSP Kỹ Thuật"
    ,"Station_Address":"368, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849597
    ,"Long":106.771917
    ,"Polyline":"[106.76477814,10.83324909] ; [106.77043915,10.84310627] ; [106.77332306,10.84798431] ; [106.77432251,10.84916496] ; [106.77342224,10.84965992] ; [106.77191925,10.84959698]"
    ,"Distance":"2336"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"486"
    ,"Station_Code":"QTD 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Công ty Sanofi Aventis"
    ,"Station_Address":"Kế 50, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.841652
    ,"Long":106.764175
    ,"Polyline":"[106.77191925,10.84959698] ; [106.76638031,10.83939648] ; [106.76577759,10.84057713] ; [106.76417542,10.84165192]"
    ,"Distance":"1646"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"489"
    ,"Station_Code":"QTD 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Công ty may Sài Gòn"
    ,"Station_Address":"Đối diện 139, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.843897
    ,"Long":106.762466
    ,"Polyline":"[106.76417542,10.84165192] ; [106.76382446,10.84188366] ; [106.76351929,10.84215736] ; [106.76312256,10.84275818] ; [106.76246643,10.84389687]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"491"
    ,"Station_Code":"QTD 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Trường mầm  non Vành Khuyên"
    ,"Station_Address":"Trường mầm non Họa Mi, đường Đặng Văn  Bi, Quận Thủ Đức"
    ,"Lat":10.847888
    ,"Long":106.760056
    ,"Polyline":"[106.76246643,10.84389687] ; [106.76206970,10.84443378] ; [106.76169586,10.84499168] ; [106.76157379,10.84523392] ; [106.76153564,10.84557152] ; [106.76141357,10.84591961] ; [106.76123047,10.84638309] ; [106.76091003,10.84685707] ; [106.76005554,10.84788799]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"488"
    ,"Station_Code":"QTD 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Làng trẻ em SOS"
    ,"Station_Address":"238-240, đường Đặng Văn Bi, Quận Thủ Đức"
    ,"Lat":10.850015
    ,"Long":106.758781
    ,"Polyline":"[106.76005554,10.84788799] ; [106.75920105,10.84873295] ; [106.75887299,10.84923840] ; [106.75877380,10.84962845] ; [106.75878143,10.85001469]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"493"
    ,"Station_Code":"QTD 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"100, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850503
    ,"Long":106.759998
    ,"Polyline":"[106.75878143,10.85001469] ; [106.75865173,10.85063457] ; [106.75999451,10.85050297]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"490"
    ,"Station_Code":"QTD 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Cao đẳng xây dựng 2"
    ,"Station_Address":"190, đường Võ Văn  Ngân, Quận Thủ Đức"
    ,"Lat":10.85065
    ,"Long":106.764439
    ,"Polyline":"[106.75999451,10.85050297] ; [106.76196289,10.85041904] ; [106.76279449,10.85080814] ; [106.76444244,10.85064983]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"492"
    ,"Station_Code":"QTD 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Siêu thị Nguyễn Kim"
    ,"Station_Address":"274-276, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849686
    ,"Long":106.769112
    ,"Polyline":"[106.76444244,10.85064983] ; [106.76705170,10.85042381] ; [106.76720428,10.85037136] ; [106.76731873,10.85028648] ; [106.76765442,10.84988117] ; [106.76774597,10.84980774] ; [106.76821899,10.84971809] ; [106.76911163,10.84968567]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"494"
    ,"Station_Code":"Q9 218"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Công an Quận 9"
    ,"Station_Address":"Công an Quận  9, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.849966
    ,"Long":106.775066
    ,"Polyline":"[106.76911163,10.84968567] ; [106.77249908,10.84955502] ; [106.77332306,10.84958649] ; [106.77367401,10.84930134] ; [106.77413940,10.84897518] ; [106.77506256,10.84996605]"
    ,"Distance":"723"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"498"
    ,"Station_Code":"Q9 219"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Chợ chiều"
    ,"Station_Address":"Kế 830 (Chợ  Chiều), đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.853511
    ,"Long":106.780474
    ,"Polyline":"[106.77506256,10.84996605] ; [106.77681732,10.85136700] ; [106.78047180,10.85351086]"
    ,"Distance":"713"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"495"
    ,"Station_Code":"Q9 220"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Khu Công ngh ệ cao quận 9"
    ,"Station_Address":"Khu công ngh ệ cao, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.858511
    ,"Long":106.788869
    ,"Polyline":"[106.78047180,10.85351086] ; [106.78887177,10.85851097]"
    ,"Distance":"1074"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"500"
    ,"Station_Code":"QTD 180"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Đại học N ông Lâm"
    ,"Station_Address":"Đối diện 1026-1028, đường Quốc lộ 1, Quận  Thủ Đức"
    ,"Lat":10.866961
    ,"Long":106.791101
    ,"Polyline":"[106.78887177,10.85851097] ; [106.79617310,10.86289406] ; [106.79646301,10.86297894] ; [106.79677582,10.86302567] ; [106.79697418,10.86299992] ; [106.79711914,10.86294651] ; [106.79724884,10.86285210.06.79739380] ; [10.86265182,106.79744720] ; [10.86243629,106.79743195] ; [10.86219883,106.79739380] ; [10.86201954,106.79731750] ; [10.86186695,106.79720306] ; [10.86174583,106.79705811] ; [10.86167240,106.79680634] ; [10.86159801,106.79656982] ; [10.86161423,106.79629517] ; [10.86172485,106.79615784] ; [10.86183548,106.79605865] ; [10.86196136,106.79530334] ; [10.86315727,106.79434204] ; [10.86463261,106.79389191] ; [10.86521244,106.79259491] ; [10.86620235,106.79188538] ; [10.86659241,106.79109955]"
    ,"Distance":"2135"
  },
  {
     "Route_Id":"6"
    ,"Station_Id":"394"
    ,"Station_Code":"BX73"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Bến xe buýt ĐH Nông Lâm, đường  Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868183135986328
    ,"Long":106.78744506835938
    ,"Polyline":"[106.79109955,10.86696053] ; [106.79002380,10.86717701] ; [106.78910828,10.86727238] ; [106.78826141,10.86730862] ; [106.78818512,10.86743546] ; [106.78809357,10.86753559] ; [106.78796387,10.86764622] ; [106.78779602,10.86773014] ; [106.78774261,10.86785698] ; [106.78771973,10.86796188] ; [106.78772736,10.86808872] ; [106.78775787,10.86822033] ; [106.78761292,10.86826801] ; [106.78749847,10.86825752] ; [106.78744507,10.86818314]"
    ,"Distance":"480"
  }]