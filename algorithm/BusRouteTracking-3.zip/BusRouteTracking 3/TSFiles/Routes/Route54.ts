export const Route54 =[

  {
     "Route_Id":"54"
    ,"Station_Id":"4112"
    ,"Station_Code":"BX90"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến Xe Buýt ÐH Quốc Gia"
    ,"Station_Address":"Bến xe buýt Khu B - ĐH Quốc Gia,  đường Đường nội bộ Đại học Quốc gia, Quận Thủ Đức"
    ,"Lat":10.884156227111816
    ,"Long":106.77871704101562
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"572"
    ,"Station_Code":"QTD 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"621-Ngã 3 Lâm Viên"
    ,"Station_Address":"Nhà máy Tiến Thành, đường Quốc lộ 1, Qu ận Thủ Đức"
    ,"Lat":10.871128
    ,"Long":106.806979
    ,"Polyline":"[106.77839661,10.88381958] ; [106.78056335,10.88171959] ; [106.78067780,10.88156986] ; [106.78112030,10.88070011] ; [106.78235626,10.88173962] ; [106.78262329,10.88197994] ; [106.78328705,10.88132000] ; [106.78383636,10.88088036] ; [106.78441620,10.88057041] ; [106.78546906,10.88014984] ; [106.78618622,10.87996006] ; [106.78658295,10.87987041] ; [106.78692627,10.87983036] ; [106.78778839,10.87977982] ; [106.78838348,10.87981987] ; [106.78981018,10.87996960] ; [106.79183960,10.88002968] ; [106.79325867,10.88010025] ; [106.79380798,10.88022995] ; [106.79473114,10.88047981] ; [106.79518127,10.88061047] ; [106.79604340,10.88086033] ; [106.79662323,10.88103962] ; [106.79698944,10.88121986] ; [106.79818726,10.88191986] ; [106.79969788,10.88278961] ; [106.80030060,10.88302040] ; [106.80065918,10.88315010.06.80098724] ; [10.88236046,106.80172729] ; [10.88051987,106.80209351] ; [10.87961006,106.80281067] ; [10.87749004,106.80300140] ; [10.87689972,106.80316162] ; [10.87654018,106.80313873] ; [10.87640953,106.80323029] ; [10.87639999,106.80364227] ; [10.87631989,106.80442047] ; [10.87604046,106.80467987] ; [10.87590981,106.80506134] ; [10.87557030,106.80513000] ; [10.87547016,106.80523682] ; [10.87526035,106.80520630] ; [10.87500954,106.80558014] ; [10.87495995,106.80657959] ; [10.87452030,106.80677032] ; [10.87444019,106.80734253] ; [10.87413025,106.80787659] ; [10.87378979,106.80809784] ; [10.87347031,106.80850983] ; [10.87308979,106.80699158] ; [10.87098980,106.80683899]"
    ,"Distance":"4704"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo  dục Quốc phòng, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80697632,10.87112808] ; [106.80580139,10.86958504] ; [106.80436707,10.86821556]"
    ,"Distance":"392.058776326592"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"574"
    ,"Station_Code":"QTD 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Khu DL Su ối Tiên"
    ,"Station_Address":"9/29, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86605
    ,"Long":106.801116
    ,"Polyline":"[106.80436707,10.86821556] ; [106.80281830,10.86703491] ; [106.80111694,10.86604977]"
    ,"Distance":"427.71496060995"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"4560"
    ,"Station_Code":"QTD 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"18/1, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.865613
    ,"Long":106.800381
    ,"Polyline":"[106.80111694,10.86604977] ; [106.80111694,10.86604977] ; [106.80078125,10.86582375] ; [106.80038452,10.86561298] ; [106.80038452,10.86561298]"
    ,"Distance":"95.5968187887421"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2145"
    ,"Station_Code":"QTD 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Thảo Nguyên"
    ,"Station_Address":"35B, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.865335
    ,"Long":106.793938
    ,"Polyline":"[106.80038452,10.86561298] ; [106.79939270,10.86485386] ; [106.79801178,10.86447430] ; [106.79593658,10.86462212] ; [106.79489136,10.86480141] ; [106.79393768,10.86533546]"
    ,"Distance":"757"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"500"
    ,"Station_Code":"QTD 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Đối diện 1026-1028, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.866961
    ,"Long":106.791101
    ,"Polyline":"[106.79393768,10.86533546] ; [106.79309845,10.86587048] ; [106.79233551,10.86637115] ; [106.79109955,10.86696053]"
    ,"Distance":"358.595036225023"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"1101"
    ,"Station_Code":"QTD 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"Kế 21, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867404
    ,"Long":106.787265
    ,"Polyline":"[106.79109955,10.86696053] ; [106.79009247,10.86718273] ; [106.78726196,10.86740398]"
    ,"Distance":"481.482875050416"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"1102"
    ,"Station_Code":"QTD 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty điện tử Samsung"
    ,"Station_Address":"Kế 59/6, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867867
    ,"Long":106.782201
    ,"Polyline":"[106.78726196,10.86740398] ; [106.78545380,10.86739349] ; [106.78442383,10.86742496] ; [106.78344727,10.86752987] ; [106.78237915,10.86775112] ; [106.78220367,10.86786747]"
    ,"Distance":"497.848106194235"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"1103"
    ,"Station_Code":"QTD 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Đại học Kinh tế -Luật"
    ,"Station_Address":"Đại học Kinh tế -Luật, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.869274
    ,"Long":106.777909
    ,"Polyline":"[106.78220367,10.86786747] ; [106.77790833,10.86927414]"
    ,"Distance":"492.54871207259"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2142"
    ,"Station_Code":"QTD 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trung tâm kho vận Linh Xuân"
    ,"Station_Address":"Trung  tâm kho vận Linh Xuân, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870254
    ,"Long":106.774932
    ,"Polyline":"[106.77790833,10.86927414] ; [106.77790833,10.86927414] ; [106.77642822,10.86972141] ; [106.77493286,10.87025356] ; [106.77493286,10.87025356]"
    ,"Distance":"345.243235847098"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2147"
    ,"Station_Code":"QTD 185"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nghĩa trang Thành phố"
    ,"Station_Address":"Cột điện NG/1, đường Quốc  lộ 1, Quận Thủ Đức"
    ,"Lat":10.870912
    ,"Long":106.772878
    ,"Polyline":"[106.77493286,10.87025356] ; [106.77493286,10.87025356] ; [106.77390289,10.87051201] ; [106.77288055,10.87091160] ; [106.77288055,10.87091160]"
    ,"Distance":"233.840738510465"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2143"
    ,"Station_Code":"QTD 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Công ty Nissan"
    ,"Station_Address":"Đối diện công ty Nissan, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871571
    ,"Long":106.770823
    ,"Polyline":"[106.77288055,10.87091160] ; [106.77288055,10.87091160] ; [106.77182007,10.87117577] ; [106.77082062,10.87157059] ; [106.77082062,10.87157059]"
    ,"Distance":"237.985701417885"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"339"
    ,"Station_Code":"QTD 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu vượt Linh Xuân"
    ,"Station_Address":"559, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.874474
    ,"Long":106.762095
    ,"Polyline":"[106.77078247,10.87147045] ; [106.76754761,10.87252998] ; [106.76730347,10.87269974] ; [106.76686859,10.87285042] ; [106.76580811,10.87322998] ; [106.76458740,10.87362003] ; [106.76332092,10.87403965] ; [106.76293182,10.87407970] ; [106.76233673,10.87427998] ; [106.76203918,10.87438011]"
    ,"Distance":"1008.53532535519"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"341"
    ,"Station_Code":"QTD 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Giày da Thái Bình"
    ,"Station_Address":"467B, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875454
    ,"Long":106.758689
    ,"Polyline":"[106.76209259,10.87447357] ; [106.76120758,10.87467957] ; [106.75969696,10.87516880] ; [106.75868988,10.87545395]"
    ,"Distance":"385.054185290905"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"343"
    ,"Station_Code":"QTD 189"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bến xe Lam Hồng"
    ,"Station_Address":"Đối diện 20B/8, đường Quốc lộ 1, Quận Thủ  Đức"
    ,"Lat":10.875738
    ,"Long":106.757305
    ,"Polyline":"[106.75868988,10.87545395] ; [106.75797272,10.87550640] ; [106.75730133,10.87573814]"
    ,"Distance":"157.115740952676"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"342"
    ,"Station_Code":"QTD 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu vượt Sóng Thần"
    ,"Station_Address":"12/28, đường Quốc lộ 1, Qu ận Thủ Đức"
    ,"Lat":10.876049
    ,"Long":106.755631
    ,"Polyline":"[106.75730133,10.87573814] ; [106.75648499,10.87580109] ; [106.75563049,10.87604904]"
    ,"Distance":"192.080703894022"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"344"
    ,"Station_Code":"QTD 191"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu vượt Sóng Thần"
    ,"Station_Address":"275, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.874115
    ,"Long":106.746528
    ,"Polyline":"[106.75553131,10.87594032] ; [106.75489807,10.87605953] ; [106.75421906,10.87615967] ; [106.75382996,10.87617016] ; [106.75346375,10.87615013] ; [106.75312805,10.87609959] ; [106.75231934,10.87590027] ; [106.75132751,10.87557030] ; [106.74655151,10.87399960]"
    ,"Distance":"1034"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"346"
    ,"Station_Code":"QTD 192"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Tam Hà"
    ,"Station_Address":"251B, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.873373
    ,"Long":106.744291
    ,"Polyline":"[106.74652863,10.87411499] ; [106.74542236,10.87366199] ; [106.74429321,10.87337303]"
    ,"Distance":"256.162236722469"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"345"
    ,"Station_Code":"QTD 193"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"179, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.872177
    ,"Long":106.739913
    ,"Polyline":"[106.74429321,10.87337303] ; [106.74176788,10.87244987] ; [106.74092102,10.87224007] ; [106.73991394,10.87217712]"
    ,"Distance":"497.427634960903"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"348"
    ,"Station_Code":"QTD 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Tam Bình"
    ,"Station_Address":"Đối diện Bưu điện Tam Bình, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870828
    ,"Long":106.734474
    ,"Polyline":"[106.73991394,10.87217712] ; [106.73837280,10.87187004] ; [106.73751068,10.87174988] ; [106.73639679,10.87148952] ; [106.73533630,10.87110996] ; [106.73447418,10.87082767]"
    ,"Distance":"613.052203703902"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"347"
    ,"Station_Code":"QTD 195"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ đầu mối nông sản Thủ Đức"
    ,"Station_Address":"Chợ đầu mối nông sản Thủ  Đức, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86812
    ,"Long":106.729158
    ,"Polyline":"[106.73447418,10.87082767] ; [106.73307800,10.87003994] ; [106.73204041,10.86952972] ; [106.72915649,10.86812019]"
    ,"Distance":"700.422640211867"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2348"
    ,"Station_Code":"QTD 196"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Bình  Phước"
    ,"Station_Address":"39A, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.863451
    ,"Long":106.719894
    ,"Polyline":"[106.72915649,10.86812019] ; [106.72653198,10.86666965] ; [106.72357941,10.86522007] ; [106.71989441,10.86345100]"
    ,"Distance":"1091.95315825714"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2345"
    ,"Station_Code":"Q12 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Aone"
    ,"Station_Address":"Đối diện Aone, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860397
    ,"Long":106.713853
    ,"Polyline":"[106.71989441,10.86345100] ; [106.71694183,10.86185074] ; [106.71385193,10.86039734]"
    ,"Distance":"754.823797465654"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2349"
    ,"Station_Code":"Q12 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Công ty EUROPA"
    ,"Station_Address":"Công ty EUROPA, đường Quốc lộ 1A, Quận  12"
    ,"Lat":10.858996
    ,"Long":106.709325
    ,"Polyline":"[106.71346283,10.86003971] ; [106.71234131,10.85947037] ; [106.71154022,10.85908985] ; [106.71115875,10.85896969]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2347"
    ,"Station_Code":"Q12 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Chùa Khánh An"
    ,"Station_Address":"Kế Hi ệp Hưng (1048/3B), đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.85967
    ,"Long":106.70454
    ,"Polyline":"[106.70932770,10.85899639] ; [106.70854187,10.85892963] ; [106.70597839,10.85925007] ; [106.70453644,10.85966969]"
    ,"Distance":"529.443637302582"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2350"
    ,"Station_Code":"Q12 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trà Tiến  Đạt"
    ,"Station_Address":"501, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860197
    ,"Long":106.699905
    ,"Polyline":"[106.70453644,10.85966969] ; [106.70336914,10.85964870] ; [106.70123291,10.85988045] ; [106.69990540,10.86019707]"
    ,"Distance":"510.52612397211"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2351"
    ,"Station_Code":"Q12 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đình An Phú Đông"
    ,"Station_Address":"Đối diện đình An Phú Đông, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860576
    ,"Long":106.69703
    ,"Polyline":"[106.69990540,10.86019707] ; [106.69886780,10.86018658] ; [106.69767761,10.86032867] ; [106.69702911,10.86057568]"
    ,"Distance":"316.352592718523"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2353"
    ,"Station_Code":"Q12 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Quán Phú Đông"
    ,"Station_Address":"351  (Quán Phú Đông), đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860913
    ,"Long":106.691451
    ,"Polyline":"[106.69702911,10.86057568] ; [106.69606018,10.86050034] ; [106.69525146,10.86056042] ; [106.69335938,10.86073017] ; [106.69145203,10.86091328]"
    ,"Distance":"403.332283324285"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2352"
    ,"Station_Code":"Q12 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Công ty H ồng Mã"
    ,"Station_Address":"Công ty Hồng Mã, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861061
    ,"Long":106.689734
    ,"Polyline":"[106.69145203,10.86091328] ; [106.69056702,10.86088657] ; [106.68973541,10.86106110]"
    ,"Distance":"393.722253513609"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2355"
    ,"Station_Code":"Q12 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Phường An  Phú Đông"
    ,"Station_Address":"616 - 618, đư ờng Quốc lộ 1A, Quận 12"
    ,"Lat":10.861324
    ,"Long":106.685797
    ,"Polyline":"[106.68975830,10.86091042] ; [106.68576813,10.86116982]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2357"
    ,"Station_Code":"Q12 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Cầu Ga Nhỏ"
    ,"Station_Address":"189, đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.861503
    ,"Long":106.682321
    ,"Polyline":"[106.68579865,10.86132431] ; [106.68404388,10.86133671] ; [106.68231964,10.86150265]"
    ,"Distance":"366.095964415682"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2354"
    ,"Station_Code":"Q12 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"B ến xe Ngã tư ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861788
    ,"Long":106.678517
    ,"Polyline":"[106.68231964,10.86150265] ; [106.68137360,10.86153507] ; [106.68003845,10.86161900] ; [106.67852020,10.86178780]"
    ,"Distance":"430.678731732242"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"976"
    ,"Station_Code":"Q12 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Đá hoa c ương Hoà Thắng"
    ,"Station_Address":"96/2, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.86193
    ,"Long":106.675143
    ,"Polyline":"[106.67852020,10.86178780] ; [106.67665863,10.86180401] ; [106.67514038,10.86192989]"
    ,"Distance":"368.3553281478"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"964"
    ,"Station_Code":"Q12 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Tô Ngọc V ân"
    ,"Station_Address":"972, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861904
    ,"Long":106.671935
    ,"Polyline":"[106.67514038,10.86192989] ; [106.67465210,10.86181927] ; [106.67407227,10.86184025] ; [106.67252350,10.86182022] ; [106.67193604,10.86190414]"
    ,"Distance":"286.93009928659"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"965"
    ,"Station_Code":"Q12 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Khách sạn Thạnh Xuân"
    ,"Station_Address":"Khách sạn Thạnh Xuân, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.861862
    ,"Long":106.665863
    ,"Polyline":"[106.67193604,10.86190414] ; [106.66986847,10.86176968] ; [106.66723633,10.86174965] ; [106.66586304,10.86186218]"
    ,"Distance":"727.358678468733"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"977"
    ,"Station_Code":"Q12 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Khách sạn Phi Vũ"
    ,"Station_Address":"Khách sạn Phi Vũ, đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.861862
    ,"Long":106.660016
    ,"Polyline":"[106.66586304,10.86186218] ; [106.66429901,10.86172962] ; [106.66304016,10.86166954] ; [106.66181946,10.86165047] ; [106.66075897,10.86171913] ; [106.66001892,10.86186218]"
    ,"Distance":"612.251375363656"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"966"
    ,"Station_Code":"Q12 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Bãi xe Tri Ân"
    ,"Station_Address":"1360, đường Quốc lộ 1A, Quận  12"
    ,"Lat":10.86202
    ,"Long":106.656121
    ,"Polyline":"[106.66001892,10.86186218] ; [106.65778351,10.86180973] ; [106.65612030,10.86201954]"
    ,"Distance":"271.37671891724"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"969"
    ,"Station_Code":"Q12 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Quận ủy Quận 12"
    ,"Station_Address":"1456 (Quận Ủy quận 12) , đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.86212
    ,"Long":106.653659
    ,"Polyline":"[106.65612030,10.86201954] ; [106.65445709,10.86198044] ; [106.65365601,10.86211967]"
    ,"Distance":"364.140447837537"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"972"
    ,"Station_Code":"Q12 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Tân Thới Hiệp"
    ,"Station_Address":"1680, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.862273
    ,"Long":106.650757
    ,"Polyline":"[106.65365601,10.86211967] ; [106.65267944,10.86205959] ; [106.65244293,10.86209965] ; [106.65189362,10.86211967] ; [106.65117645,10.86215973] ; [106.65075684,10.86227322]"
    ,"Distance":"405.210438886886"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2775"
    ,"Station_Code":"Q12 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cao su Vina"
    ,"Station_Address":"67/3A, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861767
    ,"Long":106.648536
    ,"Polyline":"[106.65075684,10.86217976] ; [106.65035248,10.86217976] ; [106.64987183,10.86213017] ; [106.64955902,10.86207008] ; [106.64903259,10.86190033] ; [106.64859009,10.86170006] ; [106.64779663,10.86126041] ; [106.64762115,10.86116982] ; [106.64756012,10.86108017] ; [106.64707947,10.86083984] ; [106.64672852,10.86065960]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2776"
    ,"Station_Code":"Q12 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Cây xăng Trung Tín"
    ,"Station_Address":"1828, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860302
    ,"Long":106.645682
    ,"Polyline":"[106.64672852,10.86065960] ; [106.64382935,10.85908031]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2777"
    ,"Station_Code":"Q12 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm điện Hóc Môn"
    ,"Station_Address":"1956, đường Quốc lộ 1A, Quận  12"
    ,"Lat":10.857668
    ,"Long":106.640918
    ,"Polyline":"[106.64568329,10.86030197] ; [106.64483643,10.85964394] ; [106.64382935,10.85908031] ; [106.64213562,10.85814190] ; [106.64091492,10.85766792]"
    ,"Distance":"351.64420864763"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2778"
    ,"Station_Code":"Q12 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngã 4 Đình"
    ,"Station_Address":"44D, đường Qu ốc lộ 1A, Quận 12"
    ,"Lat":10.856256
    ,"Long":106.638172
    ,"Polyline":"[106.64091492,10.85766792] ; [106.64042664,10.85723114] ; [106.63936615,10.85661983] ; [106.63816833,10.85625553]"
    ,"Distance":"322.648503601326"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2779"
    ,"Station_Code":"Q12 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà lầu"
    ,"Station_Address":"228 /3, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.855055
    ,"Long":106.636165
    ,"Polyline":"[106.63816833,10.85625553] ; [106.63796997,10.85586643] ; [106.63690186,10.85528660] ; [106.63616180,10.85505486]"
    ,"Distance":"267.633760137594"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2781"
    ,"Station_Code":"Q12 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Trường Nguy ễn Du"
    ,"Station_Address":"Đối diện Trường Nguyễn Du, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.853048
    ,"Long":106.632469
    ,"Polyline":"[106.63616180,10.85505486] ; [106.63547516,10.85454369] ; [106.63333893,10.85340023] ; [106.63246918,10.85304832]"
    ,"Distance":"461.432086690047"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2780"
    ,"Station_Code":"Q12 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Công viên phần mềm Quang Trung"
    ,"Station_Address":"Công viên phần mềm Quang Trung, đường Qu ốc lộ 1A, Quận 12"
    ,"Lat":10.852242
    ,"Long":106.630935
    ,"Polyline":"[106.63246918,10.85304832] ; [106.63179016,10.85256290] ; [106.63093567,10.85224247]"
    ,"Distance":"193.0293288491"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2254"
    ,"Station_Code":"Q12 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Chung cư Thái An"
    ,"Station_Address":"Chung cư Thái An, đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.84907
    ,"Long":106.624348
    ,"Polyline":"[106.63093567,10.85224247] ; [106.63031769,10.85183048] ; [106.62950134,10.85138035] ; [106.62734985,10.85037041] ; [106.62551880,10.84953308] ; [106.62435150,10.84906960]"
    ,"Distance":"808.827489413196"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2250"
    ,"Station_Code":"Q12 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Trạm đăng kiểm"
    ,"Station_Address":"Tra ̣m đăng kiểm, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.8475
    ,"Long":106.621059
    ,"Polyline":"[106.62435150,10.84906960] ; [106.62364197,10.84863758] ; [106.62241364,10.84805870] ; [106.62105560,10.84749985]"
    ,"Distance":"397.270735171532"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2251"
    ,"Station_Code":"Q12 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"bãi xe T ây Nam"
    ,"Station_Address":"Đối diện bến xe Tây Nam, đường Quốc lộ  1A, Quận 12"
    ,"Lat":10.845935
    ,"Long":106.618758
    ,"Polyline":"[106.62105560,10.84749985] ; [106.62072754,10.84724140] ; [106.61995697,10.84687328] ; [106.61934662,10.84643078] ; [106.61875916,10.84593487]"
    ,"Distance":"306.260618280998"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2252"
    ,"Station_Code":"Q12 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Cầu vượt An Sương"
    ,"Station_Address":"Xưởng Z735, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.843623
    ,"Long":106.616081
    ,"Polyline":"[106.61875916,10.84593487] ; [106.61757660,10.84479046] ; [106.61730957,10.84451771] ; [106.61677551,10.84405422] ; [106.61608124,10.84362316]"
    ,"Distance":"390.707109986815"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Qu ận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61611938,10.84358978] ; [106.61585999,10.84340000] ; [106.61557770,10.84327030] ; [106.61543274,10.84325027] ; [106.61528015,10.84325981] ; [106.61514282,10.84331989] ; [106.61502075,10.84340954] ; [106.61475372,10.84370995] ; [106.61412811,10.84465981] ; [106.61334991,10.84585953] ; [106.61253357,10.84716034] ; [106.61244202,10.84726048] ; [106.61237335,10.84720993] ; [106.61290741,10.84638023] ; [106.61348724,10.84547043] ; [106.61405182,10.84459972] ; [106.61338806,10.84424973] ; [106.61311340,10.84409046] ; [106.61316681,10.84397030] ; [106.61319733,10.84385967]"
    ,"Distance":"1176"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2342"
    ,"Station_Code":"Q12T255"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Cầu vượt An Sương"
    ,"Station_Address":"17A-4/8A, đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.844568252563477
    ,"Long":106.61766052246094
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61504364,10.84255981] ; [106.61511993,10.84243011] ; [106.61530304,10.84235001] ; [106.61544800,10.84235001] ; [106.61559296,10.84243965] ; [106.61566162,10.84257984] ; [106.61566162,10.84274006] ; [106.61625671,10.84329033] ; [106.61739349,10.84432983] ; [106.61760712,10.84459972]"
    ,"Distance":"838"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2343"
    ,"Station_Code":"Q12 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Bến xe Tây Nam"
    ,"Station_Address":"2531(Bến xe Tây Nam), đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.845851
    ,"Long":106.619087
    ,"Polyline":"[106.61766052,10.84456825] ; [106.61768341,10.84469032] ; [106.61805725,10.84502983] ; [106.61904907,10.84589005] ; [106.61908722,10.84585094]"
    ,"Distance":"211.468981818577"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2341"
    ,"Station_Code":"Q12 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm đăng kiểm"
    ,"Station_Address":"Đối diện trạm đăng kiểm, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.847418
    ,"Long":106.621506
    ,"Polyline":"[106.61904907,10.84589005] ; [106.61949158,10.84626007] ; [106.62000275,10.84663963] ; [106.62055206,10.84698963] ; [106.62114716,10.84731007] ; [106.62148285,10.84747982]"
    ,"Distance":"316.766673164803"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2346"
    ,"Station_Code":"Q12 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Thái An"
    ,"Station_Address":"B336, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.848157
    ,"Long":106.623123
    ,"Polyline":"[106.62148285,10.84747982] ; [106.62309265,10.84821987]"
    ,"Distance":"195.037660220424"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2344"
    ,"Station_Code":"Q12 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Đài phát thanh  Quán Tre"
    ,"Station_Address":"Đài phát thanh  quán tre, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.849082
    ,"Long":106.625069
    ,"Polyline":"[106.62309265,10.84821987] ; [106.62503815,10.84912968]"
    ,"Distance":"236.31781550803"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2677"
    ,"Station_Code":"Q12 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Phan Bội Ch âu"
    ,"Station_Address":"Trường Nguyễn Du, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.852583
    ,"Long":106.632347
    ,"Polyline":"[106.62503815,10.84912968] ; [106.62892151,10.85093975] ; [106.63069153,10.85177040] ; [106.63229370,10.85262012]"
    ,"Distance":"886.056170587493"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2675"
    ,"Station_Code":"Q12 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bác sĩ Liêm"
    ,"Station_Address":"103/4B, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.853322
    ,"Long":106.633719
    ,"Polyline":"[106.63231659,10.85262966] ; [106.63368225,10.85338974]"
    ,"Distance":"171.718507761621"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2676"
    ,"Station_Code":"Q12 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã tư Đình"
    ,"Station_Address":"1793B, đường Quốc lộ 1A , Quận 12"
    ,"Lat":10.856667
    ,"Long":106.639832
    ,"Polyline":"[106.63368225,10.85338974] ; [106.63980103,10.85671997]"
    ,"Distance":"764.343624432341"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2678"
    ,"Station_Code":"Q12 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cây xăng Thạnh Xuân"
    ,"Station_Address":"Kế cây xăng Thạnh Xuân, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.858953
    ,"Long":106.644233
    ,"Polyline":"[106.63980103,10.85671997] ; [106.64185333,10.85785007] ; [106.64353180,10.85875034] ; [106.64417267,10.85910034]"
    ,"Distance":"545.759554581811"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2680"
    ,"Station_Code":"Q12 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cao su Vina"
    ,"Station_Address":"1721, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.86097
    ,"Long":106.647781
    ,"Polyline":"[106.64423370,10.85895348] ; [106.64466095,10.85935402] ; [106.64495850,10.85951996] ; [106.64512634,10.85964012] ; [106.64698792,10.86065006] ; [106.64733124,10.86082363] ; [106.64777374,10.86102962] ; [106.64778137,10.86096954]"
    ,"Distance":"446.62362930627"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"932"
    ,"Station_Code":"Q12 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã tư Tân Thới Hiệp"
    ,"Station_Address":"79/1, đường Qu ốc lộ 1A, Quận 12"
    ,"Lat":10.861881
    ,"Long":106.651199
    ,"Polyline":"[106.64777374,10.86102962] ; [106.64784241,10.86104965] ; [106.64851379,10.86139965] ; [106.64910889,10.86168957] ; [106.64945984,10.86180019] ; [106.64978027,10.86188984] ; [106.65019226,10.86194992] ; [106.65064240,10.86196041] ; [106.65119934,10.86194038]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"935"
    ,"Station_Code":"Q12 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"UBND Quận 12"
    ,"Station_Address":"1251, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861808
    ,"Long":106.654053
    ,"Polyline":"[106.65119934,10.86188126] ; [106.65119934,10.86194038] ; [106.65180206,10.86199284] ; [106.65242004,10.86196136] ; [106.65280151,10.86197758] ; [106.65324402,10.86194611] ; [106.65406036,10.86186028] ; [106.65405273,10.86180782]"
    ,"Distance":"312.054730386085"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"933"
    ,"Station_Code":"Q12 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Bãi xe Tri  Ân"
    ,"Station_Address":"1797, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861651
    ,"Long":106.657127
    ,"Polyline":"[106.65406036,10.86186028] ; [106.65550995,10.86178970] ; [106.65712738,10.86172009]"
    ,"Distance":"336.586828996669"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"936"
    ,"Station_Code":"Q12 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Khách sạn  Phi Vũ"
    ,"Station_Address":"973, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861335
    ,"Long":106.662247
    ,"Polyline":"[106.65712738,10.86165142] ; [106.65712738,10.86172009] ; [106.66036224,10.86155987] ; [106.66119385,10.86152458] ; [106.66224670,10.86133480]"
    ,"Distance":"553.370249752892"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"942"
    ,"Station_Code":"Q12 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Gò Sao"
    ,"Station_Address":"109 , đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861503
    ,"Long":106.666458
    ,"Polyline":"[106.66224670,10.86133480] ; [106.66271210,10.86156654] ; [106.66432953,10.86161041] ; [106.66557312,10.86160374] ; [106.66645813,10.86150265]"
    ,"Distance":"465.577038364063"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"937"
    ,"Station_Code":"Q12 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Cây xăng Thạnh Xuân"
    ,"Station_Address":"Cây xăng Thạnh Xuân, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861577
    ,"Long":106.671882
    ,"Polyline":"[106.66644287,10.86163998] ; [106.66767883,10.86161995] ; [106.67015076,10.86163998] ; [106.67188263,10.86166954]"
    ,"Distance":"594.713143494058"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"938"
    ,"Station_Code":"Q12 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Cả Bốn"
    ,"Station_Address":"109, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.861619
    ,"Long":106.674446
    ,"Polyline":"[106.67188263,10.86166954] ; [106.67445374,10.86170006]"
    ,"Distance":"280.283213406121"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"944"
    ,"Station_Code":"Q12 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Đối diện Bx Ngã tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861472
    ,"Long":106.678078
    ,"Polyline":"[106.67445374,10.86170006] ; [106.67534637,10.86168957] ; [106.67703247,10.86161041] ; [106.67807770,10.86155033]"
    ,"Distance":"397.415570119312"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2356"
    ,"Station_Code":"Q12 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu Ga"
    ,"Station_Address":"30, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861229
    ,"Long":106.68174
    ,"Polyline":"[106.67807770,10.86147213] ; [106.67807770,10.86153984] ; [106.67881012,10.86156178] ; [106.68047333,10.86143494] ; [106.68120575,10.86138248] ; [106.68173981,10.86128998] ; [106.68173981,10.86122894]"
    ,"Distance":"401.401266097855"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2359"
    ,"Station_Code":"Q12 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"An Phú Đông"
    ,"Station_Address":"365 - 501, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.86103
    ,"Long":106.684921
    ,"Polyline":"[106.68173981,10.86122894] ; [106.68173981,10.86128998] ; [106.68338013,10.86131382] ; [106.68492126,10.86108971] ; [106.68492126,10.86102962]"
    ,"Distance":"348.521110092138"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2358"
    ,"Station_Code":"Q12 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty Vĩnh Hưng"
    ,"Station_Address":"Kế công ty Vĩnh Hưng (TMI), đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.86075
    ,"Long":106.689178
    ,"Polyline":"[106.68492126,10.86102962] ; [106.68492126,10.86108971] ; [106.68711853,10.86096573] ; [106.68917847,10.86081028] ; [106.68917847,10.86075020]"
    ,"Distance":"466.458987109792"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2360"
    ,"Station_Code":"Q12 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Chợ An Phú Đông"
    ,"Station_Address":"388/5A (1544/1B), đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.860463
    ,"Long":106.69384
    ,"Polyline":"[106.68917847,10.86075020] ; [106.68917847,10.86081028] ; [106.69187164,10.86065006] ; [106.69384003,10.86052036] ; [106.69384003,10.86046314]"
    ,"Distance":"510.628651239913"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2361"
    ,"Station_Code":"Q12 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Công ty Dương Linh"
    ,"Station_Address":"Kế công ty Dương Linh, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860074
    ,"Long":106.697968
    ,"Polyline":"[106.69384003,10.86046314] ; [106.69384003,10.86052036] ; [106.69480133,10.86056519] ; [106.69679260,10.86028957] ; [106.69796753,10.86013031] ; [106.69796753,10.86007404]"
    ,"Distance":"453.316237763044"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2364"
    ,"Station_Code":"Q12 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Công ty Tân Nam Tiến"
    ,"Station_Address":"1126/3A (Công  ty Tân Nam Tiến), đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.859648
    ,"Long":106.701317
    ,"Polyline":"[106.69796753,10.86013031] ; [106.69863129,10.86003971] ; [106.70040894,10.85982990] ; [106.70131683,10.85970020]"
    ,"Distance":"369.227805661813"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2362"
    ,"Station_Code":"Q12 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Công ty  Đinh Đan"
    ,"Station_Address":"1268 (Công ty Đinh Đan), đường Quốc lộ 1A , Quận 12"
    ,"Lat":10.859035
    ,"Long":106.706116
    ,"Polyline":"[106.70131683,10.85964775] ; [106.70131683,10.85970020] ; [106.70387268,10.85941696] ; [106.70612335,10.85908985] ; [106.70611572,10.85903454]"
    ,"Distance":"529.052181626544"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2363"
    ,"Station_Code":"Q12 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Bãi đậu xe kho hàng"
    ,"Station_Address":"1500/3C (Bãi đậu xe kho hàng), đường Qu ốc lộ 1A, Quận 12"
    ,"Lat":10.858574
    ,"Long":106.708982
    ,"Polyline":"[106.70611572,10.85903454] ; [106.70612335,10.85908985] ; [106.70700073,10.85905361] ; [106.70803070,10.85889053] ; [106.70905304,10.85873032] ; [106.70898438,10.85857391]"
    ,"Distance":"316.351833854138"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2368"
    ,"Station_Code":"Q12 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Aone"
    ,"Station_Address":"Aone, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860176
    ,"Long":106.714507
    ,"Polyline":"[106.70908356,10.85873032] ; [106.70955658,10.85861969] ; [106.70992279,10.85857964] ; [106.71041870,10.85857010.06.71083069] ; [10.85861969,106.71150208] ; [10.85875988,106.71224213] ; [10.85906982,106.71302032] ; [10.85947037,106.71459961]"
    ,"Distance":"691"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2365"
    ,"Station_Code":"QTD 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã 4 Bình Phước"
    ,"Station_Address":"33/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.863315
    ,"Long":106.720451
    ,"Polyline":"[106.71450806,10.86017609] ; [106.71459961,10.86030006] ; [106.71668243,10.86146164] ; [106.71798706,10.86211491] ; [106.71958923,10.86291981] ; [106.72042847,10.86336040] ; [106.72045135,10.86331463]"
    ,"Distance":"750.334383371171"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"315"
    ,"Station_Code":"QTD 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ Đầu M ối"
    ,"Station_Address":"120, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86689
    ,"Long":106.727425
    ,"Polyline":"[106.72042847,10.86336040] ; [106.72113037,10.86373997] ; [106.72338104,10.86483002] ; [106.72367859,10.86493969] ; [106.72384644,10.86493015] ; [106.72399139,10.86491966] ; [106.72412872,10.86499977] ; [106.72418213,10.86509991] ; [106.72418976,10.86515045] ; [106.72427368,10.86524010.06.72438049] ; [10.86532974,106.72463989] ; [10.86544991,106.72666168] ; [10.86645985,106.72680664] ; [10.86657047,106.72708893] ; [10.86682034,106.72718048] ; [10.86686993,106.72737885]"
    ,"Distance":"859.986390814364"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"320"
    ,"Station_Code":"QTD 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Chợ Đầu Mối"
    ,"Station_Address":"160, đường Quốc lộ 1, Quận  Thủ Đức"
    ,"Lat":10.86831
    ,"Long":106.730198
    ,"Polyline":"[106.72742462,10.86688995] ; [106.72737885,10.86697006] ; [106.72966766,10.86817265] ; [106.73020172,10.86830997]"
    ,"Distance":"342.428806715519"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"317"
    ,"Station_Code":"QTD 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Tam Bình"
    ,"Station_Address":"Chợ  Tam Bình, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.87086
    ,"Long":106.73538
    ,"Polyline":"[106.73020172,10.86830997] ; [106.73054504,10.86859989] ; [106.73095703,10.86884022] ; [106.73193359,10.86931038] ; [106.73319244,10.86993027] ; [106.73468781,10.87067986] ; [106.73535919,10.87098026] ; [106.73538208,10.87086010]"
    ,"Distance":"636.549272730913"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"322"
    ,"Station_Code":"QTD 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"376, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871766
    ,"Long":106.739666
    ,"Polyline":"[106.73535919,10.87098026] ; [106.73597717,10.87121964] ; [106.73674774,10.87143993] ; [106.73748779,10.87160969] ; [106.73834991,10.87172985] ; [106.73964691,10.87189960]"
    ,"Distance":"478.877214442436"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"319"
    ,"Station_Code":"QTD 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Tam Hải"
    ,"Station_Address":"450 , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.872935
    ,"Long":106.744081
    ,"Polyline":"[106.73964691,10.87189960] ; [106.74082184,10.87207985] ; [106.74160767,10.87226963] ; [106.74257660,10.87257004] ; [106.74403381,10.87304974]"
    ,"Distance":"496.322931092688"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"321"
    ,"Station_Code":"QTD 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu vượt Sóng  Thần"
    ,"Station_Address":"Đối diện 275, đường  Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.873905
    ,"Long":106.747128
    ,"Polyline":"[106.74403381,10.87304974] ; [106.74707794,10.87403011]"
    ,"Distance":"350.757961575321"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"323"
    ,"Station_Code":"QTD 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Bến xe Lam Hồng"
    ,"Station_Address":"6/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.875706
    ,"Long":106.75562
    ,"Polyline":"[106.74707794,10.87403011] ; [106.74913025,10.87469006] ; [106.75228119,10.87574005] ; [106.75308990,10.87596035] ; [106.75370026,10.87602043] ; [106.75434113,10.87600994] ; [106.75489807,10.87592983] ; [106.75566101,10.87580013]"
    ,"Distance":"988"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"325"
    ,"Station_Code":"QTD 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Giày da Th ái Bình"
    ,"Station_Address":"20/8, đường Quốc  lộ 1, Quận Thủ Đức"
    ,"Lat":10.875353
    ,"Long":106.757466
    ,"Polyline":"[106.75566101,10.87580013] ; [106.75749969,10.87545013]"
    ,"Distance":"204.566713173213"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"328"
    ,"Station_Code":"QTD 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Linh Xuân"
    ,"Station_Address":"54/8, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.874474
    ,"Long":106.76091
    ,"Polyline":"[106.75746918,10.87535286] ; [106.75748444,10.87539387] ; [106.75922394,10.87512684] ; [106.76092529,10.87457085] ; [106.76091003,10.87447357]"
    ,"Distance":"387.152348659692"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"324"
    ,"Station_Code":"QTD 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Cầu vượt Linh Xuân"
    ,"Station_Address":"Kho 856, đường Quốc lộ 1, Qu ận Thủ Đức"
    ,"Lat":10.873973
    ,"Long":106.762476
    ,"Polyline":"[106.76091003,10.87447357] ; [106.76139832,10.87446880] ; [106.76194763,10.87428951] ; [106.76229095,10.87418938] ; [106.76247406,10.87397289]"
    ,"Distance":"179.783046294244"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2083"
    ,"Station_Code":"QTD 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Vietcombank"
    ,"Station_Address":"Ngân hàng Vietcombank, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871597
    ,"Long":106.769643
    ,"Polyline":"[106.76248169,10.87404919] ; [106.76249695,10.87411022] ; [106.76289368,10.87397957] ; [106.76309204,10.87384033] ; [106.76686859,10.87255001] ; [106.76715088,10.87246037] ; [106.76751709,10.87233448] ; [106.76966095,10.87170982] ; [106.76964569,10.87165546]"
    ,"Distance":"827.267009036889"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"2084"
    ,"Station_Code":"QTD 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Nghĩa trang TP"
    ,"Station_Address":"Cổng nghĩa trang thành phố, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870507
    ,"Long":106.773039
    ,"Polyline":"[106.76966095,10.87170982] ; [106.77307129,10.87059975]"
    ,"Distance":"391.778023604437"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"1040"
    ,"Station_Code":"QTD 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"ĐH Kinh tế Luật"
    ,"Station_Address":"Đối diện 665, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.869306
    ,"Long":106.776724
    ,"Polyline":"[106.77307129,10.87059975] ; [106.77645874,10.86948967]"
    ,"Distance":"391.694195408589"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"1041"
    ,"Station_Code":"QTD 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Công ty điện tử Samsung"
    ,"Station_Address":"C ông ty điện tử Samsung, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868691
    ,"Long":106.778656
    ,"Polyline":"[106.77672577,10.86930561] ; [106.77712250,10.86926842] ; [106.77748108,10.86913967] ; [106.77867889,10.86874962] ; [106.77865601,10.86869144]"
    ,"Distance":"255.352577657702"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"1042"
    ,"Station_Code":"QTD 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"Cột điện SI 2, đường Quốc lộ 1, Quận Th ủ Đức"
    ,"Lat":10.867122
    ,"Long":106.787277
    ,"Polyline":"[106.77867889,10.86874962] ; [106.78009033,10.86828041] ; [106.78092194,10.86802959] ; [106.78225708,10.86762047] ; [106.78260803,10.86752033] ; [106.78318787,10.86740017] ; [106.78382111,10.86732960] ; [106.78704071,10.86719036] ; [106.78727722,10.86717987]"
    ,"Distance":"977"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"396"
    ,"Station_Code":"QTD 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"1030 , đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.866912
    ,"Long":106.790283
    ,"Polyline":"[106.78727722,10.86717987] ; [106.78822327,10.86713028] ; [106.78961182,10.86707020] ; [106.79029846,10.86695957]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"54"
    ,"Station_Id":"4112"
    ,"Station_Code":"BX90"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến Xe Buýt ÐH  Quốc Gia"
    ,"Station_Address":"Bến xe buýt Khu B - ĐH Quốc Gia, đường Đường nội bộ Đại học Quốc gia, Quận Thủ Đức"
    ,"Lat":10.884156227111816
    ,"Long":106.77871704101562
    ,"Polyline":"[106.79028320,10.86691189] ; [106.79116821,10.86675072] ; [106.79175568,10.86642361] ; [106.79295349,10.86580181] ; [106.79386902,10.86502266] ; [106.79534149,10.86282063] ; [106.79602814,10.86161900] ; [106.79587555,10.86099720] ; [106.79519653,10.86076546] ; [106.79468536,10.86102962] ; [106.79460144,10.86152458] ; [106.79485321,10.86198807] ; [106.79518127,10.86240959] ; [106.79659271,10.86313629] ; [106.79796600,10.86391640] ; [106.80067444,10.86559200] ; [106.80303192,10.86700344] ; [106.80498505,10.86843681] ; [106.80672455,10.87054348] ; [106.80868530,10.87306690] ; [106.80825806,10.87337303] ; [106.80787659,10.87375164] ; [106.80747986,10.87409973] ; [106.80693817,10.87438965] ; [106.80610657,10.87476826] ; [106.80563354,10.87501144] ; [106.80538177,10.87525368] ; [106.80509186,10.87563229] ; [106.80467224,10.87605381] ; [106.80355835,10.87647533] ; [106.80325317,10.87665462] ; [106.80307007,10.87707043] ; [106.80285645,10.87768745] ; [106.80265045,10.87830925] ; [106.80238342,10.87913609] ; [106.80206299,10.87997341] ; [106.80190277,10.88036346] ; [106.80145264,10.88148499] ; [106.80107117,10.88244438] ; [106.80090332,10.88284492] ; [106.80069733,10.88331890] ; [106.79926300,10.88274479] ; [106.79708099,10.88138008] ; [106.79523468,10.88070011] ; [106.79369354,10.88026810.06.79283905] ; [10.88014221,106.79187012] ; [10.88021564,106.78866577] ; [10.87995243,106.78721619] ; [10.87989426,106.78633118] ; [10.88004684,106.78528595] ; [10.88037395,106.78440857] ; [10.88069534,106.78362274] ; [10.88117981,106.78282928] ; [10.88193798,106.78232574] ; [10.88171196,106.78112030] ; [10.88067913,106.78079224] ; [10.88112164,106.78063202] ; [10.88159561,106.78015900] ; [10.88192272,106.77972412] ; [10.88241768,106.77902222] ; [10.88321877,106.77828217] ; [10.88379765,106.77871704]"
    ,"Distance":"7596"
  }]