export const Route88 =[
  {
     "Route_Id":"88"
    ,"Station_Id":"3362"
    ,"Station_Code":"QTD 212"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Cầu Vĩnh Bình"
    ,"Station_Address":"875, đường Quốc lộ 13, Quận Thủ  Đức"
    ,"Lat":10.867865
    ,"Long":106.718254
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"3360"
    ,"Station_Code":"QTD 213"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Xây dựng Ngọc Đào"
    ,"Station_Address":"Kế 801, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.866772
    ,"Long":106.722847
    ,"Polyline":"[106.71824646,10.86793041] ; [106.72038269,10.86793995] ; [106.72103882,10.86789036] ; [106.72151947,10.86777020] ; [106.72181702,10.86763954] ; [106.72219086,10.86744976] ; [106.72248840,10.86721992] ; [106.72271729,10.86701965] ; [106.72290039,10.86680984]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"349"
    ,"Station_Code":"QTD 214"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã 4 Bình Phước"
    ,"Station_Address":"777, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.863809
    ,"Long":106.72451
    ,"Polyline":"[106.72290039,10.86680984] ; [106.72315979,10.86645031] ; [106.72353363,10.86579037] ; [106.72358704,10.86559010.06.72355652] ; [10.86544991,106.72354889] ; [10.86542034,106.72355652] ; [10.86528015,106.72366333] ; [10.86507034,106.72380066] ; [10.86495018,106.72390747] ; [10.86491013,106.72409058] ; [10.86472034,106.72431946] ; [10.86429024,106.72457123]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"350"
    ,"Station_Code":"QTD 215"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Hồ bơi Mèo Mun"
    ,"Station_Address":"Đối diện 782, đư ờng Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.861345
    ,"Long":106.724396
    ,"Polyline":"[106.72457123,10.86384010.06.72473907] ; [10.86353016,106.72483826] ; [10.86318016,106.72486877] ; [10.86281967,106.72486877] ; [10.86262989,106.72482300] ; [10.86233997,106.72450256] ; [10.86145020,106.72444916]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"353"
    ,"Station_Code":"QTD 216"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"UBND P.Hiệp Bình Phước"
    ,"Station_Address":"715, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.859791
    ,"Long":106.723782
    ,"Polyline":"[106.72444916,10.86131954] ; [106.72419739,10.86071014] ; [106.72392273,10.85991001] ; [106.72386932,10.85978031]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"351"
    ,"Station_Code":"QTD 217"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trạm y t ế P. Hiệp Bình Phước"
    ,"Station_Address":"645, đường Quốc lộ 13, Quận Th ủ Đức"
    ,"Lat":10.856024
    ,"Long":106.722343
    ,"Polyline":"[106.72386932,10.85978031] ; [106.72328186,10.85824966] ; [106.72283936,10.85709000] ; [106.72255707,10.85641003] ; [106.72241211,10.85599995]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"355"
    ,"Station_Code":"QTD 218"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã 3 Đường Hiệp Bình"
    ,"Station_Address":"607, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852579
    ,"Long":106.720719
    ,"Polyline":"[106.72241211,10.85599995] ; [106.72168732,10.85418034] ; [106.72133636,10.85344028] ; [106.72078705,10.85254002]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"352"
    ,"Station_Code":"QTD 219"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã 3 Hi ệp Bình"
    ,"Station_Address":"557A, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.848727
    ,"Long":106.718346
    ,"Polyline":"[106.72078705,10.85254002] ; [106.71970367,10.85097980] ; [106.71938324,10.85054016] ; [106.71903229,10.84994030] ; [106.71888733,10.84965992] ; [106.71858978,10.84904957] ; [106.71842194,10.84869957]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"358"
    ,"Station_Code":"QTD 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cân Nhơn  Hòa"
    ,"Station_Address":"447-449 , đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.844473
    ,"Long":106.718086
    ,"Polyline":"[106.71842194,10.84869957] ; [106.71826172,10.84827995] ; [106.71816254,10.84772968] ; [106.71811676,10.84702969] ; [106.71813965,10.84626007] ; [106.71816254,10.84447956] ; [106.71816254,10.84447002]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"354"
    ,"Station_Code":"QTD 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"385, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.84109
    ,"Long":106.716858
    ,"Polyline":"[106.71816254,10.84447002] ; [106.71817780,10.84362030] ; [106.71814728,10.84313011] ; [106.71807098,10.84270000] ; [106.71791077,10.84232998] ; [106.71782684,10.84216976] ; [106.71765137,10.84193993] ; [106.71736145,10.84158993] ; [106.71691895,10.84103966]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"359"
    ,"Station_Code":"QTD 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"327-329, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.83877
    ,"Long":106.714915
    ,"Polyline":"[106.71691895,10.84103966] ; [106.71498871,10.83872032]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"356"
    ,"Station_Code":"QTD 223"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"261, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.835822
    ,"Long":106.713745
    ,"Polyline":"[106.71498871,10.83872032] ; [106.71470642,10.83839035] ; [106.71434784,10.83794022] ; [106.71421814,10.83777046] ; [106.71411133,10.83755970] ; [106.71394348,10.83718967] ; [106.71386719,10.83691978] ; [106.71382904,10.83662033] ; [106.71382904,10.83598995] ; [106.71383667,10.83582973]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"357"
    ,"Station_Code":"QTD 224"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"173, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.83294
    ,"Long":106.71389
    ,"Polyline":"[106.71383667,10.83582973] ; [106.71389008,10.83508968] ; [106.71392822,10.83368015] ; [106.71396637,10.83294010]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"360"
    ,"Station_Code":"QTD 225"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"UBND P .Hiệp Bình Chánh"
    ,"Station_Address":"328/5 (Đại học Luật), đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.830039
    ,"Long":106.714027
    ,"Polyline":"[106.71396637,10.83294010.06.71407318] ; [10.83065033,106.71411133]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường  Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71411133,10.83003998] ; [106.71411896,10.82958984] ; [106.71415710,10.82874012] ; [106.71423340,10.82748985] ; [106.71427155,10.82697964] ; [106.71427917,10.82686043] ; [106.71420288,10.82660961] ; [106.71407318,10.82623005] ; [106.71395111,10.82618046] ; [106.71385956,10.82606983] ; [106.71382141,10.82596016] ; [106.71382141,10.82581043] ; [106.71388245,10.82565975] ; [106.71394348,10.82559013] ; [106.71389771,10.82511997] ; [106.71379089,10.82446957] ; [106.71375275,10.82433033] ; [106.71369171,10.82413006] ; [106.71338654,10.82229996] ; [106.71288300,10.81877995] ; [106.71279907,10.81809044] ; [106.71273804,10.81783962] ; [106.71263885,10.81770992] ; [106.71254730,10.81760979] ; [106.71222687,10.81737995] ; [106.71204376,10.81717968] ; [106.71183777,10.81707954] ; [106.71160889,10.81692028] ; [106.71128845,10.81663990]"
    ,"Distance":"1598"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường Đinh Bộ Lĩnh, Quận Bình  Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71128845,10.81663990] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71038818,10.81499958] ; [106.70954132,10.81330013] ; [106.70925140,10.81260014]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70925140,10.81260014] ; [106.70919037,10.81247044] ; [106.70913696,10.81227016] ; [106.70912933,10.81159019] ; [106.70913696,10.81058025] ; [106.70919037,10.80980968]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70919037,10.80980968] ; [106.70923615,10.80919456] ; [106.70927429,10.80800438] ; [106.70932770,10.80737400] ; [106.70940399,10.80680084]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70940399,10.80679798] ; [106.70944977,10.80626488] ; [106.70951080,10.80550861] ; [106.70942688,10.80436993]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70942688,10.80436993] ; [106.70935059,10.80296993] ; [106.71053314,10.80290031]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"221, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71053314,10.80290031] ; [106.71138000,10.80282974] ; [106.71137238,10.80218697] ; [106.71133423,10.80160999] ; [106.71123505,10.80158615] ; [106.71117401,10.80152321] ; [106.71114349,10.80145454] ; [106.71116638,10.80134106.06.71122742] ; [10.80127811,106.71129608] ; [10.80123806,106.71121216] ; [10.80054283,106.71114349]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường  TH Hồng Hà"
    ,"Station_Address":"153, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71114349,10.79971981] ; [106.71102905,10.79864025] ; [106.71092987,10.79813004] ; [106.71070862,10.79736042] ; [106.71057892,10.79699993] ; [106.71044922,10.79668045]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"369"
    ,"Station_Code":"QBTH 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu Th ị Điện máy tự do"
    ,"Station_Address":"151, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.794978
    ,"Long":106.709368
    ,"Polyline":"[106.71044922,10.79668045] ; [106.70999146,10.79553986] ; [106.70974731,10.79522038] ; [106.70935822,10.79479980]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"373"
    ,"Station_Code":"QBTH 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"79, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793534
    ,"Long":106.707979
    ,"Polyline":"[106.70935822,10.79479980] ; [106.70805359,10.79343033]"
    ,"Distance":"209"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"370"
    ,"Station_Code":"Q1 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Thảo Cầm Viên"
    ,"Station_Address":"2A, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.790694
    ,"Long":106.705259
    ,"Polyline":"[106.70805359,10.79343033] ; [106.70539093,10.79061031]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"374"
    ,"Station_Code":"Q1 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đài truyền hình"
    ,"Station_Address":"Đối diện 9, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.787157
    ,"Long":106.702011
    ,"Polyline":"[106.70539093,10.79061031] ; [106.70334625,10.78841972] ; [106.70207977,10.78709984]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1190"
    ,"Station_Code":"Q1 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Đại học Y Dược"
    ,"Station_Address":"43, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785716
    ,"Long":106.702385
    ,"Polyline":"[106.70207977,10.78709984] ; [106.70159149,10.78658009] ; [106.70243835,10.78577995]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1189"
    ,"Station_Code":"Q1 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"TTTM Sài  Gòn"
    ,"Station_Address":"35, đường Tôn Đức Th ắng, Quận 1"
    ,"Lat":10.783902
    ,"Long":106.704417
    ,"Polyline":"[106.70243835,10.78577995] ; [106.70446777,10.78390980]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1192"
    ,"Station_Code":"Q1 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngô Văn Năm"
    ,"Station_Address":"3C, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.779807
    ,"Long":106.707609
    ,"Polyline":"[106.70446777,10.78390980] ; [106.70507813,10.78335953] ; [106.70616913,10.78238964] ; [106.70635223,10.78205967] ; [106.70781708,10.78071022] ; [106.70790863,10.78063011] ; [106.70790863,10.78057003] ; [106.70787811,10.78044987] ; [106.70781708,10.78024960] ; [106.70762634,10.77964020]"
    ,"Distance":"641"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70762634,10.77964020] ; [106.70726013,10.77820969] ; [106.70687866,10.77655983] ; [106.70671844,10.77598000] ; [106.70674896,10.77591038] ; [106.70671844,10.77563953] ; [106.70671082,10.77530003] ; [106.70667267,10.77488041] ; [106.70658112,10.77460003] ; [106.70646667,10.77322006]"
    ,"Distance":"729"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Cục Hải Quan Thành Phố"
    ,"Station_Address":"2-4, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70646667,10.77322006] ; [106.70635223,10.77178955] ; [106.70632935,10.77157021] ; [106.70632172,10.77140045] ; [106.70620728,10.77097988] ; [106.70613861,10.77089977] ; [106.70597839,10.77083969] ; [106.70564270,10.77085972]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84, đường Hàm Nghi, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70564270,10.77085972] ; [106.70468140,10.77091026] ; [106.70339203,10.77093983] ; [106.70317078,10.77095032]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70317078,10.77095032] ; [106.70172119,10.77103043]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70172119,10.77103043] ; [106.69934845,10.77112007]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"118"
    ,"Station_Code":"Q1TC1B"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bến Tha ̀nh B"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77084
    ,"Long":106.698532
    ,"Polyline":"[106.69934845,10.77112007] ; [106.69915009,10.77112484] ; [106.69898987,10.77094555] ; [106.69856262,10.77077961]"
    ,"Distance":"98"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69856262,10.77077961] ; [106.69744873,10.77035046] ; [106.69615173,10.76978970] ; [106.69580841,10.76966000]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69580841,10.76966000] ; [106.69412994,10.76898003]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt S ài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69412994,10.76898003] ; [106.69052124,10.76754379] ; [106.68997192,10.76731777] ; [106.68962097,10.76746464] ; [106.68947601,10.76757431]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe bu ýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai , Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68904877,10.76807022] ; [106.68920898,10.76819992] ; [106.68988800,10.76844978] ; [106.69026184,10.76860046]"
    ,"Distance":"145"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76860046] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai,  Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69329834,10.76982975] ; [106.69458008,10.77031040] ; [106.69673157,10.77118969]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ  Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69673157,10.77118969] ; [106.69794464,10.77165222] ; [106.69805145,10.77159405] ; [106.69803619,10.77150154] ; [106.69803619,10.77146721] ; [106.69804382,10.77138710.06.69805908] ; [10.77132130,106.69810486] ; [10.77126598,106.69815063] ; [10.77122116,106.69819641] ; [10.77119637,106.69807434] ; [10.77098560,106.69744110] ; [10.77034664,106.69614410] ; [10.76978588,106.69642639] ; [10.76923943,106.69712830] ; [10.76997471,106.69744873] ; [10.77034569,106.69746399] ; [10.77035236,106.69775391] ; [10.77034473,106.69840240]"
    ,"Distance":"833"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163 , đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69840240,10.77060032] ; [106.69895935,10.77081966] ; [106.69899750,10.77095032] ; [106.69956970,10.77091980]"
    ,"Distance":"143"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956970,10.77091980] ; [106.70192719,10.77081966]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70192719,10.77081966] ; [106.70416260,10.77068996]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến Bạch  Đằng"
    ,"Station_Address":"Bến thủy nội địa Thủ Thiêm, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70416260,10.77068996] ; [106.70452118,10.77066994] ; [106.70495605,10.76980782] ; [106.70512390,10.76946449] ; [106.70520020,10.76938629] ; [106.70529175,10.76942253] ; [106.70547485,10.76946449] ; [106.70587158,10.76952839] ; [106.70601654,10.76955700] ; [106.70610046,10.76961803] ; [106.70620728,10.76979160] ; [106.70633698,10.77021313] ; [106.70642090,10.77051353] ; [106.70635986,10.77073002] ; [106.70632172,10.77134895] ; [106.70652008,10.77388954]"
    ,"Distance":"787"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1092"
    ,"Station_Code":"Q1 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bảo tàng Tôn Đức Thắng"
    ,"Station_Address":"Đối diện số 5, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.777367
    ,"Long":106.707115
    ,"Polyline":"[106.70652008,10.77388954] ; [106.70658112,10.77460003] ; [106.70667267,10.77488041] ; [106.70671082,10.77530003] ; [106.70671844,10.77563953] ; [106.70674896,10.77591038] ; [106.70671844,10.77598000] ; [106.70687866,10.77655983] ; [106.70702362,10.77717018]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1093"
    ,"Station_Code":"Q1 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngô Văn  Năm"
    ,"Station_Address":"Đối diện số 3C, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.779949
    ,"Long":106.707818
    ,"Polyline":"[106.70702362,10.77717018] ; [106.70726013,10.77820969] ; [106.70755005,10.77939034] ; [106.70771790,10.77991962]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1094"
    ,"Station_Code":"Q1 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ba Son"
    ,"Station_Address":"2, đường Tôn Đức  Thắng, Quận 1"
    ,"Lat":10.781804
    ,"Long":106.706922
    ,"Polyline":"[106.70771790,10.77991962] ; [106.70787811,10.78044987] ; [106.70790863,10.78067017] ; [106.70783997,10.78085995] ; [106.70681000,10.78180981]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1095"
    ,"Station_Code":"Q1 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"TTTM Sài Gòn"
    ,"Station_Address":"6, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.784184
    ,"Long":106.7043
    ,"Polyline":"[106.70681000,10.78180981] ; [106.70555878,10.78291035] ; [106.70504761,10.78337955] ; [106.70423889,10.78411961]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"1096"
    ,"Station_Code":"Q1 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại học Khoa  học xã hội nhân văn"
    ,"Station_Address":"10 , đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.785778
    ,"Long":106.702663
    ,"Polyline":"[106.70423889,10.78411961] ; [106.70259857,10.78563023]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"293"
    ,"Station_Code":"Q1 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Thảo Cầm Vi ên"
    ,"Station_Address":"3, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.789598
    ,"Long":106.70459
    ,"Polyline":"[106.70259857,10.78563023] ; [106.70159149,10.78658009] ; [106.70285034,10.78791046] ; [106.70352936,10.78861046] ; [106.70446777,10.78962994]"
    ,"Distance":"616"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"295"
    ,"Station_Code":"Q1 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Cầu Thị Nghè"
    ,"Station_Address":"1A, đường Nguyễn Thị Minh  Khai, Quận 1"
    ,"Lat":10.790669
    ,"Long":106.705597
    ,"Polyline":"[106.70451355,10.78966999] ; [106.70525360,10.79045963] ; [106.70556641,10.79080009] ; [106.70564270,10.79069042]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"298"
    ,"Station_Code":"QBTH 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà Thờ Thị Nghè"
    ,"Station_Address":"22 B, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.793445
    ,"Long":106.70814
    ,"Polyline":"[106.70564270,10.79069042] ; [106.70556641,10.79080009] ; [106.70565033,10.79088020] ; [106.70761871,10.79298019] ; [106.70806122,10.79343987]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trung tâm Dưỡng Lão"
    ,"Station_Address":"138, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70806122,10.79343987] ; [106.70974731,10.79522038] ; [106.70999146,10.79553986] ; [106.71012878,10.79586029] ; [106.71057892,10.79699993] ; [106.71074677,10.79747963]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"246, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71074677,10.79747963] ; [106.71092987,10.79813004] ; [106.71101379,10.79852962] ; [106.71112061,10.79951000] ; [106.71114349,10.79971027]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71114349,10.79971027] ; [106.71131134,10.80123806] ; [106.71146393,10.80128002] ; [106.71153259,10.80138874] ; [106.71151733,10.80150700] ; [106.71143341,10.80159378] ; [106.71132660,10.80161762] ; [106.71138763,10.80284977] ; [106.71141815,10.80299473] ; [106.71142578,10.80356503] ; [106.71144867,10.80414677] ; [106.71147919,10.80471039]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71147919,10.80471039] ; [106.71151733,10.80535984] ; [106.71154022,10.80655003] ; [106.71154022,10.80681992] ; [106.71156311,10.80747032] ; [106.71161652,10.80797005] ; [106.71167755,10.80821037] ; [106.71177673,10.80848980] ; [106.71190643,10.80883980] ; [106.71198273,10.80906963]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Qu ận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71215820,10.80955029] ; [106.71228790,10.81021976] ; [106.71235657,10.81079960]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71235657,10.81079960] ; [106.71272278,10.81385994]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"304"
    ,"Station_Code":"QTD 198"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường TH Bình Triệu"
    ,"Station_Address":"136 , đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.829247
    ,"Long":106.71434
    ,"Polyline":"[106.71272278,10.81385994] ; [106.71293640,10.81564045] ; [106.71305084,10.81651974] ; [106.71320343,10.81752968] ; [106.71324158,10.81793976] ; [106.71360016,10.82091999] ; [106.71389771,10.82341957] ; [106.71399689,10.82431984] ; [106.71410370,10.82481956] ; [106.71417236,10.82497978] ; [106.71441650,10.82561016] ; [106.71452332,10.82575035] ; [106.71454620,10.82586002] ; [106.71454620,10.82596016] ; [106.71446991,10.82612991] ; [106.71440887,10.82618046] ; [106.71440125,10.82682037] ; [106.71437836,10.82715034] ; [106.71437836,10.82752991] ; [106.71427155,10.82923985]"
    ,"Distance":"1737"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"309"
    ,"Station_Code":"QTD 199"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm xăng  dầu"
    ,"Station_Address":"64/1, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.832655
    ,"Long":106.714149
    ,"Polyline":"[106.71427155,10.82923985] ; [106.71415710,10.83108997] ; [106.71408844,10.83248043] ; [106.71408081,10.83265018]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"306"
    ,"Station_Code":"QTD 200"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Ông Dầu"
    ,"Station_Address":"416, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.836135
    ,"Long":106.714012
    ,"Polyline":"[106.71408081,10.83265018] ; [106.71398926,10.83428955] ; [106.71394348,10.83520031] ; [106.71394348,10.83563042] ; [106.71392059,10.83613014]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"310"
    ,"Station_Code":"QTD 201"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Đường số 3"
    ,"Station_Address":"486 , đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.838815
    ,"Long":106.715317
    ,"Polyline":"[106.71391296,10.83619022] ; [106.71391296,10.83650970] ; [106.71394348,10.83681011] ; [106.71401215,10.83708000] ; [106.71412659,10.83742046] ; [106.71427917,10.83771038] ; [106.71449280,10.83800030] ; [106.71515656,10.83878040] ; [106.71524048,10.83887959]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"312"
    ,"Station_Code":"QTD 202"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường số 4"
    ,"Station_Address":"510, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.841072
    ,"Long":106.71714
    ,"Polyline":"[106.71524048,10.83887959] ; [106.71601105,10.83979988] ; [106.71708679,10.84111023]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"307"
    ,"Station_Code":"QTD 203"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Cân Nh ơn Hòa"
    ,"Station_Address":"Cân Nhơn Hòa, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.844687
    ,"Long":106.718307
    ,"Polyline":"[106.71708679,10.84111023] ; [106.71772003,10.84187984] ; [106.71788025,10.84210014] ; [106.71803284,10.84237957] ; [106.71814728,10.84270954] ; [106.71823120,10.84305954] ; [106.71826172,10.84362984] ; [106.71824646,10.84469032]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"308"
    ,"Station_Code":"QTD 204"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã 3 Hiệp Bình"
    ,"Station_Address":"1/42A, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.848944
    ,"Long":106.718704
    ,"Polyline":"[106.71824646,10.84469032] ; [106.71823120,10.84589958] ; [106.71822357,10.84700966] ; [106.71823120,10.84759998] ; [106.71832275,10.84811974] ; [106.71843719,10.84848976] ; [106.71864319,10.84897995]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"314"
    ,"Station_Code":"QTD 205"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã 3 Đường Hiệp Bình"
    ,"Station_Address":"620, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.852921
    ,"Long":106.721222
    ,"Polyline":"[106.71864319,10.84897995] ; [106.71903992,10.84974957] ; [106.71926880,10.85019016] ; [106.71974945,10.85093975] ; [106.72103119,10.85272980] ; [106.72116089,10.85295010]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"316"
    ,"Station_Code":"QTD 206"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm y tế Hiệp Bình Phước"
    ,"Station_Address":"702, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.855787
    ,"Long":106.722504
    ,"Polyline":"[106.72116089,10.85295010.06.72158813] ; [10.85377026,106.72202301] ; [10.85478020,106.72242737]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"311"
    ,"Station_Code":"QTD 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"UBND P.Hiệp Bình Phước"
    ,"Station_Address":"750, đường Qu ốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.858809
    ,"Long":106.723663
    ,"Polyline":"[106.72242737,10.85581017] ; [106.72274017,10.85661030] ; [106.72328949,10.85807037] ; [106.72358704,10.85883045]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"313"
    ,"Station_Code":"QTD 208"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Hồ Bơi"
    ,"Station_Address":"784, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.861172
    ,"Long":106.724564
    ,"Polyline":"[106.72358704,10.85883045] ; [106.72450256,10.86120033]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"318"
    ,"Station_Code":"QTD 209"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã 4 Bình Phước"
    ,"Station_Address":"828, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.863845
    ,"Long":106.724792
    ,"Polyline":"[106.72450256,10.86120033] ; [106.72486115,10.86213017] ; [106.72496033,10.86248016] ; [106.72498322,10.86283016] ; [106.72495270,10.86308956] ; [106.72486877,10.86340046] ; [106.72470093,10.86380005]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"3403"
    ,"Station_Code":"QTD 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Xây dựng Ngọc Đào"
    ,"Station_Address":"858, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.866679
    ,"Long":106.723175
    ,"Polyline":"[106.72470093,10.86380005] ; [106.72431946,10.86454964] ; [106.72418213,10.86485004] ; [106.72416687,10.86505985] ; [106.72418976,10.86513042] ; [106.72419739,10.86520958] ; [106.72418213,10.86532021] ; [106.72409821,10.86548042] ; [106.72399139,10.86559963] ; [106.72386932,10.86563969] ; [106.72371674,10.86573029] ; [106.72363281,10.86583996] ; [106.72332001,10.86635971] ; [106.72312164,10.86664009]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"88"
    ,"Station_Id":"3405"
    ,"Station_Code":"QTD 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Vĩnh Bình"
    ,"Station_Address":"922, đường Quốc lộ 13, Quận Thủ Đức"
    ,"Lat":10.868033
    ,"Long":106.717964
    ,"Polyline":"[106.72312164,10.86664009] ; [106.72286224,10.86697960] ; [106.72264099,10.86719990] ; [106.72225189,10.86750031] ; [106.72155762,10.86781979] ; [106.72135925,10.86789036] ; [106.72109222,10.86795044] ; [106.72090149,10.86798954] ; [106.72036743,10.86800957] ; [106.71900940,10.86800003] ; [106.71843719,10.86798000] ; [106.71795654,10.86800957]"
    ,"Distance":"615"
  }]