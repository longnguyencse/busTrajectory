export const Route135 =[

  {
     "Route_Id":"135"
    ,"Station_Id":"3486"
    ,"Station_Code":"BX52"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu công nghiệp Tân Bình"
    ,"Station_Address":"ĐẦU BẾN KCN TÂN BÌNH, đư ờng Đường CN1, Quận Tân Phú"
    ,"Lat":10.806971549987793
    ,"Long":106.6078872680664
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"3156"
    ,"Station_Code":"QTP 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trạm Đ ường CN 13"
    ,"Station_Address":"473, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.809837
    ,"Long":106.613106
    ,"Polyline":"[106.60788727,10.80696964] ; [106.60801697,10.80671978] ; [106.60838318,10.80714035] ; [106.60901642,10.80786991] ; [106.60936737,10.80830956] ; [106.61003876,10.80908012] ; [106.61134338,10.81064034] ; [106.61148071,10.81085968] ; [106.61213684,10.81054974] ; [106.61260223,10.81031990] ; [106.61319733,10.81005001]"
    ,"Distance":"836"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"3155"
    ,"Station_Code":"QTP 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm Kênh 19/5"
    ,"Station_Address":"443, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.808721
    ,"Long":106.615913
    ,"Polyline":"[106.61319733,10.81005001] ; [106.61486816,10.80928040] ; [106.61598206,10.80895996]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2915"
    ,"Station_Code":"QTP 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm Đầu Tây Thạnh"
    ,"Station_Address":"389, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.809416
    ,"Long":106.619644
    ,"Polyline":"[106.61598206,10.80895996] ; [106.61824036,10.80832005] ; [106.61826324,10.80842018] ; [106.61940765,10.80963039]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2919"
    ,"Station_Code":"QTP 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm Trường Tiểu Học Lê Lai"
    ,"Station_Address":"237, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.812798
    ,"Long":106.622345
    ,"Polyline":"[106.61940765,10.80963039] ; [106.62238312,10.81285000]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2457"
    ,"Station_Code":"QTP 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trạm Công Ty Ngọc Nghĩa"
    ,"Station_Address":"Đối diện công ty Ngọc Ngh ĩa, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.815767
    ,"Long":106.625061
    ,"Polyline":"[106.62238312,10.81285000] ; [106.62312317,10.81369972] ; [106.62432861,10.81511021] ; [106.62474823,10.81554985] ; [106.62502289,10.81581020]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2916"
    ,"Station_Code":"QTP 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trạm C ổng KCN Tân Bình"
    ,"Station_Address":"29/26 (Công ty Thành Công), đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.818994
    ,"Long":106.628616
    ,"Polyline":"[106.62502289,10.81581020] ; [106.62677765,10.81744957] ; [106.62828827,10.81877995] ; [106.62859344,10.81902981]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.62859344,10.81902981] ; [106.62944031,10.81964970] ; [106.63059998,10.82044029] ; [106.63073730,10.82050037] ; [106.63041687,10.82151985] ; [106.63038635,10.82162952]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2607"
    ,"Station_Code":"QTB 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chung cư Phúc Yên"
    ,"Station_Address":"8 (14/32), đ ường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.824498
    ,"Long":106.630356
    ,"Polyline":"[106.63038635,10.82162952] ; [106.63025665,10.82201958] ; [106.63004303,10.82254028] ; [106.62976837,10.82297993] ; [106.62978363,10.82320976] ; [106.62982178,10.82341957] ; [106.62988281,10.82361984] ; [106.63021088,10.82433033] ; [106.63030243,10.82452011]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2605"
    ,"Station_Code":"QTB 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà máy  hóa chất Tân Bình"
    ,"Station_Address":"Đối diện nhà máy hóa chất, đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.828074
    ,"Long":106.632019
    ,"Polyline":"[106.63030243,10.82452011] ; [106.63095093,10.82586956] ; [106.63197327,10.82810020]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2609"
    ,"Station_Code":"QTB 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thờ Hy Vọng"
    ,"Station_Address":"72, đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.830503
    ,"Long":106.633183
    ,"Polyline":"[106.63197327,10.82810020] ; [106.63263702,10.82956028] ; [106.63311005,10.83055019]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2606"
    ,"Station_Code":"QGV 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường Cao đẳng Du Lịch"
    ,"Station_Address":"162, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.832665
    ,"Long":106.634178
    ,"Polyline":"[106.63311005,10.83055019] ; [106.63410950,10.83269024]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2608"
    ,"Station_Code":"QGVT102"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cây Xăng dầu Anh Thư"
    ,"Station_Address":"80 /10B, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.835247993469238
    ,"Long":106.63538360595703
    ,"Polyline":"[106.63417816,10.83266544] ; [106.63538361,10.83524799]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2611"
    ,"Station_Code":"QGV 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà sách Phan Huy Ích"
    ,"Station_Address":"332 , đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.837891
    ,"Long":106.636604
    ,"Polyline":"[106.63532257,10.83528042] ; [106.63655090,10.83790970]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2612"
    ,"Station_Code":"QGV 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chùa Linh  Sơn Hải Tự"
    ,"Station_Address":"386, đường Phan  Huy Ích, Quận Gò Vấp"
    ,"Lat":10.841504
    ,"Long":106.638451
    ,"Polyline":"[106.63655090,10.83790970] ; [106.63681030,10.83848000] ; [106.63715363,10.83917999] ; [106.63751221,10.83994961] ; [106.63793945,10.84080029] ; [106.63839722,10.84154034]"
    ,"Distance":"466"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2613"
    ,"Station_Code":"QGV 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Đường Nguyễn Duy Cung"
    ,"Station_Address":"460, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.843685
    ,"Long":106.639851
    ,"Polyline":"[106.63839722,10.84154034] ; [106.63951874,10.84331036]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2094"
    ,"Station_Code":"QGV 170"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"869-871 (Kế A4-A5), đường  Quang Trung, Quận Gò Vấp"
    ,"Lat":10.843801
    ,"Long":106.640671
    ,"Polyline":"[106.63985443,10.84368515] ; [106.63990021,10.84397984] ; [106.64009094,10.84424973] ; [106.64010620,10.84428024] ; [106.64016724,10.84424019] ; [106.64070892,10.84385967] ; [106.64067078,10.84380054]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2095"
    ,"Station_Code":"QGV 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"819, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.842036
    ,"Long":106.643311
    ,"Polyline":"[106.64067078,10.84380054] ; [106.64070892,10.84385967] ; [106.64157867,10.84325314] ; [106.64239502,10.84269524] ; [106.64325714,10.84214973] ; [106.64334869,10.84208965] ; [106.64331055,10.84203625]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2098"
    ,"Station_Code":"QGV 172"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"751 (364), đường  Quang Trung, Quận Gò Vấp"
    ,"Lat":10.839758
    ,"Long":106.646347
    ,"Polyline":"[106.64334869,10.84208965] ; [106.64398956,10.84165955] ; [106.64470673,10.84117985] ; [106.64505768,10.84092045] ; [106.64555359,10.84053040] ; [106.64636230,10.83985996] ; [106.64640045,10.83983040]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2096"
    ,"Station_Code":"QGV 173"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã ba Tân Sơn"
    ,"Station_Address":"Đối diện 972  (Công ty ISUZU), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83902
    ,"Long":106.647728
    ,"Polyline":"[106.64634705,10.83975792] ; [106.64640045,10.83983040] ; [106.64674377,10.83953857] ; [106.64710999,10.83928013] ; [106.64730835,10.83918953] ; [106.64774323,10.83907986] ; [106.64772797,10.83901978]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2099"
    ,"Station_Code":"QGV 174"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Dệt may Phương Đông"
    ,"Station_Address":"695  (đối diện 97), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83839
    ,"Long":106.650246
    ,"Polyline":"[106.64774323,10.83907986] ; [106.65026093,10.83845043]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2097"
    ,"Station_Code":"QGV 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường THPT Nguyễn Công Trứ"
    ,"Station_Address":"Đối diện 842, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.837576
    ,"Long":106.653412
    ,"Polyline":"[106.65026093,10.83845043] ; [106.65342712,10.83763981]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"4627"
    ,"Station_Code":"QGV 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"12B, Quang Trung"
    ,"Station_Address":"Đối di ện 746 (12B), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836552
    ,"Long":106.657376
    ,"Polyline":"[106.65341187,10.83757591] ; [106.65737915,10.83655167]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"4628"
    ,"Station_Code":"QGV 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Công an  Quận Gò Vấp"
    ,"Station_Address":"Đối diện 628A  (9), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835561
    ,"Long":106.661367
    ,"Polyline":"[106.65737915,10.83655167] ; [106.66136932,10.83556080]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"926"
    ,"Station_Code":"QGV 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chùa Hu ỳnh Kim"
    ,"Station_Address":"621, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.834918
    ,"Long":106.663395
    ,"Polyline":"[106.66136932,10.83556080] ; [106.66232300,10.83536053] ; [106.66296387,10.83513927] ; [106.66339874,10.83491802]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2762"
    ,"Station_Code":"QGV 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Thông Tây"
    ,"Station_Address":"1417, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.834634
    ,"Long":106.666882
    ,"Polyline":"[106.66339874,10.83491802] ; [106.66342926,10.83496571] ; [106.66435242,10.83453369] ; [106.66464233,10.83516026] ; [106.66473389,10.83543968] ; [106.66684723,10.83471298] ; [106.66688538,10.83463383]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2763"
    ,"Station_Code":"QGV 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã Ba Tân Thông Hội"
    ,"Station_Address":"1319, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.833638
    ,"Long":106.669602
    ,"Polyline":"[106.66688538,10.83463383] ; [106.66834259,10.83417034] ; [106.66960144,10.83363819]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2764"
    ,"Station_Code":"QGV 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Xí nghiệp Z751"
    ,"Station_Address":"1195-1197, đường  Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.832837
    ,"Long":106.671823
    ,"Polyline":"[106.66960144,10.83363819] ; [106.66963959,10.83368015] ; [106.67144775,10.83304977] ; [106.67141724,10.83297920]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2766"
    ,"Station_Code":"QGV 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Xí nghiệp dệt Quân Đội"
    ,"Station_Address":"7, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.831942
    ,"Long":106.674324
    ,"Polyline":"[106.67144775,10.83304977] ; [106.67434692,10.83201027]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2765"
    ,"Station_Code":"QGV 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã Tư Nguyễn Oanh"
    ,"Station_Address":"1071, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.831051
    ,"Long":106.67672
    ,"Polyline":"[106.67434692,10.83201027] ; [106.67642212,10.83127022]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2768"
    ,"Station_Code":"QGV 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Patin Z751"
    ,"Station_Address":"1013, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.830319
    ,"Long":106.679049
    ,"Polyline":"[106.67671967,10.83105087] ; [106.67680359,10.83114529] ; [106.67771149,10.83080959] ; [106.67816162,10.83065033] ; [106.67833710,10.83061028] ; [106.67839050,10.83049774]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2772"
    ,"Station_Code":"QGV 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã Ba Nguyễn Huy Điển"
    ,"Station_Address":"893, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.829513
    ,"Long":106.681335
    ,"Polyline":"[106.67861938,10.83051968] ; [106.68135834,10.82958031]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2770"
    ,"Station_Code":"QGV 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"PCCC Qu ận Gò Vấp"
    ,"Station_Address":"771, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.828364
    ,"Long":106.684939
    ,"Polyline":"[106.68133545,10.82951260] ; [106.68135834,10.82958031] ; [106.68286133,10.82909966] ; [106.68467712,10.82849979] ; [106.68493652,10.82836437]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2767"
    ,"Station_Code":"QGV 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Caphê Cát Đằng"
    ,"Station_Address":"689, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.827421
    ,"Long":106.687996
    ,"Polyline":"[106.68493652,10.82836437] ; [106.68503571,10.82846928] ; [106.68572998,10.82822704] ; [106.68722534,10.82775307] ; [106.68771362,10.82750034] ; [106.68769073,10.82750988]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1766"
    ,"Station_Code":"QGV 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bãi hậu cần số 1"
    ,"Station_Address":"439, đường Phan  Văn Trị, Quận Gò Vấp"
    ,"Lat":10.823559
    ,"Long":106.692165
    ,"Polyline":"[106.68769073,10.82750988] ; [106.68795013,10.82754230] ; [106.68849182,10.82703972] ; [106.69226074,10.82355022] ; [106.69216156,10.82355881]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1767"
    ,"Station_Code":"QBTH 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chùa Giác Quang"
    ,"Station_Address":"189, đường Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.819749
    ,"Long":106.694375
    ,"Polyline":"[106.69226074,10.82355022] ; [106.69307709,10.82279015] ; [106.69338226,10.82236004] ; [106.69344330,10.82225037] ; [106.69354248,10.82186031] ; [106.69362640,10.82159042] ; [106.69390869,10.82096004] ; [106.69436646,10.81991005] ; [106.69441986,10.81974983]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1769"
    ,"Station_Code":"QBTH 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"235, đường Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.813695
    ,"Long":106.695217
    ,"Polyline":"[106.69441986,10.81974983] ; [106.69467163,10.81892967] ; [106.69480133,10.81857967] ; [106.69509125,10.81801033] ; [106.69523621,10.81762981] ; [106.69529724,10.81739044] ; [106.69529724,10.81711960] ; [106.69528961,10.81688023] ; [106.69519043,10.81626034] ; [106.69519043,10.81604004] ; [106.69522095,10.81577969] ; [106.69523621,10.81509018] ; [106.69525146,10.81369019]"
    ,"Distance":"702"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1768"
    ,"Station_Code":"QBTH 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Nhà th ờ Bình Hòa"
    ,"Station_Address":"89, đường Nơ  Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809833
    ,"Long":106.695061
    ,"Polyline":"[106.69525146,10.81369019] ; [106.69528961,10.81313992] ; [106.69526672,10.81250954] ; [106.69522858,10.81215000] ; [106.69519043,10.81198978] ; [106.69518280,10.81180000] ; [106.69519043,10.81167984] ; [106.69522858,10.81159019] ; [106.69550323,10.81120014] ; [106.69528198,10.81079006] ; [106.69515228,10.81042957] ; [106.69510651,10.81021976] ; [106.69509888,10.80998993] ; [106.69509888,10.80982971]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2107"
    ,"Station_Code":"QBTH 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"27, đường N ơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.805712
    ,"Long":106.694965
    ,"Polyline":"[106.69509888,10.80982971] ; [106.69503784,10.80665970] ; [106.69500732,10.80566978]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2110"
    ,"Station_Code":"QBTH 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bệnh Vi ện Gia Định"
    ,"Station_Address":"1, đường Nơ  Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803583
    ,"Long":106.694906
    ,"Polyline":"[106.69500732,10.80566978] ; [106.69493866,10.80352020]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"517"
    ,"Station_Code":"QBTH 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"1, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802455
    ,"Long":106.696826
    ,"Polyline":"[106.69490814,10.80358315] ; [106.69493866,10.80352020] ; [106.69492340,10.80282021] ; [106.69654846,10.80259991] ; [106.69682312,10.80245495]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"473C, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69682312,10.80245495] ; [106.69731903,10.80251312] ; [106.69795990,10.80245972] ; [106.69858551,10.80256653] ; [106.69895935,10.80278206] ; [106.69924927,10.80286694] ; [106.69955444,10.80296135]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"449, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69955444,10.80296135] ; [106.69955444,10.80296135] ; [106.70026398,10.80331421] ; [106.70071411,10.80349922] ; [106.70117950,10.80362511] ; [106.70117950,10.80362511]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"375, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70117950,10.80362511] ; [106.70153809,10.80381489] ; [106.70172882,10.80383968] ; [106.70278168,10.80356026] ; [106.70324707,10.80346012] ; [106.70365143,10.80342007] ; [106.70372009,10.80341434] ; [106.70398712,10.80329323]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70398712,10.80329323] ; [106.70473480,10.80331421] ; [106.70602417,10.80322456] ; [106.70671082,10.80307674]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Ngã Ba  Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70670319,10.80317020] ; [106.70815277,10.80307007] ; [106.70899200,10.80300045] ; [106.70997620,10.80294991] ; [106.71053314,10.80290031]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ Tĩnh , Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71053314,10.80290031] ; [106.71114349,10.80286026] ; [106.71138763,10.80284023] ; [106.71141815,10.80298042] ; [106.71143341,10.80377960] ; [106.71145630,10.80453014] ; [106.71147919,10.80471039]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71166229,10.80680275] ; [106.71163177,10.80777264] ; [106.71178436,10.80830956] ; [106.71196747,10.80883121]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71215820,10.80955029] ; [106.71228790,10.81021976] ; [106.71240997,10.81079102]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128 , đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71260834,10.81231976]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Bến xe  Miền Đông"
    ,"Station_Address":"78/3, đường  Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71253967,10.81233025] ; [106.71290588,10.81513882] ; [106.71313477,10.81736183] ; [106.71243286,10.81730938] ; [106.71195221,10.81713009] ; [106.71128845,10.81663990]"
    ,"Distance":"800"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bến xe Miền  Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71128845,10.81663990] ; [106.71118927,10.81653786] ; [106.71108246,10.81636906] ; [106.71044159,10.81512260] ; [106.70987701,10.81399250] ; [106.71009064,10.81390858] ; [106.71020508,10.81397915] ; [106.71073914,10.81503010]"
    ,"Distance":"577"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ L ĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường  Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71073914,10.81503010.06.71019745] ; [10.81396961,106.71009827] ; [10.81390953,106.70989227] ; [10.81398964,106.70986176] ; [10.81394005,106.70954132] ; [10.81330013,106.70925140]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70925140,10.81260014] ; [106.70919037,10.81247044] ; [106.70913696,10.81227016] ; [106.70912933,10.81159019] ; [106.70913696,10.81058025] ; [106.70919037,10.80980968]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70919037,10.80980968] ; [106.70926666,10.80805969] ; [106.70937347,10.80710983] ; [106.70941162,10.80679989] ; [106.70925140,10.80677986] ; [106.70924377,10.80677986]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70924377,10.80677986] ; [106.70941162,10.80679989] ; [106.70947266,10.80597973] ; [106.70950317,10.80550957] ; [106.70947266,10.80498028] ; [106.70942688,10.80436993]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường Bạch Đằng, Quận Bình  Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.70942688,10.80436993] ; [106.70935059,10.80296993] ; [106.70806885,10.80307007] ; [106.70793152,10.80307961]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70793152,10.80307961] ; [106.70395660,10.80338955]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"288, đường Bạch Đằng, Quận  Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70395660,10.80338955] ; [106.70346069,10.80342960] ; [106.70278168,10.80356026] ; [106.70172882,10.80383968] ; [106.70157623,10.80385017] ; [106.70136261,10.80381966] ; [106.70104218,10.80368996]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"368, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70104218,10.80368996] ; [106.69924164,10.80296993]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"UBND Quận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69924164,10.80296993] ; [106.69860077,10.80268002] ; [106.69795990,10.80245972] ; [106.69753265,10.80249977] ; [106.69599152,10.80268002] ; [106.69573212,10.80272007]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2039"
    ,"Station_Code":"QBTH 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"2, đường Nơ Trang  Long, Quận Bình Thạnh"
    ,"Lat":10.803488
    ,"Long":106.695013
    ,"Polyline":"[106.69573212,10.80272007] ; [106.69492340,10.80282021] ; [106.69492340,10.80292034] ; [106.69493866,10.80342960]"
    ,"Distance":"157"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2035"
    ,"Station_Code":"QBTH 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"48, đường Nơ Trang Long, Quận Bình Th ạnh"
    ,"Lat":10.806076
    ,"Long":106.695083
    ,"Polyline":"[106.69493866,10.80342960] ; [106.69500732,10.80591011]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1650"
    ,"Station_Code":"QBTH 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"124, đường Nơ Trang Long,  Quận Bình Thạnh"
    ,"Lat":10.809732
    ,"Long":106.695158
    ,"Polyline":"[106.69500732,10.80591011] ; [106.69509125,10.80912971] ; [106.69509888,10.80978012]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1654"
    ,"Station_Code":"QBTH 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"182B/2, đường Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.812722
    ,"Long":106.695343
    ,"Polyline":"[106.69509888,10.80978012] ; [106.69510651,10.81023979] ; [106.69519043,10.81058979] ; [106.69550323,10.81120014] ; [106.69519043,10.81167984] ; [106.69519043,10.81198978] ; [106.69523621,10.81225014] ; [106.69525146,10.81239033] ; [106.69526672,10.81272030]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"1652"
    ,"Station_Code":"QBTH 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chùa Giác Quang"
    ,"Station_Address":"342, đường Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.819601
    ,"Long":106.694536
    ,"Polyline":"[106.69526672,10.81272030] ; [106.69528961,10.81313992] ; [106.69525146,10.81365967] ; [106.69525146,10.81478024] ; [106.69522858,10.81560040] ; [106.69522095,10.81571007] ; [106.69519043,10.81614017] ; [106.69522858,10.81649017] ; [106.69525909,10.81669044] ; [106.69529724,10.81700039] ; [106.69531250,10.81725979] ; [106.69526672,10.81750965] ; [106.69519043,10.81777000] ; [106.69486237,10.81846046] ; [106.69474030,10.81871986] ; [106.69458771,10.81917000] ; [106.69448853,10.81949043]"
    ,"Distance":"771"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2046"
    ,"Station_Code":"QGV 152"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường  Đại học Công nghiệp"
    ,"Station_Address":"28, đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.821646
    ,"Long":106.688759
    ,"Polyline":"[106.69447327,10.81958199] ; [106.69417572,10.82037640] ; [106.69432068,10.82050800] ; [106.69431305,10.82062912] ; [106.69422150,10.82073402] ; [106.69409180,10.82077122] ; [106.69396973,10.82073975] ; [106.69387817,10.82065010.06.68997955] ; [10.81958580,106.69004822] ; [10.81980705,106.68998718] ; [10.81995964,106.68983459] ; [10.82016563,106.68962860] ; [10.82039165,106.68923187] ; [10.82071304,106.68896484] ; [10.82118702,106.68875885]"
    ,"Distance":"916"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"462"
    ,"Station_Code":"QGV 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"UBND Phường 5, Quận Gò Vấp"
    ,"Station_Address":"396, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.82507
    ,"Long":106.687881
    ,"Polyline":"[106.68875885,10.82164574] ; [106.68796539,10.82308388] ; [106.68754578,10.82350540] ; [106.68663025,10.82409573] ; [106.68699646,10.82458115] ; [106.68788147,10.82507038]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2729"
    ,"Station_Code":"QGV 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã Tư Nguyễn Thái Sơn"
    ,"Station_Address":"12, đường Phan  Văn Trị, Quận Gò Vấp"
    ,"Lat":10.827015
    ,"Long":106.68864
    ,"Polyline":"[106.68788147,10.82507038] ; [106.68878174,10.82572937] ; [106.68935394,10.82628822] ; [106.68922424,10.82642460]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2731"
    ,"Station_Code":"QGV 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"PCCC Quận Gò Vấp"
    ,"Station_Address":"16B, đường Phan  Văn Trị, Quận Gò Vấp"
    ,"Lat":10.828654
    ,"Long":106.68474
    ,"Polyline":"[106.68922424,10.82642460] ; [106.68917847,10.82639027] ; [106.68828583,10.82734203] ; [106.68797302,10.82757378] ; [106.68669128,10.82801628] ; [106.68498993,10.82839012] ; [106.68499756,10.82842159]"
    ,"Distance":"589"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2730"
    ,"Station_Code":"QGV 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã Ba Nguyễn Huy Điển"
    ,"Station_Address":"30D, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.829644
    ,"Long":106.681516
    ,"Polyline":"[106.68498993,10.82839012] ; [106.68359375,10.82886982] ; [106.68138123,10.82958031] ; [106.68100739,10.82971001]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2733"
    ,"Station_Code":"QGV 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Patin Z751"
    ,"Station_Address":"596, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.830519
    ,"Long":106.678877
    ,"Polyline":"[106.68151855,10.82964420] ; [106.68103027,10.82976246] ; [106.67903900,10.83047104]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2732"
    ,"Station_Code":"QGV 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà máy Z751"
    ,"Station_Address":"2A, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.831494
    ,"Long":106.67605
    ,"Polyline":"[106.67903900,10.83047104] ; [106.67797089,10.83079529] ; [106.67698669,10.83113480] ; [106.67596436,10.83154106]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2734"
    ,"Station_Code":"QGV 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Xí nghiệp Z751"
    ,"Station_Address":"670, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.832948
    ,"Long":106.67201
    ,"Polyline":"[106.67596436,10.83154106.06.67507172]"
    ,"Distance":"103"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2737"
    ,"Station_Code":"QGV 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã Ba Tân Thông Hội"
    ,"Station_Address":"Đối diện 1287, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.833754
    ,"Long":106.6698
    ,"Polyline":"[106.67507172,10.83184147] ; [106.67210388,10.83287430] ; [106.66979980,10.83375359]"
    ,"Distance":"615"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2735"
    ,"Station_Code":"QGV 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Thông Tây"
    ,"Station_Address":"676, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.834723
    ,"Long":106.66714
    ,"Polyline":"[106.66979980,10.83375359] ; [106.66903687,10.83398056] ; [106.66713715,10.83472347]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"4745"
    ,"Station_Code":"QGV 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chùa Huỳnh Kim"
    ,"Station_Address":"548, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.835234
    ,"Long":106.663315
    ,"Polyline":"[106.66713715,10.83472347] ; [106.66471863,10.83550835] ; [106.66464233,10.83513927] ; [106.66440582,10.83464432] ; [106.66331482,10.83523369]"
    ,"Distance":"518"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"925"
    ,"Station_Code":"QGV 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Siêu thị Bình Dân, Quang Trung"
    ,"Station_Address":"628A, đường Quang Trung , Quận Gò Vấp"
    ,"Lat":10.835988
    ,"Long":106.660675
    ,"Polyline":"[106.66331482,10.83523369] ; [106.66067505,10.83598804]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2049"
    ,"Station_Code":"QGV 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Chợ Thông Tây"
    ,"Station_Address":"734, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836836
    ,"Long":106.657355
    ,"Polyline":"[106.66067505,10.83598804] ; [106.66045380,10.83603477] ; [106.65762329,10.83674622] ; [106.65735626,10.83683586]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2044"
    ,"Station_Code":"QGV 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trường THPT Nguyễn Công Trứ"
    ,"Station_Address":"872 (96H), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.838
    ,"Long":106.652741
    ,"Polyline":"[106.65735626,10.83683586] ; [106.65274048,10.83800030]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2045"
    ,"Station_Code":"QGV 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Dệt may  Phương Đông"
    ,"Station_Address":"930 (Kho 97), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.838654
    ,"Long":106.650091
    ,"Polyline":"[106.65274048,10.83800030] ; [106.65250397,10.83802700] ; [106.65009308,10.83865356]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2051"
    ,"Station_Code":"QGV 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"1010, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.839881
    ,"Long":106.646621
    ,"Polyline":"[106.65009308,10.83865356] ; [106.64952087,10.83875942] ; [106.64781952,10.83923817] ; [106.64730072,10.83935452] ; [106.64698792,10.83952808] ; [106.64672089,10.83975983] ; [106.64662170,10.83988094]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2048"
    ,"Station_Code":"QGV 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"1134, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.842279
    ,"Long":106.643348
    ,"Polyline":"[106.64662170,10.83988094] ; [106.64559174,10.84068775] ; [106.64519501,10.84100914] ; [106.64426422,10.84164143] ; [106.64356232,10.84208393] ; [106.64334869,10.84227943]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2053"
    ,"Station_Code":"QGV 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"1246, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.843743
    ,"Long":106.641186
    ,"Polyline":"[106.64334869,10.84227943] ; [106.64118958,10.84374332]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2641"
    ,"Station_Code":"QGV 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Đường Nguyễn Duy Cung"
    ,"Station_Address":"411, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.843496
    ,"Long":106.639507
    ,"Polyline":"[106.64118958,10.84374332] ; [106.64011383,10.84440708] ; [106.63959503,10.84351158] ; [106.63950348,10.84349632]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2646"
    ,"Station_Code":"QGV 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chùa Linh  Sơn Hải Tự"
    ,"Station_Address":"12/78, đường  Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.841177
    ,"Long":106.638043
    ,"Polyline":"[106.63950348,10.84349632] ; [106.63804626,10.84117699]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2642"
    ,"Station_Code":"QGV 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nhà sách Phan Huy Ích"
    ,"Station_Address":"275, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.837036
    ,"Long":106.636031
    ,"Polyline":"[106.63804626,10.84117699] ; [106.63603210,10.83703613]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2644"
    ,"Station_Code":"QGVT097"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":""
    ,"Station_Address":"20/10A, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.833786964416504
    ,"Long":106.6345443725586
    ,"Polyline":"[106.63613129,10.83699989] ; [106.63461304,10.83376026]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2647"
    ,"Station_Code":"QGV 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường Cao đẳng Du Lịch"
    ,"Station_Address":"175, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.832136
    ,"Long":106.633741
    ,"Polyline":"[106.63454437,10.83378696] ; [106.63421631,10.83294201] ; [106.63374329,10.83213615]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2645"
    ,"Station_Code":"QTB 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà thờ Hy Vọng"
    ,"Station_Address":"69 , đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.83081
    ,"Long":106.633163
    ,"Polyline":"[106.63374329,10.83213615] ; [106.63381195,10.83210468] ; [106.63321686,10.83078003] ; [106.63316345,10.83080959]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2648"
    ,"Station_Code":"QTB 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Nhà m áy hóa chất Tân Bình"
    ,"Station_Address":"Nhà máy hóa chất , đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.82854
    ,"Long":106.632103
    ,"Polyline":"[106.63321686,10.83078003] ; [106.63273621,10.82979012] ; [106.63237762,10.82898998] ; [106.63215637,10.82851028]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2649"
    ,"Station_Code":"QTB 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cao ốc Phúc Yên"
    ,"Station_Address":"31-33, đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.826112
    ,"Long":106.630997
    ,"Polyline":"[106.63215637,10.82851028] ; [106.63105011,10.82608986]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.63105011,10.82608986] ; [106.62988281,10.82361984] ; [106.62967682,10.82332039] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"509"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2454"
    ,"Station_Code":"QTP 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Cty Dầu Thực Vật"
    ,"Station_Address":"Công ty dầu thực vật Tân Bình, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.81896
    ,"Long":106.628532
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63059235,10.82044029] ; [106.62867737,10.81910992] ; [106.62851715,10.81896973]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2651"
    ,"Station_Code":"QTP 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trạm Công Ty Ngọc Nghĩa"
    ,"Station_Address":"Công ty Ngọc Nghĩa, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.816059
    ,"Long":106.625336
    ,"Polyline":"[106.62851715,10.81896973] ; [106.62772369,10.81828022] ; [106.62677765,10.81744957] ; [106.62568665,10.81643009] ; [106.62532806,10.81608963]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2920"
    ,"Station_Code":"QTP 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Trạm Trường Tiểu Học Lê Lai"
    ,"Station_Address":"Tr ường Lê Lai, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.812615
    ,"Long":106.622147
    ,"Polyline":"[106.62533569,10.81605911] ; [106.62531281,10.81608009] ; [106.62452698,10.81532955] ; [106.62371063,10.81441975] ; [106.62265015,10.81315994] ; [106.62214661,10.81261539]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"2921"
    ,"Station_Code":"QTP 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trạm L ê Trọng Tấn"
    ,"Station_Address":"298, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.809585
    ,"Long":106.619133
    ,"Polyline":"[106.62214661,10.81261539] ; [106.62207794,10.81252003] ; [106.62035370,10.81065941] ; [106.61962128,10.80989075] ; [106.61913300,10.80958462]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"3101"
    ,"Station_Code":"QTP 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Trạm Kênh 19/5"
    ,"Station_Address":"456, đường Lê Tr ọng Tấn, Quận Tân Phú"
    ,"Lat":10.809163
    ,"Long":106.616302
    ,"Polyline":"[106.61924744,10.80947018] ; [106.61826324,10.80842018] ; [106.61676788,10.80883980] ; [106.61624908,10.80897999]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"3100"
    ,"Station_Code":"QTP 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Trạm Đường CN 13"
    ,"Station_Address":"510, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.810217
    ,"Long":106.61351
    ,"Polyline":"[106.61624908,10.80897999] ; [106.61493683,10.80935955] ; [106.61396027,10.80982018] ; [106.61344147,10.81007004]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"135"
    ,"Station_Id":"3486"
    ,"Station_Code":"BX52"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Khu công nghiệp Tân Bình"
    ,"Station_Address":"ĐẦU BẾN KCN TÂN BÌNH, đường Đường CN1, Quận Tân Ph ú"
    ,"Lat":10.806971549987793
    ,"Long":106.6078872680664
    ,"Polyline":"[106.61344147,10.81007004] ; [106.61267853,10.81040955] ; [106.61192322,10.81079006] ; [106.61152649,10.81097031] ; [106.61148071,10.81085968] ; [106.61134338,10.81064034] ; [106.61106873,10.81031036] ; [106.61032867,10.80943012] ; [106.60975647,10.80875969] ; [106.60864258,10.80743980] ; [106.60801697,10.80671978] ; [106.60788727,10.80696964]"
    ,"Distance":"892"
  }]