export const Route91 =[
  {
     "Route_Id":"91"
    ,"Station_Id":"2745"
    ,"Station_Code":"BX35"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"BÃI XE THỚI AN, đường Lê Văn Kh ương, Quận 12"
    ,"Lat":10.878466606140137
    ,"Long":106.64797973632812
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1746"
    ,"Station_Code":"Q12 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đài liệt s ỹ"
    ,"Station_Address":"Đài liệt sỹ, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.874953
    ,"Long":106.648972
    ,"Polyline":"[106.64891052,10.87851048] ; [106.64904785,10.87582016] ; [106.64910889,10.87495995]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1745"
    ,"Station_Code":"Q12 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Hiệp Th ành 49"
    ,"Station_Address":"251, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.871424
    ,"Long":106.649185
    ,"Polyline":"[106.64910889,10.87495995] ; [106.64922333,10.87310982] ; [106.64929199,10.87143040]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1748"
    ,"Station_Code":"Q12 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Nhà máy  Bia"
    ,"Station_Address":"119, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.867475
    ,"Long":106.649368
    ,"Polyline":"[106.64929199,10.87143040] ; [106.64936066,10.86970997] ; [106.64949036,10.86748028]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1749"
    ,"Station_Code":"Q12T018"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Hiệp Th ành 37"
    ,"Station_Address":"99, đường Lê Văn  Khương, Quận 12"
    ,"Lat":10.865412712097168
    ,"Long":106.6495132446289
    ,"Polyline":"[106.64949036,10.86748028] ; [106.64959717,10.86542034]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1747"
    ,"Station_Code":"Q12 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Metro Hi ệp Phú"
    ,"Station_Address":"Metro Hiệp Phú , đường Lê Văn Khương, Quận 12"
    ,"Lat":10.862768
    ,"Long":106.649641
    ,"Polyline":"[106.64959717,10.86542034] ; [106.64974213,10.86275005]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2775"
    ,"Station_Code":"Q12 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cao su Vina"
    ,"Station_Address":"67/3A, đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.861767
    ,"Long":106.648536
    ,"Polyline":"[106.64974213,10.86275005] ; [106.64975739,10.86211014] ; [106.64929199,10.86198997] ; [106.64903259,10.86190033] ; [106.64859009,10.86170006] ; [106.64762115,10.86116982] ; [106.64756012,10.86108017] ; [106.64737701,10.86100006] ; [106.64682770,10.86071968] ; [106.64672852,10.86065960]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2776"
    ,"Station_Code":"Q12 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cây xăng Trung Tín"
    ,"Station_Address":"1828, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.860302
    ,"Long":106.645682
    ,"Polyline":"[106.64672852,10.86065960] ; [106.64382935,10.85908031]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2777"
    ,"Station_Code":"Q12 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm điện Hóc Môn"
    ,"Station_Address":"1956, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.857668
    ,"Long":106.640918
    ,"Polyline":"[106.64382935,10.85908031] ; [106.64102173,10.85754013]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2778"
    ,"Station_Code":"Q12 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 4 Đ ình"
    ,"Station_Address":"44D, đường Quốc lộ 1A , Quận 12"
    ,"Lat":10.856256
    ,"Long":106.638172
    ,"Polyline":"[106.64102173,10.85754013] ; [106.63844299,10.85614014]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2779"
    ,"Station_Code":"Q12 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà lầu"
    ,"Station_Address":"228/3, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.855055
    ,"Long":106.636165
    ,"Polyline":"[106.63844299,10.85614014] ; [106.63629913,10.85496998]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2781"
    ,"Station_Code":"Q12 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường Nguyễn Du"
    ,"Station_Address":"Đối diện Trường Nguyễn Du, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.853048
    ,"Long":106.632469
    ,"Polyline":"[106.63629913,10.85496998] ; [106.63259888,10.85295963]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2780"
    ,"Station_Code":"Q12 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Công viên phần mềm Quang Trung"
    ,"Station_Address":"Công viên phần mềm Quang Trung, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.852242
    ,"Long":106.630935
    ,"Polyline":"[106.63259888,10.85295963] ; [106.63105011,10.85212994]"
    ,"Distance":"193"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2091"
    ,"Station_Code":"Q12 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu vượt Quang Trung"
    ,"Station_Address":"B45, đường Quang Trung, Quận 12"
    ,"Lat":10.848996
    ,"Long":106.632679
    ,"Polyline":"[106.63105011,10.85212994] ; [106.62950134,10.85138035] ; [106.62734985,10.85037041] ; [106.62670898,10.85007000] ; [106.62644196,10.85004997] ; [106.62625885,10.85011005] ; [106.62618256,10.85023022] ; [106.62615204,10.85033035] ; [106.62616730,10.85046959] ; [106.62626648,10.85054970] ; [106.62651062,10.85066032] ; [106.62748718,10.85101986] ; [106.62767792,10.85105991] ; [106.62795258,10.85101032] ; [106.62850952,10.85091019] ; [106.62962341,10.85068989] ; [106.63027954,10.85054970] ; [106.63091278,10.85035992] ; [106.63121796,10.85023022] ; [106.63152313,10.85004997] ; [106.63188934,10.84974957] ; [106.63273621,10.84914970]"
    ,"Distance":"1403"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2092"
    ,"Station_Code":"Q12 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"113, đường Quang Trung, Quận 12"
    ,"Lat":10.848253
    ,"Long":106.634363
    ,"Polyline":"[106.63275146,10.84914970] ; [106.63414001,10.84813976]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3415"
    ,"Station_Code":"Q12 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Tín Sang"
    ,"Station_Address":"90, đường Nguyễn Văn Quá,  Quận 12"
    ,"Lat":10.846736
    ,"Long":106.634148
    ,"Polyline":"[106.63414001,10.84813976] ; [106.63491821,10.84759045] ; [106.63510132,10.84747028] ; [106.63507080,10.84741020] ; [106.63462067,10.84702015] ; [106.63419342,10.84667969]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3414"
    ,"Station_Code":"Q12 149"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Đông Hưng Thuận 2"
    ,"Station_Address":"593, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.84416
    ,"Long":106.631568
    ,"Polyline":"[106.63419342,10.84667969] ; [106.63332367,10.84597969] ; [106.63202667,10.84453011] ; [106.63162231,10.84409046]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3417"
    ,"Station_Code":"Q12 150"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cafe Venus"
    ,"Station_Address":"B168, đường Nguyễn Văn Qu á, Quận 12"
    ,"Lat":10.841262
    ,"Long":106.630226
    ,"Polyline":"[106.63162231,10.84409046] ; [106.63139343,10.84381962] ; [106.63117218,10.84335995] ; [106.63079071,10.84239960] ; [106.63031006,10.84130955] ; [106.63028717,10.84123993]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3416"
    ,"Station_Code":"Q12 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Phan Bội Châu"
    ,"Station_Address":"401, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.838861
    ,"Long":106.629677
    ,"Polyline":"[106.63028717,10.84123993] ; [106.63020325,10.84097004] ; [106.63015747,10.84080982] ; [106.63007355,10.84027004] ; [106.62973022,10.83885002]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3419"
    ,"Station_Code":"Q12 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà hàng Phương Đông"
    ,"Station_Address":"285, đường Nguyễn Văn Quá, Qu ận 12"
    ,"Lat":10.835321
    ,"Long":106.628723
    ,"Polyline":"[106.62973022,10.83885002] ; [106.62934875,10.83743000] ; [106.62890625,10.83578968] ; [106.62879181,10.83530045]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3421"
    ,"Station_Code":"Q12 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Sân bóng đá Cây Sộp"
    ,"Station_Address":"213, đường Nguyễn Văn Quá , Quận 12"
    ,"Lat":10.833132
    ,"Long":106.628059
    ,"Polyline":"[106.62877655,10.83526039] ; [106.62847137,10.83417988] ; [106.62812805,10.83312035]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3418"
    ,"Station_Code":"Q12 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Đông Hưng Thuận 2"
    ,"Station_Address":"1/64, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.830608
    ,"Long":106.627258
    ,"Polyline":"[106.62812805,10.83312035] ; [106.62732697,10.83059025]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3420"
    ,"Station_Code":"Q12 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đường song hành QL22"
    ,"Station_Address":"63 , đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.828106
    ,"Long":106.626713
    ,"Polyline":"[106.62731171,10.83055019] ; [106.62690735,10.82931995] ; [106.62683868,10.82894039] ; [106.62673950,10.82810020]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.62673950,10.82810020] ; [106.62670898,10.82777977] ; [106.62669373,10.82703972] ; [106.62654877,10.82602024] ; [106.62595367,10.82662010]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đường Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62595367,10.82662010.06.62528229] ; [10.82740974,106.62519836] ; [10.82752037,106.62503052] ; [10.82740974,106.62522125] ; [10.82717991,106.62560272] ; [10.82676029,106.62599182]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62599182,10.82637978] ; [106.62699890,10.82542038] ; [106.62803650,10.82446957] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm KCN Tân Bình"
    ,"Station_Address":"881, đường Tr ường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63089752,10.81947041]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chế Lan Viên"
    ,"Station_Address":"28/7B, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Tr ường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2292"
    ,"Station_Code":"QTP 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trạm Nhà Hàng Thượng Uyển"
    ,"Station_Address":"1/1, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.806212
    ,"Long":106.634773
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63448334,10.80760002] ; [106.63481903,10.80665016] ; [106.63497925,10.80636978]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2291"
    ,"Station_Code":"QTP 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"33/24 (659-661), đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.8048
    ,"Long":106.635269
    ,"Polyline":"[106.63500977,10.80628967] ; [106.63530731,10.80535984] ; [106.63545990,10.80486012]"
    ,"Distance":"166"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2294"
    ,"Station_Code":"QTP 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trạm Bà Quẹo"
    ,"Station_Address":"593A, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.80215
    ,"Long":106.63633
    ,"Polyline":"[106.63545990,10.80486012] ; [106.63601685,10.80313015] ; [106.63610840,10.80288029] ; [106.63636780,10.80230999] ; [106.63642883,10.80220985]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2392"
    ,"Station_Code":"QTP 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm Ng ã ba Bà Quẹo"
    ,"Station_Address":"971, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.800893
    ,"Long":106.63678
    ,"Polyline":"[106.63642883,10.80220985] ; [106.63672638,10.80177975] ; [106.63670349,10.80161953] ; [106.63681793,10.80111980] ; [106.63687134,10.80091953]"
    ,"Distance":"156"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2395"
    ,"Station_Code":"QTP 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm chợ Võ Thành Trang"
    ,"Station_Address":"885-887, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.798211
    ,"Long":106.637497
    ,"Polyline":"[106.63687134,10.80091953] ; [106.63760376,10.79823971]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4312"
    ,"Station_Code":"QTP 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã 3 Dân Tộc"
    ,"Station_Address":"1033, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.794408
    ,"Long":106.638026
    ,"Polyline":"[106.63749695,10.79821110.06.63819122] ; [10.79612732,106.63802338]"
    ,"Distance":"436"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4313"
    ,"Station_Code":"QTP 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Độc Lập"
    ,"Station_Address":"903, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.791274
    ,"Long":106.637441
    ,"Polyline":"[106.63802338,10.79440784] ; [106.63744354,10.79127407]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4314"
    ,"Station_Code":"QTP 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Vườn L ài"
    ,"Station_Address":"821, đường Lũy Bán B ích, Quận Tân Phú"
    ,"Lat":10.787764
    ,"Long":106.636889
    ,"Polyline":"[106.63744354,10.79127407] ; [106.63688660,10.78776360]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3574"
    ,"Station_Code":"QTP 189"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Siêu thị Coopmart"
    ,"Station_Address":"254 (Coop mart), đường Lũy Bán Bích,  Quận Tân Phú"
    ,"Lat":10.78475
    ,"Long":106.636421
    ,"Polyline":"[106.63688660,10.78776360] ; [106.63642120,10.78474998]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3575"
    ,"Station_Code":"QTP 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm Thoại Ngọc Hầu"
    ,"Station_Address":"721, đường Lũy Bán Bích, Quận Tân Ph ú"
    ,"Lat":10.781077
    ,"Long":106.635857
    ,"Polyline":"[106.63648224,10.78474045] ; [106.63593292,10.78106976]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3576"
    ,"Station_Code":"QTP 191"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm Cây Xăng Bình An"
    ,"Station_Address":"611, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.778568
    ,"Long":106.635117
    ,"Polyline":"[106.63593292,10.78106976] ; [106.63581085,10.78044987] ; [106.63555908,10.77958965] ; [106.63524628,10.77875996] ; [106.63516998,10.77855015]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3577"
    ,"Station_Code":"QTPT220"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Thạch Lam"
    ,"Station_Address":"531, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.776239395141602
    ,"Long":106.6336898803711
    ,"Polyline":"[106.63516998,10.77855015] ; [106.63487244,10.77789021] ; [106.63468933,10.77756023] ; [106.63436890,10.77709007] ; [106.63413239,10.77670002] ; [106.63377380,10.77618980]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3578"
    ,"Station_Code":"QTP 193"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm Bùi Thế Mỹ"
    ,"Station_Address":"425, đường L ũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.773767
    ,"Long":106.632378
    ,"Polyline":"[106.63377380,10.77618980] ; [106.63308716,10.77515984] ; [106.63287354,10.77474976] ; [106.63269806,10.77439022] ; [106.63244629,10.77373981]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3579"
    ,"Station_Code":"QTP 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Cây Keo"
    ,"Station_Address":"295-297, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.770796
    ,"Long":106.63179
    ,"Polyline":"[106.63244629,10.77373981] ; [106.63220978,10.77299023] ; [106.63210297,10.77237988] ; [106.63195038,10.77141953] ; [106.63185883,10.77079010]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1570"
    ,"Station_Code":"QTP 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"69, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769694
    ,"Long":106.633057
    ,"Polyline":"[106.63185883,10.77079010.06.63179779] ; [10.77029037,106.63313293]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1567"
    ,"Station_Code":"QTP 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Cây Xăng Hòa Bình"
    ,"Station_Address":"176/26, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769394
    ,"Long":106.63533
    ,"Polyline":"[106.63313293,10.76990032] ; [106.63390350,10.76963043] ; [106.63421631,10.76949978] ; [106.63432312,10.76947021] ; [106.63439941,10.76947975] ; [106.63446045,10.76947975] ; [106.63500977,10.76953030] ; [106.63530731,10.76955986]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1571"
    ,"Station_Code":"Q11 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Thuỷ Tạ"
    ,"Station_Address":"đd 90 (nhà hàng Thủy Tạ Đầm Sen), đường  Hòa Bình, Quận 11"
    ,"Lat":10.768719
    ,"Long":106.637909
    ,"Polyline":"[106.63530731,10.76955986] ; [106.63571167,10.76959038] ; [106.63597870,10.76955986] ; [106.63630676,10.76949024] ; [106.63687134,10.76930046] ; [106.63793182,10.76887035] ; [106.63796234,10.76885033]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1569"
    ,"Station_Code":"Q11 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"7B (Bến xe buýt Đầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.767916
    ,"Long":106.639511
    ,"Polyline":"[106.63796234,10.76885033] ; [106.63893890,10.76850033] ; [106.63918304,10.76838970] ; [106.63963318,10.76807976]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1043"
    ,"Station_Code":"Q11 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"3 (79), đường  Hòa Bình, Quận 11"
    ,"Lat":10.76698
    ,"Long":106.641571
    ,"Polyline":"[106.63963318,10.76807976] ; [106.64053345,10.76756001] ; [106.64096832,10.76729012] ; [106.64115143,10.76718998] ; [106.64138794,10.76710033] ; [106.64158630,10.76704025]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1044"
    ,"Station_Code":"Q11 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Tòa án nhân dân Q11"
    ,"Station_Address":"85, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.766342
    ,"Long":106.643349
    ,"Polyline":"[106.64158630,10.76704025] ; [106.64217377,10.76686954] ; [106.64215851,10.76685047] ; [106.64215851,10.76679993] ; [106.64221191,10.76669979] ; [106.64231110,10.76665020] ; [106.64241028,10.76665974] ; [106.64248657,10.76673031] ; [106.64337921,10.76642036]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1045"
    ,"Station_Code":"Q11 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Ông Ích Khiêm"
    ,"Station_Address":"43, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.765737
    ,"Long":106.645157
    ,"Polyline":"[106.64337921,10.76642036] ; [106.64517975,10.76581001]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1046"
    ,"Station_Code":"Q11 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Chợ La ̃nh Binh Thăng"
    ,"Station_Address":"307, đường L ãnh Binh Thăng, Quận 11"
    ,"Lat":10.764374
    ,"Long":106.647964
    ,"Polyline":"[106.64517975,10.76581001] ; [106.64584351,10.76558018] ; [106.64633942,10.76539993] ; [106.64646149,10.76531982] ; [106.64736938,10.76480961] ; [106.64801025,10.76445007]"
    ,"Distance":"364"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1047"
    ,"Station_Code":"Q11 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"CV Lãnh Binh Thăng"
    ,"Station_Address":"281A (Siêu thị Vinatex), đường Lãnh Binh  Thăng, Quận 11"
    ,"Lat":10.763238
    ,"Long":106.650167
    ,"Polyline":"[106.64801025,10.76445007] ; [106.65006256,10.76334000]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1048"
    ,"Station_Code":"Q11 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Trường TH Phú Thọ"
    ,"Station_Address":"316, đường Tôn Thất Hiệp, Quận 11"
    ,"Lat":10.761051
    ,"Long":106.652656
    ,"Polyline":"[106.65006256,10.76334000] ; [106.65106964,10.76280022] ; [106.65122223,10.76276016] ; [106.65222168,10.76266003] ; [106.65222931,10.76196003] ; [106.65229797,10.76167011] ; [106.65241241,10.76138020] ; [106.65270233,10.76097012]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"153"
    ,"Station_Code":"Q11 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Chợ Thi ết"
    ,"Station_Address":"1163, đường Đường 3/2, Quận 11"
    ,"Lat":10.760371
    ,"Long":106.653763
    ,"Polyline":"[106.65270233,10.76097012] ; [106.65290070,10.76076984] ; [106.65316772,10.76056004] ; [106.65328979,10.76018047] ; [106.65373230,10.76043034]"
    ,"Distance":"187"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"154"
    ,"Station_Code":"Q11 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Lê Đại Hành"
    ,"Station_Address":"1007 (1029), đường Đường 3/2, Quận 11"
    ,"Lat":10.761562
    ,"Long":106.656006
    ,"Polyline":"[106.65373230,10.76043034] ; [106.65563965,10.76144981] ; [106.65595245,10.76163960]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1049"
    ,"Station_Code":"Q11 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"167-169, đường Phó Cơ Điều, Quận 11"
    ,"Lat":10.761036
    ,"Long":106.656982
    ,"Polyline":"[106.65595245,10.76163960] ; [106.65698242,10.76220989] ; [106.65701294,10.76204014] ; [106.65704346,10.76103973]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1050"
    ,"Station_Code":"Q5 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Chợ Thiếc"
    ,"Station_Address":"235 , đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.757568
    ,"Long":106.657616
    ,"Polyline":"[106.65704346,10.76103973] ; [106.65708923,10.75936031] ; [106.65708923,10.75798035] ; [106.65711975,10.75753975] ; [106.65760803,10.75763035]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"281"
    ,"Station_Code":"Q5 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Bệnh viện Ch ợ Rẫy"
    ,"Station_Address":"201A, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758079
    ,"Long":106.660128
    ,"Polyline":"[106.65760803,10.75763035] ; [106.65827942,10.75778961] ; [106.66010284,10.75815010]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"616"
    ,"Station_Code":"Q5 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Bệnh vi ện Hùng Vương"
    ,"Station_Address":"Hông Bệnh vi ện Hùng Vương, đường Lý Thường Kiệt, Quận 5"
    ,"Lat":10.755702
    ,"Long":106.66221
    ,"Polyline":"[106.66010284,10.75815010.06.66062164] ; [10.75825977,106.66149139] ; [10.75844955,106.66149139] ; [10.75842953,106.66184998] ; [10.75718021,106.66226196]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Bệnh vi ện Hùng Vương"
    ,"Station_Address":"132, đường Hồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66226196,10.75570965] ; [106.66236877,10.75539017] ; [106.66108704,10.75514030]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Bệnh vi ện Chợ Rẫy"
    ,"Station_Address":"172, đường H ồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66108704,10.75514030] ; [106.65962982,10.75485992]"
    ,"Distance":"177"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"397"
    ,"Station_Code":"Q5 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"81, đường Châu V ăn Liêm, Quận 5"
    ,"Lat":10.752445
    ,"Long":106.658792
    ,"Polyline":"[106.65962982,10.75485992] ; [106.65843964,10.75463009] ; [106.65841675,10.75452995] ; [106.65837097,10.75434017] ; [106.65849304,10.75378990] ; [106.65878296,10.75296974] ; [106.65886688,10.75245953]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.65886688,10.75245953] ; [106.65895081,10.75201035] ; [106.65892792,10.75181961] ; [106.65898895,10.75139046]"
    ,"Distance":"139"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"617"
    ,"Station_Code":"Q8 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Tùng Thi ện Vương"
    ,"Station_Address":"388, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.74483
    ,"Long":106.656926
    ,"Polyline":"[106.65897369,10.75139046] ; [106.65901947,10.75082016] ; [106.65899658,10.75078964] ; [106.65899658,10.75072002] ; [106.65902710,10.75065994] ; [106.65908813,10.75063038] ; [106.65914917,10.75061989] ; [106.65921021,10.75063992] ; [106.65924072,10.75067043] ; [106.65971375,10.75045967] ; [106.65985870,10.75035954] ; [106.65991974,10.75024986] ; [106.66033173,10.74905968] ; [106.66037750,10.74890041] ; [106.66050720,10.74841976] ; [106.66052246,10.74827957] ; [106.66052246,10.74806023] ; [106.66042328,10.74730968] ; [106.66036987,10.74703979] ; [106.66031647,10.74699020] ; [106.66024017,10.74695969] ; [106.66010284,10.74695015] ; [106.65994263,10.74693012] ; [106.65984344,10.74685001] ; [106.65956879,10.74660969] ; [106.65921783,10.74625969] ; [106.65902710,10.74600983] ; [106.65888214,10.74577999] ; [106.65854645,10.74563980] ; [106.65705872,10.74479961] ; [106.65664673,10.74456978]"
    ,"Distance":"1088"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"618"
    ,"Station_Code":"Q8 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"65"
    ,"Station_Name":"Chùa Pha ́p Quang"
    ,"Station_Address":"100, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738642
    ,"Long":106.656142
    ,"Polyline":"[106.65664673,10.74456978] ; [106.65602112,10.74423981] ; [106.65577698,10.74403954] ; [106.65567017,10.74392033] ; [106.65554047,10.74370003] ; [106.65541840,10.74337959] ; [106.65538788,10.74310017] ; [106.65545654,10.74271011] ; [106.65560150,10.74232006] ; [106.65605927,10.74118996] ; [106.65612030,10.74098015] ; [106.65618896,10.74079037] ; [106.65627289,10.74055958] ; [106.65628815,10.74038982] ; [106.65618896,10.73954010.06.65612793] ; [10.73927021,106.65612793] ; [10.73919010.06.65617371,10.73906040] ; [106.65619659,10.73863983]"
    ,"Distance":"751"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"619"
    ,"Station_Code":"Q8 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"66"
    ,"Station_Name":"Bùi Minh Tr ực"
    ,"Station_Address":"224, đường Quốc lộ 50 , Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656126
    ,"Polyline":"[106.65618896,10.73864460] ; [106.65620422,10.73618889]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"0"
    ,"Station_Order":"67"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":"[106.65621948,10.73618984] ; [106.65615082,10.73363972]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường  Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"502"
    ,"Station_Code":"Q8 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"193, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656346
    ,"Polyline":"[106.65615082,10.73363972] ; [106.65621185,10.73606968]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"499"
    ,"Station_Code":"Q8 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Nhị Thiên Đường"
    ,"Station_Address":"81, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738769
    ,"Long":106.656427
    ,"Polyline":"[106.65621185,10.73606968] ; [106.65628815,10.73882961]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"542"
    ,"Station_Code":"Q8 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"487, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.744513
    ,"Long":106.656802
    ,"Polyline":"[106.65628815,10.73882961] ; [106.65628815,10.73923969] ; [106.65638733,10.74069023] ; [106.65635681,10.74090958] ; [106.65622711,10.74122047] ; [106.65585327,10.74217033] ; [106.65570831,10.74260998] ; [106.65558624,10.74295044] ; [106.65554810,10.74326038] ; [106.65557861,10.74351978] ; [106.65567780,10.74376965] ; [106.65579987,10.74396992] ; [106.65583801,10.74407005] ; [106.65602112,10.74423981] ; [106.65647888,10.74448013]"
    ,"Distance":"690"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"501"
    ,"Station_Code":"Q8 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Xóm C ủi"
    ,"Station_Address":"337, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.746073
    ,"Long":106.659763
    ,"Polyline":"[106.65647888,10.74448013] ; [106.65854645,10.74563980] ; [106.65904999,10.74584961] ; [106.65960693,10.74612045]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"14-16, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65960693,10.74612045] ; [106.66024780,10.74643993] ; [106.66036224,10.74650955] ; [106.66045380,10.74662971] ; [106.66059875,10.74779987] ; [106.66062927,10.74816990] ; [106.66062164,10.74831009] ; [106.66056824,10.74868011] ; [106.66046143,10.74899960] ; [106.66005707,10.75010967] ; [106.66007233,10.75022030] ; [106.66011810,10.75030994] ; [106.66021729,10.75037956] ; [106.66040039,10.75045967] ; [106.66056061,10.75055981] ; [106.66060638,10.75063992] ; [106.66110229,10.75092030] ; [106.66133881,10.75100994] ; [106.66150665,10.75104046] ; [106.66149902,10.75119972] ; [106.66127014,10.75113010.06.66092682] ; [10.75098038,106.66050720] ; [10.75072002,106.66026306] ; [10.75057030,106.66011810] ; [10.75053024,106.65998077] ; [10.75053024,106.65986633] ; [10.75055027,106.65966034] ; [10.75063038,106.65926361] ; [10.75078964,106.65924835] ; [10.75082016,106.65920258] ; [10.75086975,106.65917206] ; [10.75088024,106.65911102]"
    ,"Distance":"1062"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"5"
    ,"Station_Code":"Q5 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"68, đường Châu V ăn Liêm, Quận 5"
    ,"Lat":10.752566
    ,"Long":106.658937
    ,"Polyline":"[106.65911102,10.75135994] ; [106.65904999,10.75183010.06.65895081] ; [10.75201035,106.65885162]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65885162,10.75255013] ; [106.65878296,10.75296974] ; [106.65849304,10.75378990] ; [106.65837097,10.75434017] ; [106.65840149,10.75444984] ; [106.65921783,10.75459957]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"544"
    ,"Station_Code":"Q5 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Hùng Vương Plaza"
    ,"Station_Address":"4, đường Lý Thường Kiệt, Quận 5"
    ,"Lat":10.756013
    ,"Long":106.662333
    ,"Polyline":"[106.65921783,10.75459957] ; [106.66153717,10.75502014] ; [106.66245270,10.75520992] ; [106.66236877,10.75539017] ; [106.66219330,10.75597954]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"393"
    ,"Station_Code":"Q11 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"BV Răng  Hàm Mặt"
    ,"Station_Address":"598, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.758364
    ,"Long":106.660828
    ,"Polyline":"[106.66219330,10.75597954] ; [106.66149139,10.75842953] ; [106.66149139,10.75844955] ; [106.66084290,10.75831032]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1014"
    ,"Station_Code":"Q11 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đường 3/2"
    ,"Station_Address":"170-172, đường  Lê Đại Hành, Quận 11"
    ,"Lat":10.761931
    ,"Long":106.657376
    ,"Polyline":"[106.66082764,10.75836372] ; [106.66084290,10.75831032] ; [106.66027832,10.75819016] ; [106.65953064,10.75802994] ; [106.65952301,10.75804996] ; [106.65827942,10.75773144] ; [106.65862274,10.75886917] ; [106.65879059,10.75934410.06.65888214] ; [10.75959969,106.65823364] ; [10.76049042,106.65762329] ; [10.76138973,106.65740967] ; [10.76165962,106.65743256]"
    ,"Distance":"798"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1016"
    ,"Station_Code":"Q11 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Cổng chào CV Đầm sen"
    ,"Station_Address":"20, đường Lãnh  Binh Thăng, Quận 11"
    ,"Lat":10.762369
    ,"Long":106.655917
    ,"Polyline":"[106.65740967,10.76165962] ; [106.65727234,10.76183033] ; [106.65705109,10.76224041] ; [106.65698242,10.76220989] ; [106.65663147,10.76216030] ; [106.65598297,10.76222992] ; [106.65589905,10.76224041]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1023"
    ,"Station_Code":"Q11 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Phú Thọ"
    ,"Station_Address":"134, đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.762564
    ,"Long":106.653879
    ,"Polyline":"[106.65589905,10.76224041] ; [106.65386200,10.76247978]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1018"
    ,"Station_Code":"Q11 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"CV Lãnh Binh Thăng"
    ,"Station_Address":"Đối diện Trư ờng mầm non (278), đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.762875
    ,"Long":106.651239
    ,"Polyline":"[106.65386200,10.76247978] ; [106.65281677,10.76257992] ; [106.65174866,10.76272011] ; [106.65151215,10.76272964]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1024"
    ,"Station_Code":"Q11 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà văn hóa Quận 11"
    ,"Station_Address":"284, đường Lãnh Binh Thăng, Qu ận 11"
    ,"Lat":10.764453
    ,"Long":106.648193
    ,"Polyline":"[106.65151215,10.76272964] ; [106.65117645,10.76276970] ; [106.65106964,10.76280022] ; [106.65045929,10.76313019] ; [106.64814758,10.76438046]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1027"
    ,"Station_Code":"Q11 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Lãnh Binh Thăng"
    ,"Station_Address":"308-310, đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.76512
    ,"Long":106.646926
    ,"Polyline":"[106.64814758,10.76438046] ; [106.64685822,10.76508999]"
    ,"Distance":"161"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1020"
    ,"Station_Code":"Q11 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Tòa án nhân dân Q11"
    ,"Station_Address":"150, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.76659
    ,"Long":106.643082
    ,"Polyline":"[106.64685822,10.76508999] ; [106.64633942,10.76539993] ; [106.64530182,10.76576996] ; [106.64428711,10.76611042] ; [106.64305878,10.76653957]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1029"
    ,"Station_Code":"Q11 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bãi xe  buýt Đầm Sen"
    ,"Station_Address":"40A, đường Hòa Bình, Quận 11"
    ,"Lat":10.767302
    ,"Long":106.641181
    ,"Polyline":"[106.64305878,10.76653957] ; [106.64250183,10.76675034] ; [106.64250946,10.76677990] ; [106.64250946,10.76683044] ; [106.64247131,10.76692009] ; [106.64237976,10.76698017] ; [106.64231110,10.76698017] ; [106.64225006,10.76696014] ; [106.64218140,10.76688957] ; [106.64163971,10.76702976] ; [106.64125824,10.76714993] ; [106.64109802,10.76721954]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1616"
    ,"Station_Code":"Q11 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Hòa Bình"
    ,"Station_Address":"72, đường Hòa Bình, Quận 11"
    ,"Lat":10.768496
    ,"Long":106.639137
    ,"Polyline":"[106.64108276,10.76723003] ; [106.63979340,10.76797962] ; [106.63909912,10.76842022]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1604"
    ,"Station_Code":"QTP 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đầm Sen"
    ,"Station_Address":"45 (Đối diện công viên nước Đầm Sen), đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769367
    ,"Long":106.63707
    ,"Polyline":"[106.63909912,10.76842022] ; [106.63761139,10.76900005] ; [106.63701630,10.76924038]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1617"
    ,"Station_Code":"QTP 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Chùa Huệ Quang"
    ,"Station_Address":"116, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769747
    ,"Long":106.635246
    ,"Polyline":"[106.63701630,10.76924038] ; [106.63658905,10.76939964] ; [106.63613892,10.76953030] ; [106.63587189,10.76957989] ; [106.63551331,10.76959038] ; [106.63526917,10.76955986]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1619"
    ,"Station_Code":"QTP 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"126, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.77
    ,"Long":106.633362
    ,"Polyline":"[106.63526917,10.76955986] ; [106.63452911,10.76947975] ; [106.63440704,10.76947975] ; [106.63432312,10.76947021] ; [106.63411713,10.76951981] ; [106.63390350,10.76963043] ; [106.63336182,10.76982975]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4315"
    ,"Station_Code":"QTPT232"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"264, Lũy Bán Bích"
    ,"Station_Address":"264, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.7706848586522
    ,"Long":106.631915803614
    ,"Polyline":"[106.63336182,10.77000046] ; [106.63191223,10.77068520]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4316"
    ,"Station_Code":"QTPT233"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"332, Lũy Bán Bích"
    ,"Station_Address":"314, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.7736781543893
    ,"Long":106.632484431926
    ,"Polyline":"[106.63191223,10.77068520] ; [106.63248444,10.77367783]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4317"
    ,"Station_Code":"QTP 204"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Thạch Lam"
    ,"Station_Address":"394, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.77606
    ,"Long":106.633788
    ,"Polyline":"[106.63248444,10.77367783] ; [106.63378906,10.77606010]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4318"
    ,"Station_Code":"QTP 205"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cây xăng Bình An"
    ,"Station_Address":"464,  đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.778395
    ,"Long":106.635204
    ,"Polyline":"[106.63378906,10.77606010.06.63520050]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4319"
    ,"Station_Code":"QTPT236"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công vi ên Ủy ban Quận Tân Phú"
    ,"Station_Address":"K ế 556, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.780972
    ,"Long":106.635987
    ,"Polyline":"[106.63520050,10.77839470] ; [106.63598633,10.78097153]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4320"
    ,"Station_Code":"QTP 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Siêu th ị Coopmart"
    ,"Station_Address":"Đối diện 564 , đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.784639
    ,"Long":106.636545
    ,"Polyline":"[106.63598633,10.78097153] ; [106.63654327,10.78463936]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4321"
    ,"Station_Code":"QTPT239"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Vườn L ài"
    ,"Station_Address":"624, đường Lũy Bán B ích, Quận Tân Phú"
    ,"Lat":10.787638
    ,"Long":106.637028
    ,"Polyline":"[106.63654327,10.78463936] ; [106.63703156,10.78763771]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4322"
    ,"Station_Code":"QTP 209"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Độc Lập"
    ,"Station_Address":"672, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.791189
    ,"Long":106.637591
    ,"Polyline":"[106.63703156,10.78763771] ; [106.63758850,10.79118919]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"4323"
    ,"Station_Code":"QTP 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"Kios 07, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.794481
    ,"Long":106.63808
    ,"Polyline":"[106.63758850,10.79118919] ; [106.63807678,10.79448128]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2422"
    ,"Station_Code":"QTB 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm Ba Vân"
    ,"Station_Address":"928, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.796295
    ,"Long":106.638214
    ,"Polyline":"[106.63807678,10.79448128] ; [106.63821411,10.79629517]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2425"
    ,"Station_Code":"QTB 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Võ  Thành Trang"
    ,"Station_Address":"988-990, đ ường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.79878
    ,"Long":106.63752
    ,"Polyline":"[106.63816071,10.79627991] ; [106.63745880,10.79876041]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2424"
    ,"Station_Code":"QTB 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã ba Bà Quẹo"
    ,"Station_Address":"1064, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.80068
    ,"Long":106.636986
    ,"Polyline":"[106.63745880,10.79876041] ; [106.63694000,10.80066967]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1302"
    ,"Station_Code":"QTB 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"638, đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.804626
    ,"Long":106.635656
    ,"Polyline":"[106.63694000,10.80066967] ; [106.63681793,10.80111980] ; [106.63670349,10.80161953] ; [106.63672638,10.80177975] ; [106.63642883,10.80220985] ; [106.63610840,10.80288029] ; [106.63565826,10.80420017] ; [106.63553619,10.80459976]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2202"
    ,"Station_Code":"QTB 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.806202
    ,"Long":106.635184
    ,"Polyline":"[106.63553619,10.80459976] ; [106.63504791,10.80618000]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63504791,10.80618000] ; [106.63497925,10.80636978] ; [106.63493347,10.80665970] ; [106.63488007,10.80706978] ; [106.63481903,10.80762005] ; [106.63462067,10.80801010]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận  Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63462067,10.80801010.06.63450623] ; [10.80827045,106.63417053] ; [10.80928993,106.63343811]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63343811,10.81167984] ; [106.63253784,10.81462002]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63253784,10.81462002] ; [106.63163757,10.81752968]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63163757,10.81752968] ; [106.63038635,10.82162952]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3407"
    ,"Station_Code":"Q12 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đường song hành QL 22"
    ,"Station_Address":"1 /42, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.827323
    ,"Long":106.626762
    ,"Polyline":"[106.63038635,10.82162952] ; [106.63025665,10.82201958] ; [106.63004303,10.82254028] ; [106.62976837,10.82297993] ; [106.62959290,10.82320023] ; [106.62840271,10.82431984] ; [106.62654877,10.82602024] ; [106.62669373,10.82703972] ; [106.62670135,10.82732010]"
    ,"Distance":"814"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3406"
    ,"Station_Code":"Q12 141"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Ngân h àng ACB"
    ,"Station_Address":"1/64, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.829623
    ,"Long":106.627083
    ,"Polyline":"[106.62670135,10.82732010.06.62670898] ; [10.82777977,106.62683868] ; [10.82894039,106.62690735] ; [10.82931995,106.62702179]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3409"
    ,"Station_Code":"Q12 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Sân bóng Cây Sộp"
    ,"Station_Address":"Kế 1/97, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.833522
    ,"Long":106.628334
    ,"Polyline":"[106.62702179,10.82964039] ; [106.62812805,10.83312035] ; [106.62827301,10.83353996]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3408"
    ,"Station_Code":"Q12 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà hàng Phương Đông"
    ,"Station_Address":"344, đường Nguyễn Văn Quá , Quận 12"
    ,"Lat":10.836078
    ,"Long":106.629051
    ,"Polyline":"[106.62827301,10.83353996] ; [106.62875366,10.83514023] ; [106.62899780,10.83609009]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3411"
    ,"Station_Code":"Q12 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trường Phan Bội Châu"
    ,"Station_Address":"21A, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.839212
    ,"Long":106.629883
    ,"Polyline":"[106.62899780,10.83609009] ; [106.62934875,10.83743000] ; [106.62966919,10.83860016] ; [106.62979889,10.83915997] ; [106.62982178,10.83922958]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3410"
    ,"Station_Code":"Q12 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Cafe Venus"
    ,"Station_Address":"566, đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.841681
    ,"Long":106.630554
    ,"Polyline":"[106.62982178,10.83922958] ; [106.63004303,10.84010983] ; [106.63009644,10.84045029] ; [106.63018799,10.84094048] ; [106.63023376,10.84109020] ; [106.63049316,10.84171009]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3412"
    ,"Station_Code":"Q12 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Đông H ưng Thuận 2"
    ,"Station_Address":"708 (Trung tâm y tế), đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.844249
    ,"Long":106.631851
    ,"Polyline":"[106.63049316,10.84171009] ; [106.63117218,10.84335995] ; [106.63139343,10.84381962] ; [106.63181305,10.84428978]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3413"
    ,"Station_Code":"Q12 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Quang Trung"
    ,"Station_Address":"52 , đường Nguyễn Văn Quá, Quận 12"
    ,"Lat":10.84656
    ,"Long":106.634117
    ,"Polyline":"[106.63182068,10.84430027] ; [106.63258362,10.84512997] ; [106.63330841,10.84597015] ; [106.63394165,10.84648991] ; [106.63408661,10.84659958]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2056"
    ,"Station_Code":"Q12 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"154, đường Quang Trung, Quận 12"
    ,"Lat":10.847842
    ,"Long":106.634422
    ,"Polyline":"[106.63408661,10.84659958] ; [106.63497162,10.84731960] ; [106.63510132,10.84747028] ; [106.63516235,10.84755993] ; [106.63452148,10.84801960]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2052"
    ,"Station_Code":"Q12 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Cầu vượt Quang Trung"
    ,"Station_Address":"170, đường Quang Trung, Quận 12"
    ,"Lat":10.849784
    ,"Long":106.63221
    ,"Polyline":"[106.63452148,10.84801960] ; [106.63292694,10.84916973] ; [106.63217926,10.84974003]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2677"
    ,"Station_Code":"Q12 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Phan Bội Châu"
    ,"Station_Address":"Trường Nguyễn Du, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.852583
    ,"Long":106.632347
    ,"Polyline":"[106.63217926,10.84974003] ; [106.63188171,10.84996033] ; [106.63188171,10.85000992] ; [106.63114166,10.85058022] ; [106.63107300,10.85066986] ; [106.63099670,10.85079002] ; [106.63099670,10.85093021] ; [106.63108063,10.85107040] ; [106.63130951,10.85126019] ; [106.63146210,10.85144043] ; [106.63153839,10.85161972] ; [106.63159180,10.85181046] ; [106.63166809,10.85198021] ; [106.63178253,10.85214043] ; [106.63185120,10.85223007] ; [106.63201904,10.85237026] ; [106.63214874,10.85245991] ; [106.63229370,10.85262012]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2675"
    ,"Station_Code":"Q12 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Bác sĩ Liêm"
    ,"Station_Address":"103/4B, đ ường Quốc lộ 1A, Quận 12"
    ,"Lat":10.853322
    ,"Long":106.633719
    ,"Polyline":"[106.63231659,10.85262966] ; [106.63368225,10.85338974]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2676"
    ,"Station_Code":"Q12 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngã tư Đình"
    ,"Station_Address":"1793B, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.856667
    ,"Long":106.639832
    ,"Polyline":"[106.63368225,10.85338974] ; [106.63980103,10.85671997]"
    ,"Distance":"778"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2678"
    ,"Station_Code":"Q12 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Cây xăng Thạnh Xuân"
    ,"Station_Address":"Kế cây xăng  Thạnh Xuân, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.858953
    ,"Long":106.644233
    ,"Polyline":"[106.63980103,10.85671997] ; [106.64185333,10.85785007] ; [106.64353180,10.85875034] ; [106.64417267,10.85910034]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2680"
    ,"Station_Code":"Q12 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Cao su  Vina"
    ,"Station_Address":"1721, đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.86097
    ,"Long":106.647781
    ,"Polyline":"[106.64417267,10.85910034] ; [106.64495850,10.85951996] ; [106.64512634,10.85964012] ; [106.64698792,10.86065006] ; [106.64759827,10.86098957] ; [106.64777374,10.86102962]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1670"
    ,"Station_Code":"Q12 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Metro Hiệp Phú"
    ,"Station_Address":"48, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.863513
    ,"Long":106.649757
    ,"Polyline":"[106.64777374,10.86102962] ; [106.64784241,10.86104965] ; [106.64851379,10.86139965] ; [106.64910889,10.86168957] ; [106.64945984,10.86180019] ; [106.64978027,10.86188984] ; [106.64978027,10.86196995] ; [106.64975739,10.86211014] ; [106.64968872,10.86351013]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1672"
    ,"Station_Code":"Q12T002"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Trạm xăng Hưng Thịnh"
    ,"Station_Address":"C ây xăng Hưng Thịnh, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.865291595458984
    ,"Long":106.64966583251953
    ,"Polyline":"[106.64968872,10.86351013] ; [106.64959717,10.86528969]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1669"
    ,"Station_Code":"Q12 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Công ty bia Tiger"
    ,"Station_Address":"Công ty bia Tiger, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.868094
    ,"Long":106.649555
    ,"Polyline":"[106.64959717,10.86528969] ; [106.64945984,10.86808014]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1674"
    ,"Station_Code":"Q12 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Bảo hiểm xã hội Quận 12"
    ,"Station_Address":"270, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.872066
    ,"Long":106.649335
    ,"Polyline":"[106.64945984,10.86808014] ; [106.64936066,10.86970997] ; [106.64929199,10.87150955] ; [106.64926910,10.87205029]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"1671"
    ,"Station_Code":"Q12 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"UBND phường Thới An"
    ,"Station_Address":"Ủy ban nhân dan P.Thới An, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.874247
    ,"Long":106.649238
    ,"Polyline":"[106.64926910,10.87205029] ; [106.64914703,10.87423038]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"3426"
    ,"Station_Code":"Q12 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"390, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.878841
    ,"Long":106.649002
    ,"Polyline":"[106.64914703,10.87423038] ; [106.64897919,10.87705040] ; [106.64890289,10.87884045]"
    ,"Distance":"526"
  },
  {
     "Route_Id":"91"
    ,"Station_Id":"2745"
    ,"Station_Code":"BX35"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"BÃI XE THỚI AN, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.878466606140137
    ,"Long":106.64797973632812
    ,"Polyline":"[106.64890289,10.87884045] ; [106.64891052,10.87851048]"
    ,"Distance":"144"
  }]