export const Route2 =[
  {
     "Route_Id":"2"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vư ơng, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"4149"
    ,"Station_Code":"QBT 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"49-51 (317), Kinh Dương Vương"
    ,"Station_Address":"49-51 (317), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743396
    ,"Long":106.62136
    ,"Polyline":"[106.61979720,10.74053589] ; [106.61992200,10.74073772] ; [106.61960700,10.74118199] ; [106.61933900,10.74149895] ; [106.61916350,10.74172497] ; [106.62038420,10.74270058] ; [106.62089540,10.74316406] ; [106.62136080,10.74339581]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Qu ận Bình Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.62136078,10.74339581] ; [106.62215424,10.74412823] ; [106.62274170,10.74461365] ; [106.62304688,10.74485588] ; [106.62316132,10.74491882]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"141"
    ,"Station_Code":"Q6 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Mũi Tàu Phú Lâm"
    ,"Station_Address":"1031C, đường Hậu Giang, Quận 6"
    ,"Lat":10.745362
    ,"Long":106.624466
    ,"Polyline":"[106.62316132,10.74491882] ; [106.62330627,10.74508286] ; [106.62363434,10.74523544] ; [106.62371826,10.74531937] ; [106.62382507,10.74535656] ; [106.62390137,10.74537754] ; [106.62397003,10.74536705] ; [106.62411499,10.74531460] ; [106.62446594,10.74536228]"
    ,"Distance":"161"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"143"
    ,"Station_Code":"Q6 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Đồng Quê"
    ,"Station_Address":"919, đường Hậu Giang, Quận 6"
    ,"Lat":10.746311
    ,"Long":106.628092
    ,"Polyline":"[106.62446594,10.74536228] ; [106.62549591,10.74561977] ; [106.62686920,10.74603653] ; [106.62808990,10.74631119]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"145"
    ,"Station_Code":"Q6 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Bình Phú"
    ,"Station_Address":"733-735, đường Hậu Giang, Quận 6"
    ,"Lat":10.747623
    ,"Long":106.633526
    ,"Polyline":"[106.62808990,10.74631119] ; [106.63352966,10.74762344]"
    ,"Distance":"612"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"142"
    ,"Station_Code":"Q6 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Nguyễn Văn Lu ông"
    ,"Station_Address":"517-519, đường Hậu Giang, Quận 6"
    ,"Lat":10.74826
    ,"Long":106.636192
    ,"Polyline":"[106.63352966,10.74762344] ; [106.63477325,10.74794388] ; [106.63619232,10.74825954]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"144"
    ,"Station_Code":"Q6 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Chợ Hoa"
    ,"Station_Address":"411, đường H ậu Giang, Quận 6"
    ,"Lat":10.748814
    ,"Long":106.638359
    ,"Polyline":"[106.63619232,10.74825954] ; [106.63726807,10.74855042] ; [106.63835907,10.74881363]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"146"
    ,"Station_Code":"Q6 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Minh Phụng"
    ,"Station_Address":"122, đường Minh Phụng, Quận 6"
    ,"Lat":10.750869
    ,"Long":106.642619
    ,"Polyline":"[106.63835907,10.74881363] ; [106.63902283,10.74900913] ; [106.64035797,10.74933529] ; [106.64145660,10.74962044] ; [106.64192200,10.74972057] ; [106.64212799,10.74975777] ; [106.64234924,10.74976254] ; [106.64247131,10.75042152] ; [106.64261627,10.75086880]"
    ,"Distance":"577"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"147"
    ,"Station_Code":"Q6 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"242, đường Minh Phụng, Quận 6"
    ,"Lat":10.753468
    ,"Long":106.643096
    ,"Polyline":"[106.64261627,10.75086880] ; [106.64279938,10.75158119] ; [106.64287567,10.75225544] ; [106.64309692,10.75346756]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"148"
    ,"Station_Code":"Q11 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường Nguyễn Thi"
    ,"Station_Address":"1559, đường Đường 3/2, Quận 11"
    ,"Lat":10.755201
    ,"Long":106.644314
    ,"Polyline":"[106.64309692,10.75346756] ; [106.64331818,10.75471687] ; [106.64431763,10.75520134]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"150"
    ,"Station_Code":"Q11 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Chùa Phụng Sơn"
    ,"Station_Address":"1479, đường Đường 3/2, Quận 11"
    ,"Lat":10.756082
    ,"Long":106.645993
    ,"Polyline":"[106.64431763,10.75520134] ; [106.64515686,10.75567532] ; [106.64599609,10.75608158]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"149"
    ,"Station_Code":"Q11 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Hàn Hải  Nguyên"
    ,"Station_Address":"1375, đường Đường 3/2, Quận 11"
    ,"Lat":10.757257
    ,"Long":106.648171
    ,"Polyline":"[106.64599609,10.75608158] ; [106.64703369,10.75668812] ; [106.64817047,10.75725746]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"151"
    ,"Station_Code":"Q11 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Xóm Đất"
    ,"Station_Address":"1293, đường  Đường 3/2, Quận 11"
    ,"Lat":10.758469
    ,"Long":106.650301
    ,"Polyline":"[106.64817047,10.75725746] ; [106.64902496,10.75784683] ; [106.65029907,10.75846863]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"152"
    ,"Station_Code":"Q11 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Công an P12, Q11"
    ,"Station_Address":"1231, đường Đường 3/2, Quận 11"
    ,"Lat":10.759454
    ,"Long":106.652108
    ,"Polyline":"[106.65029907,10.75846863] ; [106.65210724,10.75945377]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"153"
    ,"Station_Code":"Q11 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"1163, đường Đường 3/2, Quận 11"
    ,"Lat":10.760371
    ,"Long":106.653763
    ,"Polyline":"[106.65210724,10.75945377] ; [106.65376282,10.76037121]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"154"
    ,"Station_Code":"Q11 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Lê Đại Hành"
    ,"Station_Address":"1007 (1029 ), đường Đường 3/2, Quận 11"
    ,"Lat":10.761562
    ,"Long":106.656006
    ,"Polyline":"[106.65376282,10.76037121] ; [106.65600586,10.76156235]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"155"
    ,"Station_Code":"Q11 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trung tâm chăm sóc sức khỏe sinh  sản"
    ,"Station_Address":"957, đường Đường 3/2, Quận 11"
    ,"Lat":10.76245
    ,"Long":106.657539
    ,"Polyline":"[106.65600586,10.76156235] ; [106.65686035,10.76210022] ; [106.65753937,10.76245022]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"156"
    ,"Station_Code":"Q10 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"781, đường  Đường 3/2, Quận 10"
    ,"Lat":10.76434
    ,"Long":106.661078
    ,"Polyline":"[106.65753937,10.76245022] ; [106.65995026,10.76378632] ; [106.66057587,10.76408386]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"157"
    ,"Station_Code":"Q10 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà thờ tin lành Nguyễn Tri Phư ơng"
    ,"Station_Address":"635, đường Đường 3/2 , Quận 10"
    ,"Lat":10.766232
    ,"Long":106.664627
    ,"Polyline":"[106.66057587,10.76408386] ; [106.66462708,10.76623154]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"158"
    ,"Station_Code":"Q10 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Bệnh viện nhi đồng"
    ,"Station_Address":"Đối diện 350, đường Đường 3/2, Quận 10"
    ,"Lat":10.769518
    ,"Long":106.670609
    ,"Polyline":"[106.66462708,10.76623154] ; [106.67060852,10.76951790]"
    ,"Distance":"750"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"160"
    ,"Station_Code":"Q10 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà thờ Vinh Sơn"
    ,"Station_Address":"273-275, đường Đường 3/2, Quận 10"
    ,"Lat":10.770269
    ,"Long":106.672166
    ,"Polyline":"[106.67060852,10.76951790] ; [106.67224884,10.77039719]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"159"
    ,"Station_Code":"Q10 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà hát Hòa Bình"
    ,"Station_Address":"183A-183B, đường Đường 3/2, Quận 10"
    ,"Lat":10.771855
    ,"Long":106.674805
    ,"Polyline":"[106.67224884,10.77039719] ; [106.67315674,10.77084827] ; [106.67476654,10.77188873]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"162"
    ,"Station_Code":"Q10 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Học viện hành chính quốc gia"
    ,"Station_Address":"113, đường Đường 3/2, Quận 10"
    ,"Lat":10.77323
    ,"Long":106.677015
    ,"Polyline":"[106.67476654,10.77188873] ; [106.67707062,10.77332211]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"161"
    ,"Station_Code":"Q3 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"75, đường Cao Thắng, Quận 3"
    ,"Lat":10.77182
    ,"Long":106.679947
    ,"Polyline":"[106.67707062,10.77332211] ; [106.67781067,10.77377796] ; [106.67825317,10.77333069] ; [106.67922974,10.77248192] ; [106.67994690,10.77182007]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"163"
    ,"Station_Code":"Q3 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"31, đường Cao Thắng, Quận 3"
    ,"Lat":10.769566
    ,"Long":106.682526
    ,"Polyline":"[106.67994690,10.77182007] ; [106.68129730,10.77072144] ; [106.68252563,10.76956558]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"164"
    ,"Station_Code":"Q1 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Chợ Thái Bình"
    ,"Station_Address":"A43 , đường Cống Quỳnh, Quận 1"
    ,"Lat":10.766863
    ,"Long":106.687653
    ,"Polyline":"[106.68252563,10.76956558] ; [106.68300629,10.76925659] ; [106.68401337,10.76839733] ; [106.68415833,10.76828671] ; [106.68430328,10.76825047] ; [106.68447113,10.76826572] ; [106.68462372,10.76828671] ; [106.68686676,10.76727009] ; [106.68765259,10.76686287]"
    ,"Distance":"648"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68765259,10.76686287] ; [106.68794250,10.76679039] ; [106.68815613,10.76671124] ; [106.68824005,10.76661682] ; [106.68829346,10.76660061] ; [106.68836212,10.76661110.06.68841553] ; [10.76665878,106.68842316] ; [10.76672173,106.68840027] ; [10.76679039,106.68833160] ; [10.76685333,106.68837738] ; [10.76706409,106.68846893] ; [10.76725960,106.68892670] ; [10.76800728,106.68924713] ; [10.76816082,106.68958282] ; [10.76830769,106.69033813]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nguyễn Thị  Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69187164,10.76917267] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Khách sạn New  world"
    ,"Station_Address":"Đối diện 1A Phạm  Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69787598,10.77159691] ; [106.69795990,10.77158642] ; [106.69802094,10.77155399] ; [106.69807434,10.77141762] ; [106.69810486,10.77132797] ; [106.69817352,10.77123833] ; [106.69736481,10.77030563] ; [106.69615936,10.76984215] ; [106.69650269,10.76918316] ; [106.69749451,10.77023697] ; [106.69844818,10.77054024]"
    ,"Distance":"819"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69925690,10.77092171] ; [106.69956207,10.77094269]"
    ,"Distance":"132"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77094269] ; [106.70195770,10.77082157]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70407104,10.77072239]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"Bến thủy nội địa Thủ Thiêm, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70407104,10.77072239] ; [106.70452881,10.77072144] ; [106.70513153,10.76943016] ; [106.70538330,10.76944160] ; [106.70563507,10.76949406] ; [106.70589447,10.76954174] ; [106.70607758,10.76962566] ; [106.70616150,10.76973629] ; [106.70621490,10.76987839] ; [106.70632935,10.77026844] ; [106.70636749,10.77043724] ; [106.70638275,10.77060604] ; [106.70636749,10.77079582] ; [106.70638275,10.77122211] ; [106.70641327,10.77184391] ; [106.70664978,10.77387810]"
    ,"Distance":"796"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"34"
    ,"Station_Code":"Q1 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"2, đường Hai  Bà Trưng, Quận 1"
    ,"Lat":10.776048
    ,"Long":106.705719
    ,"Polyline":"[106.70664978,10.77387810.06.70672607] ; [10.77570152,106.70658112] ; [10.77583885,106.70645905] ; [10.77585983,106.70632935] ; [10.77584362,106.70619202] ; [10.77579117,106.70607758] ; [10.77571201,106.70571899]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"165"
    ,"Station_Code":"BX 07"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"CÔNG TRƯỜNG  MÊ LINH, đường Đông Du, Quận 1"
    ,"Lat":10.776809
    ,"Long":106.705429
    ,"Polyline":"[106.70571899,10.77604771] ; [106.70514679,10.77656078] ; [106.70542908,10.77680874]"
    ,"Distance":"126"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"33"
    ,"Station_Code":"BX 06"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"Công trường Mê Linh, đường Thi Sách, Quận 1"
    ,"Lat":10.77679
    ,"Long":106.705856
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn  Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70585632,10.77678967] ; [106.70597076,10.77662945] ; [106.70631409,10.77582836] ; [106.70618439,10.77578068] ; [106.70606232,10.77570152] ; [106.70598602,10.77556515] ; [106.70592499,10.77536964] ; [106.70594788,10.77519608] ; [106.70600891,10.77503204] ; [106.70613098,10.77490616] ; [106.70627594,10.77482700] ; [106.70645905,10.77478504] ; [106.70652008,10.77466869] ; [106.70635986,10.77329922]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cục Hải Quan Thành Phố"
    ,"Station_Address":"2-4, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70635986,10.77329922] ; [106.70622253,10.77097988] ; [106.70610809,10.77087498] ; [106.70593262,10.77085304] ; [106.70555115,10.77088547]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84 , đường Hàm Nghi, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70555115,10.77088547] ; [106.70302582,10.77097988]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70302582,10.77097988] ; [106.70166016,10.77104759]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70166016,10.77104759] ; [106.69935608,10.77116299]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bến Thành  A"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69921875,10.77118015] ; [106.69853973,10.77089596]"
    ,"Distance":"96"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Ernst  Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853973,10.77089596] ; [106.69732666,10.77029991] ; [106.69595337,10.76980972]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"84"
    ,"Station_Code":"Q1 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện số 26, đường Nguyễn Thị Nghĩa, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.693779
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69475555,10.76930904] ; [106.69377899,10.77097988]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"85"
    ,"Station_Code":"Q1 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 6 Phù Đổng"
    ,"Station_Address":"22, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.77097
    ,"Long":106.69268
    ,"Polyline":"[106.69377899,10.77097988] ; [106.69361877,10.77118587] ; [106.69346619,10.77132797] ; [106.69344330,10.77147007] ; [106.69337463,10.77152824] ; [106.69328308,10.77154922] ; [106.69318390,10.77154922] ; [106.69309998,10.77147579] ; [106.69306946,10.77138615] ; [106.69307709,10.77128601] ; [106.69293213,10.77112770] ; [106.69268036,10.77097034]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"87"
    ,"Station_Code":"Q1 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"136, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.769646
    ,"Long":106.690788
    ,"Polyline":"[106.69268036,10.77097034] ; [106.69078827,10.76964569]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"86"
    ,"Station_Code":"Q1 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà thờ Huyện Sỹ"
    ,"Station_Address":"206Bis, đường Nguyễn Trãi, Quận 1"
    ,"Lat":10.767692
    ,"Long":106.688591
    ,"Polyline":"[106.69078827,10.76964569] ; [106.69023895,10.76926231] ; [106.68967438,10.76878738] ; [106.68941498,10.76849747] ; [106.68920135,10.76821327] ; [106.68894958,10.76808167] ; [106.68879700,10.76795006] ; [106.68859100,10.76769161]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"88"
    ,"Station_Code":"Q1 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Thái Bình"
    ,"Station_Address":"244, đường Cống Quỳnh, Quận 1"
    ,"Lat":10.766943
    ,"Long":106.687793
    ,"Polyline":"[106.68859100,10.76769161] ; [106.68834686,10.76711750] ; [106.68830109,10.76694298] ; [106.68825531,10.76689053] ; [106.68818665,10.76685333] ; [106.68811035,10.76683807] ; [106.68802643,10.76683807] ; [106.68778992,10.76694298]"
    ,"Distance":"151"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"89"
    ,"Station_Code":"Q3 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Hội Chữ thập đỏ thành phố"
    ,"Station_Address":"464 - 466, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.767691
    ,"Long":106.683693
    ,"Polyline":"[106.68778992,10.76694298] ; [106.68463135,10.76832962] ; [106.68446350,10.76833439] ; [106.68428802,10.76828671] ; [106.68369293,10.76769066]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"90"
    ,"Station_Code":"Q3 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà sách Minh Khai"
    ,"Station_Address":"488 , đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.766416
    ,"Long":106.682428
    ,"Polyline":"[106.68369293,10.76769066] ; [106.68242645,10.76641560]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"91"
    ,"Station_Code":"Q3 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Bàn Cờ"
    ,"Station_Address":"80 - 82, đường Nguyễn Thiện Thuật, Quận 3"
    ,"Lat":10.767718
    ,"Long":106.680321
    ,"Polyline":"[106.68242645,10.76641560] ; [106.68222809,10.76619530] ; [106.68032074,10.76771832]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"92"
    ,"Station_Code":"Q3 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Cao Thắng"
    ,"Station_Address":"503, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.771249
    ,"Long":106.677505
    ,"Polyline":"[106.68032074,10.76771832] ; [106.67680359,10.77058983] ; [106.67723846,10.77106953] ; [106.67750549,10.77124882]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"93"
    ,"Station_Code":"Q10 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cao Thắng"
    ,"Station_Address":"156, đường Cao Thắng, Quận 10"
    ,"Lat":10.773362
    ,"Long":106.67836
    ,"Polyline":"[106.67750549,10.77124882] ; [106.67764282,10.77149105] ; [106.67794800,10.77177620] ; [106.67830658,10.77203941] ; [106.67861176,10.77234459] ; [106.67908478,10.77274513] ; [106.67835999,10.77336216]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"95"
    ,"Station_Code":"Q10 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Học viện h ành chính quốc gia"
    ,"Station_Address":"10, đường Đường 3/2, Quận 10"
    ,"Lat":10.773457
    ,"Long":106.676951
    ,"Polyline":"[106.67835999,10.77336216] ; [106.67770386,10.77392578] ; [106.67671967,10.77335644]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"94"
    ,"Station_Code":"Q10 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Học viện h ành chính quốc gia"
    ,"Station_Address":"Kế 10A , đường Đường 3/2, Quận 10"
    ,"Lat":10.772661
    ,"Long":106.675701
    ,"Polyline":"[106.67671967,10.77335644] ; [106.67572021,10.77264309]"
    ,"Distance":"135"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"97"
    ,"Station_Code":"Q10 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà hát Hòa Bình"
    ,"Station_Address":"240, đường Đường 3/2, Quận 10"
    ,"Lat":10.771712
    ,"Long":106.674202
    ,"Polyline":"[106.67572021,10.77264309] ; [106.67420197,10.77171230]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"96"
    ,"Station_Code":"Q10 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà thờ Vinh Sơn"
    ,"Station_Address":"270, đường Đường 3/2, Quận 10"
    ,"Lat":10.770521
    ,"Long":106.67215
    ,"Polyline":"[106.67420197,10.77171230] ; [106.67306519,10.77099037] ; [106.67205811,10.77042961]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"99"
    ,"Station_Code":"Q10 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh viện nhi đồng"
    ,"Station_Address":"356, đường Đường 3/2, Quận 10"
    ,"Lat":10.769578
    ,"Long":106.670364
    ,"Polyline":"[106.67205811,10.77042961] ; [106.67040253,10.76953030]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"98"
    ,"Station_Code":"Q10 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"626-628, đ ường Đường 3/2, Quận 10"
    ,"Lat":10.764972
    ,"Long":106.661743
    ,"Polyline":"[106.67040253,10.76953030] ; [106.66174316,10.76497173]"
    ,"Distance":"1074"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"100"
    ,"Station_Code":"Q11 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nhà sách Phú Thọ"
    ,"Station_Address":"940 (6B), đường  Đường 3/2, Quận 11"
    ,"Lat":10.763115
    ,"Long":106.658409
    ,"Polyline":"[106.66174316,10.76497173] ; [106.66006470,10.76406574] ; [106.65840912,10.76311493]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"101"
    ,"Station_Code":"Q11 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Lãnh Binh Thăng"
    ,"Station_Address":"970, đường Đường  3/2, Quận 11"
    ,"Lat":10.761842
    ,"Long":106.65603
    ,"Polyline":"[106.65840912,10.76311493] ; [106.65700531,10.76227379] ; [106.65602875,10.76184177]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"103"
    ,"Station_Code":"Q11 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"1114A-1116A, đường Đường 3 /2, Quận 11"
    ,"Lat":10.760535
    ,"Long":106.653557
    ,"Polyline":"[106.65602875,10.76184177] ; [106.65479279,10.76116180] ; [106.65355682,10.76053524]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"105"
    ,"Station_Code":"Q11 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Xóm Đất"
    ,"Station_Address":"1196, đường Đường 3/2, Qu ận 11"
    ,"Lat":10.758648
    ,"Long":106.650156
    ,"Polyline":"[106.65355682,10.76053524] ; [106.65188599,10.75958061] ; [106.65015411,10.75864792]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"104"
    ,"Station_Code":"Q11 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đội Giao Thông Phú Lâm"
    ,"Station_Address":"1274, đường Đường 3/2, Qu ận 11"
    ,"Lat":10.757357
    ,"Long":106.647838
    ,"Polyline":"[106.65015411,10.75864792] ; [106.64894104,10.75791550] ; [106.64783478,10.75735664]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"107"
    ,"Station_Code":"Q11 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Phụng Sơn"
    ,"Station_Address":"1354, đường Đường 3/2, Quận 11"
    ,"Lat":10.756348
    ,"Long":106.646034
    ,"Polyline":"[106.64783478,10.75735664] ; [106.64603424,10.75634766]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"106"
    ,"Station_Code":"Q11 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường Nguyễn Thi"
    ,"Station_Address":"1456, đường Đường 3/2, Quận 11"
    ,"Lat":10.755207
    ,"Long":106.643858
    ,"Polyline":"[106.64603424,10.75634766] ; [106.64385986,10.75520706]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"109"
    ,"Station_Code":"Q6 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"201, đường Minh  Phụng, Quận 6"
    ,"Lat":10.753264
    ,"Long":106.642929
    ,"Polyline":"[106.64385986,10.75520706] ; [106.64324951,10.75482178] ; [106.64292908,10.75326443]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"108"
    ,"Station_Code":"Q6 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Minh Phụng"
    ,"Station_Address":"101, đường Minh Ph ụng, Quận 6"
    ,"Lat":10.750922
    ,"Long":106.642495
    ,"Polyline":"[106.64292908,10.75326443] ; [106.64270020,10.75162792] ; [106.64249420,10.75092220]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"111"
    ,"Station_Code":"Q6 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Cầu Hậu Giang"
    ,"Station_Address":"212A, đường Hậu Giang, Quận 6"
    ,"Lat":10.749736
    ,"Long":106.641503
    ,"Polyline":"[106.64249420,10.75092220] ; [106.64236450,10.75039005] ; [106.64227295,10.74985218] ; [106.64208984,10.74984646] ; [106.64150238,10.74973583]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"110"
    ,"Station_Code":"Q6 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Hoa"
    ,"Station_Address":"460-462, đường  Hậu Giang, Quận 6"
    ,"Lat":10.748714
    ,"Long":106.637437
    ,"Polyline":"[106.64150238,10.74973583] ; [106.63743591,10.74871445]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"113"
    ,"Station_Code":"Q6 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nguyễn Văn Luông"
    ,"Station_Address":"620-622, đường Hậu Giang, Quận 6"
    ,"Lat":10.748039
    ,"Long":106.634663
    ,"Polyline":"[106.63743591,10.74871445] ; [106.63466644,10.74803925]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"112"
    ,"Station_Code":"Q6 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Bình Phú"
    ,"Station_Address":"730-732, đường Hậu Giang, Quận 6"
    ,"Lat":10.747697
    ,"Long":106.633312
    ,"Polyline":"[106.63466644,10.74803925] ; [106.63330841,10.74769688]"
    ,"Distance":"153"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"114"
    ,"Station_Code":"Q6 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Đồng Quê"
    ,"Station_Address":"910, đường Hậu Giang, Quận 6"
    ,"Lat":10.746511
    ,"Long":106.628382
    ,"Polyline":"[106.63330841,10.74769688] ; [106.63064575,10.74702168] ; [106.62837982,10.74651146]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"115"
    ,"Station_Code":"Q6 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Mũi Tàu Ph ú Lâm"
    ,"Station_Address":"1054, đường Hậu Giang , Quận 6"
    ,"Lat":10.745536
    ,"Long":106.624686
    ,"Polyline":"[106.62837982,10.74651146] ; [106.62468719,10.74553585]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214 , đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62468719,10.74553585] ; [106.62408447,10.74537754] ; [106.62398529,10.74542522] ; [106.62398529,10.74555206] ; [106.62393188,10.74567318] ; [106.62380219,10.74571991] ; [106.62371826,10.74569416] ; [106.62364960,10.74565220] ; [106.62351227,10.74557304] ; [106.62335968,10.74546242] ; [106.62320709,10.74532986] ; [106.62247467,10.74474621]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương  Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62039948,10.74309158]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"4150"
    ,"Station_Code":"QBT 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"428, Kinh Dương Vương"
    ,"Station_Address":"428, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.741383
    ,"Long":106.618377
    ,"Polyline":"[106.62039948,10.74309158] ; [106.62011719,10.74279499] ; [106.61837769,10.74138260]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"2"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Qu ận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61837770,10.74138260] ; [106.61824040,10.74123001] ; [106.61858370,10.74084473] ; [106.61933900,10.74151993] ; [106.61903440,10.74188333] ; [106.61765190,10.74070672] ; [106.61640350,10.73962760] ; [106.61653700,10.73948542] ; [106.61816350,10.74085304] ; [106.61831670,10.74070454]"
    ,"Distance":"521"
  }]