export const Route44 =[

  {
     "Route_Id":"44"
    ,"Station_Id":"2227"
    ,"Station_Code":"BX 39"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Cầu Lớn"
    ,"Station_Address":"BÃI XE CẦU LỚN, đường Nguyễn Văn Bứa, Huyện H óc Môn"
    ,"Lat":10.871845
    ,"Long":106.535561
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2265"
    ,"Station_Code":"HHM 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"trường tiểu học Nhị Xuân"
    ,"Station_Address":"46B - 48B, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.869385
    ,"Long":106.552105
    ,"Polyline":"[106.53485870,10.87189960] ; [106.53629303,10.87162971] ; [106.53843689,10.87121964] ; [106.53864288,10.87117958]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2274"
    ,"Station_Code":"HHM 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Long Thành Phát"
    ,"Station_Address":"25A, đường Nguy ễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.872124
    ,"Long":106.569228
    ,"Polyline":"[106.53864288,10.87117958] ; [106.53975677,10.87096977] ; [106.54145813,10.87071037] ; [106.54476166,10.87024975] ; [106.54486084,10.87022972] ; [106.54480743,10.86985970]"
    ,"Distance":"729"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2267"
    ,"Station_Code":"HHM 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Thịnh Phát"
    ,"Station_Address":"34, đường Nguyễn  Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.870612
    ,"Long":106.564159
    ,"Polyline":"[106.54480743,10.86985970] ; [106.54486084,10.87022972] ; [106.54528809,10.87016964] ; [106.54853821,10.86973953] ; [106.55110931,10.86938000] ; [106.55126953,10.86935997] ; [106.55113983,10.86892986]"
    ,"Distance":"798"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2276"
    ,"Station_Code":"HHM 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường PTTH Nguyễn Văn Cừ"
    ,"Station_Address":"Trường Nguyễn Văn Cừ, đường Nguyễn  Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.868463
    ,"Long":106.555892
    ,"Polyline":"[106.55113983,10.86892986] ; [106.55126953,10.86935997] ; [106.55151367,10.86931992] ; [106.55251312,10.86917973] ; [106.55422211,10.86888981] ; [106.55545807,10.86868954]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2269"
    ,"Station_Code":"QHMT180"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Giồng"
    ,"Station_Address":"3, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.86580753326416
    ,"Long":106.56269073486328
    ,"Polyline":"[106.55545807,10.86868954] ; [106.55802155,10.86826038] ; [106.55838776,10.86806965] ; [106.55895996,10.86777973] ; [106.56121826,10.86678028] ; [106.56281281,10.86606026]"
    ,"Distance":"862"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2271"
    ,"Station_Code":"QHMT181"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã 3 Giồng"
    ,"Station_Address":"28 /7A, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.863937377929688
    ,"Long":106.56668853759766
    ,"Polyline":"[106.56281281,10.86606026] ; [106.56475830,10.86518955] ; [106.56537628,10.86491966] ; [106.56681061,10.86415005]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2273"
    ,"Station_Code":"HHM 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm nhà máy"
    ,"Station_Address":"12, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.850334
    ,"Long":106.587296
    ,"Polyline":"[106.56681061,10.86415005] ; [106.56765747,10.86367035] ; [106.56806183,10.86351967] ; [106.56920624,10.86316967] ; [106.57138062,10.86250973] ; [106.57230377,10.86225033] ; [106.57328796,10.86188984] ; [106.57353210,10.86172962] ; [106.57382202,10.86147022] ; [106.57460785,10.86081028]"
    ,"Distance":"942"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2275"
    ,"Station_Code":"HHM 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Xuân Thới Thượng"
    ,"Station_Address":"70/5, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.854744
    ,"Long":106.581322
    ,"Polyline":"[106.57460785,10.86081028] ; [106.57572937,10.85986042] ; [106.57791901,10.85803986] ; [106.57908630,10.85708046] ; [106.58003998,10.85628033] ; [106.58065796,10.85573959] ; [106.58151245,10.85503006]"
    ,"Distance":"991"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2278"
    ,"Station_Code":"HHM 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã tư Bà Điểm"
    ,"Station_Address":"56/1B, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.834655
    ,"Long":106.60635
    ,"Polyline":"[106.58154297,10.85501003] ; [106.58316040,10.85367012] ; [106.58464813,10.85241985]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2277"
    ,"Station_Code":"QHMT185"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trạm y tế"
    ,"Station_Address":"86/5, đường Phan Văn Hớn,  Huyện Hóc Môn"
    ,"Lat":10.848169326782227
    ,"Long":106.58950805664062
    ,"Polyline":"[106.58464813,10.85241985] ; [106.58509064,10.85204983] ; [106.58654022,10.85079002] ; [106.58717346,10.85025024] ; [106.58805084,10.84955978] ; [106.58912659,10.84864998] ; [106.58962250,10.84829044]"
    ,"Distance":"712"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2279"
    ,"Station_Code":"QHMT186"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trưởng học  lầu"
    ,"Station_Address":"26/4, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.845755577087402
    ,"Long":106.59258270263672
    ,"Polyline":"[106.58962250,10.84829044] ; [106.59043121,10.84764957] ; [106.59097290,10.84722996] ; [106.59255981,10.84597969] ; [106.59268188,10.84587955]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2280"
    ,"Station_Code":"HHM 196"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm Ấp 2"
    ,"Station_Address":"10 /5, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.849154
    ,"Long":106.588197
    ,"Polyline":"[106.59268188,10.84587955] ; [106.59417725,10.84473038] ; [106.59449005,10.84447002] ; [106.59496307,10.84405041] ; [106.59516144,10.84383965]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2282"
    ,"Station_Code":"QHMT188"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Ph ạm Văn Sáng"
    ,"Station_Address":"2/3, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.841983795166016
    ,"Long":106.59666442871094
    ,"Polyline":"[106.59516144,10.84383965] ; [106.59681702,10.84212017]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2281"
    ,"Station_Code":"QHMT189"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Đại  Hải"
    ,"Station_Address":"7/3, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.84106731414795
    ,"Long":106.59765625
    ,"Polyline":"[106.59681702,10.84212017] ; [106.59738159,10.84152985] ; [106.59755707,10.84138966] ; [106.59777069,10.84123993]"
    ,"Distance":"143"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2284"
    ,"Station_Code":"HHM 202"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Bà Điểm"
    ,"Station_Address":"17/7, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.839502
    ,"Long":106.59996
    ,"Polyline":"[106.59777069,10.84123993] ; [106.59848785,10.84080029] ; [106.59880066,10.84058952] ; [106.59931946,10.84018040] ; [106.60002899,10.83957958]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2283"
    ,"Station_Code":"QHMT191"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trạm Bô Rác"
    ,"Station_Address":"Cafe V&N, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.836677551269531
    ,"Long":106.60321044921875
    ,"Polyline":"[106.60002899,10.83957958] ; [106.60106659,10.83872032] ; [106.60211182,10.83782959] ; [106.60308075,10.83703995] ; [106.60333252,10.83681011]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2286"
    ,"Station_Code":"HHM 203"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"48/3B, đường Phan Văn Hớn , Huyện Hóc Môn"
    ,"Lat":10.837078
    ,"Long":106.602745
    ,"Polyline":"[106.60333252,10.83681011] ; [106.60343170,10.83672047] ; [106.60386658,10.83637047] ; [106.60428619,10.83607960] ; [106.60471344,10.83584023] ; [106.60575104,10.83524036] ; [106.60617828,10.83498001] ; [106.60662842,10.83469009]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2285"
    ,"Station_Code":"Q12 193"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Bà Điểm"
    ,"Station_Address":"197, đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.829302
    ,"Long":106.615598
    ,"Polyline":"[106.60662842,10.83469009] ; [106.60697937,10.83444023] ; [106.60711670,10.83436012] ; [106.60717010,10.83428001] ; [106.60896301,10.83304024]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2288"
    ,"Station_Code":"Q12 192"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trạm trại hòm"
    ,"Station_Address":"255, đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.831673
    ,"Long":106.611153
    ,"Polyline":"[106.60896301,10.83304024] ; [106.61009979,10.83228970] ; [106.61068726,10.83197021] ; [106.61118317,10.83172035]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2287"
    ,"Station_Code":"Q12 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Bà Điểm"
    ,"Station_Address":"Nhà sách quận 12, đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.833928
    ,"Long":106.607863
    ,"Polyline":"[106.61118317,10.83172035] ; [106.61476135,10.82989025]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2290"
    ,"Station_Code":"Q12 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm Chùa"
    ,"Station_Address":"127, đường Phan  Văn Hớn, Quận 12"
    ,"Lat":10.828498
    ,"Long":106.618813
    ,"Polyline":"[106.61476135,10.82989025] ; [106.61564636,10.82946014] ; [106.61628723,10.82923985] ; [106.61795807,10.82874012] ; [106.61882019,10.82853985]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2289"
    ,"Station_Code":"Q12 195"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Ủy ban Phường Tân Thới Nhất"
    ,"Station_Address":"21, đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.827344
    ,"Long":106.6241
    ,"Polyline":"[106.61882019,10.82853985] ; [106.62091827,10.82806015] ; [106.62287140,10.82765961] ; [106.62410736,10.82740021]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Thiên H òa"
    ,"Station_Address":"Kế 2/6B, đường Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62410736,10.82740021] ; [106.62487793,10.82723045] ; [106.62512207,10.82730007] ; [106.62560272,10.82676029] ; [106.62599182,10.82637978]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62599182,10.82637978] ; [106.62699890,10.82542038] ; [106.62803650,10.82446957] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm KCN Tân Bình"
    ,"Station_Address":"881, đường Tr ường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63089752,10.81947041]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chế Lan Viên"
    ,"Station_Address":"28/7B, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Trường  Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2292"
    ,"Station_Code":"QTP 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trạm Nhà Hàng Thượng Uyển"
    ,"Station_Address":"1/1, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.806212
    ,"Long":106.634773
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63448334,10.80760002] ; [106.63481903,10.80665016] ; [106.63497925,10.80636978]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2291"
    ,"Station_Code":"QTP 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"33/24 (659-661), đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.8048
    ,"Long":106.635269
    ,"Polyline":"[106.63500977,10.80628967] ; [106.63530731,10.80535984] ; [106.63545990,10.80486012]"
    ,"Distance":"166"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2294"
    ,"Station_Code":"QTP 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm Bà Quẹo"
    ,"Station_Address":"593A, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.80215
    ,"Long":106.63633
    ,"Polyline":"[106.63545990,10.80486012] ; [106.63601685,10.80313015] ; [106.63610840,10.80288029] ; [106.63636780,10.80230999] ; [106.63642883,10.80220985] ; [106.63632202,10.80216980]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2293"
    ,"Station_Code":"QTB 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Võ Thành Trang"
    ,"Station_Address":"541, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.801391
    ,"Long":106.637308
    ,"Polyline":"[106.63632202,10.80216980] ; [106.63642883,10.80220985] ; [106.63643646,10.80220032] ; [106.63672638,10.80177975] ; [106.63688660,10.80173016] ; [106.63787842,10.80119038] ; [106.63842773,10.80088997]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2296"
    ,"Station_Code":"QTB 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã ba Trương Công Định"
    ,"Station_Address":"403, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.799115
    ,"Long":106.641557
    ,"Polyline":"[106.63842773,10.80088997] ; [106.64115906,10.79942036] ; [106.64158630,10.79918957]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2295"
    ,"Station_Code":"QTB 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Hồng Đào"
    ,"Station_Address":"Đối diện 7,  đường Nguyễn Hồng Đào, Quận Tân Bình"
    ,"Lat":10.797381
    ,"Long":106.643434
    ,"Polyline":"[106.64158630,10.79918957] ; [106.64311218,10.79839039] ; [106.64376831,10.79806042] ; [106.64370728,10.79796028] ; [106.64353943,10.79738045] ; [106.64351654,10.79732990]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2298"
    ,"Station_Code":"QTB 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bàu Cát  2"
    ,"Station_Address":"146, đường Nguyễn Hồng Đào, Quận Tân Bình"
    ,"Lat":10.793972
    ,"Long":106.642433
    ,"Polyline":"[106.64351654,10.79732990] ; [106.64299774,10.79557037] ; [106.64282990,10.79500008] ; [106.64266968,10.79440022] ; [106.64247894,10.79395008]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2297"
    ,"Station_Code":"QTB 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chợ Bàu Cát"
    ,"Station_Address":"218, đường Nguyễn Hồng Đào, Quận Tân Bình"
    ,"Lat":10.791608
    ,"Long":106.641472
    ,"Polyline":"[106.64247894,10.79395008] ; [106.64173126,10.79209995] ; [106.64153290,10.79158974]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2299"
    ,"Station_Code":"QTP 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm Ngã 4 Thoại Ngọc Hầu"
    ,"Station_Address":"647, đường Âu  Cơ, Quận Tân Phú"
    ,"Lat":10.787243
    ,"Long":106.640915
    ,"Polyline":"[106.64153290,10.79158974] ; [106.64112854,10.79053020] ; [106.64103699,10.79036045] ; [106.64096069,10.79026031] ; [106.64083862,10.79020977] ; [106.64019775,10.79006004] ; [106.64073181,10.78845024] ; [106.64109802,10.78730965]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2300"
    ,"Station_Code":"QTP 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm Nhà Hàng Bạch Kim"
    ,"Station_Address":"577 (1004-1008A ), đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.784081
    ,"Long":106.642113
    ,"Polyline":"[106.64109802,10.78730965] ; [106.64199066,10.78509045] ; [106.64231873,10.78413963]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2301"
    ,"Station_Code":"QTP 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm Nhà Hàng Hoàng Long"
    ,"Station_Address":"8, đường Khuông Việt, Quận Tân Phú"
    ,"Lat":10.78075
    ,"Long":106.642349
    ,"Polyline":"[106.64232635,10.78411007] ; [106.64292145,10.78227997] ; [106.64318085,10.78166962] ; [106.64334106,10.78137970] ; [106.64311218,10.78120995] ; [106.64277649,10.78100967] ; [106.64267731,10.78092003] ; [106.64254761,10.78073978] ; [106.64250183,10.78065968]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2302"
    ,"Station_Code":"QTP 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm Lê Ngã"
    ,"Station_Address":"88, đường Khuông Việt, Quận Tân Phú"
    ,"Lat":10.777988
    ,"Long":106.641365
    ,"Polyline":"[106.64250183,10.78065968] ; [106.64241791,10.78052044] ; [106.64234161,10.78036976] ; [106.64228058,10.78019047] ; [106.64219666,10.77985954] ; [106.64212036,10.77952003] ; [106.64173889,10.77845001] ; [106.64151764,10.77791977]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2303"
    ,"Station_Code":"QTP 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm cầu số 2"
    ,"Station_Address":"148, đường Khuông  Việt, Quận Tân Phú"
    ,"Lat":10.776302
    ,"Long":106.639305
    ,"Polyline":"[106.64151764,10.77791977] ; [106.64108276,10.77682972] ; [106.64028168,10.77713013] ; [106.64012146,10.77715969] ; [106.63996887,10.77713013] ; [106.63990784,10.77707005] ; [106.63974762,10.77676964] ; [106.63945007,10.77622032]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2304"
    ,"Station_Code":"QTP 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm Chùa"
    ,"Station_Address":"294, đường Khuông Việt, Qu ận Tân Phú"
    ,"Lat":10.772719
    ,"Long":106.637459
    ,"Polyline":"[106.63945007,10.77622032] ; [106.63913727,10.77567005] ; [106.63874054,10.77484989] ; [106.63849640,10.77439022] ; [106.63822937,10.77398968] ; [106.63789368,10.77357960] ; [106.63780212,10.77348995] ; [106.63765717,10.77338982] ; [106.63760376,10.77338028] ; [106.63760376,10.77336025] ; [106.63761902,10.77272034]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2305"
    ,"Station_Code":"QTP 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngã Đầm Sen Khuông Việt"
    ,"Station_Address":"Đối diện 313 , đường Khuông Việt, Quận Tân Phú"
    ,"Lat":10.770379
    ,"Long":106.637497
    ,"Polyline":"[106.63761902,10.77272034] ; [106.63764191,10.77196026] ; [106.63774872,10.77038956]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1571"
    ,"Station_Code":"Q11 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Thuỷ Tạ"
    ,"Station_Address":"đd 90 (nhà hàng Thủy Tạ Đ ầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.768719
    ,"Long":106.637909
    ,"Polyline":"[106.63774872,10.77038956] ; [106.63778687,10.76990986] ; [106.63777161,10.76963997] ; [106.63768005,10.76933956] ; [106.63761139,10.76900005] ; [106.63796234,10.76885033]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1569"
    ,"Station_Code":"Q11 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bãi xe bu ýt Đầm Sen"
    ,"Station_Address":"7B (Bến xe buýt Đầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.767916
    ,"Long":106.639511
    ,"Polyline":"[106.63796234,10.76885033] ; [106.63893890,10.76850033] ; [106.63918304,10.76838970] ; [106.63963318,10.76807976]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1043"
    ,"Station_Code":"Q11 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"3 (79), đường Hòa Bình, Quận 11"
    ,"Lat":10.76698
    ,"Long":106.641571
    ,"Polyline":"[106.63963318,10.76807976] ; [106.64053345,10.76756001] ; [106.64096832,10.76729012] ; [106.64115143,10.76718998] ; [106.64140320,10.76710033] ; [106.64158630,10.76704025]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1044"
    ,"Station_Code":"Q11 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Tòa án nhân dân Q11"
    ,"Station_Address":"85, đường Ông  Ích Khiêm, Quận 11"
    ,"Lat":10.766342
    ,"Long":106.643349
    ,"Polyline":"[106.64158630,10.76704025] ; [106.64209747,10.76690006] ; [106.64222717,10.76686001] ; [106.64227295,10.76692009] ; [106.64238739,10.76694965] ; [106.64248657,10.76690006] ; [106.64251709,10.76681995] ; [106.64250946,10.76673031] ; [106.64337921,10.76642036]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1045"
    ,"Station_Code":"Q11 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Ông Ích Khiêm"
    ,"Station_Address":"43, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.765737
    ,"Long":106.645157
    ,"Polyline":"[106.64337921,10.76642036] ; [106.64517975,10.76581001]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1046"
    ,"Station_Code":"Q11 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Chợ Lãnh Binh Thăng"
    ,"Station_Address":"307, đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.764374
    ,"Long":106.647964
    ,"Polyline":"[106.64517975,10.76581001] ; [106.64584351,10.76558018] ; [106.64633942,10.76539993] ; [106.64646149,10.76531982] ; [106.64736938,10.76480961] ; [106.64801025,10.76445007]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1047"
    ,"Station_Code":"Q11 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"CV Lãnh Binh Thăng"
    ,"Station_Address":"281A (Siêu thị Vinatex), đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.763238
    ,"Long":106.650167
    ,"Polyline":"[106.64801025,10.76445007] ; [106.65006256,10.76334000]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1048"
    ,"Station_Code":"Q11 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Trường TH Phú Thọ"
    ,"Station_Address":"316, đường Tôn Thất Hiệp, Quận 11"
    ,"Lat":10.761051
    ,"Long":106.652656
    ,"Polyline":"[106.65006256,10.76334000] ; [106.65106964,10.76280022] ; [106.65122223,10.76276016] ; [106.65222168,10.76266003] ; [106.65222931,10.76196003] ; [106.65229797,10.76167011] ; [106.65241241,10.76138020] ; [106.65270233,10.76097012]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1015"
    ,"Station_Code":"Q11 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Trạm Trần Quý - Tạ Uyên"
    ,"Station_Address":"193, đường Tạ Uyên, Quận 11"
    ,"Lat":10.758068
    ,"Long":106.653492
    ,"Polyline":"[106.65270233,10.76097012] ; [106.65290070,10.76076984] ; [106.65316772,10.76056004] ; [106.65328217,10.76039982] ; [106.65335083,10.76021957] ; [106.65347290,10.75914001] ; [106.65354919,10.75807953]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1017"
    ,"Station_Code":"Q5 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"79 , đường Tạ Uyên, Quận 5"
    ,"Lat":10.755201
    ,"Long":106.653696
    ,"Polyline":"[106.65354919,10.75807953] ; [106.65368652,10.75687027] ; [106.65370178,10.75631046] ; [106.65370178,10.75566006] ; [106.65374756,10.75520992]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1010"
    ,"Station_Code":"Q5 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"266, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753657
    ,"Long":106.652559
    ,"Polyline":"[106.65374756,10.75520992] ; [106.65380859,10.75405025] ; [106.65377808,10.75376987] ; [106.65257263,10.75360012]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận  5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65257263,10.75360012] ; [106.65178680,10.75351048] ; [106.65180206,10.75333023] ; [106.65180206,10.75300026] ; [106.65180206,10.75242996] ; [106.65180969,10.75181961] ; [106.65180969,10.75142956] ; [106.65186310,10.75115013] ; [106.65193939,10.75100040] ; [106.65258026,10.75104046]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.65107727,10.75096035] ; [106.65048218,10.75100994] ; [106.65058899,10.75197029] ; [106.65072632,10.75337029] ; [106.65086365,10.75333977] ; [106.65180206,10.75333023] ; [106.65232849,10.75339031]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"897"
    ,"Station_Code":"Q5 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"20-22, đường Tạ Uyên, Quận 5"
    ,"Lat":10.754606
    ,"Long":106.65383
    ,"Polyline":"[106.65232849,10.75339031] ; [106.65300751,10.75347042] ; [106.65377808,10.75360012] ; [106.65377808,10.75376987] ; [106.65380859,10.75393963] ; [106.65377045,10.75498962] ; [106.65373230,10.75535011]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"896"
    ,"Station_Code":"Q11 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm Trần Quý - Tạ Uyên"
    ,"Station_Address":"114, đường Tạ Uyên, Quận 11"
    ,"Lat":10.758002
    ,"Long":106.653603
    ,"Polyline":"[106.65373230,10.75535011] ; [106.65370178,10.75566006] ; [106.65370178,10.75631046] ; [106.65368652,10.75687027] ; [106.65355682,10.75800037]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1018"
    ,"Station_Code":"Q11 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"CV Lãnh Binh Thăng"
    ,"Station_Address":"Đối diện Trường mầm non (278 ), đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.762875
    ,"Long":106.651239
    ,"Polyline":"[106.65360260,10.75800228] ; [106.65360260,10.75800228] ; [106.65338135,10.76030827] ; [106.65323639,10.76051903] ; [106.65369415,10.76093578] ; [106.65425110,10.76160431] ; [106.65444946,10.76192570] ; [106.65458679,10.76242161] ; [106.65148163,10.76277447] ; [106.65123749,10.76287460] ; [106.65123749,10.76287460]"
    ,"Distance":"921"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1024"
    ,"Station_Code":"Q11 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà văn h óa Quận 11"
    ,"Station_Address":"284, đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.764453
    ,"Long":106.648193
    ,"Polyline":"[106.65123749,10.76287460] ; [106.64814758,10.76438046] ; [106.64819336,10.76445293]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1027"
    ,"Station_Code":"Q11 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Lãnh Binh Thăng"
    ,"Station_Address":"308-310 , đường Lãnh Binh Thăng, Quận 11"
    ,"Lat":10.76512
    ,"Long":106.646926
    ,"Polyline":"[106.64814758,10.76438046] ; [106.64685822,10.76508999]"
    ,"Distance":"161"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1020"
    ,"Station_Code":"Q11 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Tòa án nhân  dân Q11"
    ,"Station_Address":"150, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.76659
    ,"Long":106.643082
    ,"Polyline":"[106.64685822,10.76508999] ; [106.64633942,10.76539993] ; [106.64530182,10.76576996] ; [106.64428711,10.76611042] ; [106.64305878,10.76653957]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1029"
    ,"Station_Code":"Q11 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"40A, đường Hòa Bình, Quận 11"
    ,"Lat":10.767302
    ,"Long":106.641181
    ,"Polyline":"[106.64305878,10.76653957] ; [106.64250946,10.76673031] ; [106.64251709,10.76681995] ; [106.64248657,10.76690006] ; [106.64238739,10.76694965] ; [106.64227295,10.76692009] ; [106.64222717,10.76686001] ; [106.64209747,10.76690006] ; [106.64140320,10.76710033] ; [106.64115143,10.76718998] ; [106.64109802,10.76721954]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1616"
    ,"Station_Code":"Q11 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Hòa Bình"
    ,"Station_Address":"72, đường Hòa Bình, Quận 11"
    ,"Lat":10.768496
    ,"Long":106.639137
    ,"Polyline":"[106.64108276,10.76723003] ; [106.63979340,10.76797962] ; [106.63909912,10.76842022]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2191"
    ,"Station_Code":"QTP 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã 3 Khuông Việt - Hòa Bình"
    ,"Station_Address":"317, đường Khuông Việt, Quận Tân Phú"
    ,"Lat":10.770105
    ,"Long":106.637932
    ,"Polyline":"[106.63909912,10.76842022] ; [106.63761139,10.76900005] ; [106.63768005,10.76933956] ; [106.63777161,10.76963997] ; [106.63778687,10.76990986] ; [106.63777161,10.77009010]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2192"
    ,"Station_Code":"QTP 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm chùa"
    ,"Station_Address":"249, đường Khuông Việt, Quận Tân Phú"
    ,"Lat":10.772361
    ,"Long":106.63784
    ,"Polyline":"[106.63777161,10.77009010.06.63762665] ; [10.77225971,106.63762665]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2193"
    ,"Station_Code":"QTP 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm cầu số 2"
    ,"Station_Address":"115, đường Khuông Việt, Quận Tân Phú"
    ,"Lat":10.776155
    ,"Long":106.639626
    ,"Polyline":"[106.63762665,10.77235985] ; [106.63760376,10.77336025] ; [106.63760376,10.77338028] ; [106.63765717,10.77338982] ; [106.63780212,10.77348995] ; [106.63789368,10.77357960] ; [106.63822937,10.77398968] ; [106.63849640,10.77439022] ; [106.63913727,10.77567005] ; [106.63945770,10.77624035]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2194"
    ,"Station_Code":"QTP 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Lê Ngã"
    ,"Station_Address":"69, đường Khuông Việt, Quận Tân Phú"
    ,"Lat":10.777757
    ,"Long":106.64164
    ,"Polyline":"[106.63945770,10.77624035] ; [106.63990784,10.77707005] ; [106.64005280,10.77715969] ; [106.64019012,10.77715969] ; [106.64031219,10.77711010.06.64108276] ; [10.77682972,106.64109039] ; [10.77686977,106.64147949]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2197"
    ,"Station_Code":"QTPT169"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm Nhà Hàng Hoàng Long"
    ,"Station_Address":"988, đường Âu Cơ, Quận Tân Phú"
    ,"Lat":10.780560493469238
    ,"Long":106.64271545410156
    ,"Polyline":"[106.64147949,10.77781963] ; [106.64173889,10.77845001] ; [106.64212036,10.77952003] ; [106.64228058,10.78019047] ; [106.64234161,10.78036976] ; [106.64241791,10.78052044] ; [106.64250946,10.78067970]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2199"
    ,"Station_Code":"QTB 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh Viện Tân Phú"
    ,"Station_Address":"584-590, đường  Âu Cơ, Quận Tân Bình"
    ,"Lat":10.78299
    ,"Long":106.642785
    ,"Polyline":"[106.64250946,10.78067970] ; [106.64267731,10.78092003] ; [106.64290619,10.78108978] ; [106.64333344,10.78137016] ; [106.64322662,10.78157043] ; [106.64295959,10.78219986] ; [106.64277649,10.78271008]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2195"
    ,"Station_Code":"QTB 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã tư Thoại Ngọc Hầu"
    ,"Station_Address":"678, đường  Âu Cơ, Quận Tân Bình"
    ,"Lat":10.785272
    ,"Long":106.642052
    ,"Polyline":"[106.64277649,10.78271008] ; [106.64206696,10.78487968] ; [106.64193726,10.78522968]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2196"
    ,"Station_Code":"QTB 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bàu Cát 9"
    ,"Station_Address":"722, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.78729
    ,"Long":106.641182
    ,"Polyline":"[106.64193726,10.78522968] ; [106.64112091,10.78726959]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2198"
    ,"Station_Code":"QTB 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Bàu Cát"
    ,"Station_Address":"205, đường Nguyễn Hồng Đào, Quận Tân Bình"
    ,"Lat":10.791806
    ,"Long":106.641678
    ,"Polyline":"[106.64112091,10.78726959] ; [106.64073181,10.78845024] ; [106.64047241,10.78925037] ; [106.64016724,10.79006004] ; [106.64083862,10.79020977] ; [106.64096069,10.79026031] ; [106.64103699,10.79036045] ; [106.64112854,10.79053020] ; [106.64128113,10.79094028] ; [106.64161682,10.79183006]"
    ,"Distance":"606"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2201"
    ,"Station_Code":"QTB 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Bàu Cát 2"
    ,"Station_Address":"181-185, đư ờng Nguyễn Hồng Đào, Quận Tân Bình"
    ,"Lat":10.793495
    ,"Long":106.642349
    ,"Polyline":"[106.64161682,10.79183006] ; [106.64230347,10.79351997]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2203"
    ,"Station_Code":"QTB 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Nguyễn H ồng Đào"
    ,"Station_Address":"21, đường Nguyễn Hồng Đào, Quận Tân Bình"
    ,"Lat":10.797017
    ,"Long":106.643445
    ,"Polyline":"[106.64230347,10.79351997] ; [106.64266968,10.79440022] ; [106.64282990,10.79500008] ; [106.64340973,10.79697037]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2200"
    ,"Station_Code":"QTB 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã ba Ấp Bắc"
    ,"Station_Address":"366A, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.799642
    ,"Long":106.641036
    ,"Polyline":"[106.64340973,10.79697037] ; [106.64370728,10.79796028] ; [106.64376831,10.79806042] ; [106.64334106,10.79825974] ; [106.64196014,10.79899025] ; [106.64115906,10.79942036] ; [106.64099121,10.79950047]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2205"
    ,"Station_Code":"QTB 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Chợ Võ Thành Trang"
    ,"Station_Address":"510, đường Trường Chinh, Quận  Tân Bình"
    ,"Lat":10.80147
    ,"Long":106.637608
    ,"Polyline":"[106.64099121,10.79950047] ; [106.64040375,10.79981995] ; [106.63889313,10.80064011] ; [106.63755035,10.80136013]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"1302"
    ,"Station_Code":"QTB 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"638, đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.804626
    ,"Long":106.635656
    ,"Polyline":"[106.63755035,10.80136013] ; [106.63688660,10.80173016] ; [106.63672638,10.80177975] ; [106.63642883,10.80220985] ; [106.63610840,10.80288029] ; [106.63596344,10.80331993] ; [106.63553619,10.80459976]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2202"
    ,"Station_Code":"QTB 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.806202
    ,"Long":106.635184
    ,"Polyline":"[106.63553619,10.80459976] ; [106.63504791,10.80618000]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63504791,10.80618000] ; [106.63497925,10.80636978] ; [106.63493347,10.80665970] ; [106.63488007,10.80706978] ; [106.63481903,10.80762005] ; [106.63462067,10.80801010]"
    ,"Distance":"211"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận  Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63462067,10.80801010.06.63450623] ; [10.80827045,106.63417053] ; [10.80928993,106.63343811]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63343811,10.81167984] ; [106.63253784,10.81462002]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63253784,10.81462002] ; [106.63163757,10.81752968]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63163757,10.81752968] ; [106.63038635,10.82162952]"
    ,"Distance":"476"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63038635,10.82162952] ; [106.63025665,10.82201958] ; [106.63004303,10.82254028] ; [106.62976837,10.82297993] ; [106.62959290,10.82320023] ; [106.62840271,10.82431984] ; [106.62654877,10.82602024] ; [106.62595367,10.82662010]"
    ,"Distance":"747"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2207"
    ,"Station_Code":"Q12 186"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Công ty thời trang Sài Gòn"
    ,"Station_Address":"Công  ty thời trang Sài Gòn, đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.827637
    ,"Long":106.623516
    ,"Polyline":"[106.62595367,10.82662010.06.62528229] ; [10.82740974,106.62519836] ; [10.82752037,106.62503052] ; [10.82740974,106.62494659] ; [10.82734966,106.62486267] ; [10.82732964,106.62380219] ; [10.82752991,106.62351227]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2204"
    ,"Station_Code":"Q12 189"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cây xăng Đông Á"
    ,"Station_Address":"250A, đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.832105
    ,"Long":106.610749
    ,"Polyline":"[106.62351227,10.82758999] ; [106.62272644,10.82775974] ; [106.62177277,10.82796955] ; [106.62027740,10.82826996] ; [106.61968994,10.82841015]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2206"
    ,"Station_Code":"Q12 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm Chùa"
    ,"Station_Address":"174 , đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.829418
    ,"Long":106.616049
    ,"Polyline":"[106.61968994,10.82841015] ; [106.61844635,10.82868958] ; [106.61784363,10.82884979] ; [106.61621857,10.82933044] ; [106.61605072,10.82938004]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2208"
    ,"Station_Code":"Q12 187"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Công ty Thu ận Kiều"
    ,"Station_Address":"102, đường Phan Văn Hớn, Quận 12"
    ,"Lat":10.828469
    ,"Long":106.619707
    ,"Polyline":"[106.61605072,10.82938004] ; [106.61560822,10.82954025] ; [106.61522675,10.82973003] ; [106.61332703,10.83069992] ; [106.61158752,10.83158970]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2209"
    ,"Station_Code":"Q12 191"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm Nhà sách"
    ,"Station_Address":"347, đường Phan V ăn Hớn, Quận 12"
    ,"Lat":10.833759
    ,"Long":106.60767
    ,"Polyline":"[106.61158752,10.83158970] ; [106.61016083,10.83232021] ; [106.60870361,10.83329964] ; [106.60812378,10.83372021]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2210"
    ,"Station_Code":"HHM 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã tư Bà Điểm"
    ,"Station_Address":"41/2, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.834662
    ,"Long":106.606819
    ,"Polyline":"[106.60812378,10.83372021] ; [106.60714722,10.83435726] ; [106.60675812,10.83458996]"
    ,"Distance":"177"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2212"
    ,"Station_Code":"HHM 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm trại hòm"
    ,"Station_Address":"18/3E, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.837268
    ,"Long":106.603003
    ,"Polyline":"[106.60675812,10.83458996] ; [106.60475922,10.83581352] ; [106.60291290,10.83716965]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2211"
    ,"Station_Code":"HHM 179"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Bà Điểm"
    ,"Station_Address":"Chợ Bà Điểm, đường  Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.839987
    ,"Long":106.599693
    ,"Polyline":"[106.60291290,10.83716965] ; [106.60111237,10.83872223] ; [106.59963226,10.83992004]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2213"
    ,"Station_Code":"HHM 180"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Nguyễn Ảnh Thủ"
    ,"Station_Address":"123/4, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.841283
    ,"Long":106.598
    ,"Polyline":"[106.59963226,10.83992004] ; [106.59877777,10.84059811] ; [106.59790802,10.84115028]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2215"
    ,"Station_Code":"HHM 181"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm Bô Rác"
    ,"Station_Address":"108/5, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.845087
    ,"Long":106.593947
    ,"Polyline":"[106.59790802,10.84115028] ; [106.59669495,10.84213638] ; [106.59571838,10.84325981]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2217"
    ,"Station_Code":"HHM 183"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm nhà sách cũ"
    ,"Station_Address":"26/4, đường  Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.852905
    ,"Long":106.58427
    ,"Polyline":"[106.59571838,10.84325981] ; [106.59431458,10.84458065] ; [106.59304047,10.84560966]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2214"
    ,"Station_Code":"HHM 184"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Đại Hải"
    ,"Station_Address":"118, đường Phan V ăn Hớn, Huyện Hóc Môn"
    ,"Lat":10.86222
    ,"Long":106.57279
    ,"Polyline":"[106.59304047,10.84560966] ; [106.59098816,10.84725761] ; [106.58931732,10.84852028]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2216"
    ,"Station_Code":"QHMT175"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Nhà máy nước đá"
    ,"Station_Address":"106, đường Phan  Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.851988792419434
    ,"Long":106.5855712890625
    ,"Polyline":"[106.58931732,10.84852028] ; [106.58757782,10.84989166] ; [106.58538818,10.85179043]"
    ,"Distance":"563"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2219"
    ,"Station_Code":"QHMT176"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Trạm Ấp  2"
    ,"Station_Address":"Trường Tiểu học Xuân Thới Thượng, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.854317665100098
    ,"Long":106.58281707763672
    ,"Polyline":"[106.58538818,10.85179043] ; [106.58377838,10.85319996] ; [106.58264160,10.85410976]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2218"
    ,"Station_Code":"QHMT177"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trạm trường học lầu"
    ,"Station_Address":"79/6, đường Phan Văn Hớn, Huyện Hóc M ôn"
    ,"Lat":10.860307693481445
    ,"Long":106.57579803466797
    ,"Polyline":"[106.58264160,10.85410976] ; [106.57982635,10.85650921] ; [106.57553864,10.86001968]"
    ,"Distance":"1017"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2221"
    ,"Station_Code":"QHMT178"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Trạm y tế"
    ,"Station_Address":"68 , đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.863763809204102
    ,"Long":106.56792449951172
    ,"Polyline":"[106.57553864,10.86001968] ; [106.57422638,10.86129284] ; [106.57281494,10.86215687] ; [106.56784058,10.86359024]"
    ,"Distance":"950"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2220"
    ,"Station_Code":"HHM 190"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Ngã 3 Giồng"
    ,"Station_Address":"135/4A, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.866392
    ,"Long":106.562319
    ,"Polyline":"[106.56784058,10.86359024] ; [106.56669617,10.86432743] ; [106.56285858,10.86604023]"
    ,"Distance":"610"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2222"
    ,"Station_Code":"HHM 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Trường PTTH Nguyễn Văn Cừ"
    ,"Station_Address":"Đối diện trường Nguyễn Văn Cừ, đường Nguyễn V ăn Bứa, Huyện Hóc Môn"
    ,"Lat":10.868774
    ,"Long":106.555538
    ,"Polyline":"[106.56285858,10.86604023] ; [106.56124878,10.86689758] ; [106.55815887,10.86828899] ; [106.55684662,10.86845016]"
    ,"Distance":"716"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2223"
    ,"Station_Code":"HHM 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Nguyễn Văn Bứa"
    ,"Station_Address":"Đối diện 46B, đường Nguyễn Văn Bứa, Huyện  Hóc Môn"
    ,"Lat":10.869279
    ,"Long":106.550281
    ,"Polyline":"[106.55684662,10.86845016] ; [106.55422211,10.86888981] ; [106.55251312,10.86917973] ; [106.55151367,10.86931992] ; [106.55110931,10.86938000] ; [106.55030823,10.86948967]"
    ,"Distance":"724"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2225"
    ,"Station_Code":"HHM 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Trạm lò muối"
    ,"Station_Address":"23 - 25, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.870512
    ,"Long":106.542031
    ,"Polyline":"[106.55030823,10.86948967] ; [106.54853821,10.86973953] ; [106.54528809,10.87016964] ; [106.54387665,10.87036991]"
    ,"Distance":"709"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2224"
    ,"Station_Code":"HHM 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Trường ti ểu học Nhị Xuân"
    ,"Station_Address":"89/5, đường Nguyễn Văn Bứa, Huyện Hóc  Môn"
    ,"Lat":10.871176
    ,"Long":106.564947
    ,"Polyline":"[106.54387665,10.87036991] ; [106.54145813,10.87071037] ; [106.53975677,10.87096977] ; [106.53843689,10.87121964] ; [106.53800964,10.87131023]"
    ,"Distance":"650"
  },
  {
     "Route_Id":"44"
    ,"Station_Id":"2227"
    ,"Station_Code":"BX 39"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Cầu Lớn"
    ,"Station_Address":"BÃI XE CẦU LỚN, đường Nguyễn Văn Bứa,  Huyện Hóc Môn"
    ,"Lat":10.871845
    ,"Long":106.535561
    ,"Polyline":"[106.53800964,10.87131023] ; [106.53629303,10.87162971] ; [106.53485870,10.87189960]"
    ,"Distance":"350"
  }]