export const Route124 =[

  {
     "Route_Id":"124"
    ,"Station_Id":"3933"
    ,"Station_Code":"BX 88"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Tân Túc"
    ,"Station_Address":"Điểm Đầu - Cuối Tân Túc, đường Nguyễn Hữu  Trí, Huyện Bình Chánh"
    ,"Lat":10.684146
    ,"Long":106.549755
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3935"
    ,"Station_Code":"HBC 403"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"Đối diện công ty Đồng Tâm, đường Nguy ễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.685226
    ,"Long":106.553484
    ,"Polyline":"[106.54390717,10.68304443] ; [106.55441284,10.68528938]"
    ,"Distance":"1173.86795878516"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3934"
    ,"Station_Code":"HBC 402"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Tân Liên Hương"
    ,"Station_Address":"Đối diện công ty Liên Hương, đường Nguy ễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.68637
    ,"Long":106.557823
    ,"Polyline":"[106.55441284,10.68528938] ; [106.55817413,10.68634415]"
    ,"Distance":"427.068638337076"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3936"
    ,"Station_Code":"HBC 401"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Phước Hưng"
    ,"Station_Address":"Đối diện điện lực Bình Chánh, đường Nguyễn  Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.68812
    ,"Long":106.562882
    ,"Polyline":"[106.55817413,10.68634415] ; [106.56167603,10.68740845]"
    ,"Distance":"400.219694518924"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3948"
    ,"Station_Code":"HBC 400"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Điện lực Bình Chánh"
    ,"Station_Address":"B4/9B, đường Nguyễn Hữu Trí, Huyện B ình Chánh"
    ,"Lat":10.689765
    ,"Long":106.567619
    ,"Polyline":"[106.56167603,10.68740845] ; [106.56449890,10.68842125]"
    ,"Distance":"328.112770738327"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3937"
    ,"Station_Code":"HBC 399"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ủy ban nhân dân xã Tân Túc"
    ,"Station_Address":"B2/20, đường Nguyễn Hữu Trí, Huyện B ình Chánh"
    ,"Lat":10.690192
    ,"Long":106.569228
    ,"Polyline":"[106.56449890,10.68842125] ; [106.56755066,10.68961239]"
    ,"Distance":"358.522721539079"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3938"
    ,"Station_Code":"HBC 398"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Công ty Phú Hữu"
    ,"Station_Address":"Công ty Phú Hữu, đường Nguyễn Hữu Tr í, Huyện Bình Chánh"
    ,"Lat":10.691125
    ,"Long":106.571926
    ,"Polyline":"[106.56755066,10.68961239] ; [106.57196808,10.69102478]"
    ,"Distance":"507.194274353894"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2241"
    ,"Station_Code":"HBC 397"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Thiên Giang"
    ,"Station_Address":"14/2, đường Nguyễn Hữu Trí, Huyện Bình Ch ánh"
    ,"Lat":10.692506
    ,"Long":106.578412
    ,"Polyline":"[106.57196808,10.69102478] ; [106.57848358,10.69229031]"
    ,"Distance":"725.140175102465"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2243"
    ,"Station_Code":"HBC 396"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trung tâm TDTT Bình Chánh"
    ,"Station_Address":"Trung tâm TDTT Bình Chánh, đường Nguy ễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.695274
    ,"Long":106.588202
    ,"Polyline":"[106.57848358,10.69229031] ; [106.58458710,10.69391346]"
    ,"Distance":"690.364872759067"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2242"
    ,"Station_Code":"HBC 395"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh viện huyện Bình Chánh"
    ,"Station_Address":"Đd BV huyện Bình Chánh, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.69618
    ,"Long":106.59303
    ,"Polyline":"[106.58820343,10.69527435] ; [106.58996582,10.69579029] ; [106.59303284,10.69618034]"
    ,"Distance":"539"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2245"
    ,"Station_Code":"HBC 394"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chùa Tam Bửu"
    ,"Station_Address":"E9/21A,  đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.696591
    ,"Long":106.596099
    ,"Polyline":"[106.59303284,10.69618034] ; [106.59609985,10.69659138]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"705"
    ,"Station_Code":"HBC 390"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Dương  Đình Cúc"
    ,"Station_Address":"C14/17, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.70658
    ,"Long":106.598266
    ,"Polyline":"[106.59609985,10.69659138] ; [106.59696960,10.69700241] ; [106.59722900,10.69769859] ; [106.59754944,10.69991207] ; [106.59746552,10.70415020] ; [106.59812927,10.70594215] ; [106.59826660,10.70658016]"
    ,"Distance":"1194"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"707"
    ,"Station_Code":"HBC 391"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cầu đi  bộ Số 2"
    ,"Station_Address":"C12/3, đường Qu ốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.713538
    ,"Long":106.599564
    ,"Polyline":"[106.59826660,10.70658016] ; [106.59956360,10.71353817]"
    ,"Distance":"787"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"706"
    ,"Station_Code":"HBC 392"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã tư An Lạc"
    ,"Station_Address":"591 cầu đi bộ, đường Quốc lộ 1A, Huy ện Bình Chánh"
    ,"Lat":10.71359
    ,"Long":106.599564
    ,"Polyline":"[106.59956360,10.71353817] ; [106.59956360,10.71358967]"
    ,"Distance":"6"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"711"
    ,"Station_Code":"HBC 393"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trần Đại Nghĩa"
    ,"Station_Address":"591B (cầu bộ hành), đường Quốc lộ 1A , Huyện Bình Chánh"
    ,"Lat":10.721333
    ,"Long":106.600948
    ,"Polyline":"[106.59955597,10.71359062] ; [106.60090637,10.72177696]"
    ,"Distance":"921.463361112066"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"708"
    ,"Station_Code":"QBT 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"849, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.724317
    ,"Long":106.602337
    ,"Polyline":"[106.60094452,10.72133255] ; [106.60090637,10.72177696] ; [106.60108948,10.72250366] ; [106.60224152,10.72438335] ; [106.60234070,10.72431660]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"712"
    ,"Station_Code":"QBT 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu An Lạc"
    ,"Station_Address":"771, đường Kinh Dương Vương, Quận Bình  Tân"
    ,"Lat":10.726583
    ,"Long":106.605191
    ,"Polyline":"[106.60234070,10.72431660] ; [106.60281372,10.72495461] ; [106.60347748,10.72551823] ; [106.60519409,10.72658253]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"709"
    ,"Station_Code":"QBT 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"703, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72832
    ,"Long":106.607605
    ,"Polyline":"[106.60515594,10.72671127] ; [106.60760498,10.72832012]"
    ,"Distance":"321.615300074354"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"714"
    ,"Station_Code":"QBT 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ủy ban"
    ,"Station_Address":"631-637, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.729977
    ,"Long":106.610255
    ,"Polyline":"[106.60760498,10.72832012] ; [106.61019135,10.73007774]"
    ,"Distance":"343.307484556524"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"710"
    ,"Station_Code":"QBT 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Lâm Thành"
    ,"Station_Address":"289(561), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.734278
    ,"Long":106.61298
    ,"Polyline":"[106.61019135,10.73007774] ; [106.61285400,10.73427963]"
    ,"Distance":"549.969143980813"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"716"
    ,"Station_Code":"QBT 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"251(511), đường  Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.737541
    ,"Long":106.614906
    ,"Polyline":"[106.61285400,10.73427963] ; [106.61484528,10.73754978]"
    ,"Distance":"423.411100722669"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"713"
    ,"Station_Code":"QBT 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bệnh viện  Triều An"
    ,"Station_Address":"Bệnh viện Triều An, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739665
    ,"Long":106.61687
    ,"Polyline":"[106.61490631,10.73754120] ; [106.61484528,10.73754978] ; [106.61566162,10.73866844] ; [106.61686707,10.73966503]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"119"
    ,"Station_Code":"QBT 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.741035
    ,"Long":106.618468
    ,"Polyline":"[106.61686707,10.73966503] ; [106.61846924,10.74103546]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"718"
    ,"Station_Code":"Q6 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cư xá Phú Lâm"
    ,"Station_Address":"799 (209), đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.74776
    ,"Long":106.626332
    ,"Polyline":"[106.62307739,10.74498463] ; [106.62639618,10.74768829]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"715"
    ,"Station_Code":"Q6 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"685 (157), đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.748877
    ,"Long":106.627727
    ,"Polyline":"[106.62633514,10.74775982] ; [106.62772369,10.74887657]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"720"
    ,"Station_Code":"Q6 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"93, đường Kinh  Dương Vương, Quận 6"
    ,"Lat":10.751201
    ,"Long":106.630753
    ,"Polyline":"[106.62772369,10.74887657] ; [106.63075256,10.75120068]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"717"
    ,"Station_Code":"Q6 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"21A-21B, đư ờng Kinh Dương Vương, Quận 6"
    ,"Lat":10.753246
    ,"Long":106.633521
    ,"Polyline":"[106.63075256,10.75120068] ; [106.63246155,10.75256634] ; [106.63352203,10.75324631]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"724"
    ,"Station_Code":"Q6 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Ông Buông"
    ,"Station_Address":"963, đường Hồng B àng, Quận 6"
    ,"Lat":10.754548
    ,"Long":106.637995
    ,"Polyline":"[106.63352203,10.75324631] ; [106.63339996,10.75314999] ; [106.63414764,10.75370502] ; [106.63448334,10.75363064] ; [106.63473511,10.75371552] ; [106.63488007,10.75395775] ; [106.63530731,10.75426292] ; [106.63556671,10.75432682] ; [106.63659668,10.75435829] ; [106.63817596,10.75458622] ; [106.63799286,10.75454807]"
    ,"Distance":"612"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"719"
    ,"Station_Code":"Q6 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngân hàng ACB"
    ,"Station_Address":"871, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754295
    ,"Long":106.641245
    ,"Polyline":"[106.63799286,10.75454807] ; [106.63817596,10.75458622] ; [106.63969421,10.75449562] ; [106.64122772,10.75428200] ; [106.64124298,10.75429535]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"721"
    ,"Station_Code":"Q6 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường Nguyễn Đức Cảnh"
    ,"Station_Address":"799, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754021
    ,"Long":106.644003
    ,"Polyline":"[106.64124298,10.75429535] ; [106.64400482,10.75402069]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"723"
    ,"Station_Code":"Q6 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chùa Nam Ph ổ Đà"
    ,"Station_Address":"735, đường Hồng Bàng , Quận 6"
    ,"Lat":10.753789
    ,"Long":106.645955
    ,"Polyline":"[106.64400482,10.75402069] ; [106.64595795,10.75378895]"
    ,"Distance":"215"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"722"
    ,"Station_Code":"Q6 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"647, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753647
    ,"Long":106.647323
    ,"Polyline":"[106.64595795,10.75378895] ; [106.64732361,10.75364685]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ L ỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.64732361,10.75364685] ; [106.65083313,10.75331497] ; [106.65177917,10.75297737] ; [106.65177155,10.75153828] ; [106.65106964,10.75118542]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"621"
    ,"Station_Code":"Q6 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường Võ Văn Tần"
    ,"Station_Address":"96-98, đường Phạm Đình Hổ, Quận 6"
    ,"Lat":10.752271
    ,"Long":106.64975
    ,"Polyline":"[106.65106964,10.75118542] ; [106.65106964,10.75100613] ; [106.64960480,10.75115967] ; [106.64974976,10.75227070] ; [106.64974976,10.75227070]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"622"
    ,"Station_Code":"Q11 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"508, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753952
    ,"Long":106.646787
    ,"Polyline":"[106.64974976,10.75227070] ; [106.64974976,10.75227070] ; [106.64984131,10.75362587] ; [106.64683533,10.75390339] ; [106.64678955,10.75395203]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"624"
    ,"Station_Code":"Q11 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"638-640, đường Hồng Bàng, Quận 11"
    ,"Lat":10.754232
    ,"Long":106.644368
    ,"Polyline":"[106.64683533,10.75390339] ; [106.64438629,10.75417805]"
    ,"Distance":"269.071863613741"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"625"
    ,"Station_Code":"Q11 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Huê Lâm"
    ,"Station_Address":"690 (138 ), đường Hồng Bàng, Quận 11"
    ,"Lat":10.754558
    ,"Long":106.641229
    ,"Polyline":"[106.64438629,10.75417805] ; [106.64126587,10.75450230]"
    ,"Distance":"342.523628951268"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"623"
    ,"Station_Code":"Q11 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"786, đường Hồng Bàng, Quận 11"
    ,"Lat":10.75477
    ,"Long":106.638428
    ,"Polyline":"[106.64126587,10.75450230] ; [106.63842773,10.75477028]"
    ,"Distance":"311.236538829883"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"626"
    ,"Station_Code":"Q6 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Mạc Đỉnh Chi"
    ,"Station_Address":"832-834, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754732
    ,"Long":106.635574
    ,"Polyline":"[106.63842773,10.75477028] ; [106.63842773,10.75477028] ; [106.63707733,10.75482750] ; [106.63634491,10.75486374] ; [106.63596344,10.75483227] ; [106.63557434,10.75473213] ; [106.63557434,10.75473213]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"627"
    ,"Station_Code":"Q6 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"528, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.753346
    ,"Long":106.633365
    ,"Polyline":"[106.63557434,10.75473213] ; [106.63468170,10.75424767] ; [106.63446045,10.75431061] ; [106.63421631,10.75421047] ; [106.63413239,10.75406837] ; [106.63414001,10.75387383] ; [106.63336182,10.75334644]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"628"
    ,"Station_Code":"Q6 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cư Xá Phú Lâm"
    ,"Station_Address":"580, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.751475
    ,"Long":106.63089
    ,"Polyline":"[106.63312531,10.75319958] ; [106.63088989,10.75146103]"
    ,"Distance":"311.223773779558"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"629"
    ,"Station_Code":"Q6 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Hồ Bơi Ph ú Lâm"
    ,"Station_Address":"94-96, đường Kinh  Dương Vương, Quận 6"
    ,"Lat":10.749589
    ,"Long":106.628435
    ,"Polyline":"[106.63088989,10.75146103] ; [106.62843323,10.74956036]"
    ,"Distance":"341.343666461399"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"1386"
    ,"Station_Code":"Q6 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Công Viên Phú Lâm"
    ,"Station_Address":"Đối diện 907, đường Kinh Dương Vương , Quận 6"
    ,"Lat":10.746384
    ,"Long":106.624525
    ,"Polyline":"[106.62843323,10.74956036] ; [106.62452698,10.74639320]"
    ,"Distance":"552.870547962867"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62452698,10.74639320] ; [106.62247467,10.74474621]"
    ,"Distance":"289.275990973751"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62039948,10.74309158]"
    ,"Distance":"291.749729268892"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"631"
    ,"Station_Code":"QBT 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Hàng Dương"
    ,"Station_Address":"548, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.735138
    ,"Long":106.613144
    ,"Polyline":"[106.61643219,10.73968792] ; [106.61314392,10.73513794]"
    ,"Distance":"620.032727786722"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"632"
    ,"Station_Code":"QBT 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"SinCo"
    ,"Station_Address":"Đối diện nhà tr ọ Thanh Trường, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.731674
    ,"Long":106.611028
    ,"Polyline":"[106.61314392,10.73513794] ; [106.61107635,10.73165607]"
    ,"Distance":"447.902214586418"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"633"
    ,"Station_Code":"QBT 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Hoa hồng"
    ,"Station_Address":"620, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.729014
    ,"Long":106.608276
    ,"Polyline":"[106.61107635,10.73165607] ; [106.60827637,10.72901440]"
    ,"Distance":"423.777824855675"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"634"
    ,"Station_Code":"QBT 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"An Lạc"
    ,"Station_Address":"676, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.72733
    ,"Long":106.605751
    ,"Polyline":"[106.60827637,10.72901440] ; [106.60575104,10.72733021]"
    ,"Distance":"333.199636394376"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"635"
    ,"Station_Code":"QBT 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Thời trang"
    ,"Station_Address":"724, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.725466
    ,"Long":106.603027
    ,"Polyline":"[106.60575104,10.72733021] ; [106.60302734,10.72546577]"
    ,"Distance":"362.392983424642"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"636"
    ,"Station_Code":"HBC 362"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Bãi xe Phương Trang"
    ,"Station_Address":"Bãi xe Phương Trang, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.721333
    ,"Long":106.600379
    ,"Polyline":"[106.60302734,10.72546577] ; [106.60302734,10.72546577] ; [106.60179138,10.72411633] ; [106.60139465,10.72406387] ; [106.60102081,10.72385311] ; [106.60039520,10.72099400] ; [106.60037994,10.72133255]"
    ,"Distance":"657"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"637"
    ,"Station_Code":"HBC 363"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Hưng Nhơn"
    ,"Station_Address":"B1/5, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.71328
    ,"Long":106.598904
    ,"Polyline":"[106.60039520,10.72099400] ; [106.59980011,10.71948814]"
    ,"Distance":"179.487297814817"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"638"
    ,"Station_Code":"HBC 364"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C3/4, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.70706
    ,"Long":106.598089
    ,"Polyline":"[106.59980011,10.71948814] ; [106.59834290,10.70945263]"
    ,"Distance":"1126.348930117"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2155"
    ,"Station_Code":"HBC 414"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Chùa Tam Bửu"
    ,"Station_Address":"D/d 9/16, đường Nguyễn Hữu Trí, Huyện  Bình Chánh"
    ,"Lat":10.696713
    ,"Long":106.596297
    ,"Polyline":"[106.59809113,10.70705986] ; [106.59783173,10.70583725] ; [106.59735870,10.70497227] ; [106.59714508,10.70436096] ; [106.59707642,10.70393944] ; [106.59719086,10.69978523] ; [106.59690857,10.69774055] ; [106.59629822,10.69671345]"
    ,"Distance":"1192"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2152"
    ,"Station_Code":"HBC 413"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bệnh viện Bình Chánh"
    ,"Station_Address":"Bệnh viện Bình Chánh, đường Nguyễn H ữu Trí, Huyện Bình Chánh"
    ,"Lat":10.696259
    ,"Long":106.592746
    ,"Polyline":"[106.59629822,10.69671345] ; [106.59274292,10.69625854]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2154"
    ,"Station_Code":"HBC 412"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trung tâm văn hóa huyện Bình  Chánh"
    ,"Station_Address":"Đối diện Trung tâm văn hóa huyện Bình Chánh, đường Nguyễn Hữu Trí,  Huyện Bình Chánh"
    ,"Lat":10.695411
    ,"Long":106.588261
    ,"Polyline":"[106.59274292,10.69625854] ; [106.59049988,10.69601154] ; [106.58976746,10.69588470] ; [106.58826447,10.69541073]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2157"
    ,"Station_Code":"HBC 411"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Công ty Vĩnh Tiến"
    ,"Station_Address":"Công ty Vĩnh Tiến, đường Nguyễn Hữu Tr í, Huyện Bình Chánh"
    ,"Lat":10.693961
    ,"Long":106.583487
    ,"Polyline":"[106.58826447,10.69541073] ; [106.58348846,10.69396114]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"2156"
    ,"Station_Code":"HBC 410"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Thiên Giang"
    ,"Station_Address":"A14/7, đường Nguy ễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.692385
    ,"Long":106.577436
    ,"Polyline":"[106.58348846,10.69396114] ; [106.58110809,10.69318581] ; [106.57743835,10.69238472]"
    ,"Distance":"686"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3962"
    ,"Station_Code":"HBC 409"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Công ty Phú Hữu"
    ,"Station_Address":"A12/23, đường Nguyễn Hữu Trí, Huyện B ình Chánh"
    ,"Lat":10.691014
    ,"Long":106.570945
    ,"Polyline":"[106.57743835,10.69238472] ; [106.57094574,10.69101429]"
    ,"Distance":"726"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3946"
    ,"Station_Code":"HBC 408"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ủy ban nhân dân xã Tân Túc"
    ,"Station_Address":"Ủy ban nhân dân xã Tân Túc, đường Nguy ễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.690487
    ,"Long":106.569035
    ,"Polyline":"[106.57094574,10.69101429] ; [106.56903839,10.69048691]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3969"
    ,"Station_Code":"HBC 407"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Điện lực Bình Chánh"
    ,"Station_Address":"B4/9 - B4/10, đường Nguyễn Hữu Trí, Huy ện Bình Chánh"
    ,"Lat":10.689955
    ,"Long":106.567656
    ,"Polyline":"[106.56903839,10.69048691] ; [106.56765747,10.68995476]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3942"
    ,"Station_Code":"HBC 406"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Điện lực Bình Chánh"
    ,"Station_Address":"Điện lực Bình Chánh, đường Nguyễn Hữu  Trí, Huyện Bình Chánh"
    ,"Lat":10.688284
    ,"Long":106.562973
    ,"Polyline":"[106.56765747,10.68995476] ; [106.56297302,10.68828392]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3959"
    ,"Station_Code":"HBC 405"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Tân Liên Hương"
    ,"Station_Address":"Công ty Liên Hương, đường Nguyễn Hữu  Trí, Huyện Bình Chánh"
    ,"Lat":10.686418
    ,"Long":106.557448
    ,"Polyline":"[106.56297302,10.68828392] ; [106.55744934,10.68641758]"
    ,"Distance":"639"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3947"
    ,"Station_Code":"HBC 404"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"Công ty Đồng Tâm, đường Nguyễn Hữu Tr í, Huyện Bình Chánh"
    ,"Lat":10.685363
    ,"Long":106.553543
    ,"Polyline":"[106.55744934,10.68641758] ; [106.55354309,10.68536282]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"124"
    ,"Station_Id":"3933"
    ,"Station_Code":"BX 88"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Tân Túc"
    ,"Station_Address":"Điểm Đầu - Cuối Tân Túc,  đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.684146
    ,"Long":106.549755
    ,"Polyline":"[106.55354309,10.68536282] ; [106.54969788,10.68434048] ; [106.54975128,10.68414593]"
    ,"Distance":"459"
  }]