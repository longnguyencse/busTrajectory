export const Route37 =[
  {
     "Route_Id":"37"
    ,"Station_Id":"1945"
    ,"Station_Code":"BX 50"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Sân bay Tân Sơn Nhất"
    ,"Station_Address":"Sân bay Tân Sơn Nhất, đường Trư ờng Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.813708
    ,"Long":106.663727
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"995"
    ,"Station_Code":"QTB 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường Ngô Sỹ Liên"
    ,"Station_Address":"53, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.810257
    ,"Long":106.664673
    ,"Polyline":"[106.66372681,10.81370831] ; [106.66371155,10.81371021] ; [106.66387177,10.81552887] ; [106.66329193,10.81532288] ; [106.66286469,10.81509113] ; [106.66271973,10.81494904] ; [106.66267395,10.81465340] ; [106.66262817,10.81432724] ; [106.66249084,10.81283569] ; [106.66257477,10.81268311] ; [106.66271973,10.81262016] ; [106.66387939,10.81254005] ; [106.66425323,10.81250000] ; [106.66442108,10.81247997] ; [106.66462708,10.81233025] ; [106.66474152,10.81219959] ; [106.66481781,10.81204987] ; [106.66488647,10.81180000] ; [106.66487885,10.81167030] ; [106.66474915,10.81025028] ; [106.66467285,10.81025696]"
    ,"Distance":"1085"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"997"
    ,"Station_Code":"QTB 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Siêu thị Super Bow"
    ,"Station_Address":"Siêu thị super Bow, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.808049
    ,"Long":106.66449
    ,"Polyline":"[106.66474915,10.81025028] ; [106.66455078,10.80803967]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"999"
    ,"Station_Code":"QTB 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trần Quốc Hoàn"
    ,"Station_Address":"71, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.803644
    ,"Long":106.663925
    ,"Polyline":"[106.66455078,10.80803967] ; [106.66443634,10.80683041] ; [106.66429901,10.80500031] ; [106.66426086,10.80459023] ; [106.66416168,10.80416965] ; [106.66398621,10.80362034]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Tr ần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66398621,10.80362034] ; [106.66381073,10.80311012] ; [106.66355896,10.80266953] ; [106.66342163,10.80245972] ; [106.66262817,10.80158997] ; [106.66233826,10.80132008]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.66233826,10.80132008] ; [106.66220093,10.80121994] ; [106.66209412,10.80111980] ; [106.66199493,10.80103493] ; [106.66190338,10.80095673] ; [106.66178894,10.80087376] ; [106.66165161,10.80079842] ; [106.66154480,10.80075741] ; [106.66130829,10.80077076] ; [106.66117859,10.80078030] ; [106.66108704,10.80076027] ; [106.66101837,10.80072594] ; [106.66100311,10.80067348] ; [106.66099548,10.80060959] ; [106.66093445,10.80055428] ; [106.66089630,10.80049515] ; [106.66085052,10.80042267] ; [106.66085815,10.80035782] ; [106.66086578,10.80031395] ; [106.66092682,10.80024529] ; [106.66102600,10.80022430] ; [106.66112518,10.80027962] ; [106.66120148,10.80037498] ; [106.66128540,10.80041790] ; [106.66144562,10.80052853] ; [106.66159821,10.80060959] ; [106.66179657,10.80064583] ; [106.66326141,10.80056953]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trạm Bảo  Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80056953] ; [106.66545868,10.80035973] ; [106.66635895,10.80029964]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"188"
    ,"Station_Code":"QPN 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cây xăng Quân khu 7"
    ,"Station_Address":"307 , đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.799605
    ,"Long":106.668416
    ,"Polyline":"[106.66635895,10.80029964] ; [106.66683197,10.80027008] ; [106.66735077,10.80018044] ; [106.66767883,10.80008984] ; [106.66809845,10.79990959] ; [106.66825104,10.79981995]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"190"
    ,"Station_Code":"QPN 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã Ba Nguy ễn Trọng Tuyển"
    ,"Station_Address":"279, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.798105
    ,"Long":106.671089
    ,"Polyline":"[106.66841888,10.79960537] ; [106.67111206,10.79813957] ; [106.67108917,10.79810524]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"191"
    ,"Station_Code":"QPN 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Cổng Xe lửa"
    ,"Station_Address":"253, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.796395
    ,"Long":106.673965
    ,"Polyline":"[106.67111206,10.79813957] ; [106.67204285,10.79757977] ; [106.67288208,10.79710960] ; [106.67398834,10.79644966]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"189"
    ,"Station_Code":"QPN 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trung tâm Văn hóa Quận Phú Nhuận"
    ,"Station_Address":"157, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.795297
    ,"Long":106.675804
    ,"Polyline":"[106.67398834,10.79644966] ; [106.67584229,10.79535007]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"193"
    ,"Station_Code":"QPN 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trần Huy Liệu"
    ,"Station_Address":"101, đường Nguyễn Văn Trỗi, Quận Phú Nhu ận"
    ,"Lat":10.793276
    ,"Long":106.679167
    ,"Polyline":"[106.67584229,10.79535007] ; [106.67761230,10.79430008] ; [106.67823029,10.79395008] ; [106.67922211,10.79337025]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"192"
    ,"Station_Code":"Q3 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Chùa Vĩnh Nghiêm"
    ,"Station_Address":"321-323, đường Nam Kỳ Khởi  Nghĩa, Quận 3"
    ,"Lat":10.790381
    ,"Long":106.683022
    ,"Polyline":"[106.67922211,10.79337025] ; [106.68000031,10.79288960] ; [106.68122864,10.79214001] ; [106.68164063,10.79178047] ; [106.68212891,10.79131031] ; [106.68279266,10.79071045] ; [106.68308258,10.79043961]"
    ,"Distance":"536"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"196"
    ,"Station_Code":"Q3 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trần Quốc Toản"
    ,"Station_Address":"201 A, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.786831
    ,"Long":106.686897
    ,"Polyline":"[106.68308258,10.79043961] ; [106.68473053,10.78894043] ; [106.68521881,10.78849983] ; [106.68544769,10.78826046] ; [106.68639374,10.78740978] ; [106.68672180,10.78709984]"
    ,"Distance":"544"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"194"
    ,"Station_Code":"Q3 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Viện Paster"
    ,"Station_Address":"179, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.785213
    ,"Long":106.688637
    ,"Polyline":"[106.68672180,10.78709984] ; [106.68869019,10.78526974]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"198"
    ,"Station_Code":"Q3 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"159 Ter, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.782798
    ,"Long":106.691376
    ,"Polyline":"[106.68869019,10.78526974] ; [106.68905640,10.78493023] ; [106.68994904,10.78413963] ; [106.69058228,10.78353977] ; [106.69077301,10.78339005] ; [106.69142914,10.78285027]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1880"
    ,"Station_Code":"Q3 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Coop Mart Nguyễn Đình Chiểu"
    ,"Station_Address":"170, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.780828
    ,"Long":106.6922
    ,"Polyline":"[106.69142914,10.78285027] ; [106.69290161,10.78145027] ; [106.69225311,10.78077984]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1883"
    ,"Station_Code":"Q3 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trương Định"
    ,"Station_Address":"216 , đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.77824
    ,"Long":106.689789
    ,"Polyline":"[106.69225311,10.78077984] ; [106.69178009,10.78030968] ; [106.69069672,10.77910042] ; [106.69016266,10.77849007] ; [106.68984985,10.77818012]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"2477"
    ,"Station_Code":"Q3 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Nguyễn Thi ̣ Diệu"
    ,"Station_Address":"179D, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.77469
    ,"Long":106.687202
    ,"Polyline":"[106.68984985,10.77818012] ; [106.68846893,10.77674961] ; [106.68682098,10.77501011] ; [106.68704987,10.77488041] ; [106.68727112,10.77478027]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1396"
    ,"Station_Code":"Q1 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"85 , đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.772392
    ,"Long":106.691371
    ,"Polyline":"[106.68727112,10.77478027] ; [106.68858337,10.77406979] ; [106.68985748,10.77340031] ; [106.69113922,10.77270985] ; [106.69139862,10.77256012]"
    ,"Distance":"544"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Khách sạn  New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai , Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69134521,10.77245617] ; [106.69139862,10.77256012] ; [106.69281769,10.77180004] ; [106.69308472,10.77161217] ; [106.69312286,10.77143860] ; [106.69308472,10.77130699] ; [106.69321442,10.77119064] ; [106.69337463,10.77119064] ; [106.69346619,10.77126980] ; [106.69364929,10.77128029] ; [106.69516754,10.77120972] ; [106.69673157,10.77118969] ; [106.69673920,10.77118874]"
    ,"Distance":"688"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"118"
    ,"Station_Code":"Q1TC1B"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bến Thành B"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77084
    ,"Long":106.698532
    ,"Polyline":"[106.69673157,10.77118969] ; [106.69795227,10.77165985] ; [106.69806671,10.77159023] ; [106.69803619,10.77147007] ; [106.69805908,10.77134037] ; [106.69811249,10.77126026] ; [106.69819641,10.77120018] ; [106.69828796,10.77116966] ; [106.69841003,10.77116966] ; [106.69854736,10.77122021] ; [106.69860077,10.77124977] ; [106.69899750,10.77095032] ; [106.69856262,10.77077961]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"120"
    ,"Station_Code":"Q1 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"8, đường Trần Hưng Đạo, Qu ận 1"
    ,"Lat":10.768772
    ,"Long":106.695923
    ,"Polyline":"[106.69856262,10.77077961] ; [106.69744873,10.77035046] ; [106.69714355,10.76998997] ; [106.69642639,10.76920986] ; [106.69599152,10.76871014]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"121"
    ,"Station_Code":"Q1 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"10, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767363
    ,"Long":106.694695
    ,"Polyline":"[106.69592285,10.76877213] ; [106.69592285,10.76877213] ; [106.69599152,10.76871014] ; [106.69474792,10.76731968] ; [106.69469452,10.76736259] ; [106.69469452,10.76736259]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"122"
    ,"Station_Code":"Q1 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Rạp Hưng Đạo"
    ,"Station_Address":"112, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.765832
    ,"Long":106.693375
    ,"Polyline":"[106.69469452,10.76736259] ; [106.69469452,10.76736259] ; [106.69474792,10.76731968] ; [106.69344330,10.76578045] ; [106.69337463,10.76583195] ; [106.69337463,10.76583195]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"123"
    ,"Station_Code":"Q1 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh viện  Răng Hàm Mặt"
    ,"Station_Address":"150, đường  Trần Hưng Đạo, Quận 1"
    ,"Lat":10.763918
    ,"Long":106.691696
    ,"Polyline":"[106.69337463,10.76583195] ; [106.69169617,10.76391792]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"124"
    ,"Station_Code":"Q1 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trần Đình Xu"
    ,"Station_Address":"210 - 212, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.762262
    ,"Long":106.690247
    ,"Polyline":"[106.69169617,10.76391792] ; [106.69024658,10.76226234]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"125"
    ,"Station_Code":"Q1 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Tổng Cty Samco"
    ,"Station_Address":"262, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.759409
    ,"Long":106.687798
    ,"Polyline":"[106.69029999,10.76220989] ; [106.68784332,10.75938034]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"126"
    ,"Station_Code":"Q1 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Nanci"
    ,"Station_Address":"290, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.757467
    ,"Long":106.686035
    ,"Polyline":"[106.68784332,10.75938034] ; [106.68657684,10.75798035] ; [106.68608856,10.75741959]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1947"
    ,"Station_Code":"Q8 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường Dương Bá Trạc"
    ,"Station_Address":"158-160 , đường Dương Bá Trạc, Quận 8"
    ,"Lat":10.747844
    ,"Long":106.688544
    ,"Polyline":"[106.68608856,10.75741959] ; [106.68537140,10.75658035] ; [106.68517303,10.75644970] ; [106.68553162,10.75580978] ; [106.68576050,10.75547981] ; [106.68634796,10.75473976] ; [106.68659973,10.75436020] ; [106.68681335,10.75391960] ; [106.68686676,10.75376034] ; [106.68701172,10.75333023] ; [106.68724823,10.75255966] ; [106.68778992,10.75078011] ; [106.68895721,10.74701023]"
    ,"Distance":"1299"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1951"
    ,"Station_Code":"Q8 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường Rạch  Ông"
    ,"Station_Address":"290A/15, đường Dương Bá Trạc, Quận 8"
    ,"Lat":10.745009
    ,"Long":106.689059
    ,"Polyline":"[106.68895721,10.74701023] ; [106.68937683,10.74563026] ; [106.68937683,10.74551964] ; [106.68923950,10.74510956] ; [106.68891144,10.74415970]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1953"
    ,"Station_Code":"HBC 454"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Vòng xoay cầu Him Lam"
    ,"Station_Address":"128, đường Đường 9A, Huyện Bình Chánh"
    ,"Lat":10.737404
    ,"Long":106.689418
    ,"Polyline":"[106.68891144,10.74415970] ; [106.68840027,10.74260998] ; [106.68831635,10.74236012] ; [106.68830109,10.74215031] ; [106.68833160,10.74180031] ; [106.68836212,10.74168968] ; [106.68871307,10.74090958] ; [106.68920135,10.73991966] ; [106.68921661,10.73972988] ; [106.68937683,10.73923969] ; [106.68939972,10.73904037] ; [106.68937683,10.73902988] ; [106.68934631,10.73900032] ; [106.68933868,10.73896027] ; [106.68932343,10.73888969] ; [106.68933105,10.73880959] ; [106.68937683,10.73873997] ; [106.68945313,10.73869038] ; [106.68946838,10.73869038] ; [106.68949890,10.73855972] ; [106.68952179,10.73838997] ; [106.68946838,10.73762035] ; [106.68946075,10.73736000]"
    ,"Distance":"838"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1936"
    ,"Station_Code":"BX 56"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Khu dân cư Trung Sơn"
    ,"Station_Address":"Khu dân cư Trung Sơn, đường  Đường số 10, Huyện Bình Chánh"
    ,"Lat":10.733988
    ,"Long":106.689041
    ,"Polyline":"[106.68946075,10.73736000] ; [106.68939209,10.73400974] ; [106.68904114,10.73402023]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1936"
    ,"Station_Code":"BX 56"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu dân cư Trung  Sơn"
    ,"Station_Address":"Khu dân cư Trung Sơn, đường Đường số 10, Huyện Bình Chánh"
    ,"Lat":10.733988
    ,"Long":106.689041
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1943"
    ,"Station_Code":"HBC 455"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Thảo Loan PLAZA"
    ,"Station_Address":"Thảo Loan PLAZA, đường Đường 9A, Huyện Bình  Chánh"
    ,"Lat":10.731042
    ,"Long":106.689247
    ,"Polyline":"[106.68904114,10.73402023] ; [106.68939209,10.73400974] ; [106.68933105,10.73104000]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1938"
    ,"Station_Code":"HBC 457"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Đường 9A"
    ,"Station_Address":"259, đường Đ ường 9A, Huyện Bình Chánh"
    ,"Lat":10.731611
    ,"Long":106.689598
    ,"Polyline":"[106.68933105,10.73104000] ; [106.68930054,10.73038006] ; [106.68923187,10.73017025] ; [106.68910980,10.72998047] ; [106.68891907,10.72976971] ; [106.68837738,10.72922993] ; [106.68852234,10.72904968] ; [106.68929291,10.72984982] ; [106.68940735,10.73005009] ; [106.68952179,10.73023987] ; [106.68955231,10.73083973] ; [106.68955994,10.73161030]"
    ,"Distance":"589"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1940"
    ,"Station_Code":"HBC 456"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Vòng xoay cầu Him Lam"
    ,"Station_Address":"Kế 53, đường  Đường 9A, Huyện Bình Chánh"
    ,"Lat":10.737783
    ,"Long":106.689766
    ,"Polyline":"[106.68955994,10.73161030] ; [106.68966675,10.73563957] ; [106.68971252,10.73779011]"
    ,"Distance":"688"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1946"
    ,"Station_Code":"Q8 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường Rạch Ông"
    ,"Station_Address":"Cửa hàng Đăng  Khoa, đường Dương Bá Trạc, Quận 8"
    ,"Lat":10.744877
    ,"Long":106.689343
    ,"Polyline":"[106.68971252,10.73779011] ; [106.68972778,10.73851967] ; [106.68972015,10.73878956] ; [106.68974304,10.73884010.06.68974304] ; [10.73892975,106.68968201] ; [10.73902988,106.68963623] ; [10.73906040,106.68959808] ; [10.73908043,106.68949890] ; [10.73923969,106.68930054] ; [10.73976040,106.68920135] ; [10.73991966,106.68905640] ; [10.74022007,106.68852234] ; [10.74133015,106.68833923] ; [10.74174023,106.68830109]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1942"
    ,"Station_Code":"Q8 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Dư ơng Bá Trạc"
    ,"Station_Address":"129-131, đường Dương Bá Trạc, Quận 8"
    ,"Lat":10.746537
    ,"Long":106.689268
    ,"Polyline":"[106.68904877,10.74416065] ; [106.68923950,10.74510956] ; [106.68937683,10.74551964] ; [106.68937683,10.74563026] ; [106.68917084,10.74631977] ; [106.68907166,10.74664974] ; [106.68914795,10.74667645]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"18"
    ,"Station_Code":"Q1 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Nanci"
    ,"Station_Address":"563-565 , đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.75699
    ,"Long":106.685883
    ,"Polyline":"[106.68907166,10.74664974] ; [106.68852234,10.74843025] ; [106.68778992,10.75078011] ; [106.68695068,10.75354958] ; [106.68676758,10.75401974] ; [106.68647003,10.75457954] ; [106.68601990,10.75518036] ; [106.68553162,10.75580978] ; [106.68517303,10.75644970] ; [106.68537140,10.75658035] ; [106.68579102,10.75706959]"
    ,"Distance":"1278"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"22"
    ,"Station_Code":"Q1 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Tổng Cty Samco"
    ,"Station_Address":"449, đường Trần H ưng Đạo, Quận 1"
    ,"Lat":10.759426
    ,"Long":106.688011
    ,"Polyline":"[106.68579102,10.75706959] ; [106.68657684,10.75798035] ; [106.68794250,10.75949001]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"21"
    ,"Station_Code":"Q1 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Sở PCCC"
    ,"Station_Address":"359, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.760656
    ,"Long":106.689096
    ,"Polyline":"[106.68794250,10.75949001] ; [106.68901825,10.76074028]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"23"
    ,"Station_Code":"Q1 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Hồ Hảo Hớn"
    ,"Station_Address":"301F, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.762395
    ,"Long":106.690636
    ,"Polyline":"[106.68901825,10.76074028] ; [106.69052124,10.76245975]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"24"
    ,"Station_Code":"Q1 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Bệnh Viện  Răng Hàm Mặt"
    ,"Station_Address":"263, đường  Trần Hưng Đạo, Quận 1"
    ,"Lat":10.763567
    ,"Long":106.691612
    ,"Polyline":"[106.69052124,10.76245975] ; [106.69155121,10.76362038]"
    ,"Distance":"171"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"25"
    ,"Station_Code":"Q1 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Rạp Trần Hưng Đạo"
    ,"Station_Address":"227 - 229, đường Trần Hưng Đạo, Quận  1"
    ,"Lat":10.765213
    ,"Long":106.693069
    ,"Polyline":"[106.69155121,10.76362038] ; [106.69300079,10.76527023]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"26"
    ,"Station_Code":"Q1 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"KTX Trần Hưng Đạo"
    ,"Station_Address":"135, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.767064
    ,"Long":106.694824
    ,"Polyline":"[106.69300079,10.76527023] ; [106.69467163,10.76718998]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"27"
    ,"Station_Code":"Q1 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Nguyễn Kim"
    ,"Station_Address":"71C, đường Trần Hưng Đạo, Quận 1"
    ,"Lat":10.768327
    ,"Long":106.695847
    ,"Polyline":"[106.69467163,10.76718998] ; [106.69525909,10.76788044] ; [106.69538879,10.76801014] ; [106.69573975,10.76842022]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"38"
    ,"Station_Code":"Q1TC1D"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bến Thành D"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770603
    ,"Long":106.698441
    ,"Polyline":"[106.69573975,10.76842022] ; [106.69650269,10.76931953] ; [106.69714355,10.76998997] ; [106.69744873,10.77035046] ; [106.69774628,10.77033997] ; [106.69843292,10.77062035]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1944"
    ,"Station_Code":"Q1 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"40, đường Phạm Hồng Thái, Quận 1"
    ,"Lat":10.77129
    ,"Long":106.695824
    ,"Polyline":"[106.69843292,10.77062035] ; [106.69866943,10.77071667] ; [106.69889069,10.77079010.06.69895935] ; [10.77082062,106.69900513] ; [10.77095127,106.69860077] ; [10.77125835,106.69866180] ; [10.77132511,106.69871521] ; [10.77138710.06.69874573,10.77147293] ; [106.69876099,10.77156734] ; [106.69875336,10.77165699] ; [106.69873047,10.77172470] ; [106.69869995,10.77179813] ; [106.69866943,10.77183151] ; [106.69859314,10.77186012] ; [106.69850922,10.77188778] ; [106.69842529,10.77188492] ; [106.69835663,10.77187157] ; [106.69827271,10.77183151] ; [106.69821167,10.77178383] ; [106.69815826,10.77173519] ; [106.69810486,10.77167034] ; [106.69806671,10.77159405] ; [106.69795227,10.77165222] ; [106.69779968,10.77160358] ; [106.69757843,10.77151489] ; [106.69736481,10.77144146] ; [106.69708252,10.77132130] ; [106.69680786,10.77122402] ; [106.69672394,10.77119064] ; [106.69582367,10.77120972]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1297"
    ,"Station_Code":"Q1 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"Đối diện số 89, đường Cách Mạng Tháng  Tám, Quận 1"
    ,"Lat":10.773046
    ,"Long":106.690813
    ,"Polyline":"[106.69582367,10.77120972] ; [106.69516754,10.77120972] ; [106.69364929,10.77128029] ; [106.69342804,10.77132988] ; [106.69344330,10.77134991] ; [106.69342804,10.77138996] ; [106.69335938,10.77145004] ; [106.69328308,10.77147961] ; [106.69319916,10.77147961] ; [106.69315338,10.77161026] ; [106.69281769,10.77180004] ; [106.69113922,10.77270985] ; [106.69075012,10.77291965]"
    ,"Distance":"613"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"292"
    ,"Station_Code":"Q1 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Sở Y Tế"
    ,"Station_Address":"Đối diện 214-216, đường Nguyễn Thị Minh Khai, Quận  1"
    ,"Lat":10.774179
    ,"Long":106.690158
    ,"Polyline":"[106.69075012,10.77291965] ; [106.68985748,10.77340031] ; [106.68975830,10.77377033] ; [106.68977356,10.77388954] ; [106.68982697,10.77410030] ; [106.68995667,10.77423000]"
    ,"Distance":"211"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"242"
    ,"Station_Code":"Q1 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà Văn Hóa Lao Động"
    ,"Station_Address":"Đối diện số 138, đường Nguy ễn Thị Minh Khai, Quận 1"
    ,"Lat":10.777097
    ,"Long":106.692757
    ,"Polyline":"[106.68995667,10.77423000] ; [106.69161987,10.77598953] ; [106.69270325,10.77715015]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"243"
    ,"Station_Code":"Q3 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đại học Kiến Trúc"
    ,"Station_Address":"194 D, đường  Pasteur, Quận 3"
    ,"Lat":10.781804
    ,"Long":106.694579
    ,"Polyline":"[106.69270325,10.77715015] ; [106.69328308,10.77781010.06.69384003] ; [10.77842045,106.69496155] ; [10.77956009,106.69582367] ; [10.78050041,106.69480896] ; [10.78147030,106.69438171]"
    ,"Distance":"724"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"244"
    ,"Station_Code":"Q3 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Sở Tư Pháp"
    ,"Station_Address":"214, đường Pasteur, Quận 3"
    ,"Lat":10.783419
    ,"Long":106.692749
    ,"Polyline":"[106.69438171,10.78186035] ; [106.69270325,10.78337002]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"245"
    ,"Station_Code":"Q3 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"232, đường Pasteur, Quận 3"
    ,"Lat":10.784924
    ,"Long":106.691145
    ,"Polyline":"[106.69270325,10.78337002] ; [106.69164276,10.78431988] ; [106.69122314,10.78466988] ; [106.69109344,10.78479958]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"246"
    ,"Station_Code":"Q3 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Viện Pasteur"
    ,"Station_Address":"Đối diện 153 A-B, đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.785583
    ,"Long":106.689613
    ,"Polyline":"[106.69109344,10.78479958] ; [106.68997192,10.78584003] ; [106.68965912,10.78553963]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"247"
    ,"Station_Code":"Q3 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Viện Paster"
    ,"Station_Address":"252 (Đối diện 173), đường  Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.785577
    ,"Long":106.688683
    ,"Polyline":"[106.68965912,10.78553963] ; [106.68955231,10.78542042] ; [106.68943787,10.78544044] ; [106.68939972,10.78542042] ; [106.68910980,10.78518009] ; [106.68903351,10.78516960] ; [106.68895721,10.78518009] ; [106.68874359,10.78538036]"
    ,"Distance":"125"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"248"
    ,"Station_Code":"Q3 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngân hàng Sacombank"
    ,"Station_Address":"260, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.787047
    ,"Long":106.687133
    ,"Polyline":"[106.68874359,10.78538036] ; [106.68672943,10.78724957]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"250"
    ,"Station_Code":"Q3 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Lý Chính Thắng"
    ,"Station_Address":"288 B7, đường Nam Kỳ Khởi  Nghĩa, Quận 3"
    ,"Lat":10.789245
    ,"Long":106.684746
    ,"Polyline":"[106.68672943,10.78724957] ; [106.68586731,10.78804970] ; [106.68479919,10.78901005]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"249"
    ,"Station_Code":"Q3 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chùa Vĩnh Nghiêm"
    ,"Station_Address":"382E, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.790694
    ,"Long":106.683125
    ,"Polyline":"[106.68479919,10.78901005] ; [106.68418121,10.78956985] ; [106.68329620,10.79041004] ; [106.68279266,10.79088020]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"251"
    ,"Station_Code":"QPN 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trần Huy Liệu"
    ,"Station_Address":"40, đường Nguyễn Văn Trỗi, Quận Phú Nhu ận"
    ,"Lat":10.793598
    ,"Long":106.679236
    ,"Polyline":"[106.68279266,10.79088020] ; [106.68173981,10.79185963] ; [106.68131256,10.79224014] ; [106.68003845,10.79298019] ; [106.67919922,10.79351044]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"252"
    ,"Station_Code":"QPN 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trung tâm văn hóa Quận Phú Nhuận"
    ,"Station_Address":"68, đường Nguy ễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.795452
    ,"Long":106.676034
    ,"Polyline":"[106.67919922,10.79351044] ; [106.67787933,10.79426003] ; [106.67591095,10.79541969]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"253"
    ,"Station_Code":"QPN 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Học viện Hàng kHông"
    ,"Station_Address":"104, đường Nguyễn Văn Trỗi, Quận Phú  Nhuận"
    ,"Lat":10.79677
    ,"Long":106.673797
    ,"Polyline":"[106.67591095,10.79541969] ; [106.67392731,10.79658985]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"254"
    ,"Station_Code":"QPN 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bệnh viện Quận Phú Nhuận"
    ,"Station_Address":"142, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.798456
    ,"Long":106.670911
    ,"Polyline":"[106.67392731,10.79658985] ; [106.67125702,10.79817009]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"255"
    ,"Station_Code":"QPN 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Cây xăng Quân khu 7"
    ,"Station_Address":"180, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.799642
    ,"Long":106.66891
    ,"Polyline":"[106.67091370,10.79845619] ; [106.66890717,10.79964161]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu 7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66886902,10.79959011] ; [106.66842651,10.79983997] ; [106.66771698,10.80020046] ; [106.66710663,10.80056000] ; [106.66658783,10.80090046]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"911"
    ,"Station_Code":"QTB 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Quán Vườn Dừa"
    ,"Station_Address":"12 (1A), đường Phan Đình Giót, Quận T ân Bình"
    ,"Lat":10.803641
    ,"Long":106.664909
    ,"Polyline":"[106.66658783,10.80090046] ; [106.66603851,10.80126953] ; [106.66568756,10.80175972] ; [106.66558838,10.80185032] ; [106.66536713,10.80214024] ; [106.66512299,10.80274963] ; [106.66490173,10.80338001] ; [106.66484070,10.80362034]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"913"
    ,"Station_Code":"QTB 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Sông Đáy"
    ,"Station_Address":"Hông số 2 Sông Đáy, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.806961
    ,"Long":106.664673
    ,"Polyline":"[106.66484070,10.80362034] ; [106.66458893,10.80480003] ; [106.66449738,10.80576038] ; [106.66451263,10.80591965] ; [106.66458130,10.80663967] ; [106.66461182,10.80696964]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"915"
    ,"Station_Code":"QTB 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Siêu thị Super Bow"
    ,"Station_Address":"28, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.809024
    ,"Long":106.664864
    ,"Polyline":"[106.66461182,10.80696964] ; [106.66478729,10.80902958]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"912"
    ,"Station_Code":"QTB 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Parkson Trường Sơn"
    ,"Station_Address":"58, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.8109
    ,"Long":106.665031
    ,"Polyline":"[106.66478729,10.80902958] ; [106.66497040,10.81091022]"
    ,"Distance":"210"
  },
  {
     "Route_Id":"37"
    ,"Station_Id":"1945"
    ,"Station_Code":"BX 50"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Sân bay Tân Sơn Nhất"
    ,"Station_Address":"S ân bay Tân Sơn Nhất, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.813708
    ,"Long":106.663727
    ,"Polyline":"[106.66497040,10.81091022] ; [106.66507721,10.81216145] ; [106.66507721,10.81242275] ; [106.66493988,10.81257820] ; [106.66467285,10.81259441] ; [106.66452789,10.81267262] ; [106.66445923,10.81279278] ; [106.66455841,10.81303120] ; [106.66468048,10.81327057] ; [106.66461945,10.81353378] ; [106.66451263,10.81382370] ; [106.66434479,10.81401634] ; [106.66413116,10.81414795] ; [106.66392517,10.81418228] ; [106.66358948,10.81420040] ; [106.66328430,10.81422997] ; [106.66310120,10.81433487] ; [106.66293335,10.81455135] ; [106.66282654,10.81455612] ; [106.66275024,10.81451702] ; [106.66266632,10.81439018] ; [106.66258240,10.81362629] ; [106.66252899,10.81313610.06.66255951] ; [10.81272507,106.66284180] ; [10.81262493,106.66317749] ; [10.81259918,106.66373444] ; [10.81253529,106.66442108] ; [10.81247807,106.66491699] ; [10.81247807,106.66500854] ; [10.81248856,106.66503143] ; [10.81251717,106.66508484] ; [10.81260872,106.66510010] ; [10.81270599,106.66510773] ; [10.81283760,106.66512299] ; [10.81295967,106.66513062] ; [10.81312275,106.66515350] ; [10.81336403,106.66519928] ; [10.81373596,106.66525269] ; [10.81414890,106.66532135] ; [10.81445980,106.66545105] ; [10.81470108,106.66564178] ; [10.81493568,106.66586304] ; [10.81519127,106.66605377] ; [10.81544399,106.66606903] ; [10.81569958,106.66600800] ; [10.81588936,106.66588593] ; [10.81605816,106.66570282] ; [10.81616879,106.66527557] ; [10.81610298,106.66478729] ; [10.81590748,106.66407776] ; [10.81566525,106.66357422] ; [10.81546497,106.66316223] ; [10.81532288,106.66297913] ; [10.81505394,106.66295624] ; [10.81489372,106.66302490] ; [10.81465912,106.66310883] ; [10.81449699,106.66371155]"
    ,"Distance":"2037"
  }]