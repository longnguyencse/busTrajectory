export const Route28 =[

  {
     "Route_Id":"28"
    ,"Station_Id":"1482"
    ,"Station_Code":"BX76"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu chế xuất Linh Trung 2"
    ,"Station_Address":"ĐẦU BẾN KCX LINH TRUNG 2, đường  Ngô Chí Quốc, Quận Thủ Đức"
    ,"Lat":10.89524
    ,"Long":106.71862
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1478"
    ,"Station_Code":"QTD 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Khu Công nghiệp Đồng an"
    ,"Station_Address":"1303, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.894984
    ,"Long":106.719528
    ,"Polyline":"[106.71862030,10.89523983] ; [106.71843719,10.89535046] ; [106.71863556,10.89564037] ; [106.71952820,10.89498425]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1479"
    ,"Station_Code":"QTD 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Chợ Đồng An"
    ,"Station_Address":"1269, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.892311
    ,"Long":106.723694
    ,"Polyline":"[106.71952820,10.89498425] ; [106.72159576,10.89362240] ; [106.72369385,10.89231110]"
    ,"Distance":"544"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1481"
    ,"Station_Code":"QTD 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã 3 Linh Trung 2"
    ,"Station_Address":"1227, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.889835
    ,"Long":106.727688
    ,"Polyline":"[106.72369385,10.89231110.06.72394562] ; [10.89218426,106.72512054] ; [10.89142036,106.72557831] ; [10.89111996,106.72703552] ; [10.89039898,106.72752380] ; [10.89009285,106.72769165]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1483"
    ,"Station_Code":"QTD 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà hàng Song Sinh"
    ,"Station_Address":"1101-1103, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.886248
    ,"Long":106.728615
    ,"Polyline":"[106.72769165,10.88983536] ; [106.72786713,10.88968754] ; [106.72808075,10.88941383] ; [106.72856140,10.88860226] ; [106.72872162,10.88806534] ; [106.72866821,10.88714886] ; [106.72861481,10.88624763]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1486"
    ,"Station_Code":"QTD 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"UBND Phường Bình Chiểu"
    ,"Station_Address":"1049, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.883032
    ,"Long":106.729019
    ,"Polyline":"[106.72861481,10.88624763] ; [106.72858429,10.88572598] ; [106.72877502,10.88439846] ; [106.72901917,10.88303185]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1484"
    ,"Station_Code":"QTD 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Bình Chiểu"
    ,"Station_Address":"961, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.879025
    ,"Long":106.730472
    ,"Polyline":"[106.72901917,10.88303185] ; [106.72933197,10.88120651] ; [106.72953796,10.88040543] ; [106.72983551,10.87963676] ; [106.73046875,10.87902546]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1487"
    ,"Station_Code":"QTD 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cây Xăng  Bình Chiểu"
    ,"Station_Address":"927-929, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.876154
    ,"Long":106.731845
    ,"Polyline":"[106.73046875,10.87902546] ; [106.73128510,10.87844563] ; [106.73173523,10.87789822] ; [106.73186493,10.87751865] ; [106.73191833,10.87727642] ; [106.73191071,10.87669182] ; [106.73184204,10.87615395]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1489"
    ,"Station_Code":"QTD 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã Tư Gò Dưa"
    ,"Station_Address":"825, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.872941
    ,"Long":106.73236
    ,"Polyline":"[106.73184204,10.87615395] ; [106.73184204,10.87600136] ; [106.73178864,10.87582207] ; [106.73175812,10.87561703] ; [106.73171997,10.87510014] ; [106.73175812,10.87484741] ; [106.73200989,10.87402058] ; [106.73236084,10.87294102]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1485"
    ,"Station_Code":"QTD 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Phường Tam Bình"
    ,"Station_Address":"691, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.868147
    ,"Long":106.735611
    ,"Polyline":"[106.73236084,10.87294102] ; [106.73236084,10.87294102] ; [106.73247528,10.87276649] ; [106.73276520,10.87098598] ; [106.73418427,10.86616039] ; [106.73439026,10.86622334] ; [106.73437500,10.86634445] ; [106.73426056,10.86645508] ; [106.73374939,10.86818886] ; [106.73484039,10.86858368] ; [106.73561096,10.86814690] ; [106.73561096,10.86814690]"
    ,"Distance":"1263"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1492"
    ,"Station_Code":"QTD 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Điện lực Thủ Đức"
    ,"Station_Address":"Điện lực Thủ Đức, đường T ô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.866876
    ,"Long":106.738144
    ,"Polyline":"[106.73561096,10.86814690] ; [106.73596191,10.86805725] ; [106.73693848,10.86769867] ; [106.73741150,10.86751938] ; [106.73771667,10.86736679] ; [106.73798370,10.86707211] ; [106.73814392,10.86687565]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1488"
    ,"Station_Code":"QTD 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Công ty Minh Nghệ"
    ,"Station_Address":"601, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.865981
    ,"Long":106.740358
    ,"Polyline":"[106.73814392,10.86687565] ; [106.73831177,10.86671925] ; [106.73875427,10.86626625] ; [106.73902893,10.86618137] ; [106.73997498,10.86604977] ; [106.74035645,10.86598110]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1494"
    ,"Station_Code":"QTD 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Chùa Vạn Hạnh"
    ,"Station_Address":"579, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.864554
    ,"Long":106.741839
    ,"Polyline":"[106.74035645,10.86598110.06.74106598] ; [10.86592865,106.74141693] ; [10.86577606,106.74158478] ; [10.86558056,106.74171448] ; [10.86528111,106.74183655]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1490"
    ,"Station_Code":"QTD 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Chùa Vạn Đức"
    ,"Station_Address":"521, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.862968
    ,"Long":106.742713
    ,"Polyline":"[106.74183655,10.86455441] ; [106.74194336,10.86436939] ; [106.74204254,10.86400604] ; [106.74217987,10.86364746] ; [106.74229431,10.86343670] ; [106.74245453,10.86321545] ; [106.74271393,10.86296844]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1496"
    ,"Station_Code":"QTD 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà thờ Tam Hà"
    ,"Station_Address":"419, đường Tô Ng ọc Vân, Quận Thủ Đức"
    ,"Lat":10.860908
    ,"Long":106.745465
    ,"Polyline":"[106.74271393,10.86296844] ; [106.74406433,10.86216164] ; [106.74530792,10.86114502] ; [106.74546814,10.86090755]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1491"
    ,"Station_Code":"QTD 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Tam Hà"
    ,"Station_Address":"351-353, đường T ô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.859586
    ,"Long":106.747761
    ,"Polyline":"[106.74546814,10.86090755] ; [106.74575806,10.86067581] ; [106.74624634,10.86023331] ; [106.74683380,10.85964394] ; [106.74710083,10.85961246] ; [106.74748230,10.85962296] ; [106.74776459,10.85958576]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1498"
    ,"Station_Code":"QTD 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Siêu thị Coopfood"
    ,"Station_Address":"219, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.855843
    ,"Long":106.75045
    ,"Polyline":"[106.74776459,10.85958576] ; [106.74808502,10.85962296] ; [106.74826813,10.85935402] ; [106.74900818,10.85805798] ; [106.74953461,10.85741997] ; [106.74993896,10.85688305] ; [106.75023651,10.85632420] ; [106.75045013,10.85584259]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1493"
    ,"Station_Code":"QTD 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bồn nước"
    ,"Station_Address":"111, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.852854
    ,"Long":106.752037
    ,"Polyline":"[106.75045013,10.85584259] ; [106.75054932,10.85571861] ; [106.75083160,10.85425949] ; [106.75092316,10.85399055] ; [106.75110626,10.85368538] ; [106.75133514,10.85338974] ; [106.75160980,10.85311127] ; [106.75203705,10.85285378]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1500"
    ,"Station_Code":"QTD 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Thủ Đức"
    ,"Station_Address":"13, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.851198
    ,"Long":106.75428
    ,"Polyline":"[106.75203705,10.85285378] ; [106.75247192,10.85263634] ; [106.75289154,10.85232544] ; [106.75327301,10.85160446] ; [106.75357819,10.85126114] ; [106.75428009,10.85119820]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"493"
    ,"Station_Code":"QTD 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã ba Ch ương Dương"
    ,"Station_Address":"100, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850503
    ,"Long":106.759998
    ,"Polyline":"[106.75428009,10.85119820] ; [106.75454712,10.85122967] ; [106.75485229,10.85117245] ; [106.75487518,10.85110378] ; [106.75492859,10.85106659] ; [106.75500488,10.85107708] ; [106.75508881,10.85114574] ; [106.75527191,10.85115623] ; [106.75567627,10.85111427] ; [106.75600433,10.85110378] ; [106.75719452,10.85121918] ; [106.75751495,10.85108757] ; [106.75810242,10.85092926] ; [106.75860596,10.85061359] ; [106.75999451,10.85050297]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"490"
    ,"Station_Code":"QTD 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cao đẳng xây dựng 2"
    ,"Station_Address":"190, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.85065
    ,"Long":106.764439
    ,"Polyline":"[106.75999451,10.85050297] ; [106.76193237,10.85042953] ; [106.76216125,10.85049725] ; [106.76247406,10.85064507] ; [106.76274109,10.85080814] ; [106.76290131,10.85082912] ; [106.76444244,10.85064983]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"492"
    ,"Station_Code":"QTD 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Siêu thị Nguyễn Kim"
    ,"Station_Address":"274-276, đường Võ Văn Ngân, Qu ận Thủ Đức"
    ,"Lat":10.849686
    ,"Long":106.769112
    ,"Polyline":"[106.76444244,10.85064983] ; [106.76702881,10.85044003] ; [106.76717377,10.85040283] ; [106.76729584,10.85032368] ; [106.76739502,10.85016060] ; [106.76773071,10.84982872] ; [106.76796722,10.84977055] ; [106.76825714,10.84971237] ; [106.76911163,10.84968567]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"497"
    ,"Station_Code":"QTD 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường ĐHSP Kỹ Thuật"
    ,"Station_Address":"368, đường V õ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849597
    ,"Long":106.771917
    ,"Polyline":"[106.76911163,10.84968567] ; [106.77075195,10.84967613] ; [106.77191925,10.84959698]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1502"
    ,"Station_Code":"Q9 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Siêu thị Coopmark"
    ,"Station_Address":"4-6, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.848192
    ,"Long":106.775032
    ,"Polyline":"[106.77191925,10.84959698] ; [106.77224731,10.84960175] ; [106.77338409,10.84952259] ; [106.77359772,10.84943295] ; [106.77422333,10.84891224] ; [106.77466583,10.84855843] ; [106.77490997,10.84838009] ; [106.77503204,10.84819221]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1504"
    ,"Station_Code":"Q9 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bệnh viện  7C-Trường Quân y 2"
    ,"Station_Address":"50, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846262
    ,"Long":106.778124
    ,"Polyline":"[106.77503204,10.84819221] ; [106.77615356,10.84742641] ; [106.77812195,10.84626198]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1495"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà sách Thành Nghĩa"
    ,"Station_Address":"142-144, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.84486
    ,"Long":106.780563
    ,"Polyline":"[106.77812195,10.84626198] ; [106.78005981,10.84522915] ; [106.78056335,10.84486008]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1497"
    ,"Station_Code":"Q9 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cổng Đình Phong Phú"
    ,"Station_Address":"188, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844114
    ,"Long":106.782028
    ,"Polyline":"[106.78056335,10.84486008] ; [106.78083801,10.84472847] ; [106.78125000,10.84444427] ; [106.78202820,10.84411430]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1499"
    ,"Station_Code":"Q9 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chợ nhỏ"
    ,"Station_Address":"278, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844128
    ,"Long":106.784261
    ,"Polyline":"[106.78202820,10.84411430] ; [106.78250122,10.84399605] ; [106.78273773,10.84397507] ; [106.78426361,10.84412766]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1506"
    ,"Station_Code":"Q9 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Tăng Nhơn Phú- Trường Trần Quốc Toản"
    ,"Station_Address":"424A-424B, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844439
    ,"Long":106.788939
    ,"Polyline":"[106.78426361,10.84412766] ; [106.78539276,10.84439659] ; [106.78614044,10.84486008] ; [106.78636932,10.84500217] ; [106.78668213,10.84509754] ; [106.78742218,10.84511852] ; [106.78823853,10.84476566] ; [106.78865814,10.84458065] ; [106.78894043,10.84443855]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1501"
    ,"Station_Code":"Q9 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Bệnh viện Quận 9"
    ,"Station_Address":"Đối diện Bệnh  viện Quận 9, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.8446
    ,"Long":106.790977
    ,"Polyline":"[106.78894043,10.84443855] ; [106.78928375,10.84434891] ; [106.78955078,10.84431744] ; [106.79040527,10.84450722] ; [106.79097748,10.84459972]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1508"
    ,"Station_Code":"Q9 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Đại Học GTVT"
    ,"Station_Address":"Đối diện 451, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845276
    ,"Long":106.793922
    ,"Polyline":"[106.79097748,10.84459972] ; [106.79285431,10.84507656] ; [106.79392242,10.84527588]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1505"
    ,"Station_Code":"Q9 242"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã 3 Ngh êu sò"
    ,"Station_Address":"84D, đường Làng Tăng Phú,  Quận 9"
    ,"Lat":10.845685
    ,"Long":106.798767
    ,"Polyline":"[106.79392242,10.84527588] ; [106.79392242,10.84527588] ; [106.79622650,10.84589291] ; [106.79861450,10.84646225] ; [106.79876709,10.84568501] ; [106.79876709,10.84568501]"
    ,"Distance":"618"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1507"
    ,"Station_Code":"Q9 243"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Khu phố 4"
    ,"Station_Address":"50-52, đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.842879
    ,"Long":106.79838
    ,"Polyline":"[106.79876709,10.84568501] ; [106.79907990,10.84478664] ; [106.79905701,10.84441757] ; [106.79866028,10.84358501] ; [106.79837799,10.84287930]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1510"
    ,"Station_Code":"Q9 244"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 3 Xóm  Bến"
    ,"Station_Address":"Đối diện 17, đường Làng T ăng Phú, Quận 9"
    ,"Lat":10.840382
    ,"Long":106.797184
    ,"Polyline":"[106.79837799,10.84287930] ; [106.79824829,10.84222031] ; [106.79816437,10.84163094] ; [106.79794312,10.84131432] ; [106.79770660,10.84099293] ; [106.79718781,10.84038162]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1509"
    ,"Station_Code":"Q9 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Ga Gia Đinh"
    ,"Station_Address":"Đối diện Quán Nhà Quê, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.836178
    ,"Long":106.799408
    ,"Polyline":"[106.79718781,10.84038162] ; [106.79711151,10.84027672] ; [106.79677582,10.84009743] ; [106.79644012,10.83996010.06.79640961] ; [10.83989239,106.79748535] ; [10.83913326,106.79812622] ; [10.83833790,106.79835510] ; [10.83800030,106.79940796]"
    ,"Distance":"641"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1512"
    ,"Station_Code":"Q9 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bãi cát"
    ,"Station_Address":"Đối diện 215, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.831241
    ,"Long":106.803589
    ,"Polyline":"[106.79940796,10.83617783] ; [106.79971313,10.83581352] ; [106.80030060,10.83498192] ; [106.80117035,10.83349609] ; [106.80129242,10.83336353] ; [106.80146027,10.83330631] ; [106.80220032,10.83302116] ; [106.80259705,10.83281040] ; [106.80276489,10.83259964] ; [106.80293274,10.83238411] ; [106.80358887,10.83124065]"
    ,"Distance":"738"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1511"
    ,"Station_Code":"Q9 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã ba Lò Lu"
    ,"Station_Address":"12/1, đường L ã Xuân Oai, Quận 9"
    ,"Lat":10.823885
    ,"Long":106.808084
    ,"Polyline":"[106.80358887,10.83124065] ; [106.80428314,10.83025551] ; [106.80612946,10.82736301] ; [106.80675507,10.82655144] ; [106.80697632,10.82627773] ; [106.80741119,10.82571888] ; [106.80761719,10.82531261] ; [106.80798340,10.82436466] ; [106.80808258,10.82388496]"
    ,"Distance":"962"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1515"
    ,"Station_Code":"Q9 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm xăng Lò Lu"
    ,"Station_Address":"Kế 67, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.819593
    ,"Long":106.809624
    ,"Polyline":"[106.80808258,10.82388496] ; [106.80847931,10.82287884] ; [106.80888367,10.82173061] ; [106.80927277,10.82065487] ; [106.80962372,10.81959343]"
    ,"Distance":"507"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1513"
    ,"Station_Code":"Q9 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trường cấp 3 Long Trường"
    ,"Station_Address":"18 , đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.817035
    ,"Long":106.810707
    ,"Polyline":"[106.80962372,10.81959343] ; [106.80976868,10.81925392] ; [106.81040955,10.81747246] ; [106.81056976,10.81724644] ; [106.81070709,10.81703472]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1517"
    ,"Station_Code":"Q9 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Quán Tây Tăng Long"
    ,"Station_Address":"Đối diện 18A1, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.813004
    ,"Long":106.813766
    ,"Polyline":"[106.81070709,10.81703472] ; [106.81098938,10.81681442] ; [106.81230927,10.81546497] ; [106.81334686,10.81403160] ; [106.81376648,10.81300354]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1514"
    ,"Station_Code":"Q9 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Câu cá Lan Anh"
    ,"Station_Address":"Đối diện 27, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.80899
    ,"Long":106.815659
    ,"Polyline":"[106.81376648,10.81300354] ; [106.81565857,10.80898952]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1519"
    ,"Station_Code":"Q9 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã 3 Long Trường"
    ,"Station_Address":"766 (487), đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.806007
    ,"Long":106.816962
    ,"Polyline":"[106.81565857,10.80898952] ; [106.81634521,10.80766201] ; [106.81696320,10.80600739]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1516"
    ,"Station_Code":"Q9 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Long Trường"
    ,"Station_Address":"Chợ Long Trư ờng, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.806039
    ,"Long":106.821106
    ,"Polyline":"[106.81696320,10.80600739] ; [106.81719208,10.80549622] ; [106.81736755,10.80556393] ; [106.81752777,10.80560112] ; [106.81909180,10.80579662] ; [106.82110596,10.80603886]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1521"
    ,"Station_Code":"BX28"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"KDL BCR"
    ,"Station_Address":"KDL BCR, đường Tam Đa, Quận 9"
    ,"Lat":10.803756713867188
    ,"Long":106.83905792236328
    ,"Polyline":"[106.82110596,10.80603886] ; [106.82241058,10.80627537] ; [106.82565308,10.80707645] ; [106.82739258,10.80736160] ; [106.82916260,10.80761433] ; [106.83202362,10.80801487] ; [106.83291626,10.80777264] ; [106.83464813,10.80692959] ; [106.83514404,10.80664444] ; [106.83572388,10.80619144] ; [106.83599091,10.80591774] ; [106.83688354,10.80458927] ; [106.83727264,10.80392075] ; [106.83743286,10.80368805] ; [106.83789063,10.80295563] ; [106.83913422,10.80363083] ; [106.83905792,10.80375671]"
    ,"Distance":"2275"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1521"
    ,"Station_Code":"BX28"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"KDL BCR"
    ,"Station_Address":"KDL BCR, đường Tam Đa, Quận  9"
    ,"Lat":10.803756713867188
    ,"Long":106.83905792236328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1518"
    ,"Station_Code":"Q9 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Long Trường"
    ,"Station_Address":"Đối diện Chợ Long Trường, đường Nguyễn Duy Trinh, Quận 9"
    ,"Lat":10.806213
    ,"Long":106.821077
    ,"Polyline":"[106.83905792,10.80375671] ; [106.83914185,10.80368328] ; [106.83796692,10.80300903] ; [106.83684540,10.80477428] ; [106.83602905,10.80602837] ; [106.83560944,10.80638599] ; [106.83519745,10.80669212] ; [106.83477020,10.80695534] ; [106.83406067,10.80729771] ; [106.83290863,10.80785084] ; [106.83203888,10.80808830] ; [106.83046722,10.80789375] ; [106.82840729,10.80759335] ; [106.82733154,10.80745125] ; [106.82553864,10.80712414] ; [106.82347107,10.80662346] ; [106.82269287,10.80643940] ; [106.82188416,10.80628586] ; [106.82134247,10.80622292] ; [106.82107544,10.80621338]"
    ,"Distance":"2274"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1523"
    ,"Station_Code":"Q9 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã 3 Long Trường"
    ,"Station_Address":"65D, đường Lã Xuân Oai, Quận  9"
    ,"Lat":10.806144
    ,"Long":106.817027
    ,"Polyline":"[106.82107544,10.80621338] ; [106.82001495,10.80603313] ; [106.81745148,10.80571747] ; [106.81719208,10.80556965] ; [106.81702423,10.80614376]"
    ,"Distance":"500"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1520"
    ,"Station_Code":"Q9 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Câu cá Lan Anh"
    ,"Station_Address":"27, đường Lã Xuân Oai, Qu ận 9"
    ,"Lat":10.809005
    ,"Long":106.815814
    ,"Polyline":"[106.81702423,10.80614376] ; [106.81642914,10.80767250] ; [106.81581116,10.80900478]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1525"
    ,"Station_Code":"Q9 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Quán Tây Tăng Long"
    ,"Station_Address":"18A1, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.813089
    ,"Long":106.813899
    ,"Polyline":"[106.81581116,10.80900478] ; [106.81389618,10.81308937]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1522"
    ,"Station_Code":"Q9 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường cấp 3 Long Trường"
    ,"Station_Address":"Kế 417, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.817091
    ,"Long":106.810913
    ,"Polyline":"[106.81389618,10.81308937] ; [106.81342316,10.81406403] ; [106.81268311,10.81512260] ; [106.81236267,10.81551266] ; [106.81151581,10.81637669] ; [106.81091309,10.81709099]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1527"
    ,"Station_Code":"Q9 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Cây xăng"
    ,"Station_Address":"1/32, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.822705
    ,"Long":106.808664
    ,"Polyline":"[106.81091309,10.81709099] ; [106.81065369,10.81727791] ; [106.81049347,10.81749344] ; [106.81014252,10.81850529] ; [106.80953217,10.82026577] ; [106.80906677,10.82149315] ; [106.80866241,10.82270527]"
    ,"Distance":"679"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1524"
    ,"Station_Code":"Q9 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã ba Lò  Lu"
    ,"Station_Address":"215, đường Lã Xuân Oai, Qu ận 9"
    ,"Lat":10.830471
    ,"Long":106.804351
    ,"Polyline":"[106.80866241,10.82270527] ; [106.80831146,10.82358456] ; [106.80805969,10.82444859] ; [106.80771637,10.82530212] ; [106.80752563,10.82571316] ; [106.80667877,10.82677746] ; [106.80622864,10.82737827] ; [106.80580139,10.82801056] ; [106.80462646,10.82992363] ; [106.80435181,10.83047104]"
    ,"Distance":"992"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1529"
    ,"Station_Code":"Q9 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cơ sở hạt điều"
    ,"Station_Address":"Quán Nhà Quê, đường Lã Xu ân Oai, Quận 9"
    ,"Lat":10.836525
    ,"Long":106.799362
    ,"Polyline":"[106.80435181,10.83047104] ; [106.80384827,10.83111382] ; [106.80348206,10.83164120] ; [106.80305481,10.83234215] ; [106.80279541,10.83274746] ; [106.80267334,10.83288479] ; [106.80223846,10.83311081] ; [106.80188751,10.83321667] ; [106.80148315,10.83337402] ; [106.80130005,10.83348465] ; [106.80123138,10.83356380] ; [106.80078888,10.83431721] ; [106.80036163,10.83506012] ; [106.79983521,10.83579826] ; [106.79936218,10.83652496]"
    ,"Distance":"890"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1526"
    ,"Station_Code":"Q9 239"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 3 Xóm Bến"
    ,"Station_Address":"7, đường Làng Tăng  Phú, Quận 9"
    ,"Lat":10.839997
    ,"Long":106.79684
    ,"Polyline":"[106.79936218,10.83652496] ; [106.79906464,10.83693600] ; [106.79846191,10.83802700] ; [106.79817200,10.83842182] ; [106.79752350,10.83921719] ; [106.79647827,10.83989239] ; [106.79683685,10.83999729]"
    ,"Distance":"539"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1531"
    ,"Station_Code":"Q9 240"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Khu phố 4"
    ,"Station_Address":"51, đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.842611
    ,"Long":106.798444
    ,"Polyline":"[106.79683685,10.83999729] ; [106.79718018,10.84021378] ; [106.79770660,10.84083462] ; [106.79798889,10.84120941] ; [106.79823303,10.84158802] ; [106.79827881,10.84171009] ; [106.79829407,10.84185219] ; [106.79832458,10.84217358] ; [106.79844666,10.84261131]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1528"
    ,"Station_Code":"Q9 241"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã 3 Nghêu sò"
    ,"Station_Address":"Đối diện 15/369, đường Làng Tăng Phú,  Quận 9"
    ,"Lat":10.846004
    ,"Long":106.798847
    ,"Polyline":"[106.79844666,10.84261131] ; [106.79873657,10.84352684] ; [106.79915619,10.84443855] ; [106.79915619,10.84481812] ; [106.79884338,10.84600353]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1533"
    ,"Station_Code":"Q9 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 3 Man Thiện"
    ,"Station_Address":"Đối diện 504, đường Lê Văn  Việt, Quận 9"
    ,"Lat":10.846504
    ,"Long":106.798155
    ,"Polyline":"[106.79884338,10.84600353] ; [106.79866791,10.84660435] ; [106.79815674,10.84650421]"
    ,"Distance":"127"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1530"
    ,"Station_Code":"Q9 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại Học GTVT"
    ,"Station_Address":"Trung tâm thông tin  thư viện, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845566
    ,"Long":106.794421
    ,"Polyline":"[106.79815674,10.84650421] ; [106.79631805,10.84601402] ; [106.79441833,10.84556580]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1535"
    ,"Station_Code":"Q9 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bệnh viện  Quận 9"
    ,"Station_Address":"99, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844607
    ,"Long":106.790349
    ,"Polyline":"[106.79441833,10.84556580] ; [106.79226685,10.84501266] ; [106.79035187,10.84460735]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1532"
    ,"Station_Code":"Q9 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Trần  Quốc Toản"
    ,"Station_Address":"Đối diện chợ Tăng Nhơn Phú, đường Lê V ăn Việt, Quận 9"
    ,"Lat":10.844923
    ,"Long":106.788209
    ,"Polyline":"[106.79035187,10.84460735] ; [106.78954315,10.84441757] ; [106.78933716,10.84444904] ; [106.78876495,10.84467602] ; [106.78820801,10.84492302]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1537"
    ,"Station_Code":"Q9 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ nhỏ"
    ,"Station_Address":"249, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.84427
    ,"Long":106.784084
    ,"Polyline":"[106.78820801,10.84492302] ; [106.78745270,10.84520817] ; [106.78723145,10.84524441] ; [106.78696442,10.84523392] ; [106.78661346,10.84517670] ; [106.78626251,10.84506035] ; [106.78587341,10.84481812] ; [106.78538513,10.84450245] ; [106.78473663,10.84436989] ; [106.78408051,10.84426975]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1534"
    ,"Station_Code":"Q9 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cổng đình Phong Phú"
    ,"Station_Address":"189-191 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844381
    ,"Long":106.781723
    ,"Polyline":"[106.78408051,10.84426975] ; [106.78314209,10.84409618] ; [106.78271484,10.84407043] ; [106.78250122,10.84409142] ; [106.78172302,10.84438133]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1536"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Siêu thị Thành Nghĩa"
    ,"Station_Address":"Đối diện 140-142, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845176
    ,"Long":106.780377
    ,"Polyline":"[106.78172302,10.84438133] ; [106.78146362,10.84446526] ; [106.78127289,10.84455490] ; [106.78038025,10.84517574]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1539"
    ,"Station_Code":"Q9 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Bệnh viện 7C-Trường Quân y 2"
    ,"Station_Address":"91-93, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846799
    ,"Long":106.777512
    ,"Polyline":"[106.78038025,10.84517574] ; [106.77895355,10.84595585] ; [106.77751160,10.84679890]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1538"
    ,"Station_Code":"Q9 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Siêu thị Coopmark"
    ,"Station_Address":"17-19, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.848411
    ,"Long":106.775045
    ,"Polyline":"[106.77751160,10.84679890] ; [106.77615356,10.84756279] ; [106.77555084,10.84800053] ; [106.77504730,10.84841061]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"400"
    ,"Station_Code":"QTD 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường Đại học Sư phạm Kỹ thuật"
    ,"Station_Address":"1, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849823
    ,"Long":106.772089
    ,"Polyline":"[106.77504730,10.84841061] ; [106.77431488,10.84908581] ; [106.77365875,10.84959698] ; [106.77330780,10.84981251] ; [106.77299500,10.84984398] ; [106.77265167,10.84984970] ; [106.77208710,10.84982300]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"402"
    ,"Station_Code":"QTD 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu thị Nguyễn Kim"
    ,"Station_Address":"312, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849805
    ,"Long":106.768837
    ,"Polyline":"[106.77208710,10.84982300] ; [106.77189636,10.84980774] ; [106.77174377,10.84976006] ; [106.77157593,10.84974384] ; [106.76883698,10.84980488]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"403"
    ,"Station_Code":"QTD 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà thiếu nhi Thủ Đức"
    ,"Station_Address":"Nhà thiếu nhi, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850556
    ,"Long":106.766794
    ,"Polyline":"[106.76883698,10.84980488] ; [106.76827240,10.84979725] ; [106.76798248,10.84983349] ; [106.76775360,10.84991264] ; [106.76753235,10.85015488] ; [106.76732635,10.85042953] ; [106.76709747,10.85052395] ; [106.76679230,10.85055637]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"404"
    ,"Station_Code":"QTD 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"231, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850808
    ,"Long":106.764101
    ,"Polyline":"[106.76679230,10.85055637] ; [106.76409912,10.85080814]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"405"
    ,"Station_Code":"QTD 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"95, đường Võ Văn Ngân, Quận Th ủ Đức"
    ,"Lat":10.850679
    ,"Long":106.75943
    ,"Polyline":"[106.76409912,10.85080814] ; [106.76287842,10.85092449] ; [106.76270294,10.85090828] ; [106.76242065,10.85074043] ; [106.76216125,10.85058689] ; [106.76190948,10.85052967] ; [106.76067352,10.85057640] ; [106.75942993,10.85067940]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1540"
    ,"Station_Code":"QTD 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà Sách Thủ Đức"
    ,"Station_Address":"68-70, đường Tô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.851977
    ,"Long":106.753235
    ,"Polyline":"[106.75942993,10.85067940] ; [106.75867462,10.85069275] ; [106.75812531,10.85101414] ; [106.75762177,10.85114574] ; [106.75713348,10.85132504] ; [106.75601959,10.85120392] ; [106.75538635,10.85122490] ; [106.75502777,10.85121441] ; [106.75489044,10.85128307] ; [106.75473022,10.85130405] ; [106.75365448,10.85134602] ; [106.75334930,10.85165691] ; [106.75323486,10.85197735]"
    ,"Distance":"736"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1542"
    ,"Station_Code":"QTD 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Siêu thị CoopFood"
    ,"Station_Address":"192, đường Tô Ngọc Vân, Quận  Thủ Đức"
    ,"Lat":10.855645
    ,"Long":106.75069
    ,"Polyline":"[106.75323486,10.85197735] ; [106.75295258,10.85240459] ; [106.75256348,10.85270023] ; [106.75166321,10.85320568] ; [106.75146484,10.85338497] ; [106.75126648,10.85365391] ; [106.75110626,10.85389042] ; [106.75093842,10.85425949] ; [106.75068665,10.85564518]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1543"
    ,"Station_Code":"QTD 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã Ba Tam Hà - Tô Ngọc Vân"
    ,"Station_Address":"15, đường Tam Hà, Quận Thủ Đức"
    ,"Lat":10.860263
    ,"Long":106.747826
    ,"Polyline":"[106.75068665,10.85564518] ; [106.75004578,10.85689926] ; [106.74971771,10.85735226] ; [106.74912262,10.85804749] ; [106.74845886,10.85923767] ; [106.74782562,10.86026287]"
    ,"Distance":"604"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1545"
    ,"Station_Code":"QTD 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã Tư Tam Hà - Phú Châu"
    ,"Station_Address":"127-129, đường Tam Hà, Quận Thủ Đức"
    ,"Lat":10.863057
    ,"Long":106.745872
    ,"Polyline":"[106.74782562,10.86026287] ; [106.74587250,10.86305714]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1544"
    ,"Station_Code":"QTD 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Đường Phú Châu"
    ,"Station_Address":"23, đường Phú Châu, Quận Thủ Đức"
    ,"Lat":10.862831
    ,"Long":106.744709
    ,"Polyline":"[106.74587250,10.86305714] ; [106.74549866,10.86343670] ; [106.74470520,10.86283112]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1547"
    ,"Station_Code":"QTD 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chùa  Vạn Đức"
    ,"Station_Address":"476, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.863242
    ,"Long":106.742622
    ,"Polyline":"[106.74470520,10.86283112] ; [106.74407959,10.86226177] ; [106.74293518,10.86295223] ; [106.74262238,10.86324215]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1546"
    ,"Station_Code":"QTD 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chùa Vạn Hạnh"
    ,"Station_Address":"522, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.86497
    ,"Long":106.741928
    ,"Polyline":"[106.74262238,10.86324215] ; [106.74237061,10.86348438] ; [106.74226379,10.86368465] ; [106.74203491,10.86445332] ; [106.74192810,10.86497021]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1550"
    ,"Station_Code":"QTD 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Công ty  Minh Nghệ"
    ,"Station_Address":"96D3, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.866192
    ,"Long":106.739929
    ,"Polyline":"[106.74192810,10.86497021] ; [106.74168396,10.86562347] ; [106.74149323,10.86587048] ; [106.74111176,10.86602879] ; [106.73992920,10.86619186]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1548"
    ,"Station_Code":"QTD 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Điện lực Thủ Đức"
    ,"Station_Address":"562 , đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.866601
    ,"Long":106.738564
    ,"Polyline":"[106.73992920,10.86619186] ; [106.73905182,10.86625576] ; [106.73881531,10.86633396] ; [106.73856354,10.86660099]"
    ,"Distance":"164"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1552"
    ,"Station_Code":"QTD 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"UBND Ph ường Tam Bình"
    ,"Station_Address":"640, đường T ô Ngọc Vân, Quận Thủ Đức"
    ,"Lat":10.868458
    ,"Long":106.735382
    ,"Polyline":"[106.73856354,10.86660099] ; [106.73778534,10.86745167] ; [106.73752594,10.86759377] ; [106.73721313,10.86770916] ; [106.73581696,10.86824131] ; [106.73538208,10.86845779]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1549"
    ,"Station_Code":"QTD 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã Tư Gò Dưa"
    ,"Station_Address":"772-774, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.873517
    ,"Long":106.732315
    ,"Polyline":"[106.73538208,10.86845779] ; [106.73522949,10.86851501] ; [106.73482513,10.86872101] ; [106.73376465,10.86826801] ; [106.73355865,10.86882114] ; [106.73293304,10.87092781] ; [106.73263550,10.87270927] ; [106.73240662,10.87317276] ; [106.73231506,10.87351704]"
    ,"Distance":"802"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1551"
    ,"Station_Code":"QTD 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cây Xăng Bình Chiểu"
    ,"Station_Address":"828, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.875767
    ,"Long":106.731995
    ,"Polyline":"[106.73231506,10.87351704] ; [106.73185730,10.87491131] ; [106.73182678,10.87510014] ; [106.73182678,10.87524796] ; [106.73188782,10.87561703] ; [106.73199463,10.87576675]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1554"
    ,"Station_Code":"QTD 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Bình Chiểu"
    ,"Station_Address":"878, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.879494
    ,"Long":106.730316
    ,"Polyline":"[106.73199463,10.87576675] ; [106.73202515,10.87652779] ; [106.73202515,10.87728691] ; [106.73198700,10.87755013] ; [106.73191071,10.87777710.06.73181915] ; [10.87797165,106.73133850] ; [10.87853527,106.73097229] ; [10.87879372,106.73031616]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1557"
    ,"Station_Code":"QTD 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"UBND Phường Bình Chiểu"
    ,"Station_Address":"920, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.882558
    ,"Long":106.729233
    ,"Polyline":"[106.73031616,10.87949371] ; [106.72996521,10.87975788] ; [106.72973633,10.88016796] ; [106.72962952,10.88056374] ; [106.72923279,10.88255787]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1553"
    ,"Station_Code":"QTD 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Nhà hàng Song Sinh"
    ,"Station_Address":"992, đường Tỉnh lộ 43, Quận Th ủ Đức"
    ,"Lat":10.887765
    ,"Long":106.728844
    ,"Polyline":"[106.72923279,10.88255787] ; [106.72889709,10.88449860] ; [106.72874451,10.88572598] ; [106.72877502,10.88679028] ; [106.72884369,10.88776493]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1555"
    ,"Station_Code":"QTD 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã 3 Linh Trung 2"
    ,"Station_Address":"Hoàn Cầu, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.889891
    ,"Long":106.727898
    ,"Polyline":"[106.72884369,10.88776493] ; [106.72884369,10.88807583] ; [106.72865295,10.88863373] ; [106.72846222,10.88898182] ; [106.72789764,10.88989067]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1558"
    ,"Station_Code":"QTD 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Đồng An"
    ,"Station_Address":"28A, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.891993
    ,"Long":106.724464
    ,"Polyline":"[106.72789764,10.88989067] ; [106.72761536,10.89015102] ; [106.72679138,10.89062023] ; [106.72604370,10.89100456] ; [106.72541809,10.89135170] ; [106.72446442,10.89199257]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1556"
    ,"Station_Code":"QTD 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Khu Công nghiệp Đồng an"
    ,"Station_Address":"7/2, đường Tỉnh lộ 43, Quận Thủ Đức"
    ,"Lat":10.895303
    ,"Long":106.719292
    ,"Polyline":"[106.72446442,10.89199257] ; [106.72187805,10.89356422] ; [106.71929169,10.89530277]"
    ,"Distance":"675"
  },
  {
     "Route_Id":"28"
    ,"Station_Id":"1482"
    ,"Station_Code":"BX76"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Khu chế xuất Linh Trung 2"
    ,"Station_Address":"ĐẦU BẾN KCX LINH TRUNG 2, đường Ngô Chí Quốc, Quận  Thủ Đức"
    ,"Lat":10.89524
    ,"Long":106.71862
    ,"Polyline":"[106.71929169,10.89530277] ; [106.71861267,10.89575577] ; [106.71837616,10.89537716] ; [106.71862030,10.89523983]"
    ,"Distance":"170"
  }]