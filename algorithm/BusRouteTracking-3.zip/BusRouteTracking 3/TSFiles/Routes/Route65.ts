export const Route65 =[
  {
     "Route_Id":"65"
    ,"Station_Id":"2972"
    ,"Station_Code":"BX45"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến đò Bình Quới"
    ,"Station_Address":"ĐẦU BẾN BẾN ĐÒ BÌNH QUỚI, đường B ình Quới, Quận Bình Thạnh"
    ,"Lat":10.831978
    ,"Long":106.742767
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3044"
    ,"Station_Code":"QBTH 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Nhà hàng Hàn Quốc"
    ,"Station_Address":"401, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.830229
    ,"Long":106.741083
    ,"Polyline":"[106.74404907,10.83343983] ; [106.74236298,10.83121967] ; [106.74170685,10.83038044] ; [106.74111938,10.83014965]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3046"
    ,"Station_Code":"QBTH 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Khu du lịch Bình Quới"
    ,"Station_Address":"389, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.828501
    ,"Long":106.737864
    ,"Polyline":"[106.74111938,10.83014965] ; [106.74067688,10.82999039] ; [106.73989868,10.82966995] ; [106.73898315,10.82923985] ; [106.73873901,10.82911968] ; [106.73856354,10.82898998] ; [106.73818207,10.82866001] ; [106.73796844,10.82845020]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3045"
    ,"Station_Code":"QBTH 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Bình Quới"
    ,"Station_Address":"357, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.826836
    ,"Long":106.736233
    ,"Polyline":"[106.73796844,10.82845020] ; [106.73629761,10.82680988]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3047"
    ,"Station_Code":"QBTH 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"UBND Phường 28, Quận Bình Thạnh"
    ,"Station_Address":"1075, đường Bình  Quới, Quận Bình Thạnh"
    ,"Lat":10.825234
    ,"Long":106.734474
    ,"Polyline":"[106.73629761,10.82680988] ; [106.73573303,10.82623959] ; [106.73475647,10.82536983] ; [106.73455048,10.82520962]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3048"
    ,"Station_Code":"QBTH 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trung tâm cai nghiện Ma túy"
    ,"Station_Address":"1051, đường Bình Quới, Qu ận Bình Thạnh"
    ,"Lat":10.824307
    ,"Long":106.733208
    ,"Polyline":"[106.73455048,10.82520962] ; [106.73327637,10.82427025]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3049"
    ,"Station_Code":"QBTH 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cư xá Thanh Đa"
    ,"Station_Address":"1027, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.822094
    ,"Long":106.72971
    ,"Polyline":"[106.73327637,10.82427025] ; [106.73200989,10.82339001] ; [106.73030853,10.82234001] ; [106.72978210,10.82201958]"
    ,"Distance":"457"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3051"
    ,"Station_Code":"QBTH 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trung tâm TDTT Thanh Đa"
    ,"Station_Address":"1017, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.820323
    ,"Long":106.726491
    ,"Polyline":"[106.72978210,10.82201958] ; [106.72657013,10.82026005]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3050"
    ,"Station_Code":"QBTH 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chung c ư Thanh Đa"
    ,"Station_Address":"131, đường B ình Quới, Quận Bình Thạnh"
    ,"Lat":10.817963
    ,"Long":106.722082
    ,"Polyline":"[106.72657013,10.82026005] ; [106.72485352,10.81929016] ; [106.72428894,10.81900978] ; [106.72367859,10.81867981] ; [106.72332764,10.81851959] ; [106.72213745,10.81789970]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3053"
    ,"Station_Code":"QBTH 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Thanh Đa"
    ,"Station_Address":"130, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.816235
    ,"Long":106.719239
    ,"Polyline":"[106.72213745,10.81789970] ; [106.72020721,10.81688023] ; [106.71996307,10.81672001] ; [106.71941376,10.81630993] ; [106.71929169,10.81620026]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3052"
    ,"Station_Code":"QBTH 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Coop Mart Cầu kinh"
    ,"Station_Address":"689 , đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.812557
    ,"Long":106.715387
    ,"Polyline":"[106.71929169,10.81620026] ; [106.71881866,10.81566048] ; [106.71833038,10.81505966] ; [106.71816254,10.81486034] ; [106.71797180,10.81470966] ; [106.71678162,10.81379032] ; [106.71595764,10.81303978] ; [106.71588898,10.81299973] ; [106.71543884,10.81252956]"
    ,"Distance":"589"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3054"
    ,"Station_Code":"QBTH 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Chùa B ửu Liên"
    ,"Station_Address":"609, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.810834
    ,"Long":106.713429
    ,"Polyline":"[106.71540070,10.81249046] ; [106.71440125,10.81153965] ; [106.71347046,10.81077957]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"1410"
    ,"Station_Code":"QBTH 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Phường 25"
    ,"Station_Address":"đối diện 134/4A, đường Ung Văn Khiêm,  Quận Bình Thạnh"
    ,"Lat":10.808304
    ,"Long":106.714674
    ,"Polyline":"[106.71347046,10.81077957] ; [106.71343231,10.81075001] ; [106.71338654,10.81064034] ; [106.71260834,10.80994987] ; [106.71311188,10.80943966] ; [106.71337891,10.80918980] ; [106.71389771,10.80879974] ; [106.71446991,10.80844021] ; [106.71463776,10.80834007]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3055"
    ,"Station_Code":"QBTH 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã Tư D2"
    ,"Station_Address":"88, đường Ung Văn Khiêm, Quận Bình Thạnh"
    ,"Lat":10.807066
    ,"Long":106.717994
    ,"Polyline":"[106.71463776,10.80834007] ; [106.71562195,10.80786037] ; [106.71633911,10.80760002] ; [106.71671295,10.80749035] ; [106.71748352,10.80731010.06.71791840]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3057"
    ,"Station_Code":"QBTH 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã Ba Sông"
    ,"Station_Address":"214, đường Ung Văn Khiêm, Quận Bình Thạnh"
    ,"Lat":10.804347
    ,"Long":106.721363
    ,"Polyline":"[106.71791840,10.80720997] ; [106.71878815,10.80698967] ; [106.71942139,10.80679989] ; [106.71994781,10.80648041] ; [106.72026062,10.80626965] ; [106.72039795,10.80613041] ; [106.72061920,10.80591965] ; [106.72081757,10.80564976] ; [106.72104645,10.80533028] ; [106.72113037,10.80512047] ; [106.72116852,10.80502033] ; [106.72142029,10.80453014] ; [106.72148132,10.80440998] ; [106.72151184,10.80430031]"
    ,"Distance":"541"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3056"
    ,"Station_Code":"QBTH 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường THPT Hồng Đức"
    ,"Station_Address":"175, đường Đường D1, Quận Bình Thạnh"
    ,"Lat":10.803546
    ,"Long":106.720955
    ,"Polyline":"[106.72151184,10.80430031] ; [106.72162628,10.80387020] ; [106.72167969,10.80370998] ; [106.72118378,10.80354023] ; [106.72081757,10.80342007]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3060"
    ,"Station_Code":"QBTH 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Văn Thánh"
    ,"Station_Address":"57, đường Đư ờng D1, Quận Bình Thạnh"
    ,"Lat":10.80127
    ,"Long":106.71867
    ,"Polyline":"[106.72081757,10.80342007] ; [106.72013855,10.80319023] ; [106.71996307,10.80309010.06.71977997] ; [10.80292034,106.71910095] ; [10.80189991,106.71869659]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"420"
    ,"Station_Code":"QBTH 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"152/72c(559), đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.800153
    ,"Long":106.717442
    ,"Polyline":"[106.71869659,10.80125999] ; [106.71849823,10.80091953] ; [106.71830750,10.80056000] ; [106.71785736,10.79975033] ; [106.71719360,10.80008030]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"483, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71719360,10.80008030] ; [106.71645355,10.80043030] ; [106.71571350,10.80074024] ; [106.71513367,10.80097008] ; [106.71481323,10.80107975]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cây x ăng dầu"
    ,"Station_Address":"419, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71481323,10.80107975] ; [106.71382904,10.80140018] ; [106.71334839,10.80150986] ; [106.71280670,10.80154037]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"368"
    ,"Station_Code":"QBTH 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"221, đường Xô Viết Nghệ Tĩnh , Quận Bình Thạnh"
    ,"Lat":10.799837
    ,"Long":106.711074
    ,"Polyline":"[106.71280670,10.80154037] ; [106.71231842,10.80156040] ; [106.71144867,10.80158043] ; [106.71138763,10.80160046] ; [106.71130371,10.80160046] ; [106.71124268,10.80158043] ; [106.71118164,10.80152035] ; [106.71115112,10.80144978] ; [106.71118164,10.80132961] ; [106.71122742,10.80128002] ; [106.71130371,10.80125046] ; [106.71115112,10.79981041]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"367"
    ,"Station_Code":"QBTH 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường TH Hồng Hà"
    ,"Station_Address":"153, đường Xô Viết Nghệ Tĩnh, Quận Bình  Thạnh"
    ,"Lat":10.796738
    ,"Long":106.710414
    ,"Polyline":"[106.71115112,10.79981041] ; [106.71102905,10.79864025] ; [106.71092987,10.79813004] ; [106.71070862,10.79736042] ; [106.71057892,10.79699993] ; [106.71047211,10.79671955]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3058"
    ,"Station_Code":"QBTH 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"25, đường Nguyễn Văn Lạc, Quận Bình Thạnh"
    ,"Lat":10.794673
    ,"Long":106.709765
    ,"Polyline":"[106.71047211,10.79671955] ; [106.70999146,10.79553986] ; [106.70986176,10.79533005] ; [106.70999146,10.79528046] ; [106.70979309,10.79467010]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3061"
    ,"Station_Code":"QBTH 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã Ba Nguyễn văn Lạc"
    ,"Station_Address":"12C, đường Ngô Tất Tố, Qu ận Bình Thạnh"
    ,"Lat":10.793081
    ,"Long":106.710173
    ,"Polyline":"[106.70979309,10.79467010.06.70935059] ; [10.79335976,106.70989227] ; [10.79321003,106.71019745]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3059"
    ,"Station_Code":"QBTH 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Đại Học Tôn Đức Thắng"
    ,"Station_Address":"010 Lô A, đường Ngô Tất  Tố, Quận Bình Thạnh"
    ,"Lat":10.792502
    ,"Long":106.712265
    ,"Polyline":"[106.71019745,10.79312038] ; [106.71177673,10.79267025]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3062"
    ,"Station_Code":"QBTH 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu vượt Thủ Thiêm"
    ,"Station_Address":"120, đường Ng ô Tất Tố, Quận Bình Thạnh"
    ,"Lat":10.790705
    ,"Long":106.715028
    ,"Polyline":"[106.71177673,10.79267025] ; [106.71215820,10.79257965] ; [106.71279144,10.79244041] ; [106.71301270,10.79240036] ; [106.71322632,10.79232025] ; [106.71366119,10.79207993] ; [106.71379089,10.79197025] ; [106.71431732,10.79148006] ; [106.71476746,10.79104996] ; [106.71482849,10.79090023] ; [106.71528625,10.79045963]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2702"
    ,"Station_Code":"QBTH 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Hồ Bơi Hải Quân"
    ,"Station_Address":"22, đường Nguy ễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.789477
    ,"Long":106.710522
    ,"Polyline":"[106.71528625,10.79045963] ; [106.71604919,10.78973961] ; [106.71627045,10.78950024] ; [106.71595001,10.78938007] ; [106.71559143,10.78929996] ; [106.71520233,10.78927994] ; [106.71482849,10.78929996] ; [106.71427917,10.78938007] ; [106.71385956,10.78936958] ; [106.71199799,10.78964996] ; [106.71166229,10.78966999] ; [106.71147919,10.78964996] ; [106.71124268,10.78960991] ; [106.71103668,10.78954983] ; [106.71064758,10.78936958]"
    ,"Distance":"778"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2703"
    ,"Station_Code":"Q1 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"1, đường Nguyễn H ữu Cảnh, Quận 1"
    ,"Lat":10.784149
    ,"Long":106.707555
    ,"Polyline":"[106.71064758,10.78936958] ; [106.71035767,10.78917027] ; [106.71006012,10.78888988] ; [106.70986938,10.78862953] ; [106.70970154,10.78831959] ; [106.70908356,10.78676033] ; [106.70854187,10.78544044] ; [106.70836639,10.78511047] ; [106.70816803,10.78481007] ; [106.70790863,10.78450966] ; [106.70757294,10.78409958]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3063"
    ,"Station_Code":"Q1 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Chu Mạnh Trinh"
    ,"Station_Address":"Đối diện 15, đường Lê Thánh Tôn, Quận 1"
    ,"Lat":10.780908
    ,"Long":106.704894
    ,"Polyline":"[106.70757294,10.78409958] ; [106.70616913,10.78246975] ; [106.70613861,10.78242016] ; [106.70616913,10.78238964] ; [106.70623779,10.78225994] ; [106.70610809,10.78215981] ; [106.70561218,10.78160000] ; [106.70548248,10.78145981]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3065"
    ,"Station_Code":"Q1 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Sở Kế Ho ạch & Đầu Tư"
    ,"Station_Address":"32, đ ường Lê Thánh Tôn, Quận 1"
    ,"Lat":10.779001
    ,"Long":106.703328
    ,"Polyline":"[106.70548248,10.78145981] ; [106.70336151,10.77902031]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"4262"
    ,"Station_Code":"Q1 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trung tâm Vincom"
    ,"Station_Address":"Trung tâm Vincom, đường Lê Thánh Tôn , Quận 1"
    ,"Lat":10.777683
    ,"Long":106.702175
    ,"Polyline":"[106.70333099,10.77900124] ; [106.70217133,10.77768326]"
    ,"Distance":"193"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"4263"
    ,"Station_Code":"Q1 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Phố đi bộ Nguyễn Huệ"
    ,"Station_Address":"86Bis, đường Lê Thánh Tôn, Quận 1"
    ,"Lat":10.775048
    ,"Long":106.69983
    ,"Polyline":"[106.70233917,10.77788830] ; [106.70118713,10.77649212] ; [106.70056152,10.77580166] ; [106.69985962,10.77514744]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"1844"
    ,"Station_Code":"Q1 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Bến  Thành"
    ,"Station_Address":"220, đường Lê Thánh Tôn, Quận 1"
    ,"Lat":10.77234
    ,"Long":106.696295
    ,"Polyline":"[106.69985962,10.77514744] ; [106.69905853,10.77413177] ; [106.69871521,10.77385712] ; [106.69834137,10.77359390] ; [106.69628143,10.77235603]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69629669,10.77233982] ; [106.69600677,10.77213383] ; [106.69563293,10.77190781] ; [106.69530487,10.77165413] ; [106.69538116,10.77148056] ; [106.69554138,10.77113819] ; [106.69621277,10.77111149] ; [106.69650269,10.77108002] ; [106.69676971,10.77109146]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"202"
    ,"Station_Code":"Q1TC1C"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bến Thành C"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770787
    ,"Long":106.698532
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69727325,10.77135944] ; [106.69783783,10.77158070] ; [106.69802856,10.77152824] ; [106.69808960,10.77133846] ; [106.69827271,10.77118587] ; [106.69850159,10.77116489] ; [106.69866943,10.77118587] ; [106.69890594,10.77104282] ; [106.69877625,10.77085304] ; [106.69853210,10.77078724]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"853"
    ,"Station_Code":"Q1 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Calmette"
    ,"Station_Address":"87, đường Calmette, Quận 1"
    ,"Lat":10.767768
    ,"Long":106.699219
    ,"Polyline":"[106.69853973,10.77077007] ; [106.69818115,10.77063179] ; [106.69755554,10.77040005] ; [106.69616699,10.76978874] ; [106.69637299,10.76931477] ; [106.69658661,10.76916409] ; [106.69716644,10.76853752] ; [106.69808960,10.76937008] ; [106.69928741,10.76782036]"
    ,"Distance":"827"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"1195"
    ,"Station_Code":"Q4 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chùa Anh Linh"
    ,"Station_Address":"160-162, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.76308
    ,"Long":106.703183
    ,"Polyline":"[106.69928741,10.76782036] ; [106.69975281,10.76721001] ; [106.69980621,10.76708984] ; [106.70082092,10.76583004] ; [106.70153046,10.76504993] ; [106.70185089,10.76478958] ; [106.70300293,10.76397991] ; [106.70340729,10.76366997] ; [106.70353699,10.76354027] ; [106.70364380,10.76346970] ; [106.70378113,10.76340961] ; [106.70340729,10.76307964] ; [106.70330048,10.76299953]"
    ,"Distance":"788"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"1193"
    ,"Station_Code":"Q4 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường THCS  Vân Đồn"
    ,"Station_Address":"Đối diện 243, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.761879
    ,"Long":106.701488
    ,"Polyline":"[106.70330048,10.76299953] ; [106.70268250,10.76253033] ; [106.70188141,10.76193047] ; [106.70166016,10.76179028]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"4760"
    ,"Station_Code":"Q4 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Chùa Giác Nguyên"
    ,"Station_Address":"93, đường 41, Quận 4"
    ,"Lat":10.759296
    ,"Long":106.701434
    ,"Polyline":"[106.70148468,10.76187897] ; [106.70108795,10.76152515] ; [106.70223236,10.75988102] ; [106.70143127,10.75929642]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3069"
    ,"Station_Code":"Q4 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Hồ Bơi Quận 4"
    ,"Station_Address":"Đối diện 47, đường  Tân Vĩnh, Quận 4"
    ,"Lat":10.757584
    ,"Long":106.701381
    ,"Polyline":"[106.70143127,10.75929642] ; [106.70067596,10.75865364] ; [106.70144653,10.75762081] ; [106.70137787,10.75758362]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3066"
    ,"Station_Code":"Q4 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Nhà thuốc Hữu Nghị"
    ,"Station_Address":"28-30, đường  Vĩnh Hội, Quận 4"
    ,"Lat":10.756045
    ,"Long":106.702942
    ,"Polyline":"[106.70137787,10.75758362] ; [106.70143127,10.75760460] ; [106.70158386,10.75735664] ; [106.70176697,10.75716019] ; [106.70227814,10.75654030] ; [106.70230103,10.75638199] ; [106.70239258,10.75631905] ; [106.70246124,10.75609016] ; [106.70294189,10.75609016] ; [106.70294189,10.75602531] ; [106.70294189,10.75604534]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3068"
    ,"Station_Code":"Q4 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Tôn Đản"
    ,"Station_Address":"124-126, đường Vĩnh Hội, Quận 4"
    ,"Lat":10.756108
    ,"Long":106.705157
    ,"Polyline":"[106.70294189,10.75609016] ; [106.70514679,10.75613976]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"3071"
    ,"Station_Code":"Q4 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Tôn Đản"
    ,"Station_Address":"322-324A, đường Tôn Đản, Quận 4"
    ,"Lat":10.7551
    ,"Long":106.705711
    ,"Polyline":"[106.70514679,10.75613976] ; [106.70604706,10.75617981] ; [106.70577240,10.75508976]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2834"
    ,"Station_Code":"Q4 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Công An Phường 4"
    ,"Station_Address":"183B16, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.75323
    ,"Long":106.703601
    ,"Polyline":"[106.70577240,10.75508976] ; [106.70529175,10.75325012] ; [106.70361328,10.75314999]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2783"
    ,"Station_Code":"BX 12"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Cảng Quận 4"
    ,"Station_Address":"BÃI XE BUÝT CẦU MUỐI, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.752977
    ,"Long":106.701675
    ,"Polyline":"[106.70361328,10.75314999] ; [106.70207977,10.75306988] ; [106.70166779,10.75306034]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2783"
    ,"Station_Code":"BX 12"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Cảng Quận 4"
    ,"Station_Address":"BÃI XE BUÝT CẦU MUỐI, đường Tôn Thất Thuyết, Quận 4"
    ,"Lat":10.752977
    ,"Long":106.701675
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2782"
    ,"Station_Code":"Q4 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"UBND Phường 4"
    ,"Station_Address":"Đối diện 183N, đường Tôn Thất Thuyết, Quận  4"
    ,"Lat":10.753109
    ,"Long":106.703483
    ,"Polyline":"[106.70166779,10.75306034] ; [106.70298004,10.75312042] ; [106.70348358,10.75314999]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2946"
    ,"Station_Code":"Q4 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tôn Đản"
    ,"Station_Address":"295Bis, đường Tôn Đản, Quận 4"
    ,"Lat":10.755028
    ,"Long":106.705806
    ,"Polyline":"[106.70348358,10.75314999] ; [106.70529938,10.75329018] ; [106.70575714,10.75504971]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2947"
    ,"Station_Code":"Q4 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Tôn Đản"
    ,"Station_Address":"143-145, đường Vĩnh Hội, Quận 4"
    ,"Lat":10.756229
    ,"Long":106.705313
    ,"Polyline":"[106.70575714,10.75504971] ; [106.70604706,10.75617981] ; [106.70529938,10.75615025]"
    ,"Distance":"211"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2948"
    ,"Station_Code":"Q4 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà thuốc Hữu Nghị"
    ,"Station_Address":"31, đường Vĩnh Hội, Quận 4"
    ,"Lat":10.756151
    ,"Long":106.702988
    ,"Polyline":"[106.70529938,10.75615025] ; [106.70298767,10.75609016]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2949"
    ,"Station_Code":"Q4 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Đường 11"
    ,"Station_Address":"21-23, đường Tân Vĩnh, Quận 4"
    ,"Lat":10.756709
    ,"Long":106.702212
    ,"Polyline":"[106.70298767,10.75609016] ; [106.70246124,10.75609016] ; [106.70245361,10.75634003] ; [106.70227814,10.75654030] ; [106.70217133,10.75667000]"
    ,"Distance":"133"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2950"
    ,"Station_Code":"Q4 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Chính trị Quận 4"
    ,"Station_Address":"Đối diện 002, đường Tân Vĩnh, Quận 4"
    ,"Lat":10.759444
    ,"Long":106.700168
    ,"Polyline":"[106.70217133,10.75667000] ; [106.70176697,10.75716019] ; [106.70142365,10.75763988] ; [106.70091248,10.75835991] ; [106.70010376,10.75940990]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"1252"
    ,"Station_Code":"Q4 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường THCS  Vân Đồn"
    ,"Station_Address":"243, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.761768
    ,"Long":106.701724
    ,"Polyline":"[106.70010376,10.75940990] ; [106.69972992,10.75988007] ; [106.69941711,10.76029015] ; [106.69972992,10.76053047] ; [106.70041656,10.76099968] ; [106.70107269,10.76144028] ; [106.70146179,10.76167011] ; [106.70171356,10.76181984]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"1254"
    ,"Station_Code":"Q4 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chùa Anh Linh"
    ,"Station_Address":"177, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.763006
    ,"Long":106.703414
    ,"Polyline":"[106.70171356,10.76181984] ; [106.70226288,10.76222038] ; [106.70294952,10.76274014] ; [106.70337677,10.76305962]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"854"
    ,"Station_Code":"Q1 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Lê Thị Hồng Gấm"
    ,"Station_Address":"134, đường Calmette, Quận 1"
    ,"Lat":10.769178
    ,"Long":106.698334
    ,"Polyline":"[106.70337677,10.76305962] ; [106.70369720,10.76334000] ; [106.70378113,10.76340961] ; [106.70372772,10.76354027] ; [106.70210266,10.76471996] ; [106.70173645,10.76502037] ; [106.70144653,10.76527023] ; [106.70095825,10.76580048] ; [106.70011139,10.76686001] ; [106.69989014,10.76714039] ; [106.69975281,10.76721001] ; [106.69828033,10.76912975]"
    ,"Distance":"943"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"38"
    ,"Station_Code":"Q1TC1D"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Bến Thành D"
    ,"Station_Address":"B ến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770603
    ,"Long":106.698441
    ,"Polyline":"[106.69828033,10.76912975] ; [106.69774628,10.76984978] ; [106.69744873,10.77035046] ; [106.69774628,10.77033997] ; [106.69830322,10.77054977]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"241"
    ,"Station_Code":"Q1 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Chùa Bà  Ấn"
    ,"Station_Address":"42, đường Trương Định, Quận 1"
    ,"Lat":10.772419
    ,"Long":106.695839
    ,"Polyline":"[106.69830322,10.77054977] ; [106.69861603,10.77068520] ; [106.69895172,10.77081680] ; [106.69901276,10.77094841] ; [106.69860077,10.77124882] ; [106.69873047,10.77142239] ; [106.69875336,10.77168369] ; [106.69863892,10.77184677] ; [106.69832611,10.77186298] ; [106.69814301,10.77171993] ; [106.69805908,10.77158642] ; [106.69795227,10.77165699] ; [106.69773102,10.77157402] ; [106.69717407,10.77136230] ; [106.69673157,10.77119064] ; [106.69635010,10.77170563] ; [106.69580841,10.77239037]"
    ,"Distance":"626"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2951"
    ,"Station_Code":"Q1 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Khách sạn Golden"
    ,"Station_Address":"189 - 191, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.773244
    ,"Long":106.696228
    ,"Polyline":"[106.69580841,10.77239037] ; [106.69545746,10.77280998] ; [106.69616699,10.77332020]"
    ,"Distance":"156"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2952"
    ,"Station_Code":"Q1 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Nguyễn Trung Trực"
    ,"Station_Address":"109, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.77421
    ,"Long":106.697586
    ,"Polyline":"[106.69616699,10.77332020] ; [106.69696808,10.77388000] ; [106.69715881,10.77396011] ; [106.69754791,10.77425003]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2954"
    ,"Station_Code":"Q1 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Thư Viện Khoa Học Tổng Hợp"
    ,"Station_Address":"69,  đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.775442
    ,"Long":106.698853
    ,"Polyline":"[106.69754791,10.77425003] ; [106.69786072,10.77447987] ; [106.69818878,10.77482986] ; [106.69879913,10.77548981]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2725"
    ,"Station_Code":"Q1 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Sở Tài nguyên Môi trường"
    ,"Station_Address":"63, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.777108
    ,"Long":106.700386
    ,"Polyline":"[106.69879913,10.77548981] ; [106.70033264,10.77715969]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2569"
    ,"Station_Code":"Q1 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"TTTM Vincom"
    ,"Station_Address":"47, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.778568
    ,"Long":106.701721
    ,"Polyline":"[106.70033264,10.77715969] ; [106.70168304,10.77861023]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2570"
    ,"Station_Code":"Q1 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"23, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.780644
    ,"Long":106.703629
    ,"Polyline":"[106.70168304,10.77861023] ; [106.70218658,10.77919960] ; [106.70326233,10.78038025] ; [106.70355988,10.78069973]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2571"
    ,"Station_Code":"Q1 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Tòa án nhân dân Q1"
    ,"Station_Address":"3B, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.782521
    ,"Long":106.705338
    ,"Polyline":"[106.70355988,10.78069973] ; [106.70458984,10.78180981] ; [106.70526886,10.78258038]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2572"
    ,"Station_Code":"Q1 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Nguyễn Hữu Cảnh"
    ,"Station_Address":"Cây xanh số 17, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.78328
    ,"Long":106.707222
    ,"Polyline":"[106.70526886,10.78258038] ; [106.70555878,10.78291035] ; [106.70616913,10.78238964] ; [106.70632935,10.78248024] ; [106.70646667,10.78262043] ; [106.70690155,10.78310966]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2573"
    ,"Station_Code":"Q1 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"2A, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.785077
    ,"Long":106.708628
    ,"Polyline":"[106.70690155,10.78310966] ; [106.70783997,10.78421974] ; [106.70816040,10.78458977] ; [106.70848083,10.78501034] ; [106.70851135,10.78505993]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2579"
    ,"Station_Code":"QBTH 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Hồ Bơi Hải Quân"
    ,"Station_Address":"18, đường Nguy ễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.789113
    ,"Long":106.710779
    ,"Polyline":"[106.70851135,10.78505993] ; [106.70870972,10.78546047] ; [106.70983124,10.78827953] ; [106.71009064,10.78870964] ; [106.71025085,10.78890038] ; [106.71041870,10.78903961] ; [106.71066284,10.78921032] ; [106.71082306,10.78929996]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2955"
    ,"Station_Code":"QBTH 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu vượt Thủ Thiêm"
    ,"Station_Address":"173, đường Ngô Tất Tố, Quận Bình Thạnh"
    ,"Lat":10.790826
    ,"Long":106.715189
    ,"Polyline":"[106.71082306,10.78929996] ; [106.71108246,10.78940010.06.71103668] ; [10.78954983,106.71124268] ; [10.78960991,106.71147919] ; [10.78964996,106.71166229] ; [10.78966999,106.71199799] ; [10.78964996,106.71385956] ; [10.78936958,106.71427917] ; [10.78938007,106.71482849] ; [10.78929996,106.71501923] ; [10.78927994,106.71520233] ; [10.78927994,106.71559143] ; [10.78929996,106.71595001] ; [10.78938007,106.71636963] ; [10.78954029,106.71646118] ; [10.78958035,106.71539307]"
    ,"Distance":"812"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2953"
    ,"Station_Code":"QBTH 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường Đại học Ngô Tất Tố"
    ,"Station_Address":"83, đường Ngô Tất Tố, Quận Bình Thạnh"
    ,"Lat":10.79267
    ,"Long":106.712061
    ,"Polyline":"[106.71539307,10.79057980] ; [106.71492004,10.79098988] ; [106.71476746,10.79104996] ; [106.71453857,10.79127979] ; [106.71395111,10.79181957] ; [106.71366119,10.79207993] ; [106.71322632,10.79232025] ; [106.71301270,10.79240036] ; [106.71241760,10.79251003] ; [106.71231842,10.79253960]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2956"
    ,"Station_Code":"QBTH 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã Ba Nguyễn văn Lạc"
    ,"Station_Address":"15 , đường Ngô Tất Tố, Quận Bình Thạnh"
    ,"Lat":10.79316
    ,"Long":106.710221
    ,"Polyline":"[106.71231842,10.79253960] ; [106.71031189,10.79308033]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2957"
    ,"Station_Code":"QBTH 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh vi ện Bình Thạnh"
    ,"Station_Address":"Đối diện 9, đường Nguyễn Văn Lạc, Quận Bình Thạnh"
    ,"Lat":10.793582
    ,"Long":106.709513
    ,"Polyline":"[106.71031189,10.79308033] ; [106.70989227,10.79321003] ; [106.70935059,10.79335976] ; [106.70939636,10.79351997]"
    ,"Distance":"128"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"297"
    ,"Station_Code":"QBTH 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trung tâm Dưỡng Lão"
    ,"Station_Address":"138, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.797502
    ,"Long":106.710876
    ,"Polyline":"[106.70939636,10.79351997] ; [106.70995331,10.79529953] ; [106.70999146,10.79553986] ; [106.71035004,10.79640961] ; [106.71074677,10.79747963]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"300"
    ,"Station_Code":"QBTH 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"246, đường Xô Viết Nghệ Tĩnh , Quận Bình Thạnh"
    ,"Lat":10.799768
    ,"Long":106.711246
    ,"Polyline":"[106.71074677,10.79747963] ; [106.71092987,10.79813004] ; [106.71101379,10.79852962] ; [106.71112061,10.79951000] ; [106.71114349,10.79971027]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ T ĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71114349,10.79971027] ; [106.71133423,10.80122280] ; [106.71150208,10.80130959] ; [106.71154022,10.80147266] ; [106.71144867,10.80157566] ; [106.71132660,10.80160713] ; [106.71147156,10.80471039]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71147156,10.80471039] ; [106.71154022,10.80681992] ; [106.71156311,10.80747032] ; [106.71161652,10.80797005] ; [106.71167755,10.80821037] ; [106.71177673,10.80848980] ; [106.71190643,10.80883980] ; [106.71198273,10.80906963]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2959"
    ,"Station_Code":"QBTH 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Chùa Bửu Liên"
    ,"Station_Address":"256 (572), đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.810807
    ,"Long":106.713719
    ,"Polyline":"[106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71212006,10.80941010.06.71260834] ; [10.80994987,106.71338654] ; [10.81064034,106.71350098] ; [10.81068039,106.71372223]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2958"
    ,"Station_Code":"QBTH 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Coop Mart Cầu kinh"
    ,"Station_Address":"664-666, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.812246
    ,"Long":106.71536
    ,"Polyline":"[106.71372223,10.81085014] ; [106.71430206,10.81132030] ; [106.71476746,10.81173992] ; [106.71531677,10.81227970]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2960"
    ,"Station_Code":"QBTH 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cầu Kinh"
    ,"Station_Address":"60-62, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.814917
    ,"Long":106.718327
    ,"Polyline":"[106.71531677,10.81227970] ; [106.71578979,10.81272984] ; [106.71627808,10.81328011] ; [106.71642303,10.81338978] ; [106.71662140,10.81355953] ; [106.71698761,10.81383991] ; [106.71707153,10.81398010.06.71794128] ; [10.81462002,106.71813965] ; [10.81478977,106.71823883]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2961"
    ,"Station_Code":"QBTH 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chung cư Thanh Đa"
    ,"Station_Address":"0011  Lô A, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.817109
    ,"Long":106.720762
    ,"Polyline":"[106.71823883,10.81490993] ; [106.71871185,10.81550026] ; [106.71891022,10.81575966] ; [106.71913147,10.81601048] ; [106.71941376,10.81630993] ; [106.71955872,10.81647968] ; [106.71970367,10.81657982] ; [106.71997833,10.81676960] ; [106.72070313,10.81715012]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2962"
    ,"Station_Code":"QBTH 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chung  cư Thanh Đa"
    ,"Station_Address":"0053 Lô B,  đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.8179
    ,"Long":106.722275
    ,"Polyline":"[106.72070313,10.81715012] ; [106.72213745,10.81791973]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2963"
    ,"Station_Code":"QBTH 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trung tâm  TDTT Thanh Đa"
    ,"Station_Address":"256A, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.82026
    ,"Long":106.726749
    ,"Polyline":"[106.72213745,10.81791973] ; [106.72383118,10.81877995] ; [106.72485352,10.81929016] ; [106.72543335,10.81958961] ; [106.72575378,10.81982994] ; [106.72641754,10.82021999] ; [106.72666931,10.82036018]"
    ,"Distance":"565"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2964"
    ,"Station_Code":"QBTH 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Hồ bơi Misha"
    ,"Station_Address":"296, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.821988
    ,"Long":106.729882
    ,"Polyline":"[106.72666931,10.82036018] ; [106.72750092,10.82077980] ; [106.72817230,10.82116032] ; [106.72868347,10.82143021] ; [106.72923279,10.82168007] ; [106.72985077,10.82201958] ; [106.72997284,10.82209969]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2965"
    ,"Station_Code":"QBTH 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trung tâm cai nghiện Ma túy"
    ,"Station_Address":"330, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.824222
    ,"Long":106.733422
    ,"Polyline":"[106.72997284,10.82209969] ; [106.73149109,10.82303047] ; [106.73256683,10.82374001] ; [106.73335266,10.82431030]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2968"
    ,"Station_Code":"QBTH 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"UBND Phường 28, Quận Bình Thạnh"
    ,"Station_Address":"392, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.825466
    ,"Long":106.735053
    ,"Polyline":"[106.73335266,10.82431030] ; [106.73459625,10.82524014]"
    ,"Distance":"171"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2966"
    ,"Station_Code":"QBTH 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Bình Quới"
    ,"Station_Address":"456, đường Bình Qu ới, Quận Bình Thạnh"
    ,"Lat":10.82673
    ,"Long":106.736383
    ,"Polyline":"[106.73459625,10.82524014] ; [106.73538208,10.82590008] ; [106.73568726,10.82621002] ; [106.73612976,10.82664967]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2970"
    ,"Station_Code":"QBTH 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Khu du lịch Bình Quới"
    ,"Station_Address":"520, đường B ình Quới, Quận Bình Thạnh"
    ,"Lat":10.828416
    ,"Long":106.738079
    ,"Polyline":"[106.73612976,10.82664967] ; [106.73721313,10.82769012] ; [106.73787689,10.82837009]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2967"
    ,"Station_Code":"QBTH 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Nhà hàng Hàn Quốc"
    ,"Station_Address":"564, đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.830155
    ,"Long":106.741287
    ,"Polyline":"[106.73787689,10.82837009] ; [106.73837280,10.82884026] ; [106.73873901,10.82911968] ; [106.73931885,10.82942009] ; [106.74034882,10.82987022] ; [106.74127960,10.83020020]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"65"
    ,"Station_Id":"2972"
    ,"Station_Code":"BX45"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Bến đò Bình Quới"
    ,"Station_Address":"ĐẦU BẾN BẾN ĐÒ BÌNH QUỚI,  đường Bình Quới, Quận Bình Thạnh"
    ,"Lat":10.831978
    ,"Long":106.742767
    ,"Polyline":"[106.74127960,10.83020020] ; [106.74165344,10.83034039] ; [106.74182892,10.83047962] ; [106.74299622,10.83201981] ; [106.74337006,10.83255959] ; [106.74384308,10.83314991] ; [106.74404907,10.83343983]"
    ,"Distance":"477"
  }]