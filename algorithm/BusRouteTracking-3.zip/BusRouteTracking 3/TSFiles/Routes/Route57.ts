export const Route57 =[

  {
     "Route_Id":"57"
    ,"Station_Id":"2745"
    ,"Station_Code":"BX35"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"BÃI XE THỚI AN, đường Lê Văn Kh ương, Quận 12"
    ,"Lat":10.878466606140137
    ,"Long":106.64797973632812
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1746"
    ,"Station_Code":"Q12 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đài liệt s ỹ"
    ,"Station_Address":"Đài liệt sỹ, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.874953
    ,"Long":106.648972
    ,"Polyline":"[106.64797974,10.87846661] ; [106.64892578,10.87841415] ; [106.64897156,10.87495327]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1745"
    ,"Station_Code":"Q12 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Hiệp Th ành 49"
    ,"Station_Address":"251, đường Lê Văn  Khương, Quận 12"
    ,"Lat":10.871424
    ,"Long":106.649185
    ,"Polyline":"[106.64897156,10.87495327] ; [106.64918518,10.87142372]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1748"
    ,"Station_Code":"Q12 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Nhà máy Bia"
    ,"Station_Address":"119, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.867475
    ,"Long":106.649368
    ,"Polyline":"[106.64918518,10.87142372] ; [106.64936829,10.86747456]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1747"
    ,"Station_Code":"Q12 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Metro Hiệp Phú"
    ,"Station_Address":"Metro Hiệp Phú, đường Lê Văn Khương, Qu ận 12"
    ,"Lat":10.862768
    ,"Long":106.649641
    ,"Polyline":"[106.64936829,10.86747456] ; [106.64936829,10.86747456] ; [106.64959717,10.86563396] ; [106.64945984,10.86490631] ; [106.64968109,10.86419010.06.64964294] ; [10.86276817,106.64964294]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"973"
    ,"Station_Code":"QGV 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà thờ Nữ Vương Hòa Bình"
    ,"Station_Address":"Đối diện nhà thờ Nữ Vương Hòa Bình, đường  Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.856841
    ,"Long":106.653809
    ,"Polyline":"[106.64964294,10.86276817] ; [106.64980316,10.86125088] ; [106.64985657,10.86099720] ; [106.64997101,10.86074448] ; [106.65338135,10.85738373] ; [106.65380859,10.85684109]"
    ,"Distance":"834"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2755"
    ,"Station_Code":"QGV 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu Cụt"
    ,"Station_Address":"1181 , đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.854307
    ,"Long":106.656776
    ,"Polyline":"[106.65380859,10.85684109] ; [106.65485382,10.85601330] ; [106.65582275,10.85507584] ; [106.65677643,10.85430717]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2622"
    ,"Station_Code":"QGVT078"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường TH  Lê Thị Hồng Gấm"
    ,"Station_Address":"54/11, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.852690696716309
    ,"Long":106.66150665283203
    ,"Polyline":"[106.65677643,10.85430717] ; [106.65763092,10.85394859] ; [106.66055298,10.85244179] ; [106.66150665,10.85269070]"
    ,"Distance":"570"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2621"
    ,"Station_Code":"QGV 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã Ba Nhà Đèn"
    ,"Station_Address":"778, đường Phạm V ăn Chiêu, Quận Gò Vấp"
    ,"Lat":10.853748
    ,"Long":106.664602
    ,"Polyline":"[106.66150665,10.85269070] ; [106.66160583,10.85277367] ; [106.66441345,10.85374260] ; [106.66460419,10.85374832]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2623"
    ,"Station_Code":"QGV 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà Thờ Hà Nội"
    ,"Station_Address":"540, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.850998
    ,"Long":106.66508
    ,"Polyline":"[106.66460419,10.85374832] ; [106.66551208,10.85418034] ; [106.66549683,10.85346413] ; [106.66507721,10.85099792]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2758"
    ,"Station_Code":"QGV 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chùa Ti ên Long"
    ,"Station_Address":"537, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.847985
    ,"Long":106.6645
    ,"Polyline":"[106.66507721,10.85099792] ; [106.66493988,10.84986019] ; [106.66449738,10.84798527]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2759"
    ,"Station_Code":"QGV 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Đại học  Hồng Bàng"
    ,"Station_Address":"461, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.845208
    ,"Long":106.664709
    ,"Polyline":"[106.66449738,10.84798527] ; [106.66459656,10.84690952] ; [106.66472626,10.84583473] ; [106.66471100,10.84520817]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2760"
    ,"Station_Code":"QGV 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"UBND Phường 16,  Quận Gò Vấp"
    ,"Station_Address":"375 (109A), đường Thống Nh ất, Quận Gò Vấp"
    ,"Lat":10.842115
    ,"Long":106.664667
    ,"Polyline":"[106.66471100,10.84520817] ; [106.66472626,10.84447575] ; [106.66464233,10.84366417] ; [106.66466522,10.84211540]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1754"
    ,"Station_Code":"QGV 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã Ba Nguyễn Văn Lượng"
    ,"Station_Address":"303, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.839223
    ,"Long":106.665245
    ,"Polyline":"[106.66466522,10.84211540] ; [106.66500092,10.84042931] ; [106.66528320,10.83973408] ; [106.66524506,10.83922291]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2761"
    ,"Station_Code":"QGV 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Th ông Tây"
    ,"Station_Address":"195, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.836172
    ,"Long":106.664683
    ,"Polyline":"[106.66524506,10.83922291] ; [106.66525269,10.83865929] ; [106.66461182,10.83597660]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2762"
    ,"Station_Code":"QGV 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Th ông Tây"
    ,"Station_Address":"1417, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.834634
    ,"Long":106.666882
    ,"Polyline":"[106.66461182,10.83597660] ; [106.66464996,10.83562946] ; [106.66471100,10.83542442] ; [106.66673279,10.83475971] ; [106.66688538,10.83463383]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2763"
    ,"Station_Code":"QGV 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Ba Tân Thông Hội"
    ,"Station_Address":"1319, đường Phan  Văn Trị, Quận Gò Vấp"
    ,"Lat":10.833638
    ,"Long":106.669602
    ,"Polyline":"[106.66688538,10.83463383] ; [106.66697693,10.83467579] ; [106.66952515,10.83374310.06.66960144]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2764"
    ,"Station_Code":"QGV 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Xí nghiệp Z751"
    ,"Station_Address":"1195-1197, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.832837
    ,"Long":106.671823
    ,"Polyline":"[106.66960144,10.83363819] ; [106.66963959,10.83368015] ; [106.67144775,10.83304977] ; [106.67141724,10.83297920]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2766"
    ,"Station_Code":"QGV 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Xí nghiệp dệt Quân Đội"
    ,"Station_Address":"7, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.831942
    ,"Long":106.674324
    ,"Polyline":"[106.67144775,10.83304977] ; [106.67434692,10.83201027]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2765"
    ,"Station_Code":"QGV 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã Tư  Nguyễn Oanh"
    ,"Station_Address":"1071, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.831051
    ,"Long":106.67672
    ,"Polyline":"[106.67432404,10.83194160] ; [106.67434692,10.83201027] ; [106.67666626,10.83117771] ; [106.67671967,10.83105087]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2768"
    ,"Station_Code":"QGV 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Patin Z751"
    ,"Station_Address":"1013, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.830319
    ,"Long":106.679049
    ,"Polyline":"[106.67671967,10.83105087] ; [106.67680359,10.83114529] ; [106.67771149,10.83080959] ; [106.67816162,10.83065033] ; [106.67833710,10.83061028] ; [106.67839050,10.83049774]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2772"
    ,"Station_Code":"QGV 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã Ba Nguyễn Huy Điển"
    ,"Station_Address":"893, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.829513
    ,"Long":106.681335
    ,"Polyline":"[106.67861938,10.83051968] ; [106.68135834,10.82958031]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2770"
    ,"Station_Code":"QGV 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"PCCC Qu ận Gò Vấp"
    ,"Station_Address":"771, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.828364
    ,"Long":106.684939
    ,"Polyline":"[106.68133545,10.82951260] ; [106.68135834,10.82958031] ; [106.68286133,10.82909966] ; [106.68467712,10.82849979] ; [106.68493652,10.82836437]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2767"
    ,"Station_Code":"QGV 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Caphê Cát Đằng"
    ,"Station_Address":"689, đường Phan V ăn Trị, Quận Gò Vấp"
    ,"Lat":10.827421
    ,"Long":106.687996
    ,"Polyline":"[106.68493652,10.82836437] ; [106.68493652,10.82836437] ; [106.68503571,10.82846928] ; [106.68572998,10.82822704] ; [106.68758392,10.82763100] ; [106.68771362,10.82750034] ; [106.68769073,10.82750988] ; [106.68769073,10.82750988]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1766"
    ,"Station_Code":"QGV 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bãi hậu cần số 1"
    ,"Station_Address":"439, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.823559
    ,"Long":106.692165
    ,"Polyline":"[106.68769073,10.82750988] ; [106.68795013,10.82754230] ; [106.68849182,10.82703972] ; [106.69226074,10.82355022] ; [106.69216156,10.82355881]"
    ,"Distance":"688"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1767"
    ,"Station_Code":"QBTH 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Chùa Giác Quang"
    ,"Station_Address":"189, đường Phan  Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.819749
    ,"Long":106.694375
    ,"Polyline":"[106.69216156,10.82355881] ; [106.69315338,10.82271576] ; [106.69337463,10.82239914] ; [106.69364929,10.82148266] ; [106.69437408,10.81974888]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1769"
    ,"Station_Code":"QBTH 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"235, đường Phan Văn Trị, Quận Bình Th ạnh"
    ,"Lat":10.813695
    ,"Long":106.695217
    ,"Polyline":"[106.69437408,10.81974888] ; [106.69457245,10.81925869] ; [106.69498444,10.81817341] ; [106.69533539,10.81724644] ; [106.69523621,10.81641388] ; [106.69521332,10.81369495]"
    ,"Distance":"694"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1768"
    ,"Station_Code":"QBTH 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"89, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809833
    ,"Long":106.695061
    ,"Polyline":"[106.69521332,10.81369495] ; [106.69531250,10.81149197] ; [106.69546509,10.81126022] ; [106.69518280,10.81051254] ; [106.69506073,10.80983257]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2107"
    ,"Station_Code":"QBTH 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"27, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.805712
    ,"Long":106.694965
    ,"Polyline":"[106.69509888,10.80982971] ; [106.69503784,10.80665970] ; [106.69500732,10.80566978]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2110"
    ,"Station_Code":"QBTH 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"1, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803583
    ,"Long":106.694906
    ,"Polyline":"[106.69500732,10.80566978] ; [106.69493866,10.80352020]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2037"
    ,"Station_Code":"QBTH 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"129, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.801391
    ,"Long":106.696456
    ,"Polyline":"[106.69490814,10.80358315] ; [106.69490051,10.80276108] ; [106.69655609,10.80254459] ; [106.69645691,10.80139065]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2034"
    ,"Station_Code":"QBTH 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"95, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.798625
    ,"Long":106.696279
    ,"Polyline":"[106.69645691,10.80139065] ; [106.69628143,10.79862499]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2112"
    ,"Station_Code":"QBTH 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"51, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.79423
    ,"Long":106.695968
    ,"Polyline":"[106.69631195,10.79862022] ; [106.69606018,10.79461956]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"4269"
    ,"Station_Code":"Q1 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Đa Kao"
    ,"Station_Address":"30, đường Trần Quang  Khải, Quận 1"
    ,"Lat":10.792622
    ,"Long":106.695195
    ,"Polyline":"[106.69596863,10.79423046] ; [106.69599152,10.79384518] ; [106.69595337,10.79346561] ; [106.69588470,10.79268074] ; [106.69519806,10.79262161] ; [106.69519806,10.79262161]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"4270"
    ,"Station_Code":"Q1 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Nguyễn Hữu Cầu"
    ,"Station_Address":"124, đường Trần Quang Khải, Quận 1"
    ,"Lat":10.792072
    ,"Long":106.692088
    ,"Polyline":"[106.69519806,10.79262161] ; [106.69208527,10.79207230]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"234"
    ,"Station_Code":"Q3 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ Tân Định"
    ,"Station_Address":"Đối diện 274, đường Hai Bà Trưng, Quận 3"
    ,"Lat":10.788972
    ,"Long":106.690445
    ,"Polyline":"[106.69208527,10.79207230] ; [106.69150543,10.79193211] ; [106.69142151,10.79160595] ; [106.69123840,10.79127884] ; [106.69091797,10.79076290] ; [106.69060516,10.79023552] ; [106.69026947,10.78971958] ; [106.69001007,10.78939247] ; [106.69044495,10.78897190]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2769"
    ,"Station_Code":"Q3 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Phạm Ngo ̣c Thạch"
    ,"Station_Address":"61-63, đường Phạm  Ngọc Thạch, Quận 3"
    ,"Lat":10.786242
    ,"Long":106.691833
    ,"Polyline":"[106.69044495,10.78897190] ; [106.69161987,10.78810692] ; [106.69193268,10.78785419] ; [106.69158173,10.78751659] ; [106.69109344,10.78702068] ; [106.69183350,10.78624153]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2565"
    ,"Station_Code":"Q3 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"43, đường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.784855
    ,"Long":106.693388
    ,"Polyline":"[106.69183350,10.78624153] ; [106.69190979,10.78627300] ; [106.69342804,10.78494453] ; [106.69338989,10.78485489]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2566"
    ,"Station_Code":"Q3 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Đại học  Kinh tế"
    ,"Station_Address":"17, đường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.783159
    ,"Long":106.695198
    ,"Polyline":"[106.69338989,10.78485489] ; [106.69352722,10.78485489] ; [106.69519806,10.78328991] ; [106.69519806,10.78315926]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2568"
    ,"Station_Code":"Q1 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Nhà Thờ Đức Bà"
    ,"Station_Address":"1, đường Công xã Paris, Quận 1"
    ,"Lat":10.779233
    ,"Long":106.699154
    ,"Polyline":"[106.69519806,10.78315926] ; [106.69561768,10.78297424] ; [106.69549561,10.78266811] ; [106.69561768,10.78238392] ; [106.69589996,10.78225708] ; [106.69618988,10.78236294] ; [106.69850922,10.78029728] ; [106.69847870,10.78009701] ; [106.69858551,10.77990723] ; [106.69901276,10.77947521] ; [106.69915771,10.77923298]"
    ,"Distance":"676"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2771"
    ,"Station_Code":"Q1 159"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Pasteur"
    ,"Station_Address":"84, đường Nguyễn Du, Quận 1"
    ,"Lat":10.77831
    ,"Long":106.699192
    ,"Polyline":"[106.69915771,10.77923298] ; [106.69977570,10.77882671] ; [106.69918823,10.77830982]"
    ,"Distance":"168"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2774"
    ,"Station_Code":"Q1 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Nam Kỳ Khởi Nghĩa"
    ,"Station_Address":"100 , đường Nguyễn Du, Quận 1"
    ,"Lat":10.777256
    ,"Long":106.698259
    ,"Polyline":"[106.69918823,10.77830982] ; [106.69825745,10.77725601]"
    ,"Distance":"155"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"200"
    ,"Station_Code":"Q1 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Tòa Án Thành Phố"
    ,"Station_Address":"131, đường Nam  Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.776052
    ,"Long":106.698647
    ,"Polyline":"[106.69825745,10.77725601] ; [106.69800568,10.77680302] ; [106.69864655,10.77605247]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"199"
    ,"Station_Code":"Q1 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Chùa Ông"
    ,"Station_Address":"Đối diện 96A, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.773957
    ,"Long":106.699722
    ,"Polyline":"[106.69864655,10.77605247] ; [106.69889832,10.77597618] ; [106.69909668,10.77581978] ; [106.69954681,10.77466011] ; [106.69970703,10.77428913] ; [106.69972229,10.77395725]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2773"
    ,"Station_Code":"Q1 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bệnh viện Đa khoa Sài Gòn"
    ,"Station_Address":"108, đường Lê Lợi, Quận 1"
    ,"Lat":10.772507
    ,"Long":106.698952
    ,"Polyline":"[106.69972229,10.77395725] ; [106.69993591,10.77371025] ; [106.70002747,10.77346039] ; [106.69983673,10.77326012] ; [106.69946289,10.77280903] ; [106.69895172,10.77250671]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến Thành A"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69895172,10.77250671] ; [106.69902039,10.77243996] ; [106.69883728,10.77225971] ; [106.69863129,10.77203369] ; [106.69824982,10.77184010.06.69815826] ; [10.77176952,106.69803619] ; [10.77159977,106.69802094] ; [10.77138042,106.69805908] ; [10.77128983,106.69812775] ; [10.77122021,106.69818878] ; [10.77118015,106.69828796] ; [10.77116966,106.69840240] ; [10.77116966,106.69850159] ; [10.77120018,106.69860077] ; [10.77124977,106.69898224] ; [10.77095985,106.69879150] ; [10.77097034,106.69854736] ; [10.77087021,106.69853973]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Trường Ernst  Thalmann"
    ,"Station_Address":"Đối diện 103,  đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853973,10.77089596] ; [106.69595337,10.76980972]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt S ài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.69238281,10.76828003] ; [106.68976593,10.76723862] ; [106.68936157,10.76767635]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe bu ýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68921661,10.76812363] ; [106.69033813,10.76855087]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đ ối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"38"
    ,"Station_Code":"Q1TC1D"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành  D"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770603
    ,"Long":106.698441
    ,"Polyline":"[106.69673920,10.77118874] ; [106.69673157,10.77120972] ; [106.69728088,10.77136993] ; [106.69783783,10.77157021] ; [106.69803619,10.77151203] ; [106.69813538,10.77126980] ; [106.69827271,10.77114868] ; [106.69856262,10.77113247] ; [106.69882965,10.77111721] ; [106.69899750,10.77094841] ; [106.69917297,10.77063751] ; [106.69928741,10.77045345] ; [106.69913483,10.77029991] ; [106.69873810,10.76995754] ; [106.69836426,10.76964664] ; [106.69812012,10.76940441] ; [106.69774628,10.76986790] ; [106.69747162,10.77022076] ; [106.69785309,10.77033138] ; [106.69843292,10.77062035] ; [106.69844055,10.77060318]"
    ,"Distance":"759"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2721"
    ,"Station_Code":"Q1 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bệnh viện Đa khoa Sài Gòn"
    ,"Station_Address":"125, đường Lê Lợi, Quận 1"
    ,"Lat":10.772139
    ,"Long":106.699219
    ,"Polyline":"[106.69844055,10.77060318] ; [106.69900513,10.77083206] ; [106.69898224,10.77119637] ; [106.69885254,10.77152252] ; [106.69882965,10.77170753] ; [106.69898987,10.77199173] ; [106.69921875,10.77213860]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2723"
    ,"Station_Code":"Q1 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Sài Gòn Centre"
    ,"Station_Address":"Đối diện 58, đường Lê Lợi, Quận 1"
    ,"Lat":10.773594
    ,"Long":106.700587
    ,"Polyline":"[106.69921875,10.77213860] ; [106.70058441,10.77359390]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2724"
    ,"Station_Code":"Q1 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Lê Thánh Tôn"
    ,"Station_Address":"144, đường Pasteur, Quận 1"
    ,"Lat":10.775088
    ,"Long":106.700768
    ,"Polyline":"[106.70058441,10.77359390] ; [106.70109558,10.77425766] ; [106.70076752,10.77508831]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"4272"
    ,"Station_Code":"Q1 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Lý Tự Trọng"
    ,"Station_Address":"158, đường Pasteur, Quận 1"
    ,"Lat":10.777089
    ,"Long":106.699657
    ,"Polyline":"[106.70076752,10.77508831] ; [106.70076752,10.77508831] ; [106.70048523,10.77563858] ; [106.70024109,10.77618694] ; [106.69995117,10.77681923] ; [106.69965363,10.77708912] ; [106.69965363,10.77708912]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"4273"
    ,"Station_Code":"Q1 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công viên 30/4"
    ,"Station_Address":"178, đ ường Pasteur, Quận 1"
    ,"Lat":10.778307999999999
    ,"Long":106.698333
    ,"Polyline":"[106.69965363,10.77708912] ; [106.69833374,10.77830791]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2706"
    ,"Station_Code":"Q3 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đại học Kinh  tế"
    ,"Station_Address":"18Bis, đường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.784012
    ,"Long":106.694573
    ,"Polyline":"[106.69833374,10.77830791] ; [106.69744110,10.77910042] ; [106.69832611,10.78000164] ; [106.69847107,10.78010178] ; [106.69858551,10.78006554] ; [106.69868469,10.78009129] ; [106.69873047,10.78019714] ; [106.69866943,10.78030777] ; [106.69858551,10.78033352] ; [106.69850159,10.78032303] ; [106.69646454,10.78212547] ; [106.69621277,10.78237343] ; [106.69631958,10.78252125] ; [106.69637299,10.78266335] ; [106.69633484,10.78285789] ; [106.69620514,10.78301048] ; [106.69606781,10.78308487] ; [106.69590759,10.78310585] ; [106.69577026,10.78307915] ; [106.69561005,10.78297901] ; [106.69457245,10.78401184]"
    ,"Distance":"1013"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2707"
    ,"Station_Code":"Q3 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"42, đường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.785135
    ,"Long":106.693318
    ,"Polyline":"[106.69457245,10.78401184] ; [106.69332123,10.78513527]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"43"
    ,"Station_Code":"Q1 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Công viên Lê Văn Tám"
    ,"Station_Address":"Đối diện 245, đường Hai Bà Tr ưng, Quận 1"
    ,"Lat":10.787427
    ,"Long":106.692599
    ,"Polyline":"[106.69332123,10.78513527] ; [106.69282532,10.78555584] ; [106.69371796,10.78655720] ; [106.69259644,10.78742695]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"46"
    ,"Station_Code":"Q1 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà thờ Tân Định"
    ,"Station_Address":"298, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.789215
    ,"Long":106.690399
    ,"Polyline":"[106.69259644,10.78742695] ; [106.69039917,10.78921509]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"47"
    ,"Station_Code":"Q1 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Tân Định"
    ,"Station_Address":"372-374, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.790456
    ,"Long":106.688843
    ,"Polyline":"[106.69039917,10.78921509] ; [106.68998718,10.78942966] ; [106.68884277,10.79045582]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2728"
    ,"Station_Code":"Q1 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bà Lê Chân"
    ,"Station_Address":"151Bis, đường Trần Quang Kh ải, Quận 1"
    ,"Lat":10.79162
    ,"Long":106.690231
    ,"Polyline":"[106.68884277,10.79045582] ; [106.68772888,10.79133129] ; [106.69013214,10.79168987] ; [106.69023132,10.79162025]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2726"
    ,"Station_Code":"Q1 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Dakao"
    ,"Station_Address":"45-47 , đường Trần Quang Khải, Quận 1"
    ,"Lat":10.79239
    ,"Long":106.694878
    ,"Polyline":"[106.69023132,10.79162025] ; [106.69033813,10.79172134] ; [106.69467163,10.79245949] ; [106.69487762,10.79238987]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2033"
    ,"Station_Code":"QBTH 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"96, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.796032
    ,"Long":106.696225
    ,"Polyline":"[106.69487762,10.79238987] ; [106.69498444,10.79254341] ; [106.69592285,10.79270172] ; [106.69622803,10.79603195]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2727"
    ,"Station_Code":"QBTH 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"114, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.798066
    ,"Long":106.696376
    ,"Polyline":"[106.69622803,10.79603195] ; [106.69637299,10.79806614]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2109"
    ,"Station_Code":"QBTH 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"Đối diện 129, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.80147
    ,"Long":106.696569
    ,"Polyline":"[106.69637299,10.79806614] ; [106.69657135,10.80146980]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"UBND Quận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69657135,10.80146980] ; [106.69661713,10.80268192] ; [106.69578552,10.80281925]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2039"
    ,"Station_Code":"QBTH 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"2, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803488
    ,"Long":106.695013
    ,"Polyline":"[106.69578552,10.80281925] ; [106.69493103,10.80288219] ; [106.69501495,10.80348778]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2035"
    ,"Station_Code":"QBTH 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"48, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.806076
    ,"Long":106.695083
    ,"Polyline":"[106.69501495,10.80348778] ; [106.69508362,10.80607605]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1650"
    ,"Station_Code":"QBTH 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà thờ Bình Hòa"
    ,"Station_Address":"124, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.809732
    ,"Long":106.695158
    ,"Polyline":"[106.69508362,10.80607605] ; [106.69515991,10.80973244]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1654"
    ,"Station_Code":"QBTH 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Phan Văn Trị"
    ,"Station_Address":"182B/2, đường  Phan Văn Trị, Quận Bình Thạnh"
    ,"Lat":10.812722
    ,"Long":106.695343
    ,"Polyline":"[106.69515991,10.80973244] ; [106.69518280,10.81048107] ; [106.69544220,10.81123924] ; [106.69532776,10.81149197] ; [106.69534302,10.81272221]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1652"
    ,"Station_Code":"QBTH 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chùa Giác  Quang"
    ,"Station_Address":"342, đường Phan V ăn Trị, Quận Bình Thạnh"
    ,"Lat":10.819601
    ,"Long":106.694536
    ,"Polyline":"[106.69534302,10.81272221] ; [106.69522858,10.81621361] ; [106.69531250,10.81720448] ; [106.69522858,10.81767845] ; [106.69485474,10.81857395] ; [106.69453430,10.81960106]"
    ,"Distance":"781"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"6853"
    ,"Station_Code":"QGV 196"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Phan Văn Trị"
    ,"Station_Address":"39, đường Phạm Văn Đồng, Quận Gò Vấp"
    ,"Lat":10.820618
    ,"Long":106.693372
    ,"Polyline":"[106.69453430,10.81960106.06.69434357] ; [10.81999683,106.69420624] ; [10.82033920,106.69425964] ; [10.82044983,106.69429016] ; [10.82053375,106.69428253] ; [10.82062912,106.69425964] ; [10.82068729,106.69419098] ; [10.82075024,106.69409943] ; [10.82075500,106.69401550] ; [10.82074451,106.69359589] ; [10.82063389,106.69337463]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2046"
    ,"Station_Code":"QGV 152"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường  Đại học Công nghiệp"
    ,"Station_Address":"28, đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.821646
    ,"Long":106.688759
    ,"Polyline":"[106.69337463,10.82061768] ; [106.69268799,10.82036591] ; [106.69000244,10.81961727] ; [106.69002533,10.81977558] ; [106.68997192,10.81996536] ; [106.68982697,10.82015514] ; [106.68949890,10.82047653] ; [106.68914795,10.82075500] ; [106.68899536,10.82102394] ; [106.68892670,10.82118702] ; [106.68878937,10.82149792] ; [106.68875885,10.82164574]"
    ,"Distance":"660"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"462"
    ,"Station_Code":"QGV 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"UBND Phường 5, Quận Gò Vấp"
    ,"Station_Address":"396, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.82507
    ,"Long":106.687881
    ,"Polyline":"[106.68875885,10.82164574] ; [106.68867493,10.82170868] ; [106.68833160,10.82238388] ; [106.68793488,10.82313728] ; [106.68746948,10.82352161] ; [106.68654633,10.82417011] ; [106.68694305,10.82463837] ; [106.68773651,10.82508087] ; [106.68788147,10.82507038]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2729"
    ,"Station_Code":"QGV 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã Tư Nguyễn Thái Sơn"
    ,"Station_Address":"12, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.827015
    ,"Long":106.68864
    ,"Polyline":"[106.68788147,10.82507038] ; [106.68788147,10.82507038] ; [106.68793488,10.82520199] ; [106.68878174,10.82572937] ; [106.68935394,10.82628822] ; [106.68922424,10.82642460] ; [106.68914032,10.82653522]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2731"
    ,"Station_Code":"QGV 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"PCCC Quận Gò Vấp"
    ,"Station_Address":"16B, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.828654
    ,"Long":106.68474
    ,"Polyline":"[106.68914032,10.82653522] ; [106.68794250,10.82754230] ; [106.68473816,10.82865429]"
    ,"Distance":"544"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2730"
    ,"Station_Code":"QGV 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã Ba Nguyễn Huy Điển"
    ,"Station_Address":"30D, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.829644
    ,"Long":106.681516
    ,"Polyline":"[106.68473816,10.82865429] ; [106.68151855,10.82964420]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2733"
    ,"Station_Code":"QGV 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Patin Z751"
    ,"Station_Address":"596, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.830519
    ,"Long":106.678877
    ,"Polyline":"[106.68151855,10.82964420] ; [106.68103027,10.82976246] ; [106.67903900,10.83047104]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2732"
    ,"Station_Code":"QGV 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Nhà máy  Z751"
    ,"Station_Address":"2A, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.831494
    ,"Long":106.67605
    ,"Polyline":"[106.67903900,10.83047104] ; [106.67797089,10.83079529] ; [106.67698669,10.83113480] ; [106.67596436,10.83154106]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2734"
    ,"Station_Code":"QGV 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Xí nghiệp Z751"
    ,"Station_Address":"670, đ ường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.832948
    ,"Long":106.67201
    ,"Polyline":"[106.67596436,10.83154106.06.67507172]"
    ,"Distance":"103"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2737"
    ,"Station_Code":"QGV 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã Ba Tân  Thông Hội"
    ,"Station_Address":"Đối diện 1287, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.833754
    ,"Long":106.6698
    ,"Polyline":"[106.67507172,10.83184147] ; [106.67210388,10.83287430] ; [106.66979980,10.83375359]"
    ,"Distance":"615"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2735"
    ,"Station_Code":"QGV 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Chợ Thông Tây"
    ,"Station_Address":"676, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.834723
    ,"Long":106.66714
    ,"Polyline":"[106.66979980,10.83375359] ; [106.66903687,10.83398056] ; [106.66713715,10.83472347]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2738"
    ,"Station_Code":"QGV 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Chợ Thông Tây"
    ,"Station_Address":"214, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.83603
    ,"Long":106.664785
    ,"Polyline":"[106.66713715,10.83472347] ; [106.66471863,10.83545589] ; [106.66465759,10.83562469] ; [106.66471863,10.83597755] ; [106.66478729,10.83603001]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2736"
    ,"Station_Code":"QGV 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Ngã Ba Nguyễn Văn Lượng"
    ,"Station_Address":"308, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.838159
    ,"Long":106.66523
    ,"Polyline":"[106.66478729,10.83603001] ; [106.66526794,10.83833790]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"4744"
    ,"Station_Code":"QGV 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ủy ban nhân dân phường 16"
    ,"Station_Address":"328 , đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.842031
    ,"Long":106.664844
    ,"Polyline":"[106.66526794,10.83833790] ; [106.66533661,10.83973408] ; [106.66509247,10.84023952] ; [106.66493988,10.84079838] ; [106.66494751,10.84127235]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2741"
    ,"Station_Code":"QGV 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Đại học H ồng Bàng"
    ,"Station_Address":"452, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.845435
    ,"Long":106.664844
    ,"Polyline":"[106.66494751,10.84127235] ; [106.66469574,10.84236813] ; [106.66467285,10.84354877] ; [106.66484070,10.84543514]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"4726"
    ,"Station_Code":"QGV 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Nhà thờ Hà Đông"
    ,"Station_Address":"687, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.848922
    ,"Long":106.664822
    ,"Polyline":"[106.66484070,10.84543514] ; [106.66455078,10.84748936] ; [106.66458893,10.84826946] ; [106.66482544,10.84892178]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2632"
    ,"Station_Code":"QGV 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Nhà Thờ Thái Bình"
    ,"Station_Address":"716, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.852805
    ,"Long":106.665466
    ,"Polyline":"[106.66482544,10.84892178] ; [106.66546631,10.85280514]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2633"
    ,"Station_Code":"QGV 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Nhà thờ Hợp An"
    ,"Station_Address":"671, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.853848
    ,"Long":106.66435
    ,"Polyline":"[106.66546631,10.85280514] ; [106.66551208,10.85392761] ; [106.66548920,10.85419655] ; [106.66435242,10.85384846]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"4738"
    ,"Station_Code":"QGV 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Trường Lê Thị Hồng Gấm"
    ,"Station_Address":"545, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.8527
    ,"Long":106.661078
    ,"Polyline":"[106.66435242,10.85384846] ; [106.66107941,10.85270023]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2743"
    ,"Station_Code":"QGV 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Cầu Cụt"
    ,"Station_Address":"1292, đường Lê Đức Thọ, Qu ận Gò Vấp"
    ,"Lat":10.854739
    ,"Long":106.656459
    ,"Polyline":"[106.66107941,10.85270023] ; [106.66056061,10.85250473] ; [106.65782928,10.85387516] ; [106.65645599,10.85473919]"
    ,"Distance":"574"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2742"
    ,"Station_Code":"QGV 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Nhà thờ Nữ Vương Hòa Bình"
    ,"Station_Address":"Nhà thờ Nữ Vương Hòa Binh, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.856788
    ,"Long":106.654142
    ,"Polyline":"[106.65645599,10.85473919] ; [106.65586090,10.85511780] ; [106.65530396,10.85576057] ; [106.65414429,10.85678768]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1670"
    ,"Station_Code":"Q12 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Metro Hiệp Phú"
    ,"Station_Address":"48, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.863513
    ,"Long":106.649757
    ,"Polyline":"[106.65414429,10.85678768] ; [106.65233612,10.85843754] ; [106.65055084,10.86013317] ; [106.64991760,10.86082935] ; [106.64982605,10.86125088] ; [106.64975739,10.86351299]"
    ,"Distance":"945"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1669"
    ,"Station_Code":"Q12 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Công ty  bia Tiger"
    ,"Station_Address":"Công ty bia Tiger, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.868094
    ,"Long":106.649555
    ,"Polyline":"[106.64975739,10.86351299] ; [106.64975739,10.86351299] ; [106.64968109,10.86421108] ; [106.64948273,10.86488533] ; [106.64957428,10.86561298] ; [106.64955139,10.86809444] ; [106.64955139,10.86809444]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1674"
    ,"Station_Code":"Q12 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Bảo hiểm xã hội Quận 12"
    ,"Station_Address":"270, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.872066
    ,"Long":106.649335
    ,"Polyline":"[106.64955139,10.86809444] ; [106.64937592,10.87005901] ; [106.64933777,10.87206554]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"1671"
    ,"Station_Code":"Q12 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"UBND phường Thới An"
    ,"Station_Address":"U ̉y ban nhân dan P.Thới An, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.874247
    ,"Long":106.649238
    ,"Polyline":"[106.64933777,10.87206554] ; [106.64923859,10.87424660]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"57"
    ,"Station_Id":"2745"
    ,"Station_Code":"BX35"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Bãi xe buýt Thới An"
    ,"Station_Address":"BÃI XE THỚI AN, đường Lê Văn Khương, Quận 12"
    ,"Lat":10.878466606140137
    ,"Long":106.64797973632812
    ,"Polyline":"[106.64923859,10.87424660] ; [106.64894104,10.87850857] ; [106.64797974,10.87846661]"
    ,"Distance":"581"
  }]