export const Route79 =[
  {
     "Route_Id":"79"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận  12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"976"
    ,"Station_Code":"Q12 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đá hoa cương Hoà Thắng"
    ,"Station_Address":"96/2, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.86193
    ,"Long":106.675143
    ,"Polyline":"[106.67832947,10.86166954] ; [106.67665863,10.86178017] ; [106.67514038,10.86182976]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"964"
    ,"Station_Code":"Q12 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Tô Ngọc Vân"
    ,"Station_Address":"972, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861904
    ,"Long":106.671935
    ,"Polyline":"[106.67514038,10.86182976] ; [106.67433929,10.86184025] ; [106.67260742,10.86182022] ; [106.67252350,10.86182022]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"937"
    ,"Station_Code":"Q12 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây xăng Th ạnh Xuân"
    ,"Station_Address":"Cây xăng Thạnh Xuân, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861577
    ,"Long":106.671882
    ,"Polyline":"[106.67252350,10.86182022] ; [106.67125702,10.86178970] ; [106.67125702,10.86166000] ; [106.67188263,10.86166954]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"938"
    ,"Station_Code":"Q12 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu Cả Bốn"
    ,"Station_Address":"109, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861619
    ,"Long":106.674446
    ,"Polyline":"[106.67188263,10.86166954] ; [106.67445374,10.86170006]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"944"
    ,"Station_Code":"Q12 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Bến xe Ng ã tư Ga"
    ,"Station_Address":"Đối diện Bx Ngã tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861472
    ,"Long":106.678078
    ,"Polyline":"[106.67445374,10.86170006] ; [106.67534637,10.86168957] ; [106.67703247,10.86161041] ; [106.67807770,10.86153984]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"213"
    ,"Station_Code":"Q12 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã tư Ga"
    ,"Station_Address":"154, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.857331
    ,"Long":106.679907
    ,"Polyline":"[106.67807770,10.86153984] ; [106.67899323,10.86147976] ; [106.67917633,10.86133957] ; [106.67922974,10.86122990] ; [106.67923737,10.86112022] ; [106.67922211,10.86050987] ; [106.67913818,10.85939980] ; [106.67913818,10.85900974] ; [106.67917633,10.85890007] ; [106.67925262,10.85879993] ; [106.67935181,10.85873985] ; [106.67958069,10.85867023] ; [106.67967224,10.85859966] ; [106.67980957,10.85840988] ; [106.67986298,10.85826969] ; [106.67980957,10.85789967] ; [106.67977142,10.85760021] ; [106.67935181,10.85433960]"
    ,"Distance":"948"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"209"
    ,"Station_Code":"QGV 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu An Lộc"
    ,"Station_Address":"521, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.84862
    ,"Long":106.678535
    ,"Polyline":"[106.67935181,10.85433960] ; [106.67900848,10.85216999] ; [106.67874908,10.85031033] ; [106.67865753,10.84939003] ; [106.67861176,10.84860992]"
    ,"Distance":"643"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"210"
    ,"Station_Code":"QGV 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"451 , đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.847015
    ,"Long":106.67826
    ,"Polyline":"[106.67861176,10.84860992] ; [106.67855072,10.84794998] ; [106.67851257,10.84753990] ; [106.67839813,10.84704018] ; [106.67839050,10.84700012]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"212"
    ,"Station_Code":"QGV 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Bưu điện An  Nhơn"
    ,"Station_Address":"357, đường Nguyễn  Oanh, Quận Gò Vấp"
    ,"Lat":10.843833
    ,"Long":106.677139
    ,"Polyline":"[106.67839050,10.84700012] ; [106.67726135,10.84381962]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"214"
    ,"Station_Code":"QGV 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã Tư An Nhơn"
    ,"Station_Address":"257, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.84142
    ,"Long":106.67634
    ,"Polyline":"[106.67726135,10.84381962] ; [106.67640686,10.84142017]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"215"
    ,"Station_Code":"QGV 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"197, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.839502
    ,"Long":106.675723
    ,"Polyline":"[106.67640686,10.84142017] ; [106.67578888,10.83950996]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"216"
    ,"Station_Code":"QGV 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường Vinhempic"
    ,"Station_Address":"189 (đối diện F5), đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.836852
    ,"Long":106.675461
    ,"Polyline":"[106.67578888,10.83950996] ; [106.67565918,10.83907986] ; [106.67550659,10.83860970] ; [106.67550659,10.83852959] ; [106.67549896,10.83800983] ; [106.67549896,10.83778000] ; [106.67550659,10.83685017]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"218"
    ,"Station_Code":"QGV 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cư xá Lam Sơn"
    ,"Station_Address":"189 (đối diện A4), đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.834787
    ,"Long":106.675631
    ,"Polyline":"[106.67550659,10.83685017] ; [106.67552185,10.83586979] ; [106.67552185,10.83567047] ; [106.67556000,10.83526993] ; [106.67569733,10.83481979]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"217"
    ,"Station_Code":"QGV 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã Tư Phan Văn Trị"
    ,"Station_Address":"93 (2A), đường Nguyễn Oanh, Qu ận Gò Vấp"
    ,"Lat":10.831594
    ,"Long":106.676895
    ,"Polyline":"[106.67569733,10.83481979] ; [106.67652130,10.83273029] ; [106.67675018,10.83207035] ; [106.67694855,10.83174992] ; [106.67700958,10.83166981]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"220"
    ,"Station_Code":"QGV 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"27, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.827205
    ,"Long":106.679606
    ,"Polyline":"[106.67700958,10.83166981] ; [106.67775726,10.83059025] ; [106.67830658,10.82975006] ; [106.67932892,10.82789040]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"219"
    ,"Station_Code":"QGV 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Siêu Th ị Big C Gò Vấp"
    ,"Station_Address":"Đối diện Big C, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.825682
    ,"Long":106.679606
    ,"Polyline":"[106.67932892,10.82789040] ; [106.67987061,10.82691956] ; [106.67990112,10.82660007] ; [106.67987061,10.82658005] ; [106.67984009,10.82651997] ; [106.67984009,10.82645035] ; [106.67989349,10.82637978] ; [106.67990875,10.82635975] ; [106.67991638,10.82618046] ; [106.67989349,10.82608986] ; [106.67977142,10.82577038]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"222"
    ,"Station_Code":"QGV 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Xóm Cháy"
    ,"Station_Address":"629B, đường Nguy ễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.821751
    ,"Long":106.678764
    ,"Polyline":"[106.67977142,10.82577038] ; [106.67936707,10.82478046] ; [106.67925262,10.82439995] ; [106.67902374,10.82351971] ; [106.67893219,10.82271957] ; [106.67887115,10.82174969]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"221"
    ,"Station_Code":"QGV 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"151, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.818837
    ,"Long":106.678719
    ,"Polyline":"[106.67887115,10.82174969] ; [106.67881775,10.82075024] ; [106.67880249,10.81968975] ; [106.67877960,10.81884003]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"223"
    ,"Station_Code":"QGV 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Tân  Sơn Nhất"
    ,"Station_Address":"37 - 39, đường  Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.815118
    ,"Long":106.678619
    ,"Polyline":"[106.67877960,10.81884003] ; [106.67870331,10.81511974]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"224"
    ,"Station_Code":"QPN 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đầu công viên Gia Định"
    ,"Station_Address":"Đối diện cây  xanh số 7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.813568
    ,"Long":106.677868
    ,"Polyline":"[106.67870331,10.81511974] ; [106.67870331,10.81424046] ; [106.67857361,10.81416988] ; [106.67845917,10.81406975] ; [106.67833710,10.81389046] ; [106.67826843,10.81377029] ; [106.67803955,10.81352043]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"225"
    ,"Station_Code":"QPN 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cuối công viên Gia Định"
    ,"Station_Address":"Đối diện số 5, đường Hoàng Minh Giám, Quận Phú Nhu ận"
    ,"Lat":10.809764
    ,"Long":106.674591
    ,"Polyline":"[106.67803955,10.81352043] ; [106.67598724,10.81120014] ; [106.67537689,10.81046963] ; [106.67472839,10.80969048]"
    ,"Distance":"559"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1772"
    ,"Station_Code":"QPN 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường ĐH Kỹ Thuật Công nghệ"
    ,"Station_Address":"199, đường Ph ổ Quang, Quận Phú Nhuận"
    ,"Lat":10.808513
    ,"Long":106.671967
    ,"Polyline":"[106.67472839,10.80969048] ; [106.67362976,10.80832958] ; [106.67343903,10.80807972] ; [106.67292786,10.80793953] ; [106.67283630,10.80792046] ; [106.67273712,10.80795002] ; [106.67192841,10.80846024]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1773"
    ,"Station_Code":"QTB 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Cây xăng Quân đội"
    ,"Station_Address":"75, đường Ph ổ Quang, Quận Tân Bình"
    ,"Lat":10.807467
    ,"Long":106.668422
    ,"Polyline":"[106.67192841,10.80846024] ; [106.67153168,10.80862045] ; [106.67124176,10.80865002] ; [106.66889954,10.80873966] ; [106.66874695,10.80871010.06.66867065] ; [10.80860043,106.66847992]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1775"
    ,"Station_Code":"QTB 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Trung tâm sát hạch lái xe"
    ,"Station_Address":"Công ty Waseco, đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.805359
    ,"Long":106.666555
    ,"Polyline":"[106.66847992,10.80747032] ; [106.66822052,10.80595970] ; [106.66816711,10.80591965] ; [106.66809082,10.80591011] ; [106.66696930,10.80607033] ; [106.66687012,10.80605984] ; [106.66680145,10.80597973] ; [106.66667938,10.80550957]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1774"
    ,"Station_Code":"QTB 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Rạp Tân Sơn Nhất"
    ,"Station_Address":"Rạp Tân Sơn Nhất, đường Phổ Quang, Qu ận Tân Bình"
    ,"Lat":10.802321
    ,"Long":106.665756
    ,"Polyline":"[106.66667938,10.80550957] ; [106.66648865,10.80478954] ; [106.66636658,10.80438995] ; [106.66597748,10.80294037] ; [106.66580963,10.80230999]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"911"
    ,"Station_Code":"QTB 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Quán Vườn Dừa"
    ,"Station_Address":"12 (1A), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.803641
    ,"Long":106.664909
    ,"Polyline":"[106.66580963,10.80230999] ; [106.66577148,10.80216980] ; [106.66570282,10.80210972] ; [106.66560364,10.80208969] ; [106.66548920,10.80210018] ; [106.66536713,10.80214024] ; [106.66512299,10.80274963] ; [106.66490173,10.80338001] ; [106.66484070,10.80362034]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"999"
    ,"Station_Code":"QTB 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trần Quốc Hoàn"
    ,"Station_Address":"71, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.803644
    ,"Long":106.663925
    ,"Polyline":"[106.66484070,10.80362034] ; [106.66458893,10.80480003] ; [106.66429138,10.80480003] ; [106.66426086,10.80459023] ; [106.66416168,10.80416965] ; [106.66398621,10.80362034]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Tr ần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66398621,10.80362034] ; [106.66381073,10.80311012] ; [106.66355896,10.80266953] ; [106.66342163,10.80245972] ; [106.66262817,10.80158997] ; [106.66233826,10.80132008]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"600"
    ,"Station_Code":"QTB 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"216, đường Hoàng  Văn Thụ, Quận Tân Bình"
    ,"Lat":10.799836
    ,"Long":106.660385
    ,"Polyline":"[106.66233826,10.80132008] ; [106.66194153,10.80097008] ; [106.66169739,10.80080986] ; [106.66153717,10.80074024] ; [106.66104126,10.80060005] ; [106.66097260,10.80056000] ; [106.66088867,10.80049038] ; [106.66085815,10.80039024] ; [106.66087341,10.80027008] ; [106.66066742,10.79998016] ; [106.66039276,10.79981041]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"602"
    ,"Station_Code":"QTB 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Công an Quận Tân Bình"
    ,"Station_Address":"340H, đường Hoàng Văn Thụ, Quận Tân B ình"
    ,"Lat":10.796577
    ,"Long":106.656952
    ,"Polyline":"[106.66039276,10.79981041] ; [106.65973663,10.79918003] ; [106.65936279,10.79883003] ; [106.65850067,10.79796982] ; [106.65830231,10.79776001] ; [106.65699005,10.79652977]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đư ờng Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65699005,10.79652977] ; [106.65577698,10.79539013] ; [106.65515900,10.79603958]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62),  đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65515900,10.79603958] ; [106.65464783,10.79654980] ; [106.65390778,10.79584026]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Cây xăng d ầu"
    ,"Station_Address":"23, đường Xuân Hồng,  Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65390778,10.79584026] ; [106.65238190,10.79434013]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"605"
    ,"Station_Code":"QTB 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"733-739, đường Lý Thường Kiệt, Quận T ân Bình"
    ,"Lat":10.792122
    ,"Long":106.6528
    ,"Polyline":"[106.65238190,10.79434013] ; [106.65184021,10.79384041] ; [106.65178680,10.79374027] ; [106.65213776,10.79354954] ; [106.65337372,10.79290962] ; [106.65293884,10.79205990]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"608"
    ,"Station_Code":"QTB 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bệnh việnBệnh viện chỉnh hình và phục hồi  chức năng"
    ,"Station_Address":"589 , đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.788718
    ,"Long":106.652806
    ,"Polyline":"[106.65293884,10.79205990] ; [106.65270996,10.79156017] ; [106.65261841,10.79131985] ; [106.65251160,10.79090977] ; [106.65248108,10.79076004] ; [106.65270996,10.78975964] ; [106.65292358,10.78899002]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"607"
    ,"Station_Code":"QTB 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chợ Tân Bình"
    ,"Station_Address":"Chợ Tân Bình, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.786131
    ,"Long":106.653584
    ,"Polyline":"[106.65292358,10.78899002] ; [106.65357208,10.78676987] ; [106.65373230,10.78617954]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"610"
    ,"Station_Code":"QTB 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Siêu thị Nguyễn Kim - CMC Tân Bình"
    ,"Station_Address":"79B (siêu thị CMC Tân Bình), đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.782695
    ,"Long":106.654571
    ,"Polyline":"[106.65373230,10.78617954] ; [106.65422821,10.78431988] ; [106.65469360,10.78273010]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"609"
    ,"Station_Code":"QTB 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trường Nguyễn Thái Bình"
    ,"Station_Address":"349 (74), đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.779233
    ,"Long":106.655609
    ,"Polyline":"[106.65469360,10.78273010.06.65511322] ; [10.78122997,106.65537262] ; [10.78038025,106.65567780]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"612"
    ,"Station_Code":"Q11 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bưu Đi ện Phú Thọ"
    ,"Station_Address":"285A, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.775314
    ,"Long":106.656693
    ,"Polyline":"[106.65567780,10.77925014] ; [106.65611267,10.77770996] ; [106.65643311,10.77651024] ; [106.65676117,10.77532959]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"611"
    ,"Station_Code":"Q11 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Đại Học Bách Khoa(cổng trước)"
    ,"Station_Address":"239, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.771331
    ,"Long":106.657829
    ,"Polyline":"[106.65676117,10.77532959] ; [106.65788269,10.77134037]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"900"
    ,"Station_Code":"Q10 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"BV Trưng Vương"
    ,"Station_Address":"531, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.770922
    ,"Long":106.658913
    ,"Polyline":"[106.65788269,10.77134037] ; [106.65815735,10.77038956] ; [106.65834045,10.77048016] ; [106.65885925,10.77095985]"
    ,"Distance":"210"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"898"
    ,"Station_Code":"Q10 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Đại Học Bách Khoa (cổng sau)"
    ,"Station_Address":"523, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.773046
    ,"Long":106.661057
    ,"Polyline":"[106.65885925,10.77095985] ; [106.66065216,10.77260971] ; [106.66101074,10.77307987]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"902"
    ,"Station_Code":"Q10 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngân hàng quân đội"
    ,"Station_Address":"405, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775549
    ,"Long":106.663017
    ,"Polyline":"[106.66101074,10.77307987] ; [106.66143036,10.77359009] ; [106.66175842,10.77402973] ; [106.66233826,10.77476025] ; [106.66294098,10.77560043]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"2835"
    ,"Station_Code":"Q10 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Quán Ho àng Ty"
    ,"Station_Address":"161, đường Thành Thái, Quận 10"
    ,"Lat":10.775075
    ,"Long":106.66407
    ,"Polyline":"[106.66294098,10.77560043] ; [106.66349030,10.77635956] ; [106.66355896,10.77641010.06.66384125] ; [10.77583027,106.66413116]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"2837"
    ,"Station_Code":"Q10 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"BV 115"
    ,"Station_Address":"69, đường Thành Thái, Quận  10"
    ,"Lat":10.773051
    ,"Long":106.664833
    ,"Polyline":"[106.66413116,10.77509975] ; [106.66445923,10.77418995] ; [106.66478729,10.77340984] ; [106.66490173,10.77307034]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"2840"
    ,"Station_Code":"Q10 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Nhà thờ Đồng Tiến"
    ,"Station_Address":"Đối diện 52, đường Thành Th ái, Quận 10"
    ,"Lat":10.770474
    ,"Long":106.665863
    ,"Polyline":"[106.66490173,10.77307034] ; [106.66536713,10.77180958] ; [106.66591644,10.77050018]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"564"
    ,"Station_Code":"Q10 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Học viện quân y"
    ,"Station_Address":"527 (257), đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.766769
    ,"Long":106.667259
    ,"Polyline":"[106.66591644,10.77050018] ; [106.66635132,10.76937962] ; [106.66712189,10.76770973] ; [106.66722107,10.76723003] ; [106.66732025,10.76679039]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"567"
    ,"Station_Code":"Q10 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Chợ Nhật Tảo"
    ,"Station_Address":"475, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.764991
    ,"Long":106.667664
    ,"Polyline":"[106.66732025,10.76679039] ; [106.66742706,10.76632977] ; [106.66757202,10.76566982] ; [106.66773224,10.76500988]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"570"
    ,"Station_Code":"Q10 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Trường Hoàng Văn Thụ"
    ,"Station_Address":"399, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.763371
    ,"Long":106.668015
    ,"Polyline":"[106.66773987,10.76496029] ; [106.66809082,10.76338959]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"571"
    ,"Station_Code":"Q10 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Đại học kinh tế"
    ,"Station_Address":"279, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.761049
    ,"Long":106.668488
    ,"Polyline":"[106.66809082,10.76338959] ; [106.66861725,10.76107979]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3340"
    ,"Station_Code":"Q5 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Trường Trần Khai Nguyên"
    ,"Station_Address":"225 , đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.758406
    ,"Long":106.669103
    ,"Polyline":"[106.66861725,10.76107979] ; [106.66886902,10.76000023] ; [106.66893005,10.76000023] ; [106.66902161,10.75994968] ; [106.66905212,10.75983047] ; [106.66902161,10.75977993] ; [106.66896820,10.75973988] ; [106.66895294,10.75973034] ; [106.66922760,10.75842953]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1981"
    ,"Station_Code":"Q5 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Bệnh vi ện Nguyễn Tri Phương"
    ,"Station_Address":"161, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.755728
    ,"Long":106.669473
    ,"Polyline":"[106.66922760,10.75842953] ; [106.66941071,10.75765038] ; [106.66954803,10.75667000] ; [106.66953278,10.75572968]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"11"
    ,"Station_Code":"Q5 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Siêu thị Điện máy"
    ,"Station_Address":"99, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.754023
    ,"Long":106.669418
    ,"Polyline":"[106.66953278,10.75572968] ; [106.66951752,10.75401974]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"14"
    ,"Station_Code":"Q5 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Nhà Văn hóa Quận 5"
    ,"Station_Address":"388, đường Trần Phú, Quận 5"
    ,"Lat":10.753025
    ,"Long":106.668588
    ,"Polyline":"[106.66951752,10.75401974] ; [106.66951752,10.75345993] ; [106.66847992,10.75290966] ; [106.66840363,10.75286961]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1978"
    ,"Station_Code":"Q8 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Sân vận động Quận 8"
    ,"Station_Address":"302, đường Phạm Hùng, Quận 8"
    ,"Lat":10.74202
    ,"Long":106.668749
    ,"Polyline":"[106.66840363,10.75286961] ; [106.66847992,10.75290966] ; [106.66841125,10.75284958] ; [106.66837311,10.75279999] ; [106.66837311,10.75275993] ; [106.66842651,10.75269032] ; [106.66851807,10.75263977] ; [106.66945648,10.75271034] ; [106.66941833,10.75238037] ; [106.66938019,10.75148010.06.66931915] ; [10.75037003,106.66929626] ; [10.75010967,106.66918945] ; [10.74882030,106.66909790] ; [10.74794960,106.66893005] ; [10.74573040,106.66889191] ; [10.74477005,106.66887665] ; [10.74456024,106.66889954] ; [10.74219990,106.66889191]"
    ,"Distance":"1345"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3339"
    ,"Station_Code":"Q8 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Đường 1011"
    ,"Station_Address":"Đối diện 831, đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.736265
    ,"Long":106.669121
    ,"Polyline":"[106.66889191,10.74205017] ; [106.66890717,10.74092007] ; [106.66893768,10.74065018] ; [106.66899872,10.74030972] ; [106.66906738,10.74007034] ; [106.66921234,10.73974991] ; [106.66953278,10.73927021] ; [106.67070007,10.73768044] ; [106.67104340,10.73725033] ; [106.66937256,10.73635006] ; [106.66914368,10.73622036]"
    ,"Distance":"841"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3344"
    ,"Station_Code":"Q8 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Đường 1011"
    ,"Station_Address":"Đối diện 94, đường Đường 1011 , Quận 8"
    ,"Lat":10.73669
    ,"Long":106.667412
    ,"Polyline":"[106.66914368,10.73622036] ; [106.66786957,10.73556042] ; [106.66741180,10.73653984] ; [106.66735840,10.73666954]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3342"
    ,"Station_Code":"Q8 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Tòa án Quận 8"
    ,"Station_Address":"Tòa án Quận 8, đường Đường 1011, Quận 8"
    ,"Lat":10.741024
    ,"Long":106.666131
    ,"Polyline":"[106.66735840,10.73666954] ; [106.66722107,10.73698997] ; [106.66708374,10.73746014] ; [106.66681671,10.73830986] ; [106.66606903,10.74085999]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1459"
    ,"Station_Code":"Q8 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Quận ủy Quận 8"
    ,"Station_Address":"1228, đường Ph ạm Thế Hiển, Quận 8"
    ,"Lat":10.742252
    ,"Long":106.662987
    ,"Polyline":"[106.66606903,10.74085999] ; [106.66578674,10.74186039] ; [106.66561127,10.74262047] ; [106.66403198,10.74234009] ; [106.66316223,10.74221039]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1460"
    ,"Station_Code":"Q8 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Cầu Nhị Thiên Đường"
    ,"Station_Address":"1436, đường  Phạm Thế Hiển, Quận 8"
    ,"Lat":10.741562
    ,"Long":106.659173
    ,"Polyline":"[106.66316223,10.74221039] ; [106.66113281,10.74186993] ; [106.65898132,10.74143028]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"618"
    ,"Station_Code":"Q8 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Chùa Pháp Quang"
    ,"Station_Address":"100, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738642
    ,"Long":106.656142
    ,"Polyline":"[106.65898132,10.74143028] ; [106.65718079,10.74106026] ; [106.65695953,10.74104977] ; [106.65667725,10.74114037] ; [106.65634918,10.74123001] ; [106.65621948,10.74120998] ; [106.65554810,10.74092960] ; [106.65498352,10.74065971] ; [106.65490723,10.74059963] ; [106.65486908,10.74046993] ; [106.65486908,10.74036026] ; [106.65492249,10.74026966] ; [106.65502167,10.74018955] ; [106.65509796,10.74001980] ; [106.65535736,10.73968983] ; [106.65560913,10.73939037] ; [106.65574646,10.73929977] ; [106.65588379,10.73927975] ; [106.65612793,10.73927021] ; [106.65612793,10.73919010.06.65617371] ; [10.73906040,106.65618134]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"619"
    ,"Station_Code":"Q8 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"224, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656126
    ,"Polyline":"[106.65618134,10.73884010.06.65619659] ; [10.73863983,106.65627289] ; [10.73851013,106.65627289] ; [10.73830986,106.65621948]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Bến xe Quận  8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường Quốc  lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":"[106.65621948,10.73653984] ; [106.65615082,10.73353958] ; [106.65609741,10.73313046] ; [106.65631866,10.73311043] ; [106.65682983,10.73311996] ; [106.65704346,10.73311996]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"502"
    ,"Station_Code":"Q8 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"193, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656346
    ,"Polyline":"[106.65704346,10.73311996] ; [106.65609741,10.73313046] ; [106.65615082,10.73353958] ; [106.65615845,10.73410034] ; [106.65619659,10.73571968]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"499"
    ,"Station_Code":"Q8 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Nhị Thiên Đường"
    ,"Station_Address":"81, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738769
    ,"Long":106.656427
    ,"Polyline":"[106.65619659,10.73571968] ; [106.65628052,10.73875046]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1427"
    ,"Station_Code":"Q8 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Hiệp Ân"
    ,"Station_Address":"1219, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.741409
    ,"Long":106.659254
    ,"Polyline":"[106.65628052,10.73875046] ; [106.65628815,10.73904037] ; [106.65628815,10.73923969] ; [106.65627289,10.73929024] ; [106.65622711,10.73931026] ; [106.65618134,10.73931026] ; [106.65612793,10.73927021] ; [106.65588379,10.73927975] ; [106.65574646,10.73929977] ; [106.65560913,10.73939037] ; [106.65535736,10.73968983] ; [106.65509796,10.74001980] ; [106.65502167,10.74018955] ; [106.65492249,10.74026966] ; [106.65486908,10.74036026] ; [106.65486908,10.74046993] ; [106.65490723,10.74059963] ; [106.65498352,10.74065971] ; [106.65554810,10.74092960] ; [106.65621948,10.74120998] ; [106.65634918,10.74123001] ; [106.65667725,10.74114037] ; [106.65695953,10.74104977] ; [106.65718079,10.74106026] ; [106.65911865,10.74145985] ; [106.65956879,10.74155045]"
    ,"Distance":"835"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1432"
    ,"Station_Code":"Q8 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Quận ủy Qu ận 8"
    ,"Station_Address":"1093, đường Phạm Thế Hiển, Quận 8"
    ,"Lat":10.74248
    ,"Long":106.664864
    ,"Polyline":"[106.65956879,10.74155045] ; [106.66113281,10.74186993] ; [106.66188812,10.74199963] ; [106.66403198,10.74234009] ; [106.66487885,10.74248981]"
    ,"Distance":"590"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3298"
    ,"Station_Code":"Q8 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"UBND Quận 8"
    ,"Station_Address":"UBND Quận 8,  đường Đường 1011, Quận 8"
    ,"Lat":10.740254
    ,"Long":106.666168
    ,"Polyline":"[106.66487885,10.74248981] ; [106.66561127,10.74262047] ; [106.66578674,10.74186039] ; [106.66615295,10.74059963] ; [106.66623688,10.74028015]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3299"
    ,"Station_Code":"Q8 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Tạ Quang Bửu"
    ,"Station_Address":"106, đường Đường 1011, Quận 8"
    ,"Lat":10.736481
    ,"Long":106.667366
    ,"Polyline":"[106.66623688,10.74028015] ; [106.66693878,10.73793030] ; [106.66722107,10.73698997] ; [106.66742706,10.73651028]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3300"
    ,"Station_Code":"Q8 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Phạm Hùng"
    ,"Station_Address":"833A-835, đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.735828
    ,"Long":106.668577
    ,"Polyline":"[106.66742706,10.73651028] ; [106.66786957,10.73556042] ; [106.66937256,10.73635006] ; [106.66950989,10.73641968]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"2078"
    ,"Station_Code":"Q8 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà thờ Nam Hải"
    ,"Station_Address":"4/12, đường Phạm Hùng, Quận 8"
    ,"Lat":10.737546
    ,"Long":106.670884
    ,"Polyline":"[106.66950989,10.73641968] ; [106.67104340,10.73725033] ; [106.67083740,10.73750019]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"2080"
    ,"Station_Code":"Q8 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Sân vận  động Quận 8"
    ,"Station_Address":"175, đường Phạm Hùng, Quận 8"
    ,"Lat":10.742432
    ,"Long":106.669044
    ,"Polyline":"[106.67083740,10.73750019] ; [106.66974640,10.73896027] ; [106.66938782,10.73948956] ; [106.66921234,10.73974991] ; [106.66915131,10.73989010.06.66899872] ; [10.74030972,106.66892242] ; [10.74073029,106.66889954] ; [10.74162960,106.66889954]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"2081"
    ,"Station_Code":"Q5 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu thị Điện máy"
    ,"Station_Address":"Đối diện 105, đường Nguyễn Tri Phương , Quận 5"
    ,"Lat":10.754163
    ,"Long":106.669661
    ,"Polyline":"[106.66889954,10.74190998] ; [106.66889191,10.74477005] ; [106.66893005,10.74573040] ; [106.66909790,10.74794960] ; [106.66919708,10.74884987] ; [106.66931152,10.75018978] ; [106.66938019,10.75148010.06.66941833] ; [10.75238037,106.66945648] ; [10.75271034,106.66951752] ; [10.75345993,106.66951752]"
    ,"Distance":"1367"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"2082"
    ,"Station_Code":"Q5 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh viện Nguyễn Tri Phương"
    ,"Station_Address":"Đối diện 153, đường Nguyễn Tri Phương , Quận 5"
    ,"Lat":10.755486
    ,"Long":106.669698
    ,"Polyline":"[106.66951752,10.75417042] ; [106.66953278,10.75549984]"
    ,"Distance":"148"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"432"
    ,"Station_Code":"Q5 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Công viên Văn Lang"
    ,"Station_Address":"132A, đường Nguyễn Tri Ph ương, Quận 5"
    ,"Lat":10.757151
    ,"Long":106.669613
    ,"Polyline":"[106.66953278,10.75549984] ; [106.66954803,10.75667000] ; [106.66947937,10.75714970]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"441"
    ,"Station_Code":"Q5 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường Trần Khai Nguyên"
    ,"Station_Address":"138G-138F, đường Nguyễn Tri Phương, Quận 5"
    ,"Lat":10.758706
    ,"Long":106.66928
    ,"Polyline":"[106.66947937,10.75714970] ; [106.66941071,10.75765038] ; [106.66931152,10.75800991] ; [106.66916656,10.75870037]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"442"
    ,"Station_Code":"Q10 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Đại học kinh tế"
    ,"Station_Address":"234-236, đường  Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.761386
    ,"Long":106.668564
    ,"Polyline":"[106.66916656,10.75870037] ; [106.66895294,10.75973034] ; [106.66896820,10.75973988] ; [106.66902161,10.75977993] ; [106.66905212,10.75983047] ; [106.66903687,10.75990009] ; [106.66898346,10.75998020] ; [106.66893005,10.76000023] ; [106.66886902,10.76000023] ; [106.66854095,10.76138020]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"444"
    ,"Station_Code":"Q10 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Hoàng Văn Thụ"
    ,"Station_Address":"336, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.763073
    ,"Long":106.668213
    ,"Polyline":"[106.66854095,10.76138020] ; [106.66815948,10.76305962]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"443"
    ,"Station_Code":"Q10 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Nhật Tảo"
    ,"Station_Address":"426, đường Nguyễn Tri Phương, Quận 10"
    ,"Lat":10.765397
    ,"Long":106.667702
    ,"Polyline":"[106.66815948,10.76305962] ; [106.66764069,10.76537991]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"446"
    ,"Station_Code":"Q10 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Học viện quân y"
    ,"Station_Address":"476, đường Nguyễn  Tri Phương, Quận 10"
    ,"Lat":10.767052
    ,"Long":106.667313
    ,"Polyline":"[106.66764069,10.76537991] ; [106.66748810,10.76601028] ; [106.66735840,10.76663971] ; [106.66725922,10.76704025]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3301"
    ,"Station_Code":"Q10 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà thờ Đồng Tiến"
    ,"Station_Address":"52, đường Thành Thái, Quận 10"
    ,"Lat":10.769878
    ,"Long":106.666237
    ,"Polyline":"[106.66725922,10.76704025] ; [106.66715240,10.76751041] ; [106.66712189,10.76770973] ; [106.66648865,10.76906967] ; [106.66618347,10.76986027]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3302"
    ,"Station_Code":"Q10 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"BV 115"
    ,"Station_Address":"520A, đường Thành Thái, Quận 10"
    ,"Lat":10.772676
    ,"Long":106.665108
    ,"Polyline":"[106.66618347,10.76986027] ; [106.66541290,10.77171993] ; [106.66510773,10.77247047] ; [106.66504669,10.77266026]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"3303"
    ,"Station_Code":"Q10 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Quán Hoàng Ty"
    ,"Station_Address":"166 (182), đường Thành Thái, Quận 10"
    ,"Lat":10.775486
    ,"Long":106.664032
    ,"Polyline":"[106.66504669,10.77266026] ; [106.66468811,10.77365017] ; [106.66452789,10.77404022] ; [106.66423035,10.77484989] ; [106.66397858,10.77546978]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1007"
    ,"Station_Code":"Q10 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngân h àng quân đội"
    ,"Station_Address":"136, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775531
    ,"Long":106.662819
    ,"Polyline":"[106.66397858,10.77546978] ; [106.66384125,10.77583027] ; [106.66355896,10.77641010.06.66349030] ; [10.77635956,106.66287231]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1013"
    ,"Station_Code":"Q10 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Đại Học Bách Khoa (cổng sau)"
    ,"Station_Address":"350 ( cũ 142), đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.773322
    ,"Long":106.661125
    ,"Polyline":"[106.66287231,10.77550030] ; [106.66233826,10.77476025] ; [106.66175842,10.77402973] ; [106.66143036,10.77359009] ; [106.66117096,10.77328014]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"1008"
    ,"Station_Code":"Q10 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"BV Trưng Vương"
    ,"Station_Address":"142 kios 37-38, đường Tô Hiến Thành, Qu ận 10"
    ,"Lat":10.771244
    ,"Long":106.659096
    ,"Polyline":"[106.66117096,10.77328014] ; [106.66065216,10.77260971] ; [106.66011047,10.77210999] ; [106.65912628,10.77120018]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"506"
    ,"Station_Code":"Q10 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Đại Học Bách Khoa"
    ,"Station_Address":"268 , đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.772603
    ,"Long":106.657698
    ,"Polyline":"[106.65912628,10.77120018] ; [106.65834045,10.77048016] ; [106.65815735,10.77038956] ; [106.65805054,10.77070999] ; [106.65769958,10.77202034] ; [106.65794373,10.77210999] ; [106.65772247,10.77248955] ; [106.65769958,10.77256012]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"547"
    ,"Station_Code":"Q10 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Bưu Điện Ph ú Thọ"
    ,"Station_Address":"270Bis, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.776487
    ,"Long":106.656625
    ,"Polyline":"[106.65769958,10.77256012] ; [106.65794373,10.77210999] ; [106.65769958,10.77202034] ; [106.65756989,10.77245045] ; [106.65743256,10.77291965] ; [106.65727997,10.77346992] ; [106.65670013,10.77554989] ; [106.65637207,10.77674961]"
    ,"Distance":"630"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"507"
    ,"Station_Code":"QTB 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã ba Thành Thái"
    ,"Station_Address":"270, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.778974
    ,"Long":106.655896
    ,"Polyline":"[106.65637207,10.77674961] ; [106.65611267,10.77770996] ; [106.65596008,10.77826023] ; [106.65576172,10.77898026]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"548"
    ,"Station_Code":"QTB 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Siêu thị Nguyễn Kim - CMC Tân Bình"
    ,"Station_Address":"320 (Quận đoàn Tân Bình),  đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.781072
    ,"Long":106.65529
    ,"Polyline":"[106.65576172,10.77898026] ; [106.65537262,10.78038025] ; [106.65514374,10.78112030]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"551"
    ,"Station_Code":"QTB 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm C ây xăng số 9"
    ,"Station_Address":"151A, đường  Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.784002
    ,"Long":106.654431
    ,"Polyline":"[106.65514374,10.78112030] ; [106.65432739,10.78398991]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"508"
    ,"Station_Code":"QTB 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ Tân B ình"
    ,"Station_Address":"470, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.786222
    ,"Long":106.653786
    ,"Polyline":"[106.65432739,10.78398991] ; [106.65386963,10.78561974] ; [106.65371704,10.78621006]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"509"
    ,"Station_Code":"QTB 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bệnh vi ện chỉnh hình và Phục hồi chức năng"
    ,"Station_Address":"1A (Trung tâm phục hồi người tàn tật) , đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.788689
    ,"Long":106.653076
    ,"Polyline":"[106.65371704,10.78621006] ; [106.65341949,10.78732014] ; [106.65309906,10.78835011] ; [106.65300751,10.78866959]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"553"
    ,"Station_Code":"QTB 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Bệnh vi ện Thống Nhất"
    ,"Station_Address":"Bệnh viện Th ống Nhất, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.792101
    ,"Long":106.653074
    ,"Polyline":"[106.65300751,10.78866959] ; [106.65258026,10.79028988] ; [106.65248108,10.79076958] ; [106.65254211,10.79104042] ; [106.65270996,10.79156017] ; [106.65299225,10.79216003]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Hội Ch ợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận T ân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65299225,10.79216003] ; [106.65337372,10.79290962] ; [106.65458679,10.79424000] ; [106.65502167,10.79463959]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"555"
    ,"Station_Code":"QTB 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Nhà hàng Đông Phương"
    ,"Station_Address":"431, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.798622
    ,"Long":106.659286
    ,"Polyline":"[106.65502167,10.79463959] ; [106.65596771,10.79557991] ; [106.65695190,10.79648972] ; [106.65840912,10.79788017] ; [106.65856934,10.79804993] ; [106.65921021,10.79868984]"
    ,"Distance":"642"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65921021,10.79868984] ; [106.65995026,10.79936981] ; [106.66039276,10.79981041] ; [106.66066742,10.79998016] ; [106.66087341,10.80027008] ; [106.66091156,10.80025005] ; [106.66098022,10.80023003] ; [106.66108704,10.80027008] ; [106.66117096,10.80035973] ; [106.66127777,10.80039024] ; [106.66149139,10.80056953] ; [106.66166687,10.80064964] ; [106.66182709,10.80068016] ; [106.66326141,10.80056953]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80056953] ; [106.66545868,10.80035973] ; [106.66635895,10.80029964]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu 7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66635895,10.80029964] ; [106.66693115,10.80027962] ; [106.66700745,10.80031013] ; [106.66705322,10.80037975] ; [106.66706085,10.80045986] ; [106.66703796,10.80053043] ; [106.66696930,10.80064964] ; [106.66683960,10.80072021] ; [106.66658783,10.80090046]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"455"
    ,"Station_Code":"QTB 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Rạp Tân Sơn Nhất"
    ,"Station_Address":"2B (Hông sân vận  động Quân Khu 7), đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.80244
    ,"Long":106.665924
    ,"Polyline":"[106.66658783,10.80090046] ; [106.66603851,10.80126953] ; [106.66568756,10.80175972] ; [106.66584778,10.80245972]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"457"
    ,"Station_Code":"QTB 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trung tâm sát hạch lái xe"
    ,"Station_Address":"66 (Công ty Xe khách Sài Gòn), đường Phổ Quang, Qu ận Tân Bình"
    ,"Lat":10.805417
    ,"Long":106.6667
    ,"Polyline":"[106.66584778,10.80245972] ; [106.66620636,10.80381966] ; [106.66660309,10.80523014] ; [106.66667938,10.80552006]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"454"
    ,"Station_Code":"QTB 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Cây xăng Quân đội"
    ,"Station_Address":"96-100, đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.807221
    ,"Long":106.668495
    ,"Polyline":"[106.66667938,10.80552006] ; [106.66683197,10.80603027] ; [106.66687012,10.80605984] ; [106.66696930,10.80607033] ; [106.66816711,10.80591965] ; [106.66822052,10.80595970] ; [106.66828156,10.80632973] ; [106.66841888,10.80714989] ; [106.66844177,10.80723000]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"456"
    ,"Station_Code":"QPN 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Trường Đại học Kỹ thuật Công nghệ"
    ,"Station_Address":"140, đường Phổ Quang , Quận Phú Nhuận"
    ,"Lat":10.808344
    ,"Long":106.671997
    ,"Polyline":"[106.66844177,10.80723000] ; [106.66867065,10.80860043] ; [106.66874695,10.80871010.06.66889954] ; [10.80873966,106.67124176] ; [10.80865002,106.67153168] ; [10.80862045,106.67176056] ; [10.80854034,106.67202759]"
    ,"Distance":"534"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"459"
    ,"Station_Code":"QPN 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Cuối công viên Gia Định"
    ,"Station_Address":"7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.809727
    ,"Long":106.674929
    ,"Polyline":"[106.67202759,10.80840015] ; [106.67273712,10.80795002] ; [106.67283630,10.80792046] ; [106.67292786,10.80793953] ; [106.67343903,10.80807972] ; [106.67362976,10.80832958] ; [106.67418671,10.80904007] ; [106.67447662,10.80939007]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"458"
    ,"Station_Code":"QPN 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Ngã ba Đặng Văn Sâm"
    ,"Station_Address":"Ngã ba Đặng Văn Sâm, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.811382
    ,"Long":106.676399
    ,"Polyline":"[106.67447662,10.80939007] ; [106.67598724,10.81120014] ; [106.67623901,10.81147957]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"461"
    ,"Station_Code":"QPN 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Đầu công viên Gia Định"
    ,"Station_Address":"Cây xanh số 7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.8135
    ,"Long":106.678222
    ,"Polyline":"[106.67623901,10.81147957] ; [106.67809296,10.81357002]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"56"
    ,"Station_Code":"QGV 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Trạm đầu Nguyễn Thái Sơn"
    ,"Station_Address":"36 , đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.815178
    ,"Long":106.679596
    ,"Polyline":"[106.67809296,10.81357002] ; [106.67826843,10.81377029] ; [106.67833710,10.81389046] ; [106.67845917,10.81406975] ; [106.67857361,10.81416988] ; [106.67870331,10.81424046] ; [106.67877960,10.81425953] ; [106.67897034,10.81453037] ; [106.67952728,10.81523037]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"59"
    ,"Station_Code":"QGV 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bệnh Vi ện 175"
    ,"Station_Address":"90, đường Nguyễn  Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.81674
    ,"Long":106.680847
    ,"Polyline":"[106.67952728,10.81523037] ; [106.68076324,10.81680012]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"57"
    ,"Station_Code":"QGV 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"182 (148B), đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.819923
    ,"Long":106.683378
    ,"Polyline":"[106.68076324,10.81680012] ; [106.68226624,10.81875992] ; [106.68289185,10.81952953] ; [106.68334961,10.82013035]"
    ,"Distance":"466"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"60"
    ,"Station_Code":"QGV 187"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Nhà Tang Lễ"
    ,"Station_Address":"220 (175), đường Phạm Ngũ Lão , Quận G ò Vấp"
    ,"Lat":10.822141
    ,"Long":106.682616
    ,"Polyline":"[106.68334961,10.82013035] ; [106.68351746,10.82034016] ; [106.68328094,10.82073975] ; [106.68280029,10.82153988] ; [106.68251038,10.82207966]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"61"
    ,"Station_Code":"QGV 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"72  (45), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.825861
    ,"Long":106.680561
    ,"Polyline":"[106.68251038,10.82207966] ; [106.68158722,10.82376957] ; [106.68097687,10.82485008] ; [106.68045044,10.82581997]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"58"
    ,"Station_Code":"QGV 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Siêu th ị Văn Lang"
    ,"Station_Address":"36, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.827508
    ,"Long":106.679634
    ,"Polyline":"[106.68045044,10.82581997] ; [106.68025970,10.82618046] ; [106.68006897,10.82637024] ; [106.68009186,10.82639027] ; [106.68012238,10.82645988] ; [106.68012238,10.82653046] ; [106.68007660,10.82658958] ; [106.68000793,10.82662010.06.67993927] ; [10.82662010.06.67991638,10.82660961] ; [106.67987061,10.82691956] ; [106.67957306,10.82746983]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"65"
    ,"Station_Code":"QGV 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Ngã Tư Phan Văn Trị"
    ,"Station_Address":"150, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.829979
    ,"Long":106.678246
    ,"Polyline":"[106.67957306,10.82746983] ; [106.67819214,10.82995033]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"62"
    ,"Station_Code":"QGV 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Doanh trại Quân đội"
    ,"Station_Address":"152 , đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.832563
    ,"Long":106.676747
    ,"Polyline":"[106.67819214,10.82995033] ; [106.67775726,10.83059025] ; [106.67756653,10.83086014] ; [106.67694855,10.83174992] ; [106.67675018,10.83207035] ; [106.67661285,10.83244038]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"67"
    ,"Station_Code":"QGV 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Cư xá Lam  Sơn"
    ,"Station_Address":"214, đường Nguyễn Oanh, Qu ận Gò Vấp"
    ,"Lat":10.836141
    ,"Long":106.675637
    ,"Polyline":"[106.67661285,10.83244038] ; [106.67607117,10.83388042] ; [106.67561340,10.83510017] ; [106.67552948,10.83547020] ; [106.67552185,10.83578014] ; [106.67552185,10.83613014]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"63"
    ,"Station_Code":"QGV 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"Đối diện 197 (93), đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.839297
    ,"Long":106.67583
    ,"Polyline":"[106.67552185,10.83613014] ; [106.67550659,10.83852959] ; [106.67550659,10.83860970] ; [106.67565918,10.83907986] ; [106.67572784,10.83930016]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"72"
    ,"Station_Code":"QGV 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Ngã tư An Nhơn"
    ,"Station_Address":"388, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.842342
    ,"Long":106.676903
    ,"Polyline":"[106.67572784,10.83930016] ; [106.67623901,10.84090996] ; [106.67671204,10.84226036]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"64"
    ,"Station_Code":"QGV 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"530, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.846894
    ,"Long":106.678512
    ,"Polyline":"[106.67671204,10.84226036] ; [106.67819214,10.84642029] ; [106.67835236,10.84691048]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"66"
    ,"Station_Code":"QGVT111"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Cầu An Lộc"
    ,"Station_Address":"604, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.849006
    ,"Long":106.678749
    ,"Polyline":"[106.67835236,10.84691048] ; [106.67851257,10.84753990] ; [106.67855835,10.84811020] ; [106.67864227,10.84901047]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"73"
    ,"Station_Code":"Q12 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Nhà hàng Bến Xưa"
    ,"Station_Address":"42, đường Hà  Huy Giáp, Quận 12"
    ,"Lat":10.852642
    ,"Long":106.679285
    ,"Polyline":"[106.67864227,10.84901047] ; [106.67865753,10.84939003] ; [106.67874908,10.85031033] ; [106.67893982,10.85177994]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"79"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":"[106.67893982,10.85177994] ; [106.67929840,10.85394001] ; [106.67948914,10.85542011] ; [106.67980957,10.85789967] ; [106.68025208,10.86151981] ; [106.68049622,10.86390972] ; [106.68060303,10.86390018] ; [106.68039703,10.86390972] ; [106.68035889,10.86355019] ; [106.68019104,10.86201954] ; [106.68013000,10.86176968] ; [106.68000793,10.86163998] ; [106.67980957,10.86155987] ; [106.67832947,10.86166954]"
    ,"Distance":"1839"
  }]