export const Route51 =[

  {
     "Route_Id":"51"
    ,"Station_Id":"4412"
    ,"Station_Code":"BX 1234546789"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Đường nội bộ Đại học Quốc gia"
    ,"Station_Address":"Đại học Quốc T ế - Đại học Quốc gia, đường Đường nội bộ Đại học Quốc gia, Quận Thủ Đức"
    ,"Lat":10.876771
    ,"Long":106.801808
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"572"
    ,"Station_Code":"QTD 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"621-Ngã 3 Lâm Viên"
    ,"Station_Address":"Nhà máy Tiến Thành, đường Quốc lộ 1, Qu ận Thủ Đức"
    ,"Lat":10.871128
    ,"Long":106.806979
    ,"Polyline":"[106.80181122,10.87677097] ; [106.80185699,10.87651730] ; [106.80319977,10.87646484] ; [106.80384827,10.87630653] ; [106.80421448,10.87618065] ; [106.80453491,10.87601757] ; [106.80487823,10.87576962] ; [106.80509949,10.87545872] ; [106.80558777,10.87500000] ; [106.80610657,10.87473202] ; [106.80669403,10.87446880] ; [106.80715179,10.87421513] ; [106.80762482,10.87390518] ; [106.80804443,10.87351513] ; [106.80845642,10.87312508] ; [106.80697632,10.87112808]"
    ,"Distance":"1148"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo  dục Quốc phòng, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80697632,10.87112808] ; [106.80580139,10.86958504] ; [106.80436707,10.86821556]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"574"
    ,"Station_Code":"QTD 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Khu DL Su ối Tiên"
    ,"Station_Address":"9/29, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86605
    ,"Long":106.801116
    ,"Polyline":"[106.80436707,10.86821556] ; [106.80281830,10.86703491] ; [106.80111694,10.86604977]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"398"
    ,"Station_Code":"QTD 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Khu Công ngh ệ cao Q9"
    ,"Station_Address":"Đối diện Khu c ông nghệ cao, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.860545
    ,"Long":106.791723
    ,"Polyline":"[106.80111694,10.86604977] ; [106.79172516,10.86054516]"
    ,"Distance":"1196"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"401"
    ,"Station_Code":"QTD 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Công ty Cocacola"
    ,"Station_Address":"Công ty Cocacola, đường  Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.856483
    ,"Long":106.784964
    ,"Polyline":"[106.79172516,10.86054516] ; [106.78496552,10.85648346]"
    ,"Distance":"866"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1113"
    ,"Station_Code":"QTD 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã tư Thủ Đức"
    ,"Station_Address":"Đối diện Coopmart, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.84828
    ,"Long":106.77299
    ,"Polyline":"[106.78496552,10.85648346] ; [106.77813721,10.85246277] ; [106.77543640,10.85069275] ; [106.77298737,10.84827995]"
    ,"Distance":"1604"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1111"
    ,"Station_Code":"QTD 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Betong Hải Âu"
    ,"Station_Address":"Đối diện  Betong Hải Âu, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.844297
    ,"Long":106.77063
    ,"Polyline":"[106.77298737,10.84827995] ; [106.77062988,10.84429741]"
    ,"Distance":"513"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1112"
    ,"Station_Code":"QTD 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"UBND Quận 9"
    ,"Station_Address":"126, đường  Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.840745
    ,"Long":106.768607
    ,"Polyline":"[106.77062988,10.84429741] ; [106.76860809,10.84074497]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"410"
    ,"Station_Code":"QTD 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Đối diện 592C, đường Xa Lộ Hà Nội, Quận Th ủ Đức"
    ,"Lat":10.834945
    ,"Long":106.765244
    ,"Polyline":"[106.76860809,10.84074497] ; [106.76524353,10.83494473]"
    ,"Distance":"743"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"413"
    ,"Station_Code":"QTD 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Công ty truyền tải điện 4"
    ,"Station_Address":"Công ty truyền tải điện 4, đường Xa Lộ Hà  Nội, Quận Thủ Đức"
    ,"Lat":10.831214
    ,"Long":106.763195
    ,"Polyline":"[106.76524353,10.83494473] ; [106.76319122,10.83121395]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"412"
    ,"Station_Code":"QTD 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"Nhà máy thép Thủ Đức, đường Xa Lộ Hà  Nội, Quận Thủ Đức"
    ,"Lat":10.825366
    ,"Long":106.759998
    ,"Polyline":"[106.76319122,10.83121395] ; [106.75999451,10.82536602]"
    ,"Distance":"739"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"414"
    ,"Station_Code":"QTD 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Xi măng Hà Tiên"
    ,"Station_Address":"Xi măng Hà Tiên 1 , đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.820576
    ,"Long":106.758142
    ,"Polyline":"[106.75999451,10.82536602] ; [106.75891113,10.82329464] ; [106.75814056,10.82057571]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"415"
    ,"Station_Code":"Q2 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Đối diện Esstella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802925
    ,"Long":106.747948
    ,"Polyline":"[106.75814056,10.82057571] ; [106.75713348,10.81518078] ; [106.75663757,10.81246185] ; [106.75612640,10.80967999] ; [106.75566101,10.80860519] ; [106.75509644,10.80751896] ; [106.75412750,10.80622292] ; [106.75299072,10.80510616] ; [106.75171661,10.80434704] ; [106.75036621,10.80364132] ; [106.74915314,10.80320930] ; [106.74794769,10.80292511]"
    ,"Distance":"2460"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"416"
    ,"Station_Code":"Q2 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"655, đường  Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802134
    ,"Long":106.7434
    ,"Polyline":"[106.74794769,10.80292511] ; [106.74340057,10.80213356]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"417"
    ,"Station_Code":"Q2 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Ngã ba Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801309
    ,"Long":106.738762
    ,"Polyline":"[106.74340057,10.80213356] ; [106.73876190,10.80130863]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"418"
    ,"Station_Code":"Q2 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"Đối diện Cầu Đen, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800451
    ,"Long":106.73436
    ,"Polyline":"[106.73876190,10.80130863] ; [106.73435974,10.80045128]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"419"
    ,"Station_Code":"QBTH 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"24(597), đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.79882
    ,"Long":106.719641
    ,"Polyline":"[106.73435974,10.80045128] ; [106.72284698,10.79813957] ; [106.72219849,10.79803467] ; [106.72155762,10.79800320] ; [106.72103119,10.79808712] ; [106.72053528,10.79827690] ; [106.72010040,10.79850864] ; [106.71964264,10.79881954]"
    ,"Distance":"1659"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2699"
    ,"Station_Code":"QBTH 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cây Xăng Hoàng Nguyên"
    ,"Station_Address":"113, đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.795267
    ,"Long":106.718094
    ,"Polyline":"[106.71964264,10.79881954] ; [106.71794128,10.79991055] ; [106.71774292,10.79947853] ; [106.71968079,10.79836655] ; [106.71978760,10.79819298] ; [106.72006226,10.79803467] ; [106.72013855,10.79786015] ; [106.72001648,10.79756069] ; [106.71883392,10.79630566] ; [106.71879578,10.79617405] ; [106.71846771,10.79587364] ; [106.71828461,10.79575825] ; [106.71809387,10.79526711]"
    ,"Distance":"972"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2702"
    ,"Station_Code":"QBTH 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Hồ Bơi Hải Quân"
    ,"Station_Address":"22, đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.789477
    ,"Long":106.710522
    ,"Polyline":"[106.71809387,10.79526711] ; [106.71802521,10.79107857] ; [106.71786499,10.79060459] ; [106.71755219,10.79019356] ; [106.71706390,10.78982449] ; [106.71641541,10.78951931] ; [106.71566772,10.78926563] ; [106.71530151,10.78920269] ; [106.71491241,10.78923416] ; [106.71334839,10.78952980] ; [106.71250153,10.78963470] ; [106.71209717,10.78974056] ; [106.71168518,10.78979301] ; [106.71108246,10.78967667] ; [106.71052551,10.78947735]"
    ,"Distance":"1386"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2703"
    ,"Station_Code":"Q1 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"1, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.784149
    ,"Long":106.707555
    ,"Polyline":"[106.71052551,10.78947735] ; [106.71001434,10.78901291] ; [106.70967865,10.78841209] ; [106.70911407,10.78686333] ; [106.70857239,10.78548241] ; [106.70825958,10.78494453] ; [106.70755768,10.78414917]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1095"
    ,"Station_Code":"Q1 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"TTTM Sài Gòn"
    ,"Station_Address":"6, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.784184
    ,"Long":106.7043
    ,"Polyline":"[106.70755768,10.78414917] ; [106.70620728,10.78253651] ; [106.70429993,10.78418446]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2705"
    ,"Station_Code":"Q1 158"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"66Bis , đường Nguyễn Du, Quận 1"
    ,"Lat":10.781754
    ,"Long":106.701447
    ,"Polyline":"[106.70429993,10.78418446] ; [106.70378113,10.78467083] ; [106.70280457,10.78364372] ; [106.70181274,10.78267860] ; [106.70144653,10.78175354]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2706"
    ,"Station_Code":"Q3 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Đại học Kinh tế"
    ,"Station_Address":"18Bis, đường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.784012
    ,"Long":106.694573
    ,"Polyline":"[106.70144653,10.78175354] ; [106.70111084,10.78023338] ; [106.70009613,10.77914810.06.69890594] ; [10.78020763,106.69870758] ; [10.78026581,106.69862366] ; [10.78032875,106.69849396] ; [10.78035545,106.69696808] ; [10.78172016,106.69622803] ; [10.78235245,106.69632721] ; [10.78249454,106.69636536] ; [10.78267384,106.69633484] ; [10.78283691,106.69623566] ; [10.78299999,106.69608307] ; [10.78307438,106.69593048] ; [10.78310013,106.69577026] ; [10.78306866,106.69560242] ; [10.78297424,106.69457245]"
    ,"Distance":"1210"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2707"
    ,"Station_Code":"Q3 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"42, đường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.785135
    ,"Long":106.693318
    ,"Polyline":"[106.69457245,10.78401184] ; [106.69332123,10.78513527]"
    ,"Distance":"186"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2710"
    ,"Station_Code":"Q3 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Võ Thị Sáu"
    ,"Station_Address":"82 - 84, đ ường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.786563
    ,"Long":106.691687
    ,"Polyline":"[106.69332123,10.78513527] ; [106.69168854,10.78656292]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"3176"
    ,"Station_Code":"Q3 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Phạm Ngọc Thạch"
    ,"Station_Address":"158A - 156B, đường  Võ Thị Sáu, Quận 3"
    ,"Lat":10.786916
    ,"Long":106.690918
    ,"Polyline":"[106.69168854,10.78656292] ; [106.69109344,10.78704262] ; [106.69091797,10.78691578]"
    ,"Distance":"108"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"246"
    ,"Station_Code":"Q3 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Viện Pasteur"
    ,"Station_Address":"Đối diện 153 A-B , đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.785583
    ,"Long":106.689613
    ,"Polyline":"[106.69091797,10.78691578] ; [106.69000244,10.78589344] ; [106.68961334,10.78558254]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2491"
    ,"Station_Code":"Q3 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Bảo tàng Phụ Nữ"
    ,"Station_Address":"200, đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.783535
    ,"Long":106.687561
    ,"Polyline":"[106.68961334,10.78558254] ; [106.68756104,10.78353500]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"727"
    ,"Station_Code":"Q3 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trần Quốc Thảo"
    ,"Station_Address":"232 Võ Thị Sáu, đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.782294
    ,"Long":106.686242
    ,"Polyline":"[106.68756104,10.78353500] ; [106.68624115,10.78229427]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2708"
    ,"Station_Code":"Q3 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Dân Chủ"
    ,"Station_Address":"274, đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.778625
    ,"Long":106.682671
    ,"Polyline":"[106.68624115,10.78229427] ; [106.68267059,10.77862453]"
    ,"Distance":"565"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1299"
    ,"Station_Code":"Q3 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Siêu thị Thi ên Hòa"
    ,"Station_Address":"132C - 132D, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.778452
    ,"Long":106.680618
    ,"Polyline":"[106.68267059,10.77862453] ; [106.68215179,10.77804184] ; [106.68196869,10.77798367] ; [106.68184662,10.77808857] ; [106.68170166,10.77813625] ; [106.68155670,10.77812576] ; [106.68141174,10.77803135] ; [106.68061829,10.77845192]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1298"
    ,"Station_Code":"Q3 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã Ba Chí Hòa"
    ,"Station_Address":"276 Bis, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.780594
    ,"Long":106.676575
    ,"Polyline":"[106.68061829,10.77845192] ; [106.67657471,10.78059387]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2711"
    ,"Station_Code":"Q3 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chùa Bửu Đà"
    ,"Station_Address":"342 - 342A , đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.78163
    ,"Long":106.674741
    ,"Polyline":"[106.67657471,10.78059387] ; [106.67474365,10.78162956]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2709"
    ,"Station_Code":"Q3 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Rạp hát Thanh  Vân"
    ,"Station_Address":"360A, đường Cách M ạng Tháng Tám, Quận 3"
    ,"Lat":10.783738
    ,"Long":106.670755
    ,"Polyline":"[106.67474365,10.78162956] ; [106.67075348,10.78373814]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2712"
    ,"Station_Code":"Q3 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Cống Bà Xếp"
    ,"Station_Address":"442, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.784146
    ,"Long":106.669945
    ,"Polyline":"[106.67075348,10.78373814] ; [106.66994476,10.78414631]"
    ,"Distance":"100"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1300"
    ,"Station_Code":"Q3 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Công viên Lê Thị Riêng"
    ,"Station_Address":"542, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.785814
    ,"Long":106.66693
    ,"Polyline":"[106.66994476,10.78414631] ; [106.66693115,10.78581429]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"906"
    ,"Station_Code":"QTB 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Bắc Hải"
    ,"Station_Address":"690, đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.787486
    ,"Long":106.663727
    ,"Polyline":"[106.66693115,10.78581429] ; [106.66372681,10.78748608]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"907"
    ,"Station_Code":"QTB 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bành Văn  Trân"
    ,"Station_Address":"814, đường Cách M ạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.788639
    ,"Long":106.661544
    ,"Polyline":"[106.66372681,10.78748608] ; [106.66154480,10.78863907]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"910"
    ,"Station_Code":"QTB 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm Ông Tạ"
    ,"Station_Address":"962, đường Cách Mạng Tháng Tám, Quận Tân B ình"
    ,"Lat":10.789677
    ,"Long":106.659576
    ,"Polyline":"[106.66154480,10.78863907] ; [106.65957642,10.78967667]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"909"
    ,"Station_Code":"QTB 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm Y tế Phường 4"
    ,"Station_Address":"1130 (458), đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.791448
    ,"Long":106.656218
    ,"Polyline":"[106.65957642,10.78967667] ; [106.65621948,10.79144764]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"908"
    ,"Station_Code":"QTB 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"1236 (544), đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.792317
    ,"Long":106.654592
    ,"Polyline":"[106.65621948,10.79144764] ; [106.65459442,10.79231739]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65459442,10.79231739] ; [106.65349579,10.79290771] ; [106.65502167,10.79463959] ; [106.65505981,10.79458714]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đường Xuân Diệu,  Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65505981,10.79458714] ; [106.65502167,10.79463959] ; [106.65580750,10.79543686] ; [106.65515900,10.79603958] ; [106.65519714,10.79608059]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62),  đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65519714,10.79608059] ; [106.65464783,10.79654980] ; [106.65387726,10.79585266]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65387726,10.79585266] ; [106.65390778,10.79584026] ; [106.65233612,10.79437923]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1719"
    ,"Station_Code":"QTB 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Ngã tư B ảy Hiền"
    ,"Station_Address":"106, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794182
    ,"Long":106.651191
    ,"Polyline":"[106.65233612,10.79437923] ; [106.65180206,10.79386139] ; [106.65119171,10.79418182]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1720"
    ,"Station_Code":"QTB 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Nhà Thở  Đắc Lộ"
    ,"Station_Address":"150, đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.794973
    ,"Long":106.649743
    ,"Polyline":"[106.65119171,10.79418182] ; [106.64974213,10.79497337]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1301"
    ,"Station_Code":"QTB 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"162T, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796137
    ,"Long":106.647565
    ,"Polyline":"[106.64974213,10.79497337] ; [106.64756775,10.79613686]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2713"
    ,"Station_Code":"QTB 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Ngã ba Bình Giã"
    ,"Station_Address":"298, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797792
    ,"Long":106.644453
    ,"Polyline":"[106.64756775,10.79613686] ; [106.64445496,10.79779243]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2714"
    ,"Station_Code":"QTB 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Chùa Thiền Quang"
    ,"Station_Address":"22, đường Trương Công Định, Quận Tân Bình"
    ,"Lat":10.798234
    ,"Long":106.641663
    ,"Polyline":"[106.64439392,10.79774761] ; [106.64195251,10.79909325] ; [106.64166260,10.79823399]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2715"
    ,"Station_Code":"QTB 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Cư xá Tân Sơn Nhì"
    ,"Station_Address":"133, đường Ba Vân, Quận Tân Bình"
    ,"Lat":10.796006
    ,"Long":106.639529
    ,"Polyline":"[106.64166260,10.79823399] ; [106.64080811,10.79565239] ; [106.63950348,10.79603958]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"4312"
    ,"Station_Code":"QTP 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Ngã 3 Dân Tộc"
    ,"Station_Address":"1033, đường L ũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.794408
    ,"Long":106.638026
    ,"Polyline":"[106.63952637,10.79600620] ; [106.63950348,10.79603958] ; [106.63928223,10.79612732] ; [106.63906097,10.79603767] ; [106.63877106,10.79584217] ; [106.63841248,10.79570580] ; [106.63820648,10.79556274] ; [106.63802338,10.79440784] ; [106.63802338,10.79440784]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"4294"
    ,"Station_Code":"QTP 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"10, Độc Lập"
    ,"Station_Address":"10, đường Độc Lập , Quận Tân Phú"
    ,"Lat":10.791661
    ,"Long":106.637013
    ,"Polyline":"[106.63802338,10.79440784] ; [106.63751984,10.79159546] ; [106.63701630,10.79166126]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2716"
    ,"Station_Code":"QTP 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Trạm UBND Phường Tân Thành"
    ,"Station_Address":"146 (122), đường Độc Lập, Quận Tân Ph ú"
    ,"Lat":10.79226
    ,"Long":106.633423
    ,"Polyline":"[106.63701630,10.79166126] ; [106.63342285,10.79226017]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2718"
    ,"Station_Code":"QTP 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Trường Lê Văn Tám"
    ,"Station_Address":"216, đường Độc Lập, Quận Tân Phú"
    ,"Lat":10.792543
    ,"Long":106.63134
    ,"Polyline":"[106.63342285,10.79226017] ; [106.63134003,10.79254341]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2719"
    ,"Station_Code":"QTP 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Nhà thờ Martino"
    ,"Station_Address":"2, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.792652
    ,"Long":106.62886
    ,"Polyline":"[106.63134003,10.79254341] ; [106.62890625,10.79292870] ; [106.62886047,10.79265213]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2717"
    ,"Station_Code":"QTP 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Cafe Suối Reo"
    ,"Station_Address":"90, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.789865
    ,"Long":106.627785
    ,"Polyline":"[106.62886047,10.79265213] ; [106.62810516,10.79013538] ; [106.62778473,10.78986454]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2722"
    ,"Station_Code":"QTP 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Nhà Thờ Tân Hương"
    ,"Station_Address":"190, đường T ân Hương, Quận Tân Phú"
    ,"Lat":10.789805
    ,"Long":106.624008
    ,"Polyline":"[106.62778473,10.78986454] ; [106.62705231,10.78935051] ; [106.62548828,10.78959751] ; [106.62523651,10.78967667] ; [106.62400818,10.78980541]"
    ,"Distance":"436"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2584"
    ,"Station_Code":"QTP 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Trạm Chợ Tân Hương"
    ,"Station_Address":"248, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.79012
    ,"Long":106.621338
    ,"Polyline":"[106.62400818,10.78980541] ; [106.62133789,10.79012012]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2720"
    ,"Station_Code":"QTP 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Lê Sát"
    ,"Station_Address":"234, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.789883
    ,"Long":106.618996
    ,"Polyline":"[106.62133789,10.79012012] ; [106.62078094,10.79020882] ; [106.61899567,10.78988266]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1614"
    ,"Station_Code":"QTP 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"214, đường Lê Thúc Hoạch,  Quận Tân Phú"
    ,"Lat":10.788112
    ,"Long":106.61882
    ,"Polyline":"[106.61899567,10.78988266] ; [106.61688995,10.78946114] ; [106.61739349,10.78801155] ; [106.61882019,10.78811169]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1560"
    ,"Station_Code":"BX54"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Cư xá Nhiêu Lộc"
    ,"Station_Address":"Bến xe buýt Cư xá Nhiêu Lộc, đường Lê Thúc Hoạch, Quận Tân Phú"
    ,"Lat":10.788043
    ,"Long":106.621895
    ,"Polyline":"[106.61882019,10.78811169] ; [106.62104034,10.78830147] ; [106.62125397,10.78806496] ; [106.62185669,10.78772736] ; [106.62242126,10.78753757] ; [106.62248230,10.78771114] ; [106.62195587,10.78790665] ; [106.62189484,10.78804302]"
    ,"Distance":"519"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1560"
    ,"Station_Code":"BX54"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Cư xá Nhiêu Lộc"
    ,"Station_Address":"Bến xe buýt Cư xá Nhiêu Lộc, đường Lê Th úc Hoạch, Quận Tân Phú"
    ,"Lat":10.788043
    ,"Long":106.621895
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1561"
    ,"Station_Code":"QTP 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"239, đường Lê Thúc Hoạch, Quận Tân Phú"
    ,"Lat":10.788292
    ,"Long":106.618896
    ,"Polyline":"[106.62189484,10.78804302] ; [106.62164307,10.78809643] ; [106.62132263,10.78828621] ; [106.62102509,10.78852844] ; [106.61889648,10.78829193]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2549"
    ,"Station_Code":"QTP 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Lê Sát"
    ,"Station_Address":"395, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.789688
    ,"Long":106.618233
    ,"Polyline":"[106.61889648,10.78829193] ; [106.61740875,10.78820133] ; [106.61697388,10.78942394] ; [106.61823273,10.78968811]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2553"
    ,"Station_Code":"QTP 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm Chợ Tân Hương"
    ,"Station_Address":"217-219, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.790046
    ,"Long":106.621666
    ,"Polyline":"[106.61823273,10.78968811] ; [106.62082672,10.79016209] ; [106.62166595,10.79004574]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2551"
    ,"Station_Code":"QTP 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà Thờ Tân Hương"
    ,"Station_Address":"141, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.789681
    ,"Long":106.624565
    ,"Polyline":"[106.62166595,10.79004574] ; [106.62389374,10.78978729] ; [106.62456512,10.78968143]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2556"
    ,"Station_Code":"QTP 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Café Suối Reo"
    ,"Station_Address":"43, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.790343
    ,"Long":106.628273
    ,"Polyline":"[106.62456512,10.78968143] ; [106.62531281,10.78960323] ; [106.62613678,10.78944492] ; [106.62703705,10.78931904] ; [106.62747192,10.78955078] ; [106.62820435,10.79013538] ; [106.62827301,10.79034328]"
    ,"Distance":"455"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2554"
    ,"Station_Code":"QTP 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhà thờ Martino"
    ,"Station_Address":"15, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.792511
    ,"Long":106.628891
    ,"Polyline":"[106.62827301,10.79034328] ; [106.62860870,10.79151058] ; [106.62889099,10.79251099]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2555"
    ,"Station_Code":"QTP 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Trường Lê Văn Tám"
    ,"Station_Address":"115, đường Độc Lập, Quận Tân Phú"
    ,"Lat":10.792492
    ,"Long":106.631424
    ,"Polyline":"[106.62889099,10.79251099] ; [106.62895966,10.79284382] ; [106.63142395,10.79249191]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2558"
    ,"Station_Code":"QTPT141"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm UBND Phường Tân Thành"
    ,"Station_Address":"67-69, đường Độc Lập, Quận Tân Phú"
    ,"Lat":10.792187690734863
    ,"Long":106.63333892822266
    ,"Polyline":"[106.63142395,10.79249191] ; [106.63333893,10.79218769]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"4295"
    ,"Station_Code":"QTP 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 3 Thẩm Mỹ"
    ,"Station_Address":"21, đường  Độc Lập, Quận Tân Phú"
    ,"Lat":10.791664
    ,"Long":106.63675
    ,"Polyline":"[106.63333893,10.79218769] ; [106.63674927,10.79166412]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"4323"
    ,"Station_Code":"QTP 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"Kios 07, đường Lũy Bán Bích , Quận Tân Phú"
    ,"Lat":10.794481
    ,"Long":106.63808
    ,"Polyline":"[106.63674927,10.79166412] ; [106.63758850,10.79153728] ; [106.63807678,10.79448128]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2557"
    ,"Station_Code":"QTB 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Cư xá Tân Sơn Nhì"
    ,"Station_Address":"Đối diện 145 , đường Ba Vân, Quận Tân Bình"
    ,"Lat":10.796127
    ,"Long":106.639497
    ,"Polyline":"[106.63807678,10.79448128] ; [106.63828278,10.79553127] ; [106.63844299,10.79563713] ; [106.63868713,10.79573154] ; [106.63912964,10.79600048] ; [106.63943481,10.79605293] ; [106.63959503,10.79598236]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2560"
    ,"Station_Code":"QTB 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chùa Thiền Quang"
    ,"Station_Address":"19, đường Trương Công Định, Quận Tân Bình"
    ,"Lat":10.797898
    ,"Long":106.641678
    ,"Polyline":"[106.63959503,10.79598236] ; [106.64086151,10.79553699] ; [106.64167786,10.79789829]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2559"
    ,"Station_Code":"QTB 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã ba H ồng Đào"
    ,"Station_Address":"351, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797666
    ,"Long":106.644266
    ,"Polyline":"[106.64167786,10.79789829] ; [106.64194489,10.79893017] ; [106.64427185,10.79767609]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1392"
    ,"Station_Code":"QTB 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Hoàng Hoa  Thám"
    ,"Station_Address":"233, đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.796426
    ,"Long":106.646553
    ,"Polyline":"[106.64427185,10.79767609] ; [106.64655304,10.79642582]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1826"
    ,"Station_Code":"QTB 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Nhà thờ Đắc Lộ"
    ,"Station_Address":"97 (đối diện 160B), đường Trường Chinh, Qu ận Tân Bình"
    ,"Lat":10.794978
    ,"Long":106.64926
    ,"Polyline":"[106.64655304,10.79642582] ; [106.64927673,10.79499626]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1830"
    ,"Station_Code":"QTB 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"67, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.793856
    ,"Long":106.651368
    ,"Polyline":"[106.64927673,10.79499626] ; [106.65143585,10.79382420]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"996"
    ,"Station_Code":"QTB 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"1125 (đối diện 544), đường Cách Mạng Tháng  Tám, Quận Tân Bình"
    ,"Lat":10.792192
    ,"Long":106.654533
    ,"Polyline":"[106.65143585,10.79382420] ; [106.65298462,10.79302883] ; [106.65453339,10.79219246]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"998"
    ,"Station_Code":"QTB 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Y tế Phường 4, Tân Bình"
    ,"Station_Address":"1057, đường Cách Mạng Tháng Tám, Quận  Tân Bình"
    ,"Lat":10.791463
    ,"Long":106.655885
    ,"Polyline":"[106.65453339,10.79219246] ; [106.65664673,10.79106998]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1000"
    ,"Station_Code":"QTB 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Hồ Bơi Cộng Hòa"
    ,"Station_Address":"1003, đường Cách Mạng Tháng Tám, Quận Tân  Bình"
    ,"Lat":10.790114
    ,"Long":106.65846
    ,"Polyline":"[106.65664673,10.79106998] ; [106.65991974,10.78936863]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1002"
    ,"Station_Code":"QTB 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trạm Ông Tạ"
    ,"Station_Address":"907, đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.789261
    ,"Long":106.660075
    ,"Polyline":"[106.65991974,10.78936863] ; [106.66069794,10.78893948]"
    ,"Distance":"98"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1001"
    ,"Station_Code":"QTB 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Bành Văn Trân"
    ,"Station_Address":"771, đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.78808
    ,"Long":106.662315
    ,"Polyline":"[106.66069794,10.78893948] ; [106.66231537,10.78808022]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1003"
    ,"Station_Code":"Q10 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Công Viên Lê Thị Riêng"
    ,"Station_Address":"Công Viên Lê Thị Riêng, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.786289
    ,"Long":106.665672
    ,"Polyline":"[106.66231537,10.78808022] ; [106.66567230,10.78628922]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2562"
    ,"Station_Code":"Q10 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Hội thánh tin lành Hòa Hưng"
    ,"Station_Address":"601, đường Cách Mạng Tháng T ám, Quận 10"
    ,"Lat":10.784818
    ,"Long":106.668411
    ,"Polyline":"[106.66567230,10.78628922] ; [106.66841125,10.78484440] ; [106.66831207,10.78463459]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2561"
    ,"Station_Code":"Q10 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Tô Hiến Thành"
    ,"Station_Address":"513, đường Cách M ạng Tháng Tám, Quận 10"
    ,"Lat":10.782535
    ,"Long":106.672699
    ,"Polyline":"[106.66831207,10.78463459] ; [106.66843414,10.78486061] ; [106.67269897,10.78253460]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1399"
    ,"Station_Code":"Q10 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chùa Bửu Đà"
    ,"Station_Address":"427, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.781446
    ,"Long":106.674698
    ,"Polyline":"[106.67269897,10.78253460] ; [106.67447662,10.78157139]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2564"
    ,"Station_Code":"Q10 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Hòa Hưng"
    ,"Station_Address":"385, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.780435
    ,"Long":106.676575
    ,"Polyline":"[106.67447662,10.78157139] ; [106.67657471,10.78043461]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1394"
    ,"Station_Code":"Q10 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã 6 Dân Chủ"
    ,"Station_Address":"Đối diện 132A, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.7783
    ,"Long":106.680604
    ,"Polyline":"[106.67657471,10.78043461] ; [106.68048096,10.77836323]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2563"
    ,"Station_Code":"Q3 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Công an Quận 3"
    ,"Station_Address":"243, đường C ách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.777219
    ,"Long":106.68246
    ,"Polyline":"[106.68048096,10.77836323] ; [106.68136597,10.77795219] ; [106.68136597,10.77784157] ; [106.68139648,10.77773094] ; [106.68144226,10.77765179] ; [106.68151093,10.77758789] ; [106.68161774,10.77754116] ; [106.68172455,10.77753544] ; [106.68193817,10.77758312] ; [106.68245697,10.77721882]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"731"
    ,"Station_Code":"Q3 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cách Mạng tháng 8"
    ,"Station_Address":"303, đường  Điện Biên Phủ, Quận 3"
    ,"Lat":10.777009
    ,"Long":106.684145
    ,"Polyline":"[106.68245697,10.77721882] ; [106.68366241,10.77663994] ; [106.68414307,10.77700901]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1913"
    ,"Station_Code":"Q3 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bệnh viện Mắt"
    ,"Station_Address":"291, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.778255
    ,"Long":106.685471
    ,"Polyline":"[106.68414307,10.77700901] ; [106.68547058,10.77825546]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1917"
    ,"Station_Code":"Q3 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Sở Khoa học và Công nghệ"
    ,"Station_Address":"273, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.780286
    ,"Long":106.687621
    ,"Polyline":"[106.68547058,10.77825546] ; [106.68762207,10.78028584]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1914"
    ,"Station_Code":"Q3 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Marie Curie"
    ,"Station_Address":"Đối diện số 206 (247), đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.782872
    ,"Long":106.690369
    ,"Polyline":"[106.68762207,10.78028584] ; [106.69036865,10.78287220]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1920"
    ,"Station_Code":"Q3 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Phạm Ngọc Thạch"
    ,"Station_Address":"209,  đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.784965
    ,"Long":106.692375
    ,"Polyline":"[106.69036865,10.78287220] ; [106.69237518,10.78496456]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2565"
    ,"Station_Code":"Q3 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"43, đường Phạm Ng ọc Thạch, Quận 3"
    ,"Lat":10.784855
    ,"Long":106.693388
    ,"Polyline":"[106.69237518,10.78496456] ; [106.69280243,10.78547192] ; [106.69338989,10.78485489]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2566"
    ,"Station_Code":"Q3 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Đại học Kinh tế"
    ,"Station_Address":"17, đường Phạm Ngọc Thạch, Quận 3"
    ,"Lat":10.783159
    ,"Long":106.695198
    ,"Polyline":"[106.69338989,10.78485489] ; [106.69519806,10.78315926]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2568"
    ,"Station_Code":"Q1 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà Thờ Đức Bà"
    ,"Station_Address":"1, đường Công xã Paris, Quận 1"
    ,"Lat":10.779233
    ,"Long":106.699154
    ,"Polyline":"[106.69519806,10.78315926] ; [106.69555664,10.78294277] ; [106.69552612,10.78279972] ; [106.69552612,10.78265285] ; [106.69555664,10.78252125] ; [106.69563293,10.78239918] ; [106.69574738,10.78231525] ; [106.69589996,10.78228378] ; [106.69604492,10.78229427] ; [106.69618225,10.78233624] ; [106.69734955,10.78127766] ; [106.69846344,10.78030777] ; [106.69843292,10.78022289] ; [106.69844818,10.78012848] ; [106.69849396,10.78007030] ; [106.69853973,10.78002834] ; [106.69861603,10.77986526] ; [106.69915771,10.77923298]"
    ,"Distance":"658"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2569"
    ,"Station_Code":"Q1 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"TTTM Vincom"
    ,"Station_Address":"47, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.778568
    ,"Long":106.701721
    ,"Polyline":"[106.69915771,10.77923298] ; [106.69966888,10.77890587] ; [106.69990540,10.77893257] ; [106.70107269,10.77790451] ; [106.70172119,10.77856827]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2570"
    ,"Station_Code":"Q1 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"23, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.780644
    ,"Long":106.703629
    ,"Polyline":"[106.70172119,10.77856827] ; [106.70362854,10.78064442]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2571"
    ,"Station_Code":"Q1 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Tòa án nhân dân Q1"
    ,"Station_Address":"3B, đường Lý Tự Trọng, Quận 1"
    ,"Lat":10.782521
    ,"Long":106.705338
    ,"Polyline":"[106.70362854,10.78064442] ; [106.70533752,10.78252125]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2572"
    ,"Station_Code":"Q1 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Nguyễn H ữu Cảnh"
    ,"Station_Address":"Cây xanh số 17, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.78328
    ,"Long":106.707222
    ,"Polyline":"[106.70533752,10.78252125] ; [106.70555878,10.78279972] ; [106.70613861,10.78226757] ; [106.70722198,10.78328037]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2573"
    ,"Station_Code":"Q1 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Mầm non Hoa Lư"
    ,"Station_Address":"2A, đường Nguyễn Hữu Cảnh, Quận 1"
    ,"Lat":10.785077
    ,"Long":106.708628
    ,"Polyline":"[106.70722198,10.78328037] ; [106.70862579,10.78507710]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2579"
    ,"Station_Code":"QBTH 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Hồ Bơi H ải Quân"
    ,"Station_Address":"18, đường Nguyễn  Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.789113
    ,"Long":106.710779
    ,"Polyline":"[106.70862579,10.78507710.06.70959473] ; [10.78727436,106.70986176] ; [10.78791714,106.71015930] ; [10.78852844,106.71046448] ; [10.78888702,106.71077728]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2574"
    ,"Station_Code":"QBTH 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Chung cư Manor"
    ,"Station_Address":"176E, đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.793266
    ,"Long":106.718445
    ,"Polyline":"[106.71077728,10.78911304] ; [106.71105957,10.78929806] ; [106.71138763,10.78941345] ; [106.71213531,10.78945541] ; [106.71350861,10.78927612] ; [106.71485901,10.78899193] ; [106.71575928,10.78896046] ; [106.71666718,10.78927612] ; [106.71765137,10.78997231] ; [106.71805573,10.79039383] ; [106.71828461,10.79099464] ; [106.71844482,10.79326630]"
    ,"Distance":"1185"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"2581"
    ,"Station_Code":"QBTH 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Tân Cảng"
    ,"Station_Address":"220 , đường Nguyễn Hữu Cảnh, Quận Bình Thạnh"
    ,"Lat":10.796601
    ,"Long":106.719909
    ,"Polyline":"[106.71844482,10.79326630] ; [106.71843719,10.79446220] ; [106.71843719,10.79496765] ; [106.71852112,10.79536819] ; [106.71875763,10.79576874] ; [106.71913910,10.79607391] ; [106.71990967,10.79660130]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"477"
    ,"Station_Code":"Q2 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"794, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.799978
    ,"Long":106.7342
    ,"Polyline":"[106.71990967,10.79660130] ; [106.72113037,10.79774952] ; [106.72272491,10.79784489] ; [106.72451782,10.79817104] ; [106.73419952,10.79997826]"
    ,"Distance":"1637"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"478"
    ,"Station_Code":"Q2 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Đối diện ngã 3 Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800838
    ,"Long":106.738899
    ,"Polyline":"[106.73419952,10.79997826] ; [106.73889923,10.80083847]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"480"
    ,"Station_Code":"Q2 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"170, đường  Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801584
    ,"Long":106.742928
    ,"Polyline":"[106.73889923,10.80083847] ; [106.74292755,10.80158424]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"479"
    ,"Station_Code":"Q2 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Khu  dân cư Estella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802592
    ,"Long":106.748089
    ,"Polyline":"[106.74292755,10.80158424] ; [106.74458313,10.80196571] ; [106.74551392,10.80193424] ; [106.74595642,10.80195522] ; [106.74633026,10.80201817] ; [106.74714661,10.80220795] ; [106.74761963,10.80247116] ; [106.74809265,10.80259228]"
    ,"Distance":"582"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"482"
    ,"Station_Code":"Q9 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Xi măng h à tiên - trạm thu phí"
    ,"Station_Address":"249B, đường Xa Lộ Hà Nội, Qu ận 9"
    ,"Lat":10.819206
    ,"Long":106.758394
    ,"Polyline":"[106.74809265,10.80259228] ; [106.75114441,10.80375671] ; [106.75232697,10.80453682] ; [106.75341797,10.80537987] ; [106.75453949,10.80656052] ; [106.75546265,10.80784607] ; [106.75601959,10.80887890] ; [106.75642395,10.80995369] ; [106.75839233,10.81920624]"
    ,"Distance":"2331"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"481"
    ,"Station_Code":"Q9 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"185A, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.825972
    ,"Long":106.760775
    ,"Polyline":"[106.75839233,10.81920624] ; [106.75850677,10.82070255] ; [106.75889587,10.82234669] ; [106.75972748,10.82437038] ; [106.76077271,10.82597160]"
    ,"Distance":"810"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"485"
    ,"Station_Code":"Q9 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Trạm xây dựng"
    ,"Station_Address":"354A, đ ường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.829955
    ,"Long":106.76312
    ,"Polyline":"[106.76077271,10.82597160] ; [106.76312256,10.82995510]"
    ,"Distance":"512"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"483"
    ,"Station_Code":"Q9 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Khu QLGTDT số 2"
    ,"Station_Address":"Khu QLGTĐT số 2, đường Xa Lộ Hà Nội, Quận  9"
    ,"Lat":10.833249
    ,"Long":106.764778
    ,"Polyline":"[106.76312256,10.82995510.06.76477814]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1025"
    ,"Station_Code":"Q9 214"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Kho 71, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.836162
    ,"Long":106.76666
    ,"Polyline":"[106.76477814,10.83324909] ; [106.76666260,10.83616161]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1030"
    ,"Station_Code":"Q9 215"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"UBND quận 9"
    ,"Station_Address":"1B, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.840466
    ,"Long":106.769074
    ,"Polyline":"[106.76666260,10.83616161] ; [106.76907349,10.84046555]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1026"
    ,"Station_Code":"Q9 216"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Bê tông Hải Âu"
    ,"Station_Address":"Bê tông  Hải Âu, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.843834
    ,"Long":106.77079
    ,"Polyline":"[106.76907349,10.84046555] ; [106.77079010,10.84383392]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"1028"
    ,"Station_Code":"Q9 217"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Ngã 4 Thủ  Đức"
    ,"Station_Address":"712, đường Xa Lộ H à Nội, Quận 9"
    ,"Lat":10.847142
    ,"Long":106.772974
    ,"Polyline":"[106.77079010,10.84383392] ; [106.77297211,10.84714222]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"494"
    ,"Station_Code":"Q9 218"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Công an Quận 9"
    ,"Station_Address":"Công an Quận 9, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.849966
    ,"Long":106.775066
    ,"Polyline":"[106.77297211,10.84714222] ; [106.77337646,10.84797382] ; [106.77385712,10.84870148] ; [106.77442932,10.84936523] ; [106.77506256,10.84996605]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"498"
    ,"Station_Code":"Q9 219"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Chợ chiều"
    ,"Station_Address":"Kế 830 (Chợ Chiều), đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.853511
    ,"Long":106.780474
    ,"Polyline":"[106.77506256,10.84996605] ; [106.77681732,10.85136700] ; [106.78047180,10.85351086]"
    ,"Distance":"713"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"495"
    ,"Station_Code":"Q9 220"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Khu Công nghệ cao quận 9"
    ,"Station_Address":"Khu công nghệ cao, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.858511
    ,"Long":106.788869
    ,"Polyline":"[106.78047180,10.85351086] ; [106.78887177,10.85851097]"
    ,"Distance":"1073"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"536"
    ,"Station_Code":"Q9 221"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Cầu Vượt Trạm 2"
    ,"Station_Address":"Tiệm vàng Kim Lợi, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.863595
    ,"Long":106.797538
    ,"Polyline":"[106.78887177,10.85851097] ; [106.79753876,10.86359501]"
    ,"Distance":"1104"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"537"
    ,"Station_Code":"Q9 223"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"Suối Tiên,  đường Quốc lộ 1, Quận 9"
    ,"Lat":10.866498
    ,"Long":106.802377
    ,"Polyline":"[106.79753876,10.86359501] ; [106.80237579,10.86649799]"
    ,"Distance":"620"
  },
  {
     "Route_Id":"51"
    ,"Station_Id":"4412"
    ,"Station_Code":"BX 1234546789"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Đường nội bộ Đại học Quốc  gia"
    ,"Station_Address":"Đại học Quốc Tế - Đại học Quốc gia, đường Đường nội bộ Đại học Quốc gia, Quận Thủ Đức"
    ,"Lat":10.876771
    ,"Long":106.801808
    ,"Polyline":"[106.80237579,10.86649799] ; [106.80237579,10.86649799] ; [106.80358887,10.86731911] ; [106.80471802,10.86820412] ; [106.80588531,10.86935329] ; [106.80686951,10.87059593] ; [106.80874634,10.87306213] ; [106.80759430,10.87402058] ; [106.80670166,10.87453651] ; [106.80561829,10.87501144] ; [106.80532074,10.87546921] ; [106.80527496,10.87573242] ; [106.80519867,10.87627506] ; [106.80504608,10.87685490] ; [106.80479431,10.87727070] ; [106.80408478,10.87750244] ; [106.80381012,10.87726021] ; [106.80335236,10.87667084] ; [106.80319214,10.87660694] ; [106.80251312,10.87662792] ; [106.80182648,10.87662315] ; [106.80181122,10.87677097] ; [106.80181122,10.87677097]"
    ,"Distance":"2087"
  }]