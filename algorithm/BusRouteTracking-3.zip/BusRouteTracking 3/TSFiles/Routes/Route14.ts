export const Route14 =[
  {
     "Route_Id":"14"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận  12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"976"
    ,"Station_Code":"Q12 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đá hoa cương Hoà Thắng"
    ,"Station_Address":"96/2, đường  Quốc lộ 1A, Quận 12"
    ,"Lat":10.86193
    ,"Long":106.675143
    ,"Polyline":"[106.67832947,10.86166954] ; [106.67665863,10.86178017] ; [106.67514038,10.86182976]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"964"
    ,"Station_Code":"Q12 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Tô Ngọc Vân"
    ,"Station_Address":"972, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861904
    ,"Long":106.671935
    ,"Polyline":"[106.67514038,10.86182976] ; [106.67433929,10.86184025] ; [106.67260742,10.86182022] ; [106.67252350,10.86182022]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"965"
    ,"Station_Code":"Q12 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn Th ạnh Xuân"
    ,"Station_Address":"Khách sạn Thạnh Xuân, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861862
    ,"Long":106.665863
    ,"Polyline":"[106.67252350,10.86182022] ; [106.66986847,10.86176968] ; [106.66723633,10.86174965] ; [106.66586304,10.86174965]"
    ,"Distance":"728"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"977"
    ,"Station_Code":"Q12 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Khách sạn Phi Vũ"
    ,"Station_Address":"Khách sạn Phi Vũ, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861862
    ,"Long":106.660016
    ,"Polyline":"[106.66586304,10.86174965] ; [106.66429901,10.86172962] ; [106.66304016,10.86166954] ; [106.66181946,10.86165047] ; [106.66033173,10.86168957] ; [106.66026306,10.86170006]"
    ,"Distance":"612"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"966"
    ,"Station_Code":"Q12 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Bãi xe Tri Ân"
    ,"Station_Address":"1360, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.86202
    ,"Long":106.656121
    ,"Polyline":"[106.66026306,10.86170006] ; [106.65778351,10.86180973]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"969"
    ,"Station_Code":"Q12 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Quận ủy Qu ận 12"
    ,"Station_Address":"1456 (Quận Ủy qu ận 12), đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.86212
    ,"Long":106.653659
    ,"Polyline":"[106.65778351,10.86180973] ; [106.65445709,10.86198044]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"972"
    ,"Station_Code":"Q12 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Tân Thới  Hiệp"
    ,"Station_Address":"1680, đường Quốc lộ 1A, Qu ận 12"
    ,"Lat":10.862273
    ,"Long":106.650757
    ,"Polyline":"[106.65445709,10.86198044] ; [106.65267944,10.86205959] ; [106.65244293,10.86209965] ; [106.65189362,10.86211967] ; [106.65117645,10.86215973] ; [106.65075684,10.86217976]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"4127"
    ,"Station_Code":"Q12T080"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Kế chùa Phước Thiện An, Lê Đức Thọ"
    ,"Station_Address":"Kế chùa Phước Thiện An, đường Lê Đức Thọ, Quận 12"
    ,"Lat":10.8606050962605
    ,"Long":106.650018032253
    ,"Polyline":"[106.65075684,10.86224174] ; [106.64972687,10.86218834] ; [106.64977264,10.86130810.06.64989471] ; [10.86081314,106.65001678]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"973"
    ,"Station_Code":"QGV 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà thờ Nữ Vương Hòa Bình"
    ,"Station_Address":"Đối diện nhà thờ Nữ Vương Hòa Bình, đường Lê Đức Thọ, Quận Gò V ấp"
    ,"Lat":10.856841
    ,"Long":106.653809
    ,"Polyline":"[106.65001678,10.86060524] ; [106.65409851,10.85656643]"
    ,"Distance":"633"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"974"
    ,"Station_Code":"QGV 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã Ba Lê Đức Thọ"
    ,"Station_Address":"603 (đối diện 658), đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.854064
    ,"Long":106.655944
    ,"Polyline":"[106.65418243,10.85659981] ; [106.65493774,10.85593987] ; [106.65527344,10.85564041] ; [106.65557098,10.85531998] ; [106.65596771,10.85486031] ; [106.65601349,10.85482979] ; [106.65599060,10.85480022] ; [106.65595245,10.85463047] ; [106.65599060,10.85410023]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"978"
    ,"Station_Code":"QGV 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà hàng Tư Trì"
    ,"Station_Address":"477, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.849254
    ,"Long":106.656454
    ,"Polyline":"[106.65599060,10.85410023] ; [106.65608978,10.85208988] ; [106.65614319,10.85146046] ; [106.65618134,10.85064030] ; [106.65621948,10.85041046] ; [106.65634918,10.84998989] ; [106.65646362,10.84961987]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"979"
    ,"Station_Code":"QGV 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Câu lạc bộ Tenis"
    ,"Station_Address":"329, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.845756
    ,"Long":106.656947
    ,"Polyline":"[106.65646362,10.84961987] ; [106.65673828,10.84871960] ; [106.65682220,10.84848022] ; [106.65686035,10.84817982] ; [106.65689087,10.84762955] ; [106.65696716,10.84615040]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"981"
    ,"Station_Code":"QGV 149"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã Ba C ây Trâm"
    ,"Station_Address":"217, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.843266
    ,"Long":106.657059
    ,"Polyline":"[106.65696716,10.84615040] ; [106.65706635,10.84480953] ; [106.65712738,10.84358025] ; [106.65714264,10.84327030]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"980"
    ,"Station_Code":"QGV 150"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Cây Trâm"
    ,"Station_Address":"57, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.838559
    ,"Long":106.657707
    ,"Polyline":"[106.65714264,10.84327030] ; [106.65718079,10.84165955] ; [106.65721130,10.84127998] ; [106.65731049,10.84064960] ; [106.65740967,10.84010983] ; [106.65773010,10.83880997] ; [106.65778351,10.83858013]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"983"
    ,"Station_Code":"QGVT184"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Công an Quận Gò Vấp"
    ,"Station_Address":"9, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835590362548828
    ,"Long":106.66127014160156
    ,"Polyline":"[106.65778351,10.83858013] ; [106.65831757,10.83648968] ; [106.65830994,10.83642006] ; [106.65857697,10.83635998] ; [106.65894318,10.83625031] ; [106.66082764,10.83578014] ; [106.66129303,10.83565044]"
    ,"Distance":"601"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"985"
    ,"Station_Code":"QGVT185"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chùa Huỳnh Kim"
    ,"Station_Address":"1/5 - 1/8, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835028648376465
    ,"Long":106.66313934326172
    ,"Polyline":"[106.66129303,10.83565044] ; [106.66309357,10.83514023] ; [106.66316986,10.83510971]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"982"
    ,"Station_Code":"QGVT186"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"VKS nhân dân Quận Gò Vấp"
    ,"Station_Address":"523, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833206
    ,"Long":106.6661
    ,"Polyline":"[106.66316986,10.83510971] ; [106.66390991,10.83479023] ; [106.66445923,10.83452034] ; [106.66486359,10.83428001] ; [106.66551971,10.83376026] ; [106.66615295,10.83327007]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"987"
    ,"Station_Code":"QGV 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Quang Trung"
    ,"Station_Address":"387, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.830791
    ,"Long":106.669167
    ,"Polyline":"[106.66615295,10.83327007] ; [106.66752625,10.83220005] ; [106.66877747,10.83119011] ; [106.66921234,10.83084011]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"984"
    ,"Station_Code":"QGV 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà Thờ Xóm Thuốc"
    ,"Station_Address":"305, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.829139
    ,"Long":106.672058
    ,"Polyline":"[106.66921234,10.83084011] ; [106.66976166,10.83041954] ; [106.67011261,10.83018017] ; [106.67066956,10.82989979] ; [106.67208099,10.82919025]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"986"
    ,"Station_Code":"QGV 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Xóm thuốc"
    ,"Station_Address":"205, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.828095
    ,"Long":106.67485
    ,"Polyline":"[106.67211914,10.82917976] ; [106.67269897,10.82892990] ; [106.67395020,10.82847977] ; [106.67482758,10.82816982]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"988"
    ,"Station_Code":"QGV 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty 32"
    ,"Station_Address":"67, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.827308
    ,"Long":106.677185
    ,"Polyline":"[106.67487335,10.82814980] ; [106.67720795,10.82736969]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"991"
    ,"Station_Code":"QGV 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Đối  diện siêu thị Văn Lang, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.82661
    ,"Long":106.679153
    ,"Polyline":"[106.67720795,10.82736969] ; [106.67917633,10.82668972]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"219"
    ,"Station_Code":"QGV 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Siêu Thị Big C Gò Vấp"
    ,"Station_Address":"Đối diện Big C, đường Nguy ễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.825682
    ,"Long":106.679606
    ,"Polyline":"[106.67917633,10.82668972] ; [106.67932129,10.82662964] ; [106.67945099,10.82651997] ; [106.67965698,10.82641983] ; [106.67974091,10.82633018] ; [106.67980194,10.82614994] ; [106.67981720,10.82602978] ; [106.67981720,10.82590961] ; [106.67977142,10.82577038]"
    ,"Distance":"154"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"222"
    ,"Station_Code":"QGV 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Xóm Cháy"
    ,"Station_Address":"629B, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.821751
    ,"Long":106.678764
    ,"Polyline":"[106.67971802,10.82579231] ; [106.67878723,10.82175350]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"221"
    ,"Station_Code":"QGV 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"151, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.818837
    ,"Long":106.678719
    ,"Polyline":"[106.67878723,10.82175350] ; [106.67871857,10.81883717]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"223"
    ,"Station_Code":"QGV 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Chợ Tân Sơn Nhất"
    ,"Station_Address":"37 - 39, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.815118
    ,"Long":106.678619
    ,"Polyline":"[106.67871857,10.81883717] ; [106.67861938,10.81511784]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"989"
    ,"Station_Code":"QGVT052"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường số 6"
    ,"Station_Address":"117, đường Nguyễn Thái Sơn, Quận Gò V ấp"
    ,"Lat":10.814848899841309
    ,"Long":106.67711639404297
    ,"Polyline":"[106.67870331,10.81511974] ; [106.67870331,10.81424046] ; [106.67852020,10.81439972] ; [106.67819977,10.81449032] ; [106.67710114,10.81480026]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"990"
    ,"Station_Code":"QTB 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nguyễn Thái Sơn"
    ,"Station_Address":"169, đường Bạch Đằng, Quận Tân Bình"
    ,"Lat":10.815639
    ,"Long":106.674492
    ,"Polyline":"[106.67710114,10.81480026] ; [106.67606354,10.81511021] ; [106.67584229,10.81517982] ; [106.67571259,10.81529045] ; [106.67562103,10.81538010.06.67549896] ; [10.81544971,106.67510986] ; [10.81548977,106.67449951]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"993"
    ,"Station_Code":"QTB 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Hồng Hà"
    ,"Station_Address":"2 (Công ty Hà Đô), đường H ồng Hà, Quận Tân Bình"
    ,"Lat":10.814656
    ,"Long":106.671867
    ,"Polyline":"[106.67449951,10.81554031] ; [106.67429352,10.81548977] ; [106.67401886,10.81538963] ; [106.67314911,10.81509972] ; [106.67208099,10.81468010.06.67188263]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"992"
    ,"Station_Code":"QTBT169"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Đoàn Tiếp Viên"
    ,"Station_Address":"43, đường Hồng Hà, Quận Tân Bình"
    ,"Lat":10.813678741455078
    ,"Long":106.67003631591797
    ,"Polyline":"[106.67188263,10.81459999] ; [106.67132568,10.81446457] ; [106.67011261,10.81422997] ; [106.67006683,10.81367970]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"994"
    ,"Station_Code":"QTBT170"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Parkson"
    ,"Station_Address":"Hủy, đường Hồng Hà, Quận Tân Bình"
    ,"Lat":10.813431739807129
    ,"Long":106.66668701171875
    ,"Polyline":"[106.67006683,10.81367970] ; [106.67002106,10.81309986] ; [106.66831207,10.81320953] ; [106.66667938,10.81340027]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"995"
    ,"Station_Code":"QTB 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Ngô Sỹ Liên"
    ,"Station_Address":"53, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.810257
    ,"Long":106.664673
    ,"Polyline":"[106.66667938,10.81340027] ; [106.66581726,10.81348038] ; [106.66552734,10.81350994] ; [106.66544342,10.81355953] ; [106.66535187,10.81357956] ; [106.66525269,10.81357956] ; [106.66517639,10.81355000] ; [106.66512299,10.81348991] ; [106.66503906,10.81332970] ; [106.66497040,10.81307983] ; [106.66494751,10.81278992] ; [106.66493225,10.81239986] ; [106.66488647,10.81180000] ; [106.66475677,10.81035042] ; [106.66474915,10.81025028]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"997"
    ,"Station_Code":"QTB 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Siêu thị Super Bow"
    ,"Station_Address":"Siêu thị super Bow, đường Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.808049
    ,"Long":106.66449
    ,"Polyline":"[106.66474915,10.81025028] ; [106.66455078,10.80803967]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"999"
    ,"Station_Code":"QTB 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trần Quốc Hoàn"
    ,"Station_Address":"71, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.803644
    ,"Long":106.663925
    ,"Polyline":"[106.66455078,10.80803967] ; [106.66443634,10.80683041] ; [106.66429901,10.80500031] ; [106.66426086,10.80459023] ; [106.66416168,10.80416965] ; [106.66398621,10.80362034]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66398621,10.80362034] ; [106.66381073,10.80311012] ; [106.66355896,10.80266953] ; [106.66342163,10.80245972] ; [106.66262817,10.80158997] ; [106.66233826,10.80132008]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"600"
    ,"Station_Code":"QTB 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"216, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.799836
    ,"Long":106.660385
    ,"Polyline":"[106.66233826,10.80132008] ; [106.66194153,10.80095959] ; [106.66171265,10.80080986] ; [106.66152191,10.80070019] ; [106.66134644,10.80066013] ; [106.66101074,10.80058956] ; [106.66092682,10.80056953] ; [106.66085052,10.80051041] ; [106.66081238,10.80045986] ; [106.66082001,10.80033970] ; [106.66074371,10.80012035] ; [106.66063690,10.80002975] ; [106.66040039,10.79981995]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"602"
    ,"Station_Code":"QTB 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Công an Quận Tân Bình"
    ,"Station_Address":"340H, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.796577
    ,"Long":106.656952
    ,"Polyline":"[106.66037750,10.79979992] ; [106.65936279,10.79885960] ; [106.65862274,10.79810047] ; [106.65837860,10.79788017] ; [106.65699005,10.79654026]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đường Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65699005,10.79654026] ; [106.65577698,10.79539013] ; [106.65515900,10.79603958]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62), đường Xuân Hồng, Quận Tân B ình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65515900,10.79603958] ; [106.65464783,10.79654980] ; [106.65390778,10.79584026]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65386963,10.79587364] ; [106.65233612,10.79437923]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"996"
    ,"Station_Code":"QTB 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"1125 (đối diện 544), đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.792192
    ,"Long":106.654533
    ,"Polyline":"[106.65238190,10.79434013] ; [106.65184021,10.79384041] ; [106.65178680,10.79374027] ; [106.65213776,10.79354954] ; [106.65300751,10.79310989] ; [106.65371704,10.79271984] ; [106.65457153,10.79224968]"
    ,"Distance":"455"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"998"
    ,"Station_Code":"QTB 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm Y tế Phường 4, Tân Bình"
    ,"Station_Address":"1057, đường Cách Mạng Tháng Tám, Quận  Tân Bình"
    ,"Lat":10.791463
    ,"Long":106.655885
    ,"Polyline":"[106.65457153,10.79224968] ; [106.65667725,10.79113007]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1000"
    ,"Station_Code":"QTB 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Hồ Bơi Cộng Hòa"
    ,"Station_Address":"1003, đường Cách Mạng Tháng Tám, Quận Tân  Bình"
    ,"Lat":10.790114
    ,"Long":106.65846
    ,"Polyline":"[106.65667725,10.79113007] ; [106.65721893,10.79082966] ; [106.65770721,10.79059029] ; [106.65856171,10.79014015] ; [106.65956879,10.78962040] ; [106.65995026,10.78942013]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1002"
    ,"Station_Code":"QTB 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Trạm Ông Tạ"
    ,"Station_Address":"907, đường Cách Mạng Tháng T ám, Quận Tân Bình"
    ,"Lat":10.789261
    ,"Long":106.660075
    ,"Polyline":"[106.65995026,10.78942013] ; [106.66063690,10.78903961] ; [106.66072845,10.78899002]"
    ,"Distance":"111"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1001"
    ,"Station_Code":"QTB 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bành Văn Trân"
    ,"Station_Address":"771, đường Cách Mạng Tháng Tám, Quận Tân B ình"
    ,"Lat":10.78808
    ,"Long":106.662315
    ,"Polyline":"[106.66072845,10.78899002] ; [106.66233826,10.78812981]"
    ,"Distance":"213"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1003"
    ,"Station_Code":"Q10 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Công Viên Lê Thị Riêng"
    ,"Station_Address":"Công Viên Lê Thị Riêng, đường Cách Mạng Tháng Tám, Quận 10"
    ,"Lat":10.786289
    ,"Long":106.665672
    ,"Polyline":"[106.66233826,10.78812981] ; [106.66381073,10.78738022] ; [106.66486359,10.78678989] ; [106.66570282,10.78633976]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1004"
    ,"Station_Code":"Q10 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Công Viên Lê Thị Riêng"
    ,"Station_Address":"Đối diện 69, đường Trường Sơn, Quận 10"
    ,"Lat":10.784571
    ,"Long":106.665756
    ,"Polyline":"[106.66570282,10.78633976] ; [106.66622925,10.78604984] ; [106.66638947,10.78569984] ; [106.66580963,10.78454018]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1005"
    ,"Station_Code":"Q10 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Nguyễn Giản Thanh"
    ,"Station_Address":"BB14ter, đường Trường Sơn, Quận 10"
    ,"Lat":10.781973
    ,"Long":106.663696
    ,"Polyline":"[106.66580963,10.78454018] ; [106.66549683,10.78390980] ; [106.66510773,10.78310013] ; [106.66464233,10.78232956] ; [106.66454315,10.78223991] ; [106.66371155,10.78192997]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1009"
    ,"Station_Code":"Q10 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Đồng Nai"
    ,"Station_Address":"F4, đường Trường Sơn, Quận 10"
    ,"Lat":10.781213
    ,"Long":106.661819
    ,"Polyline":"[106.66371155,10.78192997] ; [106.66181946,10.78120041]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1006"
    ,"Station_Code":"Q10 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Trường THPT  Nguyễn Du"
    ,"Station_Address":"XX1, đường Đồng Nai, Quận 10"
    ,"Lat":10.779224
    ,"Long":106.662399
    ,"Polyline":"[106.66181946,10.78120041] ; [106.66148376,10.78104973] ; [106.66177368,10.78052998] ; [106.66235352,10.77945042] ; [106.66245270,10.77925014]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1011"
    ,"Station_Code":"Q10 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Thành Thái nối dài"
    ,"Station_Address":"197B27, đường  Thành Thái nd, Quận 10"
    ,"Lat":10.777697
    ,"Long":106.662086
    ,"Polyline":"[106.66245270,10.77925014] ; [106.66262817,10.77890015] ; [106.66166687,10.77818012] ; [106.66211700,10.77773952]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1007"
    ,"Station_Code":"Q10 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Ngân hàng quân đội"
    ,"Station_Address":"136, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775531
    ,"Long":106.662819
    ,"Polyline":"[106.66211700,10.77773952] ; [106.66355896,10.77641010.06.66349030] ; [10.77635956,106.66287231]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1013"
    ,"Station_Code":"Q10 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Đại Học  Bách Khoa (cổng sau)"
    ,"Station_Address":"350  ( cũ 142), đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.773322
    ,"Long":106.661125
    ,"Polyline":"[106.66281891,10.77553082] ; [106.66112518,10.77332211]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1008"
    ,"Station_Code":"Q10 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"BV Trưng  Vương"
    ,"Station_Address":"142 kios 37-38,  đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.771244
    ,"Long":106.659096
    ,"Polyline":"[106.66112518,10.77332211] ; [106.65909576,10.77124405]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"613"
    ,"Station_Code":"Q11 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"BV Trưng Vương"
    ,"Station_Address":"Đối diện 266, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.769639
    ,"Long":106.658295
    ,"Polyline":"[106.65912628,10.77120018] ; [106.65834045,10.77048016] ; [106.65815735,10.77038956] ; [106.65827942,10.76998997] ; [106.65836334,10.76966953]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"614"
    ,"Station_Code":"Q11 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Điện Lực Phú Thọ"
    ,"Station_Address":"215C, đường L ý Thường Kiệt, Quận 11"
    ,"Lat":10.765792
    ,"Long":106.659363
    ,"Polyline":"[106.65831757,10.76963997] ; [106.65873718,10.76817036] ; [106.65881348,10.76801014] ; [106.65917969,10.76673985] ; [106.65943146,10.76581955]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"100"
    ,"Station_Code":"Q11 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Nhà sách Phú Thọ"
    ,"Station_Address":"940 (6B), đường Đường 3/2, Quận 11"
    ,"Lat":10.763115
    ,"Long":106.658409
    ,"Polyline":"[106.65943146,10.76581955] ; [106.65957642,10.76527977] ; [106.66000366,10.76381016] ; [106.65869141,10.76311970] ; [106.65847015,10.76299953]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"101"
    ,"Station_Code":"Q11 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Lãnh Binh Thăng"
    ,"Station_Address":"970, đường Đường 3/2, Quận 11"
    ,"Lat":10.761842
    ,"Long":106.65603
    ,"Polyline":"[106.65840912,10.76311493] ; [106.65627289,10.76187325]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"103"
    ,"Station_Code":"Q11 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Chợ Thi ết"
    ,"Station_Address":"1114A-1116A, đường Đ ường 3/2, Quận 11"
    ,"Lat":10.760535
    ,"Long":106.653557
    ,"Polyline":"[106.65627289,10.76187325] ; [106.65361023,10.76042461]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1015"
    ,"Station_Code":"Q11 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Trạm Trần Quý - Tạ Uyên"
    ,"Station_Address":"193, đường Tạ Uyên, Quận 11"
    ,"Lat":10.758068
    ,"Long":106.653492
    ,"Polyline":"[106.65364075,10.76037979] ; [106.65335083,10.76021957] ; [106.65347290,10.75914001] ; [106.65354919,10.75807953]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1017"
    ,"Station_Code":"Q5 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"79, đường Tạ Uyên, Quận 5"
    ,"Lat":10.755201
    ,"Long":106.653696
    ,"Polyline":"[106.65354919,10.75807953] ; [106.65368652,10.75687027] ; [106.65370178,10.75631046] ; [106.65370178,10.75566006] ; [106.65374756,10.75520992]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"1010"
    ,"Station_Code":"Q5 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"266, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753657
    ,"Long":106.652559
    ,"Polyline":"[106.65374756,10.75520992] ; [106.65380859,10.75405025] ; [106.65377808,10.75376987] ; [106.65257263,10.75360012]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA  HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.65258026,10.75354385] ; [106.65257263,10.75360012] ; [106.65178680,10.75351048] ; [106.65180206,10.75333023] ; [106.65180206,10.75300026] ; [106.65180206,10.75242996] ; [106.65180969,10.75181961] ; [106.65180969,10.75142956] ; [106.65106964,10.75118542]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận  5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.65107727,10.75096035] ; [106.65048218,10.75100994] ; [106.65058899,10.75197029] ; [106.65072632,10.75337029] ; [106.65086365,10.75333977] ; [106.65180206,10.75333023] ; [106.65232849,10.75339031]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"897"
    ,"Station_Code":"Q5 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"20-22, đường Tạ Uyên, Quận 5"
    ,"Lat":10.754606
    ,"Long":106.65383
    ,"Polyline":"[106.65232849,10.75339031] ; [106.65300751,10.75347042] ; [106.65377808,10.75360012] ; [106.65377808,10.75376987] ; [106.65380859,10.75393963] ; [106.65377045,10.75498962] ; [106.65373230,10.75535011]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"896"
    ,"Station_Code":"Q11 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm Trần Quý - Tạ Uyên"
    ,"Station_Address":"114, đường Tạ Uyên, Quận 11"
    ,"Lat":10.758002
    ,"Long":106.653603
    ,"Polyline":"[106.65373230,10.75535011] ; [106.65370178,10.75566006] ; [106.65370178,10.75631046] ; [106.65368652,10.75687027] ; [106.65355682,10.75800037]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"153"
    ,"Station_Code":"Q11 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"1163, đường Đường 3/2, Quận 11"
    ,"Lat":10.760371
    ,"Long":106.653763
    ,"Polyline":"[106.65355682,10.75800037] ; [106.65347290,10.75914001] ; [106.65335083,10.76021957] ; [106.65373230,10.76043034]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"154"
    ,"Station_Code":"Q11 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Lê Đại Hành"
    ,"Station_Address":"1007 (1029), đường Đường 3/2, Quận 11"
    ,"Lat":10.761562
    ,"Long":106.656006
    ,"Polyline":"[106.65373230,10.76043034] ; [106.65563965,10.76144981] ; [106.65595245,10.76163960]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"155"
    ,"Station_Code":"Q11 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trung tâm chăm sóc sức khỏe sinh sản"
    ,"Station_Address":"957, đường Đường 3/2, Quận 11"
    ,"Lat":10.76245
    ,"Long":106.657539
    ,"Polyline":"[106.65595245,10.76163960] ; [106.65751648,10.76249027]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"546"
    ,"Station_Code":"Q10 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Điện Lực  Phú Thọ"
    ,"Station_Address":"192, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.76523
    ,"Long":106.659763
    ,"Polyline":"[106.65751648,10.76249027] ; [106.65869141,10.76311970] ; [106.66000366,10.76381016] ; [106.65960693,10.76517010]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"504"
    ,"Station_Code":"Q10 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà thi đấu Phú Thọ"
    ,"Station_Address":"260, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.767367
    ,"Long":106.659065
    ,"Polyline":"[106.65960693,10.76517010.06.65937042] ; [10.76607990,106.65899658]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"505"
    ,"Station_Code":"Q10 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh viện Trưng Vương"
    ,"Station_Address":"BV Tr ưng Vương, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.769652
    ,"Long":106.658524
    ,"Polyline":"[106.65899658,10.76735020] ; [106.65881348,10.76801968] ; [106.65879059,10.76803017] ; [106.65853119,10.76898003] ; [106.65830994,10.76986980]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"900"
    ,"Station_Code":"Q10 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"BV Trưng  Vương"
    ,"Station_Address":"531, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.770922
    ,"Long":106.658913
    ,"Polyline":"[106.65830994,10.76986980] ; [106.65815735,10.77038956] ; [106.65834045,10.77048016] ; [106.65885925,10.77095985]"
    ,"Distance":"160"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"898"
    ,"Station_Code":"Q10 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Đại Học Bách Khoa (cổng sau)"
    ,"Station_Address":"523, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.773046
    ,"Long":106.661057
    ,"Polyline":"[106.65885925,10.77095985] ; [106.66065216,10.77260971] ; [106.66101074,10.77307987]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"902"
    ,"Station_Code":"Q10 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngân hàng quân đội"
    ,"Station_Address":"405, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775549
    ,"Long":106.663017
    ,"Polyline":"[106.66101074,10.77307987] ; [106.66143036,10.77359009] ; [106.66175842,10.77402973] ; [106.66233826,10.77476025] ; [106.66294098,10.77560043]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"899"
    ,"Station_Code":"Q10 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Thành Th ái nối dài"
    ,"Station_Address":"218A, đường Thành Thái nd, Quận 10"
    ,"Lat":10.77768
    ,"Long":106.662285
    ,"Polyline":"[106.66294098,10.77560043] ; [106.66349030,10.77635956] ; [106.66355896,10.77641010.06.66223907]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"904"
    ,"Station_Code":"Q10 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường THPT Nguyễn Du"
    ,"Station_Address":"Đối diện THPT Nguyễn Du, đường Tam Đảo, Quận 10"
    ,"Lat":10.778545
    ,"Long":106.662254
    ,"Polyline":"[106.66223907,10.77762985] ; [106.66166687,10.77818012] ; [106.66221619,10.77859020]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"901"
    ,"Station_Code":"Q10 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đồng Nai"
    ,"Station_Address":"G3, đường Trường Sơn, Quận 10"
    ,"Lat":10.781157
    ,"Long":106.661758
    ,"Polyline":"[106.66221619,10.77859020] ; [106.66262817,10.77890015] ; [106.66235352,10.77945042] ; [106.66177368,10.78052998] ; [106.66148376,10.78104973] ; [106.66175842,10.78116989]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"905"
    ,"Station_Code":"Q10 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Nguyễn Giản Thanh"
    ,"Station_Address":"Đối diện 20, đường Trường Sơn , Quận 10"
    ,"Lat":10.782587
    ,"Long":106.664886
    ,"Polyline":"[106.66175842,10.78116989] ; [106.66320038,10.78172970] ; [106.66454315,10.78223991] ; [106.66464233,10.78232956] ; [106.66481781,10.78262997]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"903"
    ,"Station_Code":"Q10 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Công Viên Lê Thị Riêng"
    ,"Station_Address":"19, đường Trường Sơn, Quận 10"
    ,"Lat":10.785224
    ,"Long":106.666237
    ,"Polyline":"[106.66481781,10.78262997] ; [106.66510773,10.78310013] ; [106.66549683,10.78390980] ; [106.66616821,10.78526020]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"906"
    ,"Station_Code":"QTB 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Bắc Hải"
    ,"Station_Address":"690, đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.787486
    ,"Long":106.663727
    ,"Polyline":"[106.66616821,10.78526020] ; [106.66651154,10.78588963] ; [106.66622925,10.78604984] ; [106.66464233,10.78691959] ; [106.66369629,10.78744030]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"907"
    ,"Station_Code":"QTB 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Bành Văn Trân"
    ,"Station_Address":"814, đường Cách Mạng Tháng Tám, Quận Tân B ình"
    ,"Lat":10.788639
    ,"Long":106.661544
    ,"Polyline":"[106.66369629,10.78744030] ; [106.66220093,10.78820992] ; [106.66123199,10.78870964]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"910"
    ,"Station_Code":"QTB 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trạm Ông Tạ"
    ,"Station_Address":"962, đường Cách Mạng Tháng T ám, Quận Tân Bình"
    ,"Lat":10.789677
    ,"Long":106.659576
    ,"Polyline":"[106.66123199,10.78870964] ; [106.66029358,10.78925037] ; [106.65898895,10.78991032]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"909"
    ,"Station_Code":"QTB 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm Y tế Phường 4"
    ,"Station_Address":"1130 (458),  đường Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.791448
    ,"Long":106.656218
    ,"Polyline":"[106.65898895,10.78991032] ; [106.65770721,10.79059029] ; [106.65676117,10.79108047]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"908"
    ,"Station_Code":"QTB 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã tư B ảy Hiền"
    ,"Station_Address":"1236 (544), đường  Cách Mạng Tháng Tám, Quận Tân Bình"
    ,"Lat":10.792317
    ,"Long":106.654592
    ,"Polyline":"[106.65676117,10.79108047] ; [106.65467834,10.79218960]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Hội Chợ  Triển lãm Tân Bình"
    ,"Station_Address":"605  (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65467834,10.79218960] ; [106.65371704,10.79271984] ; [106.65367889,10.79281044] ; [106.65363312,10.79298019] ; [106.65363312,10.79312992] ; [106.65364838,10.79321003] ; [106.65367889,10.79327965] ; [106.65377808,10.79337978] ; [106.65458679,10.79424000] ; [106.65502167,10.79463959]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"555"
    ,"Station_Code":"QTB 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nhà hàng Đông Phương"
    ,"Station_Address":"431 , đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.798622
    ,"Long":106.659286
    ,"Polyline":"[106.65502167,10.79463959] ; [106.65596771,10.79557991] ; [106.65695190,10.79648972] ; [106.65840912,10.79788017] ; [106.65856934,10.79804993] ; [106.65921021,10.79868984]"
    ,"Distance":"642"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Phạm Văn  Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65921021,10.79868984] ; [106.65995026,10.79936981] ; [106.66039276,10.79981041] ; [106.66062164,10.80000973] ; [106.66087341,10.80027008] ; [106.66091156,10.80025005] ; [106.66098022,10.80023003] ; [106.66108704,10.80027008] ; [106.66117096,10.80035973] ; [106.66166687,10.80064964] ; [106.66300964,10.80053997] ; [106.66317749,10.80051994] ; [106.66326141,10.80056953]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80056953] ; [106.66545868,10.80035973] ; [106.66635895,10.80029964]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu 7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66635895,10.80029964] ; [106.66693115,10.80027962] ; [106.66700745,10.80031013] ; [106.66705322,10.80037975] ; [106.66706085,10.80045986] ; [106.66703796,10.80053043] ; [106.66696930,10.80064964] ; [106.66683960,10.80072021] ; [106.66658783,10.80090046]"
    ,"Distance":"163"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"911"
    ,"Station_Code":"QTB 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Quán Vườn Dừa"
    ,"Station_Address":"12  (1A), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.803641
    ,"Long":106.664909
    ,"Polyline":"[106.66658783,10.80090046] ; [106.66603851,10.80126953] ; [106.66568756,10.80175972] ; [106.66558838,10.80185032] ; [106.66536713,10.80214024] ; [106.66512299,10.80274963] ; [106.66490173,10.80338001] ; [106.66484070,10.80362034]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"913"
    ,"Station_Code":"QTB 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Sông Đáy"
    ,"Station_Address":"Hông số 2 Sông Đáy, đường  Trường Sơn_QTB, Quận Tân Bình"
    ,"Lat":10.806961
    ,"Long":106.664673
    ,"Polyline":"[106.66484070,10.80362034] ; [106.66458893,10.80480003] ; [106.66449738,10.80576038] ; [106.66451263,10.80591965] ; [106.66458130,10.80663967] ; [106.66461182,10.80696964]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"915"
    ,"Station_Code":"QTB 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Siêu thị Super  Bow"
    ,"Station_Address":"28, đường Trường S ơn_QTB, Quận Tân Bình"
    ,"Lat":10.809024
    ,"Long":106.664864
    ,"Polyline":"[106.66461182,10.80696964] ; [106.66478729,10.80902958]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"912"
    ,"Station_Code":"QTB 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Parkson Trường Sơn"
    ,"Station_Address":"58, đường Trường Sơn_QTB, Quận Tân B ình"
    ,"Lat":10.8109
    ,"Long":106.665031
    ,"Polyline":"[106.66478729,10.80902958] ; [106.66497040,10.81091022]"
    ,"Distance":"210"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"914"
    ,"Station_Code":"QTBT167"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Parkson"
    ,"Station_Address":"Hủy, đường Hồng Hà, Quận Tân Bình"
    ,"Lat":10.813360214233398
    ,"Long":106.66609954833984
    ,"Polyline":"[106.66497040,10.81091022] ; [106.66504669,10.81180954] ; [106.66507721,10.81241989] ; [106.66510773,10.81282997] ; [106.66513824,10.81322002] ; [106.66523743,10.81338024] ; [106.66528320,10.81342983] ; [106.66542816,10.81348038] ; [106.66552734,10.81350994] ; [106.66581726,10.81348038] ; [106.66610718,10.81344986]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"916"
    ,"Station_Code":"QTB 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Đoàn Tiếp Viên"
    ,"Station_Address":"115, đường Hồng Hà, Quận Tân Bình"
    ,"Lat":10.813495
    ,"Long":106.670151
    ,"Polyline":"[106.66610718,10.81344986] ; [106.66715240,10.81336021] ; [106.66847992,10.81319046] ; [106.67002869,10.81309986] ; [106.67005920,10.81350040]"
    ,"Distance":"475"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"917"
    ,"Station_Code":"QTB 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Hồng Hà"
    ,"Station_Address":"48, đường Bạch Đằng, Quận Tân Bình"
    ,"Lat":10.814443
    ,"Long":106.671463
    ,"Polyline":"[106.67005920,10.81350040] ; [106.67011261,10.81422997] ; [106.67144775,10.81449986]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"918"
    ,"Station_Code":"QTB 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nguyễn Thái Sơn"
    ,"Station_Address":"104, đường Bạch Đằng, Quận Tân Bình"
    ,"Lat":10.815431
    ,"Long":106.675072
    ,"Polyline":"[106.67144775,10.81449986] ; [106.67176056,10.81457043] ; [106.67201233,10.81464005] ; [106.67247772,10.81484032] ; [106.67308807,10.81507969] ; [106.67384338,10.81532955] ; [106.67439270,10.81552029] ; [106.67449951,10.81554031] ; [106.67479706,10.81550980] ; [106.67507172,10.81548977]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"919"
    ,"Station_Code":"QGVT051"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Đường s ố 6"
    ,"Station_Address":"261 , đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.814932823181152
    ,"Long":106.67640686035156
    ,"Polyline":"[106.67510986,10.81548977] ; [106.67549896,10.81544971] ; [106.67562103,10.81538010.06.67571259] ; [10.81529045,106.67584229] ; [10.81517982,106.67606354] ; [10.81511021,106.67642975]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"56"
    ,"Station_Code":"QGV 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm đầu Nguyễn Thái Sơn"
    ,"Station_Address":"36, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.815178
    ,"Long":106.679596
    ,"Polyline":"[106.67640686,10.81493282] ; [106.67850494,10.81434250] ; [106.67852020,10.81418514] ; [106.67862701,10.81403160] ; [106.67878723,10.81394291] ; [106.67893982,10.81393147] ; [106.67911530,10.81400585] ; [106.67920685,10.81414223] ; [106.67919922,10.81433201] ; [106.67913818,10.81443787] ; [106.67904663,10.81450081] ; [106.67959595,10.81517792]"
    ,"Distance":"495"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"59"
    ,"Station_Code":"QGV 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"90, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.81674
    ,"Long":106.680847
    ,"Polyline":"[106.67952728,10.81523037] ; [106.68076324,10.81680012]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"57"
    ,"Station_Code":"QGV 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"182 (148B), đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.819923
    ,"Long":106.683378
    ,"Polyline":"[106.68076324,10.81680012] ; [106.68226624,10.81875992] ; [106.68289185,10.81952953] ; [106.68334961,10.82013035]"
    ,"Distance":"466"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"60"
    ,"Station_Code":"QGV 187"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Nhà Tang Lễ"
    ,"Station_Address":"220  (175), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.822141
    ,"Long":106.682616
    ,"Polyline":"[106.68334961,10.82013035] ; [106.68351746,10.82034016] ; [106.68328094,10.82073975] ; [106.68280029,10.82153988] ; [106.68251038,10.82207966]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"61"
    ,"Station_Code":"QGV 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Siêu Th ị Big C"
    ,"Station_Address":"72 (45), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.825861
    ,"Long":106.680561
    ,"Polyline":"[106.68251038,10.82207966] ; [106.68158722,10.82376957] ; [106.68097687,10.82485008] ; [106.68045044,10.82581997]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"921"
    ,"Station_Code":"QGV 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Siêu thị Văn Lang, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.826804
    ,"Long":106.679354
    ,"Polyline":"[106.68045044,10.82581997] ; [106.68025970,10.82618046] ; [106.68006897,10.82637024] ; [106.68009186,10.82639027] ; [106.68012238,10.82645988] ; [106.68012238,10.82653046] ; [106.68007660,10.82658958] ; [106.68000793,10.82662010.06.67993927] ; [10.82662010.06.67987061,10.82658005] ; [106.67935181,10.82672024]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"920"
    ,"Station_Code":"QGV 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Công ty 32"
    ,"Station_Address":"138, đường Quang Trung, Qu ận Gò Vấp"
    ,"Lat":10.827779
    ,"Long":106.676559
    ,"Polyline":"[106.67935181,10.82672024] ; [106.67893982,10.82686043] ; [106.67739868,10.82738018] ; [106.67655182,10.82767010]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"922"
    ,"Station_Code":"QGV 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà Thờ Xóm Thuốc"
    ,"Station_Address":"190, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.829186
    ,"Long":106.672606
    ,"Polyline":"[106.67655182,10.82767010.06.67485046] ; [10.82824039,106.67297363] ; [10.82892036,106.67256927]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"923"
    ,"Station_Code":"QGV 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"UBND Qu ận Gò Vấp"
    ,"Station_Address":"328, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.831641
    ,"Long":106.668502
    ,"Polyline":"[106.67256927,10.82907009] ; [106.67196655,10.82931995] ; [106.67012024,10.83030033] ; [106.66979218,10.83049965] ; [106.66883850,10.83127022]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"924"
    ,"Station_Code":"QGV 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"VKS nhân dân Quận Gò Vấp"
    ,"Station_Address":"402 - 404, đ ường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833374
    ,"Long":106.666313
    ,"Polyline":"[106.66882324,10.83129025] ; [106.66757202,10.83226013] ; [106.66635132,10.83323002] ; [106.66631317,10.83325958]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"926"
    ,"Station_Code":"QGV 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Chùa Huỳnh Kim"
    ,"Station_Address":"621, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.834918
    ,"Long":106.663395
    ,"Polyline":"[106.66631317,10.83325958] ; [106.66515350,10.83417988] ; [106.66465759,10.83448982] ; [106.66403198,10.83481026] ; [106.66336060,10.83510017]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"925"
    ,"Station_Code":"QGV 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Siêu thị Bình Dân, Quang Trung"
    ,"Station_Address":"628A, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.835988
    ,"Long":106.660675
    ,"Polyline":"[106.66336060,10.83510017] ; [106.66262817,10.83537960] ; [106.66210175,10.83551025] ; [106.66065979,10.83590031]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"929"
    ,"Station_Code":"QGV 151"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Chợ Cây Trâm"
    ,"Station_Address":"68, đường Lê Văn  Thọ, Quận Gò Vấp"
    ,"Lat":10.839262
    ,"Long":106.657684
    ,"Polyline":"[106.66065979,10.83590031] ; [106.65912628,10.83629036] ; [106.65847015,10.83646011] ; [106.65831757,10.83648968] ; [106.65808868,10.83736992] ; [106.65804291,10.83753967] ; [106.65762329,10.83924961]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"928"
    ,"Station_Code":"QGV 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Ngã Ba Cây Trâm"
    ,"Station_Address":"200, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.842993
    ,"Long":106.657219
    ,"Polyline":"[106.65762329,10.83924961] ; [106.65740967,10.84010983] ; [106.65731049,10.84064960] ; [106.65721130,10.84127998] ; [106.65718079,10.84165955] ; [106.65714264,10.84298992]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"927"
    ,"Station_Code":"QGV 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Câu lạc bộ Tenis"
    ,"Station_Address":"322, đường Lê Văn  Thọ, Quận Gò Vấp"
    ,"Lat":10.84584
    ,"Long":106.657074
    ,"Polyline":"[106.65714264,10.84298992] ; [106.65711975,10.84393024] ; [106.65708923,10.84432030] ; [106.65699005,10.84582996]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"931"
    ,"Station_Code":"QGV 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Nhà hàng Tư Trì"
    ,"Station_Address":"444, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.84918
    ,"Long":106.65667
    ,"Polyline":"[106.65699005,10.84582996] ; [106.65692139,10.84727001] ; [106.65686798,10.84797001] ; [106.65686035,10.84827995] ; [106.65676117,10.84864998] ; [106.65660858,10.84916019]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"934"
    ,"Station_Code":"QGV 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngã Ba Lê Đức Thọ"
    ,"Station_Address":"660, đường Lê Văn Thọ, Quận Gò Vấp"
    ,"Lat":10.853996
    ,"Long":106.656137
    ,"Polyline":"[106.65660858,10.84916019] ; [106.65621948,10.85041046] ; [106.65617371,10.85077000] ; [106.65612030,10.85177994] ; [106.65605927,10.85286999] ; [106.65599060,10.85396004]"
    ,"Distance":"541"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"930"
    ,"Station_Code":"QGVT061"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Nhà thờ Nữ Vương Hòa Bình"
    ,"Station_Address":"131/1477, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.856388092041016
    ,"Long":106.65448760986328
    ,"Polyline":"[106.65599060,10.85396004] ; [106.65595245,10.85463047] ; [106.65599060,10.85480022] ; [106.65601349,10.85482979] ; [106.65596771,10.85486031] ; [106.65557098,10.85531998] ; [106.65527344,10.85564041] ; [106.65493774,10.85593987] ; [106.65454865,10.85628033] ; [106.65445709,10.85634995]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"4128"
    ,"Station_Code":"Q12T081"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Kế 87/1, Lê Đức Thọ"
    ,"Station_Address":"Kế 87/1, đường Lê Đức Thọ, Quận 12"
    ,"Lat":10.860104602975
    ,"Long":106.650683220085
    ,"Polyline":"[106.65448761,10.85638809] ; [106.65068054,10.86010456]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"932"
    ,"Station_Code":"Q12 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Ngã tư Tân Thới Hiệp"
    ,"Station_Address":"79/1, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861881
    ,"Long":106.651199
    ,"Polyline":"[106.65068054,10.86010456] ; [106.65019226,10.86058140] ; [106.64990234,10.86096573] ; [106.64982605,10.86142921] ; [106.64978790,10.86192513] ; [106.65061951,10.86199284] ; [106.65119934,10.86188126]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"935"
    ,"Station_Code":"Q12 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"UBND Quận 12"
    ,"Station_Address":"1251, đường Qu ốc lộ 1A, Quận 12"
    ,"Lat":10.861808
    ,"Long":106.654053
    ,"Polyline":"[106.65119934,10.86194038] ; [106.65242767,10.86188984] ; [106.65284729,10.86186981] ; [106.65309906,10.86190033] ; [106.65406036,10.86186028]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"933"
    ,"Station_Code":"Q12 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Bãi xe Tri Ân"
    ,"Station_Address":"1797, đường Quốc  lộ 1A, Quận 12"
    ,"Lat":10.861651
    ,"Long":106.657127
    ,"Polyline":"[106.65406036,10.86186028] ; [106.65550995,10.86178970] ; [106.65712738,10.86172009]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"936"
    ,"Station_Code":"Q12 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Khách sạn Phi Vũ"
    ,"Station_Address":"973, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861335
    ,"Long":106.662247
    ,"Polyline":"[106.65712738,10.86172009] ; [106.66036224,10.86155987] ; [106.66192627,10.86151028] ; [106.66219330,10.86151981]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"942"
    ,"Station_Code":"Q12 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Gò Sao"
    ,"Station_Address":"109, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861503
    ,"Long":106.666458
    ,"Polyline":"[106.66219330,10.86151981] ; [106.66432953,10.86161041] ; [106.66589355,10.86163998] ; [106.66644287,10.86163998]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"937"
    ,"Station_Code":"Q12 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Cây xăng Thạnh Xuân"
    ,"Station_Address":"Cây xăng Thạnh Xuân, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861577
    ,"Long":106.671882
    ,"Polyline":"[106.66644287,10.86163998] ; [106.66767883,10.86161995] ; [106.67015076,10.86163998] ; [106.67188263,10.86166954]"
    ,"Distance":"608"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"938"
    ,"Station_Code":"Q12 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Cầu Cả Bốn"
    ,"Station_Address":"109, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861619
    ,"Long":106.674446
    ,"Polyline":"[106.67188263,10.86166954] ; [106.67445374,10.86170006]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"944"
    ,"Station_Code":"Q12 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Đối diện Bx Ngã tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.861472
    ,"Long":106.678078
    ,"Polyline":"[106.67445374,10.86170006] ; [106.67534637,10.86168957] ; [106.67703247,10.86161041] ; [106.67807770,10.86155033]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"14"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":"[106.67807770,10.86148834] ; [106.67899323,10.86147690] ; [106.67916870,10.86134529] ; [106.67920685,10.86118698] ; [106.67913818,10.86001205] ; [106.67913055,10.85939121] ; [106.67913055,10.85905361] ; [106.67916870,10.85892200] ; [106.67926025,10.85880089] ; [106.67954254,10.85871124] ; [106.67970276,10.85861111] ; [106.67978668,10.85848427] ; [106.67994690,10.85846901] ; [106.68014526,10.86029148] ; [106.68038177,10.86217785] ; [106.68051147,10.86345291] ; [106.68056488,10.86402130] ; [106.68081665,10.86423206] ; [106.68143463,10.86423206] ; [106.68167877,10.86420059] ; [106.68186188,10.86411095] ; [106.68193054,10.86381054] ; [106.68187714,10.86330509] ; [106.68178558,10.86247253] ; [106.68172455,10.86181450] ; [106.68162537,10.86162472] ; [106.68140411,10.86149311] ; [106.68000031,10.86161900] ; [106.67835236,10.86174011] ; [106.67835999,10.86215687]"
    ,"Distance":"1965"
  }]