export const Route42 =[

  {
     "Route_Id":"42"
    ,"Station_Id":"2140"
    ,"Station_Code":"BX 72"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bình Khánh"
    ,"Station_Address":"BÃI XE BUÝT BẾN ĐÒ BÌNH KHÁNH, đường Huỳnh  Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.673856
    ,"Long":106.766263
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2174"
    ,"Station_Code":"HNB 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Phà Bình Khánh"
    ,"Station_Address":"2919, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.673856
    ,"Long":106.765426
    ,"Polyline":"[106.76616669,10.67407990] ; [106.76631927,10.67364025] ; [106.76611328,10.67360020] ; [106.76577759,10.67364025] ; [106.76303101,10.67469025]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2173"
    ,"Station_Code":"HNB 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Chùa Bà Châu Đốc 2"
    ,"Station_Address":"Cạnh 883A, đường Huỳnh Tấn Ph át, Huyện Nhà Bè"
    ,"Lat":10.674931
    ,"Long":106.762626
    ,"Polyline":"[106.76303101,10.67469025] ; [106.76290894,10.67473984] ; [106.76273346,10.67486954] ; [106.76088715,10.67556953]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"3689"
    ,"Station_Code":"HNB 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường Lê Văn Hưu"
    ,"Station_Address":"2749, đường Huỳnh Tấn Phát, Huyện Nh à Bè"
    ,"Lat":10.675985
    ,"Long":106.759847
    ,"Polyline":"[106.76091766,10.67563248] ; [106.76042175,10.67593765]"
    ,"Distance":"64"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2176"
    ,"Station_Code":"HNB 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Việt Long Sài Gòn"
    ,"Station_Address":"817, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.676882
    ,"Long":106.757594
    ,"Polyline":"[106.76035309,10.67576027] ; [106.75758362,10.67679024]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2177"
    ,"Station_Code":"HNB 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ủy ban xã Phú Xuân"
    ,"Station_Address":"2461, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.678115
    ,"Long":106.754354
    ,"Polyline":"[106.75758362,10.67679024] ; [106.75427246,10.67807961]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1141"
    ,"Station_Code":"HNB 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Công Tiến Thọ"
    ,"Station_Address":"19/8B, đường  Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.679507
    ,"Long":106.75071
    ,"Polyline":"[106.75431824,10.67819405] ; [106.75427246,10.67807961] ; [106.75189209,10.67906380] ; [106.75068665,10.67945957] ; [106.75070953,10.67950726]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1143"
    ,"Station_Code":"HNB 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Đào Tông Nguyên"
    ,"Station_Address":"23/3, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.681985
    ,"Long":106.746994
    ,"Polyline":"[106.75070953,10.67950726] ; [106.74968719,10.67981815] ; [106.74807739,10.68053436] ; [106.74745178,10.68125153] ; [106.74699402,10.68198490]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1142"
    ,"Station_Code":"HNB 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chùa Pháp Võ"
    ,"Station_Address":"27/1B, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.684125
    ,"Long":106.745476
    ,"Polyline":"[106.74693298,10.68194008] ; [106.74549103,10.68404007]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1144"
    ,"Station_Code":"HNB 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"18, đường Huỳnh Tấn Phát, Huy ện Nhà Bè"
    ,"Lat":10.687393
    ,"Long":106.743202
    ,"Polyline":"[106.74543762,10.68410969] ; [106.74487305,10.68488979] ; [106.74382019,10.68644047] ; [106.74327087,10.68721962] ; [106.74311066,10.68743992]"
    ,"Distance":"476"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1145"
    ,"Station_Code":"HNB 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường Nguyễn Bỉnh Khiêm"
    ,"Station_Address":"2213, đường Hu ỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.68996
    ,"Long":106.741909
    ,"Polyline":"[106.74311066,10.68743992] ; [106.74266815,10.68805981] ; [106.74243164,10.68844986] ; [106.74228668,10.68879986] ; [106.74205017,10.68943977] ; [106.74192047,10.68980980] ; [106.74192047,10.68982029]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1146"
    ,"Station_Code":"HNB 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường Lâm Văn Bền"
    ,"Station_Address":"638, đường Huỳnh Tấn Phát, Huyện Nhà  Bè"
    ,"Lat":10.693397
    ,"Long":106.740723
    ,"Polyline":"[106.74192047,10.68982029] ; [106.74102020,10.69237041]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1150"
    ,"Station_Code":"HNB 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Công An Thị Trấn Nhà Bè"
    ,"Station_Address":"2049, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.695332
    ,"Long":106.740026
    ,"Polyline":"[106.74114990,10.69241619] ; [106.74105072,10.69314957]"
    ,"Distance":"82"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1148"
    ,"Station_Code":"HNB 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Nha khoa Khánh Minh"
    ,"Station_Address":"1758, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.698273
    ,"Long":106.738996
    ,"Polyline":"[106.74105072,10.69314957] ; [106.73989868,10.69599056]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1059"
    ,"Station_Code":"HNB 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Phú Xuân"
    ,"Station_Address":"1809 , đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.70114
    ,"Long":106.738315
    ,"Polyline":"[106.73976898,10.69594955] ; [106.73934937,10.69711018] ; [106.73901367,10.69808006] ; [106.73851013,10.69954967] ; [106.73828125,10.70096016]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1364"
    ,"Station_Code":"Q7 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Phạm Hữu  Lầu"
    ,"Station_Address":"1697 , đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.705547
    ,"Long":106.737649
    ,"Polyline":"[106.73828125,10.70096016] ; [106.73822021,10.70135975] ; [106.73818207,10.70147038] ; [106.73819733,10.70186043] ; [106.73819733,10.70223999] ; [106.73813629,10.70275974] ; [106.73792267,10.70415020] ; [106.73776245,10.70481968] ; [106.73760223,10.70518970] ; [106.73753357,10.70543957] ; [106.73742676,10.70610046]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1363"
    ,"Station_Code":"Q7 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chùa Pháp Hoa"
    ,"Station_Address":"1611, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.708926
    ,"Long":106.737381
    ,"Polyline":"[106.73742676,10.70610046] ; [106.73734283,10.70683956] ; [106.73725891,10.70855999]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1367"
    ,"Station_Code":"Q7 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"An Chánh  Dương"
    ,"Station_Address":"1543, đường Huỳnh  Tấn Phát, Quận 7"
    ,"Lat":10.711134
    ,"Long":106.737242
    ,"Polyline":"[106.73738098,10.70892620] ; [106.73722839,10.71053600]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1365"
    ,"Station_Code":"Q7 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Ngô Quyền"
    ,"Station_Address":"1503/7, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.712795
    ,"Long":106.737177
    ,"Polyline":"[106.73715973,10.71053028] ; [106.73703766,10.71273041]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2175"
    ,"Station_Code":"Q7 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường Ngô Quyền"
    ,"Station_Address":"1393-1395, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.714624
    ,"Long":106.737081
    ,"Polyline":"[106.73703766,10.71273041] ; [106.73687744,10.71607971]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2178"
    ,"Station_Code":"Q7 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà sách Nguyễn Văn Cừ"
    ,"Station_Address":"Đối diện 1260, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.716732
    ,"Long":106.736974
    ,"Polyline":"[106.73687744,10.71607971] ; [106.73683929,10.71702957]"
    ,"Distance":"128"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2179"
    ,"Station_Code":"Q7 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường Nguyễn Văn Hưởng"
    ,"Station_Address":"1255, đường Huỳnh Tấn Phát , Quận 7"
    ,"Lat":10.718656
    ,"Long":106.736882
    ,"Polyline":"[106.73683929,10.71702957] ; [106.73677826,10.71759987] ; [106.73664856,10.72006035] ; [106.73663330,10.72025967]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2180"
    ,"Station_Code":"Q7 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Ban chỉ huy QS Quận 7"
    ,"Station_Address":"1193, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.721054
    ,"Long":106.73656
    ,"Polyline":"[106.73663330,10.72025967] ; [106.73654175,10.72070026] ; [106.73639679,10.72115040] ; [106.73616028,10.72165012] ; [106.73561096,10.72274017]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2181"
    ,"Station_Code":"Q7 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Mầm non Ban Mai"
    ,"Station_Address":"1097, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.723141
    ,"Long":106.735525
    ,"Polyline":"[106.73561096,10.72274017] ; [106.73451996,10.72482014]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2182"
    ,"Station_Code":"Q7 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Khu phố 3"
    ,"Station_Address":"1027, đường Huỳnh Tấn Ph át, Quận 7"
    ,"Lat":10.725028
    ,"Long":106.734554
    ,"Polyline":"[106.73458099,10.72485161] ; [106.73371887,10.72669411]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2183"
    ,"Station_Code":"Q7 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Phú Thuận"
    ,"Station_Address":"853, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.731727
    ,"Long":106.731834
    ,"Polyline":"[106.73351288,10.72677994] ; [106.73329926,10.72721958] ; [106.73307800,10.72770023] ; [106.73288727,10.72821999] ; [106.73278046,10.72852993]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2186"
    ,"Station_Code":"Q7 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Khu phố 2"
    ,"Station_Address":"704, đường Hu ỳnh Tấn Phát, Quận 7"
    ,"Lat":10.734294
    ,"Long":106.730751
    ,"Polyline":"[106.73270416,10.72905540] ; [106.73198700,10.73117924]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2184"
    ,"Station_Code":"Q7 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Cầu Phú Mỹ"
    ,"Station_Address":"731, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.736639
    ,"Long":106.730681
    ,"Polyline":"[106.73181915,10.73126030] ; [106.73116302,10.73316956] ; [106.73101807,10.73359966] ; [106.73078156,10.73499012] ; [106.73076630,10.73507023]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2189"
    ,"Station_Code":"Q7 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Nghĩa Trang Liệt Sĩ Nhà Bè"
    ,"Station_Address":"619, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.739944
    ,"Long":106.730188
    ,"Polyline":"[106.73076630,10.73507023] ; [106.73056793,10.73657990] ; [106.73040771,10.73754025] ; [106.73013306,10.73945045]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2185"
    ,"Station_Code":"Q7 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường Nguyễn Hữu Cảnh"
    ,"Station_Address":"571, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.742621
    ,"Long":106.729796
    ,"Polyline":"[106.73026276,10.73968601] ; [106.72979736,10.74262142]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2187"
    ,"Station_Code":"Q7 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Nhà sách Tân Thuận"
    ,"Station_Address":"473-475, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.745789
    ,"Long":106.729308
    ,"Polyline":"[106.72944641,10.74392986] ; [106.72914886,10.74600029]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2190"
    ,"Station_Code":"Q7 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm y tế Q7"
    ,"Station_Address":"375, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.749441
    ,"Long":106.728868
    ,"Polyline":"[106.72914886,10.74600029] ; [106.72885895,10.74802017] ; [106.72879791,10.74876022] ; [106.72879028,10.74892998]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2188"
    ,"Station_Code":"Q7 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 298, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.751892
    ,"Long":106.72868
    ,"Polyline":"[106.72886658,10.74944115] ; [106.72860718,10.75113010.06.72868347]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"846"
    ,"Station_Code":"Q7 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Kho 18"
    ,"Station_Address":"267, đường Huỳnh  Tấn Phát, Quận 7"
    ,"Lat":10.7549
    ,"Long":106.726204
    ,"Polyline":"[106.72868347,10.75189209] ; [106.72846222,10.75277996] ; [106.72837830,10.75384045] ; [106.72827148,10.75407028] ; [106.72814941,10.75419998] ; [106.72781372,10.75444984] ; [106.72770691,10.75450039] ; [106.72618866,10.75485039] ; [106.72620392,10.75489998]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"845"
    ,"Station_Code":"Q7 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Vòng xoay Tân Thuận"
    ,"Station_Address":"135, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.755423
    ,"Long":106.723946
    ,"Polyline":"[106.72618866,10.75485039] ; [106.72393799,10.75537014]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"848"
    ,"Station_Code":"Q4 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Cảng Sài Gòn"
    ,"Station_Address":"Đối diện 466, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.758443
    ,"Long":106.7155
    ,"Polyline":"[106.72393799,10.75537014] ; [106.72338104,10.75549984] ; [106.72335815,10.75547028] ; [106.72326660,10.75547028] ; [106.72316742,10.75543976] ; [106.72303772,10.75537968] ; [106.72296906,10.75531006] ; [106.72289276,10.75524044] ; [106.72277832,10.75510025] ; [106.72263336,10.75502968] ; [106.72250366,10.75500011] ; [106.72235107,10.75502968] ; [106.72106171,10.75564003] ; [106.71882629,10.75666046] ; [106.71794128,10.75710964] ; [106.71639252,10.75782967] ; [106.71546173,10.75837994]"
    ,"Distance":"1051"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"847"
    ,"Station_Code":"Q4 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà thờ Th ánh An Tôn"
    ,"Station_Address":"Đối diện 448, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.759771
    ,"Long":106.713241
    ,"Polyline":"[106.71549225,10.75843906] ; [106.71503448,10.75870609] ; [106.71353912,10.75959682] ; [106.71326447,10.75981331]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"850"
    ,"Station_Code":"Q4 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Đại học Nguyễn Tất Thành"
    ,"Station_Address":"Đối diện 300A, đường Nguy ễn Tất Thành, Quận 4"
    ,"Lat":10.761557
    ,"Long":106.710194
    ,"Polyline":"[106.71324158,10.75977135] ; [106.71326447,10.75981331] ; [106.71009827,10.76159954] ; [106.71019745,10.76155663]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"849"
    ,"Station_Code":"Q4 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bưu Điện Quận 4"
    ,"Station_Address":"75-83, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.707941
    ,"Polyline":"[106.70953369,10.76183033] ; [106.70847321,10.76245975] ; [106.70836639,10.76255989] ; [106.70783997,10.76373005]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"852"
    ,"Station_Code":"Q4 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Xóm Chi ếu"
    ,"Station_Address":"34, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.764983
    ,"Long":106.706471
    ,"Polyline":"[106.70783997,10.76373005] ; [106.70745087,10.76461983] ; [106.70722961,10.76515961] ; [106.70713806,10.76511955] ; [106.70652771,10.76486969]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"851"
    ,"Station_Code":"Q4 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Đoàn Văn Bơ"
    ,"Station_Address":"106-108, đường  Hoàng Diệu, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.704031
    ,"Polyline":"[106.70652771,10.76486969] ; [106.70552063,10.76445007] ; [106.70462799,10.76406956] ; [106.70432281,10.76383018] ; [106.70410156,10.76364994]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"854"
    ,"Station_Code":"Q1 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Lê Thị Hồng Gấm"
    ,"Station_Address":"134, đường Calmette, Quận 1"
    ,"Lat":10.769178
    ,"Long":106.698334
    ,"Polyline":"[106.70410156,10.76364994] ; [106.70378113,10.76340961] ; [106.70372772,10.76354027] ; [106.70362091,10.76362991] ; [106.70185852,10.76490974] ; [106.70159912,10.76513004] ; [106.70108795,10.76564980] ; [106.70088196,10.76589012] ; [106.69989014,10.76714039] ; [106.69975281,10.76721001] ; [106.69883728,10.76840973] ; [106.69828033,10.76912975]"
    ,"Distance":"950"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường  Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69833374,10.76917839] ; [106.69828033,10.76912975] ; [106.69774628,10.76984978] ; [106.69750214,10.77019978] ; [106.69777679,10.77032661] ; [106.69841766,10.77060986] ; [106.69844818,10.77054024]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69844818,10.77054024] ; [106.69841766,10.77060986] ; [106.69901276,10.77085304] ; [106.69901276,10.77116489] ; [106.69885254,10.77136421] ; [106.69885254,10.77160168] ; [106.69872284,10.77182865] ; [106.69850159,10.77195454] ; [106.69823456,10.77188110.06.69808960] ; [10.77174377,106.69803619] ; [10.77149677,106.69813538] ; [10.77124882,106.69735718] ; [10.77028942,106.69595337] ; [10.76980972,106.69595337]"
    ,"Distance":"635"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69577789,10.76972771] ; [106.69577789,10.76972771] ; [106.69493103,10.76938725] ; [106.69409180,10.76904678] ; [106.69409180,10.76904678]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.69398499,10.76903534] ; [106.69384003,10.76895618] ; [106.69238281,10.76828003] ; [106.69049072,10.76753044] ; [106.68981171,10.76729584] ; [106.68961334,10.76770687] ; [106.68936157,10.76767635] ; [106.68936157,10.76767635]"
    ,"Distance":"575"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9 , đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68907166,10.76811028] ; [106.68920898,10.76819992] ; [106.68995667,10.76846981] ; [106.69026184,10.76858997]"
    ,"Distance":"141"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Th ị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69026184,10.76858997] ; [106.69268036,10.76959038] ; [106.69329834,10.76982975]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn  New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69329834,10.76982975] ; [106.69458008,10.77031040] ; [106.69667053,10.77118015] ; [106.69673157,10.77120972]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69673157,10.77120972] ; [106.69782257,10.77167606] ; [106.69801331,10.77159119] ; [106.69798279,10.77144337] ; [106.69802856,10.77124882] ; [106.69814301,10.77114868] ; [106.69742584,10.77035809] ; [106.69616699,10.76977825] ; [106.69644928,10.76921463] ; [106.69749451,10.77030563] ; [106.69841766,10.77056980]"
    ,"Distance":"822"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận  1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69841766,10.77056980] ; [106.69907379,10.77081966] ; [106.69899750,10.77095032] ; [106.69956207,10.77093029]"
    ,"Distance":"153"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77093029] ; [106.70192719,10.77085972]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70192719,10.77085972] ; [106.70407104,10.77072239]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2114"
    ,"Station_Code":"Q1 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Tòa nhà Bitexco"
    ,"Station_Address":"31-33-35 , đường Hàm Nghi, Quận 1"
    ,"Lat":10.770685
    ,"Long":106.704792
    ,"Polyline":"[106.70407104,10.77072239] ; [106.70478821,10.77068520]"
    ,"Distance":"79"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2115"
    ,"Station_Code":"Q1 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cục Hải Quan Thành Phố"
    ,"Station_Address":"1, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770637
    ,"Long":106.705785
    ,"Polyline":"[106.70510864,10.77070999] ; [106.70584106,10.77068043]"
    ,"Distance":"79"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2116"
    ,"Station_Code":"Q4 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đại học Luật"
    ,"Station_Address":"8A, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.767288
    ,"Long":106.706032
    ,"Polyline":"[106.70584106,10.77068043] ; [106.70614624,10.77066040] ; [106.70622253,10.77066040] ; [106.70619202,10.77042007] ; [106.70610809,10.77013969] ; [106.70601654,10.76990032] ; [106.70574188,10.76941013] ; [106.70565033,10.76922989] ; [106.70559692,10.76906013] ; [106.70555115,10.76877975] ; [106.70556641,10.76846981] ; [106.70564270,10.76817989] ; [106.70575714,10.76793957] ; [106.70597076,10.76760006] ; [106.70610046,10.76733017]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"855"
    ,"Station_Code":"Q4 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bưu Điện Quận 4"
    ,"Station_Address":"136-138, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.76385
    ,"Long":106.70763
    ,"Polyline":"[106.70610046,10.76733017] ; [106.70626068,10.76706982] ; [106.70639801,10.76675987] ; [106.70738220,10.76459026] ; [106.70780182,10.76366043]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"857"
    ,"Station_Code":"Q4 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Đại học Nguy ễn Tất Thành"
    ,"Station_Address":"276, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.7618
    ,"Long":106.70932
    ,"Polyline":"[106.70780182,10.76366043] ; [106.70832062,10.76249027] ; [106.70842743,10.76241016] ; [106.70903778,10.76204014] ; [106.70935059,10.76185989]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"858"
    ,"Station_Code":"Q4 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường Nguyễn Trãi"
    ,"Station_Address":"428, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.759423
    ,"Long":106.713359
    ,"Polyline":"[106.70935059,10.76185989] ; [106.71275330,10.75986958]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"860"
    ,"Station_Code":"Q4 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Cảng Sài Gòn"
    ,"Station_Address":"456, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.7579
    ,"Long":106.715977
    ,"Polyline":"[106.71275330,10.75986958] ; [106.71550751,10.75825977]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2122"
    ,"Station_Code":"Q7 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Khu chế xu ất Tân Thuận"
    ,"Station_Address":"298, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.75166
    ,"Long":106.728428
    ,"Polyline":"[106.71546936,10.75819969] ; [106.71804810,10.75698280] ; [106.72486115,10.75191307] ; [106.72559357,10.75224972] ; [106.72638702,10.75250340] ; [106.72718048,10.75260830] ; [106.72808838,10.75262928] ; [106.72850037,10.75228214] ; [106.72845459,10.75166035]"
    ,"Distance":"1742"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2123"
    ,"Station_Code":"Q7 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bùi Văn Ba"
    ,"Station_Address":"338, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.749151
    ,"Long":106.728643
    ,"Polyline":"[106.72855377,10.75185966] ; [106.72876740,10.74915028]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2125"
    ,"Station_Code":"Q7 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhà sách Tân Thuận"
    ,"Station_Address":"448A, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.745061
    ,"Long":106.729163
    ,"Polyline":"[106.72876740,10.74915028] ; [106.72884369,10.74833965] ; [106.72891998,10.74755001] ; [106.72923279,10.74543953]"
    ,"Distance":"472"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2124"
    ,"Station_Code":"Q7 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Huỳnh Tấn Phát"
    ,"Station_Address":"488, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.742901
    ,"Long":106.729485
    ,"Polyline":"[106.72916412,10.74506092] ; [106.72950745,10.74290085]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2126"
    ,"Station_Code":"Q7 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Nghĩa trang liệt sỹ Nhà Bè"
    ,"Station_Address":"Nghĩa trang liệt sỹ Nhà Bè, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.740381
    ,"Long":106.729876
    ,"Polyline":"[106.72950745,10.74290085] ; [106.72956848,10.74273205] ; [106.72987366,10.74038124]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2130"
    ,"Station_Code":"Q7 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Phú Mỹ"
    ,"Station_Address":"16/8, đường Hu ỳnh Tấn Phát, Quận 7"
    ,"Lat":10.736803
    ,"Long":106.730434
    ,"Polyline":"[106.73001099,10.74030018] ; [106.73040771,10.73754025] ; [106.73056793,10.73657990] ; [106.73078156,10.73499012] ; [106.73079681,10.73484993]"
    ,"Distance":"651"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2127"
    ,"Station_Code":"Q7 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Phú Thuận"
    ,"Station_Address":"748 , đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.731337
    ,"Long":106.731652
    ,"Polyline":"[106.73079681,10.73484993] ; [106.73101807,10.73359966] ; [106.73116302,10.73316956] ; [106.73175049,10.73143959]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2129"
    ,"Station_Code":"Q7 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Gò Ô Môi"
    ,"Station_Address":"955A, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.728654
    ,"Long":106.732838
    ,"Polyline":"[106.73175049,10.73143959] ; [106.73220825,10.73017025] ; [106.73262787,10.72894955] ; [106.73280334,10.72846031]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2128"
    ,"Station_Code":"Q7 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Gò Ô Môi"
    ,"Station_Address":"864, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.728433
    ,"Long":106.732677
    ,"Polyline":"[106.73280334,10.72846031] ; [106.73288727,10.72821999] ; [106.73307800,10.72770023] ; [106.73329926,10.72721958] ; [106.73342133,10.72698021]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2132"
    ,"Station_Code":"Q7 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Khu phố 3"
    ,"Station_Address":"936, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.724986
    ,"Long":106.734302
    ,"Polyline":"[106.73342896,10.72696018] ; [106.73426056,10.72531986] ; [106.73439789,10.72506046]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2131"
    ,"Station_Code":"Q7 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Mầm non Ban Mai"
    ,"Station_Address":"1004, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.722836
    ,"Long":106.735412
    ,"Polyline":"[106.73439789,10.72506046] ; [106.73548126,10.72299004]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2135"
    ,"Station_Code":"Q7 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ban chỉ huy QS Quận 7"
    ,"Station_Address":"1094, đường Huỳnh Tấn Phát, Qu ận 7"
    ,"Lat":10.720833
    ,"Long":106.736378
    ,"Polyline":"[106.73548126,10.72299004] ; [106.73616028,10.72165012] ; [106.73639679,10.72115040] ; [106.73648834,10.72087002]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2133"
    ,"Station_Code":"Q7 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường Nguyễn Văn Hưởng"
    ,"Station_Address":"1166, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.71884
    ,"Long":106.736593
    ,"Polyline":"[106.73641968,10.72084332] ; [106.73648834,10.72068024] ; [106.73654175,10.72031593] ; [106.73657990,10.72000027] ; [106.73670959,10.71895027] ; [106.73664856,10.71894264]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2136"
    ,"Station_Code":"Q7 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Nhà sách Nguyễn Văn Cừ"
    ,"Station_Address":"1260, đường Hu ỳnh Tấn Phát, Quận 7"
    ,"Lat":10.7166
    ,"Long":106.736732
    ,"Polyline":"[106.73664856,10.71894264] ; [106.73664856,10.71881962] ; [106.73671722,10.71754932] ; [106.73672485,10.71725368]"
    ,"Distance":"188"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2134"
    ,"Station_Code":"Q7 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Hoàng Quốc Việt"
    ,"Station_Address":"1312, đường Huỳnh  Tấn Phát, Quận 7"
    ,"Lat":10.714782
    ,"Long":106.736813
    ,"Polyline":"[106.73681641,10.71726036] ; [106.73684692,10.71693993] ; [106.73692322,10.71516991]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1362"
    ,"Station_Code":"Q7 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường Ngô Quyền"
    ,"Station_Address":"1360, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.712974
    ,"Long":106.736904
    ,"Polyline":"[106.73692322,10.71516991] ; [106.73702240,10.71294975]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1358"
    ,"Station_Code":"Q7 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"An Chánh Dương"
    ,"Station_Address":"1400, đường Huỳnh  Tấn Phát, Quận 7"
    ,"Lat":10.711002
    ,"Long":106.737016
    ,"Polyline":"[106.73696136,10.71294212] ; [106.73696136,10.71269417] ; [106.73703003,10.71166134] ; [106.73704529,10.71141148]"
    ,"Distance":"171"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1360"
    ,"Station_Code":"Q7 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chùa Pháp Hoa"
    ,"Station_Address":"1452, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.708958
    ,"Long":106.737152
    ,"Polyline":"[106.73710632,10.71140957] ; [106.73722839,10.70895958]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1366"
    ,"Station_Code":"Q7 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Phạm Hữu Lầu"
    ,"Station_Address":"1520-1522, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.705626
    ,"Long":106.737427
    ,"Polyline":"[106.73722839,10.70895958] ; [106.73737335,10.70650959] ; [106.73750305,10.70563984]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1055"
    ,"Station_Code":"HNB 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Phú Xuân"
    ,"Station_Address":"1678-1680 (26/1-26/2), đường Huỳnh Tấn Phát, Huyện  Nhà Bè"
    ,"Lat":10.701088
    ,"Long":106.73817
    ,"Polyline":"[106.73750305,10.70563984] ; [106.73757172,10.70528030] ; [106.73770905,10.70495987] ; [106.73783875,10.70454979] ; [106.73811340,10.70296001] ; [106.73819733,10.70226955] ; [106.73819733,10.70186043] ; [106.73818207,10.70147038] ; [106.73815918,10.70137024] ; [106.73818970,10.70112991] ; [106.73822784,10.70083046]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1147"
    ,"Station_Code":"HNB 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nha khoa Khánh Minh"
    ,"Station_Address":"1901B, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.6984
    ,"Long":106.738785
    ,"Polyline":"[106.73816681,10.70079994] ; [106.73816681,10.70079994] ; [106.73845673,10.69941711] ; [106.73878479,10.69839954] ; [106.73878479,10.69839954]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1058"
    ,"Station_Code":"HNB 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Công an Thị trấn Nhà Bè"
    ,"Station_Address":"42/7, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.695869
    ,"Long":106.739666
    ,"Polyline":"[106.73878479,10.69839954] ; [106.73946381,10.69636726]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1061"
    ,"Station_Code":"HNB 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường Lâm Văn Bền"
    ,"Station_Address":"57 /4, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.69345
    ,"Long":106.740546
    ,"Polyline":"[106.73953247,10.69639015] ; [106.74069214,10.69309998]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1063"
    ,"Station_Code":"HNB 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Chùa Lá"
    ,"Station_Address":"4/11C, đường Huỳnh Tấn Ph át, Huyện Nhà Bè"
    ,"Lat":10.690113
    ,"Long":106.741694
    ,"Polyline":"[106.74069214,10.69309998] ; [106.74167633,10.69027042]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1060"
    ,"Station_Code":"HNB 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"2132, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.686992
    ,"Long":106.743314
    ,"Polyline":"[106.74167633,10.69027042] ; [106.74214172,10.68898010.06.74227905] ; [10.68859005,106.74259949] ; [10.68799973,106.74342346]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1065"
    ,"Station_Code":"HNB 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chùa Tháp Võ"
    ,"Station_Address":"536, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.683998
    ,"Long":106.74538
    ,"Polyline":"[106.74342346,10.68688965] ; [106.74530029,10.68414974]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1062"
    ,"Station_Code":"HNB 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đào Tông Nguyên"
    ,"Station_Address":"Đối di ện 23/3, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.682021
    ,"Long":106.746764
    ,"Polyline":"[106.74530029,10.68414974] ; [106.74678040,10.68200970]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1066"
    ,"Station_Code":"HNB 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Công Ti ến Thọ"
    ,"Station_Address":"15/6B, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.679275
    ,"Long":106.750803
    ,"Polyline":"[106.74678802,10.68200016] ; [106.74761200,10.68082047] ; [106.74803162,10.68043041] ; [106.74870300,10.68013000]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"1064"
    ,"Station_Code":"HNB 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngã Ba Bờ Đăng"
    ,"Station_Address":"12/8H, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.6784
    ,"Long":106.753196
    ,"Polyline":"[106.74870300,10.68013000] ; [106.75308990,10.67850018]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2138"
    ,"Station_Code":"HNB 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Ủy ban xã Phú Xuân"
    ,"Station_Address":"790 , đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.677925
    ,"Long":106.754419
    ,"Polyline":"[106.75308228,10.67844963] ; [106.75464630,10.67784977]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2137"
    ,"Station_Code":"HNB 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Việt Long  Sài Gòn"
    ,"Station_Address":"Công ty Việt Long  Sài Gòn, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.676897
    ,"Long":106.757192
    ,"Polyline":"[106.75464630,10.67784977] ; [106.75713348,10.67689037]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2141"
    ,"Station_Code":"HNB 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Trường L ê Văn Hưu"
    ,"Station_Address":"Đối diện 78/4 , đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.675922
    ,"Long":106.759611
    ,"Polyline":"[106.75713348,10.67689037] ; [106.75988770,10.67584038]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2139"
    ,"Station_Code":"HNB 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Chùa Bà  Châu Đốc 2"
    ,"Station_Address":"2864, đường  Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.674752
    ,"Long":106.76268
    ,"Polyline":"[106.75988770,10.67584038] ; [106.76262665,10.67483044]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2144"
    ,"Station_Code":"HNB 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Phà Bình Khánh"
    ,"Station_Address":"2756, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.673761
    ,"Long":106.765233
    ,"Polyline":"[106.76262665,10.67483044] ; [106.76499176,10.67393017]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"42"
    ,"Station_Id":"2140"
    ,"Station_Code":"BX 72"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Bình Khánh"
    ,"Station_Address":"BÃI XE BUÝT BẾN ĐÒ BÌNH KHÁNH, đường Huỳnh Tấn Phát, Huyện Nhà  Bè"
    ,"Lat":10.673856
    ,"Long":106.766263
    ,"Polyline":"[106.76499176,10.67393970] ; [106.76577759,10.67364025] ; [106.76589966,10.67362976] ; [106.76611328,10.67360020] ; [106.76631927,10.67364025] ; [106.76616669,10.67407990]"
    ,"Distance":"233"
  }]