export const Route40 =[

  {
     "Route_Id":"40"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguyễn Ảnh Thủ, Quận  12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1618"
    ,"Station_Code":"Q12 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"Trường Mau gi áo Họa Mi 2, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877224
    ,"Long":106.641283
    ,"Polyline":"[106.64203644,10.87744999] ; [106.64179993,10.87712860] ; [106.64128113,10.87722397]"
    ,"Distance":"102"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1620"
    ,"Station_Code":"Q12 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"NVH Lao  động Quận 12"
    ,"Station_Address":"NVH Lao động Q.12, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.879062
    ,"Long":106.637265
    ,"Polyline":"[106.64128113,10.87722397] ; [106.64042664,10.87736034] ; [106.63726807,10.87906170]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1622"
    ,"Station_Code":"Q12 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Thiệp Cưới"
    ,"Station_Address":"442, đường  Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.880495
    ,"Long":106.634685
    ,"Polyline":"[106.63726807,10.87906170] ; [106.63468170,10.88049507]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1625"
    ,"Station_Code":"Q12 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã 3 Đông Quang"
    ,"Station_Address":"544, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.882718
    ,"Long":106.630688
    ,"Polyline":"[106.63468170,10.88049507] ; [106.63209534,10.88184929] ; [106.63069153,10.88271809]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1627"
    ,"Station_Code":"Q12 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường mầm non Hiệp Thành"
    ,"Station_Address":"38/4C, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.881665
    ,"Long":106.628135
    ,"Polyline":"[106.63069153,10.88271809] ; [106.63002777,10.88308716] ; [106.62939453,10.88337135] ; [106.62897491,10.88291836] ; [106.62813568,10.88166523]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"6836"
    ,"Station_Code":"Q12 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã ba nước đá"
    ,"Station_Address":"50, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877798
    ,"Long":106.625276
    ,"Polyline":"[106.62813568,10.88166523] ; [106.62753296,10.88073254] ; [106.62667847,10.87954140] ; [106.62527466,10.87779808]"
    ,"Distance":"533"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"6838"
    ,"Station_Code":"Q12 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Nguyễn Ảnh Thủ"
    ,"Station_Address":"138, đường Nguyễn  Ảnh Thủ, Quận 12"
    ,"Lat":10.876233
    ,"Long":106.62387
    ,"Polyline":"[106.62527466,10.87779808] ; [106.62509918,10.87757683] ; [106.62415314,10.87650681] ; [106.62387085,10.87623310]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"6837"
    ,"Station_Code":"Q12 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Nguyễn Ảnh Thủ"
    ,"Station_Address":"112B, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.875696
    ,"Long":106.623414
    ,"Polyline":"[106.62387085,10.87623310.06.62341309]"
    ,"Distance":"78"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"6839"
    ,"Station_Code":"Q12 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nguyễn Ảnh Thủ"
    ,"Station_Address":"180, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.873462
    ,"Long":106.621392
    ,"Polyline":"[106.62341309,10.87569618] ; [106.62139130,10.87346172]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"6840"
    ,"Station_Code":"Q12 185"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nguyễn Ảnh Thủ"
    ,"Station_Address":"160, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.870575
    ,"Long":106.618667
    ,"Polyline":"[106.62139130,10.87346172] ; [106.61866760,10.87057495]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2062"
    ,"Station_Code":"Q12 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường  ĐH GTVT TPHCM"
    ,"Station_Address":"Đối diện 12/8, đường Tô Ký, Quận 12"
    ,"Lat":10.866608
    ,"Long":106.615684
    ,"Polyline":"[106.61866760,10.87057495] ; [106.61808014,10.86987972] ; [106.61542511,10.86736202] ; [106.61568451,10.86660767]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2085"
    ,"Station_Code":"Q12 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Doanh trại Quân Đội"
    ,"Station_Address":"583, đường Tô Ký, Quận 12"
    ,"Lat":10.862852
    ,"Long":106.616821
    ,"Polyline":"[106.61568451,10.86660767] ; [106.61629486,10.86491680] ; [106.61668396,10.86351585] ; [106.61682129,10.86285210]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2086"
    ,"Station_Code":"Q12 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Tân Chánh Hiệp"
    ,"Station_Address":"Trung tâm thể dục thể thao Q.12, đ ường Tô Ký, Quận 12"
    ,"Lat":10.859354
    ,"Long":106.617696
    ,"Polyline":"[106.61682129,10.86285210.06.61716461] ; [10.86195660,106.61769867]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2087"
    ,"Station_Code":"Q12 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chiếc nón Kỳ Diệu"
    ,"Station_Address":"535, đường T ô Ký, Quận 12"
    ,"Lat":10.857837
    ,"Long":106.619026
    ,"Polyline":"[106.61769867,10.85935402] ; [106.61784363,10.85883236] ; [106.61902618,10.85783672]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2088"
    ,"Station_Code":"Q12 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"điện lực Hóc Môn"
    ,"Station_Address":"Đối diện điện lực Hóc Môn, đường Tô Ký, Quận 12"
    ,"Lat":10.856309
    ,"Long":106.621429
    ,"Polyline":"[106.61902618,10.85783672] ; [106.62040710,10.85687733] ; [106.62078857,10.85664558] ; [106.62142944,10.85630894]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2089"
    ,"Station_Code":"Q12 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cửa hàng Vinh Phú"
    ,"Station_Address":"79, đường Tô  Ký, Quận 12"
    ,"Lat":10.854931
    ,"Long":106.624161
    ,"Polyline":"[106.62142944,10.85630894] ; [106.62330627,10.85549736] ; [106.62345886,10.85537052] ; [106.62387848,10.85514927] ; [106.62416077,10.85493088]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2090"
    ,"Station_Code":"Q12 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công viên PM Quang Trung"
    ,"Station_Address":"389, đường T ô Ký, Quận 12"
    ,"Lat":10.852871
    ,"Long":106.626099
    ,"Polyline":"[106.62416077,10.85493088] ; [106.62436676,10.85483360] ; [106.62471008,10.85460663] ; [106.62517548,10.85420704] ; [106.62561035,10.85375881] ; [106.62580109,10.85348988] ; [106.62609863,10.85287094]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2091"
    ,"Station_Code":"Q12 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Cầu vượt Quang Trung"
    ,"Station_Address":"B45, đường Quang Trung, Quận 12"
    ,"Lat":10.848996
    ,"Long":106.632679
    ,"Polyline":"[106.62609863,10.85287094] ; [106.62686157,10.85161495] ; [106.62703705,10.85140419] ; [106.62726593,10.85124588] ; [106.62753296,10.85110378] ; [106.62833405,10.85093975] ; [106.63010406,10.85061359] ; [106.63061523,10.85047150] ; [106.63114929,10.85024452] ; [106.63268280,10.84899616]"
    ,"Distance":"882"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2056"
    ,"Station_Code":"Q12 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"154, đường Quang Trung, Quận 12"
    ,"Lat":10.847842
    ,"Long":106.634422
    ,"Polyline":"[106.63268280,10.84899616] ; [106.63442230,10.84784222]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2093"
    ,"Station_Code":"QGV 169"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"927, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.844981
    ,"Long":106.638985
    ,"Polyline":"[106.63442230,10.84784222] ; [106.63562012,10.84708881] ; [106.63705444,10.84607697] ; [106.63797760,10.84552956] ; [106.63898468,10.84498119]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2094"
    ,"Station_Code":"QGV 170"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"869-871 (Kế A4-A5), đường Quang Trung, Qu ận Gò Vấp"
    ,"Lat":10.843801
    ,"Long":106.640671
    ,"Polyline":"[106.63898468,10.84498119] ; [106.63929749,10.84482384] ; [106.64067078,10.84380054]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2095"
    ,"Station_Code":"QGV 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"819, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.842036
    ,"Long":106.643311
    ,"Polyline":"[106.64067078,10.84380054] ; [106.64178467,10.84309006] ; [106.64331055,10.84203625]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2098"
    ,"Station_Code":"QGV 172"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"751 (364), đường Quang Trung , Quận Gò Vấp"
    ,"Lat":10.839758
    ,"Long":106.646347
    ,"Polyline":"[106.64331055,10.84203625] ; [106.64517975,10.84074593] ; [106.64634705,10.83975792]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2096"
    ,"Station_Code":"QGV 173"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Ngã ba Tân Sơn"
    ,"Station_Address":"Đối diện 972 (Công  ty ISUZU), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83902
    ,"Long":106.647728
    ,"Polyline":"[106.64634705,10.83975792] ; [106.64698792,10.83931255] ; [106.64772797,10.83901978]"
    ,"Distance":"173"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2099"
    ,"Station_Code":"QGV 174"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Dệt may  Phương Đông"
    ,"Station_Address":"695 (đối diện 97), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83839
    ,"Long":106.650246
    ,"Polyline":"[106.64772797,10.83901978] ; [106.64886475,10.83876991] ; [106.65024567,10.83839035]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2097"
    ,"Station_Code":"QGV 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường THPT Nguyễn Công Trứ"
    ,"Station_Address":"Đối diện 842, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.837576
    ,"Long":106.653412
    ,"Polyline":"[106.65024567,10.83839035] ; [106.65183258,10.83800030] ; [106.65341187,10.83757591]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"4627"
    ,"Station_Code":"QGV 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"12B, Quang Trung"
    ,"Station_Address":"Đối diện 746 (12B), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836552
    ,"Long":106.657376
    ,"Polyline":"[106.65341187,10.83757591] ; [106.65737915,10.83655167]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"4628"
    ,"Station_Code":"QGV 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Công an Quận Gò Vấp"
    ,"Station_Address":"Đ ối diện 628A (9), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835561
    ,"Long":106.661367
    ,"Polyline":"[106.65737915,10.83655167] ; [106.66136932,10.83556080]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"926"
    ,"Station_Code":"QGV 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Huỳnh Kim"
    ,"Station_Address":"621, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.834918
    ,"Long":106.663395
    ,"Polyline":"[106.66136932,10.83556080] ; [106.66184235,10.83547115] ; [106.66272736,10.83520794] ; [106.66339874,10.83491802]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1665"
    ,"Station_Code":"QGV 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"VKSND Quận Gò Vấp"
    ,"Station_Address":"523, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833828
    ,"Long":106.665283
    ,"Polyline":"[106.66339874,10.83491802] ; [106.66433716,10.83452797] ; [106.66491699,10.83418083] ; [106.66528320,10.83382797]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"987"
    ,"Station_Code":"QGV 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Quang Trung"
    ,"Station_Address":"387, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.830791
    ,"Long":106.669167
    ,"Polyline":"[106.66528320,10.83382797] ; [106.66620636,10.83316898] ; [106.66763306,10.83192539] ; [106.66916656,10.83079147]"
    ,"Distance":"543"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"984"
    ,"Station_Code":"QGV 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Nhà Thờ Xóm Thuốc"
    ,"Station_Address":"305, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.829139
    ,"Long":106.672058
    ,"Polyline":"[106.66916656,10.83079147] ; [106.66951752,10.83052921] ; [106.67032623,10.83001804] ; [106.67205811,10.82913876]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"986"
    ,"Station_Code":"QGV 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Xóm thu ốc"
    ,"Station_Address":"205, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.828095
    ,"Long":106.67485
    ,"Polyline":"[106.67205811,10.82913876] ; [106.67277527,10.82886982] ; [106.67485046,10.82809544]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"988"
    ,"Station_Code":"QGV 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Công ty  32"
    ,"Station_Address":"67, đường Quang Trung , Quận Gò Vấp"
    ,"Lat":10.827308
    ,"Long":106.677185
    ,"Polyline":"[106.67485046,10.82809544] ; [106.67718506,10.82730770]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"991"
    ,"Station_Code":"QGV 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Đối diện siêu thị Văn Lang, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.82661
    ,"Long":106.679153
    ,"Polyline":"[106.67718506,10.82730770] ; [106.67915344,10.82660961]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2100"
    ,"Station_Code":"QGVT159"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Chi cục Thuế Quận Gò Vấp"
    ,"Station_Address":"159, đường Nguy ễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.826214
    ,"Long":106.682159
    ,"Polyline":"[106.67915344,10.82660961] ; [106.67969513,10.82645607] ; [106.67978668,10.82635593] ; [106.67989349,10.82629299] ; [106.68003845,10.82630920] ; [106.68016052,10.82636166] ; [106.68061066,10.82625580] ; [106.68102264,10.82621956] ; [106.68143463,10.82620335] ; [106.68187714,10.82625103] ; [106.68215942,10.82621384]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2103"
    ,"Station_Code":"QGV 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa Bà Thiên Hậu"
    ,"Station_Address":"87, đường Nguy ễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.825382
    ,"Long":106.684531
    ,"Polyline":"[106.68215942,10.82621384] ; [106.68240356,10.82635117] ; [106.68351746,10.82615566] ; [106.68375397,10.82606697] ; [106.68448639,10.82555008] ; [106.68495178,10.82523441] ; [106.68516541,10.82507610]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2101"
    ,"Station_Code":"QGVT161"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"5, đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.82215690612793
    ,"Long":106.68833923339844
    ,"Polyline":"[106.68516541,10.82507610.06.68544769] ; [10.82500744,106.68579865] ; [10.82482815,106.68608856] ; [10.82459641,106.68655396] ; [10.82408047,106.68746185] ; [10.82347393,106.68786621] ; [10.82311630,106.68833923]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2104"
    ,"Station_Code":"QGV 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Ba Nguyên Hồng"
    ,"Station_Address":"497, đường Lê Quang Định, Quận Gò Vấp"
    ,"Lat":10.817979
    ,"Long":106.689171
    ,"Polyline":"[106.68833923,10.82215691] ; [106.68878174,10.82137680] ; [106.68909454,10.82078171] ; [106.68921661,10.82066059] ; [106.68945313,10.82046604] ; [106.68977356,10.82014942] ; [106.68990326,10.81997013] ; [106.68999481,10.81977558] ; [106.68988037,10.81942272] ; [106.68975830,10.81915379] ; [106.68917084,10.81797886]"
    ,"Distance":"544"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2106"
    ,"Station_Code":"QBTH 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chùa Già Lam"
    ,"Station_Address":"435, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.814411
    ,"Long":106.689616
    ,"Polyline":"[106.68917084,10.81797886] ; [106.68854523,10.81656170] ; [106.68853760,10.81629753] ; [106.68856812,10.81603432] ; [106.68862152,10.81578636] ; [106.68875885,10.81553936] ; [106.68906403,10.81517506] ; [106.68930817,10.81500721] ; [106.68954468,10.81475353] ; [106.68961334,10.81441116]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2105"
    ,"Station_Code":"QBTH 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã Tư Xóm Gà"
    ,"Station_Address":"337, đường L ê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.811967
    ,"Long":106.690502
    ,"Polyline":"[106.68961334,10.81441116] ; [106.68980408,10.81354713] ; [106.68995667,10.81294155] ; [106.69008636,10.81265163] ; [106.69049835,10.81196690]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2108"
    ,"Station_Code":"QBTH 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Chùa Hưng  Tự Gia"
    ,"Station_Address":"235, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.809306
    ,"Long":106.693232
    ,"Polyline":"[106.69049835,10.81196690] ; [106.69079590,10.81152916] ; [106.69106293,10.81108665] ; [106.69122314,10.81096554] ; [106.69158173,10.81087589] ; [106.69201660,10.81074905] ; [106.69213104,10.81064415] ; [106.69234467,10.81029606] ; [106.69250488,10.80994797] ; [106.69274139,10.80966377] ; [106.69322968,10.80930614]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2107"
    ,"Station_Code":"QBTH 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Rạp Đại  Đồng"
    ,"Station_Address":"27, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.805712
    ,"Long":106.694965
    ,"Polyline":"[106.69322968,10.80930614] ; [106.69387817,10.80885220] ; [106.69503784,10.80827808] ; [106.69496155,10.80571175]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2110"
    ,"Station_Code":"QBTH 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"1, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803583
    ,"Long":106.694906
    ,"Polyline":"[106.69496155,10.80571175] ; [106.69490814,10.80358315]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2037"
    ,"Station_Code":"QBTH 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"129, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.801391
    ,"Long":106.696456
    ,"Polyline":"[106.69490814,10.80358315] ; [106.69483185,10.80273438] ; [106.69650269,10.80247116] ; [106.69645691,10.80139065]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2034"
    ,"Station_Code":"QBTH 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"95, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.798625
    ,"Long":106.696279
    ,"Polyline":"[106.69645691,10.80139065] ; [106.69628143,10.79862499]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2112"
    ,"Station_Code":"QBTH 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"51, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.79423
    ,"Long":106.695968
    ,"Polyline":"[106.69628143,10.79862499] ; [106.69596863,10.79423046]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"726"
    ,"Station_Code":"Q1 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Đền Trần Hưng Đạo"
    ,"Station_Address":"18, đường Võ Thị Sáu, Quận 1"
    ,"Lat":10.791369
    ,"Long":106.695238
    ,"Polyline":"[106.69596863,10.79423046] ; [106.69583130,10.79191685] ; [106.69523621,10.79136944]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2111"
    ,"Station_Code":"Q1 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Công viên Lê Văn Tám"
    ,"Station_Address":"78 , đường Võ Thị Sáu, Quận 1"
    ,"Lat":10.788896
    ,"Long":106.692818
    ,"Polyline":"[106.69523621,10.79136944] ; [106.69281769,10.78889561]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"233"
    ,"Station_Code":"Q3 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Công viên Lê Văn Tám"
    ,"Station_Address":"243, đường Hai  Bà Trưng, Quận 3"
    ,"Lat":10.787174
    ,"Long":106.692653
    ,"Polyline":"[106.69281769,10.78889561] ; [106.69185638,10.78787518] ; [106.69264984,10.78717422]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"235"
    ,"Station_Code":"Q3 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Trần Cao Vân"
    ,"Station_Address":"157, đường Hai Bà Trưng, Quận 3"
    ,"Lat":10.784023
    ,"Long":106.696625
    ,"Polyline":"[106.69264984,10.78717422] ; [106.69662476,10.78402328]"
    ,"Distance":"558"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"236"
    ,"Station_Code":"Q1 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Lê Duẩn"
    ,"Station_Address":"Đối diện Lãnh sự quán Pháp, đường Hai Bà Trưng, Qu ận 1"
    ,"Lat":10.78191
    ,"Long":106.69902
    ,"Polyline":"[106.69662476,10.78402328] ; [106.69783020,10.78301620] ; [106.69902039,10.78190994]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2696"
    ,"Station_Code":"Q1 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Nhà thờ Đức Bà"
    ,"Station_Address":"12, đường Lê Duẩn, Quận 1"
    ,"Lat":10.780676
    ,"Long":106.698854
    ,"Polyline":"[106.69902039,10.78190994] ; [106.69959259,10.78149319] ; [106.69885254,10.78067589]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"200"
    ,"Station_Code":"Q1 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Tòa Án Thành Phố"
    ,"Station_Address":"131, đường Nam Kỳ Khởi Ngh ĩa, Quận 1"
    ,"Lat":10.776052
    ,"Long":106.698647
    ,"Polyline":"[106.69885254,10.78067589] ; [106.69641113,10.77817822] ; [106.69864655,10.77605247]"
    ,"Distance":"726"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"199"
    ,"Station_Code":"Q1 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Chùa Ông"
    ,"Station_Address":"Đối diện 96A, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.773957
    ,"Long":106.699722
    ,"Polyline":"[106.69864655,10.77605247] ; [106.69898987,10.77582264] ; [106.69932556,10.77506924] ; [106.69972229,10.77395725]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"201"
    ,"Station_Code":"Q1 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Trường C ĐKT Cao Thắng"
    ,"Station_Address":"Đối diện 86 , đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.771416
    ,"Long":106.700851
    ,"Polyline":"[106.69972229,10.77395725] ; [106.70085144,10.77141571]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Công ty Đường  sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70085144,10.77141571] ; [106.70104980,10.77109623] ; [106.69935608,10.77116299]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Bến Thành A"
    ,"Station_Address":"Bến Thành, đường  Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69909668,10.77116489] ; [106.69853973,10.77089596]"
    ,"Distance":"96"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Qu ận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853973,10.77089596] ; [106.69595337,10.76980972]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.68959808,10.76720715] ; [106.68936157,10.76767635]"
    ,"Distance":"579"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài  Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất T ùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68921661,10.76813412] ; [106.69033813,10.76855087]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Th ị Nghĩa"
    ,"Station_Address":"Đối diện 96, đư ờng Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê  Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69783020,10.77158642] ; [106.69804382,10.77156448] ; [106.69803619,10.77149105] ; [106.69804382,10.77141762] ; [106.69807434,10.77134895] ; [106.69814301,10.77126408] ; [106.69735718,10.77033138] ; [106.69618988,10.76987362] ; [106.69647980,10.76920414] ; [106.69749451,10.77023697] ; [106.69845581,10.77047157]"
    ,"Distance":"809"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69845581,10.77047157] ; [106.69876862,10.77061653] ; [106.69907379,10.77092743] ; [106.69956207,10.77094269]"
    ,"Distance":"139"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm  Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77094269] ; [106.70195770,10.77082157]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"4271"
    ,"Station_Code":"Q1 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Đền Thờ Ấn Giáo, Pasteur"
    ,"Station_Address":"Đền Thờ Ấn Gi áo, đường Pasteur, Quận 1"
    ,"Lat":10.773595
    ,"Long":106.70139
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70257568,10.77080059] ; [106.70139313,10.77359486]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2724"
    ,"Station_Code":"Q1 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Lê Thánh Tôn"
    ,"Station_Address":"144, đường Pasteur, Quận 1"
    ,"Lat":10.775088
    ,"Long":106.700768
    ,"Polyline":"[106.70139313,10.77359486] ; [106.70076752,10.77508831]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"4272"
    ,"Station_Code":"Q1 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Lý Tự Trọng"
    ,"Station_Address":"158, đường Pasteur, Quận 1"
    ,"Lat":10.777089
    ,"Long":106.699657
    ,"Polyline":"[106.70076752,10.77508831] ; [106.69995117,10.77685070] ; [106.69965363,10.77708912]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"4273"
    ,"Station_Code":"Q1 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Công viên 30/4"
    ,"Station_Address":"178, đường Pasteur, Quận 1"
    ,"Lat":10.778307999999999
    ,"Long":106.698333
    ,"Polyline":"[106.69965363,10.77708912] ; [106.69833374,10.77830791]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2692"
    ,"Station_Code":"Q1 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà thờ Đức Bà"
    ,"Station_Address":"47, đường Lê  Duẩn, Quận 1"
    ,"Lat":10.780794
    ,"Long":106.69912
    ,"Polyline":"[106.69833374,10.77830791] ; [106.69752502,10.77907467] ; [106.69836426,10.77999115] ; [106.69848633,10.78009129] ; [106.69857788,10.78005505] ; [106.69866180,10.78008080] ; [106.69872284,10.78016567] ; [106.69872284,10.78023911] ; [106.69870758,10.78031826] ; [106.69911957,10.78079414]"
    ,"Distance":"396"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2029"
    ,"Station_Code":"Q1 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Cty Xổ Số Kiến Thiết"
    ,"Station_Address":"Sofitel Plaza, đường Lê Duẩn, Quận 1"
    ,"Lat":10.78417
    ,"Long":106.702303
    ,"Polyline":"[106.69911957,10.78079414] ; [106.70230103,10.78417015]"
    ,"Distance":"512"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1096"
    ,"Station_Code":"Q1 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại học Khoa học xã hội nhân văn"
    ,"Station_Address":"10, đường Đinh  Tiên Hoàng, Quận 1"
    ,"Lat":10.785778
    ,"Long":106.702663
    ,"Polyline":"[106.70230103,10.78417015] ; [106.70319366,10.78521919] ; [106.70265961,10.78577805]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2030"
    ,"Station_Code":"Q1 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"SVĐ Hoa Lư"
    ,"Station_Address":"2, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.7872
    ,"Long":106.701027
    ,"Polyline":"[106.70265961,10.78577805] ; [106.70102692,10.78719997]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2031"
    ,"Station_Code":"Q1 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"18, đường Đinh Tiên Hoàng, Quận 1"
    ,"Lat":10.788253
    ,"Long":106.699898
    ,"Polyline":"[106.70102692,10.78719997] ; [106.69989777,10.78825283]"
    ,"Distance":"170"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2032"
    ,"Station_Code":"Q1 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Điện Biên  Phủ"
    ,"Station_Address":"68, đường Đinh Tiên  Hoàng, Quận 1"
    ,"Lat":10.789892
    ,"Long":106.698135
    ,"Polyline":"[106.69989777,10.78825283] ; [106.69813538,10.78989220]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2033"
    ,"Station_Code":"QBTH 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Bông"
    ,"Station_Address":"96, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.796032
    ,"Long":106.696225
    ,"Polyline":"[106.69813538,10.78989220] ; [106.69591522,10.79187965] ; [106.69595337,10.79293346] ; [106.69612122,10.79464626] ; [106.69617462,10.79573154] ; [106.69622803,10.79603195]"
    ,"Distance":"792"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2727"
    ,"Station_Code":"QBTH 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Bệnh viện Bình Thạnh"
    ,"Station_Address":"114, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.798066
    ,"Long":106.696376
    ,"Polyline":"[106.69622803,10.79603195] ; [106.69637299,10.79806614]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2109"
    ,"Station_Code":"QBTH 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"Đối diện 129, đường Đinh Tiên Hoàng, Quận Bình Thạnh"
    ,"Lat":10.80147
    ,"Long":106.696569
    ,"Polyline":"[106.69637299,10.79806614] ; [106.69657135,10.80146980]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"UBND Quận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69657135,10.80146980] ; [106.69663239,10.80270863] ; [106.69578552,10.80281925]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2039"
    ,"Station_Code":"QBTH 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"2, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.803488
    ,"Long":106.695013
    ,"Polyline":"[106.69578552,10.80281925] ; [106.69498444,10.80291367] ; [106.69501495,10.80348778]"
    ,"Distance":"153"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2035"
    ,"Station_Code":"QBTH 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Rạp Đại Đồng"
    ,"Station_Address":"48, đường Nơ Trang Long, Quận Bình Thạnh"
    ,"Lat":10.806076
    ,"Long":106.695083
    ,"Polyline":"[106.69501495,10.80348778] ; [106.69508362,10.80607605]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2041"
    ,"Station_Code":"QBTH 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã Tư BÌnh Hòa"
    ,"Station_Address":"276, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.808594
    ,"Long":106.694552
    ,"Polyline":"[106.69508362,10.80607605] ; [106.69515228,10.80830956] ; [106.69454956,10.80859375]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2036"
    ,"Station_Code":"QBTH 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chùa Hưng Tự Gia"
    ,"Station_Address":"336, đường Lê Quang Định,  Quận Bình Thạnh"
    ,"Lat":10.809501
    ,"Long":106.693093
    ,"Polyline":"[106.69454956,10.80859375] ; [106.69390869,10.80893135] ; [106.69309235,10.80950069]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2038"
    ,"Station_Code":"QBTH 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã Tư Xóm Gà"
    ,"Station_Address":"424, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.812272
    ,"Long":106.690416
    ,"Polyline":"[106.69309235,10.80950069] ; [106.69279480,10.80972195] ; [106.69258118,10.81001186] ; [106.69239807,10.81036472] ; [106.69219208,10.81072330] ; [106.69204712,10.81082821] ; [106.69122314,10.81106567] ; [106.69114685,10.81112862] ; [106.69041443,10.81227207]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2043"
    ,"Station_Code":"QBTH 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chùa Già Lam"
    ,"Station_Address":"488, đường Lê Quang Định, Quận Bình Th ạnh"
    ,"Lat":10.814274
    ,"Long":106.689767
    ,"Polyline":"[106.69041443,10.81227207] ; [106.69013977,10.81270409] ; [106.68997955,10.81318378] ; [106.68976593,10.81427383]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2047"
    ,"Station_Code":"QGV 185"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã Ba Nguyên Hồng"
    ,"Station_Address":"566, đường Lê Quang Định,  Quận Gò Vấp"
    ,"Lat":10.817873
    ,"Long":106.689278
    ,"Polyline":"[106.68976593,10.81427383] ; [106.68968964,10.81462193] ; [106.68959045,10.81481171] ; [106.68946838,10.81494904] ; [106.68930817,10.81509113] ; [106.68889618,10.81544399] ; [106.68869781,10.81582355] ; [106.68865204,10.81606579] ; [106.68864441,10.81633949] ; [106.68867493,10.81660843] ; [106.68927765,10.81787300]"
    ,"Distance":"458"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2046"
    ,"Station_Code":"QGV 152"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"28, đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.821646
    ,"Long":106.688759
    ,"Polyline":"[106.68927765,10.81787300] ; [106.68988037,10.81919575] ; [106.69000244,10.81949043] ; [106.69005585,10.81980133] ; [106.68999481,10.81996536] ; [106.68989563,10.82013321] ; [106.68975830,10.82029152] ; [106.68959808,10.82044983] ; [106.68917847,10.82079792] ; [106.68875885,10.82164574]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2040"
    ,"Station_Code":"QGV 153"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã Ba Nguyễn Du"
    ,"Station_Address":"250 , đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.825329
    ,"Long":106.684998
    ,"Polyline":"[106.68875885,10.82164574] ; [106.68846130,10.82221985] ; [106.68795013,10.82318401] ; [106.68748474,10.82356358] ; [106.68655396,10.82420158] ; [106.68618774,10.82463837] ; [106.68587494,10.82489681] ; [106.68499756,10.82532883]"
    ,"Distance":"598"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2042"
    ,"Station_Code":"QGV 154"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Chi cục  Thuế Quận Gò Vấp"
    ,"Station_Address":"308, đường Nguyễn Văn Nghi, Quận Gò V ấp"
    ,"Lat":10.826383
    ,"Long":106.682732
    ,"Polyline":"[106.68499756,10.82532883] ; [106.68470764,10.82550240] ; [106.68376923,10.82615089] ; [106.68354797,10.82623005] ; [106.68273163,10.82638264]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"921"
    ,"Station_Code":"QGV 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Siêu thị Văn Lang, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.826804
    ,"Long":106.679354
    ,"Polyline":"[106.68273163,10.82638264] ; [106.68226624,10.82645130] ; [106.68151855,10.82628822] ; [106.68114471,10.82627201] ; [106.68067169,10.82631969] ; [106.68019867,10.82644558] ; [106.68014526,10.82657719] ; [106.68004608,10.82667732] ; [106.67991638,10.82669926] ; [106.67977905,10.82663822] ; [106.67935944,10.82683086]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"920"
    ,"Station_Code":"QGV 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Công ty 32"
    ,"Station_Address":"138, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.827779
    ,"Long":106.676559
    ,"Polyline":"[106.67935944,10.82683086] ; [106.67655945,10.82777882]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"922"
    ,"Station_Code":"QGV 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Nhà Thờ Xóm Thuốc"
    ,"Station_Address":"190, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.829186
    ,"Long":106.672606
    ,"Polyline":"[106.67655945,10.82777882] ; [106.67458344,10.82845879] ; [106.67260742,10.82918644]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"923"
    ,"Station_Code":"QGV 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"UBND Quận Gò Vấp"
    ,"Station_Address":"328, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.831641
    ,"Long":106.668502
    ,"Polyline":"[106.67260742,10.82918644] ; [106.67138672,10.82973385] ; [106.66966248,10.83065033] ; [106.66850281,10.83164120]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"924"
    ,"Station_Code":"QGV 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"VKS nhân dân Quận Gò Vấp"
    ,"Station_Address":"402 - 404, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833374
    ,"Long":106.666313
    ,"Polyline":"[106.66850281,10.83164120] ; [106.66781616,10.83205700] ; [106.66756439,10.83227348] ; [106.66631317,10.83337402]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"4745"
    ,"Station_Code":"QGV 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Chùa Huỳnh Kim"
    ,"Station_Address":"548, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835234
    ,"Long":106.663315
    ,"Polyline":"[106.66631317,10.83337402] ; [106.66498566,10.83437061] ; [106.66331482,10.83523369]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"925"
    ,"Station_Code":"QGV 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Siêu th ị Bình Dân, Quang Trung"
    ,"Station_Address":"628A, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835988
    ,"Long":106.660675
    ,"Polyline":"[106.66331482,10.83523369] ; [106.66201782,10.83562469] ; [106.66067505,10.83598804]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2049"
    ,"Station_Code":"QGV 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Thông Tây"
    ,"Station_Address":"734, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836836
    ,"Long":106.657355
    ,"Polyline":"[106.66067505,10.83598804] ; [106.65900421,10.83639336] ; [106.65735626,10.83683586]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2044"
    ,"Station_Code":"QGV 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường THPT Nguyễn Công Trứ"
    ,"Station_Address":"872 (96H), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.838
    ,"Long":106.652741
    ,"Polyline":"[106.65735626,10.83683586] ; [106.65274048,10.83800030]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2045"
    ,"Station_Code":"QGV 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Dệt may  Phương Đông"
    ,"Station_Address":"930 (Kho 97 ), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.838654
    ,"Long":106.650091
    ,"Polyline":"[106.65274048,10.83800030] ; [106.65009308,10.83865356]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2051"
    ,"Station_Code":"QGV 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"1010, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.839881
    ,"Long":106.646621
    ,"Polyline":"[106.65009308,10.83865356] ; [106.64865112,10.83901215] ; [106.64721680,10.83939171] ; [106.64706421,10.83948135] ; [106.64662170,10.83988094]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2048"
    ,"Station_Code":"QGV 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"1134, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.842279
    ,"Long":106.643348
    ,"Polyline":"[106.64662170,10.83988094] ; [106.64524078,10.84097767] ; [106.64334869,10.84227943]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2053"
    ,"Station_Code":"QGV 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"1246, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.843743
    ,"Long":106.641186
    ,"Polyline":"[106.64334869,10.84227943] ; [106.64225769,10.84299564] ; [106.64118958,10.84374332]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2050"
    ,"Station_Code":"QGV 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"1324, đường Quang Trung, Qu ận Gò Vấp"
    ,"Lat":10.845532
    ,"Long":106.638435
    ,"Polyline":"[106.64118958,10.84374332] ; [106.64020538,10.84438038] ; [106.63936615,10.84499741] ; [106.63843536,10.84553242]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2092"
    ,"Station_Code":"Q12 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"113, đường Quang Trung, Qu ận 12"
    ,"Lat":10.848253
    ,"Long":106.634363
    ,"Polyline":"[106.63843536,10.84553242] ; [106.63716125,10.84625626] ; [106.63436127,10.84825325]"
    ,"Distance":"539"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2052"
    ,"Station_Code":"Q12 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Cầu vượt Quang Trung"
    ,"Station_Address":"170, đường Quang Trung, Quận 12"
    ,"Lat":10.849784
    ,"Long":106.63221
    ,"Polyline":"[106.63436127,10.84825325] ; [106.63220978,10.84978390]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2057"
    ,"Station_Code":"Q12 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Công viên phần mềm Quang Trung"
    ,"Station_Address":"Công viên phần mềm Quang Trung, đường T ô Ký, Quận 12"
    ,"Lat":10.852995
    ,"Long":106.626434
    ,"Polyline":"[106.63220978,10.84978390] ; [106.63109589,10.85053444] ; [106.63056183,10.85074043] ; [106.62779236,10.85124588] ; [106.62747955,10.85137177] ; [106.62699890,10.85183620] ; [106.62643433,10.85299492]"
    ,"Distance":"772"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2054"
    ,"Station_Code":"Q12 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Đông Bắc"
    ,"Station_Address":"288, đường Tô Ký, Quận 12"
    ,"Lat":10.855729
    ,"Long":106.623039
    ,"Polyline":"[106.62643433,10.85299492] ; [106.62581635,10.85395336] ; [106.62490845,10.85477543] ; [106.62442017,10.85511780] ; [106.62303925,10.85572910]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2055"
    ,"Station_Code":"Q12 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Điện lực Hóc Môn"
    ,"Station_Address":"Điền lực Hóc Môn, đường Tô Ký, Quận 12"
    ,"Lat":10.856714
    ,"Long":106.620909
    ,"Polyline":"[106.62303925,10.85572910.06.62194061] ; [10.85618782,106.62091064]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2058"
    ,"Station_Code":"Q12 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Chiếc nón Kỳ Diệu"
    ,"Station_Address":"312, đường Tô Ký, Quận 12"
    ,"Lat":10.857816
    ,"Long":106.619294
    ,"Polyline":"[106.62091064,10.85671425] ; [106.62078857,10.85676193] ; [106.62008667,10.85721493] ; [106.61929321,10.85781574]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2059"
    ,"Station_Code":"Q12 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"chợ Tân Chánh Hiệp"
    ,"Station_Address":"414, đường Tô Ký, Quận 12"
    ,"Lat":10.859275
    ,"Long":106.617867
    ,"Polyline":"[106.61929321,10.85781574] ; [106.61865234,10.85828400] ; [106.61791229,10.85890579] ; [106.61786652,10.85927486]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2060"
    ,"Station_Code":"Q12 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Doanh trại Quân Đội"
    ,"Station_Address":"A49, đường Tô Ký, Quận 12"
    ,"Lat":10.86154
    ,"Long":106.617427
    ,"Polyline":"[106.61786652,10.85927486] ; [106.61742401,10.86153984]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"2061"
    ,"Station_Code":"Q12 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Trường Đại học Lao động Xã hội"
    ,"Station_Address":"72, đường Tô Ký, Quận 12"
    ,"Lat":10.863368
    ,"Long":106.616945
    ,"Polyline":"[106.61742401,10.86153984] ; [106.61694336,10.86336803]"
    ,"Distance":"210"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1695"
    ,"Station_Code":"Q12 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Ngã 3 Bầu"
    ,"Station_Address":"L ô A4D, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.867625
    ,"Long":106.615899
    ,"Polyline":"[106.61694336,10.86336803] ; [106.61643219,10.86505413] ; [106.61557770,10.86732960] ; [106.61589813,10.86762524]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1696"
    ,"Station_Code":"Q12 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Trạm y t ế"
    ,"Station_Address":"772, đường Nguyễn Ảnh  Thủ, Quận 12"
    ,"Lat":10.869577
    ,"Long":106.617981
    ,"Polyline":"[106.61589813,10.86762524] ; [106.61798096,10.86957741]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1698"
    ,"Station_Code":"Q12 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Trung tâm y tế Quận 12"
    ,"Station_Address":"927, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.871676
    ,"Long":106.619911
    ,"Polyline":"[106.61798096,10.86957741] ; [106.61940765,10.87119675] ; [106.61991119,10.87167645]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1697"
    ,"Station_Code":"Q12 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Quán Năm Lửa"
    ,"Station_Address":"785, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.87539
    ,"Long":106.623355
    ,"Polyline":"[106.61991119,10.87167645] ; [106.62335205,10.87539005]"
    ,"Distance":"559"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1699"
    ,"Station_Code":"Q12 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Ngã tư Nước đá"
    ,"Station_Address":"753, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.878219
    ,"Long":106.625812
    ,"Polyline":"[106.62335205,10.87539005] ; [106.62489319,10.87719727] ; [106.62580872,10.87821865]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1700"
    ,"Station_Code":"Q12 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Trường tiểu học Nguyễn Trãi"
    ,"Station_Address":"Trường Nguyễn Trãi, đường  Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.88118
    ,"Long":106.627995
    ,"Polyline":"[106.62580872,10.87821865] ; [106.62685394,10.87958336] ; [106.62799835,10.88117981]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1703"
    ,"Station_Code":"Q12 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Ngã 3 Đông Quang"
    ,"Station_Address":"581-577, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.882892
    ,"Long":106.630087
    ,"Polyline":"[106.62799835,10.88117981] ; [106.62905121,10.88282871] ; [106.62944794,10.88320827] ; [106.63008881,10.88289165]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1701"
    ,"Station_Code":"Q12 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Cây xăng Hiệp Thành"
    ,"Station_Address":"46/8, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.880437
    ,"Long":106.634513
    ,"Polyline":"[106.63008881,10.88289165] ; [106.63211823,10.88173866] ; [106.63451385,10.88043690]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1704"
    ,"Station_Code":"Q12 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Cửa hàng Ngọc Sơn"
    ,"Station_Address":"86H, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.879073
    ,"Long":106.636975
    ,"Polyline":"[106.63451385,10.88043690] ; [106.63574219,10.87977314] ; [106.63697815,10.87907314]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1702"
    ,"Station_Code":"Q12 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Công an Hiệp Thành"
    ,"Station_Address":"425, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.878066
    ,"Long":106.638708
    ,"Polyline":"[106.63697815,10.87907314] ; [106.63791656,10.87856674] ; [106.63871002,10.87806606]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1706"
    ,"Station_Code":"Q12 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"296, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877192
    ,"Long":106.640645
    ,"Polyline":"[106.63871002,10.87806606] ; [106.64036560,10.87724495] ; [106.64064789,10.87719154]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"40"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"1"
    ,"Station_Order":"65"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":"[106.64064789,10.87719154] ; [106.64183807,10.87704945] ; [106.64210510,10.87741280] ; [106.64203644,10.87744999]"
    ,"Distance":"190"
  }]