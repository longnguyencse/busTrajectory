export const Route53 =[

  {
     "Route_Id":"53"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận  12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"213"
    ,"Station_Code":"Q12 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã tư Ga"
    ,"Station_Address":"154, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.857331
    ,"Long":106.679907
    ,"Polyline":"[106.67832947,10.86166000] ; [106.67665863,10.86176968] ; [106.67565155,10.86182022] ; [106.67433929,10.86184025] ; [106.67263031,10.86182022] ; [106.67128754,10.86178970] ; [106.67127991,10.86168957] ; [106.67429352,10.86170959] ; [106.67534637,10.86170959] ; [106.67703247,10.86163998] ; [106.67836761,10.86155033] ; [106.67900848,10.86151028] ; [106.67910767,10.86143970] ; [106.67919159,10.86135960] ; [106.67922974,10.86124039] ; [106.67925262,10.86098957] ; [106.67916107,10.85962963] ; [106.67913818,10.85900974] ; [106.67917633,10.85890007] ; [106.67925262,10.85879993] ; [106.67945862,10.85869980] ; [106.67958832,10.85865974] ; [106.67976379,10.85851002] ; [106.67980957,10.85840988] ; [106.67986298,10.85826969] ; [106.67980957,10.85787010.06.67960358] ; [10.85624027,106.67935181]"
    ,"Distance":"2477"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"209"
    ,"Station_Code":"QGV 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu An L ộc"
    ,"Station_Address":"521, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.84862
    ,"Long":106.678535
    ,"Polyline":"[106.67935181,10.85433960] ; [106.67900848,10.85216999] ; [106.67874908,10.85031033] ; [106.67865753,10.84939003] ; [106.67861176,10.84860992]"
    ,"Distance":"643"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"210"
    ,"Station_Code":"QGV 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"451 , đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.847015
    ,"Long":106.67826
    ,"Polyline":"[106.67861176,10.84860992] ; [106.67855072,10.84794998] ; [106.67851257,10.84753990] ; [106.67839813,10.84704018] ; [106.67839050,10.84700012]"
    ,"Distance":"181"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"212"
    ,"Station_Code":"QGV 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Bưu điện An  Nhơn"
    ,"Station_Address":"357, đường Nguyễn  Oanh, Quận Gò Vấp"
    ,"Lat":10.843833
    ,"Long":106.677139
    ,"Polyline":"[106.67839050,10.84700012] ; [106.67726135,10.84381962]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2630"
    ,"Station_Code":"QGV 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã Tư Nguyễn Oanh"
    ,"Station_Address":"452, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.842305
    ,"Long":106.676221
    ,"Polyline":"[106.67726135,10.84381962] ; [106.67659760,10.84193993] ; [106.67635345,10.84208012] ; [106.67617798,10.84218979]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2627"
    ,"Station_Code":"QGV 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Bệnh Vi ện Gò Vấp"
    ,"Station_Address":"642 (194), đường  Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.845118
    ,"Long":106.672091
    ,"Polyline":"[106.67617798,10.84218979] ; [106.67561340,10.84263992] ; [106.67497253,10.84304047] ; [106.67479706,10.84311008] ; [106.67447662,10.84325981] ; [106.67415619,10.84356022] ; [106.67381287,10.84401989] ; [106.67372131,10.84414959] ; [106.67350769,10.84430981] ; [106.67330933,10.84434986] ; [106.67304230,10.84438992] ; [106.67283630,10.84447002] ; [106.67270660,10.84457016] ; [106.67247772,10.84471035]"
    ,"Distance":"504"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2628"
    ,"Station_Code":"QGVT057"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường THCS Lý Tự Trọng"
    ,"Station_Address":"646, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.847060203552246
    ,"Long":106.66963195800781
    ,"Polyline":"[106.67247772,10.84471035] ; [106.67215729,10.84492016] ; [106.67186737,10.84519958] ; [106.67170715,10.84539032] ; [106.67141724,10.84572983] ; [106.67115784,10.84597015] ; [106.67093658,10.84619045] ; [106.67069244,10.84634972] ; [106.66983795,10.84689999] ; [106.66961670,10.84704971]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2631"
    ,"Station_Code":"QGV 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà thờ Trung Bắc"
    ,"Station_Address":"894, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.84927
    ,"Long":106.66604
    ,"Polyline":"[106.66961670,10.84704971] ; [106.66845703,10.84776974] ; [106.66795349,10.84807014] ; [106.66773987,10.84819984] ; [106.66716003,10.84846020] ; [106.66696167,10.84858036] ; [106.66668701,10.84873962] ; [106.66605377,10.84912968]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2632"
    ,"Station_Code":"QGV 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà Thờ  Thái Bình"
    ,"Station_Address":"716, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.852805
    ,"Long":106.665466
    ,"Polyline":"[106.66605377,10.84912968] ; [106.66509247,10.84969997] ; [106.66499329,10.84976959] ; [106.66533661,10.85227966] ; [106.66535950,10.85243988]"
    ,"Distance":"436"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2633"
    ,"Station_Code":"QGV 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thờ Hợp An"
    ,"Station_Address":"671, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.853848
    ,"Long":106.66435
    ,"Polyline":"[106.66535950,10.85243988] ; [106.66551971,10.85365963] ; [106.66549683,10.85412025] ; [106.66480255,10.85387993] ; [106.66432953,10.85373020] ; [106.66407776,10.85363960]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2634"
    ,"Station_Code":"QGVT093"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường TH Lê Thị Hồng Gấm"
    ,"Station_Address":"32/19, đường Phạm Văn Chi êu, Quận Gò Vấp"
    ,"Lat":10.852907180786133
    ,"Long":106.66179656982422
    ,"Polyline":"[106.66407776,10.85363960] ; [106.66291809,10.85323048] ; [106.66220093,10.85299969] ; [106.66181183,10.85286045]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2637"
    ,"Station_Code":"QGV 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trung t âm Văn hóa Quận Gò Vấp"
    ,"Station_Address":"14B, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.851599
    ,"Long":106.657816
    ,"Polyline":"[106.66181183,10.85286045] ; [106.65868378,10.85177994] ; [106.65783691,10.85151005]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2638"
    ,"Station_Code":"QGV 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà thờ Thạch Đà"
    ,"Station_Address":"385, đường Ph ạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.851288
    ,"Long":106.655397
    ,"Polyline":"[106.65783691,10.85151005] ; [106.65746307,10.85138988] ; [106.65709686,10.85140038] ; [106.65635681,10.85147953] ; [106.65614319,10.85146046] ; [106.65492249,10.85101032]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2635"
    ,"Station_Code":"QGV 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Thạch Đà"
    ,"Station_Address":"295, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.849923
    ,"Long":106.651551
    ,"Polyline":"[106.65492249,10.85101032] ; [106.65271759,10.85021019] ; [106.65232849,10.85006046] ; [106.65144348,10.84974003]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2636"
    ,"Station_Code":"QGV 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Công ty  Huê Phong"
    ,"Station_Address":"223, đường Ph ạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.848459
    ,"Long":106.6483
    ,"Polyline":"[106.65144348,10.84974003] ; [106.65087128,10.84951973] ; [106.65045929,10.84932995] ; [106.64981079,10.84902954] ; [106.64897156,10.84860992] ; [106.64836884,10.84834003]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2639"
    ,"Station_Code":"QGV 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Ba Cây Trâm"
    ,"Station_Address":"157, đường Phạm Văn Chiêu, Quận Gò V ấp"
    ,"Lat":10.846557
    ,"Long":106.644518
    ,"Polyline":"[106.64836884,10.84834003] ; [106.64566803,10.84702015]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2643"
    ,"Station_Code":"QGV 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã ba Cây Trâm"
    ,"Station_Address":"89 , đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.846067
    ,"Long":106.643499
    ,"Polyline":"[106.64566803,10.84702015] ; [106.64446259,10.84642029] ; [106.64366150,10.84605980] ; [106.64260101,10.84552002]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2640"
    ,"Station_Code":"QGVT085"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã Tư  Quag Trung"
    ,"Station_Address":"4B, đường Ph ạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.845171
    ,"Long":106.641675
    ,"Polyline":"[106.64260101,10.84552002] ; [106.64169312,10.84508038]"
    ,"Distance":"110"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2641"
    ,"Station_Code":"QGV 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Đường Nguyễn Duy Cung"
    ,"Station_Address":"411, đường Phan  Huy Ích, Quận Gò Vấp"
    ,"Lat":10.843496
    ,"Long":106.639507
    ,"Polyline":"[106.64169312,10.84508038] ; [106.64035797,10.84442997] ; [106.64018250,10.84434986] ; [106.64010620,10.84428024] ; [106.63990784,10.84399986] ; [106.63963318,10.84350967] ; [106.63937378,10.84309006]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2646"
    ,"Station_Code":"QGV 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chùa Linh Sơn Hải Tự"
    ,"Station_Address":"12/78, đường Phan Huy Ích, Quận Gò V ấp"
    ,"Lat":10.841177
    ,"Long":106.638043
    ,"Polyline":"[106.63937378,10.84309006] ; [106.63815308,10.84113979]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2642"
    ,"Station_Code":"QGV 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà sách Phan Huy Ích"
    ,"Station_Address":"275, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.837036
    ,"Long":106.636031
    ,"Polyline":"[106.63815308,10.84113979] ; [106.63793945,10.84080029] ; [106.63751221,10.83994961] ; [106.63715363,10.83917999] ; [106.63681030,10.83848000] ; [106.63613129,10.83699989]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2644"
    ,"Station_Code":"QGVT097"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":""
    ,"Station_Address":"20/10A, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.833786964416504
    ,"Long":106.6345443725586
    ,"Polyline":"[106.63613129,10.83699989] ; [106.63461304,10.83376026]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2647"
    ,"Station_Code":"QGV 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường Cao đẳng Du Lịch"
    ,"Station_Address":"175, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.832136
    ,"Long":106.633741
    ,"Polyline":"[106.63461304,10.83376026] ; [106.63397217,10.83238983]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2645"
    ,"Station_Code":"QTB 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Nhà thờ Hy Vọng"
    ,"Station_Address":"69, đ ường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.83081
    ,"Long":106.633163
    ,"Polyline":"[106.63397217,10.83238983] ; [106.63321686,10.83078003]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2648"
    ,"Station_Code":"QTB 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà máy h óa chất Tân Bình"
    ,"Station_Address":"Nhà máy hóa chất , đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.82854
    ,"Long":106.632103
    ,"Polyline":"[106.63321686,10.83078003] ; [106.63273621,10.82979012] ; [106.63237762,10.82898998] ; [106.63215637,10.82851028]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2649"
    ,"Station_Code":"QTB 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cao ốc Phúc Yên"
    ,"Station_Address":"31-33, đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.826112
    ,"Long":106.630997
    ,"Polyline":"[106.63215637,10.82851028] ; [106.63105011,10.82608986]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.63105011,10.82608986] ; [106.62988281,10.82361984] ; [106.62967682,10.82332039] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"500"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2454"
    ,"Station_Code":"QTP 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cty Dầu Thực Vật"
    ,"Station_Address":"Công ty dầu thực vật Tân Bình, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.81896
    ,"Long":106.628532
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63059235,10.82044029] ; [106.62867737,10.81910992] ; [106.62851715,10.81896973]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2651"
    ,"Station_Code":"QTP 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trạm Công Ty Ngọc Nghĩa"
    ,"Station_Address":"C ông ty Ngọc Nghĩa, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.816059
    ,"Long":106.625336
    ,"Polyline":"[106.62851715,10.81896973] ; [106.62772369,10.81828022] ; [106.62677765,10.81744957] ; [106.62568665,10.81643009] ; [106.62532806,10.81608963]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2650"
    ,"Station_Code":"QTP 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trạm đầu D9"
    ,"Station_Address":"Đối diện 14, đường Lưu Chí Hiếu, Quận Tân Phú"
    ,"Lat":10.814304
    ,"Long":106.62487
    ,"Polyline":"[106.62533569,10.81605911] ; [106.62531281,10.81608009] ; [106.62452698,10.81532955] ; [106.62431335,10.81509686] ; [106.62442017,10.81501007] ; [106.62463379,10.81472969] ; [106.62489319,10.81431961] ; [106.62487030,10.81430435]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2652"
    ,"Station_Code":"QTP 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm cuối D9"
    ,"Station_Address":"Đối diện 71, đường Lưu Chí Hiếu, Quận Tân Phú"
    ,"Lat":10.812283
    ,"Long":106.626389
    ,"Polyline":"[106.62489319,10.81431961] ; [106.62641144,10.81229019]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2653"
    ,"Station_Code":"QTP 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"TT vh Tân Phú"
    ,"Station_Address":"Đối diện 90,  đường Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.810605
    ,"Long":106.626991
    ,"Polyline":"[106.62641144,10.81229019] ; [106.62673950,10.81182957] ; [106.62695313,10.81153965] ; [106.62696838,10.81136990] ; [106.62700653,10.81060982]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2655"
    ,"Station_Code":"QTP 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Lê Trọng  Tấn"
    ,"Station_Address":"Đối diện 14 (Công ty may), đường Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.807312
    ,"Long":106.627266
    ,"Polyline":"[106.62700653,10.81060982] ; [106.62703705,10.80980015] ; [106.62712097,10.80891037] ; [106.62728882,10.80731010]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2654"
    ,"Station_Code":"QTP 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trường Cao Đẳng Công Nghệ Thực Phẩm"
    ,"Station_Address":"117, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.80593
    ,"Long":106.628693
    ,"Polyline":"[106.62728882,10.80731010.06.62735748] ; [10.80659962,106.62740326] ; [10.80634022,106.62748718] ; [10.80622005,106.62870026]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2600"
    ,"Station_Code":"QTP 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm Đầu Lê Trọng Tấn"
    ,"Station_Address":"8A-8B, đường Lê Trọng Tấn , Quận Tân Phú"
    ,"Lat":10.804282
    ,"Long":106.632187
    ,"Polyline":"[106.62870026,10.80595970] ; [106.62995911,10.80568027] ; [106.63034821,10.80558014] ; [106.63075256,10.80545998] ; [106.63101959,10.80533028] ; [106.63117981,10.80521011] ; [106.63150787,10.80492020] ; [106.63218689,10.80412960] ; [106.63271332,10.80348969] ; [106.63278198,10.80350971] ; [106.63284302,10.80352974] ; [106.63221741,10.80422974] ; [106.63217926,10.80428028]"
    ,"Distance":"665"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2657"
    ,"Station_Code":"QTP 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Trạm café BonJour"
    ,"Station_Address":"128-130, đường Tân Kỳ Tân Quý, Quận T ân Phú"
    ,"Lat":10.803346
    ,"Long":106.631577
    ,"Polyline":"[106.63217926,10.80428028] ; [106.63198853,10.80451965] ; [106.63153839,10.80500031] ; [106.63112640,10.80535030] ; [106.63104248,10.80539989] ; [106.63078308,10.80554008] ; [106.63056946,10.80560970] ; [106.63009644,10.80572987] ; [106.62933350,10.80591011] ; [106.62920380,10.80585003] ; [106.62940216,10.80580997] ; [106.62995911,10.80568027] ; [106.63034821,10.80558014] ; [106.63075256,10.80545998] ; [106.63101959,10.80533028] ; [106.63117981,10.80521011] ; [106.63150787,10.80492020] ; [106.63191986,10.80445957] ; [106.63218689,10.80412960] ; [106.63271332,10.80348969] ; [106.63189697,10.80335045] ; [106.63159180,10.80329990]"
    ,"Distance":"998"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2656"
    ,"Station_Code":"QTP 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm Đường Số 27"
    ,"Station_Address":"216, đường Tân Kỳ Tân Quý , Quận Tân Phú"
    ,"Lat":10.802817
    ,"Long":106.628487
    ,"Polyline":"[106.63159180,10.80329990] ; [106.62943268,10.80294037] ; [106.62850952,10.80274963]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2659"
    ,"Station_Code":"QTP 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm cây xăng Sài Gòn Petro"
    ,"Station_Address":"302, đường Tân Kỳ Tân Quý , Quận Tân Phú"
    ,"Lat":10.802044
    ,"Long":106.625923
    ,"Polyline":"[106.62850952,10.80274963] ; [106.62777710,10.80261993] ; [106.62731934,10.80251980] ; [106.62690735,10.80237961] ; [106.62600708,10.80202007] ; [106.62593842,10.80198956]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2658"
    ,"Station_Code":"QTP 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Showroom otô"
    ,"Station_Address":"51/13, đường Tân  Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.801045
    ,"Long":106.62336
    ,"Polyline":"[106.62593842,10.80198956] ; [106.62496948,10.80163956] ; [106.62336731,10.80101967]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2660"
    ,"Station_Code":"QTP 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm Nhà Thờ Họ Tộc Nguyễn"
    ,"Station_Address":"378, đường T ân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799963
    ,"Long":106.620499
    ,"Polyline":"[106.62336731,10.80101967] ; [106.62200928,10.80049038] ; [106.62052917,10.79990005]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2663"
    ,"Station_Code":"QTP 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Đầu Tân Quý"
    ,"Station_Address":"8, đường Tân  Quý, Quận Tân Phú"
    ,"Lat":10.79887
    ,"Long":106.619591
    ,"Polyline":"[106.62052917,10.79990005] ; [106.61950684,10.79950047] ; [106.61961365,10.79887009]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2661"
    ,"Station_Code":"QTP 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm UB phường Tân Quý"
    ,"Station_Address":"52C, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.796547
    ,"Long":106.619896
    ,"Polyline":"[106.61961365,10.79887009] ; [106.61991119,10.79654980]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2665"
    ,"Station_Code":"QTP 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Trạm Gò Dầu"
    ,"Station_Address":"88, đường Tân Quý, Quận T ân Phú"
    ,"Lat":10.795079
    ,"Long":106.620316
    ,"Polyline":"[106.61991119,10.79654980] ; [106.62001038,10.79584980] ; [106.62027740,10.79564953] ; [106.62033844,10.79508018]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2662"
    ,"Station_Code":"QTP 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Tiệm cửa sắt"
    ,"Station_Address":"156, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.792974
    ,"Long":106.620468
    ,"Polyline":"[106.62033844,10.79508018] ; [106.62055969,10.79304028]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2664"
    ,"Station_Code":"QTP 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Trạm Y tế phường Tân Quý"
    ,"Station_Address":"200, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.791017
    ,"Long":106.620735
    ,"Polyline":"[106.62055969,10.79298019] ; [106.62075806,10.79102039]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2553"
    ,"Station_Code":"QTP 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Trạm Chợ Tân Hương"
    ,"Station_Address":"217-219 , đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.790046
    ,"Long":106.621666
    ,"Polyline":"[106.62075806,10.79102039] ; [106.62079620,10.79057026] ; [106.62082672,10.79018021] ; [106.62104034,10.79014015] ; [106.62153625,10.79008007] ; [106.62165833,10.79006958]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2666"
    ,"Station_Code":"QTP 165"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Trường GTVT"
    ,"Station_Address":"380, đường Văn Cao, Quận Tân Phú"
    ,"Lat":10.786402
    ,"Long":106.622055
    ,"Polyline":"[106.62165833,10.79006958] ; [106.62225342,10.78999996] ; [106.62316895,10.78989029] ; [106.62307739,10.78948021] ; [106.62290955,10.78896999] ; [106.62264252,10.78812027] ; [106.62229919,10.78709030] ; [106.62207031,10.78639984]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"1733"
    ,"Station_Code":"QTP 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Phạm Văn Xảo"
    ,"Station_Address":"302-304, đường Nguyễn Sơn, Quận Tân Ph ú"
    ,"Lat":10.784016
    ,"Long":106.622986
    ,"Polyline":"[106.62207031,10.78639984] ; [106.62159729,10.78493023] ; [106.62142181,10.78450012] ; [106.62258148,10.78411961] ; [106.62297821,10.78400040]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"1816"
    ,"Station_Code":"QTP 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Chợ Tân Phú"
    ,"Station_Address":"131-133, đường Nguyễn Sơn, Quận Tân Phú"
    ,"Lat":10.783206
    ,"Long":106.62532
    ,"Polyline":"[106.62297821,10.78400040] ; [106.62534332,10.78324986]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2668"
    ,"Station_Code":"QTP 170"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Lê Cao Lăng"
    ,"Station_Address":"43, đường Lê Khôi, Quận Tân Phú"
    ,"Lat":10.781464
    ,"Long":106.628593
    ,"Polyline":"[106.62534332,10.78324986] ; [106.62600708,10.78302956] ; [106.62831879,10.78229046] ; [106.62880707,10.78215027] ; [106.62867737,10.78164959] ; [106.62860870,10.78145981]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2672"
    ,"Station_Code":"QTP 169"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Trần Thủ Độ"
    ,"Station_Address":"Kế 19, đường Lê Khôi, Quận Tân Phú"
    ,"Lat":10.778714
    ,"Long":106.627708
    ,"Polyline":"[106.62860870,10.78145981] ; [106.62840271,10.78077984] ; [106.62818909,10.78017998] ; [106.62773132,10.77871037]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2674"
    ,"Station_Code":"QTP 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Cuối Tô Hiệu"
    ,"Station_Address":"Đối diện 246 , đường Tô Hiệu, Quận Tân Phú"
    ,"Lat":10.775322
    ,"Long":106.628128
    ,"Polyline":"[106.62773132,10.77871037] ; [106.62750244,10.77803040] ; [106.62769318,10.77762985] ; [106.62792969,10.77723980] ; [106.62844086,10.77637005] ; [106.62843323,10.77622986] ; [106.62837982,10.77608967] ; [106.62815857,10.77536011] ; [106.62815094,10.77532005]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2667"
    ,"Station_Code":"QTP 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Đầu Tô Hi ệu"
    ,"Station_Address":"27K, đường Tô Hiệu, Quận Tân Phú"
    ,"Lat":10.772807
    ,"Long":106.627304
    ,"Polyline":"[106.62815094,10.77532005] ; [106.62802124,10.77490044] ; [106.62773895,10.77406025] ; [106.62731934,10.77280045]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"1565"
    ,"Station_Code":"QTP 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Trâm Tâm Mua Sắm"
    ,"Station_Address":"165, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.771252
    ,"Long":106.628975
    ,"Polyline":"[106.62731171,10.77278042] ; [106.62702179,10.77194977] ; [106.62700653,10.77192020] ; [106.62706757,10.77188969] ; [106.62821198,10.77151966] ; [106.62893677,10.77128983] ; [106.62898254,10.77128029]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2669"
    ,"Station_Code":"QTPT224"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Trung T âm Anh Ngữ"
    ,"Station_Address":"185, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.769272804260254
    ,"Long":106.63175201416016
    ,"Polyline":"[106.62898254,10.77128029] ; [106.62949371,10.77110958] ; [106.63047791,10.77079010.06.63123322] ; [10.77048969,106.63179779] ; [10.77029037,106.63178253] ; [10.76976967,106.63176727]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2670"
    ,"Station_Code":"QTP 196"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Trạm Xưởng May Việt Đại"
    ,"Station_Address":"151A, đường Lũy Bán Bích,  Quận Tân Phú"
    ,"Lat":10.766378
    ,"Long":106.631927
    ,"Polyline":"[106.63176727,10.76926994] ; [106.63176727,10.76867962] ; [106.63188171,10.76735020] ; [106.63195038,10.76638031]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2673"
    ,"Station_Code":"QTPT226"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Cty Dệt May Sài Gòn"
    ,"Station_Address":"107, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.762413024902344
    ,"Long":106.63237762451172
    ,"Polyline":"[106.63195038,10.76638031] ; [106.63217163,10.76515961] ; [106.63229370,10.76451015] ; [106.63233185,10.76404953] ; [106.63236237,10.76364994] ; [106.63237762,10.76241016]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2671"
    ,"Station_Code":"QTP 198"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Trạm Cầu Tân Hóa"
    ,"Station_Address":"19-21A, đường Lũy Bán Bích, Quận Tân Ph ú"
    ,"Lat":10.759621
    ,"Long":106.633354
    ,"Polyline":"[106.63237762,10.76241016] ; [106.63240051,10.76198006] ; [106.63243103,10.76167965] ; [106.63260651,10.76086998] ; [106.63268280,10.76025009] ; [106.63271332,10.76010990] ; [106.63278198,10.76002026] ; [106.63292694,10.75990963] ; [106.63308716,10.75984001] ; [106.63339996,10.75969028]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"626"
    ,"Station_Code":"Q6 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Trường Mạc Đỉnh Chi"
    ,"Station_Address":"832-834, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754732
    ,"Long":106.635574
    ,"Polyline":"[106.63339996,10.75969028] ; [106.63372803,10.75946999] ; [106.63406372,10.75911999] ; [106.63423920,10.75891018] ; [106.63452148,10.75868034] ; [106.63523102,10.75790977] ; [106.63609314,10.75679970] ; [106.63671112,10.75619030] ; [106.63736725,10.75549030] ; [106.63744354,10.75539970] ; [106.63748932,10.75527954] ; [106.63755798,10.75477028] ; [106.63691711,10.75477028] ; [106.63655853,10.75481033] ; [106.63632965,10.75481033] ; [106.63610840,10.75479984] ; [106.63562775,10.75471020] ; [106.63558197,10.75469971]"
    ,"Distance":"942"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"627"
    ,"Station_Code":"Q6 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Vòng xoay Phú Lâm"
    ,"Station_Address":"528, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.753346
    ,"Long":106.633365
    ,"Polyline":"[106.63558197,10.75469971] ; [106.63542175,10.75463963] ; [106.63509369,10.75444984] ; [106.63481903,10.75424957] ; [106.63468170,10.75413036] ; [106.63465118,10.75417042] ; [106.63461304,10.75421047] ; [106.63455200,10.75422955] ; [106.63442993,10.75424004] ; [106.63430786,10.75417995] ; [106.63426208,10.75413036] ; [106.63420105,10.75401020] ; [106.63420105,10.75395012] ; [106.63390350,10.75368023] ; [106.63314056,10.75319958] ; [106.63313293,10.75319004]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"628"
    ,"Station_Code":"Q6 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Cư Xá Phú Lâm"
    ,"Station_Address":"580, đường Kinh D ương Vương, Quận 6"
    ,"Lat":10.751475
    ,"Long":106.63089
    ,"Polyline":"[106.63313293,10.75319004] ; [106.63234711,10.75265026] ; [106.63153839,10.75195026] ; [106.63088989,10.75144958]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"629"
    ,"Station_Code":"Q6 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"94-96, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.749589
    ,"Long":106.628435
    ,"Polyline":"[106.63088989,10.75144958] ; [106.62844086,10.74954987]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"1386"
    ,"Station_Code":"Q6 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Công Viên Phú Lâm"
    ,"Station_Address":"Đối diện 907, đường Kinh Dương Vương,  Quận 6"
    ,"Lat":10.746384
    ,"Long":106.624525
    ,"Polyline":"[106.62844086,10.74954987] ; [106.62677002,10.74822044] ; [106.62452698,10.74639034]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường Kinh Dương  Vương, Quận Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62452698,10.74639034] ; [106.62416077,10.74608994] ; [106.62393951,10.74592018] ; [106.62377930,10.74567032] ; [106.62377167,10.74567032] ; [106.62375641,10.74567032] ; [106.62374115,10.74567032] ; [106.62368774,10.74565029] ; [106.62362671,10.74557972] ; [106.62306976,10.74522972] ; [106.62248230,10.74473953]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"65"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương Vương, Quận Bình  Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62248230,10.74473953] ; [106.62045288,10.74304008]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"66"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh  Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.62045288,10.74304008] ; [106.61823273,10.74125099] ; [106.61814880,10.74088955]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.61814880,10.74088955] ; [106.62113190,10.74335957] ; [106.62306976,10.74499035]"
    ,"Distance":"705"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"718"
    ,"Station_Code":"Q6 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cư xá Phú Lâm"
    ,"Station_Address":"799 (209), đường Kinh Dương Vương, Qu ận 6"
    ,"Lat":10.74776
    ,"Long":106.626332
    ,"Polyline":"[106.62306976,10.74499035] ; [106.62328339,10.74516010.06.62371063] ; [10.74534988,106.62374115] ; [10.74534035,106.62381744] ; [10.74534988,106.62390137] ; [10.74540043,106.62393951] ; [10.74549961,106.62391663] ; [10.74559021,106.62389374] ; [10.74563026,106.62387085] ; [10.74563980,106.62561035] ; [10.74705029,106.62638855]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"715"
    ,"Station_Code":"Q6 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Hồ Bơi Phú Lâm"
    ,"Station_Address":"685 (157), đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.748877
    ,"Long":106.627727
    ,"Polyline":"[106.62638855,10.74769974] ; [106.62776184,10.74878979]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"720"
    ,"Station_Code":"Q6 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"93, đường Kinh Dương Vương, Quận 6"
    ,"Lat":10.751201
    ,"Long":106.630753
    ,"Polyline":"[106.62776184,10.74878979] ; [106.63047028,10.75094986] ; [106.63078308,10.75117970]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2575"
    ,"Station_Code":"QTP 199"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Tân Hóa"
    ,"Station_Address":"12, đường Lũy Bán Bích, Qu ận Tân Phú"
    ,"Lat":10.759762
    ,"Long":106.633408
    ,"Polyline":"[106.63078308,10.75117493] ; [106.63244629,10.75258732] ; [106.63150787,10.75369453] ; [106.63244629,10.75584412] ; [106.63336182,10.75648785] ; [106.63458252,10.75726700] ; [106.63538361,10.75775719] ; [106.63340759,10.75976181]"
    ,"Distance":"1357"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2580"
    ,"Station_Code":"QTP 200"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Công ty Dệt May Sài Gòn"
    ,"Station_Address":"40, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.7623
    ,"Long":106.632408
    ,"Polyline":"[106.63336945,10.75969982] ; [106.63308716,10.75984001] ; [106.63292694,10.75990963] ; [106.63278198,10.76002026] ; [106.63271332,10.76010990] ; [106.63268280,10.76025009] ; [106.63260651,10.76086998] ; [106.63243103,10.76167965] ; [106.63240051,10.76198006] ; [106.63239288,10.76229954]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2576"
    ,"Station_Code":"QTP 201"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Công Ty bao bì nhựa Tân Tiến"
    ,"Station_Address":"98, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.766246
    ,"Long":106.631981
    ,"Polyline":"[106.63239288,10.76229954] ; [106.63236237,10.76364994] ; [106.63233185,10.76404953] ; [106.63229370,10.76451015] ; [106.63217163,10.76515961] ; [106.63197327,10.76624012]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2583"
    ,"Station_Code":"QTP 202"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây Keo"
    ,"Station_Address":"214 , đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.76917
    ,"Long":106.631836
    ,"Polyline":"[106.63197327,10.76624012] ; [106.63192749,10.76659966] ; [106.63188171,10.76735020] ; [106.63176727,10.76867962] ; [106.63176727,10.76916981]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"1621"
    ,"Station_Code":"QTP 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trung T âm Mua Sắm"
    ,"Station_Address":"214, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.771277
    ,"Long":106.629044
    ,"Polyline":"[106.63176727,10.76916981] ; [106.63178253,10.76976967] ; [106.63179779,10.77029037] ; [106.63123322,10.77048969] ; [106.63047791,10.77079010.06.62949371] ; [10.77110958,106.62904358]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2577"
    ,"Station_Code":"QTP 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đầu Tô  Hiệu"
    ,"Station_Address":"190, đường Tô Hiệu, Quận Tân Phú"
    ,"Lat":10.772891
    ,"Long":106.627357
    ,"Polyline":"[106.62904358,10.77126026] ; [106.62789154,10.77163029] ; [106.62700653,10.77192020] ; [106.62715912,10.77235031] ; [106.62734985,10.77289009]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2585"
    ,"Station_Code":"QTP 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Cuối Tô Hiệu"
    ,"Station_Address":"260-262, đường  Tô Hiệu, Quận Tân Phú"
    ,"Lat":10.775443
    ,"Long":106.628197
    ,"Polyline":"[106.62734985,10.77289009] ; [106.62773895,10.77406025] ; [106.62802124,10.77490044] ; [106.62815857,10.77536011] ; [106.62818146,10.77544975]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2578"
    ,"Station_Code":"QTP 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn Lý"
    ,"Station_Address":"44B, đường Nguyễn Lý, Quận Tân Phú"
    ,"Lat":10.776741
    ,"Long":106.62822
    ,"Polyline":"[106.62818146,10.77544975] ; [106.62837982,10.77608967] ; [106.62843323,10.77622986] ; [106.62844086,10.77637005] ; [106.62821960,10.77674007]"
    ,"Distance":"156"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2587"
    ,"Station_Code":"QTP 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trần Thủ Độ"
    ,"Station_Address":"14-16, đường  Lê Khôi, Quận Tân Phú"
    ,"Lat":10.778714
    ,"Long":106.627731
    ,"Polyline":"[106.62821960,10.77674007] ; [106.62769318,10.77762985] ; [106.62750244,10.77803040] ; [106.62764740,10.77845955] ; [106.62773132,10.77871990]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2582"
    ,"Station_Code":"QTPT194"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Lê Cao Lăng"
    ,"Station_Address":"42, đường Lê Khôi, Quận Tân Phú"
    ,"Lat":10.781532287597656
    ,"Long":106.62864685058594
    ,"Polyline":"[106.62773132,10.77871990] ; [106.62818909,10.78017998] ; [106.62840271,10.78077984] ; [106.62863922,10.78153038]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"1732"
    ,"Station_Code":"QTP 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Tân Phú"
    ,"Station_Address":"178, đường Nguyễn Sơn, Quận Tân Phú"
    ,"Lat":10.783249
    ,"Long":106.625412
    ,"Polyline":"[106.62863922,10.78153038] ; [106.62880707,10.78215027] ; [106.62770081,10.78250027] ; [106.62580872,10.78310013] ; [106.62542725,10.78322029]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"1733"
    ,"Station_Code":"QTP 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Phạm Văn Xảo"
    ,"Station_Address":"302-304, đường Nguyễn Sơn, Quận Tân Phú"
    ,"Lat":10.784016
    ,"Long":106.622986
    ,"Polyline":"[106.62541199,10.78322983] ; [106.62297821,10.78400040]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2589"
    ,"Station_Code":"QTPT186"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường GTVT"
    ,"Station_Address":"64, đường Văn Cao, Quận Tân Phú"
    ,"Lat":10.786699295043945
    ,"Long":106.62222290039062
    ,"Polyline":"[106.62297821,10.78400040] ; [106.62142181,10.78450012] ; [106.62159729,10.78493023] ; [106.62174225,10.78536034] ; [106.62200928,10.78621960] ; [106.62217712,10.78670979]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2584"
    ,"Station_Code":"QTP 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Chợ Tân Hương"
    ,"Station_Address":"248 , đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.79012
    ,"Long":106.621338
    ,"Polyline":"[106.62217712,10.78670979] ; [106.62248230,10.78765011] ; [106.62306213,10.78940010.06.62316895] ; [10.78989029,106.62188721] ; [10.79004002,106.62133026]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2591"
    ,"Station_Code":"QTP 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trạm y tế   P.Tân Quý"
    ,"Station_Address":"71 , đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.790937
    ,"Long":106.620766
    ,"Polyline":"[106.62133789,10.79012012] ; [106.62083435,10.79022026] ; [106.62076569,10.79093742]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2586"
    ,"Station_Code":"QTP 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trạm caf é Minh Thùy"
    ,"Station_Address":"219, đường T ân Quý, Quận Tân Phú"
    ,"Lat":10.792765
    ,"Long":106.620628
    ,"Polyline":"[106.62076569,10.79093742] ; [106.62062836,10.79276466]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2593"
    ,"Station_Code":"QTP 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm Ngã 4 Gò Dầu- Tân Quý"
    ,"Station_Address":"135, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.795121
    ,"Long":106.620346
    ,"Polyline":"[106.62062836,10.79276466] ; [106.62034607,10.79512119]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2588"
    ,"Station_Code":"QTP 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm UBND Phường Tân Quý"
    ,"Station_Address":"113, đường T ân Quý, Quận Tân Phú"
    ,"Lat":10.796416
    ,"Long":106.619942
    ,"Polyline":"[106.62033081,10.79512024] ; [106.62027740,10.79564953] ; [106.62001038,10.79584980] ; [106.61992645,10.79640961]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2595"
    ,"Station_Code":"QTP 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Đỗ Công Tường"
    ,"Station_Address":"77, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.797576
    ,"Long":106.619781
    ,"Polyline":"[106.61992645,10.79640961] ; [106.61976624,10.79757023]"
    ,"Distance":"134"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2590"
    ,"Station_Code":"QTP 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"11B, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.798971
    ,"Long":106.619598
    ,"Polyline":"[106.61976624,10.79757023] ; [106.61959076,10.79897022]"
    ,"Distance":"160"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2592"
    ,"Station_Code":"QTP 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm Nhà Thờ Họ Tộc Nguyễn"
    ,"Station_Address":"395-397, đường Tân Kỳ Tân  Quý, Quận Tân Phú"
    ,"Lat":10.799767
    ,"Long":106.620506
    ,"Polyline":"[106.61959076,10.79897022] ; [106.61950684,10.79950047] ; [106.62030029,10.79979992] ; [106.62046051,10.79986954]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2597"
    ,"Station_Code":"QTP 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Showroom otô"
    ,"Station_Address":"343-345, đường Tân Kỳ Tân Quý, Quận Tân Ph ú"
    ,"Lat":10.800703
    ,"Long":106.622986
    ,"Polyline":"[106.62050629,10.79976749] ; [106.62298584,10.80070305]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2594"
    ,"Station_Code":"QTP 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm Xăng"
    ,"Station_Address":"295, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.8019
    ,"Long":106.625854
    ,"Polyline":"[106.62298584,10.80070305] ; [106.62585449,10.80189991]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2596"
    ,"Station_Code":"QTP 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm Đường Số 27"
    ,"Station_Address":"235, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.802643
    ,"Long":106.628525
    ,"Polyline":"[106.62585449,10.80189991] ; [106.62585449,10.80189991] ; [106.62735748,10.80247688] ; [106.62800598,10.80259800] ; [106.62852478,10.80264282] ; [106.62852478,10.80264282]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2598"
    ,"Station_Code":"QTP 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trạm Lê Trọng Tấn"
    ,"Station_Address":"153, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.803166
    ,"Long":106.631592
    ,"Polyline":"[106.62852478,10.80264282] ; [106.63159180,10.80316639]"
    ,"Distance":"340.394834161229"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2600"
    ,"Station_Code":"QTP 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trạm Đầu Lê Trọng Tấn"
    ,"Station_Address":"8A-8B, đường Lê Trọng Tấn , Quận Tân Phú"
    ,"Lat":10.804282
    ,"Long":106.632187
    ,"Polyline":"[106.63159180,10.80316639] ; [106.63159180,10.80316639] ; [106.63282776,10.80355167] ; [106.63218689,10.80428219] ; [106.63218689,10.80428219]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2602"
    ,"Station_Code":"QTP 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trường Cao Đẳng Công Nghệ Th ực Phẩm"
    ,"Station_Address":"142-144, đường L ê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806065
    ,"Long":106.628586
    ,"Polyline":"[106.63218689,10.80428219] ; [106.63218689,10.80428219] ; [106.63146210,10.80510044] ; [106.63079834,10.80553246] ; [106.62858582,10.80606461] ; [106.62858582,10.80606461]"
    ,"Distance":"457"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2604"
    ,"Station_Code":"QTP 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Lê Trọng Tấn"
    ,"Station_Address":"Kế 16, đường Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.807407
    ,"Long":106.627289
    ,"Polyline":"[106.62859344,10.80607986] ; [106.62740326,10.80634022] ; [106.62731934,10.80702019] ; [106.62728119,10.80741024]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2599"
    ,"Station_Code":"QTP 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"TT vh T ân Phú"
    ,"Station_Address":"72, đường Dương Đức Hiền, Quận Tân Phú"
    ,"Lat":10.810604
    ,"Long":106.627022
    ,"Polyline":"[106.62728119,10.80741024] ; [106.62715149,10.80856991] ; [106.62706757,10.80955982] ; [106.62700653,10.81060028]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2601"
    ,"Station_Code":"QTP 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm Bơm"
    ,"Station_Address":"71, đường Lưu Chí Hiếu, Quận Tân Phú"
    ,"Lat":10.812416
    ,"Long":106.62632
    ,"Polyline":"[106.62700653,10.81060028] ; [106.62695313,10.81153965] ; [106.62654114,10.81210041] ; [106.62631226,10.81241035]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2603"
    ,"Station_Code":"QTP 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm cuối D9"
    ,"Station_Address":"12-13, đường Lưu Chí Hiếu, Quận Tân Phú"
    ,"Lat":10.814318
    ,"Long":106.624893
    ,"Polyline":"[106.62631226,10.81241035] ; [106.62489319,10.81431961]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2457"
    ,"Station_Code":"QTP 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Trạm Công Ty Ngọc Nghĩa"
    ,"Station_Address":"Đối diện công ty Ngọc Nghĩa, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.815767
    ,"Long":106.625061
    ,"Polyline":"[106.62489319,10.81431961] ; [106.62463379,10.81472969] ; [106.62442017,10.81501007] ; [106.62432861,10.81511021] ; [106.62452698,10.81532955] ; [106.62502289,10.81581020]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2454"
    ,"Station_Code":"QTP 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cty Dầu Thực Vật"
    ,"Station_Address":"Công ty dầu th ực vật Tân Bình, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.81896
    ,"Long":106.628532
    ,"Polyline":"[106.62502289,10.81581020] ; [106.62677765,10.81744957] ; [106.62828827,10.81877995] ; [106.62851715,10.81896973]"
    ,"Distance":"528"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Khu Công  Nghiệp tân Bình"
    ,"Station_Address":"906, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.62851715,10.81896973] ; [106.62944031,10.81964970] ; [106.63059998,10.82044029] ; [106.63073730,10.82050037] ; [106.63041687,10.82151985] ; [106.63038635,10.82162952]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2607"
    ,"Station_Code":"QTB 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chung cư Phúc Yên"
    ,"Station_Address":"8 (14/32), đường Phan Huy Ích, Quận Tân Bình"
    ,"Lat":10.824498
    ,"Long":106.630356
    ,"Polyline":"[106.63038635,10.82162952] ; [106.63025665,10.82201958] ; [106.63004303,10.82254028] ; [106.62976837,10.82297993] ; [106.62978363,10.82320976] ; [106.62982178,10.82341957] ; [106.62988281,10.82361984] ; [106.63021088,10.82433033] ; [106.63030243,10.82452011]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2605"
    ,"Station_Code":"QTB 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Nhà máy hóa chất Tân Bình"
    ,"Station_Address":"Đối diện nhà máy hóa chất, đường Phan Huy Ích, Quận  Tân Bình"
    ,"Lat":10.828074
    ,"Long":106.632019
    ,"Polyline":"[106.63030243,10.82452011] ; [106.63095093,10.82586956] ; [106.63197327,10.82810020]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2609"
    ,"Station_Code":"QTB 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Nhà thờ Hy Vọng"
    ,"Station_Address":"72, đường Phan Huy  Ích, Quận Tân Bình"
    ,"Lat":10.830503
    ,"Long":106.633183
    ,"Polyline":"[106.63197327,10.82810020] ; [106.63263702,10.82956028] ; [106.63311005,10.83055019]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2606"
    ,"Station_Code":"QGV 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Trường Cao đẳng Du Lịch"
    ,"Station_Address":"162, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.832665
    ,"Long":106.634178
    ,"Polyline":"[106.63311005,10.83055019] ; [106.63410950,10.83269024]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2610"
    ,"Station_Code":"QGV 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trung tâm Y khoa Dân Sinh"
    ,"Station_Address":"235, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.83397
    ,"Long":106.634604
    ,"Polyline":"[106.63410950,10.83269024] ; [106.63469696,10.83397007]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2608"
    ,"Station_Code":"QGVT102"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Cây Xăng dầu Anh Thư"
    ,"Station_Address":"80/10B, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.835247993469238
    ,"Long":106.63538360595703
    ,"Polyline":"[106.63469696,10.83397007] ; [106.63532257,10.83528042]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2611"
    ,"Station_Code":"QGV 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Nhà sách Phan Huy Ích"
    ,"Station_Address":"332, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.837891
    ,"Long":106.636604
    ,"Polyline":"[106.63532257,10.83528042] ; [106.63655090,10.83790970]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2612"
    ,"Station_Code":"QGV 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Chùa Linh Sơn Hải Tự"
    ,"Station_Address":"386, đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.841504
    ,"Long":106.638451
    ,"Polyline":"[106.63655090,10.83790970] ; [106.63681030,10.83848000] ; [106.63715363,10.83917999] ; [106.63751221,10.83994961] ; [106.63793945,10.84080029] ; [106.63839722,10.84154034]"
    ,"Distance":"466"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2613"
    ,"Station_Code":"QGV 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Đường Nguyễn Duy Cung"
    ,"Station_Address":"460 , đường Phan Huy Ích, Quận Gò Vấp"
    ,"Lat":10.843685
    ,"Long":106.639851
    ,"Polyline":"[106.63839722,10.84154034] ; [106.63951874,10.84331036]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2614"
    ,"Station_Code":"QGV 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Trường  An Hội"
    ,"Station_Address":"6A-B, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.844771
    ,"Long":106.641321
    ,"Polyline":"[106.63951874,10.84331036] ; [106.63990021,10.84397984] ; [106.64009094,10.84424973] ; [106.64015961,10.84434032] ; [106.64022827,10.84438038] ; [106.64153290,10.84500027] ; [106.64185333,10.84514999]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2615"
    ,"Station_Code":"QGV 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Ngã Ba  Cây Trâm"
    ,"Station_Address":"50, đường Phạm  Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.845867
    ,"Long":106.643461
    ,"Polyline":"[106.64185333,10.84514999] ; [106.64272308,10.84556961]"
    ,"Distance":"107"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2616"
    ,"Station_Code":"QGV 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Công ty Huê Phong"
    ,"Station_Address":"132, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.846604
    ,"Long":106.644963
    ,"Polyline":"[106.64272308,10.84556961] ; [106.64366150,10.84605980] ; [106.64446259,10.84642029] ; [106.64588928,10.84712982]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2617"
    ,"Station_Code":"QGV 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Công ty Huê Phong"
    ,"Station_Address":"212 , đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.848164
    ,"Long":106.648262
    ,"Polyline":"[106.64588928,10.84712982] ; [106.64859772,10.84844017]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2618"
    ,"Station_Code":"QGV 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Trúc Ph ương"
    ,"Station_Address":"292, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.849868
    ,"Long":106.651962
    ,"Polyline":"[106.64859772,10.84844017] ; [106.64939880,10.84883022] ; [106.65045929,10.84932995] ; [106.65107727,10.84959984] ; [106.65193939,10.84992981]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2620"
    ,"Station_Code":"QGV 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Chợ Thạch Đà"
    ,"Station_Address":"400, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.850866
    ,"Long":106.654709
    ,"Polyline":"[106.65193939,10.84992981] ; [106.65469360,10.85093021]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2619"
    ,"Station_Code":"QGV 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trung tâm Văn hóa Quận Gò Vấp"
    ,"Station_Address":"490 , đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.851372
    ,"Long":106.65765
    ,"Polyline":"[106.65469360,10.85093021] ; [106.65524292,10.85112000] ; [106.65614319,10.85146046] ; [106.65622711,10.85146999] ; [106.65666199,10.85144043] ; [106.65724945,10.85138035] ; [106.65746307,10.85138988] ; [106.65756226,10.85142040] ; [106.65762329,10.85144043]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2622"
    ,"Station_Code":"QGVT078"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Trường  TH Lê Thị Hồng Gấm"
    ,"Station_Address":"54/11, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.852690696716309
    ,"Long":106.66150665283203
    ,"Polyline":"[106.65762329,10.85144043] ; [106.66075897,10.85249043] ; [106.66148376,10.85274982]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2621"
    ,"Station_Code":"QGV 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Ngã Ba Nhà Đèn"
    ,"Station_Address":"778, đường Phạm Văn Chiêu, Quận Gò Vấp"
    ,"Lat":10.853748
    ,"Long":106.664602
    ,"Polyline":"[106.66148376,10.85274982] ; [106.66361237,10.85346985] ; [106.66419220,10.85367966]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2623"
    ,"Station_Code":"QGV 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Nhà Thờ Hà Nội"
    ,"Station_Address":"540, đường Thống Nhất, Quận Gò Vấp"
    ,"Lat":10.850998
    ,"Long":106.66508
    ,"Polyline":"[106.66419220,10.85367966] ; [106.66459656,10.85383987] ; [106.66513062,10.85400009] ; [106.66549683,10.85412025] ; [106.66551971,10.85398960] ; [106.66551971,10.85365963] ; [106.66542053,10.85286999] ; [106.66516876,10.85105038]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2624"
    ,"Station_Code":"QGV 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Nhà thờ Trung Bắc"
    ,"Station_Address":"777, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.849149
    ,"Long":106.665911
    ,"Polyline":"[106.66516876,10.85105038] ; [106.66499329,10.84976959] ; [106.66509247,10.84969997] ; [106.66587830,10.84922981] ; [106.66593170,10.84920025]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2625"
    ,"Station_Code":"QGV 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Trường  THCS Lý Tự Trọng"
    ,"Station_Address":"527, đường L ê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.84751
    ,"Long":106.668706
    ,"Polyline":"[106.66593170,10.84920025] ; [106.66702271,10.84854031] ; [106.66773987,10.84819984] ; [106.66835785,10.84782982] ; [106.66931915,10.84722996] ; [106.66980743,10.84692955]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2629"
    ,"Station_Code":"QGV 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Bệnh Viện Gò Vấp"
    ,"Station_Address":"467, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.84514
    ,"Long":106.671828
    ,"Polyline":"[106.66980743,10.84692955] ; [106.67031860,10.84659004] ; [106.67082977,10.84626007] ; [106.67104340,10.84609032] ; [106.67127991,10.84585953] ; [106.67156219,10.84556007] ; [106.67173767,10.84535027] ; [106.67205048,10.84504032] ; [106.67215729,10.84492016] ; [106.67240906,10.84475040] ; [106.67283630,10.84447002] ; [106.67304230,10.84438992] ; [106.67317963,10.84436035]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"2626"
    ,"Station_Code":"QGV 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Ngã Ba Lê Hoàng Phái"
    ,"Station_Address":"353, đường Lê Đức Thọ, Quận Gò Vấp"
    ,"Lat":10.842499
    ,"Long":106.675697
    ,"Polyline":"[106.67317963,10.84436035] ; [106.67342377,10.84434032] ; [106.67350769,10.84430981] ; [106.67362213,10.84424019] ; [106.67372894,10.84414005] ; [106.67385864,10.84395981] ; [106.67417908,10.84354019] ; [106.67436218,10.84335995] ; [106.67447662,10.84325981] ; [106.67459869,10.84321022] ; [106.67469025,10.84315968] ; [106.67494202,10.84305954] ; [106.67533875,10.84280968] ; [106.67575073,10.84253979]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"72"
    ,"Station_Code":"QGV 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Ngã tư An Nhơn"
    ,"Station_Address":"388, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.842342
    ,"Long":106.676903
    ,"Polyline":"[106.67575073,10.84253979] ; [106.67617798,10.84218979] ; [106.67635345,10.84208012] ; [106.67659760,10.84193993] ; [106.67671204,10.84226036]"
    ,"Distance":"170"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"64"
    ,"Station_Code":"QGV 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"530, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.846894
    ,"Long":106.678512
    ,"Polyline":"[106.67671204,10.84226036] ; [106.67819214,10.84642029] ; [106.67835236,10.84691048]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"66"
    ,"Station_Code":"QGVT111"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Cầu An Lộc"
    ,"Station_Address":"604, đường Nguyễn Oanh, Qu ận Gò Vấp"
    ,"Lat":10.849006
    ,"Long":106.678749
    ,"Polyline":"[106.67835236,10.84691048] ; [106.67851257,10.84753990] ; [106.67855835,10.84811020] ; [106.67864227,10.84901047]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"73"
    ,"Station_Code":"Q12 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"65"
    ,"Station_Name":"Nhà hàng Bến Xưa"
    ,"Station_Address":"42 , đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.852642
    ,"Long":106.679285
    ,"Polyline":"[106.67864227,10.84901047] ; [106.67865753,10.84939003] ; [106.67874908,10.85031033] ; [106.67893982,10.85177994]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"53"
    ,"Station_Id":"946"
    ,"Station_Code":"BX37"
    ,"Station_Direction":"1"
    ,"Station_Order":"66"
    ,"Station_Name":"Bến xe Ngã tư Ga"
    ,"Station_Address":"Bến xe Ngã Tư Ga, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.862156867980957
    ,"Long":106.67835998535156
    ,"Polyline":"[106.67893982,10.85177994] ; [106.67929840,10.85394001] ; [106.67948914,10.85542011] ; [106.67980957,10.85789967] ; [106.68025208,10.86151981] ; [106.68048859,10.86376953] ; [106.68048859,10.86413002] ; [106.68067932,10.86421967] ; [106.68080139,10.86425018] ; [106.68158722,10.86421967] ; [106.68174744,10.86417961] ; [106.68189240,10.86406994] ; [106.68192291,10.86398983] ; [106.68193054,10.86382961] ; [106.68183899,10.86297035] ; [106.68173218,10.86184978] ; [106.68166351,10.86168957] ; [106.68161011,10.86161995] ; [106.68153381,10.86155033] ; [106.68129730,10.86145020] ; [106.68041992,10.86151028] ; [106.67832947,10.86166954]"
    ,"Distance":"2251"
  }]