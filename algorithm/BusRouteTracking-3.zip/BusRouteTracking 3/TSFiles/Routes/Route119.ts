export const Route119 =[

  {
     "Route_Id":"119"
    ,"Station_Id":"3874"
    ,"Station_Code":"BX 64"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến Dược"
    ,"Station_Address":"ĐẦU BẾN BẾN DƯỢC, đường Tỉnh lộ 15, Huy ện Củ Chi"
    ,"Lat":11.154824
    ,"Long":106.455331
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3536"
    ,"Station_Code":"QCCT103"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 3 Đền Bến Dược"
    ,"Station_Address":"2185, đường Tỉnh lộ 15 Củ Chi, Huy ện Củ Chi"
    ,"Lat":11.149666786193848
    ,"Long":106.46046447753906
    ,"Polyline":"[106.45539856,11.15495014] ; [106.45749664,11.15429783] ; [106.45841980,11.15301418] ; [106.45938873,11.15124512] ; [106.45986176,11.15044498] ; [106.46037292,11.14983463]"
    ,"Distance":"830"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3533"
    ,"Station_Code":"QCCT104"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Lai Thai"
    ,"Station_Address":"2045, đường Tỉnh lộ 15 Củ Chi, Huyện C ủ Chi"
    ,"Lat":11.142566680908203
    ,"Long":106.46981811523438
    ,"Polyline":"[106.46046448,11.14966679] ; [106.46981812,11.14256668]"
    ,"Distance":"1292"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3534"
    ,"Station_Code":"QCCT105"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Xã Phú Mỹ Hưng"
    ,"Station_Address":"1979, đường  Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.139049530029297
    ,"Long":106.47348022460938
    ,"Polyline":"[106.46981812,11.14256668] ; [106.47148895,11.14106655] ; [106.47348022,11.13904953]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3538"
    ,"Station_Code":"QCCT106"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã 3 Tỉnh lộ 15"
    ,"Station_Address":"1833, đường Tỉnh lộ 15 Củ Chi, Huy ện Củ Chi"
    ,"Lat":11.130499839782715
    ,"Long":106.47985076904297
    ,"Polyline":"[106.47348022,11.13904953] ; [106.47412872,11.13828754] ; [106.47433472,11.13787651] ; [106.47466278,11.13657093] ; [106.47518921,11.13585567] ; [106.47598267,11.13501358] ; [106.47730255,11.13354969] ; [106.47933960,11.13132858] ; [106.47985077,11.13049984]"
    ,"Distance":"1195"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3875"
    ,"Station_Code":"HCC 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Hố Bò"
    ,"Station_Address":"1477, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.127224
    ,"Long":106.482933
    ,"Polyline":"[106.47985077,11.13049984] ; [106.48033142,11.12993908] ; [106.48249817,11.12965488] ; [106.48323822,11.12952900] ; [106.48464966,11.12932873] ; [106.48459625,11.12909031] ; [106.48448944,11.12870026] ; [106.48300171,11.12716007] ; [106.48293304,11.12722397]"
    ,"Distance":"877"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3877"
    ,"Station_Code":"QCCT295"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trại cưa Minh Khôi"
    ,"Station_Address":"1343, đường Nguyễn Thị Rành,  Huyện Củ Chi"
    ,"Lat":11.123639106750488
    ,"Long":106.47962951660156
    ,"Polyline":"[106.48300171,11.12716007] ; [106.48026276,11.12432003] ; [106.47978973,11.12382984] ; [106.47972107,11.12360954]"
    ,"Distance":"557"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3878"
    ,"Station_Code":"HCC 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Phú Nhuận"
    ,"Station_Address":"Đối diện 1180, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.117739
    ,"Long":106.477501
    ,"Polyline":"[106.47972107,11.12360954] ; [106.47810364,11.11868954] ; [106.47801971,11.11855030] ; [106.47760010,11.11773014]"
    ,"Distance":"717"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3879"
    ,"Station_Code":"HCC 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã tư An Nhơn Tây"
    ,"Station_Address":"Ngã tư An Nhơn Tây, đường Nguy ễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.112633
    ,"Long":106.474335
    ,"Polyline":"[106.47757721,11.11769962] ; [106.47653961,11.11567974] ; [106.47518921,11.11357975] ; [106.47438049,11.11260033]"
    ,"Distance":"684"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3881"
    ,"Station_Code":"HCC 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã tư Bàu Đưng"
    ,"Station_Address":"1149, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.105168
    ,"Long":106.472656
    ,"Polyline":"[106.47438049,11.11260033] ; [106.47377014,11.11168003] ; [106.47360992,11.11137962] ; [106.47303009,11.10741997] ; [106.47270203,11.10515976]"
    ,"Distance":"871"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3880"
    ,"Station_Code":"HCC 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trạm Bàu Đưng"
    ,"Station_Address":"1047A, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.09963
    ,"Long":106.471817
    ,"Polyline":"[106.47270203,11.10515976] ; [106.47190094,11.09961987]"
    ,"Distance":"637"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3883"
    ,"Station_Code":"HCC 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Lô 6 An Nhơn Tây"
    ,"Station_Address":"945, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.089586
    ,"Long":106.473183
    ,"Polyline":"[106.47190094,11.09961987] ; [106.47187805,11.09951019] ; [106.47268677,11.09607029] ; [106.47329712,11.09344006] ; [106.47331238,11.09255981] ; [106.47326660,11.08959007]"
    ,"Distance":"1153"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3882"
    ,"Station_Code":"HCC 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 4 Xóm mới An Nhơn Tây"
    ,"Station_Address":"847B, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.079711
    ,"Long":106.475113
    ,"Polyline":"[106.47326660,11.08959007] ; [106.47324371,11.08695984] ; [106.47326660,11.08627033] ; [106.47522736,11.07973957]"
    ,"Distance":"1150"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3884"
    ,"Station_Code":"HCC 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 3 Canh Lý"
    ,"Station_Address":"573, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.075178
    ,"Long":106.476532
    ,"Polyline":"[106.47522736,11.07973957] ; [106.47657013,11.07518959]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3885"
    ,"Station_Code":"HCC 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường tiều học Nhuận Đức 2"
    ,"Station_Address":"657, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.070663
    ,"Long":106.477768
    ,"Polyline":"[106.47657013,11.07518959] ; [106.47782135,11.07067966]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3888"
    ,"Station_Code":"HCC 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Xã Nhuận Đức"
    ,"Station_Address":"Đối diện 572, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.055224
    ,"Long":106.482521
    ,"Polyline":"[106.47782135,11.07067966] ; [106.47882080,11.06709003] ; [106.47911072,11.06585026] ; [106.47927856,11.06494999] ; [106.47943115,11.06410027] ; [106.47969818,11.06322956] ; [106.48026276,11.06196022] ; [106.48082733,11.06035042] ; [106.48164368,11.05797958] ; [106.48261261,11.05525970]"
    ,"Distance":"1815"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3886"
    ,"Station_Code":"HCC 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã tư Nhuận Đức"
    ,"Station_Address":"511, đường Nguy ễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.043473
    ,"Long":106.484581
    ,"Polyline":"[106.48261261,11.05525970] ; [106.48397064,11.05144024] ; [106.48416901,11.04961967] ; [106.48442078,11.04712009] ; [106.48465729,11.04506969] ; [106.48483276,11.04349995]"
    ,"Distance":"1378"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3889"
    ,"Station_Code":"QCCT306"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trạm Bàu Chứa"
    ,"Station_Address":"Đối diện 436, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.033785820007324
    ,"Long":106.48653411865234
    ,"Polyline":"[106.48483276,11.04349995] ; [106.48509216,11.04127026] ; [106.48528290,11.04014969] ; [106.48560333,11.03855991] ; [106.48574066,11.03787994] ; [106.48590851,11.03724003] ; [106.48660278,11.03460026] ; [106.48677826,11.03384018]"
    ,"Distance":"1153"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3887"
    ,"Station_Code":"HCC 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã 3 Bàu Chứa"
    ,"Station_Address":"313, đường Nguy ễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.020264
    ,"Long":106.483925
    ,"Polyline":"[106.48677826,11.03384018] ; [106.48692322,11.03326035] ; [106.48686218,11.03314972] ; [106.48648071,11.03254986] ; [106.48622131,11.03195953] ; [106.48612213,11.03170013] ; [106.48593140,11.03083038] ; [106.48571777,11.02952957] ; [106.48509979,11.02556038] ; [106.48483276,11.02390957] ; [106.48462677,11.02258015] ; [106.48436737,11.02105999] ; [106.48419189,11.02021027]"
    ,"Distance":"1615"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3890"
    ,"Station_Code":"HCC 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã tư Xóm Mới - Tỉnh lộ 2"
    ,"Station_Address":"207 , đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.010997
    ,"Long":106.473755
    ,"Polyline":"[106.48419189,11.02021027] ; [106.48400879,11.01928043] ; [106.48361969,11.01825047] ; [106.48341370,11.01788044] ; [106.48329163,11.01772022] ; [106.48256683,11.01753998] ; [106.48124695,11.01737022] ; [106.48078918,11.01727962] ; [106.48021698,11.01708031] ; [106.48000336,11.01700974] ; [106.47979736,11.01690960] ; [106.47811127,11.01521969] ; [106.47570038,11.01274014] ; [106.47463226,11.01165009] ; [106.47383881,11.01091003]"
    ,"Distance":"1667"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3891"
    ,"Station_Code":"HCC 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Trạm Trung  Viết"
    ,"Station_Address":"143, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":10.999085
    ,"Long":106.467171
    ,"Polyline":"[106.47383881,11.01091003] ; [106.47350311,11.01058960] ; [106.47296906,11.00979996] ; [106.47190094,11.00852966] ; [106.47126007,11.00811005] ; [106.47059631,11.00745010.06.46958160] ; [11.00615978,106.46855164] ; [11.00436020,106.46822357] ; [11.00378990,106.46700287] ; [11.00131035,106.46695709] ; [11.00098991,106.46717834] ; [10.99971962,106.46732330]"
    ,"Distance":"1597"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3892"
    ,"Station_Code":"HCC 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã 3 Trung Viết"
    ,"Station_Address":"53, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":10.989501
    ,"Long":106.469604
    ,"Polyline":"[106.46732330,10.99911976] ; [106.46806335,10.99582005] ; [106.46827698,10.99409962] ; [106.46962738,10.99059963] ; [106.46974945,10.98952007]"
    ,"Distance":"1140"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3893"
    ,"Station_Code":"HCC 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường tiểu học Liên Minh Công Nông"
    ,"Station_Address":"3 (trường Liên Minh Công Nông), đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":10.980701
    ,"Long":106.470888
    ,"Polyline":"[106.46974945,10.98952007] ; [106.47075653,10.98019028]"
    ,"Distance":"1119"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"788"
    ,"Station_Code":"HCC 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Bệnh viện Củ Chi"
    ,"Station_Address":"991, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.973655
    ,"Long":106.477443
    ,"Polyline":"[106.47075653,10.98019028] ; [106.47096252,10.97850037] ; [106.47106171,10.97729015] ; [106.47100067,10.97716999] ; [106.47399139,10.97548962] ; [106.47534943,10.97478008] ; [106.47572327,10.97459030]"
    ,"Distance":"1204"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"963"
    ,"Station_Code":"HCC 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Bệnh viện Củ Chi"
    ,"Station_Address":"907, đường Qu ốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.972091
    ,"Long":106.48049
    ,"Polyline":"[106.47747040,10.97373295] ; [106.47747040,10.97373295] ; [106.48021698,10.97238636] ; [106.48051453,10.97213268] ; [106.48051453,10.97213268]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":"[106.48051453,10.97213268] ; [106.48102570,10.97177505] ; [106.48171997,10.97117519] ; [106.48210144,10.97161674]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe C ủ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"734"
    ,"Station_Code":"HCC 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"926, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.972533
    ,"Long":106.480347
    ,"Polyline":"[106.48226166,10.97154999] ; [106.48220062,10.97148037] ; [106.48210144,10.97142029] ; [106.48197937,10.97140026] ; [106.48181152,10.97138977] ; [106.48175049,10.97136021] ; [106.48169708,10.97130013] ; [106.48161316,10.97136974]"
    ,"Distance":"83"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"733"
    ,"Station_Code":"HCC 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Bệnh viện Củ Chi"
    ,"Station_Address":"18, đường Qu ốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.974417
    ,"Long":106.476402
    ,"Polyline":"[106.48161316,10.97136974] ; [106.48153687,10.97142982] ; [106.48139191,10.97163010.06.48087311] ; [10.97208023,106.48052216] ; [10.97235012,106.48023987] ; [10.97253036,106.47952271] ; [10.97290039,106.47651672]"
    ,"Distance":"650"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3856"
    ,"Station_Code":"HCC 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Quốc lộ 22"
    ,"Station_Address":"Đối diện số 1, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":10.980538
    ,"Long":106.47084
    ,"Polyline":"[106.47651672,10.97430038] ; [106.47583771,10.97461987] ; [106.47341919,10.97589970] ; [106.47207642,10.97665024] ; [106.47103882,10.97723961] ; [106.47106171,10.97729015] ; [106.47096252,10.97850037] ; [106.47073364,10.98048973] ; [106.47073364,10.98052979]"
    ,"Distance":"1051"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3857"
    ,"Station_Code":"QCCT277"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường tiểu học Liên Minh Công Nông"
    ,"Station_Address":"Trường tiểu học Liên Minh Công Nông, đường Nguy ễn Thị Rành, Huyện Củ Chi"
    ,"Lat":10.990038871765137
    ,"Long":106.46981048583984
    ,"Polyline":"[106.47073364,10.98052979] ; [106.46970367,10.99003029]"
    ,"Distance":"1063"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3858"
    ,"Station_Code":"HCC 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Trung  Viết"
    ,"Station_Address":"112, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":10.99838
    ,"Long":106.467567
    ,"Polyline":"[106.46970367,10.99003029] ; [106.46962738,10.99059963] ; [106.46896362,10.99236012] ; [106.46827698,10.99409962] ; [106.46813202,10.99528980] ; [106.46806335,10.99582005] ; [106.46768951,10.99744987] ; [106.46749115,10.99835968]"
    ,"Distance":"963"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3859"
    ,"Station_Code":"HCC 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trạm Trung Viết"
    ,"Station_Address":"194, đường Nguy ễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.011081
    ,"Long":106.474243
    ,"Polyline":"[106.46749115,10.99835968] ; [106.46717834,10.99971962] ; [106.46695709,11.00098991] ; [106.46700287,11.00131035] ; [106.46822357,11.00378990] ; [106.46855164,11.00436020] ; [106.46958160,11.00615978] ; [106.47059631,11.00745010.06.47126007] ; [11.00811005,106.47190094] ; [11.00852966,106.47296906] ; [11.00979996,106.47350311] ; [11.01058960,106.47413635]"
    ,"Distance":"1698"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3860"
    ,"Station_Code":"HCC 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã tư Xóm Mới - Tỉnh lộ 2"
    ,"Station_Address":"Đối diện 337, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.021422
    ,"Long":106.48455
    ,"Polyline":"[106.47413635,11.01119041] ; [106.47570038,11.01274014] ; [106.47811127,11.01521969] ; [106.47979736,11.01690960] ; [106.48000336,11.01700974] ; [106.48021698,11.01708031] ; [106.48078918,11.01727962] ; [106.48124695,11.01737022] ; [106.48256683,11.01753998] ; [106.48329163,11.01772022] ; [106.48341370,11.01788044] ; [106.48361969,11.01825047] ; [106.48400879,11.01928043] ; [106.48436737,11.02105999] ; [106.48442841,11.02143955]"
    ,"Distance":"1717"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3861"
    ,"Station_Code":"QCCT281"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã 3 Bàu Chứa"
    ,"Station_Address":"Đối diện 401, đường Nguyễn Thị Rành, Huy ện Củ Chi"
    ,"Lat":11.034564971923828
    ,"Long":106.48677062988281
    ,"Polyline":"[106.48442841,11.02143955] ; [106.48474121,11.02322960] ; [106.48500061,11.02493000] ; [106.48535156,11.02719975] ; [106.48587799,11.03050995] ; [106.48612213,11.03170013] ; [106.48648071,11.03254986] ; [106.48692322,11.03326035] ; [106.48661041,11.03452969]"
    ,"Distance":"1497"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3862"
    ,"Station_Code":"HCC 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Bàu Chứa"
    ,"Station_Address":"500, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.045495
    ,"Long":106.48484
    ,"Polyline":"[106.48661041,11.03452969] ; [106.48574066,11.03787994] ; [106.48528290,11.04014969] ; [106.48509216,11.04127026] ; [106.48484039,11.04339981] ; [106.48461151,11.04547024]"
    ,"Distance":"1239"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3863"
    ,"Station_Code":"QCCT283"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã tư Nhuận Đức"
    ,"Station_Address":"580, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.056299209594727
    ,"Long":106.48248291015625
    ,"Polyline":"[106.48461151,11.04547024] ; [106.48442078,11.04712009] ; [106.48416901,11.04961967] ; [106.48397064,11.05144024] ; [106.48226929,11.05622959]"
    ,"Distance":"1232"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3865"
    ,"Station_Code":"HCC 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Xã Nhuận Đức"
    ,"Station_Address":"606, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.069524
    ,"Long":106.478363
    ,"Polyline":"[106.48226929,11.05622959] ; [106.48164368,11.05797958] ; [106.48082733,11.06035042] ; [106.48026276,11.06196022] ; [106.47969818,11.06322956] ; [106.47943115,11.06410027] ; [106.47927856,11.06494999] ; [106.47911072,11.06585026] ; [106.47882080,11.06709003] ; [106.47814941,11.06947041]"
    ,"Distance":"1544"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3864"
    ,"Station_Code":"HCC 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường tiều học Nhuận Đức 2"
    ,"Station_Address":"688, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.075652
    ,"Long":106.476707
    ,"Polyline":"[106.47814941,11.06947041] ; [106.47646332,11.07559013]"
    ,"Distance":"705"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3866"
    ,"Station_Code":"HCC 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 3 Canh Lý"
    ,"Station_Address":"778, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.079063
    ,"Long":106.475655
    ,"Polyline":"[106.47646332,11.07559013] ; [106.47544861,11.07900047]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3867"
    ,"Station_Code":"HCC 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Xóm mới An Nhơn Tây"
    ,"Station_Address":"856 , đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.09075
    ,"Long":106.473534
    ,"Polyline":"[106.47544861,11.07900047] ; [106.47457886,11.08193016] ; [106.47326660,11.08627033] ; [106.47325134,11.08679008] ; [106.47325897,11.08893013] ; [106.47328186,11.09074974]"
    ,"Distance":"1342"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3868"
    ,"Station_Code":"HCC 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Lô 6 An  Nhơn Tây"
    ,"Station_Address":"980B, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.098289
    ,"Long":106.472397
    ,"Polyline":"[106.47328186,11.09074974] ; [106.47331238,11.09255981] ; [106.47329712,11.09344006] ; [106.47268677,11.09607029] ; [106.47218323,11.09823990]"
    ,"Distance":"847"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3870"
    ,"Station_Code":"HCC 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trạm Bàu Đưng"
    ,"Station_Address":"1084 , đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.106163
    ,"Long":106.473122
    ,"Polyline":"[106.47218323,11.09823990] ; [106.47187805,11.09951019] ; [106.47222137,11.10181046] ; [106.47284698,11.10620022]"
    ,"Distance":"897"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3869"
    ,"Station_Code":"QCCT290"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã t ư Bàu Đưng"
    ,"Station_Address":"Đối diện cột  điện 78, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.112985610961914
    ,"Long":106.47496795654297
    ,"Polyline":"[106.47284698,11.10620022] ; [106.47344208,11.11023998] ; [106.47360992,11.11137962] ; [106.47377014,11.11168003] ; [106.47441864,11.11266994] ; [106.47480011,11.11312008]"
    ,"Distance":"816"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3872"
    ,"Station_Code":"HCC 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Phú Nhuận"
    ,"Station_Address":"1188A, đường Nguyễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.117954
    ,"Long":106.478035
    ,"Polyline":"[106.47480011,11.11312008] ; [106.47518921,11.11357975] ; [106.47653961,11.11567974] ; [106.47778320,11.11808014]"
    ,"Distance":"642"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3871"
    ,"Station_Code":"HCC 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trại cưa Minh Khôi"
    ,"Station_Address":"1284, đường Nguy ễn Thị Rành, Huyện Củ Chi"
    ,"Lat":11.124018
    ,"Long":106.480331
    ,"Polyline":"[106.47778320,11.11808014] ; [106.47810364,11.11868954] ; [106.47978973,11.12382984] ; [106.48014069,11.12419987]"
    ,"Distance":"733"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3873"
    ,"Station_Code":"QCCT293"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã 3 Hố Bò"
    ,"Station_Address":"Đối diện 1493A, đường Nguyễn Thị Rành, Huy ện Củ Chi"
    ,"Lat":11.127007484436035
    ,"Long":106.48336029052734
    ,"Polyline":"[106.48014069,11.12419987] ; [106.48310089,11.12724972]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3515"
    ,"Station_Code":"QCCT099"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nguyễn Thị Rành - Tỉnh lộ 15"
    ,"Station_Address":"Đối diện 1873, đường Tỉnh lộ 15 Củ Chi, Huyện C ủ Chi"
    ,"Lat":11.131916999816895
    ,"Long":106.47886657714844
    ,"Polyline":"[106.48336029,11.12700748] ; [106.48310089,11.12724972] ; [106.48448944,11.12870026] ; [106.48459625,11.12909031] ; [106.48465729,11.12936974] ; [106.48322296,11.12956047] ; [106.48234558,11.12966537] ; [106.48144531,11.12983418] ; [106.48088837,11.12989712] ; [106.48026276,11.13004494] ; [106.47998810,11.13040257] ; [106.47944641,11.13124466] ; [106.47886658,11.13191700]"
    ,"Distance":"1082"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3518"
    ,"Station_Code":"QCCT100"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Xã Phú Mỹ Hưng"
    ,"Station_Address":"1832, đường Tỉnh lộ 15 Củ Chi, Huy ện Củ Chi"
    ,"Lat":11.13933277130127
    ,"Long":106.47333526611328
    ,"Polyline":"[106.47886658,11.13191700] ; [106.47669983,11.13427639] ; [106.47463989,11.13678169] ; [106.47457886,11.13756084] ; [106.47406006,11.13848686] ; [106.47333527,11.13933277]"
    ,"Distance":"1039"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3516"
    ,"Station_Code":"QCCT102"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã 3 Đền Bến Dược"
    ,"Station_Address":"2056, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.1493501663208
    ,"Long":106.46099853515625
    ,"Polyline":"[106.47333527,11.13933277] ; [106.47013855,11.14236069] ; [106.46687317,11.14497185] ; [106.46099854,11.14935017]"
    ,"Distance":"1751"
  },
  {
     "Route_Id":"119"
    ,"Station_Id":"3874"
    ,"Station_Code":"BX 64"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Bến Dược"
    ,"Station_Address":"ĐẦU BẾN BẾN DƯỢC, đường Tỉnh lộ 15, Huyện Củ Chi"
    ,"Lat":11.154824
    ,"Long":106.455331
    ,"Polyline":"[106.46099854,11.14935017] ; [106.45983887,11.15052986] ; [106.45831299,11.15318203] ; [106.45754242,11.15423489] ; [106.45685577,11.15452957] ; [106.45532990,11.15482426]"
    ,"Distance":"917"
  }]