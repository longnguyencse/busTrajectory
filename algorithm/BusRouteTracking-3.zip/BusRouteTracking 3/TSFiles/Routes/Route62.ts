export const Route62 =[

  {
     "Route_Id":"62"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"171"
    ,"Station_Code":"Q12 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"601, đường Trường Chinh, Quận 12"
    ,"Lat":10.841209
    ,"Long":106.615925
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61504364,10.84255981] ; [106.61511993,10.84243011] ; [106.61530304,10.84235001] ; [106.61535645,10.84234047] ; [106.61546326,10.84218979] ; [106.61605835,10.84127045]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"167"
    ,"Station_Code":"Q12 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"487, đường Trường Chinh, Quận 12"
    ,"Lat":10.837863
    ,"Long":106.618044
    ,"Polyline":"[106.61605835,10.84127045] ; [106.61820221,10.83794975]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"172"
    ,"Station_Code":"Q12 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Lạc  Quang"
    ,"Station_Address":"257, đường Trường  Chinh, Quận 12"
    ,"Lat":10.834623
    ,"Long":106.620163
    ,"Polyline":"[106.61820221,10.83794975] ; [106.62029266,10.83471012]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"168"
    ,"Station_Code":"Q12 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"Chùa Vĩnh Phước, đường Trường Chinh , Quận 12"
    ,"Lat":10.831836
    ,"Long":106.621928
    ,"Polyline":"[106.62029266,10.83471012] ; [106.62207794,10.83191967]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"170"
    ,"Station_Code":"Q12 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"113, đường Trường Chinh, Quận 12"
    ,"Lat":10.82898
    ,"Long":106.623768
    ,"Polyline":"[106.62207794,10.83191967] ; [106.62387848,10.82913017]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đư ờng Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62387848,10.82913017] ; [106.62487793,10.82758999] ; [106.62512207,10.82730007] ; [106.62560272,10.82676029] ; [106.62599182,10.82637978]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trư ờng Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62599182,10.82637978] ; [106.62699890,10.82542038] ; [106.62803650,10.82446957] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2454"
    ,"Station_Code":"QTP 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Cty Dầu Thực Vật"
    ,"Station_Address":"Công ty dầu thực vật Tân Bình, đường T ây Thạnh, Quận Tân Phú"
    ,"Lat":10.81896
    ,"Long":106.628532
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63059235,10.82044029] ; [106.62867737,10.81910992] ; [106.62851715,10.81896973]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2651"
    ,"Station_Code":"QTP 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Công Ty Ngọc Nghĩa"
    ,"Station_Address":"Công ty Ngọc Nghĩa, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.816059
    ,"Long":106.625336
    ,"Polyline":"[106.62851715,10.81896973] ; [106.62772369,10.81828022] ; [106.62677765,10.81744957] ; [106.62568665,10.81643009] ; [106.62532806,10.81608963]"
    ,"Distance":"473"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2920"
    ,"Station_Code":"QTP 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trạm Trường Tiểu Học Lê Lai"
    ,"Station_Address":"Trường Lê Lai, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.812615
    ,"Long":106.622147
    ,"Polyline":"[106.62531281,10.81608009] ; [106.62452698,10.81532955] ; [106.62371063,10.81441975] ; [106.62265015,10.81315994] ; [106.62207794,10.81252003]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2921"
    ,"Station_Code":"QTP 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm Lê Trọng Tấn"
    ,"Station_Address":"298, đường T ây Thạnh, Quận Tân Phú"
    ,"Lat":10.809585
    ,"Long":106.619133
    ,"Polyline":"[106.62214661,10.81261539] ; [106.62207794,10.81252003] ; [106.62035370,10.81065941] ; [106.61962128,10.80989075] ; [106.61913300,10.80958462]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2924"
    ,"Station_Code":"QTP 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Tây Thạnh"
    ,"Station_Address":"363, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.807646
    ,"Long":106.61982
    ,"Polyline":"[106.61913300,10.80958462] ; [106.61893463,10.80914211] ; [106.61826324,10.80842018] ; [106.61923981,10.80803967] ; [106.61988068,10.80788040] ; [106.61981964,10.80764580]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1974"
    ,"Station_Code":"QTP 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Bờ Bao Tân Thắng"
    ,"Station_Address":"271, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.80731
    ,"Long":106.622368
    ,"Polyline":"[106.61988068,10.80788040] ; [106.62261963,10.80727005]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1975"
    ,"Station_Code":"QTP 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"Đối diện 220, đường Lê Trọng Tấn, Quận Tân  Phú"
    ,"Lat":10.806767
    ,"Long":106.624886
    ,"Polyline":"[106.62261963,10.80727005] ; [106.62435150,10.80688953] ; [106.62509918,10.80673027] ; [106.62506104,10.80648041]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2654"
    ,"Station_Code":"QTP 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Cao Đẳng Công Nghệ Thực Phẩm"
    ,"Station_Address":"117, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.80593
    ,"Long":106.628693
    ,"Polyline":"[106.62506104,10.80648041] ; [106.62509918,10.80673027] ; [106.62558746,10.80661011] ; [106.62658691,10.80640984] ; [106.62870026,10.80595970]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2925"
    ,"Station_Code":"QTP 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"15, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.804359
    ,"Long":106.631981
    ,"Polyline":"[106.62870026,10.80595970] ; [106.63025665,10.80560017] ; [106.63056183,10.80552006] ; [106.63101959,10.80533028] ; [106.63136292,10.80506039] ; [106.63172913,10.80467987] ; [106.63200378,10.80436993]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2657"
    ,"Station_Code":"QTP 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trạm café BonJour"
    ,"Station_Address":"128-130, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.803346
    ,"Long":106.631577
    ,"Polyline":"[106.63200378,10.80436993] ; [106.63218689,10.80412960] ; [106.63271332,10.80348969] ; [106.63189697,10.80335045] ; [106.63159180,10.80329990]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2656"
    ,"Station_Code":"QTP 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Đường Số 27"
    ,"Station_Address":"216, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.802817
    ,"Long":106.628487
    ,"Polyline":"[106.63159180,10.80329990] ; [106.62943268,10.80294037] ; [106.62850952,10.80274963]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2659"
    ,"Station_Code":"QTP 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trạm cây xăng Sài Gòn Petro"
    ,"Station_Address":"302, đường Tân Kỳ Tân Quý , Quận Tân Phú"
    ,"Lat":10.802044
    ,"Long":106.625923
    ,"Polyline":"[106.62850952,10.80274963] ; [106.62777710,10.80261993] ; [106.62731934,10.80251980] ; [106.62690735,10.80237961] ; [106.62595367,10.80198956]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2926"
    ,"Station_Code":"QTP 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đầu cầu xéo"
    ,"Station_Address":"Đối diện 9, đường  Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.800399
    ,"Long":106.624222
    ,"Polyline":"[106.62595367,10.80198956] ; [106.62464142,10.80144978] ; [106.62422943,10.80039978]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2922"
    ,"Station_Code":"QTP 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Lê Đình Thám"
    ,"Station_Address":"94, đường Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.796659
    ,"Long":106.623749
    ,"Polyline":"[106.62422943,10.80039978] ; [106.62400818,10.79967022] ; [106.62390900,10.79926014] ; [106.62384033,10.79883957] ; [106.62377930,10.79788971] ; [106.62380219,10.79666042]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2923"
    ,"Station_Code":"QTP 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Café Tino"
    ,"Station_Address":"111, đường Gò Dầu, Quận T ân Phú"
    ,"Lat":10.795829
    ,"Long":106.624748
    ,"Polyline":"[106.62380219,10.79666042] ; [106.62380981,10.79590034] ; [106.62394714,10.79590034] ; [106.62474823,10.79586983]"
    ,"Distance":"187"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2927"
    ,"Station_Code":"QTP 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chung cư  Gò Dầu"
    ,"Station_Address":"65, đường Gò Dầu, Quận Tân Phú"
    ,"Lat":10.795624
    ,"Long":106.628082
    ,"Polyline":"[106.62474823,10.79586983] ; [106.62737274,10.79580975] ; [106.62792969,10.79576969] ; [106.62803650,10.79572964] ; [106.62811279,10.79570007]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2931"
    ,"Station_Code":"QTP 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Tân Sơn Nhì"
    ,"Station_Address":"432, đường T ân Sơn Nhì, Quận Tân Phú"
    ,"Lat":10.794048
    ,"Long":106.628799
    ,"Polyline":"[106.62811279,10.79570007] ; [106.62879944,10.79528999] ; [106.62921906,10.79502010.06.62938690] ; [10.79491043,106.62915802] ; [10.79456043,106.62882996]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2719"
    ,"Station_Code":"QTP 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà thờ Martino"
    ,"Station_Address":"2, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.792652
    ,"Long":106.62886
    ,"Polyline":"[106.62879944,10.79404831] ; [106.62870789,10.79400349] ; [106.62857819,10.79378223] ; [106.62844849,10.79354477] ; [106.62838745,10.79337597] ; [106.62846375,10.79323387] ; [106.62863159,10.79312325] ; [106.62879944,10.79307556] ; [106.62889862,10.79292870] ; [106.62886047,10.79265213]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2717"
    ,"Station_Code":"QTP 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cafe Suối Reo"
    ,"Station_Address":"90, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.789865
    ,"Long":106.627785
    ,"Polyline":"[106.62882996,10.79246044] ; [106.62859344,10.79158020] ; [106.62819672,10.79022980] ; [106.62808228,10.79010010.06.62783051] ; [10.78987026,106.62779999]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2722"
    ,"Station_Code":"QTP 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Nhà Thờ Tân Hương"
    ,"Station_Address":"190, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.789805
    ,"Long":106.624008
    ,"Polyline":"[106.62779999,10.78985023] ; [106.62719727,10.78936958] ; [106.62713623,10.78934002] ; [106.62621307,10.78944016] ; [106.62525177,10.78960037] ; [106.62439728,10.78973007] ; [106.62400055,10.78979015]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2666"
    ,"Station_Code":"QTP 165"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trường GTVT"
    ,"Station_Address":"380, đường Văn Cao, Quận Tân Phú"
    ,"Lat":10.786402
    ,"Long":106.622055
    ,"Polyline":"[106.62400055,10.78979015] ; [106.62316895,10.78989029] ; [106.62307739,10.78948021] ; [106.62290955,10.78896999] ; [106.62264252,10.78812027] ; [106.62242889,10.78752041] ; [106.62207031,10.78639984]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1735"
    ,"Station_Code":"QTP 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Cây Xăng Bình Long"
    ,"Station_Address":"B10, đường Văn Cao, Quận Tân Phú"
    ,"Lat":10.782247
    ,"Long":106.620552
    ,"Polyline":"[106.62205505,10.78640175] ; [106.62207031,10.78639984] ; [106.62159729,10.78493023] ; [106.62142181,10.78450012] ; [106.62127686,10.78398037] ; [106.62107086,10.78332043] ; [106.62055206,10.78224659]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1566"
    ,"Station_Code":"QBT 211"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"660 (99), đường Bình Long, Quận Bình Tân"
    ,"Lat":10.779475
    ,"Long":106.620555
    ,"Polyline":"[106.62055206,10.78224659] ; [106.62055206,10.78224659] ; [106.62062073,10.78150940] ; [106.62043762,10.78081322] ; [106.62027740,10.78037071] ; [106.62030792,10.77986526] ; [106.62000275,10.77939320]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1562"
    ,"Station_Code":"QBT 212"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chùa Như Thị Thất"
    ,"Station_Address":"25, đường Bình Long, Quận Bình Tân"
    ,"Lat":10.775928
    ,"Long":106.621424
    ,"Polyline":"[106.62000275,10.77939320] ; [106.62062073,10.77881050] ; [106.62088776,10.77826023] ; [106.62117004,10.77731991] ; [106.62127686,10.77694988] ; [106.62112427,10.77592087]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1734"
    ,"Station_Code":"QBT 251"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Siêu th ị"
    ,"Station_Address":"42, đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.774648
    ,"Long":106.618549
    ,"Polyline":"[106.62112427,10.77592087] ; [106.62151337,10.77512169] ; [106.62156677,10.77381039] ; [106.62133789,10.77367973] ; [106.62094116,10.77383041] ; [106.62016296,10.77408028] ; [106.61939240,10.77433968] ; [106.61863708,10.77482700]"
    ,"Distance":"597"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1736"
    ,"Station_Code":"QBT 252"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"BV Đa khoa Bình Tân"
    ,"Station_Address":"194, đường Lê Văn Qưới, Quận  Bình Tân"
    ,"Lat":10.775918
    ,"Long":106.613774
    ,"Polyline":"[106.61863708,10.77482700] ; [106.61757660,10.77490044] ; [106.61637115,10.77530956] ; [106.61582184,10.77544022] ; [106.61543274,10.77550030] ; [106.61508942,10.77550030] ; [106.61461639,10.77550983] ; [106.61434174,10.77558041] ; [106.61380005,10.77601814]"
    ,"Distance":"558"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1738"
    ,"Station_Code":"QBT 253"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Lê Văn Quới"
    ,"Station_Address":"284, đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.776387
    ,"Long":106.609762
    ,"Polyline":"[106.61380005,10.77601814] ; [106.61329651,10.77608013] ; [106.61313629,10.77610016] ; [106.61235046,10.77616024] ; [106.61177826,10.77618980] ; [106.60980225,10.77654457]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1737"
    ,"Station_Code":"QBT 254"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm xăng"
    ,"Station_Address":"442, đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.776455
    ,"Long":106.605561
    ,"Polyline":"[106.60980225,10.77654457] ; [106.60894775,10.77643967] ; [106.60800934,10.77640820] ; [106.60685730,10.77645016] ; [106.60619354,10.77652931] ; [106.60553741,10.77660847]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1740"
    ,"Station_Code":"QBT 255"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Mã Lò"
    ,"Station_Address":"444, đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.776455
    ,"Long":106.603584
    ,"Polyline":"[106.60553741,10.77660847] ; [106.60511017,10.77642918] ; [106.60435486,10.77641296] ; [106.60358429,10.77645493]"
    ,"Distance":"218"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2011"
    ,"Station_Code":"QBT 260"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã 3 Ao Đôi"
    ,"Station_Address":"339, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.775607
    ,"Long":106.600991
    ,"Polyline":"[106.60358429,10.77645493] ; [106.60307312,10.77642918] ; [106.60255432,10.77642345] ; [106.60192871,10.77640820] ; [106.60126495,10.77639771] ; [106.60086060,10.77631283] ; [106.60082245,10.77577591] ; [106.60073090,10.77528000]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2010"
    ,"Station_Code":"QBT 261"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Công ty Đại Càng Phát"
    ,"Station_Address":"239, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.77235
    ,"Long":106.601849
    ,"Polyline":"[106.60073090,10.77528000] ; [106.60123444,10.77468967] ; [106.60151672,10.77400970] ; [106.60167694,10.77348042] ; [106.60166168,10.77288723] ; [106.60158539,10.77230835]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2013"
    ,"Station_Code":"QBT 262"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Phòng tiếp dân"
    ,"Station_Address":"201, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.768224
    ,"Long":106.60311
    ,"Polyline":"[106.60158539,10.77230835] ; [106.60195160,10.77167988] ; [106.60231781,10.77105045] ; [106.60285950,10.76898003] ; [106.60298157,10.76839733] ; [106.60295105,10.76788139]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2929"
    ,"Station_Code":"QBT 263"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Bệnh vi ện Bình Tân"
    ,"Station_Address":"Bệnh viện BT, đường Mã Lò, Quận Bình T ân"
    ,"Lat":10.763949
    ,"Long":106.603798
    ,"Polyline":"[106.60295105,10.76788139] ; [106.60357666,10.76700974] ; [106.60372925,10.76603031] ; [106.60386658,10.76529026] ; [106.60379791,10.76394939]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2928"
    ,"Station_Code":"QBT 264"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Công ty Hương Sở"
    ,"Station_Address":"79, đường Mã Lò, Quận Bình  Tân"
    ,"Lat":10.761125
    ,"Long":106.604934
    ,"Polyline":"[106.60379791,10.76394939] ; [106.60420227,10.76352787] ; [106.60446930,10.76299953] ; [106.60465240,10.76237011] ; [106.60482025,10.76167965] ; [106.60482788,10.76132488] ; [106.60465240,10.76100922]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2930"
    ,"Station_Code":"QBT 273"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Bà Hom"
    ,"Station_Address":"9-11, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.758957
    ,"Long":106.606194
    ,"Polyline":"[106.60465240,10.76100922] ; [106.60529327,10.76008987] ; [106.60543060,10.75981998] ; [106.60553741,10.75965977] ; [106.60605621,10.75914955] ; [106.60619354,10.75895691]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2933"
    ,"Station_Code":"QBT 269"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Đường 32"
    ,"Station_Address":"297, đường Tên L ửa, Quận Bình Tân"
    ,"Lat":10.75498
    ,"Long":106.6079
    ,"Polyline":"[106.60619354,10.75895691] ; [106.60605621,10.75914955] ; [106.60658264,10.75864029] ; [106.60682678,10.75831985] ; [106.60701752,10.75813007] ; [106.60688019,10.75809956] ; [106.60658264,10.75798035] ; [106.60630798,10.75778008] ; [106.60617828,10.75763035] ; [106.60611725,10.75726223] ; [106.60610962,10.75632954] ; [106.60607147,10.75541019] ; [106.60611725,10.75487041] ; [106.60643768,10.75485992] ; [106.60689545,10.75487995] ; [106.60734558,10.75494289] ; [106.60792542,10.75476933]"
    ,"Distance":"800"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2932"
    ,"Station_Code":"QBT 101"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Đường số 7"
    ,"Station_Address":"397, đường Tên L ửa, Quận Bình Tân"
    ,"Lat":10.753515
    ,"Long":106.609459
    ,"Polyline":"[106.60792542,10.75476933] ; [106.60841370,10.75510693] ; [106.60871887,10.75513268] ; [106.60884857,10.75471020] ; [106.60903168,10.75421047] ; [106.60918427,10.75380516] ; [106.60945892,10.75351524]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2934"
    ,"Station_Code":"QBT 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Địa ốc Phước Lộc"
    ,"Station_Address":"149, đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.748993
    ,"Long":106.611468
    ,"Polyline":"[106.60945892,10.75351524] ; [106.61033630,10.75203037] ; [106.61096191,10.75034046] ; [106.61122131,10.74962521] ; [106.61102295,10.74889278]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2389"
    ,"Station_Code":"QBT 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Đỗ Năng Tế"
    ,"Station_Address":"Đối diện 32, đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.744081
    ,"Long":106.613249
    ,"Polyline":"[106.61102295,10.74889278] ; [106.61190796,10.74785519] ; [106.61267853,10.74572563] ; [106.61299896,10.74485111] ; [106.61317444,10.74442387] ; [106.61293793,10.74397087]"
    ,"Distance":"614"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2391"
    ,"Station_Code":"QBT 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Kinh Dương Vương"
    ,"Station_Address":"Đối diện 14,  đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.741424
    ,"Long":106.614227
    ,"Polyline":"[106.61293793,10.74397087] ; [106.61347198,10.74352264] ; [106.61370087,10.74297428] ; [106.61397552,10.74224663] ; [106.61421967,10.74147034] ; [106.61422729,10.74142361]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"713"
    ,"Station_Code":"QBT 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"Bệnh viện Triều An, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739665
    ,"Long":106.61687
    ,"Polyline":"[106.61422729,10.74142361] ; [106.61439514,10.74100304] ; [106.61450195,10.74061966] ; [106.61461639,10.73997021] ; [106.61475372,10.73880005] ; [106.61496735,10.73844147] ; [106.61489868,10.73801994] ; [106.61433411,10.73715591] ; [106.61404419,10.73660755] ; [106.61397552,10.73638630] ; [106.61410522,10.73635483] ; [106.61450195,10.73697662] ; [106.61478424,10.73743534] ; [106.61502075,10.73783588] ; [106.61528015,10.73820972] ; [106.61557770,10.73862648] ; [106.61585236,10.73882103] ; [106.61611938,10.73912716] ; [106.61650848,10.73945904] ; [106.61683655,10.73980045] ; [106.61680603,10.73975658]"
    ,"Distance":"1112"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Qu ận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61683655,10.73980045] ; [106.61834717,10.74106979] ; [106.61846161,10.74116039]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"630"
    ,"Station_Code":"QBT 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bệnh viện Triều An"
    ,"Station_Address":"480 , đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.739675
    ,"Long":106.616392
    ,"Polyline":"[106.61846161,10.74116039] ; [106.61834717,10.74106979] ; [106.61823273,10.74118996] ; [106.61666107,10.73987961] ; [106.61640930,10.73966026]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2306"
    ,"Station_Code":"QBT 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Đỗ Năng  Tế"
    ,"Station_Address":"14, đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.741721
    ,"Long":106.614235
    ,"Polyline":"[106.61643219,10.73968792] ; [106.61590576,10.73921108] ; [106.61526489,10.73850536] ; [106.61504364,10.73835754] ; [106.61486816,10.73855782] ; [106.61464691,10.74007607] ; [106.61460114,10.74050808] ; [106.61423492,10.74172115]"
    ,"Distance":"602"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2307"
    ,"Station_Code":"QBT 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Địa ốc Phước Lộc"
    ,"Station_Address":"190, đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.748498
    ,"Long":106.611779
    ,"Polyline":"[106.61425018,10.74166012] ; [106.61396790,10.74234962] ; [106.61345673,10.74378014] ; [106.61273193,10.74575043] ; [106.61176300,10.74847031]"
    ,"Distance":"805"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2902"
    ,"Station_Code":"QBT 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Đường số 7"
    ,"Station_Address":"390 , đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.754147
    ,"Long":106.609687
    ,"Polyline":"[106.61176300,10.74847031] ; [106.61135864,10.74960995] ; [106.61118317,10.75004959] ; [106.61054993,10.75181961] ; [106.60971832,10.75409985]"
    ,"Distance":"665"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2904"
    ,"Station_Code":"QBT 270"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Đường 32"
    ,"Station_Address":"652, đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.755133
    ,"Long":106.608292
    ,"Polyline":"[106.60971832,10.75409985] ; [106.60935211,10.75514030] ; [106.60926056,10.75522995] ; [106.60891724,10.75516987] ; [106.60832214,10.75508022]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2907"
    ,"Station_Code":"QBT 271"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Quán cơm"
    ,"Station_Address":"706 , đường Tên Lửa, Quận Bình Tân"
    ,"Lat":10.755802
    ,"Long":106.606141
    ,"Polyline":"[106.60832214,10.75508022] ; [106.60643768,10.75485992] ; [106.60611725,10.75487041] ; [106.60607147,10.75541019] ; [106.60604858,10.75578976]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2906"
    ,"Station_Code":"QBT 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Lê Đình C ẩn"
    ,"Station_Address":"831, đường Bà Hom, Quận Bình Tân"
    ,"Lat":10.75781
    ,"Long":106.60643
    ,"Polyline":"[106.60604858,10.75578976] ; [106.60598755,10.75699043] ; [106.60597992,10.75712013] ; [106.60592651,10.75720978] ; [106.60626984,10.75772953]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2909"
    ,"Station_Code":"QBT 272"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Mã Lò"
    ,"Station_Address":"42-44, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.758862
    ,"Long":106.606407
    ,"Polyline":"[106.60626984,10.75772953] ; [106.60643005,10.75788021] ; [106.60669708,10.75804043] ; [106.60701752,10.75813007] ; [106.60674286,10.75842953] ; [106.60648346,10.75874043]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2908"
    ,"Station_Code":"QBT 266"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công ty  Hương Sở"
    ,"Station_Address":"Đ/d Công ty Hương  Sở, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.761009
    ,"Long":106.605309
    ,"Polyline":"[106.60648346,10.75874043] ; [106.60581970,10.75938988] ; [106.60547638,10.75973988] ; [106.60536194,10.75994968] ; [106.60517120,10.76043034] ; [106.60501862,10.76093960]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2910"
    ,"Station_Code":"QBT 268"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Bệnh viện  Bình Tân"
    ,"Station_Address":"104, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.76356
    ,"Long":106.60437
    ,"Polyline":"[106.60501862,10.76093960] ; [106.60469055,10.76224041] ; [106.60440063,10.76325035] ; [106.60433197,10.76358032]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1963"
    ,"Station_Code":"QBT 267"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Phòng tiếp dân"
    ,"Station_Address":"156 VP tiếp Dân, đường Mã Lò, Quận Bình Tân"
    ,"Lat":10.768097
    ,"Long":106.603239
    ,"Polyline":"[106.60433197,10.76358032] ; [106.60404968,10.76461029] ; [106.60386658,10.76529026] ; [106.60372925,10.76603031] ; [106.60357666,10.76700974] ; [106.60340118,10.76768017] ; [106.60321808,10.76813984]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1966"
    ,"Station_Code":"QBT 265"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Công ty Đại Càng Phát"
    ,"Station_Address":"290, đường Mã Lò, Quận Bình  Tân"
    ,"Lat":10.771929
    ,"Long":106.602053
    ,"Polyline":"[106.60321808,10.76813984] ; [106.60308075,10.76836967] ; [106.60285950,10.76898003] ; [106.60215759,10.77165985] ; [106.60209656,10.77186012]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1968"
    ,"Station_Code":"QBT 243"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 3 Áo Đôi"
    ,"Station_Address":"330, đường Mã Lò, Quận Bình  Tân"
    ,"Lat":10.774817
    ,"Long":106.601547
    ,"Polyline":"[106.60209656,10.77186012] ; [106.60167694,10.77348042] ; [106.60131836,10.77476025]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1806"
    ,"Station_Code":"QBT 259"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã 3 Lê Văn Quới"
    ,"Station_Address":"527, đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.776366
    ,"Long":106.602804
    ,"Polyline":"[106.60131836,10.77476025] ; [106.60095215,10.77610016] ; [106.60086060,10.77641010.06.60182190] ; [10.77639961,106.60276794]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1807"
    ,"Station_Code":"QBT 258"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Nhà thuốc Thiên Ân"
    ,"Station_Address":"371 , đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.776408
    ,"Long":106.606007
    ,"Polyline":"[106.60276794,10.77637959] ; [106.60598755,10.77628040]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1812"
    ,"Station_Code":"QBT 257"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Lê  Văn Quới"
    ,"Station_Address":"307-309, đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.776329
    ,"Long":106.609397
    ,"Polyline":"[106.60598755,10.77628040] ; [106.60709381,10.77626991] ; [106.60904694,10.77624035] ; [106.60939026,10.77624035]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1809"
    ,"Station_Code":"QBT 256"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Đa khoa Bình Tân"
    ,"Station_Address":"197, đường Lê Văn Qưới, Qu ận Bình Tân"
    ,"Lat":10.776071
    ,"Long":106.613211
    ,"Polyline":"[106.60939026,10.77624035] ; [106.61134338,10.77622032] ; [106.61196136,10.77618027] ; [106.61319733,10.77610016]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1814"
    ,"Station_Code":"QBT 238"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Siêu thị"
    ,"Station_Address":"Đ/d 42, đường Lê Văn Qưới, Quận Bình Tân"
    ,"Lat":10.774153
    ,"Long":106.619164
    ,"Polyline":"[106.61329651,10.77608013] ; [106.61366272,10.77593994] ; [106.61402130,10.77571011] ; [106.61434174,10.77558041] ; [106.61461639,10.77550983] ; [106.61508942,10.77550030] ; [106.61543274,10.77550030] ; [106.61582184,10.77544022] ; [106.61637115,10.77530956] ; [106.61757660,10.77490044] ; [106.61849213,10.77460957] ; [106.61923981,10.77437973]"
    ,"Distance":"682"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1609"
    ,"Station_Code":"QTP 182"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Bình Long"
    ,"Station_Address":"54 (445), đường Bình Long, Quận Tân Phú"
    ,"Lat":10.776197
    ,"Long":106.621689
    ,"Polyline":"[106.61923981,10.77437973] ; [106.61979675,10.77418995] ; [106.62055969,10.77396965] ; [106.62133789,10.77367973] ; [106.62156677,10.77381039] ; [106.62155914,10.77390957] ; [106.62145233,10.77573967] ; [106.62143707,10.77616024]"
    ,"Distance":"533"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1623"
    ,"Station_Code":"QTP 183"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đỗ Bí"
    ,"Station_Address":"156, đường Bình Long, Quận Tân Phú"
    ,"Lat":10.780313
    ,"Long":106.6203
    ,"Polyline":"[106.62143707,10.77616024] ; [106.62138367,10.77657986] ; [106.62127686,10.77694988] ; [106.62117004,10.77731991] ; [106.62088776,10.77826023] ; [106.62042236,10.77966976] ; [106.62023163,10.78028965]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"1811"
    ,"Station_Code":"QTP 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cây Xăng Bình Long"
    ,"Station_Address":"Đối  diện 1H, đường Văn Cao, Quận Tân Phú"
    ,"Lat":10.781946
    ,"Long":106.62075
    ,"Polyline":"[106.62023163,10.78028965] ; [106.62010193,10.78073978] ; [106.62024689,10.78083992] ; [106.62039948,10.78124046] ; [106.62064362,10.78197956]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2589"
    ,"Station_Code":"QTPT186"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường  GTVT"
    ,"Station_Address":"64, đường Văn Cao, Quận Tân Phú"
    ,"Lat":10.786699295043945
    ,"Long":106.62222290039062
    ,"Polyline":"[106.62064362,10.78197956] ; [106.62100983,10.78312016] ; [106.62114716,10.78355980] ; [106.62142181,10.78450012] ; [106.62159729,10.78493023] ; [106.62174225,10.78536034] ; [106.62200928,10.78621960] ; [106.62217712,10.78670979]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2551"
    ,"Station_Code":"QTP 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà Thờ Tân Hương"
    ,"Station_Address":"141, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.789681
    ,"Long":106.624565
    ,"Polyline":"[106.62217712,10.78670979] ; [106.62248230,10.78765011] ; [106.62306213,10.78940010.06.62316895] ; [10.78989029,106.62438202] ; [10.78973007,106.62457275]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2556"
    ,"Station_Code":"QTP 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Café Su ối Reo"
    ,"Station_Address":"43, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.790343
    ,"Long":106.628273
    ,"Polyline":"[106.62457275,10.78971004] ; [106.62621307,10.78944016] ; [106.62713623,10.78934002] ; [106.62719727,10.78936958] ; [106.62783051,10.78987026] ; [106.62808228,10.79010010.06.62819672] ; [10.79022980,106.62825012]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2554"
    ,"Station_Code":"QTP 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà thờ Martino"
    ,"Station_Address":"15, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.792511
    ,"Long":106.628891
    ,"Polyline":"[106.62825012,10.79034996] ; [106.62876892,10.79224014]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2911"
    ,"Station_Code":"QTP 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Tân Sơn  Nhì"
    ,"Station_Address":"409, đường Tân Sơn Nhì, Qu ận Tân Phú"
    ,"Lat":10.793829
    ,"Long":106.628761
    ,"Polyline":"[106.62876892,10.79224014] ; [106.62895966,10.79288960] ; [106.62838745,10.79298973] ; [106.62838745,10.79308033] ; [106.62857819,10.79356956] ; [106.62872314,10.79384995]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2913"
    ,"Station_Code":"QTP 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Chung cư  Gò Dầu"
    ,"Station_Address":"38, đường Gò  Dầu, Quận Tân Phú"
    ,"Lat":10.795697
    ,"Long":106.628242
    ,"Polyline":"[106.62872314,10.79384995] ; [106.62915802,10.79456043] ; [106.62938690,10.79491043] ; [106.62921906,10.79502010.06.62879944] ; [10.79528999,106.62825012] ; [10.79563046,106.62821960]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2912"
    ,"Station_Code":"QTP 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Café Tino"
    ,"Station_Address":"122, đường Gò Dầu, Quận Tân Phú"
    ,"Lat":10.795903
    ,"Long":106.62487
    ,"Polyline":"[106.62821960,10.79564953] ; [106.62792969,10.79576969] ; [106.62737274,10.79580975] ; [106.62693024,10.79582024] ; [106.62545776,10.79586029] ; [106.62487030,10.79586983]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2918"
    ,"Station_Code":"QTP 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Lê Đình Thám"
    ,"Station_Address":"77, đường Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.796464
    ,"Long":106.623871
    ,"Polyline":"[106.62487030,10.79586983] ; [106.62380981,10.79590034] ; [106.62380981,10.79646015]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2914"
    ,"Station_Code":"QTP 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cuối Cầu Xéo"
    ,"Station_Address":"3, đường Cầu Xéo, Quận Tân Phú"
    ,"Lat":10.800497
    ,"Long":106.624283
    ,"Polyline":"[106.62380981,10.79646015] ; [106.62377930,10.79788971] ; [106.62384033,10.79883957] ; [106.62390900,10.79926014] ; [106.62400818,10.79967022] ; [106.62416077,10.80021000] ; [106.62428284,10.80053043]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2594"
    ,"Station_Code":"QTP 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm Xăng"
    ,"Station_Address":"295, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.8019
    ,"Long":106.625854
    ,"Polyline":"[106.62428284,10.80053043] ; [106.62464142,10.80144978] ; [106.62583923,10.80193996]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2596"
    ,"Station_Code":"QTP 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trạm Đường Số 27"
    ,"Station_Address":"235, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.802643
    ,"Long":106.628525
    ,"Polyline":"[106.62583923,10.80193996] ; [106.62690735,10.80237961] ; [106.62731934,10.80251980] ; [106.62777710,10.80261993] ; [106.62850189,10.80274010]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2598"
    ,"Station_Code":"QTP 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm Lê Trọng Tấn"
    ,"Station_Address":"153, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.803166
    ,"Long":106.631592
    ,"Polyline":"[106.62850189,10.80274010.06.62943268] ; [10.80294037,106.63156891]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2600"
    ,"Station_Code":"QTP 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm Đầu Lê Trọng Tấn"
    ,"Station_Address":"8A-8B, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.804282
    ,"Long":106.632187
    ,"Polyline":"[106.63156891,10.80329990] ; [106.63271332,10.80348969] ; [106.63284302,10.80352974] ; [106.63217926,10.80428028]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2602"
    ,"Station_Code":"QTP 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường Cao Đẳng Công Nghệ Thực Phẩm"
    ,"Station_Address":"142-144, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806065
    ,"Long":106.628586
    ,"Polyline":"[106.63217926,10.80428028] ; [106.63198853,10.80451965] ; [106.63153839,10.80500031] ; [106.63112640,10.80535030] ; [106.63104248,10.80539989] ; [106.63078308,10.80554008] ; [106.63056946,10.80560970] ; [106.63009644,10.80572987] ; [106.62859344,10.80607986]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2000"
    ,"Station_Code":"QTP 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"188, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806785
    ,"Long":106.625366
    ,"Polyline":"[106.62859344,10.80607986] ; [106.62544250,10.80675983]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2005"
    ,"Station_Code":"QTP 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm B ờ Bao Tân Thắng"
    ,"Station_Address":"284, đư ờng Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.807464
    ,"Long":106.622177
    ,"Polyline":"[106.62544250,10.80675983] ; [106.62190247,10.80751038]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2917"
    ,"Station_Code":"QTP 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm Tây Th ạnh"
    ,"Station_Address":"386, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.808257
    ,"Long":106.619133
    ,"Polyline":"[106.62190247,10.80751038] ; [106.62016296,10.80788994] ; [106.61910248,10.80815029]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2915"
    ,"Station_Code":"QTP 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm Đ ầu Tây Thạnh"
    ,"Station_Address":"389, đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.809416
    ,"Long":106.619644
    ,"Polyline":"[106.61910248,10.80815029] ; [106.61826324,10.80842018] ; [106.61940765,10.80963039]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2919"
    ,"Station_Code":"QTP 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm Tr ường Tiểu Học Lê Lai"
    ,"Station_Address":"237 , đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.812798
    ,"Long":106.622345
    ,"Polyline":"[106.61940765,10.80963039] ; [106.62238312,10.81285000]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2457"
    ,"Station_Code":"QTP 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Công  Ty Ngọc Nghĩa"
    ,"Station_Address":"Đối diện công ty Ngọc Nghĩa, đường Tây  Thạnh, Quận Tân Phú"
    ,"Lat":10.815767
    ,"Long":106.625061
    ,"Polyline":"[106.62238312,10.81285000] ; [106.62312317,10.81369972] ; [106.62432861,10.81511021] ; [106.62474823,10.81554985] ; [106.62502289,10.81581020]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"2916"
    ,"Station_Code":"QTP 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm Cổng KCN Tân Bình"
    ,"Station_Address":"29/26 (Công ty Thành Công), đường Tây Thạnh, Quận Tân Phú"
    ,"Lat":10.818994
    ,"Long":106.628616
    ,"Polyline":"[106.62502289,10.81581020] ; [106.62677765,10.81744957] ; [106.62828827,10.81877995] ; [106.62859344,10.81902981]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.62859344,10.81902981] ; [106.62944031,10.81964970] ; [106.63059998,10.82044029] ; [106.63073730,10.82050037] ; [106.63041687,10.82151985] ; [106.63038635,10.82162952]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63044739,10.82164383] ; [106.62984467,10.82299995] ; [106.62889862,10.82407475] ; [106.62714386,10.82559204] ; [106.62597656,10.82664108]"
    ,"Distance":"752"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"273"
    ,"Station_Code":"Q12 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"189/4, đường  Trường Chinh, Quận 12"
    ,"Lat":10.828843
    ,"Long":106.624482
    ,"Polyline":"[106.62595367,10.82662010.06.62528229] ; [10.82740974,106.62447357] ; [10.82857037,106.62435913]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"274"
    ,"Station_Code":"Q12 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"258, đường Trường Chinh, Quận 12"
    ,"Lat":10.832547
    ,"Long":106.622116
    ,"Polyline":"[106.62435913,10.82874012] ; [106.62193298,10.83242035]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"275"
    ,"Station_Code":"Q12 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Chùa Lạc Quang"
    ,"Station_Address":"408, đường Trường Chinh, Quận 12"
    ,"Lat":10.83514
    ,"Long":106.620464
    ,"Polyline":"[106.62193298,10.83242035] ; [106.62024689,10.83504009]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"277"
    ,"Station_Code":"Q12 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"640, đường Trường Chinh, Quận 12"
    ,"Lat":10.83819
    ,"Long":106.618495
    ,"Polyline":"[106.62024689,10.83504009] ; [106.61829376,10.83808041]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"276"
    ,"Station_Code":"Q12 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Chợ Chi ều"
    ,"Station_Address":"774A, đường Trường Chinh , Quận 12"
    ,"Lat":10.841436
    ,"Long":106.616457
    ,"Polyline":"[106.61829376,10.83808041] ; [106.61621094,10.84130955]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"62"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61625671,10.84133816] ; [106.61573792,10.84223080] ; [106.61557770,10.84283161] ; [106.61521912,10.84308434] ; [106.61480713,10.84362221] ; [106.61444092,10.84429646] ; [106.61391449,10.84509754] ; [106.61334229,10.84601402] ; [106.61290741,10.84669876] ; [106.61270142,10.84660435] ; [106.61315155,10.84584522] ; [106.61381531,10.84479141] ; [106.61394501,10.84432793] ; [106.61337280,10.84373760]"
    ,"Distance":"1112"
  }]