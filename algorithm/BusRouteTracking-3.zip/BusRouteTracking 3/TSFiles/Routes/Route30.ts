export const Route30 =[

  {
     "Route_Id":"30"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguyễn Ảnh Thủ, Quận  12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1618"
    ,"Station_Code":"Q12 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"Trường Mau giáo Họa Mi 2, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877224
    ,"Long":106.641283
    ,"Polyline":"[106.64203644,10.87744999] ; [106.64183044,10.87710285] ; [106.64153290,10.87715530] ; [106.64128113,10.87722397]"
    ,"Distance":"106"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1620"
    ,"Station_Code":"Q12 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"NVH Lao động Quận 12"
    ,"Station_Address":"NVH Lao động Q.12, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.879062
    ,"Long":106.637265
    ,"Polyline":"[106.64128113,10.87722397] ; [106.64042664,10.87735558] ; [106.64015961,10.87746620] ; [106.63923645,10.87792397] ; [106.63778687,10.87874031] ; [106.63739014,10.87898350] ; [106.63726807,10.87906170]"
    ,"Distance":"489"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1622"
    ,"Station_Code":"Q12 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Thiệp Cưới"
    ,"Station_Address":"442 , đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.880495
    ,"Long":106.634685
    ,"Polyline":"[106.63726807,10.87906170] ; [106.63711548,10.87914658] ; [106.63560486,10.87997913] ; [106.63494110,10.88034248] ; [106.63468170,10.88049507]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1624"
    ,"Station_Code":"Q12T185"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Hiệp Thành  43"
    ,"Station_Address":"466A, đường Nguyễn  Ảnh Thủ, Quận 12"
    ,"Lat":10.881254196166992
    ,"Long":106.6331558227539
    ,"Polyline":"[106.63468170,10.88049507] ; [106.63315582,10.88125420]"
    ,"Distance":"187"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1625"
    ,"Station_Code":"Q12 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Đông  Quang"
    ,"Station_Address":"544, đường Nguyễn  Ảnh Thủ, Quận 12"
    ,"Lat":10.882718
    ,"Long":106.630688
    ,"Polyline":"[106.63315582,10.88125420] ; [106.63080597,10.88262844]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1627"
    ,"Station_Code":"Q12 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường mầm non Hiệp Thành"
    ,"Station_Address":"38/4C, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.881665
    ,"Long":106.628135
    ,"Polyline":"[106.63080597,10.88262844] ; [106.62940216,10.88335037] ; [106.62899017,10.88291836] ; [106.62834167,10.88185024] ; [106.62816620,10.88161945]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1629"
    ,"Station_Code":"Q12T186"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Nhà văn hóa lao động Quận 12"
    ,"Station_Address":"Nhà văn hóa lao động Quận 12, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877846717834473
    ,"Long":106.62539672851562
    ,"Polyline":"[106.62816620,10.88161945] ; [106.62539673,10.87784672]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1630"
    ,"Station_Code":"Q12T187"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường Họa Mi 2"
    ,"Station_Address":"Trường Họa Mi 2, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.875764846801758
    ,"Long":106.6235580444336
    ,"Polyline":"[106.62539673,10.87784672] ; [106.62355804,10.87576485]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1628"
    ,"Station_Code":"QHMT111"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Hiệp Thành"
    ,"Station_Address":"50, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.875144004821777
    ,"Long":106.62274169921875
    ,"Polyline":"[106.62355804,10.87576485] ; [106.62274170,10.87514400]"
    ,"Distance":"113"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1631"
    ,"Station_Code":"QHMT112"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"KCN Tân Thới Hiệp"
    ,"Station_Address":"100, đường Nguyễn Ánh Thủ, Huyện Hóc M ôn"
    ,"Lat":10.873188972473145
    ,"Long":106.62090301513672
    ,"Polyline":"[106.62290192,10.87500954] ; [106.62155151,10.87353039] ; [106.62110901,10.87302017]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1632"
    ,"Station_Code":"QHMT113"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cây xăng Hiệp Thành"
    ,"Station_Address":"138, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.871397018432617
    ,"Long":106.61931610107422
    ,"Polyline":"[106.62110901,10.87302017] ; [106.62066650,10.87250042] ; [106.62014771,10.87195969] ; [106.61962891,10.87139034] ; [106.61946106,10.87123966]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1633"
    ,"Station_Code":"QHMT114"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 3 Đông Quang"
    ,"Station_Address":"180, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.86983585357666
    ,"Long":106.61798858642578
    ,"Polyline":"[106.61946106,10.87123966] ; [106.61814117,10.86975956]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1635"
    ,"Station_Code":"QHMT250"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cây xăng Minh Luân"
    ,"Station_Address":"Trường Nguyễn Hữu Cầu, đường Nguy ễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.86644458770752
    ,"Long":106.61473846435547
    ,"Polyline":"[106.61798859,10.86983585] ; [106.61773682,10.86951065] ; [106.61751556,10.86929989] ; [106.61692047,10.86875248] ; [106.61545563,10.86736202] ; [106.61499023,10.86668205] ; [106.61473846,10.86644459]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1634"
    ,"Station_Code":"QHMT116"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường Nguy ễn Trãi"
    ,"Station_Address":"74/4, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.864206314086914
    ,"Long":106.61312103271484
    ,"Polyline":"[106.61482239,10.86639023] ; [106.61434937,10.86571980] ; [106.61373901,10.86493015] ; [106.61318970,10.86415958]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1636"
    ,"Station_Code":"QHMT117"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã tư Nước Đá"
    ,"Station_Address":"127/1, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.860050201416016
    ,"Long":106.61029815673828
    ,"Polyline":"[106.61312103,10.86420631] ; [106.61029816,10.86005020]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1637"
    ,"Station_Code":"QHMT118"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trường CĐ GTVT"
    ,"Station_Address":"150A/1, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.857827186584473
    ,"Long":106.60880279541016
    ,"Polyline":"[106.61029816,10.86005020] ; [106.60880280,10.85782719]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1638"
    ,"Station_Code":"QHMT119"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã tư Trung Chánh"
    ,"Station_Address":"155/4, đường Nguyễn Ánh Thủ, Huyện Hóc  Môn"
    ,"Lat":10.85592269897461
    ,"Long":106.60757446289062
    ,"Polyline":"[106.60887146,10.85778046] ; [106.60777283,10.85614014] ; [106.60762024,10.85589981]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1237"
    ,"Station_Code":"QHMT229"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Quán ăn xuyên Á, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854108810424805
    ,"Long":106.60777282714844
    ,"Polyline":"[106.60762024,10.85589981] ; [106.60726166,10.85533047] ; [106.60717773,10.85525036] ; [106.60729980,10.85505962] ; [106.60787964,10.85418034]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1238"
    ,"Station_Code":"HHM 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"3A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.850092
    ,"Long":106.610395
    ,"Polyline":"[106.60787964,10.85418034] ; [106.61047363,10.85015011]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61047363,10.85015011] ; [106.61290741,10.84638023] ; [106.61396027,10.84473038]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"171"
    ,"Station_Code":"Q12 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"601, đường Trường Chinh, Quận 12"
    ,"Lat":10.841209
    ,"Long":106.615925
    ,"Polyline":"[106.61396027,10.84473038] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61506653,10.84249973] ; [106.61517334,10.84239960] ; [106.61530304,10.84235001] ; [106.61535645,10.84234047] ; [106.61546326,10.84218979] ; [106.61605835,10.84127045]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"167"
    ,"Station_Code":"Q12 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"487, đường Trường Chinh, Quận 12"
    ,"Lat":10.837863
    ,"Long":106.618044
    ,"Polyline":"[106.61605835,10.84127045] ; [106.61820221,10.83794975]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"172"
    ,"Station_Code":"Q12 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chùa Lạc  Quang"
    ,"Station_Address":"257, đường Trường  Chinh, Quận 12"
    ,"Lat":10.834623
    ,"Long":106.620163
    ,"Polyline":"[106.61804199,10.83786297] ; [106.62016296,10.83462334]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"168"
    ,"Station_Code":"Q12 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"Chùa Vĩnh Phước, đường Trường Chinh , Quận 12"
    ,"Lat":10.831836
    ,"Long":106.621928
    ,"Polyline":"[106.62016296,10.83462334] ; [106.62192535,10.83183575]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"170"
    ,"Station_Code":"Q12 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"113, đường Trường Chinh, Quận 12"
    ,"Lat":10.82898
    ,"Long":106.623768
    ,"Polyline":"[106.62192535,10.83183575] ; [106.62377167,10.82898045]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đường Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62377167,10.82898045] ; [106.62404633,10.82859039] ; [106.62473297,10.82750988] ; [106.62505341,10.82711506] ; [106.62544250,10.82665157] ; [106.62574005,10.82633495] ; [106.62586212,10.82623959]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62586212,10.82623959] ; [106.62608337,10.82595062] ; [106.62696075,10.82513905] ; [106.62803650,10.82422256] ; [106.62937164,10.82299995] ; [106.62969208,10.82263088] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974] ; [106.63005066,10.82213020]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm KCN  Tân Bình"
    ,"Station_Address":"881, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63089752,10.81947041]"
    ,"Distance":"346"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Chế Lan Viên"
    ,"Station_Address":"28/7B, đ ường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm Đài Li ệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"597"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"178"
    ,"Station_Code":"QTB 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680 (Thượng Uyển), đường Cộng Hòa, Qu ận Tân Bình"
    ,"Lat":10.806144
    ,"Long":106.636055
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63455963,10.80772972] ; [106.63471985,10.80747986] ; [106.63487244,10.80729961] ; [106.63501740,10.80712986] ; [106.63535309,10.80681992] ; [106.63601685,10.80624962] ; [106.63609314,10.80617046]"
    ,"Distance":"317"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"180"
    ,"Station_Code":"QTB 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"401, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.803541
    ,"Long":106.637887
    ,"Polyline":"[106.63609314,10.80617046] ; [106.63627625,10.80595016] ; [106.63709259,10.80482960] ; [106.63793182,10.80358028]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"181"
    ,"Station_Code":"QTB 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm ETown"
    ,"Station_Address":"364  (công ty Ree), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802371
    ,"Long":106.640253
    ,"Polyline":"[106.63793182,10.80358028] ; [106.63818359,10.80319977] ; [106.63858032,10.80292034] ; [106.63897705,10.80270004] ; [106.63944244,10.80257034] ; [106.63977814,10.80249023] ; [106.64025116,10.80243969]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"179"
    ,"Station_Code":"QTB 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã ba B ình Giã"
    ,"Station_Address":"303, đường Cộng  Hòa, Quận Tân Bình"
    ,"Lat":10.802055
    ,"Long":106.644292
    ,"Polyline":"[106.64025116,10.80243969] ; [106.64430237,10.80212021]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"183"
    ,"Station_Code":"QTB 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"19A (Công ty Lô H ội), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801544
    ,"Long":106.650413
    ,"Polyline":"[106.64430237,10.80212021] ; [106.64871979,10.80173969] ; [106.65028381,10.80160999]"
    ,"Distance":"680"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"182"
    ,"Station_Code":"QTB 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Pico Plaza"
    ,"Station_Address":"20Bis, đường Cộng Hòa, Qu ận Tân Bình"
    ,"Lat":10.801254
    ,"Long":106.653637
    ,"Polyline":"[106.65028381,10.80160999] ; [106.65370941,10.80130959]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"185"
    ,"Station_Code":"QTB 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm Út tịch"
    ,"Station_Address":"35-37, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.800985
    ,"Long":106.656679
    ,"Polyline":"[106.65370941,10.80130959] ; [106.65663147,10.80105019]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"184"
    ,"Station_Code":"QTB 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"Đối diện 58 (Siêu thị Maximart), đường Cộng Hòa, Qu ận Tân Bình"
    ,"Lat":10.800833
    ,"Long":106.658819
    ,"Polyline":"[106.65667725,10.80098534] ; [106.65663147,10.80105019] ; [106.65782928,10.80095959] ; [106.65878296,10.80086040] ; [106.65888214,10.80080032] ; [106.65875244,10.80086422] ; [106.65882111,10.80083275]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"600"
    ,"Station_Code":"QTB 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"216, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.799836
    ,"Long":106.660385
    ,"Polyline":"[106.65921783,10.80078030] ; [106.65979004,10.80074024] ; [106.66069031,10.80064011] ; [106.66075897,10.80056953] ; [106.66078186,10.80051041] ; [106.66087341,10.80027008] ; [106.66062164,10.80000973] ; [106.66039276,10.79981041]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"602"
    ,"Station_Code":"QTB 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Công an  Quận Tân Bình"
    ,"Station_Address":"340H, đường Ho àng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.796577
    ,"Long":106.656952
    ,"Polyline":"[106.66039276,10.79981041] ; [106.65973663,10.79918003] ; [106.65936279,10.79883003] ; [106.65850067,10.79796982] ; [106.65830231,10.79776001] ; [106.65699005,10.79652977]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đư ờng Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65699005,10.79652977] ; [106.65577698,10.79539013] ; [106.65515900,10.79603958]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62),  đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65515900,10.79603958] ; [106.65464783,10.79654980] ; [106.65390778,10.79584026]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Cây xăng d ầu"
    ,"Station_Address":"23, đường Xuân Hồng,  Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65390778,10.79584026] ; [106.65238190,10.79434013]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"605"
    ,"Station_Code":"QTB 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"733-739, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.792122
    ,"Long":106.6528
    ,"Polyline":"[106.65238190,10.79434013] ; [106.65184021,10.79384041] ; [106.65178680,10.79374027] ; [106.65213776,10.79354954] ; [106.65300751,10.79310989] ; [106.65337372,10.79290962] ; [106.65318298,10.79253006] ; [106.65293884,10.79205990]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1639"
    ,"Station_Code":"QTB 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Cây xăng Lạc Long Quân"
    ,"Station_Address":"1103, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.788628
    ,"Long":106.651776
    ,"Polyline":"[106.65293884,10.79205990] ; [106.65270996,10.79156017] ; [106.65261841,10.79131985] ; [106.65251160,10.79090977] ; [106.65235901,10.79039955] ; [106.65210724,10.78944016] ; [106.65187836,10.78859997]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1640"
    ,"Station_Code":"QTB 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Trạm Công Thọ"
    ,"Station_Address":"933, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.784233
    ,"Long":106.650848
    ,"Polyline":"[106.65187836,10.78859997] ; [106.65154266,10.78748989] ; [106.65138245,10.78684998] ; [106.65119171,10.78602982] ; [106.65109253,10.78551960] ; [106.65106201,10.78516006] ; [106.65094757,10.78433037] ; [106.65093231,10.78421974]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1641"
    ,"Station_Code":"QTB 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Ni sư Huỳnh Liên"
    ,"Station_Address":"759, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.781511
    ,"Long":106.649994
    ,"Polyline":"[106.65093231,10.78421974] ; [106.65081024,10.78365040] ; [106.65071869,10.78339958] ; [106.65065002,10.78318977] ; [106.65057373,10.78291035] ; [106.65048218,10.78273010.06.65035248] ; [10.78244019,106.65020752] ; [10.78223038,106.65010071] ; [10.78190994,106.65007019]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1642"
    ,"Station_Code":"QTB 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Chùa Giác Lâm"
    ,"Station_Address":"656 (133), đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.777941
    ,"Long":106.649786
    ,"Polyline":"[106.65007019,10.78151035] ; [106.64997864,10.78063965] ; [106.64990997,10.78013039] ; [106.64987946,10.77950954] ; [106.64984131,10.77805996]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1643"
    ,"Station_Code":"QTB 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Ngã tư Lạc Long Quân"
    ,"Station_Address":"523-525 (176A), đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.77547
    ,"Long":106.648396
    ,"Polyline":"[106.64984131,10.77805996] ; [106.64983368,10.77762985] ; [106.64980316,10.77731991] ; [106.64974213,10.77709007] ; [106.64961243,10.77686024] ; [106.64930725,10.77653980] ; [106.64855957,10.77550983]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1644"
    ,"Station_Code":"Q11 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"501, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.774116
    ,"Long":106.647484
    ,"Polyline":"[106.64855957,10.77550983] ; [106.64813995,10.77493954] ; [106.64803314,10.77474022] ; [106.64761353,10.77416992]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1646"
    ,"Station_Code":"Q11 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Trạm Đăng Kiểm"
    ,"Station_Address":"345F, đường Lạc Long  Quân, Quận 11"
    ,"Lat":10.770237
    ,"Long":106.644716
    ,"Polyline":"[106.64761353,10.77416992] ; [106.64675903,10.77299976] ; [106.64611816,10.77210045] ; [106.64479065,10.77023029]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1645"
    ,"Station_Code":"Q11 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"Trường Lạc Long Quân, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.767818
    ,"Long":106.642989
    ,"Polyline":"[106.64476013,10.77019024] ; [106.64450836,10.76980019] ; [106.64414978,10.76933002] ; [106.64360809,10.76856995] ; [106.64308167,10.76778984]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1572"
    ,"Station_Code":"Q11 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Cổng 1 Đầm Sen"
    ,"Station_Address":"281, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.765199
    ,"Long":106.642128
    ,"Polyline":"[106.64299011,10.76781845] ; [106.64289093,10.76766491] ; [106.64243317,10.76702785] ; [106.64232635,10.76694012] ; [106.64227295,10.76692009] ; [106.64222717,10.76686001] ; [106.64221954,10.76677036] ; [106.64225769,10.76669025] ; [106.64223480,10.76657963] ; [106.64219666,10.76641655] ; [106.64218903,10.76598930] ; [106.64218140,10.76553631] ; [106.64218140,10.76537228] ; [106.64212799,10.76519871]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1776"
    ,"Station_Code":"Q11 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"công an P10"
    ,"Station_Address":"569 (596), đường Minh Phụng, Quận 11"
    ,"Lat":10.763649
    ,"Long":106.644706
    ,"Polyline":"[106.64212799,10.76519871] ; [106.64212799,10.76519871] ; [106.64212799,10.76519871] ; [106.64210510,10.76281166] ; [106.64234924,10.76281643] ; [106.64337158,10.76325417] ; [106.64489746,10.76428223] ; [106.64476013,10.76361561] ; [106.64470673,10.76364899] ; [106.64470673,10.76364899]"
    ,"Distance":"700"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1777"
    ,"Station_Code":"Q11 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Đội Cung"
    ,"Station_Address":"461, đường Minh  Phụng, Quận 11"
    ,"Lat":10.761968
    ,"Long":106.644459
    ,"Polyline":"[106.64476013,10.76361561] ; [106.64448547,10.76198959]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1779"
    ,"Station_Code":"Q11 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"THCS Lê Anh Xuân"
    ,"Station_Address":"385, đường Minh Phụng, Quận 11"
    ,"Lat":10.759449
    ,"Long":106.644051
    ,"Polyline":"[106.64446259,10.76196766] ; [106.64448547,10.76198959] ; [106.64410400,10.75958061] ; [106.64405060,10.75944901]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1647"
    ,"Station_Code":"Q11 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Minh Phu ̣ng"
    ,"Station_Address":"341, đường Minh Phụng, Quận 11"
    ,"Lat":10.75736
    ,"Long":106.643654
    ,"Polyline":"[106.64405060,10.75944901] ; [106.64401245,10.75913334] ; [106.64365387,10.75735950] ; [106.64365387,10.75736046]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1649"
    ,"Station_Code":"Q11 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"275, đường Minh Phụng, Quận 11"
    ,"Lat":10.755175
    ,"Long":106.643311
    ,"Polyline":"[106.64365387,10.75736046] ; [106.64365387,10.75735950] ; [106.64331055,10.75517464]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"721"
    ,"Station_Code":"Q6 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Trường Nguy ễn Đức Cảnh"
    ,"Station_Address":"799, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754021
    ,"Long":106.644003
    ,"Polyline":"[106.64331055,10.75517464] ; [106.64330292,10.75483799] ; [106.64308929,10.75409508] ; [106.64400482,10.75402069]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"723"
    ,"Station_Code":"Q6 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Chùa Nam Phổ Đà"
    ,"Station_Address":"735, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753789
    ,"Long":106.645955
    ,"Polyline":"[106.64400482,10.75402069] ; [106.64595795,10.75378895]"
    ,"Distance":"215"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"722"
    ,"Station_Code":"Q6 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"647 , đường Hồng Bàng, Quận 6"
    ,"Lat":10.753647
    ,"Long":106.647323
    ,"Polyline":"[106.64595795,10.75378895] ; [106.64595795,10.75378895] ; [106.64595795,10.75378895] ; [106.64668274,10.75370979] ; [106.64732361,10.75364685] ; [106.64732361,10.75364685] ; [106.64732361,10.75364685]"
    ,"Distance":"151"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.64732361,10.75364685] ; [106.64732361,10.75364685] ; [106.64733124,10.75370312] ; [106.64943695,10.75352573] ; [106.65065002,10.75340939] ; [106.65111542,10.75325680] ; [106.65184784,10.75304031] ; [106.65186310,10.75237656] ; [106.65181732,10.75142765] ; [106.65164948,10.75135422] ; [106.65147400,10.75121689] ; [106.65106964,10.75118542]"
    ,"Distance":"777"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Qu ận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"620"
    ,"Station_Code":"Q11 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Cây Mai"
    ,"Station_Address":"384, đường Hồng Bàng, Quận  11"
    ,"Lat":10.753689
    ,"Long":106.64926
    ,"Polyline":"[106.65107727,10.75096035] ; [106.65048218,10.75100994] ; [106.64958191,10.75109959] ; [106.64961243,10.75158978] ; [106.64975739,10.75343990] ; [106.64978027,10.75360012] ; [106.64923859,10.75364971]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"622"
    ,"Station_Code":"Q11 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"508, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753952
    ,"Long":106.646787
    ,"Polyline":"[106.64926147,10.75368881] ; [106.64678955,10.75395203]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"624"
    ,"Station_Code":"Q11 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"638-640, đường Hồng Bàng, Quận 11"
    ,"Lat":10.754232
    ,"Long":106.644368
    ,"Polyline":"[106.64678955,10.75395203] ; [106.64437103,10.75423241]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1675"
    ,"Station_Code":"Q11 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"248-250, đư ờng Minh Phụng, Quận 11"
    ,"Lat":10.755328
    ,"Long":106.643486
    ,"Polyline":"[106.64437103,10.75423241] ; [106.64321136,10.75435257] ; [106.64348602,10.75532818]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1678"
    ,"Station_Code":"Q11 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"UBND P2, Q11"
    ,"Station_Address":"328, đường Minh Phụng, Quận 11"
    ,"Lat":10.757536
    ,"Long":106.643874
    ,"Polyline":"[106.64348602,10.75532818] ; [106.64387512,10.75753593]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1677"
    ,"Station_Code":"Q11 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"THCS Lê Anh Xuân"
    ,"Station_Address":"382, đường Minh Phụng, Quận 11"
    ,"Lat":10.759729
    ,"Long":106.64426
    ,"Polyline":"[106.64387512,10.75753593] ; [106.64425659,10.75972939]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1680"
    ,"Station_Code":"Q11 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Đội Cung"
    ,"Station_Address":"470, đường Minh  Phụng, Quận 11"
    ,"Lat":10.761849
    ,"Long":106.644592
    ,"Polyline":"[106.64420319,10.75973415] ; [106.64459229,10.76184940]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1679"
    ,"Station_Code":"Q11 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"công an P10"
    ,"Station_Address":"618, đường Minh Phụng, Quận 11"
    ,"Lat":10.763865
    ,"Long":106.644928
    ,"Polyline":"[106.64459229,10.76184940] ; [106.64492798,10.76386547]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1603"
    ,"Station_Code":"Q11 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường Phùng Hưng"
    ,"Station_Address":"240, đường L ạc Long Quân, Quận 11"
    ,"Lat":10.763818
    ,"Long":106.642259
    ,"Polyline":"[106.64492798,10.76386547] ; [106.64492798,10.76386547] ; [106.64492798,10.76386547] ; [106.64498138,10.76438713] ; [106.64363098,10.76351738] ; [106.64315796,10.76323318] ; [106.64237976,10.76290131] ; [106.64219666,10.76290131] ; [106.64223480,10.76336479] ; [106.64229584,10.76383114] ; [106.64225769,10.76381779] ; [106.64225769,10.76381779]"
    ,"Distance":"517"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1682"
    ,"Station_Code":"Q11 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"310, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.767508
    ,"Long":106.64296
    ,"Polyline":"[106.64225769,10.76381779] ; [106.64217377,10.76379204] ; [106.64228821,10.76651096] ; [106.64234161,10.76665306] ; [106.64253235,10.76673222] ; [106.64251709,10.76685333] ; [106.64247131,10.76695919] ; [106.64292145,10.76753330] ; [106.64295959,10.76750755]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1681"
    ,"Station_Code":"Q11 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm Đăng Kiểm"
    ,"Station_Address":"432, đường L ạc Long Quân, Quận 11"
    ,"Lat":10.770437
    ,"Long":106.645073
    ,"Polyline":"[106.64295959,10.76750755] ; [106.64295959,10.76750755] ; [106.64402008,10.76901913] ; [106.64507294,10.77043724] ; [106.64507294,10.77043724]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1684"
    ,"Station_Code":"Q11 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"612, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.773831
    ,"Long":106.647461
    ,"Polyline":"[106.64507294,10.77043724] ; [106.64507294,10.77043724] ; [106.64625549,10.77217102] ; [106.64746094,10.77383137] ; [106.64746094,10.77383137]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1683"
    ,"Station_Code":"QTB 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã Tư Âu Cơ"
    ,"Station_Address":"632, đường  Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.775206
    ,"Long":106.648471
    ,"Polyline":"[106.64746094,10.77383137] ; [106.64842224,10.77523232]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1686"
    ,"Station_Code":"QTB 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chùa Giác L âm"
    ,"Station_Address":"794 , đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.77821
    ,"Long":106.64992
    ,"Polyline":"[106.64846802,10.77520561] ; [106.64842224,10.77523232] ; [106.64855957,10.77548027] ; [106.64949799,10.77670288] ; [106.64982605,10.77712440] ; [106.64989471,10.77764606] ; [106.64991760,10.77820969]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1685"
    ,"Station_Code":"QTB 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ni sư Hu ỳnh Liên"
    ,"Station_Address":"930, đường Lạc  Long Quân, Quận Tân Bình"
    ,"Lat":10.781066
    ,"Long":106.650093
    ,"Polyline":"[106.64991760,10.77820969] ; [106.65009308,10.78106594]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1688"
    ,"Station_Code":"QTB 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trạm Công Thọ"
    ,"Station_Address":"1100, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.784028
    ,"Long":106.650963
    ,"Polyline":"[106.65009308,10.78106594] ; [106.65009308,10.78106594] ; [106.65013885,10.78170967] ; [106.65019226,10.78212070] ; [106.65045166,10.78257370] ; [106.65061951,10.78302670] ; [106.65096283,10.78402805] ; [106.65096283,10.78402805]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1687"
    ,"Station_Code":"QTB 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cây xăng  Lạc Long Quân"
    ,"Station_Address":"1274, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.788412
    ,"Long":106.651851
    ,"Polyline":"[106.65096283,10.78402805] ; [106.65096283,10.78402805] ; [106.65110779,10.78548241] ; [106.65139771,10.78668404] ; [106.65150452,10.78720570] ; [106.65167236,10.78771114] ; [106.65184784,10.78841209]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"553"
    ,"Station_Code":"QTB 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"B ệnh viện Thống Nhất, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.792101
    ,"Long":106.653074
    ,"Polyline":"[106.65184784,10.78841209] ; [106.65193176,10.78873920] ; [106.65210724,10.78944016] ; [106.65238190,10.78989315] ; [106.65263367,10.79014587] ; [106.65257263,10.79053593] ; [106.65271759,10.79127884] ; [106.65283203,10.79163742] ; [106.65299225,10.79202747] ; [106.65307617,10.79210091]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận  Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65304565,10.79212761] ; [106.65372467,10.79320717] ; [106.65435791,10.79393482] ; [106.65505981,10.79458714]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"555"
    ,"Station_Code":"QTB 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Nhà hàng Đông Phương"
    ,"Station_Address":"431, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.798622
    ,"Long":106.659286
    ,"Polyline":"[106.65505981,10.79458714] ; [106.65928650,10.79862213]"
    ,"Distance":"645"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"259"
    ,"Station_Code":"QTB 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Siêu thị Maximark Cộng Hòa"
    ,"Station_Address":"60, đường Cộng Hòa, Quận Tân  Bình"
    ,"Lat":10.801038
    ,"Long":106.659168
    ,"Polyline":"[106.65928650,10.79862213] ; [106.65978241,10.79920959] ; [106.66060638,10.79998970] ; [106.66085052,10.80021095] ; [106.66103363,10.80023193] ; [106.66115570,10.80032158] ; [106.66124725,10.80052185] ; [106.66120911,10.80066395] ; [106.66110992,10.80080605] ; [106.66046906,10.80091667] ; [106.65911865,10.80101967]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"260"
    ,"Station_Code":"QTB 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà hát Quân Đội"
    ,"Station_Address":"138 (Kế nhà hát Quân đội), đường Cộng Hòa, Quận Tân  Bình"
    ,"Lat":10.801238
    ,"Long":106.656754
    ,"Polyline":"[106.65911865,10.80101967] ; [106.65675354,10.80120182]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"261"
    ,"Station_Code":"QTB 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngân hàng Quân đội"
    ,"Station_Address":"Tiệc cưới Hương Sen, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801412
    ,"Long":106.654817
    ,"Polyline":"[106.65675354,10.80120182] ; [106.65480804,10.80138016]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"262"
    ,"Station_Code":"QTB 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Công ty Lô Hội"
    ,"Station_Address":"184, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801728
    ,"Long":106.651127
    ,"Polyline":"[106.65480804,10.80138016] ; [106.65112305,10.80169392]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"263"
    ,"Station_Code":"QTB 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã tư Hoàng Hoa Thám"
    ,"Station_Address":"304, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802102
    ,"Long":106.646953
    ,"Polyline":"[106.65113068,10.80172825] ; [106.65112305,10.80169392] ; [106.64903259,10.80189705] ; [106.64694214,10.80202293] ; [106.64694977,10.80210209]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"264"
    ,"Station_Code":"QTB 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã ba B ình Giã"
    ,"Station_Address":"390, đường Cộng  Hòa, Quận Tân Bình"
    ,"Lat":10.802276
    ,"Long":106.644512
    ,"Polyline":"[106.64694977,10.80210209] ; [106.64450836,10.80227566]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"265"
    ,"Station_Code":"QTB 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Lê Văn Huân"
    ,"Station_Address":"496, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802571
    ,"Long":106.640967
    ,"Polyline":"[106.64434814,10.80225754] ; [106.64096832,10.80253983]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"266"
    ,"Station_Code":"QTB 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"660 (kế 592), đường Cộng H òa, Quận Tân Bình"
    ,"Lat":10.806313
    ,"Long":106.636192
    ,"Polyline":"[106.64096832,10.80247974] ; [106.63993073,10.80255985] ; [106.63947296,10.80265045] ; [106.63915253,10.80274963] ; [106.63868713,10.80298996] ; [106.63829041,10.80329037] ; [106.63803864,10.80364037] ; [106.63768005,10.80418015] ; [106.63687897,10.80537033] ; [106.63649750,10.80589962] ; [106.63616943,10.80628014] ; [106.63616180,10.80628967]"
    ,"Distance":"736"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63617706,10.80631256] ; [106.63548279,10.80688190] ; [106.63509369,10.80729008] ; [106.63488007,10.80759811] ; [106.63467407,10.80803871]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63467407,10.80803871] ; [106.63349915,10.81169510]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63349915,10.81169510.06.63258362]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63258362,10.81463814] ; [106.63169098,10.81754112]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63169098,10.81754112] ; [106.63044739,10.82164383]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63044739,10.82164383] ; [106.63026428,10.82225227] ; [106.62996674,10.82285213] ; [106.62942505,10.82351589] ; [106.62872314,10.82418060] ; [106.62609863,10.82672977]"
    ,"Distance":"750"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"273"
    ,"Station_Code":"Q12 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"189/4, đường Trường Chinh, Quận 12"
    ,"Lat":10.828843
    ,"Long":106.624482
    ,"Polyline":"[106.62609863,10.82672977] ; [106.62532806,10.82746792] ; [106.62448120,10.82884312]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"274"
    ,"Station_Code":"Q12 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"258, đường Trường Chinh, Quận 12"
    ,"Lat":10.832547
    ,"Long":106.622116
    ,"Polyline":"[106.62448120,10.82884312] ; [106.62211609,10.83254719]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"275"
    ,"Station_Code":"Q12 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa Lạc  Quang"
    ,"Station_Address":"408, đường Trường  Chinh, Quận 12"
    ,"Lat":10.83514
    ,"Long":106.620464
    ,"Polyline":"[106.62211609,10.83254719] ; [106.62046051,10.83514023]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"277"
    ,"Station_Code":"Q12 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"640, đường Trường Chinh, Quận 12"
    ,"Lat":10.83819
    ,"Long":106.618495
    ,"Polyline":"[106.62046051,10.83514023] ; [106.62046051,10.83514023] ; [106.61943054,10.83663082] ; [106.61849213,10.83819008] ; [106.61849213,10.83819008]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"276"
    ,"Station_Code":"Q12 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"774A, đường Trường Chinh, Quận 12"
    ,"Lat":10.841436
    ,"Long":106.616457
    ,"Polyline":"[106.61849213,10.83819008] ; [106.61849213,10.83819008] ; [106.61741638,10.83978176] ; [106.61645508,10.84143639] ; [106.61645508,10.84143639]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61645508,10.84143639] ; [106.61566162,10.84250546] ; [106.61565399,10.84274197] ; [106.61556244,10.84290028] ; [106.61544037,10.84296322] ; [106.61527252,10.84297943] ; [106.61402893,10.84497070]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1151"
    ,"Station_Code":"Q12 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Cây xăng Quân Đội"
    ,"Station_Address":"2, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.850034
    ,"Long":106.610845
    ,"Polyline":"[106.61401367,10.84493923] ; [106.61078644,10.84997559]"
    ,"Distance":"675"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1689"
    ,"Station_Code":"Q12 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Cảnh sát giao thông số 5"
    ,"Station_Address":"Kế cảnh sát giao thông số 5, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.851009
    ,"Long":106.610186
    ,"Polyline":"[106.61084747,10.85003376] ; [106.61018372,10.85100937]"
    ,"Distance":"130"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1152"
    ,"Station_Code":"Q12 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Trung tâm văn hóa Quận 12, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.854892
    ,"Long":106.607718
    ,"Polyline":"[106.61018372,10.85100937] ; [106.60771942,10.85489178]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1690"
    ,"Station_Code":"Q12 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Trung tâm Văn hóa quận 12"
    ,"Station_Address":"Hông Trung tâm văn hóa Quận 12, đường  Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.855634
    ,"Long":106.607578
    ,"Polyline":"[106.60771942,10.85489178] ; [106.60738373,10.85536003] ; [106.60737610,10.85540295] ; [106.60745239,10.85553455] ; [106.60752869,10.85575962] ; [106.60753632,10.85575771] ; [106.60757446,10.85563374]"
    ,"Distance":"127"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1691"
    ,"Station_Code":"Q12 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trường Cao đẳng Giao thông vận  tải"
    ,"Station_Address":"8, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.857552
    ,"Long":106.608839
    ,"Polyline":"[106.60757446,10.85563374] ; [106.60818481,10.85666180] ; [106.60884094,10.85755157]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1692"
    ,"Station_Code":"Q12 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Nhà thờ  Trung Chánh"
    ,"Station_Address":"349, đường  Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.859981
    ,"Long":106.610422
    ,"Polyline":"[106.60884094,10.85755157] ; [106.61042023,10.85998058]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1693"
    ,"Station_Code":"Q12 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Chợ Vạn Hạnh"
    ,"Station_Address":"7, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.862873
    ,"Long":106.612412
    ,"Polyline":"[106.61042023,10.85998058] ; [106.61241150,10.86287308]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1694"
    ,"Station_Code":"Q12 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Nhà sách Nguyễn Hữu Cầu"
    ,"Station_Address":"1C, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.865112
    ,"Long":106.614016
    ,"Polyline":"[106.61241150,10.86287308] ; [106.61401367,10.86511230]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1695"
    ,"Station_Code":"Q12 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Ngã 3 Bầu"
    ,"Station_Address":"Lô A4D, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.867625
    ,"Long":106.615899
    ,"Polyline":"[106.61401367,10.86511230] ; [106.61406708,10.86524391] ; [106.61449432,10.86577034] ; [106.61551666,10.86736965] ; [106.61593628,10.86771965] ; [106.61589813,10.86762524]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1696"
    ,"Station_Code":"Q12 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Trạm y tế"
    ,"Station_Address":"772, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.869577
    ,"Long":106.617981
    ,"Polyline":"[106.61589813,10.86762524] ; [106.61798096,10.86957741]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1698"
    ,"Station_Code":"Q12 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Trung tâm y tế Quận 12"
    ,"Station_Address":"927, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.871676
    ,"Long":106.619911
    ,"Polyline":"[106.61798096,10.86957741] ; [106.61940765,10.87119675] ; [106.61991119,10.87167645]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1697"
    ,"Station_Code":"Q12 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Quán Năm Lửa"
    ,"Station_Address":"785, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.87539
    ,"Long":106.623355
    ,"Polyline":"[106.61991119,10.87167645] ; [106.62335205,10.87539005]"
    ,"Distance":"559"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1699"
    ,"Station_Code":"Q12 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngã tư Nước đá"
    ,"Station_Address":"753, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.878219
    ,"Long":106.625812
    ,"Polyline":"[106.62335205,10.87539005] ; [106.62489319,10.87719727] ; [106.62580872,10.87821865]"
    ,"Distance":"415"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1700"
    ,"Station_Code":"Q12 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trường tiểu học Nguyễn Trãi"
    ,"Station_Address":"Trường Nguyễn Trãi, đường  Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.88118
    ,"Long":106.627995
    ,"Polyline":"[106.62580872,10.87821865] ; [106.62685394,10.87958336] ; [106.62799835,10.88117981]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1703"
    ,"Station_Code":"Q12 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Ngã 3 Đông Quang"
    ,"Station_Address":"581-577, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.882892
    ,"Long":106.630087
    ,"Polyline":"[106.62799835,10.88117981] ; [106.62905121,10.88282871] ; [106.62944794,10.88320827] ; [106.63008881,10.88289165]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1701"
    ,"Station_Code":"Q12 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Cây xăng Hiệp Thành"
    ,"Station_Address":"46/8, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.880437
    ,"Long":106.634513
    ,"Polyline":"[106.63008881,10.88289165] ; [106.63211823,10.88173866] ; [106.63451385,10.88043690]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1704"
    ,"Station_Code":"Q12 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Cửa hàng Ngọc Sơn"
    ,"Station_Address":"86H, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.879073
    ,"Long":106.636975
    ,"Polyline":"[106.63451385,10.88043690] ; [106.63574219,10.87977314] ; [106.63697815,10.87907314]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1702"
    ,"Station_Code":"Q12 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Công an Hiệp Thành"
    ,"Station_Address":"425, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.878066
    ,"Long":106.638708
    ,"Polyline":"[106.63697815,10.87907314] ; [106.63791656,10.87856674] ; [106.63871002,10.87806606]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1706"
    ,"Station_Code":"Q12 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"296, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877192
    ,"Long":106.640645
    ,"Polyline":"[106.63871002,10.87806606] ; [106.64036560,10.87724495] ; [106.64064789,10.87719154]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"30"
    ,"Station_Id":"1615"
    ,"Station_Code":"BX34"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Hiệp Thành"
    ,"Station_Address":"BÃI XE HIỆP THÀNH, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.877449989318848
    ,"Long":106.64203643798828
    ,"Polyline":"[106.64064789,10.87719154] ; [106.64183807,10.87704945] ; [106.64210510,10.87741280] ; [106.64203644,10.87744999]"
    ,"Distance":"190"
  }]