export const Route133 =[

  {
     "Route_Id":"133"
    ,"Station_Id":"394"
    ,"Station_Code":"BX73"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Bến xe buýt ĐH Nông Lâm, đường Qu ốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868183135986328
    ,"Long":106.78744506835938
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1101"
    ,"Station_Code":"QTD 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"ĐH Nông  Lâm"
    ,"Station_Address":"Kế 21, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867404
    ,"Long":106.787265
    ,"Polyline":"[106.78778076,10.86812019] ; [106.78777313,10.86791992] ; [106.78781891,10.86777973] ; [106.78798676,10.86765003] ; [106.78820801,10.86746025] ; [106.78827667,10.86736965] ; [106.78829956,10.86725998] ; [106.78669739,10.86732006]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1102"
    ,"Station_Code":"QTD 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty điện tử Samsung"
    ,"Station_Address":"Kế 59/6, đường Quốc lộ 1,  Quận Thủ Đức"
    ,"Lat":10.867867
    ,"Long":106.782201
    ,"Polyline":"[106.78669739,10.86732006] ; [106.78428650,10.86742020] ; [106.78352356,10.86748028] ; [106.78308105,10.86754990] ; [106.78215790,10.86775970]"
    ,"Distance":"500"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1103"
    ,"Station_Code":"QTD 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Đại học Kinh tế -Luật"
    ,"Station_Address":"Đại học Kinh tế -Luật, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.869274
    ,"Long":106.777909
    ,"Polyline":"[106.78215790,10.86775970] ; [106.78076935,10.86818981] ; [106.77931976,10.86865044] ; [106.77787018,10.86913967]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2142"
    ,"Station_Code":"QTD 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trung tâm kho vận Linh Xuân"
    ,"Station_Address":"Trung  tâm kho vận Linh Xuân, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870254
    ,"Long":106.774932
    ,"Polyline":"[106.77787018,10.86913967] ; [106.77607727,10.86975002] ; [106.77542877,10.86995029] ; [106.77510071,10.87005043] ; [106.77487946,10.87012005]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2147"
    ,"Station_Code":"QTD 185"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Nghĩa trang Thành phố"
    ,"Station_Address":"C ột điện NG/1, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870912
    ,"Long":106.772878
    ,"Polyline":"[106.77487946,10.87012005] ; [106.77285004,10.87078953]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2143"
    ,"Station_Code":"QTD 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Công ty  Nissan"
    ,"Station_Address":"Đối diện công ty  Nissan, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871571
    ,"Long":106.770823
    ,"Polyline":"[106.77285004,10.87078953] ; [106.77078247,10.87147045]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3385"
    ,"Station_Code":"QTD 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm c ầu vượt Linh Xuân"
    ,"Station_Address":"1342, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.872113
    ,"Long":106.764297
    ,"Polyline":"[106.77078247,10.87147045] ; [106.76754761,10.87252998] ; [106.76730347,10.87269974] ; [106.76686859,10.87285042] ; [106.76580811,10.87322998] ; [106.76509857,10.87347031] ; [106.76502991,10.87331009] ; [106.76470184,10.87254047] ; [106.76435852,10.87205982]"
    ,"Distance":"838"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3384"
    ,"Station_Code":"QTD 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà hàng tiệc cưới Phố Đôi"
    ,"Station_Address":"7/16, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.867778
    ,"Long":106.762476
    ,"Polyline":"[106.76435852,10.87205982] ; [106.76400757,10.87164974] ; [106.76376343,10.87131977] ; [106.76342010,10.87084007] ; [106.76329803,10.87059021] ; [106.76325989,10.87034988] ; [106.76329041,10.86966991] ; [106.76328278,10.86935997] ; [106.76319122,10.86907959] ; [106.76304626,10.86882019]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3387"
    ,"Station_Code":"QTD 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"UBND phường Linh Tây"
    ,"Station_Address":"1250, đường Kha V ạn Cân, Quận Thủ Đức"
    ,"Lat":10.864264
    ,"Long":106.761199
    ,"Polyline":"[106.76304626,10.86882019] ; [106.76268005,10.86820984] ; [106.76233673,10.86767960] ; [106.76220703,10.86740017] ; [106.76219177,10.86711025] ; [106.76216888,10.86668015] ; [106.76204681,10.86585045] ; [106.76199341,10.86553955] ; [106.76181030,10.86513042] ; [106.76120758,10.86413002] ; [106.76110077,10.86388016]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3386"
    ,"Station_Code":"QTD 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã ba Hoàng Diệu II"
    ,"Station_Address":"1176, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.860581
    ,"Long":106.760663
    ,"Polyline":"[106.76110077,10.86388016] ; [106.76098633,10.86363029] ; [106.76090240,10.86326027] ; [106.76090240,10.86297989] ; [106.76097870,10.86252022] ; [106.76103210,10.86233044] ; [106.76106262,10.86205006] ; [106.76103973,10.86145020] ; [106.76091003,10.86087990] ; [106.76081085,10.86069965]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3388"
    ,"Station_Code":"QTD 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Phòng khám đa khoa Á Châu"
    ,"Station_Address":"1106, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.858411
    ,"Long":106.758603
    ,"Polyline":"[106.76081085,10.86069965] ; [106.76065826,10.86044979] ; [106.76035309,10.86005020] ; [106.76023102,10.85993004] ; [106.75987244,10.85964012] ; [106.75964355,10.85941982] ; [106.75929260,10.85898018] ; [106.75890350,10.85851002] ; [106.75871277,10.85834980]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3389"
    ,"Station_Code":"QTD 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"1042, đường Kha Vạn Cân, Quận  Thủ Đức"
    ,"Lat":10.855956
    ,"Long":106.756103
    ,"Polyline":"[106.75871277,10.85834980] ; [106.75845337,10.85813999] ; [106.75821686,10.85801983] ; [106.75782013,10.85791969] ; [106.75760651,10.85785007] ; [106.75730133,10.85764980] ; [106.75715637,10.85748005] ; [106.75698090,10.85709953] ; [106.75685883,10.85674953] ; [106.75656128,10.85636997] ; [106.75640869,10.85612965] ; [106.75624084,10.85593033]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3391"
    ,"Station_Code":"QTD 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường TH Nguyễn Trung Trực"
    ,"Station_Address":"150, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.851615
    ,"Long":106.754757
    ,"Polyline":"[106.75624084,10.85593033] ; [106.75565338,10.85534954] ; [106.75546265,10.85515022] ; [106.75511169,10.85447025] ; [106.75470734,10.85359955] ; [106.75463104,10.85319042] ; [106.75463104,10.85291958] ; [106.75470734,10.85245037] ; [106.75482941,10.85171032]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3277"
    ,"Station_Code":"QTD 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Thủ Đức"
    ,"Station_Address":"20-21, đường Lê Văn Ninh, Quận Thủ Đức"
    ,"Lat":10.850327
    ,"Long":106.754005
    ,"Polyline":"[106.75482941,10.85171032] ; [106.75489807,10.85122013] ; [106.75489044,10.85122013] ; [106.75488281,10.85120964] ; [106.75485229,10.85118008] ; [106.75482941,10.85112000] ; [106.75469208,10.85103035] ; [106.75406647,10.85027027]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"575"
    ,"Station_Code":"QTD 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trạm Cầu ngang"
    ,"Station_Address":"581 , đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.847199
    ,"Long":106.751587
    ,"Polyline":"[106.75406647,10.85027027] ; [106.75351715,10.84957981] ; [106.75366211,10.84943008] ; [106.75328827,10.84893036] ; [106.75267792,10.84821033] ; [106.75229645,10.84774971] ; [106.75189209,10.84735012] ; [106.75164795,10.84714031]"
    ,"Distance":"457"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"578"
    ,"Station_Code":"QTD 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Công an  Phường Linh Đông"
    ,"Station_Address":"517, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.845116
    ,"Long":106.749763
    ,"Polyline":"[106.75164795,10.84714031] ; [106.75095367,10.84648037] ; [106.75058746,10.84609032] ; [106.75009918,10.84539032] ; [106.74981689,10.84506989]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"577"
    ,"Station_Code":"QTD 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Công ty 27-7"
    ,"Station_Address":"Đối diện 624, đường Kha V ạn Cân, Quận Thủ Đức"
    ,"Lat":10.841721
    ,"Long":106.74659
    ,"Polyline":"[106.74981689,10.84506989] ; [106.74871063,10.84387970] ; [106.74836731,10.84350967] ; [106.74794769,10.84302044] ; [106.74741364,10.84235001] ; [106.74690247,10.84187031] ; [106.74665833,10.84165001]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"579"
    ,"Station_Code":"QTD 149"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường Cao đẳng Vinatex"
    ,"Station_Address":"403, đường Kha  Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.840851
    ,"Long":106.744548
    ,"Polyline":"[106.74658966,10.84172058] ; [106.74662781,10.84160995] ; [106.74609375,10.84113979] ; [106.74572754,10.84086990] ; [106.74537659,10.84076023] ; [106.74487305,10.84074974] ; [106.74453735,10.84080029] ; [106.74437714,10.84086037] ; [106.74404144,10.84117031] ; [106.74405670,10.84117031] ; [106.74454498,10.84085083]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.74454498,10.84085083] ; [106.74269104,10.84080887] ; [106.73762512,10.83958626] ; [106.73518372,10.83878517] ; [106.73286438,10.83777428] ; [106.72707367,10.83301067] ; [106.72132111,10.82833195] ; [106.71986389,10.82774162] ; [106.71385193,10.82588768] ; [106.71260834,10.81800461] ; [106.71192169,10.81728840] ; [106.71125793,10.81666088]"
    ,"Distance":"4934"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường Đinh Bộ Lĩnh, Quận Bình  Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71125793,10.81666088] ; [106.71115875,10.81656647] ; [106.71063232,10.81564426] ; [106.70983887,10.81410599] ; [106.70922089,10.81262493]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Qu ận Bình Thạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70922089,10.81262493] ; [106.70911407,10.81207180] ; [106.70914459,10.80975914]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70914459,10.80975914] ; [106.70934296,10.80690765]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Qu ận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70934296,10.80690765] ; [106.70948792,10.80553818] ; [106.70939636,10.80442142]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1872"
    ,"Station_Code":"QBTH 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Đại học Hồng Bàng"
    ,"Station_Address":"205, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799747
    ,"Long":106.706268
    ,"Polyline":"[106.70944214,10.80442047] ; [106.70935059,10.80296993] ; [106.70932007,10.80241013] ; [106.70932007,10.80202961] ; [106.70931244,10.80144978] ; [106.70937347,10.80125046] ; [106.70861816,10.80097961] ; [106.70812988,10.80078030] ; [106.70787811,10.80064964] ; [106.70706177,10.80016994] ; [106.70671082,10.79996014] ; [106.70635986,10.79969025]"
    ,"Distance":"746"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1875"
    ,"Station_Code":"QBTH 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm Điện Nguyễn Cửu Vân"
    ,"Station_Address":"119, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.797724
    ,"Long":106.704175
    ,"Polyline":"[106.70626831,10.79974747] ; [106.70558167,10.79914665] ; [106.70502472,10.79858208] ; [106.70417786,10.79772377]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1874"
    ,"Station_Code":"QBTH 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cầu Điện Biên Phủ"
    ,"Station_Address":"45, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.795157
    ,"Long":106.701745
    ,"Polyline":"[106.70417786,10.79772377] ; [106.70174408,10.79515743]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1877"
    ,"Station_Code":"Q1 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Nguyễn Văn Thủ"
    ,"Station_Address":"75, đường Nguyễn  Bỉnh Khiêm, Quận 1"
    ,"Lat":10.791216
    ,"Long":106.700569
    ,"Polyline":"[106.70118713,10.79428959] ; [106.70089722,10.79389954] ; [106.69998932,10.79294968] ; [106.69970703,10.79273033] ; [106.69946289,10.79261017] ; [106.69937134,10.79259014] ; [106.69928741,10.79255009] ; [106.69921112,10.79246998] ; [106.69915771,10.79236984] ; [106.69917297,10.79228973] ; [106.69924164,10.79220963] ; [106.69936371,10.79218006] ; [106.69947052,10.79218960] ; [106.69959259,10.79222965] ; [106.70001221,10.79185009] ; [106.70063019,10.79127979]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1879"
    ,"Station_Code":"Q1 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"UBND Phường Dakao"
    ,"Station_Address":"52 -54, đường Nguyễn Đình Chiểu, Quận  1"
    ,"Lat":10.78885
    ,"Long":106.699738
    ,"Polyline":"[106.70063019,10.79127979] ; [106.70127106,10.79069996] ; [106.70146942,10.79051018] ; [106.70099640,10.79004002] ; [106.70011139,10.78911972] ; [106.69979858,10.78878975]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1876"
    ,"Station_Code":"Q1 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Mạc Đỉnh Chi"
    ,"Station_Address":"102, đường Nguyễn Đình Chiểu, Quận 1"
    ,"Lat":10.786848
    ,"Long":106.697861
    ,"Polyline":"[106.69979858,10.78878975] ; [106.69792175,10.78680038]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1878"
    ,"Station_Code":"Q1 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Hai Bà Trưng"
    ,"Station_Address":"116 - 118, đường Nguyễn Đình Chiểu, Quận 1"
    ,"Lat":10.785293
    ,"Long":106.696457
    ,"Polyline":"[106.69792175,10.78680038] ; [106.69648743,10.78526020]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1881"
    ,"Station_Code":"Q3 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Đại học Kinh tế"
    ,"Station_Address":"138B, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.782981
    ,"Long":106.694191
    ,"Polyline":"[106.69648743,10.78526020] ; [106.69486237,10.78357029] ; [106.69425964,10.78291988]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"195"
    ,"Station_Code":"Q3 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Coop Mart Nguyễn Đình Chiểu"
    ,"Station_Address":"145 , đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.78113
    ,"Long":106.693152
    ,"Polyline":"[106.69419098,10.78298092] ; [106.69425964,10.78291988] ; [106.69290161,10.78145981] ; [106.69320679,10.78114510.06.69315338]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"197"
    ,"Station_Code":"Q3 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Trường Lê  Quý Đôn"
    ,"Station_Address":"Đối diện 166 - 168, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.779777
    ,"Long":106.694626
    ,"Polyline":"[106.69315338,10.78112984] ; [106.69315338,10.78112984] ; [106.69320679,10.78116131] ; [106.69393158,10.78046608] ; [106.69465637,10.77979660] ; [106.69462585,10.77977657] ; [106.69462585,10.77977657]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"200"
    ,"Station_Code":"Q1 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Tòa Án Thành Phố"
    ,"Station_Address":"131, đường Nam  Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.776052
    ,"Long":106.698647
    ,"Polyline":"[106.69462585,10.77977657] ; [106.69462585,10.77977657] ; [106.69839478,10.77634430] ; [106.69864655,10.77612877] ; [106.69864655,10.77605247] ; [106.69864655,10.77605247]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"199"
    ,"Station_Code":"Q1 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Chùa Ông"
    ,"Station_Address":"Đối diện 96A, đường Nam K ỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.773957
    ,"Long":106.699722
    ,"Polyline":"[106.69864655,10.77605247] ; [106.69864655,10.77605247] ; [106.69864655,10.77605247] ; [106.69869995,10.77607632] ; [106.69901276,10.77581787] ; [106.69919586,10.77543831] ; [106.69934082,10.77505875] ; [106.69976807,10.77400494] ; [106.69972229,10.77395725] ; [106.69972229,10.77395725] ; [106.69972229,10.77395725]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"201"
    ,"Station_Code":"Q1 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Trường CĐKT Cao Thắng"
    ,"Station_Address":"Đối diện 86 , đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.771416
    ,"Long":106.700851
    ,"Polyline":"[106.69972229,10.77395725] ; [106.70030975,10.77276134] ; [106.70085144,10.77141571]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Công ty Đ ường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70085144,10.77141571] ; [106.70106506,10.77109623] ; [106.69935608,10.77116299]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"81"
    ,"Station_Code":"Q1TC1A"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bến Thành A"
    ,"Station_Address":"Bến Thành, đường  Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770896
    ,"Long":106.69854
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69909668,10.77116489] ; [106.69853973,10.77089596]"
    ,"Distance":"96"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103 , đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853973,10.77089596] ; [106.69853973,10.77089596] ; [106.69853973,10.77089596] ; [106.69731140,10.77031612] ; [106.69595337,10.76980972] ; [106.69595337,10.76980972] ; [106.69595337,10.76980972]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường L ê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.68957520,10.76720715] ; [106.68936157,10.76767635]"
    ,"Distance":"581"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68907166,10.76811028] ; [106.68920898,10.76819992] ; [106.68995667,10.76846981] ; [106.69026184,10.76858997]"
    ,"Distance":"141"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69673157,10.77120972] ; [106.69786835,10.77167034] ; [106.69803619,10.77159977] ; [106.69802094,10.77149010.06.69802094] ; [10.77138042,106.69805908] ; [10.77128983,106.69812775] ; [10.77122021,106.69818878] ; [10.77118015,106.69731140] ; [10.77031612,106.69612122] ; [10.76983643,106.69647980] ; [10.76914597,106.69753265] ; [10.77021980,106.69841003] ; [10.77060986,106.69844818]"
    ,"Distance":"866"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2721"
    ,"Station_Code":"Q1 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bệnh viện Đa khoa Sài Gòn"
    ,"Station_Address":"125, đường Lê Lợi, Quận 1"
    ,"Lat":10.772139
    ,"Long":106.699219
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69902039,10.77083206] ; [106.69894409,10.77121735] ; [106.69886017,10.77142811] ; [106.69886780,10.77158070] ; [106.69884491,10.77173901] ; [106.69907379,10.77203369] ; [106.69921875,10.77213860]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2723"
    ,"Station_Code":"Q1 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Sài Gòn Centre"
    ,"Station_Address":"Đối diện 58, đường Lê Lợi, Quận 1"
    ,"Lat":10.773594
    ,"Long":106.700587
    ,"Polyline":"[106.69921875,10.77213860] ; [106.70058441,10.77359390]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2724"
    ,"Station_Code":"Q1 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Lê Thánh Tôn"
    ,"Station_Address":"144, đường Pasteur, Quận 1"
    ,"Lat":10.775088
    ,"Long":106.700768
    ,"Polyline":"[106.70058441,10.77359390] ; [106.70109558,10.77425766] ; [106.70076752,10.77508831]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"4272"
    ,"Station_Code":"Q1 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Lý Tự Trọng"
    ,"Station_Address":"158, đường Pasteur, Quận 1"
    ,"Lat":10.777089
    ,"Long":106.699657
    ,"Polyline":"[106.70076752,10.77508831] ; [106.69995117,10.77685070] ; [106.69965363,10.77708912]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"4273"
    ,"Station_Code":"Q1 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công viên 30/4"
    ,"Station_Address":"178, đường Pasteur, Quận 1"
    ,"Lat":10.778307999999999
    ,"Long":106.698333
    ,"Polyline":"[106.69965363,10.77708912] ; [106.69833374,10.77830791]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"4274"
    ,"Station_Code":"Q1 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Nguyễn Thị Minh Khai"
    ,"Station_Address":"184 , đường Pasteur, Quận 1"
    ,"Lat":10.779782
    ,"Long":106.696659
    ,"Polyline":"[106.69833374,10.77830791] ; [106.69665527,10.77978230]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"243"
    ,"Station_Code":"Q3 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Đại học Kiến Trúc"
    ,"Station_Address":"194 D, đường Pasteur, Quận 3"
    ,"Lat":10.781804
    ,"Long":106.694579
    ,"Polyline":"[106.69665527,10.77978230] ; [106.69458008,10.78180408]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"244"
    ,"Station_Code":"Q3 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Sở Tư Pháp"
    ,"Station_Address":"214, đường Pasteur, Quận 3"
    ,"Lat":10.783419
    ,"Long":106.692749
    ,"Polyline":"[106.69458008,10.78180408] ; [106.69364166,10.78258896] ; [106.69274902,10.78341866]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1920"
    ,"Station_Code":"Q3 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Phạm Ngọc Thạch"
    ,"Station_Address":"209, đường Điện Biên Phủ, Quận 3"
    ,"Lat":10.784965
    ,"Long":106.692375
    ,"Polyline":"[106.69274902,10.78341866] ; [106.69171143,10.78432846] ; [106.69237518,10.78496456]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1915"
    ,"Station_Code":"Q1 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Công Viên Lê Văn Tám"
    ,"Station_Address":"179 - 181, đường Điện Biên Phủ, Quận 1"
    ,"Lat":10.786934
    ,"Long":106.694313
    ,"Polyline":"[106.69237518,10.78496456] ; [106.69329834,10.78595638] ; [106.69431305,10.78693390]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1924"
    ,"Station_Code":"Q1 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đinh Tiên Hoàng"
    ,"Station_Address":"87, đường Điện Biên Phủ, Quận 1"
    ,"Lat":10.789477
    ,"Long":106.696783
    ,"Polyline":"[106.69431305,10.78693390] ; [106.69678497,10.78947735]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"730"
    ,"Station_Code":"QBTH 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu Điện Biên Phủ"
    ,"Station_Address":"84, đường Điện Biên Phủ, Quận  Bình Thạnh"
    ,"Lat":10.794815
    ,"Long":106.702223
    ,"Polyline":"[106.69682312,10.78964043] ; [106.69753265,10.79039001] ; [106.69812775,10.79096985] ; [106.69902802,10.79195976] ; [106.69936371,10.79218006] ; [106.69959259,10.79222965] ; [106.69967651,10.79228020] ; [106.69972992,10.79238033] ; [106.69975281,10.79249001] ; [106.69992065,10.79263973] ; [106.70092773,10.79370022] ; [106.70124054,10.79401016]"
    ,"Distance":"852"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1916"
    ,"Station_Code":"QBTH 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trạm Điện Nguyễn Cửu Vân"
    ,"Station_Address":"174, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.797286
    ,"Long":106.704567
    ,"Polyline":"[106.70222473,10.79481506] ; [106.70456696,10.79728603]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1918"
    ,"Station_Code":"QBTH 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Đại học Hồng Bàng"
    ,"Station_Address":"330, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.799505
    ,"Long":106.70689
    ,"Polyline":"[106.70456696,10.79728603] ; [106.70456696,10.79728603] ; [106.70600128,10.79877186] ; [106.70688629,10.79950523] ; [106.70688629,10.79950523]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1925"
    ,"Station_Code":"QBTH 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Vòng xoay Hàng Xanh"
    ,"Station_Address":"442, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.80108
    ,"Long":106.710269
    ,"Polyline":"[106.70688629,10.79950523] ; [106.70688629,10.79950523] ; [106.70744324,10.79987907] ; [106.70861816,10.80055332] ; [106.70944214,10.80087471] ; [106.71026611,10.80107975] ; [106.71026611,10.80107975]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338 , đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71026611,10.80107975] ; [106.70983124,10.80103970] ; [106.71054840,10.80115986] ; [106.71125031,10.80126953] ; [106.71132660,10.80123997] ; [106.71138763,10.80125046] ; [106.71147919,10.80128956] ; [106.71151733,10.80136013] ; [106.71154022,10.80144978] ; [106.71150208,10.80152988] ; [106.71144104,10.80158043] ; [106.71137238,10.80160999] ; [106.71132660,10.80160999] ; [106.71137238,10.80249977] ; [106.71140289,10.80298042] ; [106.71145630,10.80453014] ; [106.71154022,10.80474758]"
    ,"Distance":"634"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Đài Li ệt sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71163940,10.80783558] ; [106.71174622,10.80835152] ; [106.71196747,10.80883121]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222 /13A, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71212006,10.80930042] ; [106.71221161,10.80964851] ; [106.71233368,10.81025887] ; [106.71240997,10.81079102]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bến xe  Miền Đông"
    ,"Station_Address":"152, đường Qu ốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71279144,10.81385326]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"531"
    ,"Station_Code":"QTD 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trường Cao đẳng Vinatex"
    ,"Station_Address":"580, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.840767
    ,"Long":106.744022
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71421814,10.82557106.06.71477509] ; [10.82588768,106.71945190] ; [10.82704639,106.72161865] ; [10.82812119,106.72814178] ; [10.83347416,106.73462677] ; [10.83823776,106.74401855]"
    ,"Distance":"5057"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"532"
    ,"Station_Code":"QTD 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Công ty 23-7"
    ,"Station_Address":"624, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.84129
    ,"Long":106.746346
    ,"Polyline":"[106.74401855,10.84076691] ; [106.74512482,10.84066677] ; [106.74539185,10.84066677] ; [106.74580383,10.84077740] ; [106.74634552,10.84129047]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"533"
    ,"Station_Code":"QTD 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công an phường Linh Đông"
    ,"Station_Address":"684, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.844781
    ,"Long":106.74966
    ,"Polyline":"[106.74634552,10.84129047] ; [106.74747467,10.84235764] ; [106.74848938,10.84358025] ; [106.74965668,10.84478092]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"534"
    ,"Station_Code":"QTD 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm C ầu Ngang"
    ,"Station_Address":"742, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.847416
    ,"Long":106.75209
    ,"Polyline":"[106.74965668,10.84478092] ; [106.75016022,10.84536648] ; [106.75089264,10.84638786] ; [106.75209045,10.84741592]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"535"
    ,"Station_Code":"QTD 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Chợ Thủ Đức"
    ,"Station_Address":"996, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.850158
    ,"Long":106.754372
    ,"Polyline":"[106.75209045,10.84741592] ; [106.75298309,10.84848022] ; [106.75351715,10.84916496] ; [106.75437164,10.85015774]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3376"
    ,"Station_Code":"QTD 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường TH Nguyễn Trung Trực"
    ,"Station_Address":"105, đường Kha  Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.852065
    ,"Long":106.754845
    ,"Polyline":"[106.75437164,10.85015774] ; [106.75434113,10.85017967] ; [106.75491333,10.85087204] ; [106.75501251,10.85105991] ; [106.75504303,10.85112000] ; [106.75501251,10.85120010.06.75484467]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3378"
    ,"Station_Code":"QTD 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"785, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.856333
    ,"Long":106.756615
    ,"Polyline":"[106.75484467,10.85206509] ; [106.75468445,10.85292625] ; [106.75472260,10.85336876] ; [106.75511169,10.85447025] ; [106.75598907,10.85566998] ; [106.75627136,10.85595989] ; [106.75640869,10.85612965] ; [106.75656128,10.85636997] ; [106.75661469,10.85633278]"
    ,"Distance":"549"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3379"
    ,"Station_Code":"QTD 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Phòng khám đa khoa Á Châu"
    ,"Station_Address":"891-893, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.858556
    ,"Long":106.758965
    ,"Polyline":"[106.75661469,10.85633278] ; [106.75656128,10.85636997] ; [106.75685883,10.85674953] ; [106.75697327,10.85679913] ; [106.75704956,10.85708332] ; [106.75716400,10.85734653] ; [106.75740051,10.85765743] ; [106.75768280,10.85782623] ; [106.75803375,10.85797024] ; [106.75835419,10.85805225] ; [106.75859070,10.85824013] ; [106.75890350,10.85851002] ; [106.75895691,10.85855961] ; [106.75896454,10.85855579]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3380"
    ,"Station_Code":"QTD 141"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã ba Hoàng Diệu II"
    ,"Station_Address":"943, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.860415
    ,"Long":106.760712
    ,"Polyline":"[106.75895691,10.85855961] ; [106.75929260,10.85898018] ; [106.75964355,10.85941982] ; [106.75987244,10.85964012] ; [106.76023102,10.85993004] ; [106.76035309,10.86005020] ; [106.76065826,10.86044979]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3382"
    ,"Station_Code":"QTD 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"UBND phường Linh Tây"
    ,"Station_Address":"Đối diện 1260, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.863985
    ,"Long":106.7612
    ,"Polyline":"[106.76065826,10.86044979] ; [106.76091003,10.86087990] ; [106.76103973,10.86145020] ; [106.76106262,10.86205006] ; [106.76103210,10.86233044] ; [106.76097870,10.86252022] ; [106.76090240,10.86297989] ; [106.76090240,10.86326027] ; [106.76098633,10.86363029] ; [106.76116180,10.86400032]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3383"
    ,"Station_Code":"QTD 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Nhà hàng tiệc cưới Phố Đôi"
    ,"Station_Address":"15/3 , đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.868789
    ,"Long":106.763399
    ,"Polyline":"[106.76119995,10.86398506] ; [106.76116180,10.86400032] ; [106.76165009,10.86485958] ; [106.76197815,10.86538124] ; [106.76221466,10.86637688] ; [106.76221466,10.86668205] ; [106.76223755,10.86690331] ; [106.76236725,10.86711025] ; [106.76245117,10.86732960] ; [106.76280975,10.86789894] ; [106.76316071,10.86843681] ; [106.76339722,10.86878872]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"3381"
    ,"Station_Code":"QTD 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trạm c ầu vượt Linh Xuân"
    ,"Station_Address":"1129-1131, đ ường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.87135
    ,"Long":106.763999
    ,"Polyline":"[106.76339722,10.86878872] ; [106.76339722,10.86878872] ; [106.76352692,10.86938953] ; [106.76354218,10.86960602] ; [106.76351929,10.87006950] ; [106.76354980,10.87038040] ; [106.76362610,10.87078094] ; [106.76382446,10.87115955] ; [106.76399994,10.87135029] ; [106.76399994,10.87135029]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2083"
    ,"Station_Code":"QTD 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Vietcombank"
    ,"Station_Address":"Ngân hàng Vietcombank, đư ờng Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871597
    ,"Long":106.769643
    ,"Polyline":"[106.76423645,10.87191010.06.76442719] ; [10.87213993,106.76470184] ; [10.87254047,106.76484680] ; [10.87287045,106.76499176] ; [10.87318993,106.76542664] ; [10.87304020,106.76715088] ; [10.87246037,106.76750946] ; [10.87240982,106.76898193] ; [10.87191010.06.76965332,10.87168980]"
    ,"Distance":"781"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"2084"
    ,"Station_Code":"QTD 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Nghĩa trang TP"
    ,"Station_Address":"Cổng nghĩa trang thành phố, đường Qu ốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.870507
    ,"Long":106.773039
    ,"Polyline":"[106.76964569,10.87159729] ; [106.77304077,10.87050724]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1040"
    ,"Station_Code":"QTD 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"ĐH Kinh tế Luật"
    ,"Station_Address":"Đối diện 665, đường Quốc lộ 1, Quận Th ủ Đức"
    ,"Lat":10.869306
    ,"Long":106.776724
    ,"Polyline":"[106.77304077,10.87050724] ; [106.77672577,10.86930561]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1041"
    ,"Station_Code":"QTD 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Công ty điện tử Samsung"
    ,"Station_Address":"Công ty điện tử Samsung, đường Quốc lộ 1,  Quận Thủ Đức"
    ,"Lat":10.868691
    ,"Long":106.778656
    ,"Polyline":"[106.77672577,10.86930561] ; [106.77865601,10.86869144]"
    ,"Distance":"222"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"1042"
    ,"Station_Code":"QTD 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"ĐH Nông Lâm"
    ,"Station_Address":"Cột điện SI 2, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.867122
    ,"Long":106.787277
    ,"Polyline":"[106.77865601,10.86869144] ; [106.77938843,10.86856270] ; [106.78088379,10.86806297] ; [106.78207397,10.86769390] ; [106.78311920,10.86743546] ; [106.78416443,10.86732483] ; [106.78519440,10.86727905] ; [106.78636932,10.86724091] ; [106.78727722,10.86712170]"
    ,"Distance":"965"
  },
  {
     "Route_Id":"133"
    ,"Station_Id":"394"
    ,"Station_Code":"BX73"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đại học Nông Lâm"
    ,"Station_Address":"Bến xe buýt ĐH Nông Lâm, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868183135986328
    ,"Long":106.78744506835938
    ,"Polyline":"[106.78727722,10.86712170] ; [106.78791046,10.86715603] ; [106.78834534,10.86714077] ; [106.78868103,10.86714077] ; [106.78851318,10.86736202] ; [106.78821564,10.86758804] ; [106.78788757,10.86782551] ; [106.78781128,10.86807251] ; [106.78776550,10.86820412] ; [106.78759003,10.86824131] ; [106.78744507,10.86818314]"
    ,"Distance":"351"
  }]