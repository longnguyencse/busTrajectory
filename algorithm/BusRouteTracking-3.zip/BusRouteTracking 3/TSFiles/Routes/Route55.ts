export const Route55 = [

  {
     "Route_Id":"55"
    ,"Station_Id":"2681"
    ,"Station_Code":"BX 21"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Công viên Đồng Diều"
    ,"Station_Address":"ĐẦU BẾN TRƯỜNG ĐH CN SÀI GÒN , đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.736787
    ,"Long":106.675819
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2077"
    ,"Station_Code":"HBC 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đường số 5"
    ,"Station_Address":"04-06, đường Đường  số 5, Huyện Bình Chánh"
    ,"Lat":10.735706
    ,"Long":106.673566
    ,"Polyline":"[106.67581940,10.73678684] ; [106.67572021,10.73673916] ; [106.67590332,10.73641300] ; [106.67499542,10.73595428] ; [106.67469788,10.73610687] ; [106.67449188,10.73625946] ; [106.67356110,10.73569107]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2683"
    ,"Station_Code":"HBC 165"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Centre Mall"
    ,"Station_Address":"C3/9, đường Phạm  Hùng, Huyện Bình Chánh"
    ,"Lat":10.734315
    ,"Long":106.672992
    ,"Polyline":"[106.67356110,10.73569107] ; [106.67254639,10.73504257] ; [106.67273712,10.73474216]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2679"
    ,"Station_Code":"HBC 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Tạm Ấp 4"
    ,"Station_Address":"C4/9, đường Phạm Hùng, Huyện Bình Chánh"
    ,"Lat":10.732228
    ,"Long":106.674483
    ,"Polyline":"[106.67273712,10.73474216] ; [106.67391205,10.73308182]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2682"
    ,"Station_Code":"HBC 167"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"C4/20, đường Phạm Hùng, Huyện Bình Chánh"
    ,"Lat":10.729382
    ,"Long":106.676543
    ,"Polyline":"[106.67391205,10.73308182] ; [106.67618561,10.72994614]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"832"
    ,"Station_Code":"HBC 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Phúc Minh"
    ,"Station_Address":"Công ty Phúc Minh, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.727574
    ,"Long":106.680121
    ,"Polyline":"[106.67618561,10.72994614] ; [106.67790222,10.72756290] ; [106.68012238,10.72757435]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"829"
    ,"Station_Code":"HBC 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu Ông Bé"
    ,"Station_Address":"Cột điện 47, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.727785
    ,"Long":106.684177
    ,"Polyline":"[106.68012238,10.72757435] ; [106.68183899,10.72779560] ; [106.68417358,10.72778511]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"831"
    ,"Station_Code":"HBC 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trung Sơn"
    ,"Station_Address":"Cột điện 37, đường Nguyễn Văn Linh, Huy ện Bình Chánh"
    ,"Lat":10.7279
    ,"Long":106.687416
    ,"Polyline":"[106.68417358,10.72778511] ; [106.68511963,10.72788525] ; [106.68741608,10.72789955]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"833"
    ,"Station_Code":"Q7 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Đại học RMIT"
    ,"Station_Address":"Đối diện trạm thu  phí, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728011
    ,"Long":106.695308
    ,"Polyline":"[106.68741608,10.72789955] ; [106.69190216,10.72803783] ; [106.69530487,10.72801113]"
    ,"Distance":"863"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"834"
    ,"Station_Code":"Q7 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Lê Văn L ương"
    ,"Station_Address":"Cạnh 38 Lê Văn Lương , đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.727985
    ,"Long":106.699787
    ,"Polyline":"[106.69530487,10.72801113] ; [106.69862366,10.72820854]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"835"
    ,"Station_Code":"Q7 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Phòng cha ́y chữa cháy Quận 7"
    ,"Station_Address":"C ạnh cột điện 39, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728106
    ,"Long":106.704031
    ,"Polyline":"[106.69862366,10.72820854] ; [106.70384216,10.72821999]"
    ,"Distance":"571"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"836"
    ,"Station_Code":"Q7 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nguyễn  Đức Cảnh"
    ,"Station_Address":"37, đường Nguy ễn Văn Linh, Quận 7"
    ,"Lat":10.728212
    ,"Long":106.709341
    ,"Polyline":"[106.70384216,10.72821999] ; [106.70909882,10.72841835]"
    ,"Distance":"575"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"837"
    ,"Station_Code":"Q7 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Co.op mart Phú Mỹ Hưng"
    ,"Station_Address":"Co.op mart Phú Mỹ Hưng, đường Nguyễn  Văn Linh, Quận 7"
    ,"Lat":10.728275
    ,"Long":106.711557
    ,"Polyline":"[106.70909882,10.72841835] ; [106.71155548,10.72827530]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"838"
    ,"Station_Code":"Q7 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu Thầy Tiêu"
    ,"Station_Address":"Trung tâm truyền hình cáp, đường Nguy ễn Văn Linh, Quận 7"
    ,"Lat":10.728375
    ,"Long":106.714829
    ,"Polyline":"[106.71155548,10.72827530] ; [106.71482849,10.72851467]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"839"
    ,"Station_Code":"Q7 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"bệnh viện Việt Pháp"
    ,"Station_Address":"Đối diện bệnh viện Việt Pháp, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.730309
    ,"Long":106.719646
    ,"Polyline":"[106.71482849,10.72851467] ; [106.71538544,10.72855949] ; [106.71588898,10.72863865] ; [106.71662140,10.72881794] ; [106.71731567,10.72900772] ; [106.71810913,10.72937107] ; [106.71876526,10.72974014] ; [106.71954346,10.73039627]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1375"
    ,"Station_Code":"Q7 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện Việt Pháp"
    ,"Station_Address":"Đối diện bệnh viện tim Tâm Đức, đường Nguyễn Lương Bằng , Quận 7"
    ,"Lat":10.733488
    ,"Long":106.71904
    ,"Polyline":"[106.71954346,10.73039627] ; [106.72042847,10.73121071] ; [106.71896362,10.73363495]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1377"
    ,"Station_Code":"Q7 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Tân Mỹ"
    ,"Station_Address":"29, đường Tân Mỹ, Quận 7"
    ,"Lat":10.737343
    ,"Long":106.71833
    ,"Polyline":"[106.71896362,10.73363495] ; [106.71815491,10.73479462] ; [106.71833038,10.73734283]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1373"
    ,"Station_Code":"Q7 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"222, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738384
    ,"Long":106.717485
    ,"Polyline":"[106.71833038,10.73734283] ; [106.71836090,10.73827362] ; [106.71646118,10.73844242]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"4126"
    ,"Station_Code":"Q7 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Mai Văn Vĩnh"
    ,"Station_Address":"57C, đường Mai Văn Vĩnh, Qu ận 7"
    ,"Lat":10.73986
    ,"Long":106.713756
    ,"Polyline":"[106.71646118,10.73844242] ; [106.71372223,10.73855209] ; [106.71373749,10.73983288] ; [106.71379852,10.74022293]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2685"
    ,"Station_Code":"Q7 149"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"đường số 41"
    ,"Station_Address":"9, đường Mai Văn Vĩnh, Quận 7"
    ,"Lat":10.743617
    ,"Long":106.713778
    ,"Polyline":"[106.71379852,10.74022293] ; [106.71376038,10.74199390] ; [106.71377563,10.74361706]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2684"
    ,"Station_Code":"Q7 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"32, đường Đường số 17, Quận 7"
    ,"Lat":10.745025
    ,"Long":106.71315
    ,"Polyline":"[106.71377563,10.74361706] ; [106.71369171,10.74501419] ; [106.71286774,10.74505901]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2686"
    ,"Station_Code":"Q7 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường Lê Thánh Tôn"
    ,"Station_Address":"Trường Lê Thánh Tôn, đường Đường số 17 , Quận 7"
    ,"Lat":10.745025
    ,"Long":106.710591
    ,"Polyline":"[106.71286774,10.74505901] ; [106.71175385,10.74499321] ; [106.71059418,10.74502468]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2688"
    ,"Station_Code":"Q7 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đường Số 15"
    ,"Station_Address":"24 , đường Đường số 15, Quận 7"
    ,"Lat":10.745588
    ,"Long":106.709722
    ,"Polyline":"[106.71059418,10.74502468] ; [106.71017456,10.74499798] ; [106.71015930,10.74558830] ; [106.70975494,10.74560356]"
    ,"Distance":"156"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2689"
    ,"Station_Code":"Q7 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Lê Văn Lương"
    ,"Station_Address":"Ngã 3 Lê Văn Lư ơng, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.72905
    ,"Long":106.699315
    ,"Polyline":"[106.70975494,10.74560356] ; [106.70882416,10.74556255] ; [106.70786285,10.74556732]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2687"
    ,"Station_Code":"Q7 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Tân  Quy"
    ,"Station_Address":"92, đường Đường số 15, Quận 7"
    ,"Lat":10.745557
    ,"Long":106.706488
    ,"Polyline":"[106.70786285,10.74556732] ; [106.70710754,10.74555206] ; [106.70634460,10.74557781]"
    ,"Distance":"166"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2691"
    ,"Station_Code":"Q7 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"TT Y tế Tân  Quy"
    ,"Station_Address":"B9, đường Đường số 15, Quận 7"
    ,"Lat":10.745061
    ,"Long":106.704926
    ,"Polyline":"[106.70634460,10.74557781] ; [106.70565033,10.74554062] ; [106.70562744,10.74506664] ; [106.70471954,10.74505615]"
    ,"Distance":"229"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1453"
    ,"Station_Code":"Q7 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"221, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.745957
    ,"Long":106.704519
    ,"Polyline":"[106.70471954,10.74505615] ; [106.70437622,10.74505138] ; [106.70452881,10.74569130]"
    ,"Distance":"111"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1445"
    ,"Station_Code":"Q7 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Phan Huy  Thục"
    ,"Station_Address":"179, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.748861
    ,"Long":106.704943
    ,"Polyline":"[106.70452881,10.74569130] ; [106.70477295,10.74761200] ; [106.70502472,10.74883747]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1454"
    ,"Station_Code":"Q7 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã 3 T ân Quy"
    ,"Station_Address":"23-25, đường Lê V ăn Lương, Quận 7"
    ,"Lat":10.751468
    ,"Long":106.705124
    ,"Polyline":"[106.70502472,10.74883747] ; [106.70496368,10.74911976] ; [106.70500946,10.74960423] ; [106.70513916,10.75013638] ; [106.70519257,10.75077438] ; [106.70512390,10.75146770]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1988"
    ,"Station_Code":"Q7 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ủy ban Phường Tân Kiểng"
    ,"Station_Address":"525-527, đư ờng Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751728
    ,"Long":106.706874
    ,"Polyline":"[106.70512390,10.75146770] ; [106.70506287,10.75175476] ; [106.70674896,10.75179195]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1990"
    ,"Station_Code":"Q7 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Bế Văn Cấm"
    ,"Station_Address":"429-431, đường Tr ần Xuân Soạn, Quận 7"
    ,"Lat":10.751739
    ,"Long":106.709052
    ,"Polyline":"[106.70674896,10.75179195] ; [106.70805359,10.75177097] ; [106.70903778,10.75169182]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1993"
    ,"Station_Code":"Q7 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Miếu Bà Cố"
    ,"Station_Address":"327, đường Trần Xu ân Soạn, Quận 7"
    ,"Lat":10.751776
    ,"Long":106.71263
    ,"Polyline":"[106.70903778,10.75169182] ; [106.70965576,10.75179195] ; [106.71263885,10.75175762]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1992"
    ,"Station_Code":"Q7 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Nhà thờ Thuận Phát"
    ,"Station_Address":"253, đường Tr ần Xuân Soạn, Quận 7"
    ,"Lat":10.751818
    ,"Long":106.715451
    ,"Polyline":"[106.71263885,10.75175762] ; [106.71406555,10.75182819] ; [106.71544647,10.75179195]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2690"
    ,"Station_Code":"Q7 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Cư xá Ngân hàng"
    ,"Station_Address":"181-183, đường  Trần Xuân Soạn, Quận 7"
    ,"Lat":10.752925
    ,"Long":106.719299
    ,"Polyline":"[106.71544647,10.75179195] ; [106.71583557,10.75184441] ; [106.71643066,10.75185490] ; [106.71704865,10.75186539] ; [106.71735382,10.75190258] ; [106.71769714,10.75200748] ; [106.71929932,10.75292492]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"859"
    ,"Station_Code":"Q7 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Tân Thuận 2"
    ,"Station_Address":"46/14 (chân cầu Tân Thuận 2), đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.752424
    ,"Long":106.723927
    ,"Polyline":"[106.71929932,10.75292492] ; [106.71965027,10.75321960] ; [106.72035217,10.75408459] ; [106.72070313,10.75379467] ; [106.72079468,10.75357819] ; [106.72093964,10.75298309] ; [106.72104645,10.75272942] ; [106.72138214,10.75236607] ; [106.72172546,10.75207138] ; [106.72200012,10.75194931] ; [106.72213745,10.75203419] ; [106.72226715,10.75216579] ; [106.72250366,10.75244999] ; [106.72274780,10.75280380] ; [106.72286224,10.75290394] ; [106.72299194,10.75297737] ; [106.72315216,10.75299835] ; [106.72331238,10.75294018] ; [106.72369385,10.75268269] ; [106.72393036,10.75242424]"
    ,"Distance":"771"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"843"
    ,"Station_Code":"Q7 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"KCX Tân Thuận"
    ,"Station_Address":"Đối diện 49/2, đường Nguyễn Văn Linh,  Quận 7"
    ,"Lat":10.752498
    ,"Long":106.727414
    ,"Polyline":"[106.72393036,10.75242424] ; [106.72424316,10.75226021] ; [106.72480011,10.75187111] ; [106.72537231,10.75216007] ; [106.72597504,10.75237656] ; [106.72630310,10.75246620] ; [106.72662354,10.75252438] ; [106.72730255,10.75254440]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"846"
    ,"Station_Code":"Q7 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Kho 18"
    ,"Station_Address":"267, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.7549
    ,"Long":106.726204
    ,"Polyline":"[106.72730255,10.75254440] ; [106.72855377,10.75261879] ; [106.72855377,10.75299835] ; [106.72848511,10.75357342] ; [106.72841644,10.75386238] ; [106.72822571,10.75419998] ; [106.72793579,10.75438976] ; [106.72763824,10.75453758] ; [106.72711182,10.75471115] ; [106.72620392,10.75489998]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"845"
    ,"Station_Code":"Q7 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Vòng xoay Tân Thuận"
    ,"Station_Address":"135, đường Huỳnh Tấn Phát, Quận 7"
    ,"Lat":10.755423
    ,"Long":106.723946
    ,"Polyline":"[106.72620392,10.75489998] ; [106.72394562,10.75542259]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"848"
    ,"Station_Code":"Q4 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Cảng Sài Gòn"
    ,"Station_Address":"Đối diện 466 , đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.758443
    ,"Long":106.7155
    ,"Polyline":"[106.72394562,10.75542259] ; [106.72333527,10.75553894] ; [106.72270203,10.75506973] ; [106.72261047,10.75502777] ; [106.72251892,10.75500679] ; [106.72238922,10.75501728] ; [106.72227478,10.75506973] ; [106.71977234,10.75627613] ; [106.71646118,10.75783634] ; [106.71549988,10.75844288]"
    ,"Distance":"1036"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"847"
    ,"Station_Code":"Q4 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Nhà thờ Th ánh An Tôn"
    ,"Station_Address":"Đối diện 448 , đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.759771
    ,"Long":106.713241
    ,"Polyline":"[106.71549988,10.75844288] ; [106.71324158,10.75977135]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"850"
    ,"Station_Code":"Q4 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Đại học Nguy ễn Tất Thành"
    ,"Station_Address":"Đối diện 300A , đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.761557
    ,"Long":106.710194
    ,"Polyline":"[106.71324158,10.75977135] ; [106.71019745,10.76155663]"
    ,"Distance":"388"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"849"
    ,"Station_Code":"Q4 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bưu Điện Qu ận 4"
    ,"Station_Address":"75-83, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.707941
    ,"Polyline":"[106.71019745,10.76155663] ; [106.70841217,10.76253700] ; [106.70793915,10.76374435]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"852"
    ,"Station_Code":"Q4 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Xóm  Chiếu"
    ,"Station_Address":"34, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.764983
    ,"Long":106.706471
    ,"Polyline":"[106.70793915,10.76374435] ; [106.70721436,10.76522541] ; [106.70647430,10.76498318]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"851"
    ,"Station_Code":"Q4 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Đoàn Văn B ơ"
    ,"Station_Address":"106-108, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.763744
    ,"Long":106.704031
    ,"Polyline":"[106.70647430,10.76498318] ; [106.70455933,10.76411343] ; [106.70403290,10.76374435]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"854"
    ,"Station_Code":"Q1 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Lê Thị H ồng Gấm"
    ,"Station_Address":"134, đường Calmette , Quận 1"
    ,"Lat":10.769178
    ,"Long":106.698334
    ,"Polyline":"[106.70403290,10.76374435] ; [106.70381927,10.76352787] ; [106.70339203,10.76386547] ; [106.70194244,10.76488781] ; [106.70109558,10.76568890] ; [106.69833374,10.76917839]"
    ,"Distance":"909"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"38"
    ,"Station_Code":"Q1TC1D"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến Thành D"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão , Quận 1"
    ,"Lat":10.770603
    ,"Long":106.698441
    ,"Polyline":"[106.69833374,10.76917839] ; [106.69746399,10.77020550] ; [106.69844055,10.77060318]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ng ũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69844055,10.77060318] ; [106.69898224,10.77082729] ; [106.69898224,10.77116489] ; [106.69892883,10.77133274] ; [106.69884491,10.77149677] ; [106.69882965,10.77160740] ; [106.69879150,10.77171803] ; [106.69872284,10.77181816] ; [106.69861603,10.77191830] ; [106.69847107,10.77194405] ; [106.69832611,10.77192879] ; [106.69821930,10.77187538] ; [106.69812775,10.77180767] ; [106.69805145,10.77165413] ; [106.69803619,10.77149677] ; [106.69806671,10.77136993] ; [106.69814301,10.77124882] ; [106.69733429,10.77028942] ; [106.69595337,10.76980972]"
    ,"Distance":"621"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường L ê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.68957520,10.76720715] ; [106.68936157,10.76767635]"
    ,"Distance":"581"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68922424,10.76815033] ; [106.69033813,10.76855087]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69268799,10.76950932] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69510651,10.77044201] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"853"
    ,"Station_Code":"Q1 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Calmette"
    ,"Station_Address":"87, đường Calmette, Quận 1"
    ,"Lat":10.767768
    ,"Long":106.699219
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69784546,10.77158642] ; [106.69804382,10.77155972] ; [106.69805145,10.77144337] ; [106.69808960,10.77134895] ; [106.69815826,10.77123260] ; [106.69826508,10.77116966] ; [106.69837952,10.77113247] ; [106.69848633,10.77112770] ; [106.69857788,10.77116489] ; [106.69866943,10.77118587] ; [106.69881439,10.77110100] ; [106.69895935,10.77104282] ; [106.69900513,10.77087975] ; [106.69930267,10.77043724] ; [106.69808960,10.76938343] ; [106.69888306,10.76834488] ; [106.69921875,10.76776791]"
    ,"Distance":"759"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"856"
    ,"Station_Code":"Q4 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ Xóm Chiếu"
    ,"Station_Address":"51-53, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.764703
    ,"Long":106.706504
    ,"Polyline":"[106.69921875,10.76776791] ; [106.69974518,10.76718521] ; [106.70098114,10.76561546] ; [106.70168304,10.76490879] ; [106.70378113,10.76337051] ; [106.70466614,10.76403427] ; [106.70635223,10.76465130]"
    ,"Distance":"1022"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"855"
    ,"Station_Code":"Q4 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bưu Điện  Quận 4"
    ,"Station_Address":"136-138, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.76385
    ,"Long":106.70763
    ,"Polyline":"[106.70635223,10.76465130] ; [106.70715332,10.76505661] ; [106.70774078,10.76363373]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"857"
    ,"Station_Code":"Q4 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Đại học Nguy ễn Tất Thành"
    ,"Station_Address":"276, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.7618
    ,"Long":106.70932
    ,"Polyline":"[106.70774078,10.76363373] ; [106.70831299,10.76244831] ; [106.70932007,10.76179981]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"858"
    ,"Station_Code":"Q4 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường Nguy ễn Trãi"
    ,"Station_Address":"428, đường Nguyễn Tất Thành, Quận 4"
    ,"Lat":10.759423
    ,"Long":106.713359
    ,"Polyline":"[106.70932007,10.76179981] ; [106.71109772,10.76081371] ; [106.71272278,10.75982857]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"860"
    ,"Station_Code":"Q4 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cảng Sài  Gòn"
    ,"Station_Address":"456, đường Nguyễn T ất Thành, Quận 4"
    ,"Lat":10.7579
    ,"Long":106.715977
    ,"Polyline":"[106.71272278,10.75982857] ; [106.71546936,10.75819969]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2118"
    ,"Station_Code":"Q7 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Sân bóng đá CLB cảng SG"
    ,"Station_Address":"99/3A, đường Đường vòng cầu Tân Thuận 2, Quận 7"
    ,"Lat":10.752435
    ,"Long":106.72242
    ,"Polyline":"[106.71546936,10.75819969] ; [106.71794891,10.75700951] ; [106.71823883,10.75681400] ; [106.71906281,10.75618172] ; [106.72131348,10.75452137] ; [106.72258759,10.75347328] ; [106.72271729,10.75336742] ; [106.72278595,10.75325680] ; [106.72280121,10.75312519] ; [106.72274017,10.75292969] ; [106.72257996,10.75267696] ; [106.72238922,10.75243855]"
    ,"Distance":"1081"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2117"
    ,"Station_Code":"Q7 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trường mầm non Hoa Sen"
    ,"Station_Address":"Tr ường mầm non Hoa Sen, đường Đường vòng cầu Tân Thuận 2, Quận 7"
    ,"Lat":10.753436
    ,"Long":106.720929
    ,"Polyline":"[106.72238922,10.75243855] ; [106.72231293,10.75228691] ; [106.72217560,10.75209713] ; [106.72206879,10.75205517] ; [106.72196198,10.75204945] ; [106.72186279,10.75207615] ; [106.72172546,10.75213432] ; [106.72143555,10.75237656] ; [106.72109222,10.75275612] ; [106.72099304,10.75313091]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2789"
    ,"Station_Code":"Q7 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Cư xá Ngân hàng"
    ,"Station_Address":"Đối diện 187A , đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.752703
    ,"Long":106.718783
    ,"Polyline":"[106.72099304,10.75313091] ; [106.72084045,10.75363636] ; [106.72074127,10.75382614] ; [106.72036743,10.75417900] ; [106.71958923,10.75327301] ; [106.71949768,10.75320721]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2067"
    ,"Station_Code":"Q7 047"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Nhà thờ Thu ận Phát"
    ,"Station_Address":"Đối diện 253, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751902
    ,"Long":106.715049
    ,"Polyline":"[106.71949768,10.75320721] ; [106.71858978,10.75260830] ; [106.71809387,10.75229740] ; [106.71758270,10.75203419] ; [106.71732330,10.75195980] ; [106.71701050,10.75191784] ; [106.71532440,10.75196743]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2069"
    ,"Station_Code":"Q7 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Miếu Bà  Cố"
    ,"Station_Address":"Đối diện 331, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751886
    ,"Long":106.712512
    ,"Polyline":"[106.71532440,10.75196743] ; [106.71376038,10.75189686] ; [106.71234894,10.75193787]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2068"
    ,"Station_Code":"Q7 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bế Văn C ấm"
    ,"Station_Address":"Đối diện 413, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.751855
    ,"Long":106.709207
    ,"Polyline":"[106.71234894,10.75193787] ; [106.71082306,10.75188160] ; [106.70928955,10.75191975]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2070"
    ,"Station_Code":"Q7 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ủy ban Ph ường Tân Kiểng"
    ,"Station_Address":"Đối diện 505, đường Trần Xuân Soạn, Quận 7"
    ,"Lat":10.75185
    ,"Long":106.706659
    ,"Polyline":"[106.70928955,10.75191975] ; [106.70887756,10.75184917] ; [106.70716095,10.75183105]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1442"
    ,"Station_Code":"Q7 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã 3 Tân Quy"
    ,"Station_Address":"38, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.751333
    ,"Long":106.705018
    ,"Polyline":"[106.70716095,10.75183105] ; [106.70496368,10.75181770] ; [106.70507050,10.75130653]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1448"
    ,"Station_Code":"Q7 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Phan Huy  Thực"
    ,"Station_Address":"148, đường Lê Văn Lương, Qu ận 7"
    ,"Lat":10.748961
    ,"Long":106.704825
    ,"Polyline":"[106.70507050,10.75130653] ; [106.70513916,10.75073242] ; [106.70506287,10.75016308] ; [106.70500946,10.74988937] ; [106.70492554,10.74961472] ; [106.70479584,10.74864292]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1443"
    ,"Station_Code":"Q7 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Quận Đoàn 7"
    ,"Station_Address":"192, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.746068
    ,"Long":106.704422
    ,"Polyline":"[106.70479584,10.74864292] ; [106.70434570,10.74554539]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2807"
    ,"Station_Code":"Q7 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trung tâm y tế Tân Quy"
    ,"Station_Address":"Trạm y tế Tân Quy, đường  Đường số 15, Quận 7"
    ,"Lat":10.744924
    ,"Long":106.704994
    ,"Polyline":"[106.70434570,10.74554539] ; [106.70429993,10.74497700] ; [106.70479584,10.74496651] ; [106.70499420,10.74492359]"
    ,"Distance":"140"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2806"
    ,"Station_Code":"Q7 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ Tân Quy"
    ,"Station_Address":"89, đường Đường số 15, Quận 7"
    ,"Lat":10.7454
    ,"Long":106.706627
    ,"Polyline":"[106.70499420,10.74492359] ; [106.70569611,10.74498272] ; [106.70571899,10.74547291] ; [106.70662689,10.74540043]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2809"
    ,"Station_Code":"Q7 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"đường số 10"
    ,"Station_Address":"15, đường Đường số 15, Quận 7"
    ,"Lat":10.745478
    ,"Long":106.709835
    ,"Polyline":"[106.70662689,10.74540043] ; [106.70785522,10.74547291] ; [106.70944214,10.74543953]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2808"
    ,"Station_Code":"Q7 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"trường Lê Th ánh Tôn"
    ,"Station_Address":"83-85, đường Đường số 17, Quận 7"
    ,"Lat":10.744898
    ,"Long":106.710463
    ,"Polyline":"[106.70944214,10.74543953] ; [106.71010590,10.74551964] ; [106.71012878,10.74490356] ; [106.71034241,10.74487400]"
    ,"Distance":"165"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2811"
    ,"Station_Code":"Q7 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"83, đường Đường số 17, Quận 7"
    ,"Lat":10.744914
    ,"Long":106.713429
    ,"Polyline":"[106.71034241,10.74487400] ; [106.71187592,10.74492455] ; [106.71286774,10.74492455] ; [106.71341705,10.74483967]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2810"
    ,"Station_Code":"Q7 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Đường Số 43"
    ,"Station_Address":"77, đường Mai Văn Vĩnh, Qu ận 7"
    ,"Lat":10.74328
    ,"Long":106.713649
    ,"Polyline":"[106.71341705,10.74483967] ; [106.71365356,10.74493980] ; [106.71366882,10.74392319] ; [106.71360779,10.74369144]"
    ,"Distance":"168"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1997"
    ,"Station_Code":"Q7 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Nguyễn Thị Thập"
    ,"Station_Address":"52A , đường Mai Văn Vĩnh, Quận 7"
    ,"Lat":10.739471
    ,"Long":106.713615
    ,"Polyline":"[106.71360779,10.74369144] ; [106.71368408,10.74195766] ; [106.71366882,10.74058151] ; [106.71361542,10.73947144]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1351"
    ,"Station_Code":"Q7 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Mai Văn Vĩnh"
    ,"Station_Address":"351, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738368
    ,"Long":106.714003
    ,"Polyline":"[106.71361542,10.73947144] ; [106.71365356,10.73935318] ; [106.71365356,10.73874760] ; [106.71368408,10.73842621] ; [106.71439362,10.73831081]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1352"
    ,"Station_Code":"Q7 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Lâm Văn Bền"
    ,"Station_Address":"269-271, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738152
    ,"Long":106.717522
    ,"Polyline":"[106.71439362,10.73831081] ; [106.71595764,10.73828411] ; [106.71768951,10.73808861]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1354"
    ,"Station_Code":"Q7 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ Tân Mỹ"
    ,"Station_Address":"8, đường Tân Mỹ, Quận 7"
    ,"Lat":10.737562
    ,"Long":106.718203
    ,"Polyline":"[106.71768951,10.73808861] ; [106.71779633,10.73815155] ; [106.71827698,10.73814106.06.71822357]"
    ,"Distance":"117"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1353"
    ,"Station_Code":"Q7 151"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Bệnh viện Việt Pháp"
    ,"Station_Address":"Bệnh viện Việt Pháp, đường Nguyễn Lương  Bằng, Quận 7"
    ,"Lat":10.733045
    ,"Long":106.718928
    ,"Polyline":"[106.71822357,10.73768806] ; [106.71798706,10.73479462] ; [106.71863556,10.73352432]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"869"
    ,"Station_Code":"Q7 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Bệnh viện Việt Pháp"
    ,"Station_Address":"Bệnh viện Việt Pháp, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.731063
    ,"Long":106.718912
    ,"Polyline":"[106.71863556,10.73352432] ; [106.71981812,10.73180103] ; [106.71921539,10.73124790] ; [106.71891022,10.73106289]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"865"
    ,"Station_Code":"Q7 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Hưng Vượng"
    ,"Station_Address":"Kế A001, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.729461
    ,"Long":106.714041
    ,"Polyline":"[106.71891022,10.73106289] ; [106.71836090,10.73055744] ; [106.71752930,10.73009872] ; [106.71666718,10.72972393] ; [106.71604919,10.72956085] ; [106.71539307,10.72945023] ; [106.71404266,10.72946072]"
    ,"Distance":"581"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"872"
    ,"Station_Code":"Q7 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Sky Garden"
    ,"Station_Address":"1048 (Kế siêu thị Fivimart), đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.729234
    ,"Long":106.7049
    ,"Polyline":"[106.71404266,10.72946072] ; [106.70951080,10.72926044] ; [106.70490265,10.72923374]"
    ,"Distance":"1000"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"868"
    ,"Station_Code":"Q7 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Đại học RMIT"
    ,"Station_Address":"Trường đại học RMIT, đường Nguyễn Văn Linh, Quận 7"
    ,"Lat":10.728839
    ,"Long":106.695061
    ,"Polyline":"[106.70490265,10.72923374] ; [106.69557953,10.72890186]"
    ,"Distance":"1020"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"873"
    ,"Station_Code":"HBC 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trung Sơn"
    ,"Station_Address":"12-14, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.728649
    ,"Long":106.687267
    ,"Polyline":"[106.69557953,10.72890186] ; [106.69166565,10.72867012] ; [106.68726349,10.72864914]"
    ,"Distance":"910"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"870"
    ,"Station_Code":"HBC 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Ông Bé"
    ,"Station_Address":"Trụ điện  T  NVL 14, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.728586
    ,"Long":106.68334
    ,"Polyline":"[106.68726349,10.72864914] ; [106.68199158,10.72854424]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"875"
    ,"Station_Code":"HBC 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Phạm H ùng"
    ,"Station_Address":"C10/56, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.728467
    ,"Long":106.678581
    ,"Polyline":"[106.68199158,10.72854424] ; [106.68043518,10.72848034] ; [106.67858124,10.72846699]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2812"
    ,"Station_Code":"HBC 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Ấp 4A"
    ,"Station_Address":"C9/4, đường Phạm Hùng, Huyện Bình Chánh"
    ,"Lat":10.729392
    ,"Long":106.676742
    ,"Polyline":"[106.67858124,10.72846699] ; [106.67739868,10.72838020] ; [106.67662048,10.72952938]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2813"
    ,"Station_Code":"HBC 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Chợ Tạm  Ấp 4"
    ,"Station_Address":"Chợ tạm Ấp 4, đường  Phạm Hùng, Huyện Bình Chánh"
    ,"Lat":10.732275
    ,"Long":106.674623
    ,"Polyline":"[106.67662048,10.72952938] ; [106.67462158,10.73227501]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2815"
    ,"Station_Code":"HBC 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Centre Mall"
    ,"Station_Address":"369, đường Phạm Hùng, Huyện Bình Chánh"
    ,"Lat":10.734389
    ,"Long":106.673153
    ,"Polyline":"[106.67462158,10.73227501] ; [106.67291260,10.73468876]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"1985"
    ,"Station_Code":"HBC 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đường số 5"
    ,"Station_Address":"31-33, đường Đường số 5, Huyện Bình Chánh"
    ,"Lat":10.735548
    ,"Long":106.673561
    ,"Polyline":"[106.67291260,10.73468876] ; [106.67266083,10.73503685] ; [106.67354584,10.73558044]"
    ,"Distance":"162"
  },
  {
     "Route_Id":"55"
    ,"Station_Id":"2681"
    ,"Station_Code":"BX 21"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Công viên Đồng Diều"
    ,"Station_Address":"ĐẦU BẾN TRƯỜNG ĐH CN SÀI GÒN, đường Tạ Quang Bửu, Quận 8"
    ,"Lat":10.736787
    ,"Long":106.675819
    ,"Polyline":"[106.67354584,10.73558044] ; [106.67449188,10.73617554] ; [106.67473602,10.73602295] ; [106.67499542,10.73590183] ; [106.67597198,10.73638058] ; [106.67581940,10.73678684]"
    ,"Distance":"354"
  }]