export const Route18 =[
  {
     "Route_Id":"18"
    ,"Station_Id":"1088"
    ,"Station_Code":"BX 71"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hiệp Phước"
    ,"Station_Address":"Bến Hiệp Phước, đường Nguyễn Văn Tạo, Huy ện Nhà Bè"
    ,"Lat":10.602154
    ,"Long":106.741635
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1118"
    ,"Station_Code":"HNB 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Nhà Tưởng niệm Liệt sỹ Nhà Bè"
    ,"Station_Address":"Đối diện Ngh ĩa trang liệt sỹ Nhà Bè, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.604342
    ,"Long":106.741276
    ,"Polyline":"[106.74176025,10.60212994] ; [106.74154663,10.60303974] ; [106.74124908,10.60420036]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1119"
    ,"Station_Code":"HNB 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công an Huyện Nhà Bè"
    ,"Station_Address":"1095 (Cầy tơ Duy Nhất), đường Nguyễn Văn Tạo, Huyện  Nhà Bè"
    ,"Lat":10.609815
    ,"Long":106.740101
    ,"Polyline":"[106.74124908,10.60420036] ; [106.74069214,10.60634995] ; [106.74063873,10.60665035] ; [106.74057007,10.60746002] ; [106.74050140,10.60807037] ; [106.74037170,10.60846043] ; [106.74019623,10.60892963] ; [106.74011230,10.60931015]"
    ,"Distance":"584"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1121"
    ,"Station_Code":"HNB 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Phước Linh"
    ,"Station_Address":"1244  (Cửa sắt Ba Thủy), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.617645
    ,"Long":106.739157
    ,"Polyline":"[106.74002075,10.60980797] ; [106.73966980,10.61166954] ; [106.73954010,10.61236954] ; [106.73951721,10.61270046] ; [106.73940277,10.61511993] ; [106.73935699,10.61565018] ; [106.73931885,10.61579990] ; [106.73906708,10.61760044]"
    ,"Distance":"875"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1120"
    ,"Station_Code":"HNB 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường PTTH Long Thới"
    ,"Station_Address":"Kế 919 (1733), đường Nguy ễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.622153
    ,"Long":106.738159
    ,"Polyline":"[106.73906708,10.61760044] ; [106.73899078,10.61833000] ; [106.73834991,10.62112999] ; [106.73831177,10.62129021] ; [106.73811340,10.62211704]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1122"
    ,"Station_Code":"HNB 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã Tư Long Hậu"
    ,"Station_Address":"849 (280), đường Nguyễn Văn Tạo, Huy ện Nhà Bè"
    ,"Lat":10.6283
    ,"Long":106.736641
    ,"Polyline":"[106.73811340,10.62211704] ; [106.73608398,10.63113308]"
    ,"Distance":"1028"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1123"
    ,"Station_Code":"HNB 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu Đồng Điền"
    ,"Station_Address":"921, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.631169
    ,"Long":106.736104
    ,"Polyline":"[106.73608398,10.63113308] ; [106.73605347,10.63111496]"
    ,"Distance":"4"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1124"
    ,"Station_Code":"HNB 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Hiệp Phước"
    ,"Station_Address":"841, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.63643
    ,"Long":106.734946
    ,"Polyline":"[106.73602295,10.63113976] ; [106.73581696,10.63202000] ; [106.73519897,10.63498974] ; [106.73506927,10.63572025] ; [106.73490906,10.63626003]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1125"
    ,"Station_Code":"HNB 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trung tâm  dạy nghề Nhà Bè"
    ,"Station_Address":"635 (26), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.63477
    ,"Long":106.735337
    ,"Polyline":"[106.73613739,10.63691521] ; [106.73484039,10.63667297] ; [106.73528290,10.63465023]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1126"
    ,"Station_Code":"HNB 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trung tâm dạy nghề Nhà Bè"
    ,"Station_Address":"189, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.643133
    ,"Long":106.732651
    ,"Polyline":"[106.73399353,10.63920021] ; [106.73377228,10.63988018] ; [106.73345184,10.64070034] ; [106.73269653,10.64286041]"
    ,"Distance":"988"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1129"
    ,"Station_Code":"HNB 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Bà Chồi"
    ,"Station_Address":"334B (92), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.647133
    ,"Long":106.731369
    ,"Polyline":"[106.73265076,10.64313316] ; [106.73136902,10.64713287]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1130"
    ,"Station_Code":"HNB 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà máy Đại Sơn"
    ,"Station_Address":"77, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.65008
    ,"Long":106.730488
    ,"Polyline":"[106.73136902,10.64713287] ; [106.73044586,10.64991093]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1127"
    ,"Station_Code":"HNB 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"UBND Xã Long Thới"
    ,"Station_Address":"Kế  205 (155), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.653433
    ,"Long":106.729385
    ,"Polyline":"[106.73044586,10.64991093] ; [106.72938538,10.65343285]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1128"
    ,"Station_Code":"HNB 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Công an  Huyện Nhà Bè"
    ,"Station_Address":"Đối diện CA  H.Nhà Bè, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.657133
    ,"Long":106.728203
    ,"Polyline":"[106.72938538,10.65343285] ; [106.72820282,10.65713310]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1131"
    ,"Station_Code":"HNB 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Hàng Tre"
    ,"Station_Address":"91, đường Nguyễn Văn Tạo , Huyện Nhà Bè"
    ,"Lat":10.663555
    ,"Long":106.726186
    ,"Polyline":"[106.72820282,10.65713310.06.72613525]"
    ,"Distance":"741"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1132"
    ,"Station_Code":"HNB 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Vòng xoay Long Thới"
    ,"Station_Address":"24C-17, đường Nguyễn Văn Tạo, Huyện Nh à Bè"
    ,"Lat":10.66775
    ,"Long":106.72477
    ,"Polyline":"[106.72613525,10.66346741] ; [106.72476959,10.66775036]"
    ,"Distance":"500"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1133"
    ,"Station_Code":"HNB 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cầu Mương Chuối"
    ,"Station_Address":"303/12 (4/39), đường Nguy ễn Bình, Huyện Nhà Bè"
    ,"Lat":10.67165
    ,"Long":106.724533
    ,"Polyline":"[106.72476959,10.66775036] ; [106.72370148,10.67144680] ; [106.72453308,10.67164993]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1134"
    ,"Station_Code":"HNB 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Mương Chuối"
    ,"Station_Address":"525 (13/4), đường Nguyễn Bình, Huyện  Nhà Bè"
    ,"Lat":10.672733
    ,"Long":106.729568
    ,"Polyline":"[106.72453308,10.67164993] ; [106.72956848,10.67273331]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1135"
    ,"Station_Code":"HNB 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"UBND Huyện Nhà Bè"
    ,"Station_Address":"Đối diện UBND H.Nhà Bè, đường Nguyễn Bình, Huyện Nh à Bè"
    ,"Lat":10.67375
    ,"Long":106.734243
    ,"Polyline":"[106.72985840,10.67286968] ; [106.73442078,10.67387962]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1136"
    ,"Station_Code":"HNB 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường tiểu học Nguyễn Bình"
    ,"Station_Address":"Đ/d 274A (1/2), đường Nguyễn Bình, Huy ện Nhà Bè"
    ,"Lat":10.6746
    ,"Long":106.737968
    ,"Polyline":"[106.73445892,10.67374516] ; [106.73796844,10.67459965]"
    ,"Distance":"395"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1137"
    ,"Station_Code":"HNB 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Trường Nguyễn Bình"
    ,"Station_Address":"247 (Trường Nguyễn Bình), đường Nguyễn Bình, Huyện  Nhà Bè"
    ,"Lat":10.675433
    ,"Long":106.741814
    ,"Polyline":"[106.73796844,10.67459965] ; [106.74181366,10.67543316]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1140"
    ,"Station_Code":"HNB 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Nguyễn Bình"
    ,"Station_Address":"290 (209-233), đường Nguyễn Bình, Huyện Nhà Bè"
    ,"Lat":10.67595
    ,"Long":106.744034
    ,"Polyline":"[106.74181366,10.67543316] ; [106.74403381,10.67595005]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1138"
    ,"Station_Code":"HNB 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Nguyễn Bình"
    ,"Station_Address":"91, đường Nguyễn Bình, Huyện Nhà Bè"
    ,"Lat":10.67668
    ,"Long":106.747353
    ,"Polyline":"[106.74403381,10.67595005] ; [106.74735260,10.67667961]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1139"
    ,"Station_Code":"HNB 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã Ba Bờ Đăng"
    ,"Station_Address":"12/11A , đường Nguyễn Bình, Huyện Nhà Bè"
    ,"Lat":10.6776
    ,"Long":106.751465
    ,"Polyline":"[106.74735260,10.67667961] ; [106.75146484,10.67759991]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1141"
    ,"Station_Code":"HNB 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Công Tiến Th ọ"
    ,"Station_Address":"19/8B, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.679507
    ,"Long":106.75071
    ,"Polyline":"[106.75146484,10.67759991] ; [106.75341797,10.67805767] ; [106.75370026,10.67835236] ; [106.75188446,10.67911148] ; [106.75070953,10.67950726]"
    ,"Distance":"616"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1143"
    ,"Station_Code":"HNB 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đào Tông Nguyên"
    ,"Station_Address":"23/3, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.681985
    ,"Long":106.746994
    ,"Polyline":"[106.75070953,10.67950726] ; [106.74968719,10.67981815] ; [106.74807739,10.68053436] ; [106.74745178,10.68125153] ; [106.74699402,10.68198490]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1142"
    ,"Station_Code":"HNB 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Chùa Ph áp Võ"
    ,"Station_Address":"27/1B, đường Huỳnh  Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.684125
    ,"Long":106.745476
    ,"Polyline":"[106.74693298,10.68194008] ; [106.74549103,10.68404007]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1144"
    ,"Station_Code":"HNB 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngân hàng Agribank"
    ,"Station_Address":"18, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.687393
    ,"Long":106.743202
    ,"Polyline":"[106.74543762,10.68410969] ; [106.74487305,10.68488979] ; [106.74382019,10.68644047] ; [106.74327087,10.68721962] ; [106.74311066,10.68743992]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1145"
    ,"Station_Code":"HNB 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trường Nguyễn Bỉnh Khiêm"
    ,"Station_Address":"2213, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.68996
    ,"Long":106.741909
    ,"Polyline":"[106.74311066,10.68743992] ; [106.74266815,10.68805981] ; [106.74243164,10.68844986] ; [106.74228668,10.68879986] ; [106.74205017,10.68943977] ; [106.74192047,10.68980980] ; [106.74192047,10.68982029]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1146"
    ,"Station_Code":"HNB 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trường Lâm Văn Bền"
    ,"Station_Address":"638, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.693397
    ,"Long":106.740723
    ,"Polyline":"[106.74192047,10.68982029] ; [106.74102020,10.69237041]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1148"
    ,"Station_Code":"HNB 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Nha khoa Khánh Minh"
    ,"Station_Address":"1758, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.698273
    ,"Long":106.738996
    ,"Polyline":"[106.74102020,10.69237041] ; [106.74019623,10.69466972] ; [106.73976898,10.69594955]"
    ,"Distance":"421"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1150"
    ,"Station_Code":"HNB 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Công An Thị Trấn Nhà Bè"
    ,"Station_Address":"2049, đường Huỳnh Tấn Phát, Huyện Nhà  Bè"
    ,"Lat":10.695332
    ,"Long":106.740026
    ,"Polyline":"[106.73989868,10.69599056] ; [106.74080658,10.69305992] ; [106.74105072,10.69314957]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1059"
    ,"Station_Code":"HNB 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Phú Xuân"
    ,"Station_Address":"1809 , đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.70114
    ,"Long":106.738315
    ,"Polyline":"[106.74105072,10.69314957] ; [106.74082184,10.69303894] ; [106.73851013,10.69968033] ; [106.73835754,10.70099831]"
    ,"Distance":"957"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1054"
    ,"Station_Code":"BX 18"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Phú Xuân"
    ,"Station_Address":"Bến Phú Xuân, đường Đường  số 15B, Quận 7"
    ,"Lat":10.703697
    ,"Long":106.732317
    ,"Polyline":"[106.73835754,10.70099831] ; [106.73812103,10.70347500] ; [106.73788452,10.70474052] ; [106.73764801,10.70526791] ; [106.73226166,10.70455074] ; [106.73222351,10.70392895]"
    ,"Distance":"1148"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1054"
    ,"Station_Code":"BX 18"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Phú Xuân"
    ,"Station_Address":"Bến Phú Xuân, đường Đường số 15B, Quận 7"
    ,"Lat":10.703697
    ,"Long":106.732317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1055"
    ,"Station_Code":"HNB 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Phú Xu ân"
    ,"Station_Address":"1678-1680 (26/1-26/2), đư ờng Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.701088
    ,"Long":106.73817
    ,"Polyline":"[106.73222351,10.70392895] ; [106.73233032,10.70459270] ; [106.73754120,10.70522499] ; [106.73788452,10.70393944] ; [106.73811340,10.70213699] ; [106.73816681,10.70079994]"
    ,"Distance":"1149"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1147"
    ,"Station_Code":"HNB 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nha khoa Kh ánh Minh"
    ,"Station_Address":"1901B, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.6984
    ,"Long":106.738785
    ,"Polyline":"[106.73816681,10.70079994] ; [106.73816681,10.70079994] ; [106.73845673,10.69941711] ; [106.73878479,10.69839954] ; [106.73878479,10.69839954]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1058"
    ,"Station_Code":"HNB 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Công an Thị trấn Nhà Bè"
    ,"Station_Address":"42/7, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.695869
    ,"Long":106.739666
    ,"Polyline":"[106.73878479,10.69839954] ; [106.73946381,10.69636726]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1061"
    ,"Station_Code":"HNB 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường Lâm Văn Bền"
    ,"Station_Address":"57/4, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.69345
    ,"Long":106.740546
    ,"Polyline":"[106.73953247,10.69639015] ; [106.74069214,10.69309998]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1063"
    ,"Station_Code":"HNB 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chùa Lá"
    ,"Station_Address":"4/11C, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.690113
    ,"Long":106.741694
    ,"Polyline":"[106.74069214,10.69309998] ; [106.74167633,10.69027042]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1060"
    ,"Station_Code":"HNB 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngân hàng  Agribank"
    ,"Station_Address":"2132, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.686992
    ,"Long":106.743314
    ,"Polyline":"[106.74167633,10.69027042] ; [106.74214172,10.68898010.06.74227905] ; [10.68859005,106.74259949] ; [10.68799973,106.74342346]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1065"
    ,"Station_Code":"HNB 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Chùa Tháp Võ"
    ,"Station_Address":"536, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.683998
    ,"Long":106.74538
    ,"Polyline":"[106.74342346,10.68688965] ; [106.74530029,10.68414974]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1062"
    ,"Station_Code":"HNB 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Đào Tông Nguyên"
    ,"Station_Address":"Đối diện 23/3, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.682021
    ,"Long":106.746764
    ,"Polyline":"[106.74530029,10.68414974] ; [106.74678040,10.68200970]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1066"
    ,"Station_Code":"HNB 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công Tiến Thọ"
    ,"Station_Address":"15/6B, đường Huỳnh Tấn Phát, Huyện Nh à Bè"
    ,"Lat":10.679275
    ,"Long":106.750803
    ,"Polyline":"[106.74678802,10.68200016] ; [106.74761200,10.68082047] ; [106.74803162,10.68043041] ; [106.74870300,10.68013000]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1064"
    ,"Station_Code":"HNB 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã Ba Bờ Đăng"
    ,"Station_Address":"12/8H, đường Huỳnh Tấn Phát, Huyện Nhà Bè"
    ,"Lat":10.6784
    ,"Long":106.753196
    ,"Polyline":"[106.74870300,10.68013000] ; [106.75308990,10.67850018]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1069"
    ,"Station_Code":"HNB 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã Ba Bờ Đăng"
    ,"Station_Address":"32, đường Nguyễn Bình, Huyện Nhà Bè"
    ,"Lat":10.67775
    ,"Long":106.751747
    ,"Polyline":"[106.75302124,10.67829990] ; [106.75312042,10.67851543] ; [106.75358582,10.67828941] ; [106.75341034,10.67812061] ; [106.75174713,10.67774963]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1067"
    ,"Station_Code":"HNB 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn B ình"
    ,"Station_Address":"98, đường Nguyễn Bình , Huyện Nhà Bè"
    ,"Lat":10.676867
    ,"Long":106.747803
    ,"Polyline":"[106.75169373,10.67770958] ; [106.74932861,10.67720032]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1071"
    ,"Station_Code":"HNB 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Nguyễn Bình"
    ,"Station_Address":"192 (13/1), đường Nguyễn Bình, Huyện Nhà B è"
    ,"Lat":10.676117
    ,"Long":106.744499
    ,"Polyline":"[106.74780273,10.67686653] ; [106.74449921,10.67611694]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1068"
    ,"Station_Code":"HNB 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Đình Đức Hưng Thạnh"
    ,"Station_Address":"243 ( Đình Đức Hưng Thạnh), đường Nguyễn Bình, Huy ện Nhà Bè"
    ,"Lat":10.67545
    ,"Long":106.741402
    ,"Polyline":"[106.74449921,10.67611694] ; [106.74140167,10.67545033]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1073"
    ,"Station_Code":"HNB 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường tiểu học Nguyễn Bình"
    ,"Station_Address":"Đối diện 269A (Đ/d 1/2C), đường Nguy ễn Bình, Huyện Nhà Bè"
    ,"Lat":10.67475
    ,"Long":106.738251
    ,"Polyline":"[106.74140167,10.67545033] ; [106.73825073,10.67475033]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1070"
    ,"Station_Code":"HNB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Kho bạc Huyện Nhà Bè"
    ,"Station_Address":"UBND Huyện Nhà Bè, đường Nguyễn B ình, Huyện Nhà Bè"
    ,"Lat":10.67385
    ,"Long":106.734154
    ,"Polyline":"[106.73825073,10.67475033] ; [106.73415375,10.67385006]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1075"
    ,"Station_Code":"HNB 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Mương Chuối"
    ,"Station_Address":"486 (17/6), đường Nguyễn Bình, Huyện  Nhà Bè"
    ,"Lat":10.673017
    ,"Long":106.730316
    ,"Polyline":"[106.73415375,10.67385006] ; [106.73031616,10.67301655]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1072"
    ,"Station_Code":"HNB 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Cầu Bà Chiêm"
    ,"Station_Address":"578 (5/12), đường Nguyễn Bình, Huyện Nhà Bè"
    ,"Lat":10.671817
    ,"Long":106.724968
    ,"Polyline":"[106.73031616,10.67301655] ; [106.72496796,10.67181683]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"4161"
    ,"Station_Code":"HNB 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đối diện Bưu điện Long Thới, Nguyễn Văn Tạo"
    ,"Station_Address":"Đối diện Bưu  điện Long Thới, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.670545
    ,"Long":106.72375
    ,"Polyline":"[106.72496796,10.67181683] ; [106.72357178,10.67145157] ; [106.72378540,10.67083263]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1078"
    ,"Station_Code":"HNB 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Phước Kiểng"
    ,"Station_Address":"74, đ ường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.667213
    ,"Long":106.724828
    ,"Polyline":"[106.72378540,10.67083263] ; [106.72457886,10.66703987]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1074"
    ,"Station_Code":"HNB 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nguyễn V ăn Tạo"
    ,"Station_Address":"Đối diện 206, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.663817
    ,"Long":106.725929
    ,"Polyline":"[106.72457886,10.66703987] ; [106.72490692,10.66689205] ; [106.72592926,10.66381741]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1076"
    ,"Station_Code":"HNB 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Công an Nhà Bè"
    ,"Station_Address":"Công an  huyện Nhà Bè, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.65675
    ,"Long":106.728203
    ,"Polyline":"[106.72634888,10.66267967] ; [106.72772217,10.65845966]"
    ,"Distance":"825"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1077"
    ,"Station_Code":"HNB 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cửa hàng vật liệu xây dựng"
    ,"Station_Address":"288 (239), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.6529
    ,"Long":106.729431
    ,"Polyline":"[106.72820282,10.65674973] ; [106.72943115,10.65289974]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1080"
    ,"Station_Code":"HNB 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Bà Ch ồi"
    ,"Station_Address":"372 (Chợ Bà Chồi), đ ường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.650047
    ,"Long":106.730347
    ,"Polyline":"[106.72943115,10.65289974] ; [106.73034668,10.65004730]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1079"
    ,"Station_Code":"HNB 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Đại Sơn"
    ,"Station_Address":"482B, đường Nguyễn Văn T ạo, Huyện Nhà Bè"
    ,"Lat":10.647767
    ,"Long":106.731064
    ,"Polyline":"[106.73034668,10.65004730] ; [106.73106384,10.64776707]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1081"
    ,"Station_Code":"HNB 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trung tâm dạy nghề"
    ,"Station_Address":"568 (Đ/d Trung tâm dạy nghề Nhà Bè ) , đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.642867
    ,"Long":106.732651
    ,"Polyline":"[106.73106384,10.64776707] ; [106.73265076,10.64286709]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1082"
    ,"Station_Code":"HNB 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Dịch vụ  cầm đồ số 4"
    ,"Station_Address":"718, đường  Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.634776
    ,"Long":106.735222
    ,"Polyline":"[106.73265076,10.64286709] ; [106.73522186,10.63477612]"
    ,"Distance":"944"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1085"
    ,"Station_Code":"HNB 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đức Mỹ"
    ,"Station_Address":"780 (116/5), đường Nguyễn Văn Tạo, Huy ện Nhà Bè"
    ,"Lat":10.630992
    ,"Long":106.736023
    ,"Polyline":"[106.73522186,10.63477612] ; [106.73602295,10.63099194]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1084"
    ,"Station_Code":"HNB 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu Đồng Điền"
    ,"Station_Address":"CHVLXD Thành Công , đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.626165
    ,"Long":106.737118
    ,"Polyline":"[106.73602295,10.63099194] ; [106.73722076,10.62619114] ; [106.73693848,10.62608624]"
    ,"Distance":"583"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1087"
    ,"Station_Code":"HNB 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã Tư Long  Hậu"
    ,"Station_Address":"Kế 280 (Cửa sắt Hoàng Cẩn), đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.622538
    ,"Long":106.737912
    ,"Polyline":"[106.73693848,10.62608624] ; [106.73715210,10.62608624] ; [106.73741150,10.62503147] ; [106.73795319,10.62255001]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1086"
    ,"Station_Code":"HNB 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ba Thủy"
    ,"Station_Address":"Đối diện cửa hàng Ba Thủy, đường Nguyễn Văn Tạo, Huy ện Nhà Bè"
    ,"Lat":10.617386
    ,"Long":106.739017
    ,"Polyline":"[106.73795319,10.62255001] ; [106.73861694,10.62001228] ; [106.73906708,10.61738300]"
    ,"Distance":"589"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1089"
    ,"Station_Code":"HNB 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Công an Huyện Nhà Bè"
    ,"Station_Address":"Cột điện 141P, đường Nguyễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.609572
    ,"Long":106.739951
    ,"Polyline":"[106.73934174,10.61573029] ; [106.73940277,10.61536026] ; [106.73944092,10.61421013] ; [106.73954010,10.61236954] ; [106.73996735,10.61005020]"
    ,"Distance":"878"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1091"
    ,"Station_Code":"HNB 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Nhà Tưởng niệm Liệt sỹ Nhà Bè"
    ,"Station_Address":"1/58A, đường Nguyễn Văn T ạo, Huyện Nhà Bè"
    ,"Lat":10.604458
    ,"Long":106.74104
    ,"Polyline":"[106.73996735,10.61005020] ; [106.74019623,10.60892963] ; [106.74047089,10.60818005] ; [106.74051666,10.60797024] ; [106.74060822,10.60682964] ; [106.74069214,10.60634995] ; [106.74107361,10.60488033]"
    ,"Distance":"876"
  },
  {
     "Route_Id":"18"
    ,"Station_Id":"1088"
    ,"Station_Code":"BX 71"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Hiệp Phước"
    ,"Station_Address":"Bến Hiệp Phước, đường Nguy ễn Văn Tạo, Huyện Nhà Bè"
    ,"Lat":10.602154
    ,"Long":106.741635
    ,"Polyline":"[106.74107361,10.60488033] ; [106.74154663,10.60303974] ; [106.74176025,10.60212994]"
    ,"Distance":"631"
  }]