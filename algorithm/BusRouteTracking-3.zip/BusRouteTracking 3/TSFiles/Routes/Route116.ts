export const Route116 =[

  {
     "Route_Id":"116"
    ,"Station_Id":"3719"
    ,"Station_Code":"BX25"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Đền Hùng"
    ,"Station_Address":"BÃI XE ĐỀN HÙNG, đường Đường Số 11- Q9, Qu ận 9"
    ,"Lat":10.875285
    ,"Long":106.825819
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3743"
    ,"Station_Code":"Q9 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đường 11"
    ,"Station_Address":"Hông đường số 13, đường Đường Số 11- Q9, Quận 9"
    ,"Lat":10.875185
    ,"Long":106.81693
    ,"Polyline":"[106.82582092,10.87528515] ; [106.82437897,10.87395763] ; [106.82407379,10.87483215] ; [106.82354736,10.87548542] ; [106.82262421,10.87588596] ; [106.82144928,10.87589645] ; [106.81852722,10.87547493] ; [106.81751251,10.87540054] ; [106.81693268,10.87518501]"
    ,"Distance":"1152"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3742"
    ,"Station_Code":"Q9 267"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã 3 D400"
    ,"Station_Address":"8C5 (Bảo Anh), đường Hoàng Hữu Nam, Quận 9"
    ,"Lat":10.871176
    ,"Long":106.814125
    ,"Polyline":"[106.81809998,10.87524986] ; [106.81758118,10.87516022] ; [106.81665802,10.87504005] ; [106.81616974,10.87495041] ; [106.81585693,10.87481976] ; [106.81546783,10.87452030] ; [106.81503296,10.87399960] ; [106.81501007,10.87397003] ; [106.81488037,10.87345028] ; [106.81429291,10.87115955]"
    ,"Distance":"706"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3745"
    ,"Station_Code":"Q9 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Hoàng Hữu Nam"
    ,"Station_Address":"Đối diện 100, đường D400, Quận 9"
    ,"Lat":10.870689
    ,"Long":106.812386
    ,"Polyline":"[106.81429291,10.87115955] ; [106.81414795,10.87065029] ; [106.81407928,10.87020016] ; [106.81343842,10.87028980] ; [106.81236267,10.87063026]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3744"
    ,"Station_Code":"Q9 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Xa Lộ Hà Nội"
    ,"Station_Address":"Đối diện 28, đường D400, Quận 9"
    ,"Lat":10.871408
    ,"Long":106.809345
    ,"Polyline":"[106.81236267,10.87063026] ; [106.81047821,10.87115002] ; [106.80935669,10.87139988]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"572"
    ,"Station_Code":"QTD 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"621-Ngã 3 Lâm Viên"
    ,"Station_Address":"Nhà máy Tiến Thành, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871128
    ,"Long":106.806979
    ,"Polyline":"[106.80935669,10.87139988] ; [106.80866241,10.87154961] ; [106.80831146,10.87166977] ; [106.80773926,10.87183952] ; [106.80766296,10.87189960] ; [106.80699158,10.87098980] ; [106.80683899,10.87077999]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo dục Quốc phòng, đường Quốc lộ 1, Quận Thủ  Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80683899,10.87077999] ; [106.80651855,10.87038040] ; [106.80586243,10.86958027] ; [106.80507660,10.86878967] ; [106.80455017,10.86830044] ; [106.80441284,10.86816978]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"574"
    ,"Station_Code":"QTD 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Khu DL Suối Tiên"
    ,"Station_Address":"9/29, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86605
    ,"Long":106.801116
    ,"Polyline":"[106.80441284,10.86816978] ; [106.80362701,10.86754036] ; [106.80291748,10.86703968] ; [106.80229950,10.86666012] ; [106.80117798,10.86598015]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"398"
    ,"Station_Code":"QTD 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Khu Công nghệ cao Q9"
    ,"Station_Address":"Đối diện Khu công nghệ cao , đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.860545
    ,"Long":106.791723
    ,"Polyline":"[106.80117798,10.86598015] ; [106.79895020,10.86468029] ; [106.79505920,10.86238003] ; [106.79054260,10.85970020] ; [106.78871155,10.85859013]"
    ,"Distance":"1592"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"401"
    ,"Station_Code":"QTD 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Công ty  Cocacola"
    ,"Station_Address":"Công ty Cocacola, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.856483
    ,"Long":106.784964
    ,"Polyline":"[106.78871155,10.85859013] ; [106.78813934,10.85824966] ; [106.78781128,10.85799980] ; [106.78724670,10.85772991] ; [106.78677368,10.85744953] ; [106.78600311,10.85698032] ; [106.78494263,10.85636997]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1502"
    ,"Station_Code":"Q9 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Siêu thị Coopmark"
    ,"Station_Address":"4-6, đường Lê Văn Việt, Quận  9"
    ,"Lat":10.848192
    ,"Long":106.775032
    ,"Polyline":"[106.78494263,10.85636997] ; [106.78103638,10.85406017] ; [106.77652740,10.85136986] ; [106.77603149,10.85103989] ; [106.77538300,10.85056973] ; [106.77496338,10.85021973] ; [106.77391052,10.84926033] ; [106.77481079,10.84844971] ; [106.77507782,10.84823990]"
    ,"Distance":"1617"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1504"
    ,"Station_Code":"Q9 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh viện 7C-Trường Quân y 2"
    ,"Station_Address":"50, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846262
    ,"Long":106.778124
    ,"Polyline":"[106.77507782,10.84823990] ; [106.77516937,10.84815979] ; [106.77583313,10.84768963] ; [106.77671051,10.84718037] ; [106.77778625,10.84655952] ; [106.77863312,10.84607983]"
    ,"Distance":"457"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1495"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Nhà sách Thành Nghĩa"
    ,"Station_Address":"142-144, đường  Lê Văn Việt, Quận 9"
    ,"Lat":10.84486
    ,"Long":106.780563
    ,"Polyline":"[106.77863312,10.84607983] ; [106.77919769,10.84576035] ; [106.78009033,10.84529972] ; [106.78063202,10.84492970]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1497"
    ,"Station_Code":"Q9 092"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cổng Đình Phong Phú"
    ,"Station_Address":"188, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844114
    ,"Long":106.782028
    ,"Polyline":"[106.78063202,10.84492970] ; [106.78103638,10.84461021] ; [106.78141785,10.84442043] ; [106.78205872,10.84416962]"
    ,"Distance":"179"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1499"
    ,"Station_Code":"Q9 093"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ nh ỏ"
    ,"Station_Address":"278 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844128
    ,"Long":106.784261
    ,"Polyline":"[106.78205872,10.84416962] ; [106.78231049,10.84407997] ; [106.78260040,10.84401035] ; [106.78273010,10.84399986] ; [106.78327179,10.84405994] ; [106.78388214,10.84414959] ; [106.78428650,10.84422016]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3748"
    ,"Station_Code":"Q9 144"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã 3 Lê Văn Việt"
    ,"Station_Address":"28A, đường Man Thiện, Quận 9"
    ,"Lat":10.846004
    ,"Long":106.786761
    ,"Polyline":"[106.78428650,10.84422016] ; [106.78515625,10.84438038] ; [106.78539276,10.84440994] ; [106.78553772,10.84447956] ; [106.78610992,10.84486961] ; [106.78617096,10.84496021] ; [106.78630066,10.84504032] ; [106.78656006,10.84514999] ; [106.78665161,10.84515953] ; [106.78662109,10.84533024] ; [106.78665161,10.84580040] ; [106.78668213,10.84601021]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3746"
    ,"Station_Code":"Q9 143"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Học Vi ện Bưu chính"
    ,"Station_Address":"A1/3 (số 2), đường Man Thiện, Quận 9"
    ,"Lat":10.84859
    ,"Long":106.787383
    ,"Polyline":"[106.78668213,10.84601021] ; [106.78677368,10.84654045] ; [106.78711700,10.84801960] ; [106.78726196,10.84862041]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3747"
    ,"Station_Code":"Q9 142"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường Đảng"
    ,"Station_Address":"Đối diện học viện Chính trị - Hành chính, đường Man Thiện, Quận  9"
    ,"Lat":10.850245
    ,"Long":106.787764
    ,"Polyline":"[106.78726196,10.84862041] ; [106.78764343,10.85023022] ; [106.78769684,10.85058975]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3749"
    ,"Station_Code":"Q9 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chung Cư C3"
    ,"Station_Address":"152, đường Man Thiện, Quận 9"
    ,"Lat":10.853095
    ,"Long":106.791115
    ,"Polyline":"[106.78776550,10.85024548] ; [106.78775787,10.85057926] ; [106.78808594,10.85200977] ; [106.78814697,10.85247326] ; [106.78830719,10.85286999] ; [106.78839874,10.85303211] ; [106.78883362,10.85332680] ; [106.78929901,10.85346413] ; [106.78961945,10.85348511] ; [106.79000854,10.85336876] ; [106.79054260,10.85325336] ; [106.79084015,10.85318947] ; [106.79112244,10.85315037] ; [106.79111481,10.85309505] ; [106.79111481,10.85309505]"
    ,"Distance":"641"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3751"
    ,"Station_Code":"Q9 140"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà nghỉ Thiên Thêu"
    ,"Station_Address":"263-265, đường Man Thiện, Quận 9"
    ,"Lat":10.850469
    ,"Long":106.79554
    ,"Polyline":"[106.79112244,10.85315037] ; [106.79145813,10.85309029] ; [106.79200745,10.85307026] ; [106.79276276,10.85305023] ; [106.79308319,10.85301018] ; [106.79337311,10.85291004] ; [106.79367828,10.85272026] ; [106.79387665,10.85254002] ; [106.79425812,10.85208988] ; [106.79459381,10.85171986] ; [106.79490662,10.85130024] ; [106.79518890,10.85093975] ; [106.79557800,10.85050964]"
    ,"Distance":"611"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3750"
    ,"Station_Code":"Q9 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Chung Cư C5"
    ,"Station_Address":"272, đường Man Thiện, Quận 9"
    ,"Lat":10.847784
    ,"Long":106.798729
    ,"Polyline":"[106.79557800,10.85050964] ; [106.79685211,10.84951019] ; [106.79730988,10.84914017] ; [106.79795074,10.84854984] ; [106.79872131,10.84786034]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1505"
    ,"Station_Code":"Q9 242"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã 3 Nghêu sò"
    ,"Station_Address":"84D, đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.845685
    ,"Long":106.798767
    ,"Polyline":"[106.79872131,10.84786034] ; [106.79902649,10.84755039] ; [106.79918671,10.84733009] ; [106.79933929,10.84710979] ; [106.79949188,10.84673977] ; [106.79859161,10.84650993] ; [106.79882813,10.84570026]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1507"
    ,"Station_Code":"Q9 243"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Khu phố 4"
    ,"Station_Address":"50-52, đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.842879
    ,"Long":106.79838
    ,"Polyline":"[106.79882813,10.84570026] ; [106.79907990,10.84484005] ; [106.79910278,10.84459972] ; [106.79908752,10.84442997] ; [106.79898071,10.84416008] ; [106.79856110,10.84321976] ; [106.79834747,10.84261990]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1510"
    ,"Station_Code":"Q9 244"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã 3 Xóm Bến"
    ,"Station_Address":"Đối diện 17, đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.840382
    ,"Long":106.797184
    ,"Polyline":"[106.79834747,10.84261990] ; [106.79827118,10.84230995] ; [106.79824066,10.84206009] ; [106.79817200,10.84162998] ; [106.79808807,10.84148026] ; [106.79782867,10.84107971] ; [106.79734802,10.84043980] ; [106.79721069,10.84029007] ; [106.79717255,10.84033966]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1509"
    ,"Station_Code":"Q9 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Ga Gia  Đinh"
    ,"Station_Address":"Đối diện Quán Nhà Quê, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.836178
    ,"Long":106.799408
    ,"Polyline":"[106.79717255,10.84033966] ; [106.79721069,10.84029007] ; [106.79714966,10.84023952] ; [106.79698944,10.84012985] ; [106.79675293,10.84000969] ; [106.79640198,10.83990002] ; [106.79659271,10.83975983] ; [106.79734802,10.83924961] ; [106.79749298,10.83915043] ; [106.79773712,10.83885956] ; [106.79833221,10.83804035] ; [106.79884338,10.83718967] ; [106.79946136,10.83621025]"
    ,"Distance":"644"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1512"
    ,"Station_Code":"Q9 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bãi cát"
    ,"Station_Address":"Đối diện 215, đường Lã Xu ân Oai, Quận 9"
    ,"Lat":10.831241
    ,"Long":106.803589
    ,"Polyline":"[106.79946136,10.83621025] ; [106.80043030,10.83481026] ; [106.80071259,10.83428001] ; [106.80113220,10.83355999] ; [106.80123901,10.83341980] ; [106.80136871,10.83333969] ; [106.80213928,10.83304977] ; [106.80245972,10.83292007] ; [106.80262756,10.83279991] ; [106.80281067,10.83261013] ; [106.80348206,10.83154964] ; [106.80364990,10.83127022]"
    ,"Distance":"738"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3752"
    ,"Station_Code":"Q9 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã 3 Lò Lu"
    ,"Station_Address":"81A, đường Lò Lu, Quận 9"
    ,"Lat":10.824436
    ,"Long":106.808472
    ,"Polyline":"[106.80364990,10.83127022] ; [106.80478668,10.82946968] ; [106.80538177,10.82849026] ; [106.80608368,10.82744980] ; [106.80664063,10.82670975] ; [106.80725098,10.82590961] ; [106.80741119,10.82567978] ; [106.80754089,10.82540989] ; [106.80799103,10.82439995] ; [106.80845642,10.82448959]"
    ,"Distance":"954"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3753"
    ,"Station_Code":"Q9 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Tòa Án"
    ,"Station_Address":"Đối diện 77, đường Lò Lu, Quận 9"
    ,"Lat":10.825187
    ,"Long":106.812386
    ,"Polyline":"[106.80845642,10.82448959] ; [106.81237030,10.82524967]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3755"
    ,"Station_Code":"Q9 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trường Mầm non"
    ,"Station_Address":"Đối diện trường mầm non Trường Thạnh, đường Lò Lu, Quận 9"
    ,"Lat":10.825856
    ,"Long":106.815653
    ,"Polyline":"[106.81237030,10.82524967] ; [106.81360626,10.82549000] ; [106.81430054,10.82559013] ; [106.81565857,10.82584953]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3756"
    ,"Station_Code":"Q9 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ Lò Lu"
    ,"Station_Address":"164, đường Lò Lu, Quận 9"
    ,"Lat":10.826298
    ,"Long":106.821104
    ,"Polyline":"[106.81565857,10.82584953] ; [106.81765747,10.82625961] ; [106.81910706,10.82658958] ; [106.81935120,10.82662010.06.81994629] ; [10.82656002,106.82111359]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3757"
    ,"Station_Code":"Q9 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Chùm Chụp"
    ,"Station_Address":"Đối diện trạm Cầu Chùm Chụp, đường Lò Lu, Quận 9"
    ,"Lat":10.824112
    ,"Long":106.826152
    ,"Polyline":"[106.82111359,10.82633018] ; [106.82317352,10.82596016] ; [106.82331085,10.82586002] ; [106.82347870,10.82569981] ; [106.82420349,10.82495022] ; [106.82441711,10.82479954] ; [106.82494354,10.82468033] ; [106.82604980,10.82409954]"
    ,"Distance":"613"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3754"
    ,"Station_Code":"Q9 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Lò Lu"
    ,"Station_Address":"Đối diện cột điện PB 27,  đường Lò Lu, Quận 9"
    ,"Lat":10.824923
    ,"Long":106.829032
    ,"Polyline":"[106.82604980,10.82409954] ; [106.82665253,10.82380962] ; [106.82678223,10.82388973] ; [106.82687378,10.82396984] ; [106.82707977,10.82425022] ; [106.82720184,10.82433987] ; [106.82843018,10.82479954] ; [106.82911682,10.82505035]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3758"
    ,"Station_Code":"Q9 206"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"cây xăng Trường Thạnh"
    ,"Station_Address":"195, đường Nguy ễn Xiển, Quận 9"
    ,"Lat":10.823353
    ,"Long":106.830475
    ,"Polyline":"[106.82911682,10.82505035] ; [106.82978058,10.82528973] ; [106.83054352,10.82338047]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3759"
    ,"Station_Code":"Q9 205"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Đường số 9"
    ,"Station_Address":"Đối diện cột điện PD38, đường Nguyễn Xiển , Quận 9"
    ,"Lat":10.818943
    ,"Long":106.832213
    ,"Polyline":"[106.83054352,10.82338047] ; [106.83229065,10.81898975]"
    ,"Distance":"524"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3760"
    ,"Station_Code":"Q9 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã 3 Long Thuận"
    ,"Station_Address":"15, đường Nguyễn Xiển, Quận 9"
    ,"Lat":10.815107
    ,"Long":106.833732
    ,"Polyline":"[106.83229065,10.81898975] ; [106.83381653,10.81513023]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3761"
    ,"Station_Code":"Q9 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã 3 Long Thuận"
    ,"Station_Address":"Cột điện 6,  đường Long Thuận, Quận 9"
    ,"Lat":10.814425
    ,"Long":106.834999
    ,"Polyline":"[106.83381653,10.81513023] ; [106.83412933,10.81435966] ; [106.83421326,10.81435966] ; [106.83499146,10.81447029]"
    ,"Distance":"187"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3763"
    ,"Station_Code":"Q9 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Trường Phước"
    ,"Station_Address":"116/A, đường Long Thuận, Quận 9"
    ,"Lat":10.811874
    ,"Long":106.843163
    ,"Polyline":"[106.83499146,10.81447029] ; [106.83782959,10.81488037] ; [106.83801270,10.81486988] ; [106.83818817,10.81484985] ; [106.83837128,10.81478977] ; [106.83851624,10.81470013] ; [106.83924103,10.81396008] ; [106.83957672,10.81371021] ; [106.84097290,10.81285000] ; [106.84224701,10.81215000] ; [106.84316254,10.81194019] ; [106.84317017,10.81194019]"
    ,"Distance":"996"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3762"
    ,"Station_Code":"Q9 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"phim tr ường"
    ,"Station_Address":"Cột điện PDA40, đường Long Thuận, Quận 9"
    ,"Lat":10.811287
    ,"Long":106.84671
    ,"Polyline":"[106.84317017,10.81194019] ; [106.84409332,10.81175995] ; [106.84671783,10.81134987]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3764"
    ,"Station_Code":"Q9 126"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trại nh ím"
    ,"Station_Address":"220, đường Long Thuận, Quận 9"
    ,"Lat":10.811619
    ,"Long":106.853827
    ,"Polyline":"[106.84671783,10.81134987] ; [106.84745789,10.81124020] ; [106.84803772,10.81128025] ; [106.85379028,10.81161022]"
    ,"Distance":"775"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3766"
    ,"Station_Code":"Q9 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã 3 Long Phước"
    ,"Station_Address":"322-324, đường Long Thuận, Quận 9"
    ,"Lat":10.811961
    ,"Long":106.859035
    ,"Polyline":"[106.85379028,10.81161022] ; [106.85855865,10.81190968] ; [106.85897827,10.81194973]"
    ,"Distance":"568"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3765"
    ,"Station_Code":"Q9 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Trường  tiểu học Long Phước"
    ,"Station_Address":"Trường Tiểu học Long Phước, đường Long Phước, Quận 9"
    ,"Lat":10.811131
    ,"Long":106.859474
    ,"Polyline":"[106.85897827,10.81194973] ; [106.85981750,10.81200981] ; [106.85968781,10.81161976] ; [106.85954285,10.81110954]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3768"
    ,"Station_Code":"Q9 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ Long Phước"
    ,"Station_Address":"Đầu bến tuyến 88, đường Long Phước, Quận 9"
    ,"Lat":10.808194
    ,"Long":106.859556
    ,"Polyline":"[106.85954285,10.81110954] ; [106.85929871,10.81033039] ; [106.85916138,10.80976963] ; [106.85916138,10.80957031] ; [106.85942078,10.80877018] ; [106.85962677,10.80813980]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3767"
    ,"Station_Code":"Q9 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"ngã 3 đường số 9"
    ,"Station_Address":"Đối diện 413, đư ờng Long Phước, Quận 9"
    ,"Lat":10.805101
    ,"Long":106.858971
    ,"Polyline":"[106.85962677,10.80813980] ; [106.85968018,10.80793953] ; [106.85932922,10.80642986] ; [106.85904694,10.80508995]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3692"
    ,"Station_Code":"BX26"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Long Phước"
    ,"Station_Address":"ĐẦU BẾN HẺM 813 LONG PHƯỚC , đường Long Thuận, Quận 9"
    ,"Lat":10.789044
    ,"Long":106.860107
    ,"Polyline":"[106.85904694,10.80508995] ; [106.85852051,10.80253029] ; [106.85865021,10.80002022] ; [106.85877991,10.79798031] ; [106.85900879,10.79549026] ; [106.85897827,10.79434967] ; [106.86026764,10.79119968] ; [106.86025238,10.79098034] ; [106.85997009,10.79026031] ; [106.85961151,10.78956032] ; [106.85954285,10.78915024]"
    ,"Distance":"1825"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3692"
    ,"Station_Code":"BX26"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Long Phước"
    ,"Station_Address":"ĐẦU BẾN HẺM 813 LONG PHƯỚC, đường Long Thuận, Quận 9"
    ,"Lat":10.789044
    ,"Long":106.860107
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3693"
    ,"Station_Code":"Q9 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"ngã 3 đường số 9"
    ,"Station_Address":"413, đường Long Phước, Quận 9"
    ,"Lat":10.805248
    ,"Long":106.859146
    ,"Polyline":"[106.85954285,10.78915024] ; [106.85961151,10.78956032] ; [106.85997009,10.79026031] ; [106.86025238,10.79098034] ; [106.86026764,10.79119968] ; [106.85897827,10.79434967] ; [106.85900879,10.79549026] ; [106.85877991,10.79798031] ; [106.85865021,10.80002022] ; [106.85852051,10.80253029] ; [106.85909271,10.80525970]"
    ,"Distance":"1844"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3695"
    ,"Station_Code":"Q9 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Chợ Long  Phước"
    ,"Station_Address":"Chợ Long Phước, đường Long Phước, Quận 9"
    ,"Lat":10.808594
    ,"Long":106.859583
    ,"Polyline":"[106.85909271,10.80525970] ; [106.85932922,10.80642986] ; [106.85968018,10.80793953] ; [106.85964203,10.80809975]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3694"
    ,"Station_Code":"Q9 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Nhà bia tưởng niệm"
    ,"Station_Address":"Nhà bia tưởng  niệm, đường Long Phước, Quận 9"
    ,"Lat":10.81038
    ,"Long":106.859411
    ,"Polyline":"[106.85964203,10.80809975] ; [106.85920715,10.80937958] ; [106.85916138,10.80957031] ; [106.85916138,10.80976963] ; [106.85932159,10.81040001]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3696"
    ,"Station_Code":"Q9 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã 3 Long  Phước"
    ,"Station_Address":"281, đường Long Thuận, Quận 9"
    ,"Lat":10.812077
    ,"Long":106.859041
    ,"Polyline":"[106.85932159,10.81040001] ; [106.85968781,10.81161976] ; [106.85981750,10.81200981] ; [106.85906982,10.81194973]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3698"
    ,"Station_Code":"Q9 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Trại nhím"
    ,"Station_Address":"Đối diện 216, đường Long Thuận, Quận 9"
    ,"Lat":10.811729
    ,"Long":106.853371
    ,"Polyline":"[106.85906982,10.81194973] ; [106.85529327,10.81169033] ; [106.85337067,10.81157970]"
    ,"Distance":"624"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3697"
    ,"Station_Code":"Q9 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"phim trường"
    ,"Station_Address":"Đối diện 168, đường Long Thuận, Quận 9"
    ,"Lat":10.81146
    ,"Long":106.846359
    ,"Polyline":"[106.85337067,10.81157970] ; [106.84745789,10.81124020] ; [106.84635162,10.81140995]"
    ,"Distance":"770"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3700"
    ,"Station_Code":"Q9 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Trường Phước"
    ,"Station_Address":"Đối diện 116/A, đường Long Thuận, Quận 9"
    ,"Lat":10.812019
    ,"Long":106.842964
    ,"Polyline":"[106.84635162,10.81140995] ; [106.84409332,10.81175995] ; [106.84316254,10.81194019] ; [106.84288025,10.81200981]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3699"
    ,"Station_Code":"Q9 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cầu Long Thuận"
    ,"Station_Address":"51, đường Long Thuận, Quận 9"
    ,"Lat":10.814543
    ,"Long":106.834939
    ,"Polyline":"[106.84288025,10.81200981] ; [106.84224701,10.81215000] ; [106.84097290,10.81285000] ; [106.83957672,10.81371021] ; [106.83924103,10.81396008] ; [106.83851624,10.81470013] ; [106.83837128,10.81478977] ; [106.83818817,10.81484985] ; [106.83801270,10.81486988] ; [106.83782959,10.81488037] ; [106.83466339,10.81443024]"
    ,"Distance":"1000"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3701"
    ,"Station_Code":"Q9 209"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 3 Long Thuận"
    ,"Station_Address":"16, đường Nguyễn Xiển, Quận 9"
    ,"Lat":10.815012
    ,"Long":106.833931
    ,"Polyline":"[106.83466339,10.81443024] ; [106.83412933,10.81435966] ; [106.83387756,10.81499004]"
    ,"Distance":"133"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3702"
    ,"Station_Code":"Q9 208"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đường số 9"
    ,"Station_Address":"Cột điện PD38, đường Nguyễn Xiển, Quận 9"
    ,"Lat":10.819264
    ,"Long":106.832237
    ,"Polyline":"[106.83387756,10.81499004] ; [106.83219147,10.81925011]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3703"
    ,"Station_Code":"Q9 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"cây xăng Trường Thạnh"
    ,"Station_Address":"198 , đường Nguyễn Xiển, Quận 9"
    ,"Lat":10.823674
    ,"Long":106.830482
    ,"Polyline":"[106.83219147,10.81925011] ; [106.83042908,10.82365990]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3704"
    ,"Station_Code":"Q9 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Lò Lu"
    ,"Station_Address":"Cột điện PB 28, đường Lò Lu , Quận 9"
    ,"Lat":10.825013
    ,"Long":106.828857
    ,"Polyline":"[106.83042908,10.82365990] ; [106.82978058,10.82528973] ; [106.82887268,10.82497025]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3705"
    ,"Station_Code":"Q9 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu Chùm Chụp"
    ,"Station_Address":"Trạm cầu Chùm Chụp, đường Lò Lu, Quận 9"
    ,"Lat":10.82437
    ,"Long":106.825921
    ,"Polyline":"[106.82887268,10.82497025] ; [106.82776642,10.82454967] ; [106.82720184,10.82433987] ; [106.82707977,10.82425022] ; [106.82678223,10.82388973] ; [106.82665253,10.82380962] ; [106.82624054,10.82400036] ; [106.82579803,10.82421970]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3706"
    ,"Station_Code":"Q9 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Ph ước Long"
    ,"Station_Address":"Đối diện 164, đường Lò Lu, Quận 9"
    ,"Lat":10.826504
    ,"Long":106.820846
    ,"Polyline":"[106.82579803,10.82421970] ; [106.82494354,10.82468033] ; [106.82441711,10.82479954] ; [106.82420349,10.82495022] ; [106.82347870,10.82569981] ; [106.82331085,10.82586002] ; [106.82317352,10.82596016] ; [106.82209015,10.82614040] ; [106.82093048,10.82637024]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3707"
    ,"Station_Code":"Q9 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Mầm non"
    ,"Station_Address":"Trường mầm non Trường Thạnh, đường Lò Lu,  Quận 9"
    ,"Lat":10.826093
    ,"Long":106.816083
    ,"Polyline":"[106.82093048,10.82637024] ; [106.81994629,10.82656002] ; [106.81954956,10.82660961] ; [106.81922913,10.82660961] ; [106.81800842,10.82633972] ; [106.81691742,10.82610989] ; [106.81613922,10.82594967]"
    ,"Distance":"534"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3708"
    ,"Station_Code":"Q9 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã 3 Lò Lu"
    ,"Station_Address":"35, đường Lò Lu, Quận 9"
    ,"Lat":10.824618
    ,"Long":106.808717
    ,"Polyline":"[106.81613922,10.82594967] ; [106.81510162,10.82573986] ; [106.81430054,10.82559013] ; [106.81360626,10.82549000] ; [106.80872345,10.82454014]"
    ,"Distance":"826"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1524"
    ,"Station_Code":"Q9 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã ba Lò Lu"
    ,"Station_Address":"215, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.830471
    ,"Long":106.804351
    ,"Polyline":"[106.80872345,10.82454014] ; [106.80799103,10.82439995] ; [106.80783844,10.82474995] ; [106.80741119,10.82567978] ; [106.80709839,10.82612038] ; [106.80653381,10.82684040] ; [106.80608368,10.82744980] ; [106.80538177,10.82849026] ; [106.80478668,10.82946968] ; [106.80413818,10.83047962] ; [106.80339050,10.83170033]"
    ,"Distance":"1039"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1529"
    ,"Station_Code":"Q9 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Cơ sở h ạt điều"
    ,"Station_Address":"Quán Nhà Quê, đường Lã Xuân Oai, Quận 9"
    ,"Lat":10.836525
    ,"Long":106.799362
    ,"Polyline":"[106.80339050,10.83170033] ; [106.80281067,10.83261013] ; [106.80262756,10.83279991] ; [106.80245972,10.83292007] ; [106.80213928,10.83304977] ; [106.80136871,10.83333969] ; [106.80123901,10.83341980] ; [106.80113220,10.83355999] ; [106.80071259,10.83428001] ; [106.80043030,10.83481026] ; [106.80013275,10.83522987] ; [106.79927826,10.83648014]"
    ,"Distance":"719"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1526"
    ,"Station_Code":"Q9 239"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã 3 Xóm Bến"
    ,"Station_Address":"7, đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.839997
    ,"Long":106.79684
    ,"Polyline":"[106.79927826,10.83648014] ; [106.79833221,10.83804035] ; [106.79773712,10.83885956] ; [106.79749298,10.83915043] ; [106.79711151,10.83942032] ; [106.79640198,10.83990002] ; [106.79675293,10.84000969] ; [106.79689789,10.84008026]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1531"
    ,"Station_Code":"Q9 240"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Khu phố 4"
    ,"Station_Address":"51 , đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.842611
    ,"Long":106.798444
    ,"Polyline":"[106.79689789,10.84008026] ; [106.79714966,10.84023952] ; [106.79724121,10.84031963] ; [106.79743958,10.84055996] ; [106.79794312,10.84123039] ; [106.79814911,10.84156990] ; [106.79818726,10.84171009] ; [106.79826355,10.84222984] ; [106.79833221,10.84255028]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1528"
    ,"Station_Code":"Q9 241"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã 3 Ngh êu sò"
    ,"Station_Address":"Đối diện 15/369, đường Làng Tăng Phú, Quận 9"
    ,"Lat":10.846004
    ,"Long":106.798847
    ,"Polyline":"[106.79833221,10.84255028] ; [106.79844666,10.84290981] ; [106.79871368,10.84356976] ; [106.79904938,10.84436035] ; [106.79910278,10.84451962] ; [106.79910278,10.84471989] ; [106.79901123,10.84510040] ; [106.79875183,10.84599018]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3185"
    ,"Station_Code":"BX 30"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Khu Công Nghệ cao"
    ,"Station_Address":"ĐẦU BẾN KCN CAO QUẬN 9, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.847352
    ,"Long":106.799606
    ,"Polyline":"[106.79875183,10.84599018] ; [106.79859161,10.84650993] ; [106.79871368,10.84654045] ; [106.79949188,10.84673977] ; [106.79933929,10.84710979] ; [106.79930878,10.84716034]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3709"
    ,"Station_Code":"Q9 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Chung Cư C5"
    ,"Station_Address":"Đối diện 260-262, đường Man Thiện, Quận 9"
    ,"Lat":10.848179
    ,"Long":106.798546
    ,"Polyline":"[106.79930878,10.84716034] ; [106.79904938,10.84751987] ; [106.79888916,10.84770012] ; [106.79843140,10.84811974]"
    ,"Distance":"144"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3710"
    ,"Station_Code":"Q9 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nhà nghỉ Thiên Thêu"
    ,"Station_Address":"Đối diện 355-357, đường Man Thiện, Quận 9"
    ,"Lat":10.850772
    ,"Long":106.795515
    ,"Polyline":"[106.79843140,10.84811974] ; [106.79730988,10.84914017] ; [106.79643250,10.84984970] ; [106.79570007,10.85041046] ; [106.79541779,10.85068035]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3711"
    ,"Station_Code":"Q9 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chung C ư C3"
    ,"Station_Address":"253-255 , đường Man Thiện, Quận 9"
    ,"Lat":10.8533
    ,"Long":106.790886
    ,"Polyline":"[106.79541779,10.85068035] ; [106.79498291,10.85120010.06.79459381] ; [10.85171986,106.79409027] ; [10.85231018,106.79376984] ; [10.85264969,106.79351044] ; [10.85282040,106.79322052] ; [10.85297012,106.79295349] ; [10.85303020,106.79241943] ; [10.85305977,106.79145813] ; [10.85309029,106.79087830]"
    ,"Distance":"612"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3712"
    ,"Station_Code":"Q9 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường Đảng"
    ,"Station_Address":"Học viện Chính trị - Hành chính, đường Man Thiện, Quận 9"
    ,"Lat":10.850761
    ,"Long":106.787721
    ,"Polyline":"[106.79088593,10.85330009] ; [106.79089355,10.85326099] ; [106.79087830,10.85319996] ; [106.79054260,10.85329533] ; [106.79002380,10.85341072] ; [106.78968811,10.85352707] ; [106.78916931,10.85353756] ; [106.78885651,10.85343170] ; [106.78852844,10.85321045] ; [106.78832245,10.85298920] ; [106.78816986,10.85268021] ; [106.78807068,10.85247040] ; [106.78795624,10.85204029] ; [106.78774261,10.85085964] ; [106.78768158,10.85086632] ; [106.78771973,10.85076141]"
    ,"Distance":"583"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3713"
    ,"Station_Code":"Q9 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Học Viện Bưu chính"
    ,"Station_Address":"Học viện CN BC-VT, đường Man Thiện, Quận 9"
    ,"Lat":10.848164
    ,"Long":106.787147
    ,"Polyline":"[106.78774261,10.85085964] ; [106.78764343,10.85023022] ; [106.78716278,10.84815025]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3714"
    ,"Station_Code":"Q9 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã 3 Lê Văn Việt"
    ,"Station_Address":"19-21, đường Man Thiện, Quận 9"
    ,"Lat":10.845593
    ,"Long":106.786605
    ,"Polyline":"[106.78716278,10.84815025] ; [106.78668976,10.84615993] ; [106.78663635,10.84558010]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1537"
    ,"Station_Code":"Q9 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ nhỏ"
    ,"Station_Address":"249, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.84427
    ,"Long":106.784084
    ,"Polyline":"[106.78663635,10.84558010.06.78662109] ; [10.84533024,106.78665161] ; [10.84515953,106.78656006] ; [10.84514999,106.78630066] ; [10.84504032,106.78617096] ; [10.84496021,106.78610992] ; [10.84486961,106.78553772] ; [10.84447956,106.78539276] ; [10.84440994,106.78515625] ; [10.84438038,106.78472137] ; [10.84430027,106.78407288]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1534"
    ,"Station_Code":"Q9 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cổng đình Phong Phú"
    ,"Station_Address":"189-191, đường  Lê Văn Việt, Quận 9"
    ,"Lat":10.844381
    ,"Long":106.781723
    ,"Polyline":"[106.78407288,10.84418964] ; [106.78273010,10.84399986] ; [106.78231049,10.84407997] ; [106.78182220,10.84426975]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1536"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Siêu thị Thành Nghĩa"
    ,"Station_Address":"Đối diện 140-142, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845176
    ,"Long":106.780377
    ,"Polyline":"[106.78182220,10.84426975] ; [106.78141785,10.84442043] ; [106.78103638,10.84461021] ; [106.78050232,10.84504032] ; [106.78038025,10.84512043]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1539"
    ,"Station_Code":"Q9 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh viện 7C-Trường Quân y 2"
    ,"Station_Address":"91-93, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846799
    ,"Long":106.777512
    ,"Polyline":"[106.78038025,10.84512043] ; [106.78009033,10.84529972] ; [106.77919769,10.84576035] ; [106.77778625,10.84655952] ; [106.77747345,10.84673977]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"1538"
    ,"Station_Code":"Q9 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Siêu th ị Coopmark"
    ,"Station_Address":"17-19, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.848411
    ,"Long":106.775045
    ,"Polyline":"[106.77747345,10.84673977] ; [106.77583313,10.84768963] ; [106.77510071,10.84823036] ; [106.77494812,10.84834003]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"494"
    ,"Station_Code":"Q9 218"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Công an Quận 9"
    ,"Station_Address":"Công an Quận 9, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.849966
    ,"Long":106.775066
    ,"Polyline":"[106.77494812,10.84834003] ; [106.77467346,10.84858036] ; [106.77449799,10.84887981] ; [106.77445221,10.84908009] ; [106.77446747,10.84920979] ; [106.77458191,10.84947968] ; [106.77507019,10.84990025]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"498"
    ,"Station_Code":"Q9 219"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ chiều"
    ,"Station_Address":"Kế 830 (Chợ Chiều), đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.853511
    ,"Long":106.780474
    ,"Polyline":"[106.77507019,10.84990025] ; [106.77549744,10.85027981] ; [106.77593994,10.85058975] ; [106.77648926,10.85103989] ; [106.77693939,10.85134983] ; [106.77751923,10.85171032] ; [106.77758026,10.85181999] ; [106.77851105,10.85239029] ; [106.78000641,10.85330963] ; [106.78044128,10.85358047]"
    ,"Distance":"718"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"495"
    ,"Station_Code":"Q9 220"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Khu Công nghệ cao quận 9"
    ,"Station_Address":"Khu  công nghệ cao, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.858511
    ,"Long":106.788869
    ,"Polyline":"[106.78044128,10.85358047] ; [106.78164673,10.85431957] ; [106.78484344,10.85618973] ; [106.78681946,10.85729027] ; [106.78800201,10.85803032] ; [106.78878784,10.85851002]"
    ,"Distance":"1065"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"536"
    ,"Station_Code":"Q9 221"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Cầu Vư ợt Trạm 2"
    ,"Station_Address":"Tiệm vàng Kim Lợi, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.863595
    ,"Long":106.797538
    ,"Polyline":"[106.78878784,10.85851002] ; [106.79067230,10.85966969] ; [106.79197693,10.86044979] ; [106.79512024,10.86227989] ; [106.79592896,10.86273956] ; [106.79680634,10.86328030] ; [106.79727936,10.86357021]"
    ,"Distance":"1085"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"537"
    ,"Station_Code":"Q9 223"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Suối Ti ên"
    ,"Station_Address":"Suối Tiên, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.866498
    ,"Long":106.802377
    ,"Polyline":"[106.79730988,10.86359024] ; [106.80146790,10.86606026] ; [106.80248260,10.86666965]"
    ,"Distance":"661"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3715"
    ,"Station_Code":"Q9 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Xa Lộ H à Nội"
    ,"Station_Address":"14-18, đường D400, Quận 9"
    ,"Lat":10.871371
    ,"Long":106.809028
    ,"Polyline":"[106.80248260,10.86666965] ; [106.80357361,10.86740971] ; [106.80422211,10.86791039] ; [106.80460358,10.86822987] ; [106.80522156,10.86880016] ; [106.80615997,10.86979008] ; [106.80673218,10.87049007] ; [106.80764008,10.87172031] ; [106.80773926,10.87183952] ; [106.80831146,10.87166977] ; [106.80866241,10.87154961] ; [106.80905151,10.87147045]"
    ,"Distance":"968"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3716"
    ,"Station_Code":"Q9 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Hoàng Hữu Nam"
    ,"Station_Address":"124, đường D400, Quận 9"
    ,"Lat":10.87037
    ,"Long":106.812891
    ,"Polyline":"[106.80905151,10.87147045] ; [106.81047821,10.87115002] ; [106.81136322,10.87090015] ; [106.81210327,10.87071037] ; [106.81291962,10.87045002]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3717"
    ,"Station_Code":"Q9 266"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã 3 D400"
    ,"Station_Address":"kế 474, đường Hoàng Hữu Nam, Quận 9"
    ,"Lat":10.87185
    ,"Long":106.814522
    ,"Polyline":"[106.81291962,10.87045002] ; [106.81343842,10.87028980] ; [106.81405640,10.87020016] ; [106.81407928,10.87020016] ; [106.81414795,10.87065029] ; [106.81443024,10.87170029]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3718"
    ,"Station_Code":"Q9 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Đường 11"
    ,"Station_Address":"34, đường Đư ờng Số 11- Q9, Quận 9"
    ,"Lat":10.875336
    ,"Long":106.819046
    ,"Polyline":"[106.81443024,10.87170029] ; [106.81488037,10.87345028] ; [106.81501007,10.87397003] ; [106.81503296,10.87399960] ; [106.81546783,10.87452030] ; [106.81585693,10.87481976] ; [106.81616974,10.87495041] ; [106.81665802,10.87504005] ; [106.81758118,10.87516022] ; [106.81903839,10.87539005]"
    ,"Distance":"748"
  },
  {
     "Route_Id":"116"
    ,"Station_Id":"3719"
    ,"Station_Code":"BX25"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Đền Hùng"
    ,"Station_Address":"BÃI XE ĐỀN HÙNG, đường Đư ờng Số 11- Q9, Quận 9"
    ,"Lat":10.875285
    ,"Long":106.825819
    ,"Polyline":"[106.81904602,10.87533569] ; [106.82064056,10.87560081] ; [106.82218933,10.87578011] ; [106.82278442,10.87564278] ; [106.82336426,10.87537956] ; [106.82395172,10.87469482] ; [106.82440186,10.87372589] ; [106.82490540,10.87605381] ; [106.82482147,10.87717056] ; [106.82572937,10.87929916] ; [106.82651520,10.88143826] ; [106.82654572,10.88168049] ; [106.82648468,10.88195419] ; [106.82434845,10.88359833] ; [106.82415771,10.88405132] ; [106.82402802,10.88400841] ; [106.82430267,10.88340855] ; [106.82630157,10.88190174] ; [106.82643890,10.88157463] ; [106.82531738,10.87871933] ; [106.82463837,10.87718105] ; [106.82469940,10.87576962] ; [106.82582092,10.87528515]"
    ,"Distance":"3233"
  }]