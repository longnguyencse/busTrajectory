export const Route125 =[

  {
     "Route_Id":"125"
    ,"Station_Id":"2227"
    ,"Station_Code":"BX 39"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Cầu Lớn"
    ,"Station_Address":"BÃI XE CẦU LỚN, đường Nguyễn Văn Bứa, Huyện H óc Môn"
    ,"Lat":10.871845
    ,"Long":106.535561
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3967"
    ,"Station_Code":"HHM 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường Nhị Xuân"
    ,"Station_Address":"Đối diện trường Nhị Xuân, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.871492
    ,"Long":106.536076
    ,"Polyline":"[106.53491974,10.87216663] ; [106.53488159,10.87188148] ; [106.53613281,10.87164974] ; [106.53607941,10.87149239]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2225"
    ,"Station_Code":"HHM 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm lò muối"
    ,"Station_Address":"23 - 25,  đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.870512
    ,"Long":106.542031
    ,"Polyline":"[106.53607941,10.87149239] ; [106.54203033,10.87051201]"
    ,"Distance":"660"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2223"
    ,"Station_Code":"HHM 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Nguyễn V ăn Bứa"
    ,"Station_Address":"Đối diện 46B, đư ờng Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.869279
    ,"Long":106.550281
    ,"Polyline":"[106.54203033,10.87051201] ; [106.55027771,10.86927891]"
    ,"Distance":"912"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2276"
    ,"Station_Code":"HHM 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường PTTH  Nguyễn Văn Cừ"
    ,"Station_Address":"Trường Nguyễn Văn Cừ, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.868463
    ,"Long":106.555892
    ,"Polyline":"[106.55027771,10.86927891] ; [106.55033112,10.86947918] ; [106.55589294,10.86846256]"
    ,"Distance":"641"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3964"
    ,"Station_Code":"HHM 063"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Giồng"
    ,"Station_Address":"Ngã ba Giồng , đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.869374
    ,"Long":106.561058
    ,"Polyline":"[106.55589294,10.86846256] ; [106.55802155,10.86826038] ; [106.55960846,10.86888981] ; [106.56101227,10.86948013] ; [106.56105804,10.86937428]"
    ,"Distance":"601"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3949"
    ,"Station_Code":"HHM 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Sân banh"
    ,"Station_Address":"Đối diện 88/5, đường Nguy ễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.870333
    ,"Long":106.56351
    ,"Polyline":"[106.56105804,10.86937428] ; [106.56350708,10.87033272]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2267"
    ,"Station_Code":"HHM 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Thịnh Phát"
    ,"Station_Address":"34, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.870612
    ,"Long":106.564159
    ,"Polyline":"[106.56350708,10.87033272] ; [106.56415558,10.87061214]"
    ,"Distance":"77"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3944"
    ,"Station_Code":"HHM 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ấp 4"
    ,"Station_Address":"17/2B , đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.871629
    ,"Long":106.566954
    ,"Polyline":"[106.56415558,10.87061214] ; [106.56417847,10.87071705] ; [106.56619263,10.87156010.06.56688690] ; [10.87173939,106.56695557]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2274"
    ,"Station_Code":"HHM 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Long Thành  Phát"
    ,"Station_Address":"25A, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.872124
    ,"Long":106.569228
    ,"Polyline":"[106.56695557,10.87162876] ; [106.56696320,10.87174988] ; [106.56921387,10.87225056] ; [106.56922913,10.87212372]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3940"
    ,"Station_Code":"HHM 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Công ty SamBo"
    ,"Station_Address":"2/4, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.874906
    ,"Long":106.575816
    ,"Polyline":"[106.56922913,10.87212372] ; [106.56932831,10.87230301] ; [106.57141876,10.87272453] ; [106.57334900,10.87372589] ; [106.57572937,10.87500000] ; [106.57581329,10.87490559]"
    ,"Distance":"805"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3943"
    ,"Station_Code":"HHM 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm y tế Xuân Thới Thượng"
    ,"Station_Address":"Trạm y tế Xuân Thới Thượng, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.880342
    ,"Long":106.582671
    ,"Polyline":"[106.57581329,10.87490559] ; [106.57963562,10.87739182] ; [106.58267212,10.88034153]"
    ,"Distance":"968"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3952"
    ,"Station_Code":"HHM 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã tư Hóc Môn-Nguyễn Văn Bứa"
    ,"Station_Address":"9A,  đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.883461
    ,"Long":106.586314
    ,"Polyline":"[106.58267212,10.88034153] ; [106.58360291,10.88203812] ; [106.58447266,10.88320827] ; [106.58631134,10.88346100]"
    ,"Distance":"579"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2329"
    ,"Station_Code":"HHM 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 4 H óc Môn"
    ,"Station_Address":"81(Số củ 21), đường Lý Thường Kiệt , Huyện  Hóc Môn"
    ,"Lat":10.884794
    ,"Long":106.5878
    ,"Polyline":"[106.58631134,10.88346100] ; [106.58670044,10.88367653] ; [106.58709717,10.88390350] ; [106.58769226,10.88473034] ; [106.58779907,10.88479424]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2330"
    ,"Station_Code":"HHM 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Nhà hàng Thanh Trúc"
    ,"Station_Address":"10/6A, đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.886938
    ,"Long":106.590691
    ,"Polyline":"[106.58779907,10.88491726] ; [106.58776093,10.88494015] ; [106.58834076,10.88566971] ; [106.58872986,10.88617039] ; [106.58889008,10.88630962] ; [106.58904266,10.88644028] ; [106.58937836,10.88668442] ; [106.59066772,10.88702011] ; [106.59068298,10.88698292]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2331"
    ,"Station_Code":"HHM 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngân hàng Nông Nghiệp"
    ,"Station_Address":"39/1, đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.887954
    ,"Long":106.593674
    ,"Polyline":"[106.59068298,10.88698292] ; [106.59365082,10.88799953]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"4746"
    ,"Station_Code":"HHM 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Thị trần Hóc Môn"
    ,"Station_Address":"45/4, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.887638
    ,"Long":106.596147
    ,"Polyline":"[106.59367371,10.88795376] ; [106.59494781,10.88847637] ; [106.59505463,10.88844395] ; [106.59513855,10.88850784] ; [106.59630585,10.88836002] ; [106.59614563,10.88763809]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1227"
    ,"Station_Code":"HHM 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Mần non 23-11"
    ,"Station_Address":"24, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.883945
    ,"Long":106.594635
    ,"Polyline":"[106.59614563,10.88763809] ; [106.59614563,10.88705349] ; [106.59463501,10.88394547]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"4747"
    ,"Station_Code":"HHM 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Bệnh vi ện Hóc Môn"
    ,"Station_Address":"Đối diện 1/11A , đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.883161
    ,"Long":106.594318
    ,"Polyline":"[106.59463501,10.88394547] ; [106.59463501,10.88394547] ; [106.59465790,10.88388252] ; [106.59438324,10.88316059] ; [106.59431458,10.88316059] ; [106.59431458,10.88316059]"
    ,"Distance":"101"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1228"
    ,"Station_Code":"HHM 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã tư Giếng  Nước"
    ,"Station_Address":"106, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.878356
    ,"Long":106.592054
    ,"Polyline":"[106.59431458,10.88316059] ; [106.59263611,10.87884617] ; [106.59205627,10.87835598]"
    ,"Distance":"598"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1230"
    ,"Station_Code":"HHM 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cây xăng  Thành Công"
    ,"Station_Address":"Cây xăng Thành Công, đường Quốc lộ 22 , Huyện Hóc Môn"
    ,"Lat":10.877018
    ,"Long":106.591635
    ,"Polyline":"[106.59205627,10.87835598] ; [106.59140015,10.87782001] ; [106.59130096,10.87758160] ; [106.59167480,10.87711811] ; [106.59163666,10.87701797]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1232"
    ,"Station_Code":"HHM 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Miểu Con Mèo"
    ,"Station_Address":"42/7B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.871902
    ,"Long":106.595306
    ,"Polyline":"[106.59172821,10.87714958] ; [106.59541321,10.87197018]"
    ,"Distance":"735"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1231"
    ,"Station_Code":"HHM 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã 3 Bùi Môn"
    ,"Station_Address":"43/1, đường Quốc lộ 22, Huy ện Hóc Môn"
    ,"Lat":10.868887
    ,"Long":106.597473
    ,"Polyline":"[106.59541321,10.87197018] ; [106.59622955,10.87077045] ; [106.59658051,10.87028980] ; [106.59755707,10.86894035]"
    ,"Distance":"436"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1235"
    ,"Station_Code":"HHM 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường học Tân Xuân"
    ,"Station_Address":"58/6, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.865924
    ,"Long":106.599602
    ,"Polyline":"[106.59755707,10.86894035] ; [106.59967804,10.86596966]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1233"
    ,"Station_Code":"HHM 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Xí nghiệp phân bón Hóc Môn"
    ,"Station_Address":"114, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.861867
    ,"Long":106.602356
    ,"Polyline":"[106.59967804,10.86596966] ; [106.60108948,10.86394024] ; [106.60241699,10.86209011] ; [106.60250854,10.86196041]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1234"
    ,"Station_Code":"HHM 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã 3 C ủ Cải"
    ,"Station_Address":"13/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.859233
    ,"Long":106.604295
    ,"Polyline":"[106.60235596,10.86186695] ; [106.60250854,10.86196041] ; [106.60305786,10.86112022] ; [106.60429382,10.85923290]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1236"
    ,"Station_Code":"HHM 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã ba Nguyễn Thị Sóc"
    ,"Station_Address":"43 /5, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.857373
    ,"Long":106.605669
    ,"Polyline":"[106.60429382,10.85923290] ; [106.60566711,10.85737324]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3635"
    ,"Station_Code":"HHM 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chùa Linh  Sơn"
    ,"Station_Address":"G68A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.85554
    ,"Long":106.606779
    ,"Polyline":"[106.60566711,10.85737324] ; [106.60575867,10.85744667] ; [106.60691071,10.85562420] ; [106.60678101,10.85554028]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1393"
    ,"Station_Code":"HHM 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã tư Nguyễn Ảnh Thủ"
    ,"Station_Address":"30/10B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854628
    ,"Long":106.607476
    ,"Polyline":"[106.60678101,10.85554028] ; [106.60689545,10.85563469] ; [106.60753632,10.85471725] ; [106.60747528,10.85462761]"
    ,"Distance":"153"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1238"
    ,"Station_Code":"HHM 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"3A, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.850092
    ,"Long":106.610395
    ,"Polyline":"[106.60747528,10.85462761] ; [106.61039734,10.85009193]"
    ,"Distance":"598"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61047363,10.85015011] ; [106.61290741,10.84638023] ; [106.61396027,10.84473038]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Bến xe An S ương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61384583,10.84465027] ; [106.61390686,10.84472847] ; [106.61408234,10.84449100] ; [106.61326599,10.84382725] ; [106.61337280,10.84373760]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"B ến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61337280,10.84373760] ; [106.61406708,10.84424400] ; [106.61536407,10.84227371] ; [106.61569214,10.84249496] ; [106.61401367,10.84493923]"
    ,"Distance":"731"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1116"
    ,"Station_Code":"Q12 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm cây xăng"
    ,"Station_Address":"128, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.845487
    ,"Long":106.61371
    ,"Polyline":"[106.61401367,10.84493923] ; [106.61367035,10.84547901]"
    ,"Distance":"79"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1117"
    ,"Station_Code":"Q12 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"7C, đường  Quốc lộ 22, Quận 12"
    ,"Lat":10.845845
    ,"Long":106.613474
    ,"Polyline":"[106.61367035,10.84547901] ; [106.61344147,10.84581375]"
    ,"Distance":"54"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1151"
    ,"Station_Code":"Q12 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cây xăng Quân Đội"
    ,"Station_Address":"2, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.850034
    ,"Long":106.610845
    ,"Polyline":"[106.61338806,10.84578991] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61106110,10.84941959] ; [106.61073303,10.84994030]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1689"
    ,"Station_Code":"Q12 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cảnh sát giao thông số 5"
    ,"Station_Address":"Kế cảnh sát giao thông số 5, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.851009
    ,"Long":106.610186
    ,"Polyline":"[106.61078644,10.84997559] ; [106.61013031,10.85097694]"
    ,"Distance":"149"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1152"
    ,"Station_Code":"Q12 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Trung tâm văn hóa Quận 12, đường Qu ốc lộ 22, Quận 12"
    ,"Lat":10.854892
    ,"Long":106.607718
    ,"Polyline":"[106.61013031,10.85097694] ; [106.60794067,10.85446453] ; [106.60765076,10.85483360]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1154"
    ,"Station_Code":"HHM 022"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Liên đoàn lao động Hóc Môn"
    ,"Station_Address":"69/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.855756
    ,"Long":106.607198
    ,"Polyline":"[106.60761261,10.85480976] ; [106.60710144,10.85558987]"
    ,"Distance":"139"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1153"
    ,"Station_Code":"HHM 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cây xăng Củ Cải"
    ,"Station_Address":"33 /4, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.859054
    ,"Long":106.604869
    ,"Polyline":"[106.60710144,10.85558987] ; [106.60597229,10.85727978] ; [106.60545349,10.85801029] ; [106.60475159,10.85900974]"
    ,"Distance":"494"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1156"
    ,"Station_Code":"HHM 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Ngã 3 Củ  Cải"
    ,"Station_Address":"8/6B, đường Quốc l ộ 22, Huyện Hóc Môn"
    ,"Lat":10.861856
    ,"Long":106.602844
    ,"Polyline":"[106.60475159,10.85900974] ; [106.60276031,10.86180973]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1155"
    ,"Station_Code":"HHM 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường học Tân Xuân"
    ,"Station_Address":"44A, đường Qu ốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.865945
    ,"Long":106.599972
    ,"Polyline":"[106.60276031,10.86180973] ; [106.60131836,10.86382008] ; [106.59986877,10.86587048]"
    ,"Distance":"576"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1158"
    ,"Station_Code":"HHM 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã 3 Bùi Môn"
    ,"Station_Address":"1/1, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.869901
    ,"Long":106.597206
    ,"Polyline":"[106.59986877,10.86587048] ; [106.59706879,10.86981010]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1160"
    ,"Station_Code":"HHM 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã 3 Bùi Môn"
    ,"Station_Address":"3/19, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.872535
    ,"Long":106.595305
    ,"Polyline":"[106.59706879,10.86981010.06.59520721]"
    ,"Distance":"390"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1157"
    ,"Station_Code":"HHM 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cây xăng Thành Công - Ngã tư Giếng Nước"
    ,"Station_Address":"3/88C, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.877313
    ,"Long":106.591855
    ,"Polyline":"[106.59520721,10.87244987] ; [106.59176636,10.87730980]"
    ,"Distance":"683"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"4751"
    ,"Station_Code":"HHM 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã tư Giếng nước"
    ,"Station_Address":"2/16A , đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.87765
    ,"Long":106.591598
    ,"Polyline":"[106.59185791,10.87731266] ; [106.59159851,10.87765026]"
    ,"Distance":"47"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"4586"
    ,"Station_Code":"HHM 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã tư Gi ếng nước"
    ,"Station_Address":"3/88C, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.87803
    ,"Long":106.591882
    ,"Polyline":"[106.59159851,10.87765026] ; [106.59146118,10.87776089] ; [106.59181976,10.87804508] ; [106.59188080,10.87802982]"
    ,"Distance":"77"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1162"
    ,"Station_Code":"HHM 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bệnh viện Hóc Môn"
    ,"Station_Address":"77/4, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.88246
    ,"Long":106.5942
    ,"Polyline":"[106.59188080,10.87802982] ; [106.59265137,10.87871933] ; [106.59294128,10.87920475] ; [106.59420013,10.88245964]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1164"
    ,"Station_Code":"HHM 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường mầm non 23-11"
    ,"Station_Address":"84/2A, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.88433
    ,"Long":106.594929
    ,"Polyline":"[106.59420013,10.88245964] ; [106.59493256,10.88432980]"
    ,"Distance":"223"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"1161"
    ,"Station_Code":"HHM 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Thị trấn Hóc Môn"
    ,"Station_Address":"98/2, đường Bà Triệu, Huyện Hóc Môn"
    ,"Lat":10.8867
    ,"Long":106.596077
    ,"Polyline":"[106.59493256,10.88432980] ; [106.59607697,10.88669968]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2259"
    ,"Station_Code":"HHM 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngân hàng  Nông Nghiệp"
    ,"Station_Address":"13/3 (số củ 12 ), đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.888333
    ,"Long":106.594368
    ,"Polyline":"[106.59607697,10.88669968] ; [106.59603882,10.88671970] ; [106.59610748,10.88694954] ; [106.59612274,10.88716030] ; [106.59609222,10.88749027] ; [106.59620667,10.88792992] ; [106.59629059,10.88836956] ; [106.59559631,10.88842964] ; [106.59513855,10.88853931] ; [106.59506989,10.88862896] ; [106.59496307,10.88862896] ; [106.59491730,10.88848019] ; [106.59484100,10.88842964] ; [106.59436798,10.88833332]"
    ,"Distance":"424"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2268"
    ,"Station_Code":"HHM 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Thanh Tr úc"
    ,"Station_Address":"78, đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.88715
    ,"Long":106.590866
    ,"Polyline":"[106.59436798,10.88833332] ; [106.59403992,10.88815975] ; [106.59086609,10.88714981]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2261"
    ,"Station_Code":"HHM 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã tư H óc Môn"
    ,"Station_Address":"51/8, đường Lý Th ường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.884733
    ,"Long":106.58757
    ,"Polyline":"[106.59086609,10.88714981] ; [106.59036255,10.88698006] ; [106.58935547,10.88662148] ; [106.58904266,10.88644028] ; [106.58872986,10.88617039] ; [106.58757019,10.88473320]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3954"
    ,"Station_Code":"HHM 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã 4 Hóc Môn"
    ,"Station_Address":"8B, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.883608
    ,"Long":106.586292
    ,"Polyline":"[106.58757019,10.88473320] ; [106.58709717,10.88393021] ; [106.58637238,10.88357639] ; [106.58628845,10.88360786]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3950"
    ,"Station_Code":"HHM 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Xuân  Thới Sơn"
    ,"Station_Address":"Ban nhân dân Ấp 1  (79/79), đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.880395
    ,"Long":106.582275
    ,"Polyline":"[106.58628845,10.88360786] ; [106.58607483,10.88347149] ; [106.58471680,10.88330841] ; [106.58439636,10.88319778] ; [106.58409882,10.88284969] ; [106.58377838,10.88242340] ; [106.58332825,10.88169575] ; [106.58290100,10.88099575] ; [106.58245850,10.88030052] ; [106.58227539,10.88039494]"
    ,"Distance":"624"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3953"
    ,"Station_Code":"HHM 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Xuân  Thới Đông"
    ,"Station_Address":"96/3C, đường Nguyễn Văn Bứa, Huyện Hóc  Môn"
    ,"Lat":10.878762
    ,"Long":106.580729
    ,"Polyline":"[106.58227539,10.88039494] ; [106.58244324,10.88033676] ; [106.58171082,10.87943649] ; [106.58080292,10.87866211] ; [106.58072662,10.87876225]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3951"
    ,"Station_Code":"HHM 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Nguyễn Hồng Đào"
    ,"Station_Address":"40B, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.873789
    ,"Long":106.573069
    ,"Polyline":"[106.58072662,10.87876225] ; [106.57969666,10.87760258] ; [106.57332611,10.87376785] ; [106.57306671,10.87378883]"
    ,"Distance":"1017"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3956"
    ,"Station_Code":"HHM 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ấp 4"
    ,"Station_Address":"37B, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.873093
    ,"Long":106.571717
    ,"Polyline":"[106.57306671,10.87378883] ; [106.57311249,10.87368298] ; [106.57175446,10.87297249] ; [106.57171631,10.87309265]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3974"
    ,"Station_Code":"HHM 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Công ty Sambu"
    ,"Station_Address":"8/7, đường Nguyễn Văn Bứa, Huyện Hóc M ôn"
    ,"Lat":10.872293
    ,"Long":106.568724
    ,"Polyline":"[106.57171631,10.87309265] ; [106.57176208,10.87298775] ; [106.57111359,10.87274551] ; [106.56874847,10.87221336] ; [106.56872559,10.87229347]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2224"
    ,"Station_Code":"HHM 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trường tiểu học Nhị Xuân"
    ,"Station_Address":"89/5, đường Nguy ễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.871176
    ,"Long":106.564947
    ,"Polyline":"[106.56872559,10.87229347] ; [106.56642914,10.87168121] ; [106.56494904,10.87117577]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3945"
    ,"Station_Code":"HHM 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Khu di tích lịch sử Ngã Ba Gi ồng"
    ,"Station_Address":"Đối diện Ngã ba gio ̀ng, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.869005
    ,"Long":106.559728
    ,"Polyline":"[106.56494904,10.87117577] ; [106.55973053,10.86900520]"
    ,"Distance":"620"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2222"
    ,"Station_Code":"HHM 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Trường PTTH  Nguyễn Văn Cừ"
    ,"Station_Address":"Đối diện tr ường Nguyễn Văn Cừ, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.868774
    ,"Long":106.555538
    ,"Polyline":"[106.55973053,10.86900520] ; [106.55898285,10.86863995] ; [106.55803680,10.86826038] ; [106.55785370,10.86828041] ; [106.55684662,10.86845016] ; [106.55553436,10.86877441]"
    ,"Distance":"482"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2265"
    ,"Station_Code":"HHM 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"trường tiểu học Nhị Xuân"
    ,"Station_Address":"46B  - 48B, đường Nguyễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.869385
    ,"Long":106.552105
    ,"Polyline":"[106.55553436,10.86877441] ; [106.55553436,10.86877441] ; [106.55551910,10.86868382] ; [106.55209351,10.86927891] ; [106.55210876,10.86938477] ; [106.55210876,10.86938477]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3939"
    ,"Station_Code":"HHM 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Văn phòng  Ấp 4"
    ,"Station_Address":"23B, đường Nguyễn  Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.870902
    ,"Long":106.541955
    ,"Polyline":"[106.55210876,10.86938477] ; [106.54195404,10.87090206]"
    ,"Distance":"1123"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"3941"
    ,"Station_Code":"HHM 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Cổng KCN Nhị Xuân"
    ,"Station_Address":"Trường Nhị Xuân, đường Nguyễn Văn Bứa , Huyện Hóc Môn"
    ,"Lat":10.87166
    ,"Long":106.537557
    ,"Polyline":"[106.54195404,10.87090206] ; [106.53755951,10.87166023]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"125"
    ,"Station_Id":"2227"
    ,"Station_Code":"BX 39"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu Lớn"
    ,"Station_Address":"BÃI XE CẦU LỚN, đường Nguy ễn Văn Bứa, Huyện Hóc Môn"
    ,"Lat":10.871845
    ,"Long":106.535561
    ,"Polyline":"[106.53755951,10.87166023] ; [106.53755951,10.87166023] ; [106.53747559,10.87148094] ; [106.53621674,10.87170219] ; [106.53502655,10.87193489] ; [106.53491974,10.87216663] ; [106.53491974,10.87216663]"
    ,"Distance":"323"
  }]