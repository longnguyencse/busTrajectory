export const Route75 =[
  {
     "Route_Id":"75"
    ,"Station_Id":"3185"
    ,"Station_Code":"BX 30"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu Công Nghệ cao"
    ,"Station_Address":"ĐẦU BẾN KCN CAO QUẬN 9, đường L ê Văn Việt, Quận 9"
    ,"Lat":10.847352
    ,"Long":106.799606
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1533"
    ,"Station_Code":"Q9 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 3 Man Thiện"
    ,"Station_Address":"Đối diện 504, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846504
    ,"Long":106.798155
    ,"Polyline":"[106.79930878,10.84716034] ; [106.79949188,10.84673977] ; [106.79859161,10.84650993] ; [106.79814911,10.84642029]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1530"
    ,"Station_Code":"Q9 103"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Đại Học GTVT"
    ,"Station_Address":"Trung tâm thông tin thư viện, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845566
    ,"Long":106.794421
    ,"Polyline":"[106.79814911,10.84642029] ; [106.79563904,10.84578991] ; [106.79450226,10.84549046]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1535"
    ,"Station_Code":"Q9 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Bệnh viện Quận 9"
    ,"Station_Address":"99, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844607
    ,"Long":106.790349
    ,"Polyline":"[106.79450226,10.84549046] ; [106.79222107,10.84494019] ; [106.79141235,10.84477043] ; [106.79042053,10.84451962]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1532"
    ,"Station_Code":"Q9 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường Trần Quốc Toản"
    ,"Station_Address":"Đối diện chợ Tăng Nhơn Phú, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844923
    ,"Long":106.788209
    ,"Polyline":"[106.79042053,10.84451962] ; [106.78981781,10.84436035] ; [106.78964233,10.84432983] ; [106.78929138,10.84436035] ; [106.78904724,10.84440041] ; [106.78878784,10.84449959] ; [106.78855133,10.84461021] ; [106.78823853,10.84480000] ; [106.78817749,10.84482002]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1537"
    ,"Station_Code":"Q9 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ nhỏ"
    ,"Station_Address":"249, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.84427
    ,"Long":106.784084
    ,"Polyline":"[106.78817749,10.84482002] ; [106.78733063,10.84517002] ; [106.78697968,10.84519005] ; [106.78665161,10.84515953] ; [106.78656006,10.84514999] ; [106.78630066,10.84504032] ; [106.78617096,10.84496021] ; [106.78610992,10.84486961] ; [106.78553772,10.84447956] ; [106.78539276,10.84440994] ; [106.78479767,10.84430981] ; [106.78407288,10.84418964]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1534"
    ,"Station_Code":"Q9 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Cổng đình Phong Phú"
    ,"Station_Address":"189-191, đường  Lê Văn Việt, Quận 9"
    ,"Lat":10.844381
    ,"Long":106.781723
    ,"Polyline":"[106.78407288,10.84418964] ; [106.78273010,10.84399986] ; [106.78231049,10.84407997] ; [106.78182220,10.84426975]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1536"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Siêu thị Thành Nghĩa"
    ,"Station_Address":"Đối diện 140-142, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845176
    ,"Long":106.780377
    ,"Polyline":"[106.78182220,10.84426975] ; [106.78141785,10.84442043] ; [106.78103638,10.84461021] ; [106.78050232,10.84504032] ; [106.78038025,10.84512043]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1539"
    ,"Station_Code":"Q9 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Bệnh viện 7C-Trường Quân y 2"
    ,"Station_Address":"91-93 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846799
    ,"Long":106.777512
    ,"Polyline":"[106.78038025,10.84512043] ; [106.78009033,10.84529972] ; [106.77919769,10.84576035] ; [106.77778625,10.84655952] ; [106.77747345,10.84673977]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1538"
    ,"Station_Code":"Q9 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Siêu thị Coopmark"
    ,"Station_Address":"17-19, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.848411
    ,"Long":106.775045
    ,"Polyline":"[106.77747345,10.84673977] ; [106.77583313,10.84768963] ; [106.77510071,10.84823036] ; [106.77494812,10.84834003]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1113"
    ,"Station_Code":"QTD 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã tư  Thủ Đức"
    ,"Station_Address":"Đối diện Coopmart, đường Xa Lộ Hà Nội, Qu ận Thủ Đức"
    ,"Lat":10.84828
    ,"Long":106.77299
    ,"Polyline":"[106.77494812,10.84834003] ; [106.77404022,10.84914017] ; [106.77391052,10.84926033] ; [106.77340698,10.84871006] ; [106.77310181,10.84827042]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1111"
    ,"Station_Code":"QTD 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Betong Hải Âu"
    ,"Station_Address":"Đối diện Betong Hải Âu, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.844297
    ,"Long":106.77063
    ,"Polyline":"[106.77298737,10.84827995] ; [106.77310181,10.84827042] ; [106.77133942,10.84535027] ; [106.77062988,10.84429741]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1112"
    ,"Station_Code":"QTD 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"UBND Quận 9"
    ,"Station_Address":"126, đường  Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.840745
    ,"Long":106.768607
    ,"Polyline":"[106.77044678,10.84377003] ; [106.76873016,10.84070969]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"410"
    ,"Station_Code":"QTD 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 4 Bình Thái"
    ,"Station_Address":"Đối diện 592C, đường Xa Lộ Hà Nội, Qu ận Thủ Đức"
    ,"Lat":10.834945
    ,"Long":106.765244
    ,"Polyline":"[106.76873016,10.84070969] ; [106.76544952,10.83495045]"
    ,"Distance":"734"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"413"
    ,"Station_Code":"QTD 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Công ty truyền tải điện 4"
    ,"Station_Address":"Công ty truyền tải điện 4, đường Xa L ộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.831214
    ,"Long":106.763195
    ,"Polyline":"[106.76544952,10.83495045] ; [106.76335144,10.83117008]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"412"
    ,"Station_Code":"QTD 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"Nhà máy thép Thủ Đức, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.825366
    ,"Long":106.759998
    ,"Polyline":"[106.76335144,10.83117008] ; [106.76077271,10.82660961] ; [106.76042175,10.82596970] ; [106.76006317,10.82534027]"
    ,"Distance":"742"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"414"
    ,"Station_Code":"QTD 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Xi măng Hà Tiên"
    ,"Station_Address":"Xi măng Hà Tiên 1, đường Xa Lộ Hà Nội , Quận Thủ Đức"
    ,"Lat":10.820576
    ,"Long":106.758142
    ,"Polyline":"[106.75999451,10.82536602] ; [106.76006317,10.82534027] ; [106.75936127,10.82404041] ; [106.75901031,10.82326984] ; [106.75881958,10.82271957] ; [106.75849915,10.82153034] ; [106.75832367,10.82067966] ; [106.75814056,10.82057571]"
    ,"Distance":"587"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"415"
    ,"Station_Code":"Q2 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Đối diện Esstella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802925
    ,"Long":106.747948
    ,"Polyline":"[106.75824738,10.82028961] ; [106.75800323,10.81882000] ; [106.75762177,10.81719971] ; [106.75750732,10.81649971] ; [106.75665283,10.81186962] ; [106.75646210,10.81079006] ; [106.75637054,10.81039047] ; [106.75617981,10.80984020] ; [106.75598145,10.80965996] ; [106.75581360,10.80947018] ; [106.75559235,10.80926037] ; [106.75546265,10.80908012] ; [106.75527191,10.80881023] ; [106.75486755,10.80805969] ; [106.75475311,10.80792999] ; [106.75462341,10.80772018] ; [106.75428772,10.80725002] ; [106.75395203,10.80685043] ; [106.75332642,10.80630016] ; [106.75301361,10.80597019] ; [106.75257111,10.80548954] ; [106.75234985,10.80527973] ; [106.75190735,10.80494022] ; [106.75112152,10.80440998] ; [106.75038910,10.80405998] ; [106.74987030,10.80385017] ; [106.74957275,10.80370998] ; [106.74935913,10.80356026] ; [106.74886322,10.80315018] ; [106.74861145,10.80301952] ; [106.74826050,10.80294991] ; [106.74796295,10.80286980]"
    ,"Distance":"2404"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"416"
    ,"Station_Code":"Q2 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Metro Qu ận 2"
    ,"Station_Address":"655, đường Xa Lộ Hà Nội, Qu ận 2"
    ,"Lat":10.802134
    ,"Long":106.7434
    ,"Polyline":"[106.74796295,10.80286980] ; [106.74703217,10.80266953] ; [106.74620819,10.80251026] ; [106.74530792,10.80233955] ; [106.74463654,10.80222988] ; [106.74340820,10.80202007]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"417"
    ,"Station_Code":"Q2 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Ngã ba Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801309
    ,"Long":106.738762
    ,"Polyline":"[106.74340820,10.80202007] ; [106.74149323,10.80167007] ; [106.74060822,10.80146980] ; [106.73986816,10.80136013] ; [106.73879242,10.80115986]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"418"
    ,"Station_Code":"Q2 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"Đối diện Cầu  Đen, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800451
    ,"Long":106.73436
    ,"Polyline":"[106.73879242,10.80115986] ; [106.73438263,10.80035019]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"419"
    ,"Station_Code":"QBTH 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Cầu Sài G òn"
    ,"Station_Address":"24(597), đường Điện Biên Ph ủ, Quận Bình Thạnh"
    ,"Lat":10.79882
    ,"Long":106.719641
    ,"Polyline":"[106.73438263,10.80035019] ; [106.73294067,10.80004978] ; [106.73187256,10.79979992] ; [106.72416687,10.79837036] ; [106.72223663,10.79802990] ; [106.72196960,10.79800987] ; [106.72158051,10.79800034] ; [106.72128296,10.79804993] ; [106.72090149,10.79813957] ; [106.72048950,10.79827976] ; [106.72003937,10.79848003] ; [106.71987915,10.79856968] ; [106.71972656,10.79868984] ; [106.71945953,10.79881954]"
    ,"Distance":"1676"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"420"
    ,"Station_Code":"QBTH 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"152/72c(559), đường Điện Biên Phủ, Qu ận Bình Thạnh"
    ,"Lat":10.800153
    ,"Long":106.717442
    ,"Polyline":"[106.71964264,10.79881954] ; [106.71945953,10.79881954] ; [106.71913147,10.79899025] ; [106.71864319,10.79930019] ; [106.71785736,10.79975033] ; [106.71744537,10.80015278]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"421"
    ,"Station_Code":"QBTH 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"483, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.801228
    ,"Long":106.714856
    ,"Polyline":"[106.71719360,10.80008030] ; [106.71645355,10.80043030] ; [106.71571350,10.80074024] ; [106.71513367,10.80097008] ; [106.71481323,10.80107975]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"423"
    ,"Station_Code":"QBTH 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"419, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.801639
    ,"Long":106.712447
    ,"Polyline":"[106.71485901,10.80122757] ; [106.71471405,10.80127525] ; [106.71443939,10.80134869] ; [106.71388245,10.80146503] ; [106.71343231,10.80159092] ; [106.71300507,10.80169678] ; [106.71281433,10.80164433] ; [106.71244812,10.80163860]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1114"
    ,"Station_Code":"QBTH 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"18, đường Bạch Đ ằng, Quận Bình Thạnh"
    ,"Lat":10.802998
    ,"Long":106.710441
    ,"Polyline":"[106.71244812,10.80163860] ; [106.71231842,10.80156040] ; [106.71192169,10.80169964] ; [106.71177673,10.80175972] ; [106.71166229,10.80185032] ; [106.71150970,10.80206013] ; [106.71137238,10.80249977] ; [106.71138763,10.80284023] ; [106.71114349,10.80286026] ; [106.71045685,10.80290985] ; [106.71044159,10.80299759]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.71044159,10.80299759] ; [106.70935059,10.80296993] ; [106.70844269,10.80305004] ; [106.70803070,10.80317688]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường  Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70797729,10.80307961] ; [106.70393372,10.80338955]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Th ạnh"
    ,"Station_Address":"288 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70401764,10.80348301] ; [106.70373535,10.80351448] ; [106.70278168,10.80364132] ; [106.70172119,10.80392075] ; [106.70153046,10.80396271] ; [106.70114136,10.80384636] ; [106.70096588,10.80375671]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chợ B à Chiểu"
    ,"Station_Address":"368, đường Bạch  Đằng, Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70096588,10.80375671] ; [106.69937134,10.80312538]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"UBND Quận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Th ạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69924164,10.80296993] ; [106.69860077,10.80268002] ; [106.69795990,10.80245972] ; [106.69753265,10.80249977] ; [106.69599152,10.80268002] ; [106.69573212,10.80272007]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"594"
    ,"Station_Code":"QBTH 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"10, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803088
    ,"Long":106.693586
    ,"Polyline":"[106.69573212,10.80272007] ; [106.69348145,10.80301952]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"593"
    ,"Station_Code":"QBTH 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Công an PCCC, Quận Bình Thạnh"
    ,"Station_Address":"14-16, đường Phan Đăng Lưu , Quận Bình Thạnh"
    ,"Lat":10.803362
    ,"Long":106.691473
    ,"Polyline":"[106.69358063,10.80300045] ; [106.69243622,10.80313015] ; [106.69143677,10.80327034]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"595"
    ,"Station_Code":"QPN 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bệnh viện Phước An"
    ,"Station_Address":"36A, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803894
    ,"Long":106.687535
    ,"Polyline":"[106.69143677,10.80327034] ; [106.68968964,10.80350018] ; [106.68791199,10.80370998] ; [106.68756866,10.80375004]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"596"
    ,"Station_Code":"QPN 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"68, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.804063
    ,"Long":106.686269
    ,"Polyline":"[106.68753815,10.80389404] ; [106.68690491,10.80390453] ; [106.68627167,10.80406284]"
    ,"Distance":"141"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"597"
    ,"Station_Code":"QPN 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"124, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802629
    ,"Long":106.683689
    ,"Polyline":"[106.68601227,10.80395985] ; [106.68576050,10.80399036] ; [106.68560028,10.80397987] ; [106.68544006,10.80395031] ; [106.68515778,10.80383015] ; [106.68492889,10.80364037] ; [106.68470764,10.80344963] ; [106.68376160,10.80249977]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"598"
    ,"Station_Code":"QPN 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"172, đường Phan Đăng Lưu, Quận Phú Nhu ận"
    ,"Lat":10.800854
    ,"Long":106.681833
    ,"Polyline":"[106.68376160,10.80249977] ; [106.68286133,10.80163956] ; [106.68202209,10.80080032]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"50"
    ,"Station_Code":"QPN 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"392, đường Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.799713
    ,"Long":106.680138
    ,"Polyline":"[106.68202209,10.80080032] ; [106.68138885,10.80014992] ; [106.68048096,10.79924011] ; [106.68028259,10.79920006] ; [106.68007660,10.79969025]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"51"
    ,"Station_Code":"QPN 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà Truyền Thông"
    ,"Station_Address":"466, đường Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.802232
    ,"Long":106.679245
    ,"Polyline":"[106.68007660,10.79969025] ; [106.67945862,10.80121994] ; [106.67926025,10.80183029] ; [106.67917633,10.80222034]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"52"
    ,"Station_Code":"QPN 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Ba Hồ Văn Huê"
    ,"Station_Address":"582, đường Nguyễn Kiệm, Quận  Phú Nhuận"
    ,"Lat":10.805259
    ,"Long":106.678759
    ,"Polyline":"[106.67917633,10.80222034] ; [106.67884827,10.80410957] ; [106.67868042,10.80515957] ; [106.67867279,10.80523968]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"53"
    ,"Station_Code":"QPN 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Coop Mart Nguyễn Kiệm"
    ,"Station_Address":"668-670, đường Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.807156
    ,"Long":106.678555
    ,"Polyline":"[106.67867279,10.80523968] ; [106.67848206,10.80657005] ; [106.67845154,10.80704975] ; [106.67845154,10.80774975]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"54"
    ,"Station_Code":"QPN 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Chùa Vạn Hạnh"
    ,"Station_Address":"750, đường Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.810723
    ,"Long":106.678609
    ,"Polyline":"[106.67845154,10.80774975] ; [106.67846680,10.80941963] ; [106.67849731,10.81005955]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"55"
    ,"Station_Code":"QGV 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trường Cao đẳng Hải Quan"
    ,"Station_Address":"780A, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.812475
    ,"Long":106.678711
    ,"Polyline":"[106.67849731,10.81005955] ; [106.67864227,10.81247997]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"56"
    ,"Station_Code":"QGV 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Trạm đ ầu Nguyễn Thái Sơn"
    ,"Station_Address":"36, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.815178
    ,"Long":106.679596
    ,"Polyline":"[106.67871094,10.81247520] ; [106.67871857,10.81392670] ; [106.67890167,10.81394768] ; [106.67902374,10.81400585] ; [106.67914581,10.81407452] ; [106.67919922,10.81418991] ; [106.67915344,10.81438541] ; [106.67901611,10.81454849] ; [106.67959595,10.81517792]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"59"
    ,"Station_Code":"QGV 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"90, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.81674
    ,"Long":106.680847
    ,"Polyline":"[106.67959595,10.81517792] ; [106.68084717,10.81674004]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"57"
    ,"Station_Code":"QGV 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"182 (148B), đường  Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.819923
    ,"Long":106.683378
    ,"Polyline":"[106.68076324,10.81680012] ; [106.68226624,10.81875992] ; [106.68289185,10.81952953] ; [106.68334961,10.82013035]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"60"
    ,"Station_Code":"QGV 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Nhà Tang Lễ"
    ,"Station_Address":"220 (175), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.822141
    ,"Long":106.682616
    ,"Polyline":"[106.68334961,10.82013035] ; [106.68351746,10.82034016] ; [106.68328094,10.82073975] ; [106.68280029,10.82153988] ; [106.68251038,10.82207966]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"61"
    ,"Station_Code":"QGV 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"72 (45), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.825861
    ,"Long":106.680561
    ,"Polyline":"[106.68256378,10.82211208] ; [106.68050385,10.82584763]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"921"
    ,"Station_Code":"QGV 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Siêu thị Văn Lang, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.826804
    ,"Long":106.679354
    ,"Polyline":"[106.68045044,10.82581997] ; [106.68025970,10.82618046] ; [106.68006897,10.82637024] ; [106.68009186,10.82639027] ; [106.68012238,10.82645988] ; [106.68012238,10.82653046] ; [106.68007660,10.82658958] ; [106.68000793,10.82662010.06.67993927] ; [10.82662010.06.67987061,10.82658005] ; [106.67935181,10.82672024]"
    ,"Distance":"211"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"920"
    ,"Station_Code":"QGV 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Công ty 32"
    ,"Station_Address":"138, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.827779
    ,"Long":106.676559
    ,"Polyline":"[106.67935944,10.82683086] ; [106.67906189,10.82690430] ; [106.67655945,10.82777882]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"922"
    ,"Station_Code":"QGV 157"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Nhà Thờ Xóm Thuốc"
    ,"Station_Address":"190, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.829186
    ,"Long":106.672606
    ,"Polyline":"[106.67655945,10.82777882] ; [106.67260742,10.82918644]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"923"
    ,"Station_Code":"QGV 158"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"UBND Qu ận Gò Vấp"
    ,"Station_Address":"328, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.831641
    ,"Long":106.668502
    ,"Polyline":"[106.67260742,10.82918644] ; [106.67206573,10.82940674] ; [106.67166901,10.82960701] ; [106.67024994,10.83033466] ; [106.66980743,10.83055592] ; [106.66883850,10.83127022] ; [106.66850281,10.83164120]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"924"
    ,"Station_Code":"QGV 159"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"VKS nh ân dân Quận Gò Vấp"
    ,"Station_Address":"402 - 404, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833374
    ,"Long":106.666313
    ,"Polyline":"[106.66850281,10.83164120] ; [106.66769409,10.83221054] ; [106.66631317,10.83337402]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"4745"
    ,"Station_Code":"QGV 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Chùa Huỳnh Kim"
    ,"Station_Address":"548, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835234
    ,"Long":106.663315
    ,"Polyline":"[106.66631317,10.83337402] ; [106.66518402,10.83423328] ; [106.66426086,10.83473873] ; [106.66331482,10.83523369]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"925"
    ,"Station_Code":"QGV 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Siêu thị Bình Dân, Quang Trung"
    ,"Station_Address":"628A, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835988
    ,"Long":106.660675
    ,"Polyline":"[106.66331482,10.83523369] ; [106.66067505,10.83598804]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2049"
    ,"Station_Code":"QGV 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Chợ Thông Tây"
    ,"Station_Address":"734, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836836
    ,"Long":106.657355
    ,"Polyline":"[106.66067505,10.83598804] ; [106.66045380,10.83603477] ; [106.65762329,10.83674622] ; [106.65735626,10.83683586]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2044"
    ,"Station_Code":"QGV 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Trường THPT Nguyễn Công Trứ"
    ,"Station_Address":"872 (96H), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.838
    ,"Long":106.652741
    ,"Polyline":"[106.65735626,10.83683586] ; [106.65274048,10.83800030]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2045"
    ,"Station_Code":"QGV 164"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Dệt may Phương Đông"
    ,"Station_Address":"930 (Kho 97), đường Quang Trung, Quận  Gò Vấp"
    ,"Lat":10.838654
    ,"Long":106.650091
    ,"Polyline":"[106.65274048,10.83800030] ; [106.65250397,10.83802700] ; [106.65009308,10.83865356]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2051"
    ,"Station_Code":"QGV 165"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"1010, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.839881
    ,"Long":106.646621
    ,"Polyline":"[106.65009308,10.83865356] ; [106.64952087,10.83875942] ; [106.64781952,10.83923817] ; [106.64730072,10.83935452] ; [106.64698792,10.83952808] ; [106.64672089,10.83975983] ; [106.64662170,10.83988094]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2048"
    ,"Station_Code":"QGV 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"1134, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.842279
    ,"Long":106.643348
    ,"Polyline":"[106.64662170,10.83988094] ; [106.64559174,10.84068775] ; [106.64519501,10.84100914] ; [106.64426422,10.84164143] ; [106.64356232,10.84208393] ; [106.64334869,10.84227943]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2053"
    ,"Station_Code":"QGV 167"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"1246, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.843743
    ,"Long":106.641186
    ,"Polyline":"[106.64334869,10.84227943] ; [106.64118958,10.84374332]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2050"
    ,"Station_Code":"QGV 168"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"1324, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.845532
    ,"Long":106.638435
    ,"Polyline":"[106.64118958,10.84374332] ; [106.64093781,10.84389114] ; [106.64015198,10.84440231] ; [106.63938904,10.84497070] ; [106.63890839,10.84526634] ; [106.63843536,10.84553242]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2092"
    ,"Station_Code":"Q12 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"113, đường Quang Trung, Quận 12"
    ,"Lat":10.848253
    ,"Long":106.634363
    ,"Polyline":"[106.63843536,10.84553242] ; [106.63704681,10.84625626] ; [106.63436127,10.84825325]"
    ,"Distance":"540"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2052"
    ,"Station_Code":"Q12 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Cầu vư ợt Quang Trung"
    ,"Station_Address":"170, đường  Quang Trung, Quận 12"
    ,"Lat":10.849784
    ,"Long":106.63221
    ,"Polyline":"[106.63436127,10.84825325] ; [106.63220978,10.84978390]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"3184"
    ,"Station_Code":"BX36"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Công viên phần mềm Quang Trung"
    ,"Station_Address":"BÃI XE CV PM QUANG TRUNG,  đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.85192584991455
    ,"Long":106.63029479980469
    ,"Polyline":"[106.63220978,10.84978390] ; [106.63113403,10.85045052] ; [106.63068390,10.85067177] ; [106.63005829,10.85082912] ; [106.62792969,10.85117245] ; [106.62755585,10.85128784] ; [106.62736511,10.85140896] ; [106.62693787,10.85191441] ; [106.62666321,10.85247326] ; [106.62628937,10.85315800] ; [106.62649536,10.85313702] ; [106.62677765,10.85292625] ; [106.62700653,10.85303211] ; [106.62721252,10.85272121] ; [106.62761688,10.85241032] ; [106.62790680,10.85228920] ; [106.62821198,10.85224152] ; [106.62848663,10.85224152] ; [106.62895203,10.85238361] ; [106.62937927,10.85160923] ; [106.63018036,10.85194683] ; [106.63029480,10.85192585]"
    ,"Distance":"1341"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"3184"
    ,"Station_Code":"BX36"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Công viên ph ần mềm Quang Trung"
    ,"Station_Address":"BÃI XE CV PM QUANG TRUNG, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.85192584991455
    ,"Long":106.63029479980469
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2057"
    ,"Station_Code":"Q12 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Công viên phần mềm Quang Trung"
    ,"Station_Address":"Công viên phần mềm Quang Trung, đường Tô Ký, Quận  12"
    ,"Lat":10.852995
    ,"Long":106.626434
    ,"Polyline":"[106.63037109,10.85179043] ; [106.62920380,10.85124016] ; [106.62876892,10.85112000] ; [106.62860107,10.85109997] ; [106.62840271,10.85112000] ; [106.62805176,10.85118961] ; [106.62763214,10.85128975] ; [106.62729645,10.85144997] ; [106.62716675,10.85155964] ; [106.62702942,10.85173035] ; [106.62674713,10.85223007] ; [106.62640381,10.85280037] ; [106.62625885,10.85307026]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2089"
    ,"Station_Code":"Q12 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cửa hàng Vinh Phú"
    ,"Station_Address":"79, đường Tô Ký, Quận 12"
    ,"Lat":10.854931
    ,"Long":106.624161
    ,"Polyline":"[106.62625885,10.85307026] ; [106.62599945,10.85348988] ; [106.62554169,10.85408020] ; [106.62503052,10.85457039] ; [106.62444305,10.85499954] ; [106.62365723,10.85542965] ; [106.62345123,10.85546017] ; [106.62361145,10.85529041] ; [106.62419128,10.85498047]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2090"
    ,"Station_Code":"Q12 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Công viên PM Quang Trung"
    ,"Station_Address":"389, đường Tô Ký, Quận 12"
    ,"Lat":10.852871
    ,"Long":106.626099
    ,"Polyline":"[106.62416077,10.85493088] ; [106.62419128,10.85498047] ; [106.62441254,10.85484982] ; [106.62481689,10.85455036] ; [106.62532806,10.85408020] ; [106.62579346,10.85352993] ; [106.62599182,10.85316372] ; [106.62609863,10.85287094]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2091"
    ,"Station_Code":"Q12 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu vượt Quang Trung"
    ,"Station_Address":"B45, đường Quang Trung, Quận 12"
    ,"Lat":10.848996
    ,"Long":106.632679
    ,"Polyline":"[106.62615967,10.85289955] ; [106.62642670,10.85239029] ; [106.62658691,10.85214996] ; [106.62682343,10.85173988] ; [106.62699890,10.85146999] ; [106.62724304,10.85124969] ; [106.62750244,10.85111046] ; [106.62795258,10.85101032] ; [106.62911987,10.85079956] ; [106.63027954,10.85054970] ; [106.63091278,10.85035992] ; [106.63121796,10.85023022] ; [106.63152313,10.85004997] ; [106.63188934,10.84974957] ; [106.63273621,10.84914970]"
    ,"Distance":"902"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2056"
    ,"Station_Code":"Q12 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"154, đường Quang Trung, Quận 12"
    ,"Lat":10.847842
    ,"Long":106.634422
    ,"Polyline":"[106.63268280,10.84899616] ; [106.63274384,10.84909630] ; [106.63446808,10.84792137] ; [106.63442230,10.84784222]"
    ,"Distance":"253"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2093"
    ,"Station_Code":"QGV 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"927, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.844981
    ,"Long":106.638985
    ,"Polyline":"[106.63442230,10.84784222] ; [106.63898468,10.84498119]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2094"
    ,"Station_Code":"QGV 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"869-871 (Kế  A4-A5), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.843801
    ,"Long":106.640671
    ,"Polyline":"[106.63898468,10.84498119] ; [106.63902283,10.84504032] ; [106.63976288,10.84450722] ; [106.64010620,10.84428024] ; [106.64070892,10.84385967] ; [106.64067078,10.84380054]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2095"
    ,"Station_Code":"QGV 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Công ty  Đồng Tâm"
    ,"Station_Address":"819, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.842036
    ,"Long":106.643311
    ,"Polyline":"[106.64067078,10.84380054] ; [106.64070892,10.84385967] ; [106.64157867,10.84325314] ; [106.64239502,10.84269524] ; [106.64325714,10.84214973] ; [106.64334869,10.84208965] ; [106.64331055,10.84203625]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2098"
    ,"Station_Code":"QGV 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"751  (364), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.839758
    ,"Long":106.646347
    ,"Polyline":"[106.64334869,10.84208965] ; [106.64398956,10.84165955] ; [106.64470673,10.84117985] ; [106.64505768,10.84092045] ; [106.64555359,10.84053040] ; [106.64636230,10.83985996] ; [106.64640045,10.83983040]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2096"
    ,"Station_Code":"QGV 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngã ba  Tân Sơn"
    ,"Station_Address":"Đối diện 972 (Công ty ISUZU), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83902
    ,"Long":106.647728
    ,"Polyline":"[106.64634705,10.83975792] ; [106.64640045,10.83983040] ; [106.64674377,10.83953857] ; [106.64710999,10.83928013] ; [106.64730835,10.83918953] ; [106.64774323,10.83907986] ; [106.64772797,10.83901978]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2099"
    ,"Station_Code":"QGV 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Dệt may Phương Đông"
    ,"Station_Address":"695  (đối diện 97), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83839
    ,"Long":106.650246
    ,"Polyline":"[106.64774323,10.83907986] ; [106.65026093,10.83845043]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"2097"
    ,"Station_Code":"QGV 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trường THPT Nguyễn Công Trứ"
    ,"Station_Address":"Đối diện 842, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.837576
    ,"Long":106.653412
    ,"Polyline":"[106.65026093,10.83845043] ; [106.65342712,10.83763981]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"4627"
    ,"Station_Code":"QGV 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"12B, Quang Trung"
    ,"Station_Address":"Đối di ện 746 (12B), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836552
    ,"Long":106.657376
    ,"Polyline":"[106.65341187,10.83757591] ; [106.65737915,10.83655167]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"4628"
    ,"Station_Code":"QGV 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Công an  Quận Gò Vấp"
    ,"Station_Address":"Đối diện 628A  (9), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835561
    ,"Long":106.661367
    ,"Polyline":"[106.65737915,10.83655167] ; [106.66136932,10.83556080]"
    ,"Distance":"451"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"926"
    ,"Station_Code":"QGV 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chùa Hu ỳnh Kim"
    ,"Station_Address":"621, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.834918
    ,"Long":106.663395
    ,"Polyline":"[106.66136932,10.83556080] ; [106.66232300,10.83536053] ; [106.66296387,10.83513927] ; [106.66339874,10.83491802]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1665"
    ,"Station_Code":"QGV 179"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"VKSND Quận Gò Vấp"
    ,"Station_Address":"523, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833828
    ,"Long":106.665283
    ,"Polyline":"[106.66339874,10.83491802] ; [106.66374207,10.83479691] ; [106.66416168,10.83460236] ; [106.66446686,10.83443356] ; [106.66477966,10.83422756] ; [106.66505432,10.83405972] ; [106.66528320,10.83382797]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"987"
    ,"Station_Code":"QGV 180"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường Quang Trung"
    ,"Station_Address":"387, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.830791
    ,"Long":106.669167
    ,"Polyline":"[106.66528320,10.83382797] ; [106.66916656,10.83079147]"
    ,"Distance":"543"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"984"
    ,"Station_Code":"QGV 181"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhà Thờ Xóm Thuốc"
    ,"Station_Address":"305, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.829139
    ,"Long":106.672058
    ,"Polyline":"[106.66916656,10.83079147] ; [106.66921234,10.83084011] ; [106.66976166,10.83041954] ; [106.67011261,10.83018017] ; [106.67066956,10.82985973] ; [106.67208099,10.82919025] ; [106.67205811,10.82913876]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"986"
    ,"Station_Code":"QGV 182"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Xóm thuốc"
    ,"Station_Address":"205, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.828095
    ,"Long":106.67485
    ,"Polyline":"[106.67211914,10.82917976] ; [106.67269897,10.82892990] ; [106.67395020,10.82847977] ; [106.67482758,10.82816982]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"988"
    ,"Station_Code":"QGV 183"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Công ty 32"
    ,"Station_Address":"67, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.827308
    ,"Long":106.677185
    ,"Polyline":"[106.67485046,10.82809544] ; [106.67487335,10.82814980] ; [106.67603302,10.82772064] ; [106.67720795,10.82736969] ; [106.67718506,10.82730770]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"991"
    ,"Station_Code":"QGV 184"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Đối diện siêu thị Văn Lang, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.82661
    ,"Long":106.679153
    ,"Polyline":"[106.67718506,10.82730770] ; [106.67720795,10.82736969] ; [106.67819214,10.82702065] ; [106.67917633,10.82668972] ; [106.67915344,10.82660961]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"219"
    ,"Station_Code":"QGV 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Siêu Thị Big C Gò Vấp"
    ,"Station_Address":"Đối diện Big C, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.825682
    ,"Long":106.679606
    ,"Polyline":"[106.67917633,10.82668972] ; [106.67932129,10.82662964] ; [106.67945099,10.82651997] ; [106.67965698,10.82641983] ; [106.67974091,10.82633018] ; [106.67980194,10.82614994] ; [106.67981720,10.82602978] ; [106.67981720,10.82590961] ; [106.67977142,10.82577038]"
    ,"Distance":"169"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"222"
    ,"Station_Code":"QGV 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Xóm Cháy"
    ,"Station_Address":"629B, đường Nguy ễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.821751
    ,"Long":106.678764
    ,"Polyline":"[106.67974854,10.82577991] ; [106.67936707,10.82478046] ; [106.67925262,10.82439995] ; [106.67902374,10.82351971] ; [106.67893219,10.82271957] ; [106.67887115,10.82174969]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"221"
    ,"Station_Code":"QGV 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"151, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.818837
    ,"Long":106.678719
    ,"Polyline":"[106.67878723,10.82175350] ; [106.67871857,10.81883717]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"223"
    ,"Station_Code":"QGV 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Tân Sơn Nhất"
    ,"Station_Address":"37 - 39, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.815118
    ,"Long":106.678619
    ,"Polyline":"[106.67871857,10.81883717] ; [106.67861938,10.81511784]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"224"
    ,"Station_Code":"QPN 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Đầu công viên Gia Định"
    ,"Station_Address":"Đối diện cây xanh số 7, đ ường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.813568
    ,"Long":106.677868
    ,"Polyline":"[106.67861938,10.81511784] ; [106.67861938,10.81511784] ; [106.67866516,10.81450653] ; [106.67859650,10.81437492] ; [106.67855072,10.81425858] ; [106.67858124,10.81410027] ; [106.67800903,10.81354427] ; [106.67787170,10.81356812]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"225"
    ,"Station_Code":"QPN 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Cuối c ông viên Gia Định"
    ,"Station_Address":"Đối di ện số 5, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.809764
    ,"Long":106.674591
    ,"Polyline":"[106.67800903,10.81354427] ; [106.67467499,10.80972481]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"226"
    ,"Station_Code":"QPN 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đầu Đư ờng Đào Duy Anh"
    ,"Station_Address":"155, đường Đào Duy Anh, Quận Phú Nhuận"
    ,"Lat":10.807978
    ,"Long":106.674057
    ,"Polyline":"[106.67459106,10.80976391] ; [106.67362976,10.80832958] ; [106.67408752,10.80803013] ; [106.67405701,10.80797768]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"228"
    ,"Station_Code":"QPN 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cuối Đường Đào Duy Anh"
    ,"Station_Address":"7-9, đường Đào Duy Anh, Quận Phú Nhuận"
    ,"Lat":10.805891
    ,"Long":106.677177
    ,"Polyline":"[106.67408752,10.80803013] ; [106.67648315,10.80646038] ; [106.67723083,10.80597019]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"230"
    ,"Station_Code":"QPN 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Đầu đường Hồ Văn Huê"
    ,"Station_Address":"129, đường Hồ Văn Huê, Quận Phú Nhuận"
    ,"Lat":10.804737
    ,"Long":106.677689
    ,"Polyline":"[106.67723083,10.80597019] ; [106.67812347,10.80539989] ; [106.67774963,10.80471039]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"227"
    ,"Station_Code":"QPN 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Tháp Nước"
    ,"Station_Address":"43B, đường Hồ Văn Huê, Quận Phú Nhuận"
    ,"Lat":10.802824
    ,"Long":106.676602
    ,"Polyline":"[106.67774963,10.80471039] ; [106.67668152,10.80278015]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"229"
    ,"Station_Code":"QPN 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Trung tâm hội nghị tiệc cưới White Palace"
    ,"Station_Address":"1B, đường Hồ Văn  Huê, Quận Phú Nhuận"
    ,"Lat":10.800174
    ,"Long":106.675068
    ,"Polyline":"[106.67668152,10.80278015] ; [106.67590332,10.80136967] ; [106.67516327,10.80014038]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"232"
    ,"Station_Code":"QPN 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"59, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799094
    ,"Long":106.679247
    ,"Polyline":"[106.67516327,10.80014038] ; [106.67494965,10.79979038] ; [106.67492676,10.79959011] ; [106.67604065,10.79950047] ; [106.67784882,10.79934025]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"558"
    ,"Station_Code":"QPN 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"171, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.800241
    ,"Long":106.681541
    ,"Polyline":"[106.67924500,10.79913139] ; [106.68000793,10.79918957] ; [106.68028259,10.79920006] ; [106.68048096,10.79924011] ; [106.68096161,10.79973984] ; [106.68151093,10.80027008] ; [106.68154144,10.80024147]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"513"
    ,"Station_Code":"QPN 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"141 - 143, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802197
    ,"Long":106.683619
    ,"Polyline":"[106.68154144,10.80024147] ; [106.68151093,10.80027008] ; [106.68286133,10.80163956] ; [106.68315887,10.80191994] ; [106.68361664,10.80219746]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"514"
    ,"Station_Code":"QPN 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"109, đường Phan Đăng Lưu, Quận Phú Nhu ận"
    ,"Lat":10.803841
    ,"Long":106.686156
    ,"Polyline":"[106.68361664,10.80219746] ; [106.68470764,10.80344963] ; [106.68492889,10.80364037] ; [106.68515778,10.80383015] ; [106.68544006,10.80395031] ; [106.68560028,10.80397987] ; [106.68576050,10.80399036] ; [106.68614960,10.80393982] ; [106.68615723,10.80384064]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"515"
    ,"Station_Code":"QPN 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Bệnh Viện Phước An"
    ,"Station_Address":"81  - 83, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.80362
    ,"Long":106.687744
    ,"Polyline":"[106.68615723,10.80384064] ; [106.68688202,10.80382538] ; [106.68737793,10.80374146] ; [106.68774414,10.80362034]"
    ,"Distance":"177"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"516"
    ,"Station_Code":"QBTH 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Công an  PCCC"
    ,"Station_Address":"45, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803188
    ,"Long":106.691371
    ,"Polyline":"[106.68774414,10.80362034] ; [106.68869019,10.80360985] ; [106.69014740,10.80343533] ; [106.69136810,10.80318832]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"517"
    ,"Station_Code":"QBTH 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Lăng Ông Bà Chiểu"
    ,"Station_Address":"1,  đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802455
    ,"Long":106.696826
    ,"Polyline":"[106.69136810,10.80318832] ; [106.69271088,10.80306721] ; [106.69474792,10.80281925] ; [106.69587708,10.80267143] ; [106.69682312,10.80245495]"
    ,"Distance":"603"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ B à Chiểu"
    ,"Station_Address":"473C, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69682312,10.80245495] ; [106.69731903,10.80251312] ; [106.69795990,10.80245972] ; [106.69858551,10.80256653] ; [106.69895935,10.80278206] ; [106.69924927,10.80286694] ; [106.69955444,10.80296135]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Tòa Án  nhân dân Quận Bình Thạnh"
    ,"Station_Address":"449 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69955444,10.80296135] ; [106.69955444,10.80296135] ; [106.70026398,10.80331421] ; [106.70071411,10.80349922] ; [106.70117950,10.80362511] ; [106.70117950,10.80362511]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Chùa B ồ Đề"
    ,"Station_Address":"375, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70117950,10.80362511] ; [106.70153809,10.80381489] ; [106.70172882,10.80383968] ; [106.70278168,10.80356026] ; [106.70324707,10.80346012] ; [106.70365143,10.80342007] ; [106.70372009,10.80341434] ; [106.70398712,10.80329323]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70398712,10.80329323] ; [106.70473480,10.80331421] ; [106.70602417,10.80322456] ; [106.70671082,10.80307674]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70670319,10.80317020] ; [106.70815277,10.80307007] ; [106.70899200,10.80300045] ; [106.70997620,10.80294991] ; [106.71053314,10.80290031]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"476"
    ,"Station_Code":"QBTH 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trường Hutech"
    ,"Station_Address":"500-502, đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.800864
    ,"Long":106.714287
    ,"Polyline":"[106.71053314,10.80290031] ; [106.71114349,10.80286026] ; [106.71138763,10.80284023] ; [106.71137238,10.80249977] ; [106.71132660,10.80160999] ; [106.71128082,10.80160046] ; [106.71121979,10.80156994] ; [106.71115875,10.80150032] ; [106.71115112,10.80144024] ; [106.71115875,10.80136967] ; [106.71118164,10.80132008] ; [106.71125031,10.80126953] ; [106.71132660,10.80123997] ; [106.71138763,10.80125046] ; [106.71147919,10.80128956] ; [106.71234131,10.80130005] ; [106.71283722,10.80125999] ; [106.71347809,10.80117989] ; [106.71401215,10.80105019] ; [106.71414185,10.80101013]"
    ,"Distance":"640"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"473"
    ,"Station_Code":"QBTH 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Khu Du lịch Văn Thánh"
    ,"Station_Address":"600, đường Điện Biên Phủ, Quận Bình Th ạnh"
    ,"Lat":10.799547
    ,"Long":106.717409
    ,"Polyline":"[106.71428680,10.80086422] ; [106.71469879,10.80084991] ; [106.71527863,10.80066013] ; [106.71617889,10.80035019] ; [106.71685791,10.80000973] ; [106.71720886,10.79983044] ; [106.71740723,10.79954720]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"475"
    ,"Station_Code":"QBTH 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Cầu Sài Gòn"
    ,"Station_Address":"658 , đường Điện Biên Phủ, Quận Bình Thạnh"
    ,"Lat":10.798525
    ,"Long":106.719496
    ,"Polyline":"[106.71740723,10.79954720] ; [106.71833801,10.79920959] ; [106.71943665,10.79856968] ; [106.71949768,10.79852486]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"477"
    ,"Station_Code":"Q2 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Cầu Đen"
    ,"Station_Address":"794 , đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.799978
    ,"Long":106.7342
    ,"Polyline":"[106.71943665,10.79856968] ; [106.72039795,10.79808044] ; [106.72083282,10.79792976] ; [106.72122955,10.79782009] ; [106.72164154,10.79780960] ; [106.72203064,10.79780006] ; [106.72254944,10.79782963] ; [106.72306824,10.79790020] ; [106.72422791,10.79811001] ; [106.72696686,10.79862022] ; [106.73007202,10.79920006] ; [106.73149872,10.79944992] ; [106.73229980,10.79963970] ; [106.73371887,10.80000019] ; [106.73417664,10.80008984]"
    ,"Distance":"1676"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"478"
    ,"Station_Code":"Q2 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Thảo Điền"
    ,"Station_Address":"Đối diện ngã 3 Thảo Điền, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.800838
    ,"Long":106.738899
    ,"Polyline":"[106.73419952,10.79997826] ; [106.73553467,10.80037403] ; [106.73753357,10.80075359] ; [106.73889923,10.80083847]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"480"
    ,"Station_Code":"Q2 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Metro Quận 2"
    ,"Station_Address":"170, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.801584
    ,"Long":106.742928
    ,"Polyline":"[106.73889923,10.80083847] ; [106.74015808,10.80118561] ; [106.74160767,10.80151272] ; [106.74292755,10.80158424]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"479"
    ,"Station_Code":"Q2 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Cát Lái"
    ,"Station_Address":"Khu dân cư Estella, đường Xa Lộ Hà Nội, Quận 2"
    ,"Lat":10.802592
    ,"Long":106.748089
    ,"Polyline":"[106.74292755,10.80158424] ; [106.74306488,10.80175972] ; [106.74376678,10.80189037] ; [106.74430084,10.80200958] ; [106.74456787,10.80204010.06.74524689] ; [10.80206966,106.74575806] ; [10.80202961,106.74610901] ; [10.80202007,106.74642181] ; [10.80206966,106.74662781] ; [10.80214024,106.74687958] ; [10.80226040,106.74725342] ; [10.80241966,106.74761963] ; [10.80255032,106.74806213] ; [10.80268955,106.74809265]"
    ,"Distance":"600"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"482"
    ,"Station_Code":"Q9 210"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Xi măng hà tiên - trạm thu phí"
    ,"Station_Address":"249B, đường Xa Lộ Hà Nội,  Quận 9"
    ,"Lat":10.819206
    ,"Long":106.758394
    ,"Polyline":"[106.74806213,10.80266953] ; [106.74839020,10.80274010.06.74859619] ; [10.80278015,106.74897003] ; [10.80292034,106.74938202] ; [10.80301952,106.74983215] ; [10.80315971,106.75074005] ; [10.80352020,106.75142670] ; [10.80387974,106.75209045] ; [10.80432034,106.75256348] ; [10.80461979,106.75302124] ; [10.80500984,106.75366974] ; [10.80558968,106.75424194] ; [10.80618000,106.75460052] ; [10.80661964,106.75485229] ; [10.80694962,106.75514221] ; [10.80733013,106.75559235] ; [10.80803967,106.75594330] ; [10.80877018,106.75621796] ; [10.80947018,106.75650787] ; [10.81050968,106.75662994] ; [10.81101990,106.75669098] ; [10.81138992,106.75765228] ; [10.81647015,106.75775909] ; [10.81698036,106.75784302] ; [10.81725025,106.75814056] ; [10.81892967,106.75833130] ; [10.81906033,106.75836945]"
    ,"Distance":"2350"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"481"
    ,"Station_Code":"Q9 211"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngã 4 Tây Hòa (RMK)"
    ,"Station_Address":"185A , đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.825972
    ,"Long":106.760775
    ,"Polyline":"[106.75836945,10.81912041] ; [106.75858307,10.82100868] ; [106.75972748,10.82420158] ; [106.76068115,10.82600975]"
    ,"Distance":"836"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"485"
    ,"Station_Code":"Q9 212"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trạm xây dựng"
    ,"Station_Address":"354A, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.829955
    ,"Long":106.76312
    ,"Polyline":"[106.76077271,10.82597160] ; [106.76112366,10.82678032] ; [106.76235962,10.82892036] ; [106.76312256,10.82995510]"
    ,"Distance":"515"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"483"
    ,"Station_Code":"Q9 213"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Khu QLGTDT  số 2"
    ,"Station_Address":"Khu  QLGTĐT số 2, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.833249
    ,"Long":106.764778
    ,"Polyline":"[106.76312256,10.82995510.06.76312256] ; [10.82995510.06.76359558,10.83101940] ; [106.76416016,10.83214664] ; [106.76477814,10.83325005] ; [106.76477814,10.83324909] ; [106.76477814,10.83324909]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1025"
    ,"Station_Code":"Q9 214"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Ngã 4 B ình Thái"
    ,"Station_Address":"Kho 71, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.836162
    ,"Long":106.76666
    ,"Polyline":"[106.76477814,10.83324909] ; [106.76477814,10.83324909] ; [106.76477814,10.83325005] ; [106.76568604,10.83470726] ; [106.76612091,10.83548737] ; [106.76666260,10.83616161] ; [106.76666260,10.83616161]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1030"
    ,"Station_Code":"Q9 215"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"UBND qu ận 9"
    ,"Station_Address":"1B, đường Xa Lộ Hà Nội, Qu ận 9"
    ,"Lat":10.840466
    ,"Long":106.769074
    ,"Polyline":"[106.76666260,10.83616161] ; [106.76666260,10.83616161] ; [106.76736450,10.83777428] ; [106.76822662,10.83934021] ; [106.76907349,10.84046555] ; [106.76907349,10.84046555]"
    ,"Distance":"550"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1026"
    ,"Station_Code":"Q9 216"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Bê tông Hải Âu"
    ,"Station_Address":"Bê tông Hải Âu, đường Xa L ộ Hà Nội, Quận 9"
    ,"Lat":10.843834
    ,"Long":106.77079
    ,"Polyline":"[106.76907349,10.84046555] ; [106.76907349,10.84046555] ; [106.76931000,10.84120941] ; [106.77010345,10.84256840] ; [106.77076721,10.84383965] ; [106.77079010,10.84383392] ; [106.77079010,10.84383392]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1028"
    ,"Station_Code":"Q9 217"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Ngã 4 Thủ Đức"
    ,"Station_Address":"712, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.847142
    ,"Long":106.772974
    ,"Polyline":"[106.77079010,10.84383392] ; [106.77076721,10.84383965] ; [106.77150726,10.84517956] ; [106.77175903,10.84545994] ; [106.77204132,10.84582996] ; [106.77229309,10.84620953] ; [106.77261353,10.84668827] ; [106.77297211,10.84714222]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1502"
    ,"Station_Code":"Q9 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Siêu th ị Coopmark"
    ,"Station_Address":"4-6, đường L ê Văn Việt, Quận 9"
    ,"Lat":10.848192
    ,"Long":106.775032
    ,"Polyline":"[106.77282715,10.84714031] ; [106.77333069,10.84799957] ; [106.77368927,10.84848976] ; [106.77414703,10.84902954] ; [106.77481079,10.84844971] ; [106.77507782,10.84823990]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1504"
    ,"Station_Code":"Q9 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Bệnh viện 7C-Trường Quân y 2"
    ,"Station_Address":"50 , đường Lê Văn Việt, Quận 9"
    ,"Lat":10.846262
    ,"Long":106.778124
    ,"Polyline":"[106.77503204,10.84819221] ; [106.77507782,10.84823990] ; [106.77516937,10.84815979] ; [106.77583313,10.84768963] ; [106.77671051,10.84718037] ; [106.77778625,10.84655952] ; [106.77812195,10.84626198]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1495"
    ,"Station_Code":"Q9 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Nhà sách Thành Nghĩa"
    ,"Station_Address":"142-144, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.84486
    ,"Long":106.780563
    ,"Polyline":"[106.77812195,10.84626198] ; [106.77863312,10.84607983] ; [106.77919769,10.84576035] ; [106.78016663,10.84522343] ; [106.78043365,10.84501839] ; [106.78056335,10.84486008]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1497"
    ,"Station_Code":"Q9 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Cổng Đình Phong Phú"
    ,"Station_Address":"188, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844114
    ,"Long":106.782028
    ,"Polyline":"[106.78056335,10.84486008] ; [106.78066254,10.84487057] ; [106.78103638,10.84461021] ; [106.78141785,10.84442043] ; [106.78205872,10.84416962] ; [106.78202820,10.84411430]"
    ,"Distance":"190"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1499"
    ,"Station_Code":"Q9 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Chợ nhỏ"
    ,"Station_Address":"278, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844128
    ,"Long":106.784261
    ,"Polyline":"[106.78205872,10.84416962] ; [106.78231049,10.84407997] ; [106.78260040,10.84401035] ; [106.78273010,10.84399986] ; [106.78327179,10.84405994] ; [106.78388214,10.84414959] ; [106.78428650,10.84422016]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1506"
    ,"Station_Code":"Q9 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"65"
    ,"Station_Name":"Chợ Tăng Nhơn Phú- Trường Trần Quốc Toản"
    ,"Station_Address":"424A-424B, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.844439
    ,"Long":106.788939
    ,"Polyline":"[106.78428650,10.84422016] ; [106.78515625,10.84438038] ; [106.78539276,10.84440994] ; [106.78553772,10.84447956] ; [106.78610992,10.84486961] ; [106.78617096,10.84496021] ; [106.78630066,10.84504032] ; [106.78656006,10.84514999] ; [106.78697968,10.84519005] ; [106.78733063,10.84517002] ; [106.78765106,10.84504032] ; [106.78823853,10.84480000] ; [106.78855133,10.84461021] ; [106.78891754,10.84445000]"
    ,"Distance":"566"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1501"
    ,"Station_Code":"Q9 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"66"
    ,"Station_Name":"Bệnh viện Quận 9"
    ,"Station_Address":"Đối diện Bệnh viện Quận 9, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.8446
    ,"Long":106.790977
    ,"Polyline":"[106.78891754,10.84445000] ; [106.78904724,10.84440041] ; [106.78929138,10.84436035] ; [106.78964233,10.84432983] ; [106.78981781,10.84436035] ; [106.79096222,10.84465981]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"1508"
    ,"Station_Code":"Q9 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"67"
    ,"Station_Name":"Đại Học GTVT"
    ,"Station_Address":"Đối diện 451, đường Lê Văn Việt, Quận 9"
    ,"Lat":10.845276
    ,"Long":106.793922
    ,"Polyline":"[106.79096222,10.84465981] ; [106.79222107,10.84494019] ; [106.79370117,10.84529018] ; [106.79383087,10.84531975]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"75"
    ,"Station_Id":"3185"
    ,"Station_Code":"BX 30"
    ,"Station_Direction":"1"
    ,"Station_Order":"68"
    ,"Station_Name":"Khu Công Nghệ cao"
    ,"Station_Address":"ĐẦU BẾN KCN CAO QUẬN 9, đường Lê Văn Vi ệt, Quận 9"
    ,"Lat":10.847352
    ,"Long":106.799606
    ,"Polyline":"[106.79392242,10.84527588] ; [106.79962921,10.84681511] ; [106.79927826,10.84729958] ; [106.79960632,10.84735203]"
    ,"Distance":"750"
  }]