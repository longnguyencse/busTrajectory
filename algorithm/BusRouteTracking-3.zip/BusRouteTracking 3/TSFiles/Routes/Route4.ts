export const Route4 =[
  {
     "Route_Id":"4"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"171"
    ,"Station_Code":"Q12 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"601, đường Trường Chinh, Quận 12"
    ,"Lat":10.841209
    ,"Long":106.615925
    ,"Polyline":"[106.61337280,10.84373760] ; [106.61407471,10.84444427] ; [106.61506653,10.84286308] ; [106.61502075,10.84263706] ; [106.61511230,10.84248447] ; [106.61524200,10.84238434] ; [106.61534882,10.84235764] ; [106.61555481,10.84191990] ; [106.61582184,10.84146690] ; [106.61592865,10.84120941]"
    ,"Distance":"535"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"167"
    ,"Station_Code":"Q12 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"487, đường Trường Chinh, Quận 12"
    ,"Lat":10.837863
    ,"Long":106.618044
    ,"Polyline":"[106.61592865,10.84120941] ; [106.61804199,10.83786297]"
    ,"Distance":"439"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"172"
    ,"Station_Code":"Q12 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa Lạc Quang"
    ,"Station_Address":"257, đường Trường Chinh , Quận 12"
    ,"Lat":10.834623
    ,"Long":106.620163
    ,"Polyline":"[106.61804199,10.83786297] ; [106.62016296,10.83462334]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"168"
    ,"Station_Code":"Q12 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"Chùa Vĩnh Phước, đường Trường Chinh, Quận 12"
    ,"Lat":10.831836
    ,"Long":106.621928
    ,"Polyline":"[106.62016296,10.83462334] ; [106.62192535,10.83183575]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"170"
    ,"Station_Code":"Q12 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"113, đường Trường Chinh, Quận 12"
    ,"Lat":10.82898
    ,"Long":106.623768
    ,"Polyline":"[106.62192535,10.83183575] ; [106.62377167,10.82898045]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đường Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62377167,10.82898045] ; [106.62490082,10.82740498] ; [106.62586212,10.82623959]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trường Chinh, Quận T ân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62586212,10.82623959] ; [106.62821198,10.82417011] ; [106.62915039,10.82339001] ; [106.62965393,10.82278919] ; [106.63005066,10.82213020]"
    ,"Distance":"652"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm KCN Tân Bình"
    ,"Station_Address":"881, đường Trường Chinh, Qu ận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63005066,10.82213020] ; [106.63049316,10.82034397] ; [106.63061523,10.81938553]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63061523,10.81938553] ; [106.63138580,10.81704617]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chế Lan Viên"
    ,"Station_Address":"28/7B, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63138580,10.81704617] ; [106.63258362,10.81291485]"
    ,"Distance":"478"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63258362,10.81291485] ; [106.63426208,10.80820942]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"178"
    ,"Station_Code":"QTB 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"680 (Thượng Uyển), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.806144
    ,"Long":106.636055
    ,"Polyline":"[106.63426208,10.80820942] ; [106.63461304,10.80761433] ; [106.63501740,10.80716133] ; [106.63545227,10.80672932] ; [106.63578796,10.80642891] ; [106.63605499,10.80614376]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"180"
    ,"Station_Code":"QTB 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Tân Kỳ Tân Quý"
    ,"Station_Address":"401, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.803541
    ,"Long":106.637887
    ,"Polyline":"[106.63605499,10.80614376] ; [106.63661957,10.80553818] ; [106.63706970,10.80488491] ; [106.63750458,10.80420971] ; [106.63788605,10.80354595]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"181"
    ,"Station_Code":"QTB 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm ETown"
    ,"Station_Address":"364 (công ty Ree), đường C ộng Hòa, Quận Tân Bình"
    ,"Lat":10.802371
    ,"Long":106.640253
    ,"Polyline":"[106.63788605,10.80354595] ; [106.63788605,10.80354595] ; [106.63835144,10.80308819] ; [106.63877869,10.80281353] ; [106.63918304,10.80263996] ; [106.63960266,10.80252361] ; [106.64024353,10.80237103] ; [106.64024353,10.80237103]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"179"
    ,"Station_Code":"QTB 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã ba Bình Giã"
    ,"Station_Address":"303, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802055
    ,"Long":106.644292
    ,"Polyline":"[106.64024353,10.80237103] ; [106.64429474,10.80206299]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"183"
    ,"Station_Code":"QTB 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"19A (Công ty Lô Hội), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801544
    ,"Long":106.650413
    ,"Polyline":"[106.64429474,10.80206299] ; [106.65027618,10.80152798]"
    ,"Distance":"657"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"182"
    ,"Station_Code":"QTB 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Pico Plaza"
    ,"Station_Address":"20Bis, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801254
    ,"Long":106.653637
    ,"Polyline":"[106.65027618,10.80152798] ; [106.65370178,10.80123329]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"185"
    ,"Station_Code":"QTB 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Út tịch"
    ,"Station_Address":"35-37, đ ường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.800985
    ,"Long":106.656679
    ,"Polyline":"[106.65370178,10.80123329] ; [106.65662384,10.80099297]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"184"
    ,"Station_Code":"QTB 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"Đối diện 58 (Siêu thị Maximart ), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.800833
    ,"Long":106.658819
    ,"Polyline":"[106.65662384,10.80099297] ; [106.65888214,10.80085373] ; [106.65922546,10.80075645]"
    ,"Distance":"286"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65882111,10.80083275] ; [106.65922546,10.80075645] ; [106.66062164,10.80064774] ; [106.66075897,10.80051613] ; [106.66075897,10.80037403] ; [106.66077423,10.80024242] ; [106.66091156,10.80016327] ; [106.66111755,10.80025291] ; [106.66127777,10.80042171] ; [106.66164398,10.80059528] ; [106.66255951,10.80058479] ; [106.66330719,10.80050278] ; [106.66330719,10.80052662]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80050278] ; [106.66635132,10.80023193]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"188"
    ,"Station_Code":"QPN 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cây xăng Quân khu 7"
    ,"Station_Address":"307, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.799605
    ,"Long":106.668416
    ,"Polyline":"[106.66635132,10.80023193] ; [106.66679382,10.80025768] ; [106.66738892,10.80021572] ; [106.66782379,10.80006313] ; [106.66820526,10.79982090] ; [106.66841888,10.79960537]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"190"
    ,"Station_Code":"QPN 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Ngã Ba Nguyễn Trọng Tuyển"
    ,"Station_Address":"279, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.798105
    ,"Long":106.671089
    ,"Polyline":"[106.66841888,10.79960537] ; [106.67108917,10.79810524]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"191"
    ,"Station_Code":"QPN 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cổng Xe lửa"
    ,"Station_Address":"253, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.796395
    ,"Long":106.673965
    ,"Polyline":"[106.67108917,10.79810524] ; [106.67396545,10.79639530]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"189"
    ,"Station_Code":"QPN 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trung tâm  Văn hóa Quận Phú Nhuận"
    ,"Station_Address":"157 , đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.795297
    ,"Long":106.675804
    ,"Polyline":"[106.67396545,10.79639530] ; [106.67580414,10.79529667]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"193"
    ,"Station_Code":"QPN 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trần Huy Li ệu"
    ,"Station_Address":"101, đường Nguyễn Văn  Trỗi, Quận Phú Nhuận"
    ,"Lat":10.793276
    ,"Long":106.679167
    ,"Polyline":"[106.67580414,10.79529667] ; [106.67916870,10.79327583]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"192"
    ,"Station_Code":"Q3 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Chùa Vĩnh Nghiêm"
    ,"Station_Address":"321-323, đường Nam  Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.790381
    ,"Long":106.683022
    ,"Polyline":"[106.67916870,10.79327583] ; [106.67916870,10.79327583] ; [106.68019867,10.79280758] ; [106.68131256,10.79212189] ; [106.68244171,10.79109955] ; [106.68302155,10.79038143] ; [106.68302155,10.79038143]"
    ,"Distance":"538"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"196"
    ,"Station_Code":"Q3 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trần Quốc Toản"
    ,"Station_Address":"201 A, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.786831
    ,"Long":106.686897
    ,"Polyline":"[106.68302155,10.79038143] ; [106.68689728,10.78683090]"
    ,"Distance":"579"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"194"
    ,"Station_Code":"Q3 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Viện Paster"
    ,"Station_Address":"179, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.785213
    ,"Long":106.688637
    ,"Polyline":"[106.68689728,10.78683090] ; [106.68863678,10.78521347]"
    ,"Distance":"262"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"198"
    ,"Station_Code":"Q3 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"159 Ter , đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.782798
    ,"Long":106.691376
    ,"Polyline":"[106.68863678,10.78521347] ; [106.69137573,10.78279781]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"195"
    ,"Station_Code":"Q3 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Coop Mart Nguy ễn Đình Chiểu"
    ,"Station_Address":"145, đường  Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.78113
    ,"Long":106.693152
    ,"Polyline":"[106.69137573,10.78279781] ; [106.69315338,10.78112984]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"197"
    ,"Station_Code":"Q3 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"Đối diện 166 - 168, đường Nam Kỳ Khởi Ngh ĩa, Quận 3"
    ,"Lat":10.779777
    ,"Long":106.694626
    ,"Polyline":"[106.69315338,10.78112984] ; [106.69462585,10.77977657]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"200"
    ,"Station_Code":"Q1 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Tòa Án Thành Phố"
    ,"Station_Address":"131, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.776052
    ,"Long":106.698647
    ,"Polyline":"[106.69462585,10.77977657] ; [106.69864655,10.77605247]"
    ,"Distance":"604"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"199"
    ,"Station_Code":"Q1 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chùa Ông"
    ,"Station_Address":"Đối diện 96A, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.773957
    ,"Long":106.699722
    ,"Polyline":"[106.69864655,10.77605247] ; [106.69903564,10.77582264] ; [106.69972229,10.77395725]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"201"
    ,"Station_Code":"Q1 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường CĐKT Cao Thắng"
    ,"Station_Address":"Đối diện 86, đường Nam Kỳ Khởi Nghĩa, Quận 1"
    ,"Lat":10.771416
    ,"Long":106.700851
    ,"Polyline":"[106.69972229,10.77395725] ; [106.70085144,10.77141571]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Công ty Đường sắt"
    ,"Station_Address":"136, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70085144,10.77141571] ; [106.70112610,10.77104855] ; [106.69935608,10.77116299]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"202"
    ,"Station_Code":"Q1TC1C"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Bến Thành C"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770787
    ,"Long":106.698532
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69902802,10.77101707] ; [106.69853210,10.77078724]"
    ,"Distance":"99"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853210,10.77078724] ; [106.69595337,10.76980972]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171,  đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt  Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69398499,10.76903534] ; [106.68960571,10.76719570] ; [106.68936157,10.76767635]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt S ài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68920135,10.76814461] ; [106.69033813,10.76855087]"
    ,"Distance":"187"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New  world"
    ,"Station_Address":"Đối diện 1A Phạm  Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"29"
    ,"Station_Code":"Q1TC1E"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành E"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.77054
    ,"Long":106.698448
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69783783,10.77157593] ; [106.69803619,10.77154922] ; [106.69803619,10.77144909] ; [106.69808960,10.77138615] ; [106.69814301,10.77129078] ; [106.69820404,10.77122211] ; [106.69831085,10.77117538] ; [106.69841766,10.77114296] ; [106.69856262,10.77115345] ; [106.69868469,10.77118587] ; [106.69882965,10.77109623] ; [106.69895935,10.77100658] ; [106.69930267,10.77043724] ; [106.69810486,10.76940441] ; [106.69744110,10.77022076] ; [106.69844818,10.77054024]"
    ,"Distance":"763"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69844818,10.77054024] ; [106.69921112,10.77097511] ; [106.69956207,10.77094269]"
    ,"Distance":"135"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm  Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77094269] ; [106.70195770,10.77082157]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"4271"
    ,"Station_Code":"Q1 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Đền Thờ Ấn Giáo, Pasteur"
    ,"Station_Address":"Đền Thờ Ấn Gi áo, đường Pasteur, Quận 1"
    ,"Lat":10.773595
    ,"Long":106.70139
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70251465,10.77084255] ; [106.70139313,10.77359486]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"2724"
    ,"Station_Code":"Q1 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Lê Thánh Tôn"
    ,"Station_Address":"144, đường Pasteur, Quận 1"
    ,"Lat":10.775088
    ,"Long":106.700768
    ,"Polyline":"[106.70139313,10.77359486] ; [106.70076752,10.77508831]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"4272"
    ,"Station_Code":"Q1 080"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Lý Tự Trọng"
    ,"Station_Address":"158, đường Pasteur, Quận 1"
    ,"Lat":10.777089
    ,"Long":106.699657
    ,"Polyline":"[106.70076752,10.77508831] ; [106.70024109,10.77618694] ; [106.69995117,10.77681923] ; [106.69965363,10.77708912]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"4273"
    ,"Station_Code":"Q1 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Công viên 30/4"
    ,"Station_Address":"178, đường Pasteur, Quận 1"
    ,"Lat":10.778307999999999
    ,"Long":106.698333
    ,"Polyline":"[106.69965363,10.77708912] ; [106.69833374,10.77830791]"
    ,"Distance":"198"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"4274"
    ,"Station_Code":"Q1 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nguyễn Thị Minh Khai"
    ,"Station_Address":"184 , đường Pasteur, Quận 1"
    ,"Lat":10.779782
    ,"Long":106.696659
    ,"Polyline":"[106.69833374,10.77830791] ; [106.69665527,10.77978230]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"243"
    ,"Station_Code":"Q3 082"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Đại học Kiến Trúc"
    ,"Station_Address":"194 D, đường Pasteur, Quận 3"
    ,"Lat":10.781804
    ,"Long":106.694579
    ,"Polyline":"[106.69665527,10.77978230] ; [106.69458008,10.78180408]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"244"
    ,"Station_Code":"Q3 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Sở Tư Pháp"
    ,"Station_Address":"214, đường Pasteur, Quận 3"
    ,"Lat":10.783419
    ,"Long":106.692749
    ,"Polyline":"[106.69458008,10.78180408] ; [106.69364166,10.78258896] ; [106.69274902,10.78341866]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"245"
    ,"Station_Code":"Q3 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Điện Biên Phủ"
    ,"Station_Address":"232, đường Pasteur, Quận 3"
    ,"Lat":10.784924
    ,"Long":106.691145
    ,"Polyline":"[106.69274902,10.78341866] ; [106.69194031,10.78415966] ; [106.69114685,10.78492355]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"246"
    ,"Station_Code":"Q3 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Viện Pasteur"
    ,"Station_Address":"Đối diện 153 A-B, đường Võ Thị Sáu, Quận 3"
    ,"Lat":10.785583
    ,"Long":106.689613
    ,"Polyline":"[106.69114685,10.78492355] ; [106.69000244,10.78592014] ; [106.68961334,10.78558254]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"247"
    ,"Station_Code":"Q3 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Viện Paster"
    ,"Station_Address":"252 (Đối diện 173), đường Nam Kỳ Khởi  Nghĩa, Quận 3"
    ,"Lat":10.785577
    ,"Long":106.688683
    ,"Polyline":"[106.68961334,10.78558254] ; [106.68961334,10.78558254] ; [106.68945313,10.78546143] ; [106.68929291,10.78534031] ; [106.68908691,10.78522396] ; [106.68887329,10.78539276] ; [106.68868256,10.78557682] ; [106.68868256,10.78557682]"
    ,"Distance":"130"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"248"
    ,"Station_Code":"Q3 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngân hàng Sacombank"
    ,"Station_Address":"260, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.787047
    ,"Long":106.687133
    ,"Polyline":"[106.68868256,10.78557682] ; [106.68713379,10.78704739]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"250"
    ,"Station_Code":"Q3 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Lý Chính Thắng"
    ,"Station_Address":"288 B7, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.789245
    ,"Long":106.684746
    ,"Polyline":"[106.68713379,10.78704739] ; [106.68474579,10.78924465]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"249"
    ,"Station_Code":"Q3 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chùa Vĩnh Nghiêm"
    ,"Station_Address":"382E, đường Nam Kỳ Khởi Nghĩa, Quận 3"
    ,"Lat":10.790694
    ,"Long":106.683125
    ,"Polyline":"[106.68474579,10.78924465] ; [106.68312836,10.79069424]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"251"
    ,"Station_Code":"QPN 048"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trần Huy Liệu"
    ,"Station_Address":"40, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.793598
    ,"Long":106.679236
    ,"Polyline":"[106.68312836,10.79069424] ; [106.68120575,10.79242802] ; [106.67923737,10.79359818]"
    ,"Distance":"537"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"252"
    ,"Station_Code":"QPN 049"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trung tâm văn hóa Quận Phú Nhuận"
    ,"Station_Address":"68, đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.795452
    ,"Long":106.676034
    ,"Polyline":"[106.67923737,10.79359818] ; [106.67604065,10.79549980]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"253"
    ,"Station_Code":"QPN 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Học viện Hàng kHông"
    ,"Station_Address":"104 , đường Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.79677
    ,"Long":106.673797
    ,"Polyline":"[106.67604065,10.79549980] ; [106.67379761,10.79677010]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"254"
    ,"Station_Code":"QPN 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bệnh viện  Quận Phú Nhuận"
    ,"Station_Address":"142, đư ờng Nguyễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.798456
    ,"Long":106.670911
    ,"Polyline":"[106.67379761,10.79677010.06.67091370]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"255"
    ,"Station_Code":"QPN 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Cây xăng  Quân khu 7"
    ,"Station_Address":"180, đường Nguy ễn Văn Trỗi, Quận Phú Nhuận"
    ,"Lat":10.799642
    ,"Long":106.66891
    ,"Polyline":"[106.67091370,10.79845619] ; [106.66890717,10.79964161]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu 7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66890717,10.79964161] ; [106.66763306,10.80029488] ; [106.66698456,10.80067444] ; [106.66662598,10.80095100]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"257"
    ,"Station_Code":"QTB 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công viên Hoàng Văn Thụ"
    ,"Station_Address":"Công viên Hoàng Văn Thụ, đường Phan Thúc Duyện, Qu ận Tân Bình"
    ,"Lat":10.802403
    ,"Long":106.664221
    ,"Polyline":"[106.66662598,10.80095100] ; [106.66583252,10.80145454] ; [106.66416931,10.80236053]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Trần Quốc Hoàn,  Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66416931,10.80236053] ; [106.66357422,10.80268764] ; [106.66230011,10.80137253]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"259"
    ,"Station_Code":"QTB 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Siêu thị Maximark Cộng Hòa"
    ,"Station_Address":"60, đường C ộng Hòa, Quận Tân Bình"
    ,"Lat":10.801038
    ,"Long":106.659168
    ,"Polyline":"[106.66230011,10.80137253] ; [106.66173553,10.80082703] ; [106.65911865,10.80101967]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"260"
    ,"Station_Code":"QTB 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Nhà hát Quân Đội"
    ,"Station_Address":"138 (Kế nhà hát Quân đội), đường Cộng Hòa , Quận Tân Bình"
    ,"Lat":10.801238
    ,"Long":106.656754
    ,"Polyline":"[106.65911865,10.80101967] ; [106.65675354,10.80120182]"
    ,"Distance":"259"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"261"
    ,"Station_Code":"QTB 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngân hàng Quân đội"
    ,"Station_Address":"Tiệc cưới Hương Sen, đường Cộng Hòa,  Quận Tân Bình"
    ,"Lat":10.801412
    ,"Long":106.654817
    ,"Polyline":"[106.65675354,10.80120182] ; [106.65480804,10.80138016]"
    ,"Distance":"214"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"262"
    ,"Station_Code":"QTB 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Công ty Lô Hội"
    ,"Station_Address":"184, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.801728
    ,"Long":106.651127
    ,"Polyline":"[106.65480804,10.80138016] ; [106.65112305,10.80169392]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"263"
    ,"Station_Code":"QTB 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã tư Hoàng Hoa Thám"
    ,"Station_Address":"304, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802102
    ,"Long":106.646953
    ,"Polyline":"[106.65112305,10.80169392] ; [106.64694214,10.80202293]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"264"
    ,"Station_Code":"QTB 115"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã ba Bình Giã"
    ,"Station_Address":"390, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.802276
    ,"Long":106.644512
    ,"Polyline":"[106.64694214,10.80202293] ; [106.64434814,10.80225754]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"265"
    ,"Station_Code":"QTB 116"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Lê Văn Hu ân"
    ,"Station_Address":"496, đường Cộng Hòa,  Quận Tân Bình"
    ,"Lat":10.802571
    ,"Long":106.640967
    ,"Polyline":"[106.64434814,10.80225754] ; [106.64096832,10.80253983]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"4485"
    ,"Station_Code":"QTBBXCH"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"592, Cộng Hòa"
    ,"Station_Address":"592, đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.8040600032583
    ,"Long":106.63784712553
    ,"Polyline":"[106.64096832,10.80253983] ; [106.64096832,10.80253983] ; [106.64096832,10.80253983] ; [106.64003754,10.80259228] ; [106.63977814,10.80262375] ; [106.63952637,10.80266666] ; [106.63926697,10.80272961] ; [106.63903809,10.80281925] ; [106.63879395,10.80293465] ; [106.63860321,10.80306721] ; [106.63838959,10.80324554] ; [106.63822174,10.80342007] ; [106.63804626,10.80370998] ; [106.63784790,10.80405998] ; [106.63784790,10.80405998] ; [106.63784790,10.80405998]"
    ,"Distance":"409"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"266"
    ,"Station_Code":"QTB 117"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Thượng Uyển"
    ,"Station_Address":"660 (kế 592), đường Cộng Hòa, Quận Tân Bình"
    ,"Lat":10.806313
    ,"Long":106.636192
    ,"Polyline":"[106.63784790,10.80405998] ; [106.63679504,10.80554867] ; [106.63617706,10.80631256]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63617706,10.80631256] ; [106.63548279,10.80688190] ; [106.63509369,10.80729008] ; [106.63488007,10.80759811] ; [106.63467407,10.80803871]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63467407,10.80803871] ; [106.63349915,10.81169510]"
    ,"Distance":"427"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Tân Sơn"
    ,"Station_Address":"720, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63349915,10.81169510.06.63258362]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63258362,10.81463814] ; [106.63169098,10.81754112]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63169098,10.81754112] ; [106.63044739,10.82164383]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A, đường Trường Chinh , Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63044739,10.82164383] ; [106.63026428,10.82225227] ; [106.62996674,10.82285213] ; [106.62942505,10.82351589] ; [106.62872314,10.82418060] ; [106.62609863,10.82672977]"
    ,"Distance":"750"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"273"
    ,"Station_Code":"Q12 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"189/4, đường Trường Chinh , Quận 12"
    ,"Lat":10.828843
    ,"Long":106.624482
    ,"Polyline":"[106.62609863,10.82672977] ; [106.62532806,10.82746792] ; [106.62448120,10.82884312]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"274"
    ,"Station_Code":"Q12 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"258, đường Trường Chinh, Quận 12"
    ,"Lat":10.832547
    ,"Long":106.622116
    ,"Polyline":"[106.62448120,10.82884312] ; [106.62211609,10.83254719]"
    ,"Distance":"487"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"275"
    ,"Station_Code":"Q12 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Chùa Lạc Quang"
    ,"Station_Address":"408, đường Trường Chinh, Quận 12"
    ,"Lat":10.83514
    ,"Long":106.620464
    ,"Polyline":"[106.62211609,10.83254719] ; [106.62046051,10.83514023]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"277"
    ,"Station_Code":"Q12 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"640, đường Trường Chinh, Quận 12"
    ,"Lat":10.83819
    ,"Long":106.618495
    ,"Polyline":"[106.62046051,10.83514023] ; [106.61849213,10.83819008]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"276"
    ,"Station_Code":"Q12 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"774A, đường Trường Chinh , Quận 12"
    ,"Lat":10.841436
    ,"Long":106.616457
    ,"Polyline":"[106.61849213,10.83819008] ; [106.61645508,10.84143639]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc l ộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61645508,10.84143639] ; [106.61566162,10.84250546] ; [106.61565399,10.84274197] ; [106.61556244,10.84290028] ; [106.61544037,10.84296322] ; [106.61527252,10.84297943] ; [106.61402893,10.84497070]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"4"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61402893,10.84497070] ; [106.61250305,10.84729481] ; [106.61235809,10.84720516] ; [106.61327362,10.84582043] ; [106.61369324,10.84515953] ; [106.61405182,10.84459972] ; [106.61413574,10.84444904] ; [106.61367035,10.84412766] ; [106.61328125,10.84385395] ; [106.61337280,10.84373760]"
    ,"Distance":"820"
  }]