export const Route45 =[

  {
     "Route_Id":"45"
    ,"Station_Id":"2272"
    ,"Station_Code":"BX 40"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bãi xe buýt 19/5"
    ,"Station_Address":"BÃI XE BUÝT 19/5, đường Hương Lộ 60B , Huyện Hóc Môn"
    ,"Lat":10.893196
    ,"Long":106.583473
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2263"
    ,"Station_Code":"HHM 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 3 Lam Sơn"
    ,"Station_Address":"65/5C, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.891747
    ,"Long":106.581384
    ,"Polyline":"[106.58347321,10.89319611] ; [106.58293152,10.89384365] ; [106.58166504,10.89304352] ; [106.58090973,10.89256859] ; [106.58138275,10.89174747]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2328"
    ,"Station_Code":"HHM 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Bích Phương"
    ,"Station_Address":"64/4, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.886943
    ,"Long":106.584758
    ,"Polyline":"[106.58138275,10.89174747] ; [106.58475494,10.88694286]"
    ,"Distance":"650"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2329"
    ,"Station_Code":"HHM 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ngã 4 Hóc Môn"
    ,"Station_Address":"81(Số củ 21) , đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.884794
    ,"Long":106.5878
    ,"Polyline":"[106.58475494,10.88694286] ; [106.58583832,10.88536835] ; [106.58672333,10.88416672] ; [106.58695221,10.88374519] ; [106.58726501,10.88405132] ; [106.58779907,10.88491726]"
    ,"Distance":"591"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2330"
    ,"Station_Code":"HHM 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Nhà hàng  Thanh Trúc"
    ,"Station_Address":"10/6A, đường Lý Thường Kiệt , Huyện H óc Môn"
    ,"Lat":10.886938
    ,"Long":106.590691
    ,"Polyline":"[106.58779907,10.88491726] ; [106.58776093,10.88494015] ; [106.58834076,10.88566971] ; [106.58872986,10.88617039] ; [106.58889008,10.88630962] ; [106.58904266,10.88644028] ; [106.58937836,10.88668442] ; [106.59066772,10.88702011] ; [106.59068298,10.88698292]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2331"
    ,"Station_Code":"HHM 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngân hàng Nông Nghiệp"
    ,"Station_Address":"39/1, đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.887954
    ,"Long":106.593674
    ,"Polyline":"[106.59068298,10.88698292] ; [106.59365082,10.88799953]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"4165"
    ,"Station_Code":"HHM 199"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Phan Văn Hớn"
    ,"Station_Address":"20/7, đường Phan Văn Hớn, Huyện Hóc Môn"
    ,"Lat":10.844117
    ,"Long":106.594677
    ,"Polyline":"[106.59365082,10.88799953] ; [106.59469604,10.88833332] ; [106.59498596,10.88843918] ; [106.59510040,10.88843346] ; [106.59519196,10.88847637] ; [106.59563446,10.88838100] ; [106.59600067,10.88824368]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2332"
    ,"Station_Code":"HHM 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Chợ Hóc Môn"
    ,"Station_Address":"36 /6A, đường Quang Trung, Huyện Hóc Môn"
    ,"Lat":10.888083
    ,"Long":106.598915
    ,"Polyline":"[106.59600067,10.88824368] ; [106.59637451,10.88831806] ; [106.59749603,10.88828087] ; [106.59814453,10.88822842] ; [106.59891510,10.88808346]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2333"
    ,"Station_Code":"HHM 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công an huy ện Hóc Môn"
    ,"Station_Address":"1/18, đường Quang Trung, Huyện Hóc Môn"
    ,"Lat":10.887849
    ,"Long":106.601341
    ,"Polyline":"[106.59891510,10.88808346] ; [106.60008240,10.88798618] ; [106.60102081,10.88794899] ; [106.60134125,10.88784885]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2334"
    ,"Station_Code":"HHM 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Cây xăng"
    ,"Station_Address":"30/13, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.887491
    ,"Long":106.602648
    ,"Polyline":"[106.60134125,10.88784885] ; [106.60134125,10.88784885] ; [106.60154724,10.88785458] ; [106.60190582,10.88778591] ; [106.60239410,10.88761234] ; [106.60260010,10.88752270] ; [106.60282898,10.88737011] ; [106.60282898,10.88737011]"
    ,"Distance":"174"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2335"
    ,"Station_Code":"HHM 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Hoa Viên Trúc Lâm"
    ,"Station_Address":"30/11, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.884604
    ,"Long":106.60582
    ,"Polyline":"[106.60286713,10.88747025] ; [106.60331726,10.88729000] ; [106.60356140,10.88712978] ; [106.60578156,10.88492012] ; [106.60595703,10.88473988]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2336"
    ,"Station_Code":"HHM 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cống Đôi"
    ,"Station_Address":"307H, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.879626
    ,"Long":106.609253
    ,"Polyline":"[106.60595703,10.88473988] ; [106.60765076,10.88306999] ; [106.60794830,10.88251019] ; [106.60877228,10.88088036] ; [106.60936737,10.87969017]"
    ,"Distance":"719"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2338"
    ,"Station_Code":"HHM 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Đồng Quê"
    ,"Station_Address":"150A, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.872082
    ,"Long":106.613646
    ,"Polyline":"[106.60936737,10.87969017] ; [106.61065674,10.87714005]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2337"
    ,"Station_Code":"HHM 091"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cây kiểng  Bảy Châu"
    ,"Station_Address":"72, đường Tô K ý, Huyện Hóc Môn"
    ,"Lat":10.874545
    ,"Long":106.611809
    ,"Polyline":"[106.61065674,10.87714005] ; [106.61193848,10.87460995]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2339"
    ,"Station_Code":"HHM 095"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã 3 Bầu"
    ,"Station_Address":"6/5, đường Tô Ký, Huyện H óc Môn"
    ,"Lat":10.873873
    ,"Long":106.612465
    ,"Polyline":"[106.61193848,10.87460995] ; [106.61271667,10.87308025] ; [106.61293793,10.87277031]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2340"
    ,"Station_Code":"HHM 094"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Nghĩa trang liệt sỹ Trung Chánh"
    ,"Station_Address":"12/7, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.868199
    ,"Long":106.615443
    ,"Polyline":"[106.61293793,10.87277031] ; [106.61363983,10.87191963] ; [106.61492920,10.87030983] ; [106.61502075,10.87014008] ; [106.61512756,10.86972046] ; [106.61521912,10.86903000]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1635"
    ,"Station_Code":"QHMT250"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Cây xăng Minh Luân"
    ,"Station_Address":"Trường Nguyễn Hữu Cầu, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.86644458770752
    ,"Long":106.61473846435547
    ,"Polyline":"[106.61505890,10.86900520] ; [106.61521912,10.86903000] ; [106.61537933,10.86789989] ; [106.61544037,10.86736202] ; [106.61489105,10.86656094] ; [106.61473846,10.86644459]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1634"
    ,"Station_Code":"QHMT116"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trường Nguyễn Trãi"
    ,"Station_Address":"74/4, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.864206314086914
    ,"Long":106.61312103271484
    ,"Polyline":"[106.61473846,10.86644459] ; [106.61470032,10.86627674] ; [106.61376190,10.86499119] ; [106.61330414,10.86436939] ; [106.61312103,10.86420631]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1636"
    ,"Station_Code":"QHMT117"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngã tư Nước Đá"
    ,"Station_Address":"127/1, đường Nguy ễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.860050201416016
    ,"Long":106.61029815673828
    ,"Polyline":"[106.61319733,10.86415005] ; [106.61193085,10.86238003] ; [106.61058807,10.86038971] ; [106.61035156,10.86001968]"
    ,"Distance":"572"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1637"
    ,"Station_Code":"QHMT118"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường C Đ GTVT"
    ,"Station_Address":"150A/1, đường Nguy ễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.857827186584473
    ,"Long":106.60880279541016
    ,"Polyline":"[106.61035156,10.86001968] ; [106.60887146,10.85778046]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1638"
    ,"Station_Code":"QHMT119"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Trung  Chánh"
    ,"Station_Address":"155/4, đường Nguyễn Ánh Thủ, Huyện Hóc Môn"
    ,"Lat":10.85592269897461
    ,"Long":106.60757446289062
    ,"Polyline":"[106.60887146,10.85778046] ; [106.60777283,10.85614014] ; [106.60762024,10.85589981]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1393"
    ,"Station_Code":"HHM 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Ngã tư Nguyễn Ảnh Thủ"
    ,"Station_Address":"30 /10B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.854628
    ,"Long":106.607476
    ,"Polyline":"[106.60757446,10.85592270] ; [106.60739899,10.85562897] ; [106.60730743,10.85542870] ; [106.60720062,10.85530281] ; [106.60714722,10.85519218] ; [106.60747528,10.85462761]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1238"
    ,"Station_Code":"HHM 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cư xá B à Điểm"
    ,"Station_Address":"3A, đường Quốc l ộ 22, Huyện Hóc Môn"
    ,"Lat":10.850092
    ,"Long":106.610395
    ,"Polyline":"[106.60747528,10.85462761] ; [106.61039734,10.85009193]"
    ,"Distance":"597"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Qu ốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61047363,10.85015011] ; [106.61290741,10.84638023] ; [106.61396027,10.84473038]"
    ,"Distance":"740"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2342"
    ,"Station_Code":"Q12T255"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cầu vượt An Sương"
    ,"Station_Address":"17A-4/8A, đư ờng Quốc lộ 1A, Quận 12"
    ,"Lat":10.844568252563477
    ,"Long":106.61766052246094
    ,"Polyline":"[106.61396027,10.84473038] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61506653,10.84249973] ; [106.61517334,10.84239960] ; [106.61530304,10.84235001] ; [106.61544800,10.84235001] ; [106.61559296,10.84243965] ; [106.61566162,10.84257984] ; [106.61566162,10.84274006] ; [106.61625671,10.84329033] ; [106.61739349,10.84432983] ; [106.61760712,10.84459972]"
    ,"Distance":"704"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2343"
    ,"Station_Code":"Q12 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bến xe T ây Nam"
    ,"Station_Address":"2531(Bến xe Tây Nam), đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.845851
    ,"Long":106.619087
    ,"Polyline":"[106.61760712,10.84459972] ; [106.61768341,10.84469032] ; [106.61805725,10.84502983] ; [106.61904907,10.84589005]"
    ,"Distance":"226"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2341"
    ,"Station_Code":"Q12 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm đăng kiểm"
    ,"Station_Address":"Đối diện trạm đăng kiểm, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.847418
    ,"Long":106.621506
    ,"Polyline":"[106.61904907,10.84589005] ; [106.61949158,10.84626007] ; [106.62000275,10.84663963] ; [106.62055206,10.84698963] ; [106.62114716,10.84731007] ; [106.62148285,10.84747982]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2346"
    ,"Station_Code":"Q12 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Thái An"
    ,"Station_Address":"B336, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.848157
    ,"Long":106.623123
    ,"Polyline":"[106.62148285,10.84747982] ; [106.62309265,10.84821987]"
    ,"Distance":"209"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2344"
    ,"Station_Code":"Q12 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Đài phát  thanh Quán Tre"
    ,"Station_Address":"Đài pha ́t thanh quán tre, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.849082
    ,"Long":106.625069
    ,"Polyline":"[106.62309265,10.84821987] ; [106.62503815,10.84912968]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2091"
    ,"Station_Code":"Q12 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Cầu vượt  Quang Trung"
    ,"Station_Address":"B45, đường Quang  Trung, Quận 12"
    ,"Lat":10.848996
    ,"Long":106.632679
    ,"Polyline":"[106.62503815,10.84912968] ; [106.62677002,10.84994030] ; [106.62799835,10.85050011] ; [106.62806702,10.85046959] ; [106.62822723,10.85046959] ; [106.62870789,10.85070038] ; [106.62885284,10.85070992] ; [106.62904358,10.85068989] ; [106.63018036,10.85046005] ; [106.63104248,10.85019016] ; [106.63159943,10.84990025] ; [106.63178253,10.84982967] ; [106.63188934,10.84974957] ; [106.63273621,10.84914970]"
    ,"Distance":"936"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2092"
    ,"Station_Code":"Q12 060"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"113, đường Quang Trung, Quận 12"
    ,"Lat":10.848253
    ,"Long":106.634363
    ,"Polyline":"[106.63275146,10.84914970] ; [106.63414001,10.84813976]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2093"
    ,"Station_Code":"QGV 169"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"927, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.844981
    ,"Long":106.638985
    ,"Polyline":"[106.63414001,10.84813976] ; [106.63491821,10.84759045] ; [106.63530731,10.84733963] ; [106.63594055,10.84692955] ; [106.63668060,10.84640980] ; [106.63716888,10.84605026] ; [106.63760376,10.84582043] ; [106.63790894,10.84564972] ; [106.63902283,10.84504032]"
    ,"Distance":"652"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2094"
    ,"Station_Code":"QGV 170"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"869-871 (Kế A4-A5), đường Quang Trung , Quận Gò Vấp"
    ,"Lat":10.843801
    ,"Long":106.640671
    ,"Polyline":"[106.63898468,10.84498119] ; [106.63902283,10.84504032] ; [106.63976288,10.84450722] ; [106.64010620,10.84428024] ; [106.64070892,10.84385967] ; [106.64067078,10.84380054]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2095"
    ,"Station_Code":"QGV 171"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"819, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.842036
    ,"Long":106.643311
    ,"Polyline":"[106.64067078,10.84380054] ; [106.64070892,10.84385967] ; [106.64157867,10.84325314] ; [106.64239502,10.84269524] ; [106.64325714,10.84214973] ; [106.64334869,10.84208965] ; [106.64331055,10.84203625]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2098"
    ,"Station_Code":"QGV 172"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"751 (364), đường Quang Trung , Quận Gò Vấp"
    ,"Lat":10.839758
    ,"Long":106.646347
    ,"Polyline":"[106.64334869,10.84208965] ; [106.64398956,10.84165955] ; [106.64470673,10.84117985] ; [106.64505768,10.84092045] ; [106.64555359,10.84053040] ; [106.64636230,10.83985996] ; [106.64640045,10.83983040]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2096"
    ,"Station_Code":"QGV 173"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã ba Tân Sơn"
    ,"Station_Address":"Đối diện 972 (Công  ty ISUZU), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83902
    ,"Long":106.647728
    ,"Polyline":"[106.64634705,10.83975792] ; [106.64640045,10.83983040] ; [106.64674377,10.83953857] ; [106.64710999,10.83928013] ; [106.64730835,10.83918953] ; [106.64774323,10.83907986] ; [106.64772797,10.83901978]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2099"
    ,"Station_Code":"QGV 174"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Dệt may  Phương Đông"
    ,"Station_Address":"695 (đối di ện 97), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.83839
    ,"Long":106.650246
    ,"Polyline":"[106.64774323,10.83907986] ; [106.65026093,10.83845043]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2097"
    ,"Station_Code":"QGV 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Trường THPT  Nguyễn Công Trứ"
    ,"Station_Address":"Đối di ện 842, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.837576
    ,"Long":106.653412
    ,"Polyline":"[106.65026093,10.83845043] ; [106.65342712,10.83763981]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"4627"
    ,"Station_Code":"QGV 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"12B, Quang  Trung"
    ,"Station_Address":"Đối diện 746 (12B ), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836552
    ,"Long":106.657376
    ,"Polyline":"[106.65341187,10.83757591] ; [106.65737915,10.83655167]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"4628"
    ,"Station_Code":"QGV 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Công an  Quận Gò Vấp"
    ,"Station_Address":"Đối diện 628A  (9), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835561
    ,"Long":106.661367
    ,"Polyline":"[106.65737915,10.83655167] ; [106.66136932,10.83556080]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"926"
    ,"Station_Code":"QGV 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chùa Hu ỳnh Kim"
    ,"Station_Address":"621, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.834918
    ,"Long":106.663395
    ,"Polyline":"[106.66136932,10.83556080] ; [106.66232300,10.83536053] ; [106.66296387,10.83513927] ; [106.66339874,10.83491802]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1665"
    ,"Station_Code":"QGV 179"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"VKSND Quận Gò Vấp"
    ,"Station_Address":"523, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833828
    ,"Long":106.665283
    ,"Polyline":"[106.66339874,10.83491802] ; [106.66374207,10.83479691] ; [106.66416168,10.83460236] ; [106.66446686,10.83443356] ; [106.66477966,10.83422756] ; [106.66505432,10.83405972] ; [106.66528320,10.83382797]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"987"
    ,"Station_Code":"QGV 180"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Trường Quang Trung"
    ,"Station_Address":"387, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.830791
    ,"Long":106.669167
    ,"Polyline":"[106.66528320,10.83382797] ; [106.66916656,10.83079147]"
    ,"Distance":"543"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"984"
    ,"Station_Code":"QGV 181"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Nhà Thờ Xóm Thuốc"
    ,"Station_Address":"305, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.829139
    ,"Long":106.672058
    ,"Polyline":"[106.66916656,10.83079147] ; [106.66921234,10.83084011] ; [106.66976166,10.83041954] ; [106.67011261,10.83018017] ; [106.67066956,10.82985973] ; [106.67208099,10.82919025] ; [106.67205811,10.82913876]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"986"
    ,"Station_Code":"QGV 182"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Xóm thuốc"
    ,"Station_Address":"205, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.828095
    ,"Long":106.67485
    ,"Polyline":"[106.67211914,10.82917976] ; [106.67269897,10.82892990] ; [106.67395020,10.82847977] ; [106.67482758,10.82816982]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"988"
    ,"Station_Code":"QGV 183"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Công ty 32"
    ,"Station_Address":"67, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.827308
    ,"Long":106.677185
    ,"Polyline":"[106.67485046,10.82809544] ; [106.67487335,10.82814980] ; [106.67603302,10.82772064] ; [106.67720795,10.82736969] ; [106.67718506,10.82730770]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"991"
    ,"Station_Code":"QGV 184"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Đối diện siêu thị Văn Lang, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.82661
    ,"Long":106.679153
    ,"Polyline":"[106.67718506,10.82730770] ; [106.67720795,10.82736969] ; [106.67819214,10.82702065] ; [106.67917633,10.82668972] ; [106.67915344,10.82660961]"
    ,"Distance":"245"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2100"
    ,"Station_Code":"QGVT159"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Chi cục Thuế Quận Gò Vấp"
    ,"Station_Address":"159, đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.826214
    ,"Long":106.682159
    ,"Polyline":"[106.67915344,10.82660961] ; [106.67917633,10.82668972] ; [106.67942810,10.82660007] ; [106.67984772,10.82643032] ; [106.67987061,10.82639027] ; [106.67993164,10.82635021] ; [106.68000031,10.82633972] ; [106.68006134,10.82637024] ; [106.68009186,10.82639027] ; [106.68009949,10.82639980] ; [106.68036652,10.82633018] ; [106.68070221,10.82624531] ; [106.68135071,10.82619953] ; [106.68148041,10.82621002] ; [106.68199158,10.82631969] ; [106.68212128,10.82635021] ; [106.68215942,10.82621384]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2103"
    ,"Station_Code":"QGV 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Chùa Bà Thiên Hậu"
    ,"Station_Address":"87, đường Nguyễn Văn Nghi, Qu ận Gò Vấp"
    ,"Lat":10.825382
    ,"Long":106.684531
    ,"Polyline":"[106.68215942,10.82621384] ; [106.68212128,10.82635021] ; [106.68232727,10.82637978] ; [106.68256378,10.82633972] ; [106.68322754,10.82625008] ; [106.68338776,10.82620335] ; [106.68350983,10.82617760] ; [106.68376923,10.82606030] ; [106.68402863,10.82584572] ; [106.68441772,10.82558727] ; [106.68517303,10.82514954] ; [106.68520355,10.82513046] ; [106.68516541,10.82507610]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2101"
    ,"Station_Code":"QGVT161"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"5, đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.82215690612793
    ,"Long":106.68833923339844
    ,"Polyline":"[106.68520355,10.82513046] ; [106.68541718,10.82501984] ; [106.68562317,10.82487965] ; [106.68624115,10.82437038] ; [106.68653870,10.82415962] ; [106.68752289,10.82345963] ; [106.68795013,10.82306004] ; [106.68814087,10.82277966] ; [106.68840790,10.82219028]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2104"
    ,"Station_Code":"QGV 186"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Ngã Ba Nguyên Hồng"
    ,"Station_Address":"497, đường Lê Quang Định, Quận Gò Vấp"
    ,"Lat":10.817979
    ,"Long":106.689171
    ,"Polyline":"[106.68840790,10.82219028] ; [106.68856812,10.82184029] ; [106.68878937,10.82145977] ; [106.68892670,10.82116032] ; [106.68907928,10.82081985] ; [106.68917084,10.82069969] ; [106.68965912,10.82028961] ; [106.68991852,10.81993961] ; [106.68998718,10.81976032] ; [106.69001007,10.81964016] ; [106.68994904,10.81937981] ; [106.68972778,10.81888008] ; [106.68943787,10.81836987]"
    ,"Distance":"556"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2106"
    ,"Station_Code":"QBTH 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Chùa Già Lam"
    ,"Station_Address":"435, đường Lê Quang Định, Quận Bình Th ạnh"
    ,"Lat":10.814411
    ,"Long":106.689616
    ,"Polyline":"[106.68917084,10.81797886] ; [106.68891144,10.81723976] ; [106.68856049,10.81634998] ; [106.68859863,10.81601048] ; [106.68869019,10.81571960] ; [106.68891907,10.81536961] ; [106.68913269,10.81517982] ; [106.68921661,10.81507015] ; [106.68934631,10.81497002] ; [106.68948364,10.81486034] ; [106.68953705,10.81476974] ; [106.68965149,10.81439972] ; [106.68961334,10.81441116]"
    ,"Distance":"454"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2105"
    ,"Station_Code":"QBTH 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Ngã Tư Xóm Gà"
    ,"Station_Address":"337, đường Lê Quang Định,  Quận Bình Thạnh"
    ,"Lat":10.811967
    ,"Long":106.690502
    ,"Polyline":"[106.68965149,10.81439972] ; [106.68972015,10.81410027] ; [106.68979645,10.81346035] ; [106.68991089,10.81299973] ; [106.68998718,10.81278992] ; [106.69011688,10.81256962] ; [106.69052887,10.81196022]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2108"
    ,"Station_Code":"QBTH 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Chùa Hưng Tự Gia"
    ,"Station_Address":"235, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.809306
    ,"Long":106.693232
    ,"Polyline":"[106.69052887,10.81196022] ; [106.69075775,10.81161976] ; [106.69103241,10.81116962] ; [106.69120026,10.81103039] ; [106.69129944,10.81097984] ; [106.69143677,10.81095028] ; [106.69171143,10.81089020] ; [106.69193268,10.81085014] ; [106.69204712,10.81079960] ; [106.69219208,10.81062031] ; [106.69233704,10.81039047] ; [106.69262695,10.80986977] ; [106.69271088,10.80974007] ; [106.69277954,10.80967045] ; [106.69302368,10.80947971] ; [106.69328308,10.80932045]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1770"
    ,"Station_Code":"QBTH 087"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Cây Xăng 178"
    ,"Station_Address":"117-119, đường Lê Quang Định, Quận Bình  Thạnh"
    ,"Lat":10.806666
    ,"Long":106.696794
    ,"Polyline":"[106.69328308,10.80932045] ; [106.69396210,10.80887032] ; [106.69419098,10.80873013] ; [106.69465637,10.80850983] ; [106.69508362,10.80832005] ; [106.69529724,10.80819035] ; [106.69544220,10.80807972] ; [106.69664764,10.80685043] ; [106.69680786,10.80669022]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1771"
    ,"Station_Code":"QBTH 086"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Trường TH Nguyễn Đình Chiểu"
    ,"Station_Address":"1A, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.803278
    ,"Long":106.698366
    ,"Polyline":"[106.69679260,10.80666637] ; [106.69680786,10.80669022] ; [106.69706726,10.80626965] ; [106.69738007,10.80587959] ; [106.69776154,10.80541039] ; [106.69795227,10.80506039] ; [106.69808197,10.80467987] ; [106.69822693,10.80401039] ; [106.69836426,10.80327797]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"473C, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69836426,10.80327797] ; [106.69849396,10.80280876] ; [106.69856262,10.80256653] ; [106.69955444,10.80296135]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"449, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69955444,10.80296135] ; [106.70117950,10.80362511]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"375, đường Bạch Đằng, Quận B ình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70113373,10.80373001] ; [106.70149231,10.80385017] ; [106.70172882,10.80383968] ; [106.70278168,10.80356026] ; [106.70324707,10.80346012] ; [106.70365143,10.80342007] ; [106.70400238,10.80338955]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235, đường B ạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70398712,10.80329323] ; [106.70670319,10.80317020] ; [106.70671082,10.80307674]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70670319,10.80317020] ; [106.70815277,10.80307007] ; [106.70899200,10.80300045] ; [106.70997620,10.80294991] ; [106.71053314,10.80290031]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71053314,10.80290031] ; [106.71114349,10.80286026] ; [106.71138763,10.80284023] ; [106.71141815,10.80298042] ; [106.71143341,10.80377960] ; [106.71145630,10.80453014] ; [106.71147919,10.80471039]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"504, đường X ô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71166229,10.80680275] ; [106.71163177,10.80777264] ; [106.71178436,10.80830956] ; [106.71196747,10.80883121]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Siêu th ị Coop Mart"
    ,"Station_Address":"222/13A, đường  Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71198273,10.80906963] ; [106.71206665,10.80928040] ; [106.71215820,10.80955029] ; [106.71228790,10.81021976] ; [106.71240997,10.81079102]"
    ,"Distance":"225"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128, đường Quốc lộ 13, Quận Bình  Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71260834,10.81231976]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"0"
    ,"Station_Order":"65"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"Bến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":"[106.71260834,10.81231976] ; [106.71253967,10.81233025] ; [106.71305084,10.81651974] ; [106.71318054,10.81737041] ; [106.71308136,10.81737995] ; [106.71288300,10.81739044] ; [106.71269989,10.81735992] ; [106.71225739,10.81723976] ; [106.71196747,10.81715012] ; [106.71172333,10.81700039] ; [106.71130371,10.81665039] ; [106.71118927,10.81651974] ; [106.71092224,10.81604004] ; [106.71041870,10.81526470] ; [106.71013641,10.81468582] ; [106.70996094,10.81432152] ; [106.70970917,10.81385803] ; [106.70983124,10.81379986] ; [106.71016693,10.81389999] ; [106.71050262,10.81452751] ; [106.71077728,10.81510162] ; [106.71129608,10.81473255]"
    ,"Distance":"1431"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1403"
    ,"Station_Code":"BX44"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"B ến xe Miền Đông, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.814733
    ,"Long":106.711294
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71129608,10.81473255] ; [106.71076202,10.81501198] ; [106.71112061,10.81579208] ; [106.71086884,10.81620312] ; [106.71054077,10.81550694] ; [106.70989227,10.81416893] ; [106.70922089,10.81262493]"
    ,"Distance":"653"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183 , đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70925140,10.81260014] ; [106.70919037,10.81247044] ; [106.70913696,10.81227016] ; [106.70912933,10.81159019] ; [106.70913696,10.81058025] ; [106.70919037,10.80980968]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Đinh  Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70919037,10.80980968] ; [106.70926666,10.80805969] ; [106.70937347,10.80710983] ; [106.70938873,10.80690956]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70938873,10.80690956] ; [106.70948792,10.80566978] ; [106.70947266,10.80506039] ; [106.70944214,10.80442047]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.70939636,10.80442142] ; [106.70944214,10.80442047] ; [106.70932770,10.80307770] ; [106.70831299,10.80316162] ; [106.70803070,10.80317688]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường  Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70797729,10.80307961] ; [106.70393372,10.80338955]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Th ạnh"
    ,"Station_Address":"288 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70401764,10.80348301] ; [106.70373535,10.80351448] ; [106.70278168,10.80364132] ; [106.70172119,10.80392075] ; [106.70153046,10.80396271] ; [106.70114136,10.80384636] ; [106.70096588,10.80375671]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Bà Chi ểu"
    ,"Station_Address":"368, đường Bạch Đằng , Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70096588,10.80375671] ; [106.69937134,10.80312538]"
    ,"Distance":"188"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1648"
    ,"Station_Code":"QBTH 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Trường TH Nguyễn Đình Chiểu"
    ,"Station_Address":"22-24, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.803241
    ,"Long":106.698462
    ,"Polyline":"[106.69937134,10.80312538] ; [106.69856262,10.80278778] ; [106.69846344,10.80324078]"
    ,"Distance":"148"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1651"
    ,"Station_Code":"QBTH 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cây Xăng  178"
    ,"Station_Address":"164, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.80665
    ,"Long":106.696912
    ,"Polyline":"[106.69846344,10.80324078] ; [106.69802856,10.80484962] ; [106.69786072,10.80523014] ; [106.69776154,10.80541039] ; [106.69740295,10.80585003] ; [106.69716644,10.80613041] ; [106.69696045,10.80644989] ; [106.69691467,10.80665016]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2041"
    ,"Station_Code":"QBTH 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã Tư BÌnh Hòa"
    ,"Station_Address":"276, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.808594
    ,"Long":106.694552
    ,"Polyline":"[106.69691467,10.80665016] ; [106.69676971,10.80684471] ; [106.69544220,10.80807972] ; [106.69529724,10.80821991] ; [106.69508362,10.80832005] ; [106.69472504,10.80849934] ; [106.69454956,10.80859375]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2036"
    ,"Station_Code":"QBTH 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chùa Hưng Tự Gia"
    ,"Station_Address":"336, đường L ê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.809501
    ,"Long":106.693093
    ,"Polyline":"[106.69454956,10.80859375] ; [106.69417572,10.80880547] ; [106.69393921,10.80892086] ; [106.69360352,10.80912113] ; [106.69309235,10.80950069]"
    ,"Distance":"189"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2038"
    ,"Station_Code":"QBTH 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã Tư Xóm  Gà"
    ,"Station_Address":"424 , đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.812272
    ,"Long":106.690416
    ,"Polyline":"[106.69309235,10.80950069] ; [106.69290924,10.80964851] ; [106.69274902,10.80978489] ; [106.69252014,10.81005001] ; [106.69229889,10.81046009] ; [106.69212341,10.81070995] ; [106.69204712,10.81079960] ; [106.69196320,10.81085014] ; [106.69185638,10.81085968] ; [106.69129944,10.81097984] ; [106.69119263,10.81105042] ; [106.69103241,10.81116962] ; [106.69075775,10.81161976] ; [106.69050598,10.81211376] ; [106.69041443,10.81227207]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2043"
    ,"Station_Code":"QBTH 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chùa Gi à Lam"
    ,"Station_Address":"488, đường Lê Quang Định, Quận Bình Thạnh"
    ,"Lat":10.814274
    ,"Long":106.689767
    ,"Polyline":"[106.69041443,10.81227207] ; [106.69009399,10.81281471] ; [106.68989563,10.81356335] ; [106.68976593,10.81427383]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2047"
    ,"Station_Code":"QGV 185"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã Ba Nguyên Hồng"
    ,"Station_Address":"566, đường Lê Quang Định, Quận Gò Vấp"
    ,"Lat":10.817873
    ,"Long":106.689278
    ,"Polyline":"[106.68976593,10.81427383] ; [106.68966675,10.81465340] ; [106.68955994,10.81481171] ; [106.68934631,10.81504917] ; [106.68891144,10.81543922] ; [106.68875122,10.81570721] ; [106.68864441,10.81608677] ; [106.68863678,10.81634521] ; [106.68866730,10.81658745] ; [106.68927765,10.81787300]"
    ,"Distance":"457"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2046"
    ,"Station_Code":"QGV 152"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"28 , đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.821646
    ,"Long":106.688759
    ,"Polyline":"[106.68927765,10.81787300] ; [106.68968964,10.81876373] ; [106.68989563,10.81921673] ; [106.69006348,10.81969070] ; [106.68997192,10.81997585] ; [106.68965149,10.82039165] ; [106.68923187,10.82075024] ; [106.68910217,10.82097149] ; [106.68898010,10.82119846] ; [106.68875885,10.82164574]"
    ,"Distance":"485"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2040"
    ,"Station_Code":"QGV 153"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã Ba Nguy ễn Du"
    ,"Station_Address":"250 , đường Nguyễn Văn Nghi, Quận Gò Vấp"
    ,"Lat":10.825329
    ,"Long":106.684998
    ,"Polyline":"[106.68875885,10.82164574] ; [106.68849945,10.82220459] ; [106.68823242,10.82272625] ; [106.68808746,10.82301044] ; [106.68783569,10.82326317] ; [106.68735504,10.82366371] ; [106.68663025,10.82411194] ; [106.68618011,10.82468605] ; [106.68591309,10.82484436] ; [106.68563843,10.82501316] ; [106.68499756,10.82532883]"
    ,"Distance":"599"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2042"
    ,"Station_Code":"QGV 154"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chi cục  Thuế Quận Gò Vấp"
    ,"Station_Address":"308, đường Nguyễn Văn Nghi, Quận Gò V ấp"
    ,"Lat":10.826383
    ,"Long":106.682732
    ,"Polyline":"[106.68499756,10.82532883] ; [106.68392944,10.82604027] ; [106.68377686,10.82614040] ; [106.68329620,10.82628250] ; [106.68273163,10.82638264]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"921"
    ,"Station_Code":"QGV 155"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"Si êu thị Văn Lang, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.826804
    ,"Long":106.679354
    ,"Polyline":"[106.68273163,10.82638264] ; [106.68257141,10.82643032] ; [106.68230438,10.82644081] ; [106.68213654,10.82642460] ; [106.68199921,10.82639885] ; [106.68168640,10.82633018] ; [106.68145752,10.82627201] ; [106.68071747,10.82628822] ; [106.68036652,10.82637215] ; [106.68012238,10.82645035] ; [106.68013000,10.82647991] ; [106.68010712,10.82654953] ; [106.68006134,10.82660961] ; [106.67997742,10.82662964] ; [106.67990875,10.82660961] ; [106.67987823,10.82658005] ; [106.67986298,10.82656956] ; [106.67968750,10.82667732] ; [106.67954254,10.82672501] ; [106.67935944,10.82683086]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"920"
    ,"Station_Code":"QGV 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Công ty  32"
    ,"Station_Address":"138, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.827779
    ,"Long":106.676559
    ,"Polyline":"[106.67935944,10.82683086] ; [106.67906189,10.82690430] ; [106.67655945,10.82777882]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"922"
    ,"Station_Code":"QGV 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà Thờ  Xóm Thuốc"
    ,"Station_Address":"190, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.829186
    ,"Long":106.672606
    ,"Polyline":"[106.67655945,10.82777882] ; [106.67260742,10.82918644]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"923"
    ,"Station_Code":"QGV 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"UBND Quận Gò Vấp"
    ,"Station_Address":"328, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.831641
    ,"Long":106.668502
    ,"Polyline":"[106.67260742,10.82918644] ; [106.67206573,10.82940674] ; [106.67166901,10.82960701] ; [106.67024994,10.83033466] ; [106.66980743,10.83055592] ; [106.66883850,10.83127022] ; [106.66850281,10.83164120]"
    ,"Distance":"530"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"924"
    ,"Station_Code":"QGV 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"VKS nhân dân Quận Gò Vấp"
    ,"Station_Address":"402 - 404,  đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.833374
    ,"Long":106.666313
    ,"Polyline":"[106.66850281,10.83164120] ; [106.66769409,10.83221054] ; [106.66631317,10.83337402]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"4745"
    ,"Station_Code":"QGV 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chùa Huỳnh  Kim"
    ,"Station_Address":"548, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835234
    ,"Long":106.663315
    ,"Polyline":"[106.66631317,10.83337402] ; [106.66518402,10.83423328] ; [106.66426086,10.83473873] ; [106.66331482,10.83523369]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"925"
    ,"Station_Code":"QGV 161"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Siêu thị Bình Dân, Quang Trung"
    ,"Station_Address":"628A, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.835988
    ,"Long":106.660675
    ,"Polyline":"[106.66331482,10.83523369] ; [106.66067505,10.83598804]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2049"
    ,"Station_Code":"QGV 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chợ Thông  Tây"
    ,"Station_Address":"734, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.836836
    ,"Long":106.657355
    ,"Polyline":"[106.66067505,10.83598804] ; [106.66045380,10.83603477] ; [106.65762329,10.83674622] ; [106.65735626,10.83683586]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2044"
    ,"Station_Code":"QGV 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường THPT Nguyễn Công Trứ"
    ,"Station_Address":"872 (96H), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.838
    ,"Long":106.652741
    ,"Polyline":"[106.65735626,10.83683586] ; [106.65274048,10.83800030]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2045"
    ,"Station_Code":"QGV 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Dệt may  Phương Đông"
    ,"Station_Address":"930 (Kho 97), đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.838654
    ,"Long":106.650091
    ,"Polyline":"[106.65274048,10.83800030] ; [106.65250397,10.83802700] ; [106.65009308,10.83865356]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2051"
    ,"Station_Code":"QGV 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Làng SOS"
    ,"Station_Address":"1010, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.839881
    ,"Long":106.646621
    ,"Polyline":"[106.65009308,10.83865356] ; [106.64952087,10.83875942] ; [106.64781952,10.83923817] ; [106.64730072,10.83935452] ; [106.64698792,10.83952808] ; [106.64672089,10.83975983] ; [106.64662170,10.83988094]"
    ,"Distance":"411"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2048"
    ,"Station_Code":"QGV 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Công ty Đồng Tâm"
    ,"Station_Address":"1134, đường Quang  Trung, Quận Gò Vấp"
    ,"Lat":10.842279
    ,"Long":106.643348
    ,"Polyline":"[106.64662170,10.83988094] ; [106.64559174,10.84068775] ; [106.64519501,10.84100914] ; [106.64426422,10.84164143] ; [106.64356232,10.84208393] ; [106.64334869,10.84227943]"
    ,"Distance":"447"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2053"
    ,"Station_Code":"QGV 167"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã Tư Cầu cống"
    ,"Station_Address":"1246, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.843743
    ,"Long":106.641186
    ,"Polyline":"[106.64334869,10.84227943] ; [106.64118958,10.84374332]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2050"
    ,"Station_Code":"QGV 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"1324, đường Quang Trung, Quận Gò Vấp"
    ,"Lat":10.845532
    ,"Long":106.638435
    ,"Polyline":"[106.64118958,10.84374332] ; [106.64093781,10.84389114] ; [106.64015198,10.84440231] ; [106.63938904,10.84497070] ; [106.63890839,10.84526634] ; [106.63843536,10.84553242]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2056"
    ,"Station_Code":"Q12 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Cầu"
    ,"Station_Address":"154, đường Quang Trung, Quận 12"
    ,"Lat":10.847842
    ,"Long":106.634422
    ,"Polyline":"[106.63843536,10.84553242] ; [106.63816833,10.84567738] ; [106.63787842,10.84578037] ; [106.63750458,10.84605598] ; [106.63694763,10.84645653] ; [106.63619995,10.84697342] ; [106.63533020,10.84752083] ; [106.63499451,10.84778404] ; [106.63464355,10.84801579] ; [106.63455200,10.84806347]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2052"
    ,"Station_Code":"Q12 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cầu vượt  Quang Trung"
    ,"Station_Address":"170, đường  Quang Trung, Quận 12"
    ,"Lat":10.849784
    ,"Long":106.63221
    ,"Polyline":"[106.63455200,10.84806347] ; [106.63220978,10.84978390]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2057"
    ,"Station_Code":"Q12 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Công viên phần mềm Quang Trung"
    ,"Station_Address":"Công viên phần mềm Quang Trung, đường Tô Ký, Quận 12"
    ,"Lat":10.852995
    ,"Long":106.626434
    ,"Polyline":"[106.63220978,10.84978390] ; [106.63188171,10.85000229] ; [106.63162994,10.85010815] ; [106.63112640,10.85037041] ; [106.63063812,10.85056019] ; [106.62993622,10.85074043] ; [106.62892151,10.85093975] ; [106.62773895,10.85116005] ; [106.62741089,10.85126019] ; [106.62712097,10.85146999] ; [106.62695313,10.85167027] ; [106.62670135,10.85210037] ; [106.62658691,10.85245991] ; [106.62631226,10.85297966] ; [106.62625885,10.85307026] ; [106.62631226,10.85309982]"
    ,"Distance":"804"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2089"
    ,"Station_Code":"Q12 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Cửa hàng Vinh Phú"
    ,"Station_Address":"79, đường Tô Ký, Quận 12"
    ,"Lat":10.854931
    ,"Long":106.624161
    ,"Polyline":"[106.62631226,10.85309982] ; [106.62617493,10.85338497] ; [106.62593842,10.85372162] ; [106.62557983,10.85415363] ; [106.62528992,10.85441208] ; [106.62501526,10.85466003] ; [106.62472534,10.85489655] ; [106.62442780,10.85509682] ; [106.62400055,10.85532856] ; [106.62357330,10.85554504] ; [106.62348175,10.85553932] ; [106.62345123,10.85546017] ; [106.62346649,10.85536003] ; [106.62361145,10.85529041] ; [106.62419128,10.85498047] ; [106.62416077,10.85493088]"
    ,"Distance":"540"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2090"
    ,"Station_Code":"Q12 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Công viên PM Quang Trung"
    ,"Station_Address":"389, đường T ô Ký, Quận 12"
    ,"Lat":10.852871
    ,"Long":106.626099
    ,"Polyline":"[106.62416077,10.85493088] ; [106.62419128,10.85498047] ; [106.62441254,10.85484982] ; [106.62481689,10.85455036] ; [106.62532806,10.85408020] ; [106.62579346,10.85352993] ; [106.62599182,10.85316372] ; [106.62609863,10.85287094]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2254"
    ,"Station_Code":"Q12 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Chung cư Thái An"
    ,"Station_Address":"Chung cư Thái An, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.84907
    ,"Long":106.624348
    ,"Polyline":"[106.62615967,10.85289955] ; [106.62642670,10.85239029] ; [106.62651825,10.85210037] ; [106.62664795,10.85182953] ; [106.62689209,10.85136986] ; [106.62692261,10.85124969] ; [106.62690735,10.85105038] ; [106.62686920,10.85097980] ; [106.62677002,10.85091972] ; [106.62626648,10.85070992] ; [106.62610626,10.85060978] ; [106.62600708,10.85052013] ; [106.62595367,10.85039997] ; [106.62566376,10.84992981] ; [106.62525177,10.84939003] ; [106.62438202,10.84899044]"
    ,"Distance":"610"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2250"
    ,"Station_Code":"Q12 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Trạm đăng kiểm"
    ,"Station_Address":"Trạm  đăng kiểm, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.8475
    ,"Long":106.621059
    ,"Polyline":"[106.62435913,10.84903145] ; [106.62107849,10.84749699]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2251"
    ,"Station_Code":"Q12 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"bãi xe T ây Nam"
    ,"Station_Address":"Đối diện bến xe Tây Nam, đường Quốc lộ  1A, Quận 12"
    ,"Lat":10.845935
    ,"Long":106.618758
    ,"Polyline":"[106.62107849,10.84749699] ; [106.62068176,10.84727287] ; [106.61995697,10.84687328] ; [106.61934662,10.84643078] ; [106.61878204,10.84592152]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2252"
    ,"Station_Code":"Q12 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Cầu vượt An Sương"
    ,"Station_Address":"Xưởng Z735, đường Quốc lộ 1A, Quận 12"
    ,"Lat":10.843623
    ,"Long":106.616081
    ,"Polyline":"[106.61882019,10.84587955] ; [106.61757660,10.84479046] ; [106.61721802,10.84457970] ; [106.61611938,10.84358978]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Qu ốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61608124,10.84362316] ; [106.61601257,10.84356976] ; [106.61578369,10.84343815] ; [106.61551666,10.84331131] ; [106.61538696,10.84331131] ; [106.61524963,10.84333801] ; [106.61508179,10.84345341] ; [106.61479187,10.84372234] ; [106.61421204,10.84464455] ; [106.61401367,10.84493923]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1116"
    ,"Station_Code":"Q12 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trạm cây xăng"
    ,"Station_Address":"128, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.845487
    ,"Long":106.61371
    ,"Polyline":"[106.61401367,10.84493923] ; [106.61367035,10.84547901]"
    ,"Distance":"71"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1117"
    ,"Station_Code":"Q12 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"7C, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.845845
    ,"Long":106.613474
    ,"Polyline":"[106.61367035,10.84547901] ; [106.61344147,10.84581375]"
    ,"Distance":"45"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1151"
    ,"Station_Code":"Q12 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Cây xăng Quân Đội"
    ,"Station_Address":"2, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.850034
    ,"Long":106.610845
    ,"Polyline":"[106.61338806,10.84578991] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61106110,10.84941959] ; [106.61073303,10.84994030]"
    ,"Distance":"559"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1689"
    ,"Station_Code":"Q12 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Cảnh sát giao thông số 5"
    ,"Station_Address":"Kế cảnh sát giao thông số 5, đường Qu ốc lộ 22, Quận 12"
    ,"Lat":10.851009
    ,"Long":106.610186
    ,"Polyline":"[106.61078644,10.84997559] ; [106.61013031,10.85097694]"
    ,"Distance":"133"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1152"
    ,"Station_Code":"Q12 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Trung tâm văn hóa Quận 12"
    ,"Station_Address":"Trung tâm v ăn hóa Quận 12, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.854892
    ,"Long":106.607718
    ,"Polyline":"[106.61013031,10.85097694] ; [106.60794067,10.85446453] ; [106.60765076,10.85483360]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1690"
    ,"Station_Code":"Q12 156"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Trung t âm Văn hóa quận 12"
    ,"Station_Address":"Hông Trung tâm văn hóa Quận 12, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.855634
    ,"Long":106.607578
    ,"Polyline":"[106.60765076,10.85483360] ; [106.60731506,10.85542393] ; [106.60752869,10.85575962] ; [106.60753632,10.85575771]"
    ,"Distance":"120"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1691"
    ,"Station_Code":"Q12 157"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Trường Cao đẳng Giao thông vận tải"
    ,"Station_Address":"8, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.857552
    ,"Long":106.608839
    ,"Polyline":"[106.60752869,10.85575962] ; [106.60851288,10.85727024] ; [106.60875702,10.85762024]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1692"
    ,"Station_Code":"Q12 158"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Nhà thờ Trung Chánh"
    ,"Station_Address":"349, đường Nguy ễn Ảnh Thủ, Quận 12"
    ,"Lat":10.859981
    ,"Long":106.610422
    ,"Polyline":"[106.60875702,10.85762024] ; [106.60997772,10.85945988] ; [106.61035919,10.86001968]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1693"
    ,"Station_Code":"Q12 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Chợ Vạn Hạnh"
    ,"Station_Address":"7, đường Nguyễn  Ảnh Thủ, Quận 12"
    ,"Lat":10.862873
    ,"Long":106.612412
    ,"Polyline":"[106.61035919,10.86001968] ; [106.61176300,10.86213017] ; [106.61231995,10.86293030]"
    ,"Distance":"391"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1694"
    ,"Station_Code":"Q12 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Nhà sách Nguyễn Hữu Cầu"
    ,"Station_Address":"1C, đường Nguyễn Ảnh Thủ, Quận 12"
    ,"Lat":10.865112
    ,"Long":106.614016
    ,"Polyline":"[106.61231995,10.86293030] ; [106.61300659,10.86390018] ; [106.61364746,10.86474037] ; [106.61396790,10.86513996]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2256"
    ,"Station_Code":"Q12T097"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Ngã 3 B ầu"
    ,"Station_Address":"Ct dệt Sài Gòn, đường Tô Ký, Quận 12"
    ,"Lat":10.867839813232422
    ,"Long":106.61540222167969
    ,"Polyline":"[106.61392975,10.86516953] ; [106.61441040,10.86579990] ; [106.61551666,10.86736965] ; [106.61540222,10.86783981]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2258"
    ,"Station_Code":"HHM 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trạm bưu điện"
    ,"Station_Address":"40/9D, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.876423
    ,"Long":106.610856
    ,"Polyline":"[106.61540222,10.86783981] ; [106.61528015,10.86859989] ; [106.61508942,10.86993980] ; [106.61502075,10.87014008] ; [106.61492920,10.87030983] ; [106.61374664,10.87178040]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2253"
    ,"Station_Code":"HHM 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Thép Đăng Khoa"
    ,"Station_Address":"515, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.872714
    ,"Long":106.612921
    ,"Polyline":"[106.61381531,10.87182617] ; [106.61299133,10.87299824] ; [106.61224365,10.87417030]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2260"
    ,"Station_Code":"HHM 093"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Nghĩa trang  liệt sỹ Trung Chánh"
    ,"Station_Address":"Ngh ĩa trang liệt sỹ Trung Chánh, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.86831
    ,"Long":106.615169
    ,"Polyline":"[106.61224365,10.87417030] ; [106.61094666,10.87666798]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2262"
    ,"Station_Code":"HHM 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Cống Đôi"
    ,"Station_Address":"Đối diện 370L, đường Tô Ký, Huyện Hóc Môn"
    ,"Lat":10.880301
    ,"Long":106.609192
    ,"Polyline":"[106.61094666,10.87666798] ; [106.61009216,10.87853050] ; [106.60919189,10.88030148]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2255"
    ,"Station_Code":"HHM 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Trạm cây xăng"
    ,"Station_Address":"14/1, đường T ô Ký, Huyện Hóc Môn"
    ,"Lat":10.88639
    ,"Long":106.604462
    ,"Polyline":"[106.60909271,10.88024998] ; [106.60774994,10.88288975] ; [106.60765076,10.88306999] ; [106.60749054,10.88323975] ; [106.60679626,10.88393021] ; [106.60655212,10.88416958]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2264"
    ,"Station_Code":"HHM 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Cây Bàng"
    ,"Station_Address":"1/1, đường Tô Ký, Huyện H óc Môn"
    ,"Lat":10.876423
    ,"Long":106.611178
    ,"Polyline":"[106.60662842,10.88424587] ; [106.60641479,10.88439846] ; [106.60437775,10.88641071] ; [106.60360718,10.88712692] ; [106.60331726,10.88729000] ; [106.60314941,10.88735962] ; [106.60316467,10.88739872]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2266"
    ,"Station_Code":"HHM 083"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Ngã 3 Chùa"
    ,"Station_Address":"4/36, đường Quang Trung, Huy ện Hóc Môn"
    ,"Lat":10.887975
    ,"Long":106.601688
    ,"Polyline":"[106.60316467,10.88739872] ; [106.60239410,10.88773346] ; [106.60168457,10.88797474]"
    ,"Distance":"174"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2257"
    ,"Station_Code":"HHM 084"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Chợ Hóc Môn"
    ,"Station_Address":"1/18, đường Quang  Trung, Huyện Hóc Môn"
    ,"Lat":10.888287
    ,"Long":106.598663
    ,"Polyline":"[106.60168457,10.88797474] ; [106.60150909,10.88802242] ; [106.60121918,10.88805962] ; [106.59989929,10.88807583] ; [106.59942627,10.88809967] ; [106.59866333,10.88823986] ; [106.59866333,10.88828659]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2259"
    ,"Station_Code":"HHM 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Ngân hàng Nông Nghiệp"
    ,"Station_Address":"13/3 (số củ 12), đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.888333
    ,"Long":106.594368
    ,"Polyline":"[106.59866333,10.88828659] ; [106.59866333,10.88823986] ; [106.59803772,10.88836575] ; [106.59732819,10.88837051] ; [106.59574127,10.88848686] ; [106.59514618,10.88855457] ; [106.59509277,10.88861847] ; [106.59501648,10.88863945] ; [106.59491730,10.88860035] ; [106.59488678,10.88852978] ; [106.59491730,10.88848019] ; [106.59481049,10.88846016] ; [106.59436798,10.88833332]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2268"
    ,"Station_Code":"HHM 165"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Thanh Trúc"
    ,"Station_Address":"78, đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.88715
    ,"Long":106.590866
    ,"Polyline":"[106.59436798,10.88833332] ; [106.59403992,10.88815975] ; [106.59086609,10.88714981]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2261"
    ,"Station_Code":"HHM 166"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Ngã tư Hóc Môn"
    ,"Station_Address":"51/8, đường Lý Thường Kiệt , Huyện Hóc Môn"
    ,"Lat":10.884733
    ,"Long":106.58757
    ,"Polyline":"[106.59086609,10.88714981] ; [106.59036255,10.88698006] ; [106.58935547,10.88662148] ; [106.58904266,10.88644028] ; [106.58872986,10.88617039] ; [106.58757019,10.88473320]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"1303"
    ,"Station_Code":"HHM 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"65"
    ,"Station_Name":"Ngã tư Hóc Môn"
    ,"Station_Address":"206, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.884705
    ,"Long":106.586678
    ,"Polyline":"[106.58757019,10.88473320] ; [106.58743286,10.88451958] ; [106.58712006,10.88402939] ; [106.58692169,10.88429832] ; [106.58670807,10.88459873] ; [106.58667755,10.88470459]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2270"
    ,"Station_Code":"HHM 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"66"
    ,"Station_Name":"Bích Phương"
    ,"Station_Address":"58/2, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.886817
    ,"Long":106.58522
    ,"Polyline":"[106.58667755,10.88470459] ; [106.58649445,10.88495731] ; [106.58534241,10.88661098] ; [106.58522034,10.88681698]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"45"
    ,"Station_Id":"2272"
    ,"Station_Code":"BX 40"
    ,"Station_Direction":"1"
    ,"Station_Order":"67"
    ,"Station_Name":"Bãi xe buýt 19/5"
    ,"Station_Address":"BÃI XE BUÝT 19 /5, đường Hương Lộ 60B, Huyện Hóc Môn"
    ,"Lat":10.893196
    ,"Long":106.583473
    ,"Polyline":"[106.58522034,10.88681698] ; [106.58309174,10.88997173] ; [106.58119965,10.89260578] ; [106.58270264,10.89372253] ; [106.58347321,10.89319611]"
    ,"Distance":"1088"
  }]