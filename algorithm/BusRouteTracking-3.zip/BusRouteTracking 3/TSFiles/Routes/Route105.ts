export const Route105 =[

  {
     "Route_Id":"105"
    ,"Station_Id":"3486"
    ,"Station_Code":"BX52"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu công nghiệp Tân Bình"
    ,"Station_Address":"ĐẦU BẾN KCN TÂN BÌNH, đư ờng Đường CN1, Quận Tân Phú"
    ,"Lat":10.806971549987793
    ,"Long":106.6078872680664
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3156"
    ,"Station_Code":"QTP 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trạm Đ ường CN 13"
    ,"Station_Address":"473, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.809837
    ,"Long":106.613106
    ,"Polyline":"[106.60788727,10.80696964] ; [106.60801697,10.80671978] ; [106.60838318,10.80714035] ; [106.60901642,10.80786991] ; [106.60936737,10.80830956] ; [106.61003876,10.80908012] ; [106.61134338,10.81064034] ; [106.61148071,10.81085968] ; [106.61213684,10.81054974] ; [106.61260223,10.81031990] ; [106.61319733,10.81005001]"
    ,"Distance":"836"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3155"
    ,"Station_Code":"QTP 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm Kênh 19/5"
    ,"Station_Address":"443, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.808721
    ,"Long":106.615913
    ,"Polyline":"[106.61319733,10.81005001] ; [106.61486816,10.80928040] ; [106.61598206,10.80895996]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2924"
    ,"Station_Code":"QTP 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Tây Thạnh"
    ,"Station_Address":"363, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.807646
    ,"Long":106.61982
    ,"Polyline":"[106.61598206,10.80895996] ; [106.61824036,10.80832005] ; [106.61923981,10.80803967] ; [106.61988068,10.80788040]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1974"
    ,"Station_Code":"QTP 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm Bờ Bao Tân Thắng"
    ,"Station_Address":"271, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.80731
    ,"Long":106.622368
    ,"Polyline":"[106.61988068,10.80788040] ; [106.62261963,10.80727005]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1975"
    ,"Station_Code":"QTP 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"Đối diện 220, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806767
    ,"Long":106.624886
    ,"Polyline":"[106.62236786,10.80731010.06.62261963] ; [10.80727005,106.62435150] ; [10.80688953,106.62488556]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2654"
    ,"Station_Code":"QTP 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Cao Đẳng Công Nghệ Thực Phẩm"
    ,"Station_Address":"117, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.80593
    ,"Long":106.628693
    ,"Polyline":"[106.62488556,10.80676746] ; [106.62509918,10.80673027] ; [106.62558746,10.80661011] ; [106.62658691,10.80640984] ; [106.62870026,10.80595970] ; [106.62869263,10.80593014]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2925"
    ,"Station_Code":"QTP 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"15, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.804359
    ,"Long":106.631981
    ,"Polyline":"[106.62870026,10.80595970] ; [106.63025665,10.80560017] ; [106.63056183,10.80552006] ; [106.63101959,10.80533028] ; [106.63136292,10.80506039] ; [106.63172913,10.80467987] ; [106.63200378,10.80436993]"
    ,"Distance":"422"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2657"
    ,"Station_Code":"QTP 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm café BonJour"
    ,"Station_Address":"128-130, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.803346
    ,"Long":106.631577
    ,"Polyline":"[106.63200378,10.80436993] ; [106.63218689,10.80412960] ; [106.63271332,10.80348969] ; [106.63189697,10.80335045] ; [106.63159180,10.80329990]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2656"
    ,"Station_Code":"QTP 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Đường Số 27"
    ,"Station_Address":"216, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.802817
    ,"Long":106.628487
    ,"Polyline":"[106.63159180,10.80329990] ; [106.62943268,10.80294037] ; [106.62850952,10.80274963]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2659"
    ,"Station_Code":"QTP 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trạm cây xăng Sài Gòn Petro"
    ,"Station_Address":"302, đường Tân Kỳ Tân Quý , Quận Tân Phú"
    ,"Lat":10.802044
    ,"Long":106.625923
    ,"Polyline":"[106.62850952,10.80274963] ; [106.62777710,10.80261993] ; [106.62731934,10.80251980] ; [106.62690735,10.80237961] ; [106.62595367,10.80198956]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2658"
    ,"Station_Code":"QTP 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Showroom otô"
    ,"Station_Address":"51/13, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.801045
    ,"Long":106.62336
    ,"Polyline":"[106.62595367,10.80198956] ; [106.62496948,10.80158043] ; [106.62377167,10.80111980] ; [106.62338257,10.80099010]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2660"
    ,"Station_Code":"QTP 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm Nh à Thờ Họ Tộc Nguyễn"
    ,"Station_Address":"378, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799963
    ,"Long":106.620499
    ,"Polyline":"[106.62338257,10.80099010.06.62236023] ; [10.80058002,106.62120056] ; [10.80014038,106.62052917]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2004"
    ,"Station_Code":"QTP 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Tân Quý"
    ,"Station_Address":"Kế 410, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798983
    ,"Long":106.618134
    ,"Polyline":"[106.62052917,10.79988956] ; [106.61817932,10.79899025]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2007"
    ,"Station_Code":"QTP 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường Tiểu Học Tân Quý"
    ,"Station_Address":"3/1B, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798385
    ,"Long":106.616493
    ,"Polyline":"[106.61814117,10.79897022] ; [106.61656952,10.79839993]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2009"
    ,"Station_Code":"QTP 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trạm Bình Long"
    ,"Station_Address":"520-522, đường Tân Kỳ Tân Quý, Quận T ân Phú"
    ,"Lat":10.797263
    ,"Long":106.614571
    ,"Polyline":"[106.61656952,10.79839993] ; [106.61621857,10.79821968] ; [106.61566925,10.79790020] ; [106.61459351,10.79726028]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3567"
    ,"Station_Code":"QTP 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Dương Văn Dương"
    ,"Station_Address":"225, đường Gò Dầu, Quận T ân Phú"
    ,"Lat":10.795776
    ,"Long":106.617661
    ,"Polyline":"[106.61459351,10.79726028] ; [106.61370850,10.79673862] ; [106.61401367,10.79601097] ; [106.61439514,10.79512596] ; [106.61495972,10.79534149] ; [106.61547089,10.79549503] ; [106.61602020,10.79571056] ; [106.61630249,10.79583740] ; [106.61660004,10.79597950] ; [106.61696625,10.79604816] ; [106.61766815,10.79582977]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3568"
    ,"Station_Code":"QTP 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Lê Liễu"
    ,"Station_Address":"180, đường G ò Dầu, Quận Tân Phú"
    ,"Lat":10.795753
    ,"Long":106.619202
    ,"Polyline":"[106.61766815,10.79582977] ; [106.61795044,10.79580021] ; [106.61907196,10.79582977] ; [106.61920166,10.79582977]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2665"
    ,"Station_Code":"QTP 096"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trạm Gò Dầu"
    ,"Station_Address":"88, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.795079
    ,"Long":106.620316
    ,"Polyline":"[106.61920166,10.79582977] ; [106.62001038,10.79584980] ; [106.62027740,10.79563046] ; [106.62033844,10.79508018]"
    ,"Distance":"188"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2662"
    ,"Station_Code":"QTP 097"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Tiệm c ửa sắt"
    ,"Station_Address":"156, đường Tân Qu ý, Quận Tân Phú"
    ,"Lat":10.792974
    ,"Long":106.620468
    ,"Polyline":"[106.62033844,10.79508018] ; [106.62055969,10.79304028]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2664"
    ,"Station_Code":"QTP 098"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Trạm Y tế phường Tân Quý"
    ,"Station_Address":"200, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.791017
    ,"Long":106.620735
    ,"Polyline":"[106.62055969,10.79298019] ; [106.62075806,10.79102039]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2553"
    ,"Station_Code":"QTP 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trạm Chợ Tân Hương"
    ,"Station_Address":"217-219, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.790046
    ,"Long":106.621666
    ,"Polyline":"[106.62075806,10.79102039] ; [106.62079620,10.79057026] ; [106.62082672,10.79018021] ; [106.62104034,10.79014015] ; [106.62153625,10.79008007] ; [106.62165833,10.79006958]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3571"
    ,"Station_Code":"QTP 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm Phạm Văn Xảo"
    ,"Station_Address":"451, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.788065
    ,"Long":106.623726
    ,"Polyline":"[106.62165833,10.79006958] ; [106.62225342,10.78999996] ; [106.62316895,10.78989029] ; [106.62307739,10.78948021] ; [106.62290955,10.78896999] ; [106.62277985,10.78855991] ; [106.62390137,10.78818989] ; [106.62384796,10.78802967]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3569"
    ,"Station_Code":"QTP 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Vườn Lài"
    ,"Station_Address":"345, đường Vườn Lài, Quận  Tân Phú"
    ,"Lat":10.787748
    ,"Long":106.626221
    ,"Polyline":"[106.62384796,10.78802967] ; [106.62390137,10.78818989] ; [106.62500763,10.78802013] ; [106.62622833,10.78781033]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3572"
    ,"Station_Code":"QTP 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Minh Tâm"
    ,"Station_Address":"221-223, đường Vườn Lài, Qu ận Tân Phú"
    ,"Lat":10.788038
    ,"Long":106.62928
    ,"Polyline":"[106.62622833,10.78781033] ; [106.62716675,10.78769016] ; [106.62757874,10.78765011] ; [106.62772369,10.78767014] ; [106.62805176,10.78779030] ; [106.62872314,10.78800011] ; [106.62925720,10.78814030]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3570"
    ,"Station_Code":"QTP 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trạm Nguyễn Văn Tố"
    ,"Station_Address":"125-127, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.787796
    ,"Long":106.632668
    ,"Polyline":"[106.62925720,10.78814030] ; [106.62979126,10.78814983] ; [106.63040924,10.78812027] ; [106.63136292,10.78800011] ; [106.63266754,10.78783989]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3573"
    ,"Station_Code":"QTP 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm Lũy Bán Bích"
    ,"Station_Address":"5, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.786632
    ,"Long":106.635857
    ,"Polyline":"[106.63266754,10.78783989] ; [106.63349152,10.78773022] ; [106.63378906,10.78765011] ; [106.63468933,10.78724003] ; [106.63533783,10.78693008] ; [106.63588715,10.78670025]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3574"
    ,"Station_Code":"QTP 189"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Siêu th ị Coopmart"
    ,"Station_Address":"254 (Coop mart), đường Lũy Bán Bích, Qu ận Tân Phú"
    ,"Lat":10.78475
    ,"Long":106.636421
    ,"Polyline":"[106.63588715,10.78670025] ; [106.63612366,10.78662968] ; [106.63674927,10.78652000] ; [106.63667297,10.78596020] ; [106.63648224,10.78474045]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3575"
    ,"Station_Code":"QTP 190"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm Thoại Ngọc Hầu"
    ,"Station_Address":"721, đường Lũy Bán Bích, Quận Tân Ph ú"
    ,"Lat":10.781077
    ,"Long":106.635857
    ,"Polyline":"[106.63648224,10.78474045] ; [106.63593292,10.78106976]"
    ,"Distance":"412"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3576"
    ,"Station_Code":"QTP 191"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trạm Cây Xăng Bình An"
    ,"Station_Address":"611, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.778568
    ,"Long":106.635117
    ,"Polyline":"[106.63593292,10.78106976] ; [106.63581085,10.78044987] ; [106.63555908,10.77958965] ; [106.63524628,10.77875996] ; [106.63516998,10.77855015]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3577"
    ,"Station_Code":"QTPT220"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trạm Thạch Lam"
    ,"Station_Address":"531, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.776239395141602
    ,"Long":106.6336898803711
    ,"Polyline":"[106.63516998,10.77855015] ; [106.63487244,10.77789021] ; [106.63468933,10.77756023] ; [106.63436890,10.77709007] ; [106.63413239,10.77670002] ; [106.63377380,10.77618980]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3578"
    ,"Station_Code":"QTP 193"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm Bùi Thế Mỹ"
    ,"Station_Address":"425, đường L ũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.773767
    ,"Long":106.632378
    ,"Polyline":"[106.63377380,10.77618980] ; [106.63308716,10.77515984] ; [106.63287354,10.77474976] ; [106.63269806,10.77439022] ; [106.63244629,10.77373981]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3579"
    ,"Station_Code":"QTP 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Cây Keo"
    ,"Station_Address":"295-297, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.770796
    ,"Long":106.63179
    ,"Polyline":"[106.63244629,10.77373981] ; [106.63220978,10.77299023] ; [106.63210297,10.77237988] ; [106.63195038,10.77141953] ; [106.63185883,10.77079010]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1570"
    ,"Station_Code":"QTP 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"69, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769694
    ,"Long":106.633057
    ,"Polyline":"[106.63185883,10.77079010.06.63179779] ; [10.77029037,106.63313293]"
    ,"Distance":"207"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1567"
    ,"Station_Code":"QTP 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Cây Xăng Hòa Bình"
    ,"Station_Address":"176/26, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769394
    ,"Long":106.63533
    ,"Polyline":"[106.63313293,10.76990032] ; [106.63390350,10.76963043] ; [106.63421631,10.76949978] ; [106.63432312,10.76947021] ; [106.63439941,10.76947975] ; [106.63446045,10.76947975] ; [106.63500977,10.76953030] ; [106.63530731,10.76955986]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1571"
    ,"Station_Code":"Q11 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Thuỷ Tạ"
    ,"Station_Address":"đd 90 (nhà hàng Thủy Tạ Đầm Sen), đường  Hòa Bình, Quận 11"
    ,"Lat":10.768719
    ,"Long":106.637909
    ,"Polyline":"[106.63530731,10.76955986] ; [106.63571167,10.76959038] ; [106.63597870,10.76955986] ; [106.63630676,10.76949024] ; [106.63687134,10.76930046] ; [106.63793182,10.76887035] ; [106.63796234,10.76885033]"
    ,"Distance":"304"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1569"
    ,"Station_Code":"Q11 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"7B (Bến xe buýt Đầm Sen), đường Hòa Bình, Quận 11"
    ,"Lat":10.767916
    ,"Long":106.639511
    ,"Polyline":"[106.63796234,10.76885033] ; [106.63893890,10.76850033] ; [106.63918304,10.76838970] ; [106.63963318,10.76807976]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1043"
    ,"Station_Code":"Q11 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"3 (79), đường  Hòa Bình, Quận 11"
    ,"Lat":10.76698
    ,"Long":106.641571
    ,"Polyline":"[106.63963318,10.76807976] ; [106.64053345,10.76756001] ; [106.64096832,10.76729012] ; [106.64115143,10.76718998] ; [106.64140320,10.76710033] ; [106.64158630,10.76704025]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1044"
    ,"Station_Code":"Q11 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Tòa án nhân dân Q11"
    ,"Station_Address":"85, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.766342
    ,"Long":106.643349
    ,"Polyline":"[106.64158630,10.76704025] ; [106.64209747,10.76690006] ; [106.64222717,10.76686001] ; [106.64227295,10.76692009] ; [106.64238739,10.76694965] ; [106.64248657,10.76690006] ; [106.64251709,10.76681995] ; [106.64250946,10.76673031] ; [106.64337921,10.76642036]"
    ,"Distance":"227"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1045"
    ,"Station_Code":"Q11 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Ông Ích Khiêm"
    ,"Station_Address":"43, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.765737
    ,"Long":106.645157
    ,"Polyline":"[106.64337921,10.76642036] ; [106.64517975,10.76581001]"
    ,"Distance":"208"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3580"
    ,"Station_Code":"Q11 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Chim  Xanh"
    ,"Station_Address":"133E, đường Bình Thới, Qu ận 11"
    ,"Lat":10.766184
    ,"Long":106.647903
    ,"Polyline":"[106.64517975,10.76581001] ; [106.64584351,10.76558018] ; [106.64633942,10.76539993] ; [106.64646149,10.76531982] ; [106.64713287,10.76574039] ; [106.64788055,10.76622963]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3581"
    ,"Station_Code":"Q11 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"UBND P11"
    ,"Station_Address":"63A  (41-43), đường Bình Thới, Quận 11"
    ,"Lat":10.767647
    ,"Long":106.650139
    ,"Polyline":"[106.64788055,10.76622963] ; [106.64862823,10.76671028] ; [106.64972687,10.76747036] ; [106.65006256,10.76768017]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2833"
    ,"Station_Code":"Q11 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Đường  Nguyễn Thị Nhỏ"
    ,"Station_Address":"Đối Diện 47, đường Nguyễn Thị Nhỏ, Qu ận 11"
    ,"Lat":10.770221
    ,"Long":106.652672
    ,"Polyline":"[106.65013885,10.76764679] ; [106.65041351,10.76789188] ; [106.65188599,10.76889324] ; [106.65228271,10.76875591] ; [106.65244293,10.76880360] ; [106.65252686,10.76890373] ; [106.65251923,10.76919842] ; [106.65256500,10.76969433] ; [106.65267181,10.77022076]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2836"
    ,"Station_Code":"Q11 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Coopmark Phú Thọ"
    ,"Station_Address":"Đối Diện 64, đường Lữ Gia, Quận 11"
    ,"Lat":10.771025
    ,"Long":106.653313
    ,"Polyline":"[106.65267181,10.77022076] ; [106.65273285,10.77089024] ; [106.65277100,10.77119064] ; [106.65294647,10.77116013] ; [106.65332031,10.77108955] ; [106.65331268,10.77102470]"
    ,"Distance":"177"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2838"
    ,"Station_Code":"Q11 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nhà thi đấu Phú Thọ"
    ,"Station_Address":"Đối Diện 10B, đường Lữ Gia, Quận 11"
    ,"Lat":10.770303
    ,"Long":106.657303
    ,"Polyline":"[106.65332031,10.77108955] ; [106.65447235,10.77091026] ; [106.65519714,10.77081966] ; [106.65583038,10.77071953] ; [106.65733337,10.77050018]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"900"
    ,"Station_Code":"Q10 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"BV Tr ưng Vương"
    ,"Station_Address":"531, đường Tô Hi ến Thành, Quận 10"
    ,"Lat":10.770922
    ,"Long":106.658913
    ,"Polyline":"[106.65730286,10.77030277] ; [106.65760040,10.77046871] ; [106.65815735,10.77038956] ; [106.65834045,10.77048016] ; [106.65885925,10.77095890] ; [106.65891266,10.77092171]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"898"
    ,"Station_Code":"Q10 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Đại Học Bách Khoa (cổng sau )"
    ,"Station_Address":"523, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.773046
    ,"Long":106.661057
    ,"Polyline":"[106.65885925,10.77095985] ; [106.66065216,10.77260971] ; [106.66101074,10.77307987]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"902"
    ,"Station_Code":"Q10 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Ngân h àng quân đội"
    ,"Station_Address":"405, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775549
    ,"Long":106.663017
    ,"Polyline":"[106.66101074,10.77307987] ; [106.66143036,10.77359009] ; [106.66175842,10.77402973] ; [106.66233826,10.77476025] ; [106.66294098,10.77560043]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2835"
    ,"Station_Code":"Q10 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Quán Hoàng Ty"
    ,"Station_Address":"161, đường Thành Thái, Quận 10"
    ,"Lat":10.775075
    ,"Long":106.66407
    ,"Polyline":"[106.66294098,10.77560043] ; [106.66349030,10.77635956] ; [106.66355896,10.77641010.06.66384125] ; [10.77583027,106.66413116]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2837"
    ,"Station_Code":"Q10 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"BV 115"
    ,"Station_Address":"69, đường Thành Thái, Quận 10"
    ,"Lat":10.773051
    ,"Long":106.664833
    ,"Polyline":"[106.66413116,10.77509975] ; [106.66445923,10.77418995] ; [106.66478729,10.77340984] ; [106.66490173,10.77307034]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2840"
    ,"Station_Code":"Q10 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Nhà th ờ Đồng Tiến"
    ,"Station_Address":"Đối diện 52, đường Thành Thái, Quận 10"
    ,"Lat":10.770474
    ,"Long":106.665863
    ,"Polyline":"[106.66490173,10.77307034] ; [106.66536713,10.77180958] ; [106.66591644,10.77050018]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1397"
    ,"Station_Code":"Q10 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bệnh viện nhi đồng 1"
    ,"Station_Address":"359, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767765
    ,"Long":106.67038
    ,"Polyline":"[106.66586304,10.77047443] ; [106.66591644,10.77050018] ; [106.66635132,10.76937962] ; [106.66712189,10.76770973] ; [106.66784668,10.76799202] ; [106.66903687,10.76793003] ; [106.66938019,10.76778126]"
    ,"Distance":"601"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1398"
    ,"Station_Code":"Q10 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Chợ P10, Q10"
    ,"Station_Address":"183, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767623
    ,"Long":106.673357
    ,"Polyline":"[106.66938019,10.76778126] ; [106.67034912,10.76788616] ; [106.67153931,10.76782036] ; [106.67336273,10.76772022] ; [106.67335510,10.76766014]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1404"
    ,"Station_Code":"Q10 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Hồ Thị Kỳ"
    ,"Station_Address":"93 (27B), đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767207
    ,"Long":106.67554
    ,"Polyline":"[106.67336273,10.76772022] ; [106.67415619,10.76768017] ; [106.67417145,10.76764965] ; [106.67417908,10.76760006] ; [106.67423248,10.76751995] ; [106.67429352,10.76747036] ; [106.67434692,10.76745033] ; [106.67447662,10.76747036] ; [106.67456055,10.76753044] ; [106.67459106,10.76756954] ; [106.67460632,10.76758957] ; [106.67460632,10.76760960] ; [106.67636871,10.76708984] ; [106.67707062,10.76686954]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1402"
    ,"Station_Code":"Q10 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Nhà Khách Chính Phủ"
    ,"Station_Address":"Đ ối diện 180 (1B), đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.766522
    ,"Long":106.677799
    ,"Polyline":"[106.67707062,10.76686954] ; [106.67859650,10.76640034]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1406"
    ,"Station_Code":"Q10 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Ngã 6  Cộng Hòa"
    ,"Station_Address":"Đối diện 30-32 , đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.76571
    ,"Long":106.680449
    ,"Polyline":"[106.67859650,10.76640034] ; [106.68031311,10.76587009]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"287"
    ,"Station_Code":"Q1 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Phạm Viết Chánh"
    ,"Station_Address":"Đối diện 492, đường Nguyễn Thị Minh Khai , Quận 1"
    ,"Lat":10.766214
    ,"Long":106.682533
    ,"Polyline":"[106.68026733,10.76574707] ; [106.68031311,10.76587009] ; [106.68127441,10.76559925] ; [106.68135834,10.76530457] ; [106.68153381,10.76517773] ; [106.68169403,10.76518345] ; [106.68177795,10.76523590] ; [106.68187714,10.76535130] ; [106.68184662,10.76554108] ; [106.68202972,10.76572037] ; [106.68229675,10.76607990] ; [106.68245697,10.76624012] ; [106.68247986,10.76626015] ; [106.68253326,10.76621437]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"290"
    ,"Station_Code":"Q1 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Bệnh viện Tù Dũ"
    ,"Station_Address":"Đối diện 446, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.768709
    ,"Long":106.685024
    ,"Polyline":"[106.68247986,10.76626015] ; [106.68479156,10.76875019]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"289"
    ,"Station_Code":"Q1 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"99, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.77185
    ,"Long":106.687943
    ,"Polyline":"[106.68479156,10.76875019] ; [106.68753815,10.77167034]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1396"
    ,"Station_Code":"Q1 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"85, đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.772392
    ,"Long":106.691371
    ,"Polyline":"[106.68753815,10.77167034] ; [106.68811035,10.77227020] ; [106.68943787,10.77363014] ; [106.69139862,10.77256012]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1401"
    ,"Station_Code":"Q1 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"26  - 32, đường Nguyễn Thị Nghĩa, Quận 1"
    ,"Lat":10.770854
    ,"Long":106.693588
    ,"Polyline":"[106.69136810,10.77239227] ; [106.69188690,10.77225494] ; [106.69284821,10.77172279] ; [106.69310760,10.77155399] ; [106.69305420,10.77136421] ; [106.69316101,10.77121162] ; [106.69342041,10.77121735] ; [106.69358826,10.77085400]"
    ,"Distance":"328"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69365692,10.77089024] ; [106.69467926,10.76920986] ; [106.69412994,10.76898003]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"TĐH xe bu ýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt S ài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.69412994,10.76898003] ; [106.69238281,10.76828003] ; [106.69052124,10.76753998] ; [106.68988800,10.76844978] ; [106.68920898,10.76819992] ; [106.68904877,10.76807022]"
    ,"Distance":"650"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe bu ýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đường Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.69029999,10.76851273]"
    ,"Distance":"138.305440937207"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69207001,10.76928806] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"84"
    ,"Station_Code":"Q1 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Nguyễn  Thị Nghĩa"
    ,"Station_Address":"Đối diện số 26, đường Nguyễn Thị Nghĩa, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.693779
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69406891,10.77003670] ; [106.69418335,10.77019501] ; [106.69377899,10.77097988]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1297"
    ,"Station_Code":"Q1 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"Đối diện số 89, đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.773046
    ,"Long":106.690813
    ,"Polyline":"[106.69377899,10.77097988] ; [106.69358063,10.77122211] ; [106.69348907,10.77130127] ; [106.69343567,10.77145386] ; [106.69333649,10.77154922] ; [106.69303131,10.77175426] ; [106.69229126,10.77213955] ; [106.69079590,10.77299595] ; [106.69081116,10.77304554]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3478"
    ,"Station_Code":"Q3 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Võ Văn Tần"
    ,"Station_Address":"40 - 42, đường Cách Mạng Tháng Tám, Quận 3"
    ,"Lat":10.774068
    ,"Long":106.688946
    ,"Polyline":"[106.69081116,10.77304554] ; [106.69015503,10.77327728] ; [106.68937683,10.77367783] ; [106.68894958,10.77406788]"
    ,"Distance":"237"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1882"
    ,"Station_Code":"Q3 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Cách mạng Tháng Tám"
    ,"Station_Address":"Đối diện 193, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.77465
    ,"Long":106.686394
    ,"Polyline":"[106.68894958,10.77406788] ; [106.68838501,10.77422619] ; [106.68772125,10.77464294] ; [106.68706512,10.77498531] ; [106.68684387,10.77504826] ; [106.68639374,10.77464962] ; [106.68639374,10.77464962]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1889"
    ,"Station_Code":"Q3 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Chợ Vườn Chuối"
    ,"Station_Address":"448 - 450, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.772213
    ,"Long":106.684086
    ,"Polyline":"[106.68639374,10.77464962] ; [106.68639374,10.77464962] ; [106.68408966,10.77221298]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1884"
    ,"Station_Code":"Q3 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cao thắng"
    ,"Station_Address":"596  - 598, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.769731
    ,"Long":106.681672
    ,"Polyline":"[106.68408966,10.77221298] ; [106.68374634,10.77185345] ; [106.68215179,10.77012634] ; [106.68167114,10.76973057]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1890"
    ,"Station_Code":"Q3 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ Bàn  Cờ"
    ,"Station_Address":"678 - 680, đường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.768289
    ,"Long":106.680359
    ,"Polyline":"[106.68167114,10.76973057] ; [106.68122101,10.76917744] ; [106.68035889,10.76828861] ; [106.68035889,10.76828861]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1885"
    ,"Station_Code":"Q3 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Lý Thái Tổ"
    ,"Station_Address":"766 - 768, đ ường Nguyễn Đình Chiểu, Quận 3"
    ,"Lat":10.76709
    ,"Long":106.67926
    ,"Polyline":"[106.68035889,10.76828861] ; [106.68035889,10.76828861] ; [106.67983246,10.76767063] ; [106.67926025,10.76708984] ; [106.67926025,10.76708984]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1413"
    ,"Station_Code":"Q3 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nguyễn Đình Chiểu"
    ,"Station_Address":"170, đường Lý Thái Tổ, Quận 3"
    ,"Lat":10.76668
    ,"Long":106.678099
    ,"Polyline":"[106.67926025,10.76708984] ; [106.67926025,10.76708984] ; [106.67895508,10.76674271] ; [106.67874146,10.76643181] ; [106.67829132,10.76652908] ; [106.67810059,10.76667976]"
    ,"Distance":"170"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1416"
    ,"Station_Code":"Q3 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Hồ Thị Kỷ"
    ,"Station_Address":"306, đường Lý Thái Tổ, Qu ận 3"
    ,"Lat":10.767423
    ,"Long":106.675664
    ,"Polyline":"[106.67810059,10.76667976] ; [106.67725372,10.76684284] ; [106.67582703,10.76730824] ; [106.67566681,10.76742268]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1411"
    ,"Station_Code":"Q10 029"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Chợ Phường 10, Quận 10"
    ,"Station_Address":"430, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767865
    ,"Long":106.673051
    ,"Polyline":"[106.67566681,10.76742268] ; [106.67507172,10.76754951] ; [106.67473602,10.76767540] ; [106.67465210,10.76780701] ; [106.67446899,10.76792908] ; [106.67428589,10.76789188] ; [106.67409515,10.76771832] ; [106.67378998,10.76774979] ; [106.67313385,10.76779652] ; [106.67313385,10.76779747]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1412"
    ,"Station_Code":"Q10 030"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bện viện Nhi Đồng 1"
    ,"Station_Address":"Bệnh viện Nhi đồng 1, đường Lý Thái T ổ, Quận 10"
    ,"Lat":10.768029
    ,"Long":106.669739
    ,"Polyline":"[106.67313385,10.76779747] ; [106.67313385,10.76779652] ; [106.67228699,10.76783848] ; [106.67144012,10.76788139] ; [106.67056274,10.76792908] ; [106.66973877,10.76802921] ; [106.66973877,10.76802921]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3301"
    ,"Station_Code":"Q10 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Nhà thờ Đồng Tiến"
    ,"Station_Address":"52, đường Thành Thái, Quận 10"
    ,"Lat":10.769878
    ,"Long":106.666237
    ,"Polyline":"[106.66973877,10.76802921] ; [106.66973877,10.76802921] ; [106.66973877,10.76802921] ; [106.66883850,10.76799679] ; [106.66814423,10.76801872] ; [106.66801453,10.76810741] ; [106.66770172,10.76808643] ; [106.66734314,10.76794434] ; [106.66708374,10.76800251] ; [106.66657257,10.76892471] ; [106.66635895,10.76939392] ; [106.66623688,10.76987839] ; [106.66623688,10.76987839] ; [106.66623688,10.76987839]"
    ,"Distance":"527"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3302"
    ,"Station_Code":"Q10 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"BV 115"
    ,"Station_Address":"520A , đường Thành Thái, Quận 10"
    ,"Lat":10.772676
    ,"Long":106.665108
    ,"Polyline":"[106.66623688,10.76987839] ; [106.66623688,10.76987839] ; [106.66564941,10.77127552] ; [106.66510773,10.77267647] ; [106.66510773,10.77267647]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3303"
    ,"Station_Code":"Q10 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Quán Hoàng Ty"
    ,"Station_Address":"166 (182), đường Thành Thái, Quận 10"
    ,"Lat":10.775486
    ,"Long":106.664032
    ,"Polyline":"[106.66510773,10.77267647] ; [106.66403198,10.77548599]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1007"
    ,"Station_Code":"Q10 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ngân hàng quân đội"
    ,"Station_Address":"136 , đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775531
    ,"Long":106.662819
    ,"Polyline":"[106.66403198,10.77548599] ; [106.66403198,10.77548599] ; [106.66403198,10.77548599] ; [106.66378784,10.77602291] ; [106.66362000,10.77645016] ; [106.66281891,10.77553082] ; [106.66281891,10.77553082] ; [106.66281891,10.77553082]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1013"
    ,"Station_Code":"Q10 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đại Học B ách Khoa (cổng sau)"
    ,"Station_Address":"350  ( cũ 142), đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.773322
    ,"Long":106.661125
    ,"Polyline":"[106.66281891,10.77553082] ; [106.66112518,10.77332211]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1008"
    ,"Station_Code":"Q10 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"BV Tr ưng Vương"
    ,"Station_Address":"142 kios 37-38 , đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.771244
    ,"Long":106.659096
    ,"Polyline":"[106.66112518,10.77332211] ; [106.65909576,10.77124405]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2855"
    ,"Station_Code":"Q11 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà thi  đấu Phú Thọ"
    ,"Station_Address":"14, đường Lữ Gia, Quận 11"
    ,"Lat":10.770645
    ,"Long":106.656738
    ,"Polyline":"[106.65909576,10.77124405] ; [106.65909576,10.77124405] ; [106.65869904,10.77083778] ; [106.65826416,10.77045822] ; [106.65755463,10.77048969] ; [106.65673828,10.77064514] ; [106.65673828,10.77064514]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2852"
    ,"Station_Code":"Q11 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Coopmark  Phú Thọ"
    ,"Station_Address":"70A, đường Lữ Gia , Quận 11"
    ,"Lat":10.771143
    ,"Long":106.653236
    ,"Polyline":"[106.65673828,10.77064514] ; [106.65323639,10.77114296]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3480"
    ,"Station_Code":"Q11 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"UBND Phường 11"
    ,"Station_Address":"96A, đường Bình Thới, Quận 11"
    ,"Lat":10.767902
    ,"Long":106.650314
    ,"Polyline":"[106.65323639,10.77114296] ; [106.65323639,10.77114296] ; [106.65284729,10.77122211] ; [106.65267944,10.77029514] ; [106.65248108,10.76938820] ; [106.65238953,10.76917744] ; [106.65217590,10.76915169] ; [106.65187073,10.76917267] ; [106.65184021,10.76904106.06.65187073] ; [10.76888752,106.65145874] ; [10.76860809,106.65031433] ; [10.76790237,106.65031433]"
    ,"Distance":"569"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3479"
    ,"Station_Code":"Q11 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Chim Xanh"
    ,"Station_Address":"220, đường Bình Thới, Quận 11"
    ,"Lat":10.765965
    ,"Long":106.647392
    ,"Polyline":"[106.65031433,10.76790237] ; [106.65031433,10.76790237] ; [106.64886475,10.76693249] ; [106.64739227,10.76596546] ; [106.64739227,10.76596546]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1020"
    ,"Station_Code":"Q11 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Tòa án nhân dân Q11"
    ,"Station_Address":"150, đường Ông Ích Khiêm, Quận 11"
    ,"Lat":10.76659
    ,"Long":106.643082
    ,"Polyline":"[106.64739227,10.76596546] ; [106.64739227,10.76596546] ; [106.64655304,10.76539421] ; [106.64485931,10.76595211] ; [106.64308167,10.76659012] ; [106.64308167,10.76659012]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1029"
    ,"Station_Code":"Q11 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"40A, đường Hòa Bình, Quận 11"
    ,"Lat":10.767302
    ,"Long":106.641181
    ,"Polyline":"[106.64308167,10.76659012] ; [106.64308167,10.76659012] ; [106.64275360,10.76666355] ; [106.64252472,10.76677418] ; [106.64252472,10.76686382] ; [106.64244080,10.76695347] ; [106.64231110,10.76698494] ; [106.64216614,10.76690674] ; [106.64177704,10.76703262] ; [106.64118195,10.76730156]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1616"
    ,"Station_Code":"Q11 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Trường Hòa Bình"
    ,"Station_Address":"72, đường Hòa Bình, Quận 11"
    ,"Lat":10.768496
    ,"Long":106.639137
    ,"Polyline":"[106.64118195,10.76730156] ; [106.64053345,10.76756477] ; [106.63979340,10.76801300] ; [106.63913727,10.76849556] ; [106.63913727,10.76849556]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1604"
    ,"Station_Code":"QTP 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đầm Sen"
    ,"Station_Address":"45 (Đối diện công viên nước Đầm Sen), đường Hòa Bình , Quận Tân Phú"
    ,"Lat":10.769367
    ,"Long":106.63707
    ,"Polyline":"[106.63913727,10.76849556] ; [106.63913727,10.76849556] ; [106.63863373,10.76860332] ; [106.63778687,10.76895618] ; [106.63738251,10.76910400] ; [106.63706970,10.76936722] ; [106.63706970,10.76936722]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1617"
    ,"Station_Code":"QTP 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Huệ Quang"
    ,"Station_Address":"116, đường Hòa Bình, Quận Tân Phú"
    ,"Lat":10.769747
    ,"Long":106.635246
    ,"Polyline":"[106.63706970,10.76936722] ; [106.63706970,10.76936722] ; [106.63663483,10.76935196] ; [106.63597107,10.76957798] ; [106.63524628,10.76974678] ; [106.63524628,10.76974678]"
    ,"Distance":"206"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4315"
    ,"Station_Code":"QTPT232"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"264, Lũy Bán Bích"
    ,"Station_Address":"264, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.7706848586522
    ,"Long":106.631915803614
    ,"Polyline":"[106.63524628,10.76974678] ; [106.63467407,10.76947308] ; [106.63314819,10.76982021] ; [106.63186646,10.77032661] ; [106.63191223,10.77068520]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4316"
    ,"Station_Code":"QTPT233"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"332, Lũy Bán Bích"
    ,"Station_Address":"314, đường Lũy Bán Bích, Quận  Tân Phú"
    ,"Lat":10.7736781543893
    ,"Long":106.632484431926
    ,"Polyline":"[106.63191223,10.77068520] ; [106.63191223,10.77068520] ; [106.63208008,10.77232933] ; [106.63248444,10.77367783] ; [106.63248444,10.77367783]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4317"
    ,"Station_Code":"QTP 204"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Thạch Lam"
    ,"Station_Address":"394, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.77606
    ,"Long":106.633788
    ,"Polyline":"[106.63248444,10.77367783] ; [106.63248444,10.77367783] ; [106.63285065,10.77486897] ; [106.63332367,10.77556515] ; [106.63378906,10.77606010.06.63378906]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4318"
    ,"Station_Code":"QTP 205"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Cây xăng Bình An"
    ,"Station_Address":"464, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.778395
    ,"Long":106.635204
    ,"Polyline":"[106.63378906,10.77606010.06.63378906] ; [10.77606010.06.63449097,10.77719879] ; [106.63520050,10.77839470] ; [106.63520050,10.77839470]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4319"
    ,"Station_Code":"QTPT236"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Công viên Ủy ban Quận Tân Phú"
    ,"Station_Address":"Kế 556, đường Lũy  Bán Bích, Quận Tân Phú"
    ,"Lat":10.780972
    ,"Long":106.635987
    ,"Polyline":"[106.63520050,10.77839470] ; [106.63520050,10.77839470] ; [106.63558960,10.77968311] ; [106.63598633,10.78097153] ; [106.63598633,10.78097153]"
    ,"Distance":"300"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4320"
    ,"Station_Code":"QTP 207"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Siêu thị Coopmart"
    ,"Station_Address":"Đối diện 564, đường Lũy Bán Bích, Quận Tân Phú"
    ,"Lat":10.784639
    ,"Long":106.636545
    ,"Polyline":"[106.63598633,10.78097153] ; [106.63598633,10.78097153] ; [106.63616180,10.78283215] ; [106.63654327,10.78463936] ; [106.63654327,10.78463936]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4277"
    ,"Station_Code":"QTP 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"14-16, Vườn Lài"
    ,"Station_Address":"14-16, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.78686
    ,"Long":106.635607
    ,"Polyline":"[106.63654327,10.78463936] ; [106.63670349,10.78624153] ; [106.63676453,10.78646755] ; [106.63645172,10.78648853] ; [106.63598633,10.78666782] ; [106.63560486,10.78686047]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4278"
    ,"Station_Code":"QTP 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"100, Vườn Lài"
    ,"Station_Address":"100, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.787851
    ,"Long":106.632779
    ,"Polyline":"[106.63560486,10.78686047] ; [106.63491821,10.78712082] ; [106.63418579,10.78748512] ; [106.63355255,10.78784847] ; [106.63311005,10.78789043] ; [106.63278198,10.78785133]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4279"
    ,"Station_Code":"QTP 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"180, V ườn Lài"
    ,"Station_Address":"180, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.788212
    ,"Long":106.629373
    ,"Polyline":"[106.63278198,10.78785133] ; [106.63172150,10.78803253] ; [106.63054657,10.78812790] ; [106.62937164,10.78821182]"
    ,"Distance":"376"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"4280"
    ,"Station_Code":"QTP 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"240, Vườn Lài"
    ,"Station_Address":"240, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.787835
    ,"Long":106.626393
    ,"Polyline":"[106.62937164,10.78821182] ; [106.62892151,10.78811169] ; [106.62841034,10.78794289] ; [106.62805176,10.78781700] ; [106.62760925,10.78768539] ; [106.62699890,10.78775978] ; [106.62639618,10.78783512]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3481"
    ,"Station_Code":"QTP 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Trạm Phạm Văn Xảo"
    ,"Station_Address":"320, đường Vườn Lài, Quận Tân Phú"
    ,"Lat":10.788267
    ,"Long":106.623787
    ,"Polyline":"[106.62639618,10.78783512] ; [106.62639618,10.78783512] ; [106.62584686,10.78791142] ; [106.62478638,10.78806973] ; [106.62378693,10.78826714] ; [106.62378693,10.78826714]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2553"
    ,"Station_Code":"QTP 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Ch ợ Tân Hương"
    ,"Station_Address":"217-219, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.790046
    ,"Long":106.621666
    ,"Polyline":"[106.62378693,10.78826714] ; [106.62378693,10.78826714] ; [106.62282562,10.78855991] ; [106.62303162,10.78931904] ; [106.62316895,10.78988743] ; [106.62239838,10.78998756] ; [106.62166595,10.79004574] ; [106.62166595,10.79004574]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2584"
    ,"Station_Code":"QTP 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Trạm Chợ Tân Hương"
    ,"Station_Address":"248, đường Tân Hương, Quận Tân Phú"
    ,"Lat":10.79012
    ,"Long":106.621338
    ,"Polyline":"[106.62166595,10.79004574] ; [106.62150574,10.79012012] ; [106.62133789,10.79012012]"
    ,"Distance":"38"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2591"
    ,"Station_Code":"QTP 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Trạm y tế  P.Tân Quý"
    ,"Station_Address":"71 , đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.790937
    ,"Long":106.620766
    ,"Polyline":"[106.62133789,10.79012012] ; [106.62083435,10.79022026] ; [106.62076569,10.79093742]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2586"
    ,"Station_Code":"QTP 100"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Trạm café Minh Thùy"
    ,"Station_Address":"219, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.792765
    ,"Long":106.620628
    ,"Polyline":"[106.62076569,10.79093742] ; [106.62062836,10.79276466]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2593"
    ,"Station_Code":"QTP 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Trạm Ngã 4 Gò Dầu- Tân Quý"
    ,"Station_Address":"135, đường Tân Quý, Quận Tân Phú"
    ,"Lat":10.795121
    ,"Long":106.620346
    ,"Polyline":"[106.62062836,10.79276466] ; [106.62034607,10.79512119]"
    ,"Distance":"264"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3482"
    ,"Station_Code":"QTP 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Lê Liễu"
    ,"Station_Address":"133A, đường Gò Dầu, Quận Tân Phú"
    ,"Lat":10.795924
    ,"Long":106.619576
    ,"Polyline":"[106.62034607,10.79512119] ; [106.62034607,10.79512119] ; [106.62033844,10.79564190] ; [106.62006378,10.79587936] ; [106.61982727,10.79590034] ; [106.61957550,10.79592419] ; [106.61957550,10.79592419]"
    ,"Distance":"152"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3483"
    ,"Station_Code":"QTP 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Trạm D ương Văn Dương"
    ,"Station_Address":"282, đường G ò Dầu, Quận Tân Phú"
    ,"Lat":10.795945
    ,"Long":106.61747
    ,"Polyline":"[106.61957550,10.79592419] ; [106.61957550,10.79592419] ; [106.61895752,10.79582119] ; [106.61802673,10.79582119] ; [106.61746979,10.79594517] ; [106.61746979,10.79594517]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3484"
    ,"Station_Code":"QTP 181"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"17, đường Bình  Long, Quận Tân Phú"
    ,"Lat":10.795888
    ,"Long":106.614075
    ,"Polyline":"[106.61746979,10.79594517] ; [106.61746979,10.79594517] ; [106.61710358,10.79601669] ; [106.61672211,10.79603767] ; [106.61656189,10.79603195] ; [106.61623383,10.79583740] ; [106.61562347,10.79555225] ; [106.61492920,10.79534149] ; [106.61441040,10.79522038] ; [106.61407471,10.79588795] ; [106.61407471,10.79588795]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1967"
    ,"Station_Code":"QTP 085"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Trạm Bình Long"
    ,"Station_Address":"595-597, đường Tân Kỳ Tân Quý, Quận T ân Phú"
    ,"Lat":10.797259
    ,"Long":106.614601
    ,"Polyline":"[106.61407471,10.79588795] ; [106.61407471,10.79588795] ; [106.61368561,10.79671669] ; [106.61421967,10.79702282] ; [106.61460114,10.79725933] ; [106.61460114,10.79725933]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1970"
    ,"Station_Code":"QTP 086"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Trường Tiểu Học Tân Quý"
    ,"Station_Address":"545, đường Tân K ỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.798479
    ,"Long":106.616829
    ,"Polyline":"[106.61460114,10.79725933] ; [106.61598206,10.79803944] ; [106.61682892,10.79847908]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"1973"
    ,"Station_Code":"QTP 087"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Tân Quý"
    ,"Station_Address":"457-459, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799005
    ,"Long":106.618256
    ,"Polyline":"[106.61682892,10.79847908] ; [106.61682892,10.79847908] ; [106.61751556,10.79878235] ; [106.61825562,10.79900455] ; [106.61825562,10.79900455]"
    ,"Distance":"167"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2592"
    ,"Station_Code":"QTP 088"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Trạm Nhà Thờ Họ Tộc Nguyễn"
    ,"Station_Address":"395-397 , đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.799767
    ,"Long":106.620506
    ,"Polyline":"[106.61825562,10.79900455] ; [106.61825562,10.79900455] ; [106.61940765,10.79947281] ; [106.62050629,10.79976749] ; [106.62050629,10.79976654]"
    ,"Distance":"261"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2597"
    ,"Station_Code":"QTP 089"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Showroom  otô"
    ,"Station_Address":"343-345, đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.800703
    ,"Long":106.622986
    ,"Polyline":"[106.62050629,10.79976654] ; [106.62050629,10.79976749] ; [106.62185669,10.80038452] ; [106.62298584,10.80070305] ; [106.62298584,10.80070305]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2594"
    ,"Station_Code":"QTP 090"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trạm Xăng"
    ,"Station_Address":"295 , đường Tân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.8019
    ,"Long":106.625854
    ,"Polyline":"[106.62298584,10.80070305] ; [106.62298584,10.80070305] ; [106.62444305,10.80135918] ; [106.62585449,10.80189991] ; [106.62585449,10.80189991]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2596"
    ,"Station_Code":"QTP 091"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Trạm  Đường Số 27"
    ,"Station_Address":"235, đường T ân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.802643
    ,"Long":106.628525
    ,"Polyline":"[106.62585449,10.80189991] ; [106.62585449,10.80189991] ; [106.62735748,10.80247688] ; [106.62800598,10.80259800] ; [106.62852478,10.80264282] ; [106.62852478,10.80264282]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2598"
    ,"Station_Code":"QTP 092"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Trạm Lê Trọng Tấn"
    ,"Station_Address":"153, đường T ân Kỳ Tân Quý, Quận Tân Phú"
    ,"Lat":10.803166
    ,"Long":106.631592
    ,"Polyline":"[106.62852478,10.80264282] ; [106.62852478,10.80264282] ; [106.62852478,10.80264282] ; [106.63011169,10.80299282] ; [106.63159180,10.80316639] ; [106.63159180,10.80316639] ; [106.63159180,10.80316639]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2600"
    ,"Station_Code":"QTP 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Trạm Đầu Lê Trọng Tấn"
    ,"Station_Address":"8A-8B, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.804282
    ,"Long":106.632187
    ,"Polyline":"[106.63159180,10.80316639] ; [106.63159180,10.80316639] ; [106.63159180,10.80316639] ; [106.63204193,10.80337238] ; [106.63282776,10.80355167] ; [106.63218689,10.80428219] ; [106.63218689,10.80428219] ; [106.63218689,10.80428219]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2602"
    ,"Station_Code":"QTP 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Trường Cao Đẳng Công Nghệ Thực Phẩm"
    ,"Station_Address":"142-144, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.806065
    ,"Long":106.628586
    ,"Polyline":"[106.63218689,10.80428219] ; [106.63218689,10.80428219] ; [106.63146210,10.80510044] ; [106.63079834,10.80553246] ; [106.62858582,10.80606461] ; [106.62858582,10.80606461]"
    ,"Distance":"457"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2000"
    ,"Station_Code":"QTP 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"TOYOTA"
    ,"Station_Address":"188, đường Lê Tr ọng Tấn, Quận Tân Phú"
    ,"Lat":10.806785
    ,"Long":106.625366
    ,"Polyline":"[106.62858582,10.80606461] ; [106.62536621,10.80678463]"
    ,"Distance":"361"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2005"
    ,"Station_Code":"QTP 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Trạm Bờ Bao Tân Thắng"
    ,"Station_Address":"284, đường Lê Trọng Tấn, Quận Tân Ph ú"
    ,"Lat":10.807464
    ,"Long":106.622177
    ,"Polyline":"[106.62536621,10.80678463] ; [106.62217712,10.80746365]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"2917"
    ,"Station_Code":"QTP 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Trạm Tây Thạnh"
    ,"Station_Address":"386, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.808257
    ,"Long":106.619133
    ,"Polyline":"[106.62217712,10.80746365] ; [106.62217712,10.80746365] ; [106.62066650,10.80780411] ; [106.61913300,10.80825710.06.61913300]"
    ,"Distance":"345"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3101"
    ,"Station_Code":"QTP 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Trạm Kênh 19/5"
    ,"Station_Address":"456, đường Lê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.809163
    ,"Long":106.616302
    ,"Polyline":"[106.61913300,10.80825710.06.61913300] ; [10.80825710.06.61913300,10.80825710.06.61715698] ; [10.80876255,106.61630249] ; [10.80916309,106.61630249] ; [10.80916309,106.61630249]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3100"
    ,"Station_Code":"QTP 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Trạm Đường CN 13"
    ,"Station_Address":"510, đường L ê Trọng Tấn, Quận Tân Phú"
    ,"Lat":10.810217
    ,"Long":106.61351
    ,"Polyline":"[106.61630249,10.80916309] ; [106.61630249,10.80916309] ; [106.61529541,10.80923748] ; [106.61418915,10.80965900] ; [106.61351013,10.81021690] ; [106.61351013,10.81021690]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"105"
    ,"Station_Id":"3486"
    ,"Station_Code":"BX52"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Khu công nghiệp Tân Bình"
    ,"Station_Address":"ĐẦU BẾN KCN TÂN BÌNH, đường Đường CN1 , Quận Tân Phú"
    ,"Lat":10.806971549987793
    ,"Long":106.6078872680664
    ,"Polyline":"[106.61351013,10.81021690] ; [106.61296082,10.81028557] ; [106.61267853,10.81040955] ; [106.61192322,10.81079006] ; [106.61152649,10.81097031] ; [106.61148071,10.81085968] ; [106.61134338,10.81064034] ; [106.61106873,10.81031036] ; [106.61032867,10.80943012] ; [106.60975647,10.80875969] ; [106.60864258,10.80743980] ; [106.60801697,10.80671978] ; [106.60788727,10.80696964] ; [106.60788727,10.80697155]"
    ,"Distance":"876"
  }]