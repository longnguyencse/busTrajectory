export const Route121 =[

  {
     "Route_Id":"121"
    ,"Station_Id":"3905"
    ,"Station_Code":"HBC 316"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến Lê Minh Xuân"
    ,"Station_Address":"Đối diện C3/79/1, đường Vườn Th ơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.75055
    ,"Long":106.478165
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3906"
    ,"Station_Code":"HBC 317"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Đầm lầy 2"
    ,"Station_Address":"Đối diện C4/29/1, đường Vườn Thơm, Bình Chánh, Huy ện Bình Chánh"
    ,"Lat":10.755001
    ,"Long":106.48402
    ,"Polyline":"[106.47815704,10.75055981] ; [106.48021698,10.75214005] ; [106.48213959,10.75354958] ; [106.48339844,10.75450039] ; [106.48406219,10.75498962]"
    ,"Distance":"812"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3907"
    ,"Station_Code":"HBC 318"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Đầm lầy 1"
    ,"Station_Address":"Đối diện C5/178, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.757573
    ,"Long":106.487496
    ,"Polyline":"[106.48406219,10.75498962] ; [106.48455811,10.75535965] ; [106.48490906,10.75566959] ; [106.48697662,10.75716972] ; [106.48748779,10.75759029]"
    ,"Distance":"474"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3908"
    ,"Station_Code":"HBC 319"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Bến đò xã Bình Lợi"
    ,"Station_Address":"Đối diện C7/223A, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.761346
    ,"Long":106.492302
    ,"Polyline":"[106.48748779,10.75759029] ; [106.48927307,10.75899982] ; [106.49069977,10.76008034] ; [106.49118042,10.76047039] ; [106.49212646,10.76119995] ; [106.49234772,10.76136017]"
    ,"Distance":"677"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3909"
    ,"Station_Code":"HBC 320"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Kênh 2"
    ,"Station_Address":"Đối diện C8/315 , đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.76435
    ,"Long":106.496363
    ,"Polyline":"[106.49234772,10.76136017] ; [106.49313354,10.76191998] ; [106.49490356,10.76331997] ; [106.49632263,10.76443958]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3910"
    ,"Station_Code":"HBC 321"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Kênh 3"
    ,"Station_Address":"Đối diện C9/361, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.767338
    ,"Long":106.500376
    ,"Polyline":"[106.49632263,10.76443958] ; [106.49806213,10.76578999] ; [106.49964905,10.76700020] ; [106.50025940,10.76747990]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3913"
    ,"Station_Code":"HBC 322"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Kênh 5"
    ,"Station_Address":"Đối diện C11/4/9, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.773446
    ,"Long":106.508101
    ,"Polyline":"[106.50025940,10.76747990] ; [106.50171661,10.76856995] ; [106.50353241,10.76998043] ; [106.50553131,10.77151012] ; [106.50695801,10.77258015] ; [106.50814056,10.77350998]"
    ,"Distance":"1092"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3911"
    ,"Station_Code":"HBC 323"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Kênh 6"
    ,"Station_Address":"Đối diện Cột điện 40P, đư ờng Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.777588
    ,"Long":106.510633
    ,"Polyline":"[106.50814056,10.77350998] ; [106.50849915,10.77379036] ; [106.50885773,10.77423954] ; [106.50932312,10.77488995] ; [106.50964355,10.77540970] ; [106.51004028,10.77614021] ; [106.51032257,10.77676010.06.51056671]"
    ,"Distance":"535"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3912"
    ,"Station_Code":"HBC 324"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Kênh 8"
    ,"Station_Address":"Đối diện Đối diện C27,  đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.780508
    ,"Long":106.51133
    ,"Polyline":"[106.51056671,10.77760983] ; [106.51132202,10.78052044]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3914"
    ,"Station_Code":"HBC 325"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Kênh 9"
    ,"Station_Address":"Đối diện D5/589A, đường  Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.782842
    ,"Long":106.511909
    ,"Polyline":"[106.51132202,10.78052044] ; [106.51187134,10.78285980]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3915"
    ,"Station_Code":"HBC 326"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Kênh 10"
    ,"Station_Address":"D6.611, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.785345
    ,"Long":106.512473
    ,"Polyline":"[106.51187134,10.78285980] ; [106.51236725,10.78483963] ; [106.51242828,10.78532982]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3916"
    ,"Station_Code":"HBC 327"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cầu Rau Răm"
    ,"Station_Address":"D6/643, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.788191
    ,"Long":106.512564
    ,"Polyline":"[106.51242828,10.78532982] ; [106.51233673,10.78600979] ; [106.51233673,10.78709030]"
    ,"Distance":"196"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3436"
    ,"Station_Code":"HBC 294"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Bãi cát cầu Rau Răm"
    ,"Station_Address":"Đối diện 3A/63 TTH Cầu Xáng, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.788676
    ,"Long":106.515541
    ,"Polyline":"[106.51233673,10.78709030] ; [106.51232910,10.78757000] ; [106.51235962,10.78794003] ; [106.51244354,10.78812027] ; [106.51296997,10.78878021] ; [106.51315308,10.78913975] ; [106.51329041,10.78975964] ; [106.51336670,10.78983974] ; [106.51454163,10.78925037] ; [106.51557159,10.78874969]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3437"
    ,"Station_Code":"HBC 295"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 3 Vườn Thơm"
    ,"Station_Address":"Đối diện 3A35/3, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.787622
    ,"Long":106.517472
    ,"Polyline":"[106.51557159,10.78874969] ; [106.51753235,10.78773022]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3438"
    ,"Station_Code":"HBC 290"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Cầu Xáng"
    ,"Station_Address":"Đối diện 3A.11, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.786463
    ,"Long":106.519908
    ,"Polyline":"[106.51753235,10.78773022] ; [106.51995087,10.78654003]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3439"
    ,"Station_Code":"HBC 296"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Nhà thờ chợ Cầu Xáng"
    ,"Station_Address":"đối diện 2A/94, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.78465
    ,"Long":106.523491
    ,"Polyline":"[106.51995087,10.78654003] ; [106.52353668,10.78474998]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3440"
    ,"Station_Code":"HBC 297"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Đa khoa Sài Gòn"
    ,"Station_Address":"Đối diện 2A/63, đường Tỉnh lộ 10 Bình Chánh, Huyện  Bình Chánh"
    ,"Lat":10.783253
    ,"Long":106.526383
    ,"Polyline":"[106.52353668,10.78474998] ; [106.52641296,10.78330994]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3441"
    ,"Station_Code":"HBC 298"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"CTY giống cây trồng TPHCM"
    ,"Station_Address":"đối diện CTY giống cây trồng TPHCM,  đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.781425
    ,"Long":106.529918
    ,"Polyline":"[106.52641296,10.78330994] ; [106.53003693,10.78149986]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3442"
    ,"Station_Code":"HBC 299"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Kênh A"
    ,"Station_Address":"Đối diện 2A/27/1, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.779949
    ,"Long":106.532804
    ,"Polyline":"[106.53003693,10.78149986] ; [106.53161621,10.78071022] ; [106.53259277,10.78026962] ; [106.53292084,10.78013039]"
    ,"Distance":"350"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3443"
    ,"Station_Code":"HBC 300"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Xã Lê Minh Xuân"
    ,"Station_Address":"Đối diện 2A/2, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.776566
    ,"Long":106.539595
    ,"Polyline":"[106.53292084,10.78013039] ; [106.53459167,10.77923012] ; [106.53568268,10.77867985] ; [106.53726196,10.77789974] ; [106.53856659,10.77723026] ; [106.53970337,10.77665997]"
    ,"Distance":"836"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3444"
    ,"Station_Code":"HBC 301"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Cầu Bà Lát"
    ,"Station_Address":"Đối diện 1A59/1, đường Tr ần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.769889
    ,"Long":106.552851
    ,"Polyline":"[106.53970337,10.77665997] ; [106.54219818,10.77538967] ; [106.54575348,10.77359009] ; [106.54724121,10.77283001]"
    ,"Distance":"928"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3311"
    ,"Station_Code":"HBC 302"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Công ty Th ịnh Uy"
    ,"Station_Address":"Đối diện 1A/38/1, đường Trần Văn Giàu, Huy ện Bình Chánh"
    ,"Lat":10.767349
    ,"Long":106.557877
    ,"Polyline":"[106.54724121,10.77283001] ; [106.54920959,10.77182961] ; [106.55045319,10.77120018] ; [106.55145264,10.77071953] ; [106.55168915,10.77066040] ; [106.55320740,10.76986980] ; [106.55328369,10.76980019] ; [106.55384064,10.76949978] ; [106.55429840,10.76926041]"
    ,"Distance":"869"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3313"
    ,"Station_Code":"HBC 303"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Coop Mart Vĩnh Lộc B"
    ,"Station_Address":"Đối diện 1A/24/2, đường Trần Văn Giàu , Huyện Bình Chánh"
    ,"Lat":10.764925
    ,"Long":106.563097
    ,"Polyline":"[106.55429840,10.76926041] ; [106.55635834,10.76817989] ; [106.55760956,10.76755047] ; [106.55848694,10.76712036] ; [106.55973053,10.76655006] ; [106.55995941,10.76644039]"
    ,"Distance":"694"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3312"
    ,"Station_Code":"HBC 304"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Võ Văn Vân"
    ,"Station_Address":"Đối diện 1A/7, đường Trần Văn Giàu, Huyện  Bình Chánh"
    ,"Lat":10.763033
    ,"Long":106.567174
    ,"Polyline":"[106.55995941,10.76644039] ; [106.56549835,10.76389027]"
    ,"Distance":"669"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3446"
    ,"Station_Code":"QBT 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cầu Tân Tạo"
    ,"Station_Address":"Đ/d 1800, đường T ỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.76113
    ,"Long":106.571632
    ,"Polyline":"[106.56549835,10.76389027] ; [106.56752777,10.76294994] ; [106.56764984,10.76290989] ; [106.56775665,10.76292992] ; [106.56903839,10.76235962] ; [106.57095337,10.76148987] ; [106.57164764,10.76117039]"
    ,"Distance":"739"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3445"
    ,"Station_Code":"QBT 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Giai Hồng Phát"
    ,"Station_Address":"1749, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình  Tân"
    ,"Lat":10.759614
    ,"Long":106.575447
    ,"Polyline":"[106.57164764,10.76117039] ; [106.57228088,10.76088047] ; [106.57308960,10.76054955] ; [106.57401276,10.76012993] ; [106.57460022,10.75986004] ; [106.57482147,10.75979996] ; [106.57502747,10.75973988] ; [106.57544708,10.75961971]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3448"
    ,"Station_Code":"QBT 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Phòng khám Đa khoa Khánh An"
    ,"Station_Address":"1689, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.758846
    ,"Long":106.578438
    ,"Polyline":"[106.57544708,10.75961971] ; [106.57631683,10.75938988] ; [106.57765198,10.75905991] ; [106.57843781,10.75885963]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3447"
    ,"Station_Code":"QBT 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Mầm non Vy Vy"
    ,"Station_Address":"1581, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam , Quận Bình Tân"
    ,"Lat":10.758222
    ,"Long":106.580635
    ,"Polyline":"[106.57843781,10.75885963] ; [106.57990265,10.75846004] ; [106.58065033,10.75827980]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3450"
    ,"Station_Code":"QBT 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu vượt Tân Tạo - Chợ Đệm"
    ,"Station_Address":"1441, đường Tỉnh lộ 10,T ân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.757578
    ,"Long":106.583069
    ,"Polyline":"[106.58065033,10.75827980] ; [106.58307648,10.75765038]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3449"
    ,"Station_Code":"QBT 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Phòng  Y học Cổ truyền"
    ,"Station_Address":"1335, đường T ỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.756835
    ,"Long":106.586945
    ,"Polyline":"[106.58307648,10.75765038] ; [106.58405304,10.75743961] ; [106.58586121,10.75701046] ; [106.58628845,10.75689983] ; [106.58648682,10.75687027] ; [106.58693695,10.75685024]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"2381"
    ,"Station_Code":"QBT 157"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trạm xăng số 5"
    ,"Station_Address":"1209, đường T ỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.755855
    ,"Long":106.594154
    ,"Polyline":"[106.58693695,10.75685024] ; [106.58744812,10.75685024] ; [106.58827972,10.75691032] ; [106.58863068,10.75689983] ; [106.59033966,10.75666046] ; [106.59130096,10.75652981] ; [106.59175873,10.75644970] ; [106.59201050,10.75638008] ; [106.59274292,10.75623035] ; [106.59416962,10.75590992]"
    ,"Distance":"801"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"2382"
    ,"Station_Code":"QBT 158"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Trạm 34"
    ,"Station_Address":"1135, đường T ỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.75497
    ,"Long":106.598061
    ,"Polyline":"[106.59416962,10.75590992] ; [106.59808350,10.75502968]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"2383"
    ,"Station_Code":"QBT 159"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Đường 32"
    ,"Station_Address":"991, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí  Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.754559
    ,"Long":106.60199
    ,"Polyline":"[106.59808350,10.75502968] ; [106.59953308,10.75473976] ; [106.59986115,10.75471020] ; [106.60027313,10.75469971] ; [106.60198975,10.75461960]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3404"
    ,"Station_Code":"QBT 164"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Ấp Văn h óa"
    ,"Station_Address":"899 , đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.755135
    ,"Long":106.604538
    ,"Polyline":"[106.60198975,10.75461960] ; [106.60308838,10.75457954] ; [106.60363770,10.75465965] ; [106.60401917,10.75473976] ; [106.60414124,10.75477982] ; [106.60430908,10.75491047] ; [106.60452271,10.75514984]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"2906"
    ,"Station_Code":"QBT 160"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Lê Đình Cẩn"
    ,"Station_Address":"831, đường Bà Hom, Quận Bình Tân"
    ,"Lat":10.75781
    ,"Long":106.60643
    ,"Polyline":"[106.60452271,10.75514984] ; [106.60475922,10.75549030] ; [106.60520172,10.75617981] ; [106.60592651,10.75720978] ; [106.60619354,10.75763035] ; [106.60632324,10.75778961] ; [106.60639954,10.75786018]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3452"
    ,"Station_Code":"QBT 161"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Nhà thờ tin lành"
    ,"Station_Address":"693, đường Bà Hom, Quận Bình Tân"
    ,"Lat":10.757863
    ,"Long":106.609671
    ,"Polyline":"[106.60639954,10.75786018] ; [106.60658264,10.75798035] ; [106.60688019,10.75809956] ; [106.60719299,10.75813961] ; [106.60749817,10.75813961] ; [106.60804749,10.75809002] ; [106.60880280,10.75798988] ; [106.60968018,10.75786018]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3451"
    ,"Station_Code":"QBT 162"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bông Sen"
    ,"Station_Address":"595, đường Bà Hom, Quận Bình Tân"
    ,"Lat":10.758195
    ,"Long":106.612991
    ,"Polyline":"[106.60968018,10.75786018] ; [106.61016083,10.75780010.06.61080170] ; [10.75788975,106.61218262] ; [10.75821972,106.61257935] ; [10.75823021,106.61298370]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3453"
    ,"Station_Code":"QBT 165"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Da sà cũ"
    ,"Station_Address":"491, đường Bà Hom, Quận Bình Tân"
    ,"Lat":10.757757
    ,"Long":106.615464
    ,"Polyline":"[106.61298370,10.75817013] ; [106.61401367,10.75796032] ; [106.61502075,10.75776958] ; [106.61544800,10.75769043]"
    ,"Distance":"275"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3454"
    ,"Station_Code":"QBT 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Cấp nước Bình Trị Đông"
    ,"Station_Address":"Cấp nước BTĐ, đường Bà Hom, Quận Bình Tân"
    ,"Lat":10.757401
    ,"Long":106.618225
    ,"Polyline":"[106.61544800,10.75769043] ; [106.61592102,10.75761986] ; [106.61643219,10.75757027] ; [106.61694336,10.75755978] ; [106.61739349,10.75751972] ; [106.61823273,10.75745964]"
    ,"Distance":"305"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3456"
    ,"Station_Code":"QBT 163"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bông Sen"
    ,"Station_Address":"343, đường Bà Hom, Quận Bình Tân"
    ,"Lat":10.757188
    ,"Long":106.620174
    ,"Polyline":"[106.61827087,10.75745010.06.61918640] ; [10.75732040,106.62001801]"
    ,"Distance":"193"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4767"
    ,"Station_Code":"Q6 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"An Dương Vương"
    ,"Station_Address":"263-265, đường Bà Hom, Quận 6"
    ,"Lat":10.755665
    ,"Long":106.626
    ,"Polyline":"[106.62017059,10.75718784] ; [106.62099457,10.75713062] ; [106.62152863,10.75712013] ; [106.62353516,10.75638771] ; [106.62443542,10.75597095] ; [106.62526703,10.75582314] ; [106.62599945,10.75566483]"
    ,"Distance":"664.960548254402"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4768"
    ,"Station_Code":"Q6 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bà Hom"
    ,"Station_Address":"171-173, đường Bà Hom, Quận 6"
    ,"Lat":10.755249
    ,"Long":106.628092
    ,"Polyline":"[106.62599945,10.75566483] ; [106.62663269,10.75559711] ; [106.62744141,10.75544930] ; [106.62808990,10.75524902]"
    ,"Distance":"233.258817516318"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4769"
    ,"Station_Code":"Q6 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Chợ Phú Lâm"
    ,"Station_Address":"109 , đường Bà Hom, Quận 6"
    ,"Lat":10.754611
    ,"Long":106.631439
    ,"Polyline":"[106.62808990,10.75524902] ; [106.62886810,10.75514317] ; [106.62977600,10.75497437] ; [106.63066864,10.75479603] ; [106.63143921,10.75461102]"
    ,"Distance":"373.115582006062"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4770"
    ,"Station_Code":"Q6 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Coop mart Phú Lâm"
    ,"Station_Address":"71-73, đường  Bà Hom, Quận 6"
    ,"Lat":10.754348
    ,"Long":106.632754
    ,"Polyline":"[106.63143921,10.75461102] ; [106.63206482,10.75456905] ; [106.63275146,10.75434780]"
    ,"Distance":"146.47448660306"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"724"
    ,"Station_Code":"Q6 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Cầu Ông Buông"
    ,"Station_Address":"963, đường Hồng B àng, Quận 6"
    ,"Lat":10.754548
    ,"Long":106.637995
    ,"Polyline":"[106.63275146,10.75434780] ; [106.63355255,10.75422668] ; [106.63419342,10.75411034] ; [106.63415527,10.75395775] ; [106.63420105,10.75380516] ; [106.63433838,10.75372028] ; [106.63454437,10.75364113] ; [106.63473511,10.75379467] ; [106.63481140,10.75403118] ; [106.63513184,10.75429535] ; [106.63551331,10.75442123] ; [106.63629150,10.75443745] ; [106.63722992,10.75452709] ; [106.63757324,10.75459003] ; [106.63799286,10.75454807]"
    ,"Distance":"592.784839958823"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"719"
    ,"Station_Code":"Q6 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Ngân hàng ACB"
    ,"Station_Address":"871, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754295
    ,"Long":106.641245
    ,"Polyline":"[106.63799286,10.75454807] ; [106.63817596,10.75458622] ; [106.63922882,10.75454235] ; [106.64059448,10.75444794] ; [106.64124298,10.75429535]"
    ,"Distance":"337.327443565454"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"721"
    ,"Station_Code":"Q6 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Trường Nguyễn Đức Cảnh"
    ,"Station_Address":"799, đường Hồng Bàng, Quận 6"
    ,"Lat":10.754021
    ,"Long":106.644003
    ,"Polyline":"[106.64124298,10.75429535] ; [106.64196777,10.75427437] ; [106.64299011,10.75414753] ; [106.64400482,10.75402069]"
    ,"Distance":"313.606042166351"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"723"
    ,"Station_Code":"Q6 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Chùa Nam Phổ Đà"
    ,"Station_Address":"735, đường Hồng Bàng, Quận 6"
    ,"Lat":10.753789
    ,"Long":106.645955
    ,"Polyline":"[106.64400482,10.75402069] ; [106.64595795,10.75378895]"
    ,"Distance":"205.151732219454"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"722"
    ,"Station_Code":"Q6 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"647 , đường Hồng Bàng, Quận 6"
    ,"Lat":10.753647
    ,"Long":106.647323
    ,"Polyline":"[106.64595795,10.75378895] ; [106.64595795,10.75378895] ; [106.64595795,10.75378895] ; [106.64668274,10.75370979] ; [106.64732361,10.75364685] ; [106.64732361,10.75364685] ; [106.64732361,10.75364685]"
    ,"Distance":"150.492925684742"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường H ồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.64732361,10.75364685] ; [106.65072632,10.75331974] ; [106.65233612,10.75333118]"
    ,"Distance":"547.610606606376"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận  5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65233612,10.75333118] ; [106.65377045,10.75363064] ; [106.65330505,10.75169659] ; [106.65313721,10.75147057] ; [106.65296936,10.75133324] ; [106.65256500,10.75125313]"
    ,"Distance":"239.628847811695"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"620"
    ,"Station_Code":"Q11 094"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Cây Mai"
    ,"Station_Address":"384, đường Hồng Bàng, Quận 11"
    ,"Lat":10.753689
    ,"Long":106.64926
    ,"Polyline":"[106.65258026,10.75104046] ; [106.65097046,10.75094986] ; [106.65048218,10.75100994] ; [106.65052795,10.75148010.06.65061951] ; [10.75234032,106.65074158] ; [10.75352001,106.64929199]"
    ,"Distance":"670"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"622"
    ,"Station_Code":"Q11 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Lò Siêu"
    ,"Station_Address":"508, đường Hồng  Bàng, Quận 11"
    ,"Lat":10.753952
    ,"Long":106.646787
    ,"Polyline":"[106.64929199,10.75364971] ; [106.64682770,10.75389957]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"624"
    ,"Station_Code":"Q11 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"638-640, đường Hồng Bàng, Quận 11"
    ,"Lat":10.754232
    ,"Long":106.644368
    ,"Polyline":"[106.64682770,10.75389957] ; [106.64437866,10.75415993]"
    ,"Distance":"269"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"625"
    ,"Station_Code":"Q11 097"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Huê Lâm"
    ,"Station_Address":"690 (138), đường  Hồng Bàng, Quận 11"
    ,"Lat":10.754558
    ,"Long":106.641229
    ,"Polyline":"[106.64437866,10.75415993] ; [106.64343262,10.75424957] ; [106.64314270,10.75426960] ; [106.64127350,10.75448990]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"623"
    ,"Station_Code":"Q11 098"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Tân Hóa"
    ,"Station_Address":"786, đường Hồng Bàng, Quận 11"
    ,"Lat":10.75477
    ,"Long":106.638428
    ,"Polyline":"[106.64127350,10.75448990] ; [106.63986206,10.75461960] ; [106.63922882,10.75469017] ; [106.63886261,10.75473976] ; [106.63842773,10.75475979]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"626"
    ,"Station_Code":"Q6 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường Mạc Đỉnh Chi"
    ,"Station_Address":"832-834, đường Hồng Bàng, Qu ận 6"
    ,"Lat":10.754732
    ,"Long":106.635574
    ,"Polyline":"[106.63842773,10.75475979] ; [106.63723755,10.75477505] ; [106.63648224,10.75477505] ; [106.63587952,10.75458527] ; [106.63558197,10.75438023]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4763"
    ,"Station_Code":"Q6 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Coop mart Phú Lâm"
    ,"Station_Address":"Đối diện 35, đường Bà Hom , Quận 6"
    ,"Lat":10.754258
    ,"Long":106.633746
    ,"Polyline":"[106.63557434,10.75473213] ; [106.63557434,10.75473213] ; [106.63495636,10.75435257] ; [106.63436127,10.75423717] ; [106.63419342,10.75413704] ; [106.63374329,10.75425816] ; [106.63374329,10.75425816]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4764"
    ,"Station_Code":"Q6 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Phú Lâm"
    ,"Station_Address":"64A3-64A4, đường Bà Hom, Quận 6"
    ,"Lat":10.754864
    ,"Long":106.630602
    ,"Polyline":"[106.63374329,10.75425816] ; [106.63059998,10.75486374]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4765"
    ,"Station_Code":"Q6 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bà Hom"
    ,"Station_Address":"100-102, đường Bà Hom, Quận 6"
    ,"Lat":10.755191
    ,"Long":106.628993
    ,"Polyline":"[106.63059998,10.75486374] ; [106.62899017,10.75519085]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"4766"
    ,"Station_Code":"Q6 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"An Dương V ương"
    ,"Station_Address":"248-250, đường Bà Hom , Quận 6"
    ,"Lat":10.755665
    ,"Long":106.626563
    ,"Polyline":"[106.62899017,10.75519085] ; [106.62656403,10.75566483]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3455"
    ,"Station_Code":"QBT 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Siêu thị Phú Lâm"
    ,"Station_Address":"334, đường T ỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.757201
    ,"Long":106.620567
    ,"Polyline":"[106.62656403,10.75566483] ; [106.62656403,10.75566483] ; [106.62485504,10.75591850] ; [106.62393188,10.75619221] ; [106.62246704,10.75680351] ; [106.62155151,10.75709915] ; [106.62056732,10.75720119]"
    ,"Distance":"682"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3457"
    ,"Station_Code":"QBT 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Phú Lâm"
    ,"Station_Address":"408, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí  Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.757481
    ,"Long":106.618355
    ,"Polyline":"[106.62056732,10.75720119] ; [106.62056732,10.75714016] ; [106.62036133,10.75719357] ; [106.62013245,10.75722504] ; [106.61957550,10.75732517] ; [106.61918640,10.75739956] ; [106.61875153,10.75743103] ; [106.61834717,10.75743961] ; [106.61835480,10.75748062]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3458"
    ,"Station_Code":"QBT 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đường số  10"
    ,"Station_Address":"508, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam , Quận Bình Tân"
    ,"Lat":10.757742
    ,"Long":106.615395
    ,"Polyline":"[106.61835480,10.75748062] ; [106.61834717,10.75743961] ; [106.61778259,10.75754642] ; [106.61731720,10.75757790] ; [106.61682892,10.75760460] ; [106.61619568,10.75769997] ; [106.61559296,10.75777817] ; [106.61538696,10.75769997] ; [106.61539459,10.75774193]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3459"
    ,"Station_Code":"QBT 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Kim Ngân"
    ,"Station_Address":"570, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.758161
    ,"Long":106.613106
    ,"Polyline":"[106.61539459,10.75774193] ; [106.61538696,10.75769997] ; [106.61481476,10.75789452] ; [106.61393738,10.75807381] ; [106.61343384,10.75817871] ; [106.61319733,10.75819492] ; [106.61311340,10.75815010.06.61310577]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3460"
    ,"Station_Code":"QBT 139"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Da sà"
    ,"Station_Address":"686, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.757884
    ,"Long":106.610107
    ,"Polyline":"[106.61310577,10.75816059] ; [106.61311340,10.75815010.06.61288452] ; [10.75824738,106.61264038] ; [10.75828934,106.61238861] ; [10.75828457,106.61209869] ; [10.75826836,106.61079407] ; [10.75793171,106.61016083] ; [10.75780010.06.61009979,10.75780964] ; [106.61010742,10.75788403]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3461"
    ,"Station_Code":"QBT 140"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chùa Mai Sơn"
    ,"Station_Address":"824-810, đường Tỉnh lộ 10,Tân Tạo, Hồ  Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.758161
    ,"Long":106.607697
    ,"Polyline":"[106.61010742,10.75788403] ; [106.61009979,10.75780964] ; [106.60987091,10.75788403] ; [106.60916138,10.75794029] ; [106.60880280,10.75798988] ; [106.60806274,10.75804710.06.60768890] ; [10.75813007,106.60769653]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3423"
    ,"Station_Code":"QBT 141"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Da sà  mới"
    ,"Station_Address":"932, đường Tỉnh lộ 10,Tân  Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.755328
    ,"Long":106.604599
    ,"Polyline":"[106.60768890,10.75813007] ; [106.60719299,10.75813961] ; [106.60688019,10.75809956] ; [106.60658264,10.75798035] ; [106.60632324,10.75778961] ; [106.60619354,10.75763035] ; [106.60592651,10.75720978] ; [106.60520172,10.75617981] ; [106.60475922,10.75549030] ; [106.60462952,10.75531006]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"2310"
    ,"Station_Code":"QBT 142"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Kim Th ành"
    ,"Station_Address":"1050, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.754742
    ,"Long":106.6017
    ,"Polyline":"[106.60462952,10.75531006] ; [106.60443115,10.75502968] ; [106.60430908,10.75491047] ; [106.60414124,10.75477982] ; [106.60401917,10.75473976] ; [106.60363770,10.75465965] ; [106.60308838,10.75457954] ; [106.60169220,10.75463009]"
    ,"Distance":"323.717432479517"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"2312"
    ,"Station_Code":"QBT 143"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đường số 32"
    ,"Station_Address":"1146 , đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.755198
    ,"Long":106.597771
    ,"Polyline":"[106.60169983,10.75474167] ; [106.60150146,10.75468540] ; [106.60077667,10.75471973] ; [106.59999084,10.75473976] ; [106.59979248,10.75473976] ; [106.59915924,10.75483036] ; [106.59845734,10.75496006] ; [106.59794617,10.75509644] ; [106.59777069,10.75519848]"
    ,"Distance":"432.70503405105"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"2313"
    ,"Station_Code":"QBT 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ Bình Trị Đông"
    ,"Station_Address":"1230, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình  Tân"
    ,"Lat":10.756071
    ,"Long":106.593796
    ,"Polyline":"[106.59777069,10.75519848] ; [106.59744263,10.75521183] ; [106.59379578,10.75607109]"
    ,"Distance":"445.432787682276"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3462"
    ,"Station_Code":"QBT 145"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Tên Lửa"
    ,"Station_Address":"1730-1370, đường Tỉnh lộ 10,Tân Tạo, H ồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.756949
    ,"Long":106.586159
    ,"Polyline":"[106.59378052,10.75599957] ; [106.59274292,10.75623035] ; [106.59201050,10.75638008] ; [106.59175873,10.75644970] ; [106.59130096,10.75652981] ; [106.58863068,10.75689983] ; [106.58827972,10.75691032] ; [106.58744812,10.75685024] ; [106.58683014,10.75685024] ; [106.58628845,10.75689983] ; [106.58615875,10.75693989]"
    ,"Distance":"840.915479772913"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3466"
    ,"Station_Code":"QBT 146"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Khang  Mỹ Lạc"
    ,"Station_Address":"1480, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.757694
    ,"Long":106.583252
    ,"Polyline":"[106.58615875,10.75693989] ; [106.58389282,10.75747013] ; [106.58322906,10.75761032]"
    ,"Distance":"328.531616583228"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3463"
    ,"Station_Code":"QBT 147"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Đạt Hòa"
    ,"Station_Address":"1598, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh , Việt Nam, Quận Bình Tân"
    ,"Lat":10.758303
    ,"Long":106.580856
    ,"Polyline":"[106.58325195,10.75769424] ; [106.58283997,10.75781536] ; [106.58115387,10.75821590] ; [106.58085632,10.75830269]"
    ,"Distance":"270.606781085822"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3464"
    ,"Station_Code":"QBT 148"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Bà Hom"
    ,"Station_Address":"1724, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.758835
    ,"Long":106.57856
    ,"Polyline":"[106.58085632,10.75830269] ; [106.58054352,10.75837898] ; [106.57990265,10.75851631] ; [106.57894135,10.75877476] ; [106.57855988,10.75883484]"
    ,"Distance":"258.037752585652"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3465"
    ,"Station_Code":"QBT 149"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chợ Bà Hom"
    ,"Station_Address":"1754, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam , Quận Bình Tân"
    ,"Lat":10.759585
    ,"Long":106.57563
    ,"Polyline":"[106.57855988,10.75881958] ; [106.57631683,10.75938988] ; [106.57563019,10.75957966]"
    ,"Distance":"331.112530309765"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3468"
    ,"Station_Code":"QBT 150"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Công ty XNK Tam Phát"
    ,"Station_Address":"1806-1810, đ ường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Quận Bình Tân"
    ,"Lat":10.761275
    ,"Long":106.57151
    ,"Polyline":"[106.57563019,10.75958538] ; [106.57563019,10.75957966] ; [106.57460022,10.75986004] ; [106.57357788,10.76033020] ; [106.57253265,10.76078033] ; [106.57192230,10.76106167] ; [106.57151031,10.76127529]"
    ,"Distance":"488.253633478355"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3289"
    ,"Station_Code":"HBC 280"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Võ Văn Vân"
    ,"Station_Address":"1A7, đường Trần Văn Giàu, Huyện Bình Ch ánh"
    ,"Lat":10.763138
    ,"Long":106.567447
    ,"Polyline":"[106.57151031,10.76127529] ; [106.57111359,10.76143074] ; [106.56974792,10.76202965] ; [106.56775665,10.76292992] ; [106.56744385,10.76313782]"
    ,"Distance":"759.169295771612"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3288"
    ,"Station_Code":"HBC 281"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Coop mart Vĩnh Lộc B"
    ,"Station_Address":"1A24/2, đường Tr ần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.765099
    ,"Long":106.563247
    ,"Polyline":"[106.56744385,10.76313782] ; [106.56520081,10.76412010.06.56324768]"
    ,"Distance":"667.192933172638"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3290"
    ,"Station_Code":"HBC 282"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Công ty Th ịnh Uy"
    ,"Station_Address":"1A38/1, đường Trần Văn Giàu, Huyện Bình Chánh"
    ,"Lat":10.767576
    ,"Long":106.557931
    ,"Polyline":"[106.56324768,10.76509857] ; [106.55967712,10.76667976] ; [106.55792999,10.76757622]"
    ,"Distance":"676.509446132864"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3467"
    ,"Station_Code":"HBC 283"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Bà Lát"
    ,"Station_Address":"1A58/1, đường Trần Văn Giàu, Huyện Bình  Chánh"
    ,"Lat":10.770105
    ,"Long":106.552899
    ,"Polyline":"[106.55792999,10.76757622] ; [106.55458069,10.76920414] ; [106.55387115,10.76953602] ; [106.55320740,10.76986980] ; [106.55290222,10.77010536]"
    ,"Distance":"880.466191640153"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3470"
    ,"Station_Code":"HBC 284"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Bà Lát"
    ,"Station_Address":"2A/2, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam , Huyện Bình Chánh"
    ,"Lat":10.776661
    ,"Long":106.539992
    ,"Polyline":"[106.55290222,10.77010536] ; [106.54699707,10.77303982] ; [106.54406738,10.77455044] ; [106.54209900,10.77552986] ; [106.54039764,10.77646065] ; [106.53999329,10.77666092]"
    ,"Distance":"863.801615221365"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3469"
    ,"Station_Code":"HBC 285"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cầu Bình Minh"
    ,"Station_Address":"2A/27/1, đường Tỉnh lộ 10,Tân Tạo, Hồ Chí Minh, Việt Nam, Huyện  Bình Chánh"
    ,"Lat":10.779907
    ,"Long":106.533539
    ,"Polyline":"[106.53999329,10.77666092] ; [106.53853607,10.77732468] ; [106.53539276,10.77890015] ; [106.53418732,10.77952003] ; [106.53353882,10.77990723]"
    ,"Distance":"795.299830559891"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3472"
    ,"Station_Code":"HBC 286"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trạm y tế xã Phạm Văn Hai"
    ,"Station_Address":"Cty cây trồng TPHCMi, đường Tỉnh lộ 10 ,Tân Tạo, Hồ Chí Minh, Việt Nam, Huyện Bình Chánh"
    ,"Lat":10.78191
    ,"Long":106.529553
    ,"Polyline":"[106.53353882,10.77990723] ; [106.53298950,10.78017998] ; [106.53240967,10.78044033] ; [106.53140259,10.78089046] ; [106.53015137,10.78153515] ; [106.52955627,10.78190994]"
    ,"Distance":"485.867854937126"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3471"
    ,"Station_Code":"HBC 287"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Xã Lê Minh Xuân"
    ,"Station_Address":"2A/63, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.783601
    ,"Long":106.526039
    ,"Polyline":"[106.52955627,10.78190994] ; [106.52879333,10.78224182] ; [106.52684784,10.78318977] ; [106.52603912,10.78360081]"
    ,"Distance":"431.568960111917"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3474"
    ,"Station_Code":"HBC 288"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Kênh A"
    ,"Station_Address":"2A/94, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.784905
    ,"Long":106.523438
    ,"Polyline":"[106.52603149,10.78357983] ; [106.52342987,10.78489017]"
    ,"Distance":"319.421527716994"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3473"
    ,"Station_Code":"HBC 291"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Khách sạn Thu Loan"
    ,"Station_Address":"3A.11, đường Tỉnh  lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.786615
    ,"Long":106.520063
    ,"Polyline":"[106.52343750,10.78490543] ; [106.52266693,10.78528214] ; [106.52060699,10.78627300] ; [106.52006531,10.78661537]"
    ,"Distance":"413.250238472798"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3476"
    ,"Station_Code":"HBC 292"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Đa khoa  Sài Gòn"
    ,"Station_Address":"3A35/3, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.787743
    ,"Long":106.517746
    ,"Polyline":"[106.52006531,10.78661537] ; [106.51950836,10.78683662] ; [106.51773834,10.78773022] ; [106.51774597,10.78774261]"
    ,"Distance":"284.685152410729"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3475"
    ,"Station_Code":"HBC 293"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà thờ chợ Cầu Xáng"
    ,"Station_Address":"3A63, đường Tỉnh lộ 10 Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.78895
    ,"Long":106.51582
    ,"Polyline":"[106.51774597,10.78774261] ; [106.51731873,10.78793240] ; [106.51675415,10.78824329] ; [106.51601410,10.78872871] ; [106.51582336,10.78894997]"
    ,"Distance":"254.941519638122"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3894"
    ,"Station_Code":"HBC 305"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu Rau Răm"
    ,"Station_Address":"Trụ điện VT2D, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.788939
    ,"Long":106.513009
    ,"Polyline":"[106.51582336,10.78894997] ; [106.51582336,10.78894997] ; [106.51512146,10.78937149] ; [106.51492310,10.78948212] ; [106.51467896,10.78957176] ; [106.51439667,10.78968239] ; [106.51395416,10.78978252] ; [106.51360321,10.78983498] ; [106.51315308,10.79004097] ; [106.51287842,10.79020882] ; [106.51244354,10.79044628] ; [106.51252747,10.79033089] ; [106.51293182,10.79013538] ; [106.51319122,10.78994560] ; [106.51332855,10.78986168] ; [106.51329041,10.78975964] ; [106.51325989,10.78960991] ; [106.51318359,10.78925037] ; [106.51300812,10.78893948] ; [106.51300812,10.78893948]"
    ,"Distance":"434.894416050658"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3896"
    ,"Station_Code":"HBC 306"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"kênh 9"
    ,"Station_Address":"D5641/2, đường Vườn Thơm, Bình Chánh, Huyện Bình Ch ánh"
    ,"Lat":10.785235
    ,"Long":106.51236
    ,"Polyline":"[106.51300812,10.78893948] ; [106.51276398,10.78850174] ; [106.51240540,10.78808022] ; [106.51233673,10.78703022] ; [106.51233673,10.78600979] ; [106.51245880,10.78547668] ; [106.51235962,10.78523540]"
    ,"Distance":"200.561104521742"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3895"
    ,"Station_Code":"HBC 307"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Kênh 8"
    ,"Station_Address":"D5/595, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.783064
    ,"Long":106.511872
    ,"Polyline":"[106.51235962,10.78523540] ; [106.51235962,10.78523540] ; [106.51236725,10.78483963] ; [106.51204681,10.78361988] ; [106.51187134,10.78306389] ; [106.51187134,10.78306389]"
    ,"Distance":"247.118807159553"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3897"
    ,"Station_Code":"HBC 308"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Kênh 6"
    ,"Station_Address":"D1 /463 - cột điện 28p, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.777694
    ,"Long":106.510574
    ,"Polyline":"[106.51187134,10.78306389] ; [106.51161957,10.78191280] ; [106.51136780,10.78076077] ; [106.51094055,10.77890587] ; [106.51057434,10.77769375]"
    ,"Distance":"610.603841238645"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3898"
    ,"Station_Code":"HBC 309"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Kênh 5"
    ,"Station_Address":"C11/429, đường Vườn Thơm, Bình Chánh, Huy ện Bình Chánh"
    ,"Lat":10.77372
    ,"Long":106.508272
    ,"Polyline":"[106.51057434,10.77769375] ; [106.51059723,10.77772045] ; [106.51013947,10.77644444] ; [106.50964355,10.77540970] ; [106.50932312,10.77488995] ; [106.50885773,10.77423954] ; [106.50850677,10.77393150] ; [106.50827026,10.77371979]"
    ,"Distance":"500.717780651743"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3899"
    ,"Station_Code":"HBC 310"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Kênh 3"
    ,"Station_Address":"C9/361, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.76767
    ,"Long":106.500623
    ,"Polyline":"[106.50827026,10.77371979] ; [106.50695801,10.77258015] ; [106.50557709,10.77145386] ; [106.50357056,10.76989937] ; [106.50266266,10.76924419] ; [106.50179291,10.76850796] ; [106.50118256,10.76811886] ; [106.50057983,10.76772976] ; [106.50062561,10.76766968]"
    ,"Distance":"1072.94751986062"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3900"
    ,"Station_Code":"HBC 311"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Kênh 2"
    ,"Station_Address":"C8/319 , đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.764614
    ,"Long":106.496594
    ,"Polyline":"[106.50062561,10.76766968] ; [106.49946594,10.76663780] ; [106.49860382,10.76607323] ; [106.49734497,10.76514053] ; [106.49659729,10.76461411]"
    ,"Distance":"552.089778415222"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3901"
    ,"Station_Code":"HBC 312"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Bến đò Xã Lợi"
    ,"Station_Address":"C7/229, đường Vườn Thơm, Bình Chánh, Huy ện Bình Chánh"
    ,"Lat":10.761568
    ,"Long":106.492463
    ,"Polyline":"[106.49659729,10.76461411] ; [106.49661255,10.76467037] ; [106.49490356,10.76331997] ; [106.49314117,10.76204205] ; [106.49246216,10.76156807]"
    ,"Distance":"569.149477043394"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3902"
    ,"Station_Code":"HBC 313"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Đầm Lầy 1"
    ,"Station_Address":"C6/189, đường Vườn Thơm, Bình Chánh, Huyện  Bình Chánh"
    ,"Lat":10.75762
    ,"Long":106.487415
    ,"Polyline":"[106.49246216,10.76156807] ; [106.49147797,10.76070023] ; [106.49069977,10.76008034] ; [106.48927307,10.75899982] ; [106.48863983,10.75848961] ; [106.48741150,10.75761986]"
    ,"Distance":"706.393982497152"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3903"
    ,"Station_Code":"HBC 314"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Trạm y tế xã Bình Lợi"
    ,"Station_Address":"Trạm y tế xã Bình Lợi, đường Vườn Thơm , Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.754938
    ,"Long":106.483939
    ,"Polyline":"[106.48741150,10.75761986] ; [106.48697662,10.75716972] ; [106.48635864,10.75673008] ; [106.48490906,10.75566959] ; [106.48455811,10.75535965] ; [106.48394012,10.75493813]"
    ,"Distance":"484.294681455487"
  },
  {
     "Route_Id":"121"
    ,"Station_Id":"3904"
    ,"Station_Code":"HBC 315"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Bến Lê Minh  Xuân"
    ,"Station_Address":"C ột điện 106P, đường Vườn Thơm, Bình Chánh, Huyện Bình Chánh"
    ,"Lat":10.750524
    ,"Long":106.478111
    ,"Polyline":"[106.48394012,10.75493813] ; [106.48396301,10.75491047] ; [106.48097992,10.75267982] ; [106.48021698,10.75214005] ; [106.47888184,10.75109959] ; [106.47811127,10.75051975] ; [106.47811127,10.75052357]"
    ,"Distance":"804.207182576811"
  }]