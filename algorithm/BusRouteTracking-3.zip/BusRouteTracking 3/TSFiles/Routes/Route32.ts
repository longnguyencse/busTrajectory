export const Route32 =[
  {
     "Route_Id":"32"
    ,"Station_Id":"468"
    ,"Station_Code":"BX43"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"BÃI HẬU CẦN SỐ 1"
    ,"Station_Address":"BÃI HẬU CẦN SỐ 1, đường Phan Văn Trị, Qu ận Gò Vấp"
    ,"Lat":10.82361125946045
    ,"Long":106.69189453125
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"539"
    ,"Station_Code":"QGV 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Bãi hậu cần số 1"
    ,"Station_Address":"Đối diện 439, đường Phan Văn Trị, Qu ận Gò Vấp"
    ,"Lat":10.82389
    ,"Long":106.69202
    ,"Polyline":"[106.69189453,10.82361126] ; [106.69201660,10.82388973]"
    ,"Distance":"34"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"540"
    ,"Station_Code":"QGV 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"UBND Phường 5, Quận Gò Vấp"
    ,"Station_Address":"247, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.825513
    ,"Long":106.688259
    ,"Polyline":"[106.69201660,10.82388973] ; [106.69182587,10.82396317] ; [106.68931580,10.82628822] ; [106.68852997,10.82562351] ; [106.68825531,10.82551289]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"541"
    ,"Station_Code":"QGV 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trường Đại học Công nghiệp"
    ,"Station_Address":"145, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.822636
    ,"Long":106.685164
    ,"Polyline":"[106.68856049,10.82557011] ; [106.68711090,10.82468987] ; [106.68685913,10.82452011] ; [106.68669128,10.82435036] ; [106.68653870,10.82415962] ; [106.68620300,10.82373047] ; [106.68576813,10.82316971]"
    ,"Distance":"534"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"543"
    ,"Station_Code":"QGV 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"63, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.820866
    ,"Long":106.683758
    ,"Polyline":"[106.68516541,10.82263565] ; [106.68376160,10.82086563]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"60"
    ,"Station_Code":"QGV 187"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Nhà Tang Lễ"
    ,"Station_Address":"220 (175), đ ường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.822141
    ,"Long":106.682616
    ,"Polyline":"[106.68376160,10.82086563] ; [106.68383026,10.82080269] ; [106.68350983,10.82034397] ; [106.68256378,10.82211208] ; [106.68261719,10.82214069]"
    ,"Distance":"301"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"61"
    ,"Station_Code":"QGV 188"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"72 (45), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.825861
    ,"Long":106.680561
    ,"Polyline":"[106.68256378,10.82211208] ; [106.68050385,10.82584763]"
    ,"Distance":"486"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"219"
    ,"Station_Code":"QGV 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Siêu Thị Big C Gò Vấp"
    ,"Station_Address":"Đối diện Big C, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.825682
    ,"Long":106.679606
    ,"Polyline":"[106.68055725,10.82586098] ; [106.68050385,10.82584763] ; [106.68018341,10.82636642] ; [106.68019104,10.82649899] ; [106.68012238,10.82661438] ; [106.68002319,10.82667732] ; [106.67992401,10.82668304] ; [106.67981720,10.82663536] ; [106.67973328,10.82652473] ; [106.67977142,10.82637787] ; [106.67988586,10.82623005] ; [106.67971802,10.82579231] ; [106.67960358,10.82568169]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"222"
    ,"Station_Code":"QGV 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Xóm Cháy"
    ,"Station_Address":"629B, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.821751
    ,"Long":106.678764
    ,"Polyline":"[106.67971802,10.82579231] ; [106.67878723,10.82175350]"
    ,"Distance":"481"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"221"
    ,"Station_Code":"QGV 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh Viện  175"
    ,"Station_Address":"151, đường Nguyễn Ki ệm, Quận Gò Vấp"
    ,"Lat":10.818837
    ,"Long":106.678719
    ,"Polyline":"[106.67878723,10.82175350] ; [106.67871857,10.81883717]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"223"
    ,"Station_Code":"QGV 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chợ Tân Sơn Nhất"
    ,"Station_Address":"37 - 39, đường Nguyễn Kiệm, Quận Gò V ấp"
    ,"Lat":10.815118
    ,"Long":106.678619
    ,"Polyline":"[106.67871857,10.81883717] ; [106.67861938,10.81511784]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"224"
    ,"Station_Code":"QPN 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Đầu công viên Gia Định"
    ,"Station_Address":"Đối diện cây xanh số 7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.813568
    ,"Long":106.677868
    ,"Polyline":"[106.67861938,10.81511784] ; [106.67861938,10.81511784] ; [106.67866516,10.81450653] ; [106.67859650,10.81437492] ; [106.67855072,10.81425858] ; [106.67858124,10.81410027] ; [106.67800903,10.81354427] ; [106.67787170,10.81356812]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"225"
    ,"Station_Code":"QPN 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Cuối công viên Gia Định"
    ,"Station_Address":"Đối diện số 5, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.809764
    ,"Long":106.674591
    ,"Polyline":"[106.67800903,10.81354427] ; [106.67467499,10.80972481]"
    ,"Distance":"586"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1772"
    ,"Station_Code":"QPN 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường ĐH Kỹ Thuật Công nghệ"
    ,"Station_Address":"199, đường Phổ Quang, Quận Phú Nhuận"
    ,"Lat":10.808513
    ,"Long":106.671967
    ,"Polyline":"[106.67472839,10.80969048] ; [106.67362976,10.80832958] ; [106.67343903,10.80807972] ; [106.67292786,10.80793953] ; [106.67283630,10.80792046] ; [106.67273712,10.80795002] ; [106.67192841,10.80846024]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1773"
    ,"Station_Code":"QTB 104"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Cây xăng Quân đội"
    ,"Station_Address":"75, đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.807467
    ,"Long":106.668422
    ,"Polyline":"[106.67192841,10.80846024] ; [106.67153168,10.80862045] ; [106.67124176,10.80865002] ; [106.66889954,10.80873966] ; [106.66874695,10.80871010.06.66867065] ; [10.80860043,106.66847992]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1775"
    ,"Station_Code":"QTB 105"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trung tâm sát hạch lái xe"
    ,"Station_Address":"Công ty Waseco, đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.805359
    ,"Long":106.666555
    ,"Polyline":"[106.66847992,10.80747032] ; [106.66822052,10.80595970] ; [106.66816711,10.80591965] ; [106.66809082,10.80591011] ; [106.66696930,10.80607033] ; [106.66687012,10.80605984] ; [106.66680145,10.80597973] ; [106.66667938,10.80550957]"
    ,"Distance":"401"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1774"
    ,"Station_Code":"QTB 106"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Rạp Tân Sơn Nhất"
    ,"Station_Address":"Rạp Tân Sơn Nhất, đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.802321
    ,"Long":106.665756
    ,"Polyline":"[106.66667938,10.80550957] ; [106.66648865,10.80478954] ; [106.66636658,10.80438995] ; [106.66597748,10.80294037] ; [106.66580963,10.80230999]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"911"
    ,"Station_Code":"QTB 100"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Quán Vườn Dừa"
    ,"Station_Address":"12 (1A), đường Phan Đình Giót, Quận T ân Bình"
    ,"Lat":10.803641
    ,"Long":106.664909
    ,"Polyline":"[106.66580963,10.80230999] ; [106.66577148,10.80216980] ; [106.66570282,10.80210972] ; [106.66560364,10.80208969] ; [106.66548920,10.80210018] ; [106.66536713,10.80214024] ; [106.66512299,10.80274963] ; [106.66490173,10.80338001] ; [106.66484070,10.80362034]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"999"
    ,"Station_Code":"QTB 109"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Trần Quốc Hoàn"
    ,"Station_Address":"71, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.803644
    ,"Long":106.663925
    ,"Polyline":"[106.66490936,10.80364132] ; [106.66484070,10.80362034] ; [106.66460419,10.80466366] ; [106.66446686,10.80469990] ; [106.66433716,10.80466366] ; [106.66426086,10.80459023] ; [106.66416168,10.80416965] ; [106.66398621,10.80362034] ; [106.66392517,10.80364418]"
    ,"Distance":"288"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66398621,10.80362034] ; [106.66381073,10.80311012] ; [106.66355896,10.80266953] ; [106.66342163,10.80245972] ; [106.66262817,10.80158997] ; [106.66233826,10.80132008]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"600"
    ,"Station_Code":"QTB 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Lăng Cha  Cả"
    ,"Station_Address":"216, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.799836
    ,"Long":106.660385
    ,"Polyline":"[106.66233826,10.80132008] ; [106.66194153,10.80095959] ; [106.66171265,10.80080986] ; [106.66152191,10.80070019] ; [106.66134644,10.80066013] ; [106.66101074,10.80058956] ; [106.66092682,10.80056953] ; [106.66085052,10.80051041] ; [106.66081238,10.80045986] ; [106.66082001,10.80033970] ; [106.66074371,10.80012035] ; [106.66063690,10.80002975] ; [106.66040039,10.79981995]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"602"
    ,"Station_Code":"QTB 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Công an Quận Tân Bình"
    ,"Station_Address":"340H, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.796577
    ,"Long":106.656952
    ,"Polyline":"[106.66037750,10.79979992] ; [106.65936279,10.79885960] ; [106.65862274,10.79810047] ; [106.65837860,10.79788017] ; [106.65699005,10.79654026]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đường Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65699005,10.79654026] ; [106.65577698,10.79539013] ; [106.65515900,10.79603958]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62), đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65515900,10.79603958] ; [106.65464783,10.79654980] ; [106.65390778,10.79584026]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65386963,10.79587364] ; [106.65233612,10.79437923]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"605"
    ,"Station_Code":"QTB 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh viện  Thống Nhất"
    ,"Station_Address":"733-739, đường  Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.792122
    ,"Long":106.6528
    ,"Polyline":"[106.65233612,10.79437923] ; [106.65233612,10.79437923] ; [106.65177917,10.79372406] ; [106.65320587,10.79297543] ; [106.65287781,10.79208755] ; [106.65287781,10.79208755]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1639"
    ,"Station_Code":"QTB 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Cây xăng Lạc Long Quân"
    ,"Station_Address":"1103, đường Lạc Long Quân, Quận Tân B ình"
    ,"Lat":10.788628
    ,"Long":106.651776
    ,"Polyline":"[106.65287781,10.79208755] ; [106.65180969,10.78861809]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1640"
    ,"Station_Code":"QTB 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Trạm Công Thọ"
    ,"Station_Address":"933, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.784233
    ,"Long":106.650848
    ,"Polyline":"[106.65180969,10.78861809] ; [106.65084839,10.78423309]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1641"
    ,"Station_Code":"QTB 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Ni sư Huỳnh Liên"
    ,"Station_Address":"759, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.781511
    ,"Long":106.649994
    ,"Polyline":"[106.65093231,10.78421974] ; [106.65081024,10.78365040] ; [106.65071869,10.78339958] ; [106.65065002,10.78318977] ; [106.65057373,10.78291035] ; [106.65048218,10.78273010.06.65035248] ; [10.78244019,106.65020752] ; [10.78223038,106.65010071] ; [10.78190994,106.65007019]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1642"
    ,"Station_Code":"QTB 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Giác Lâm"
    ,"Station_Address":"656 (133), đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.777941
    ,"Long":106.649786
    ,"Polyline":"[106.64999390,10.78151131] ; [106.64977264,10.77806282]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1643"
    ,"Station_Code":"QTB 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã tư Lạc Long Quân"
    ,"Station_Address":"523-525 (176A), đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.77547
    ,"Long":106.648396
    ,"Polyline":"[106.64984131,10.77805996] ; [106.64983368,10.77762985] ; [106.64980316,10.77731991] ; [106.64974213,10.77709007] ; [106.64961243,10.77686024] ; [106.64930725,10.77653980] ; [106.64855957,10.77550983]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1644"
    ,"Station_Code":"Q11 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"501, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.774116
    ,"Long":106.647484
    ,"Polyline":"[106.64849854,10.77554321] ; [106.64756012,10.77420521]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1646"
    ,"Station_Code":"Q11 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Trạm Đăng  Kiểm"
    ,"Station_Address":"345F, đường Lạc Long  Quân, Quận 11"
    ,"Lat":10.770237
    ,"Long":106.644716
    ,"Polyline":"[106.64756012,10.77420521] ; [106.64463806,10.77026844]"
    ,"Distance":"565"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1645"
    ,"Station_Code":"Q11 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"Trường Lạc Long Quân, đường Lạc Long  Quân, Quận 11"
    ,"Lat":10.767818
    ,"Long":106.642989
    ,"Polyline":"[106.64463806,10.77026844] ; [106.64292908,10.76789188]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1572"
    ,"Station_Code":"Q11 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Cổng 1 Đầm Sen"
    ,"Station_Address":"281, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.765199
    ,"Long":106.642128
    ,"Polyline":"[106.64299011,10.76781845] ; [106.64292908,10.76789188] ; [106.64231110,10.76701736] ; [106.64219666,10.76684856] ; [106.64212799,10.76519871] ; [106.64212799,10.76519871]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1776"
    ,"Station_Code":"Q11 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"công an P10"
    ,"Station_Address":"569 (596), đường Minh Phụng, Quận 11"
    ,"Lat":10.763649
    ,"Long":106.644706
    ,"Polyline":"[106.64212799,10.76519871] ; [106.64212799,10.76519871] ; [106.64214325,10.76282215] ; [106.64459991,10.76407623] ; [106.64476013,10.76361561] ; [106.64470673,10.76364899]"
    ,"Distance":"629"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1777"
    ,"Station_Code":"Q11 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Đội Cung"
    ,"Station_Address":"461, đường Minh  Phụng, Quận 11"
    ,"Lat":10.761968
    ,"Long":106.644459
    ,"Polyline":"[106.64476013,10.76361561] ; [106.64448547,10.76198959]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1779"
    ,"Station_Code":"Q11 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"THCS Lê Anh Xuân"
    ,"Station_Address":"385, đường Minh Phụng, Quận 11"
    ,"Lat":10.759449
    ,"Long":106.644051
    ,"Polyline":"[106.64448547,10.76198959] ; [106.64395142,10.75953865]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1647"
    ,"Station_Code":"Q11 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Minh Phụng"
    ,"Station_Address":"341, đường Minh Phụng, Quận 11"
    ,"Lat":10.75736
    ,"Long":106.643654
    ,"Polyline":"[106.64395142,10.75953865] ; [106.64365387,10.75735950]"
    ,"Distance":"260"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1649"
    ,"Station_Code":"Q11 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"275, đường Minh Phụng, Quận 11"
    ,"Lat":10.755175
    ,"Long":106.643311
    ,"Polyline":"[106.64365387,10.75736046] ; [106.64365387,10.75735950] ; [106.64331055,10.75517464]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"109"
    ,"Station_Code":"Q6 061"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"201, đường Minh Phụng, Quận 6"
    ,"Lat":10.753264
    ,"Long":106.642929
    ,"Polyline":"[106.64331055,10.75517464] ; [106.64292908,10.75326443]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"108"
    ,"Station_Code":"Q6 062"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Chợ Minh Phụng"
    ,"Station_Address":"101, đường Minh Phụng, Quận 6"
    ,"Lat":10.750922
    ,"Long":106.642495
    ,"Polyline":"[106.64299774,10.75325012] ; [106.64263153,10.75131989]"
    ,"Distance":"273"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"111"
    ,"Station_Code":"Q6 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Cầu Hậu Giang"
    ,"Station_Address":"212A, đường Hậu Giang, Quận 6"
    ,"Lat":10.749736
    ,"Long":106.641503
    ,"Polyline":"[106.64249420,10.75092220] ; [106.64244843,10.75041962] ; [106.64234924,10.75008011] ; [106.64234161,10.74977970] ; [106.64199066,10.74973011] ; [106.64154053,10.74965000] ; [106.64153290,10.74964046] ; [106.64150238,10.74973583]"
    ,"Distance":"230"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"110"
    ,"Station_Code":"Q6 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Chợ Hoa"
    ,"Station_Address":"460-462, đường Hậu Giang, Quận 6"
    ,"Lat":10.748714
    ,"Long":106.637437
    ,"Polyline":"[106.64150238,10.74973583] ; [106.64127350,10.74967861] ; [106.63947296,10.74920940] ; [106.63743591,10.74871445]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"113"
    ,"Station_Code":"Q6 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Nguyễn Văn Luông"
    ,"Station_Address":"620-622, đường Hậu Giang, Quận 6"
    ,"Lat":10.748039
    ,"Long":106.634663
    ,"Polyline":"[106.63743591,10.74871445] ; [106.63639832,10.74842930] ; [106.63466644,10.74803925]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"112"
    ,"Station_Code":"Q6 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Bình Phú"
    ,"Station_Address":"730-732, đường Hậu Giang, Quận 6"
    ,"Lat":10.747697
    ,"Long":106.633312
    ,"Polyline":"[106.63466644,10.74803925] ; [106.63400269,10.74787045] ; [106.63330841,10.74769688]"
    ,"Distance":"154"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"114"
    ,"Station_Code":"Q6 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Đồng Quê"
    ,"Station_Address":"910, đường Hậu Giang, Quận 6"
    ,"Lat":10.746511
    ,"Long":106.628382
    ,"Polyline":"[106.63330841,10.74769688] ; [106.63233948,10.74740982] ; [106.63002014,10.74687481] ; [106.62955475,10.74680138]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"115"
    ,"Station_Code":"Q6 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Mũi Tàu Phú Lâm"
    ,"Station_Address":"1054, đường Hậu Giang, Quận 6"
    ,"Lat":10.745536
    ,"Long":106.624686
    ,"Polyline":"[106.62955475,10.74680138] ; [106.62748718,10.74627399] ; [106.62581635,10.74582577]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"117"
    ,"Station_Code":"QBT 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Công viên Phú Lâm"
    ,"Station_Address":"212-214, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744746
    ,"Long":106.622475
    ,"Polyline":"[106.62581635,10.74582577] ; [106.62452698,10.74542999] ; [106.62416077,10.74536037] ; [106.62393951,10.74545956] ; [106.62393951,10.74547958] ; [106.62393951,10.74551010.06.62393951] ; [10.74553013,106.62391663] ; [10.74557972,106.62390137] ; [10.74561977,106.62380219] ; [10.74567032,106.62374878] ; [10.74567032,106.62367249] ; [10.74563980,106.62364197] ; [10.74559975,106.62306976] ; [10.74522972,106.62247467]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"116"
    ,"Station_Code":"QBT 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Chợ An Lạc"
    ,"Station_Address":"358-360, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743092
    ,"Long":106.620399
    ,"Polyline":"[106.62247467,10.74474621] ; [106.62039948,10.74309158]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"4150"
    ,"Station_Code":"QBT 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"428, Kinh Dương Vương"
    ,"Station_Address":"428, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.741383
    ,"Long":106.618377
    ,"Polyline":"[106.62039948,10.74309158] ; [106.62039948,10.74309158] ; [106.62039948,10.74309158] ; [106.62023163,10.74286366] ; [106.61849213,10.74146748] ; [106.61837769,10.74138260]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":"[106.61842346,10.74136162] ; [106.61828613,10.74120903] ; [106.61775208,10.74074459] ; [106.61791992,10.74060822] ; [106.61809540,10.74043369] ; [106.61825562,10.74057102] ; [106.61831665,10.74070454]"
    ,"Distance":"197"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"725"
    ,"Station_Code":"BX 46"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Miền Tây"
    ,"Station_Address":"Bến xe Miền Tây,  đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.740705
    ,"Long":106.618317
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"4149"
    ,"Station_Code":"QBT 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"49-51 (317 ), Kinh Dương Vương"
    ,"Station_Address":"49-51  (317), đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.743396
    ,"Long":106.62136
    ,"Polyline":"[106.61831665,10.74070454] ; [106.62136078,10.74339581]"
    ,"Distance":"448"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"140"
    ,"Station_Code":"QBT 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Công viên  Phú Lâm"
    ,"Station_Address":"7, đường Kinh Dương Vương, Quận Bình Tân"
    ,"Lat":10.744919
    ,"Long":106.623162
    ,"Polyline":"[106.62136078,10.74339581] ; [106.62135315,10.74351692] ; [106.62223053,10.74420738] ; [106.62316132,10.74491882]"
    ,"Distance":"266"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"141"
    ,"Station_Code":"Q6 031"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Mũi Tàu Phú Lâm"
    ,"Station_Address":"1031C, đường  Hậu Giang, Quận 6"
    ,"Lat":10.745362
    ,"Long":106.624466
    ,"Polyline":"[106.62307739,10.74498463] ; [106.62307739,10.74498463] ; [106.62337494,10.74516201] ; [106.62369537,10.74530411] ; [106.62384796,10.74535656] ; [106.62395477,10.74539852] ; [106.62409210,10.74530888] ; [106.62468719,10.74546242] ; [106.62575531,10.74567795]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"143"
    ,"Station_Code":"Q6 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Đồng Quê"
    ,"Station_Address":"919 , đường Hậu Giang, Quận 6"
    ,"Lat":10.746311
    ,"Long":106.628092
    ,"Polyline":"[106.62575531,10.74567795] ; [106.62756348,10.74611568] ; [106.62989044,10.74680042] ; [106.62989807,10.74670601]"
    ,"Distance":"480"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"145"
    ,"Station_Code":"Q6 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bình Phú"
    ,"Station_Address":"733-735 , đường Hậu Giang, Quận 6"
    ,"Lat":10.747623
    ,"Long":106.633526
    ,"Polyline":"[106.62989807,10.74670601] ; [106.62989044,10.74680042] ; [106.63226318,10.74729633] ; [106.63352966,10.74762344]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"142"
    ,"Station_Code":"Q6 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Nguyễn Văn Luông"
    ,"Station_Address":"517-519, đường Hậu Giang, Quận 6"
    ,"Lat":10.74826
    ,"Long":106.636192
    ,"Polyline":"[106.63352966,10.74762344] ; [106.63442993,10.74782276] ; [106.63555145,10.74812889] ; [106.63617706,10.74831963] ; [106.63619232,10.74825954]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"144"
    ,"Station_Code":"Q6 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Chợ Hoa"
    ,"Station_Address":"411, đường Hậu Giang, Quận 6"
    ,"Lat":10.748814
    ,"Long":106.638359
    ,"Polyline":"[106.63619232,10.74825954] ; [106.63617706,10.74831963] ; [106.63835907,10.74881363]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"146"
    ,"Station_Code":"Q6 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ Minh Phụng"
    ,"Station_Address":"122, đường Minh Phụng, Quận 6"
    ,"Lat":10.750869
    ,"Long":106.642619
    ,"Polyline":"[106.63844299,10.74882030] ; [106.63844299,10.74882030] ; [106.64231110,10.74977303] ; [106.64261627,10.75089359] ; [106.64262390,10.75088978]"
    ,"Distance":"578"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"147"
    ,"Station_Code":"Q6 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"242, đường Minh Phụng, Quận 6"
    ,"Lat":10.753468
    ,"Long":106.643096
    ,"Polyline":"[106.64261627,10.75089359] ; [106.64310455,10.75347042]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1675"
    ,"Station_Code":"Q11 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Cây Gõ"
    ,"Station_Address":"248-250, đường  Minh Phụng, Quận 11"
    ,"Lat":10.755328
    ,"Long":106.643486
    ,"Polyline":"[106.64310455,10.75347042] ; [106.64348602,10.75532818]"
    ,"Distance":"212"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1678"
    ,"Station_Code":"Q11 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"UBND P2, Q11"
    ,"Station_Address":"328, đường Minh Phụng, Quận 11"
    ,"Lat":10.757536
    ,"Long":106.643874
    ,"Polyline":"[106.64348602,10.75532818] ; [106.64387512,10.75753593]"
    ,"Distance":"250"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1677"
    ,"Station_Code":"Q11 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"THCS Lê Anh Xuân"
    ,"Station_Address":"382, đường Minh Phụng, Quận 11"
    ,"Lat":10.759729
    ,"Long":106.64426
    ,"Polyline":"[106.64379120,10.75764179] ; [106.64420319,10.75973415]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1680"
    ,"Station_Code":"Q11 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đội Cung"
    ,"Station_Address":"470, đường Minh  Phụng, Quận 11"
    ,"Lat":10.761849
    ,"Long":106.644592
    ,"Polyline":"[106.64420319,10.75973415] ; [106.64459229,10.76184940]"
    ,"Distance":"246"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1679"
    ,"Station_Code":"Q11 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"công an P10"
    ,"Station_Address":"618, đường Minh Phụng, Quận 11"
    ,"Lat":10.763865
    ,"Long":106.644928
    ,"Polyline":"[106.64459229,10.76184940] ; [106.64492798,10.76386547]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1603"
    ,"Station_Code":"Q11 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Trường Phùng Hưng"
    ,"Station_Address":"240, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.763818
    ,"Long":106.642259
    ,"Polyline":"[106.64492798,10.76386547] ; [106.64492798,10.76386547] ; [106.64484406,10.76427650] ; [106.64219666,10.76273727] ; [106.64229584,10.76383114] ; [106.64225769,10.76381779]"
    ,"Distance":"510"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1682"
    ,"Station_Code":"Q11 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"310, đường L ạc Long Quân, Quận 11"
    ,"Lat":10.767508
    ,"Long":106.64296
    ,"Polyline":"[106.64225769,10.76381779] ; [106.64217377,10.76379204] ; [106.64228821,10.76651096] ; [106.64234161,10.76665306] ; [106.64253235,10.76673222] ; [106.64251709,10.76685333] ; [106.64247131,10.76695919] ; [106.64292145,10.76753330] ; [106.64295959,10.76750755]"
    ,"Distance":"464"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1681"
    ,"Station_Code":"Q11 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trạm Đăng Kiểm"
    ,"Station_Address":"432, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.770437
    ,"Long":106.645073
    ,"Polyline":"[106.64295959,10.76750755] ; [106.64507294,10.77043724]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1684"
    ,"Station_Code":"Q11 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"612, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.773831
    ,"Long":106.647461
    ,"Polyline":"[106.64507294,10.77043724] ; [106.64673615,10.77298260] ; [106.64746094,10.77383137]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1683"
    ,"Station_Code":"QTB 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Ngã Tư Âu Cơ"
    ,"Station_Address":"632, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.775206
    ,"Long":106.648471
    ,"Polyline":"[106.64746094,10.77383137] ; [106.64842224,10.77523232]"
    ,"Distance":"188"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1686"
    ,"Station_Code":"QTB 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Chùa Giác Lâm"
    ,"Station_Address":"794, đường Lạc Long  Quân, Quận Tân Bình"
    ,"Lat":10.77821
    ,"Long":106.64992
    ,"Polyline":"[106.64842224,10.77523232] ; [106.64852142,10.77549076] ; [106.64949799,10.77670288] ; [106.64978027,10.77713490] ; [106.64989471,10.77764606]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1685"
    ,"Station_Code":"QTB 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ni sư Huỳnh Liên"
    ,"Station_Address":"930, đường L ạc Long Quân, Quận Tân Bình"
    ,"Lat":10.781066
    ,"Long":106.650093
    ,"Polyline":"[106.64989471,10.77764606] ; [106.64996338,10.77940083] ; [106.65009308,10.78106594]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1688"
    ,"Station_Code":"QTB 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trạm Công Thọ"
    ,"Station_Address":"1100, đường Lạc Long Quân, Quận Tân Bình"
    ,"Lat":10.784028
    ,"Long":106.650963
    ,"Polyline":"[106.65009308,10.78106594] ; [106.65009308,10.78170967] ; [106.65014648,10.78213120] ; [106.65059662,10.78302670] ; [106.65096283,10.78402805]"
    ,"Distance":"349"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"1687"
    ,"Station_Code":"QTB 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Cây xăng Lạc Long Quân"
    ,"Station_Address":"1274, đường Lạc Long Quân , Quận Tân Bình"
    ,"Lat":10.788412
    ,"Long":106.651851
    ,"Polyline":"[106.65096283,10.78402805] ; [106.65107727,10.78548241] ; [106.65134430,10.78668404] ; [106.65167999,10.78771400]"
    ,"Distance":"420"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"553"
    ,"Station_Code":"QTB 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"Bệnh viện Thống Nhất, đường Lý Thường  Kiệt, Quận Tân Bình"
    ,"Lat":10.792101
    ,"Long":106.653074
    ,"Polyline":"[106.65161133,10.78773022] ; [106.65210724,10.78944016] ; [106.65235901,10.79039955] ; [106.65261841,10.79131985] ; [106.65270996,10.79156017] ; [106.65299225,10.79216003]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh vi ện Tân Bình), đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65303040,10.79214001] ; [106.65328979,10.79261017] ; [106.65337372,10.79288006] ; [106.65367889,10.79327965] ; [106.65387726,10.79349995] ; [106.65458679,10.79424000] ; [106.65502167,10.79463959]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"555"
    ,"Station_Code":"QTB 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Nhà hàng  Đông Phương"
    ,"Station_Address":"431, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.798622
    ,"Long":106.659286
    ,"Polyline":"[106.65502167,10.79463959] ; [106.65596771,10.79557991] ; [106.65693665,10.79648972] ; [106.65862274,10.79810047] ; [106.65920258,10.79870033]"
    ,"Distance":"663"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65920258,10.79870033] ; [106.66005707,10.79953098] ; [106.66081238,10.80016327] ; [106.66117859,10.80035305] ; [106.66164398,10.80065346] ; [106.66330719,10.80058002]"
    ,"Distance":"549"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80050278] ; [106.66635132,10.80023193]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2 (Sân vận động Quân khu  7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66635132,10.80023193] ; [106.66635132,10.80023193] ; [106.66675568,10.80025768] ; [106.66690826,10.80030060] ; [106.66702271,10.80041599] ; [106.66696930,10.80063725] ; [106.66662598,10.80095100] ; [106.66662598,10.80095100]"
    ,"Distance":"156"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"455"
    ,"Station_Code":"QTB 101"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Rạp Tân S ơn Nhất"
    ,"Station_Address":"2B (Hông sân vận động Quân Khu 7), đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.80244
    ,"Long":106.665924
    ,"Polyline":"[106.66658783,10.80090046] ; [106.66603851,10.80126953] ; [106.66568756,10.80175972] ; [106.66584778,10.80245972]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"457"
    ,"Station_Code":"QTB 102"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Trung tâm sát hạch lái xe"
    ,"Station_Address":"66 (Công ty Xe khách Sài Gòn), đường Phổ Quang, Qu ận Tân Bình"
    ,"Lat":10.805417
    ,"Long":106.6667
    ,"Polyline":"[106.66592407,10.80243969] ; [106.66674805,10.80549812]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"454"
    ,"Station_Code":"QTB 103"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Cây xăng Quân đội"
    ,"Station_Address":"96-100, đường Phổ Quang, Quận Tân Bình"
    ,"Lat":10.807221
    ,"Long":106.668495
    ,"Polyline":"[106.66667938,10.80552006] ; [106.66683197,10.80603027] ; [106.66687012,10.80605984] ; [106.66696930,10.80607033] ; [106.66816711,10.80591965] ; [106.66822052,10.80595970] ; [106.66828156,10.80632973] ; [106.66841888,10.80714989] ; [106.66844177,10.80723000]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"456"
    ,"Station_Code":"QPN 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Trường Đại học Kỹ thuật Công nghệ"
    ,"Station_Address":"140, đường Phổ Quang, Quận  Phú Nhuận"
    ,"Lat":10.808344
    ,"Long":106.671997
    ,"Polyline":"[106.66844177,10.80723000] ; [106.66867065,10.80860043] ; [106.66874695,10.80871010.06.66889954] ; [10.80873966,106.67124176] ; [10.80865002,106.67153168] ; [10.80862045,106.67176056] ; [10.80854034,106.67202759]"
    ,"Distance":"547"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"459"
    ,"Station_Code":"QPN 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cuối công viên Gia Định"
    ,"Station_Address":"7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.809727
    ,"Long":106.674929
    ,"Polyline":"[106.67202759,10.80840015] ; [106.67273712,10.80795002] ; [106.67283630,10.80792046] ; [106.67292786,10.80793953] ; [106.67343903,10.80807972] ; [106.67362976,10.80832958] ; [106.67418671,10.80904007] ; [106.67447662,10.80939007]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"458"
    ,"Station_Code":"QPN 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Ngã ba Đặng Văn Sâm"
    ,"Station_Address":"Ngã ba Đặng Văn Sâm, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.811382
    ,"Long":106.676399
    ,"Polyline":"[106.67492676,10.80972672] ; [106.67628479,10.81143665] ; [106.67639923,10.81138229]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"461"
    ,"Station_Code":"QPN 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Đầu công viên Gia Định"
    ,"Station_Address":"Cây xanh số 7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.8135
    ,"Long":106.678222
    ,"Polyline":"[106.67628479,10.81143665] ; [106.67814636,10.81352329]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"56"
    ,"Station_Code":"QGV 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm đầu Nguyễn Thái Sơn"
    ,"Station_Address":"36 , đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.815178
    ,"Long":106.679596
    ,"Polyline":"[106.67814636,10.81352329] ; [106.67809296,10.81357002] ; [106.67826843,10.81377029] ; [106.67861176,10.81402683] ; [106.67877960,10.81393147] ; [106.67899323,10.81394768] ; [106.67916870,10.81405354] ; [106.67924500,10.81423759] ; [106.67915344,10.81444263] ; [106.67897797,10.81454849] ; [106.67917633,10.81478977] ; [106.67952728,10.81523037] ; [106.67959595,10.81517792]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"59"
    ,"Station_Code":"QGV 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Bệnh Viện  175"
    ,"Station_Address":"90, đường Nguyễn Th ái Sơn, Quận Gò Vấp"
    ,"Lat":10.81674
    ,"Long":106.680847
    ,"Polyline":"[106.67959595,10.81517792] ; [106.68084717,10.81674004]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"57"
    ,"Station_Code":"QGV 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"182 (148B), đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.819923
    ,"Long":106.683378
    ,"Polyline":"[106.68076324,10.81680012] ; [106.68226624,10.81875992] ; [106.68289185,10.81952953] ; [106.68334961,10.82013035]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"460"
    ,"Station_Code":"QGV 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"246  (180), đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.820508
    ,"Long":106.683828
    ,"Polyline":"[106.68338013,10.81992340] ; [106.68383026,10.82050800]"
    ,"Distance":"82"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"463"
    ,"Station_Code":"QGV 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trường Đ ại học Công nghiệp"
    ,"Station_Address":"320,  đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.822789
    ,"Long":106.685636
    ,"Polyline":"[106.68407440,10.82090855] ; [106.68536377,10.82256794]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"462"
    ,"Station_Code":"QGV 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"UBND Phư ờng 5, Quận Gò Vấp"
    ,"Station_Address":"396, đường Nguyễn Thái Sơn, Quận Gò V ấp"
    ,"Lat":10.82507
    ,"Long":106.687881
    ,"Polyline":"[106.68563843,10.82278919] ; [106.68580627,10.82322025] ; [106.68640137,10.82398033] ; [106.68669128,10.82435036] ; [106.68685913,10.82452011] ; [106.68705750,10.82466030] ; [106.68724060,10.82476044] ; [106.68784332,10.82513046] ; [106.68788147,10.82507038]"
    ,"Distance":"372"
  },
  {
     "Route_Id":"32"
    ,"Station_Id":"468"
    ,"Station_Code":"BX43"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"BÃI HẬU CẦN SỐ 1"
    ,"Station_Address":"BÃI HẬU CẦN SỐ 1, đường Phan Văn Trị, Quận Gò Vấp"
    ,"Lat":10.82361125946045
    ,"Long":106.69189453125
    ,"Polyline":"[106.68788147,10.82507038] ; [106.69189453,10.82361126]"
    ,"Distance":"468"
  }]