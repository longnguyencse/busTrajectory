export const Route12 =[

  {
     "Route_Id":"12"
    ,"Station_Id":"4761"
    ,"Station_Code":"BX_100"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Tân Nhựt"
    ,"Station_Address":"B14/290, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.706232
    ,"Long":106.563231
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"2238"
    ,"Station_Code":"HBC 445"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Tân Nhựt"
    ,"Station_Address":"Đối diện B15/307A, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.706048
    ,"Long":106.563563
    ,"Polyline":"[106.56323242,10.70623207] ; [106.56326294,10.70625305] ; [106.56356049,10.70604801]"
    ,"Distance":"44"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"2239"
    ,"Station_Code":"HBC 446"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Ngã 3 Trường học"
    ,"Station_Address":"Đối diện E9/193C, đường Th ế Lữ, Huyện Bình Chánh"
    ,"Lat":10.703923
    ,"Long":106.568112
    ,"Polyline":"[106.56356049,10.70604801] ; [106.56444550,10.70553112] ; [106.56811523,10.70392323]"
    ,"Distance":"552"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3723"
    ,"Station_Code":"HBC 447"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Tân Tạo - Chợ Đệm"
    ,"Station_Address":"Cột điện 21T, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.702305
    ,"Long":106.572044
    ,"Polyline":"[106.56811523,10.70392323] ; [106.56873322,10.70369148] ; [106.57038879,10.70296955] ; [106.57118988,10.70261097] ; [106.57204437,10.70230484]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3725"
    ,"Station_Code":"HBC 448"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Đình Phục Đức"
    ,"Station_Address":"Đình Phục Đức (cột điện 18T), đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.70036
    ,"Long":106.575456
    ,"Polyline":"[106.57204437,10.70230484] ; [106.57226563,10.70224190] ; [106.57250214,10.70217896] ; [106.57266235,10.70212078] ; [106.57405853,10.70121956] ; [106.57491302,10.70068169] ; [106.57545471,10.70036030]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3727"
    ,"Station_Code":"HBC 449"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Cầu Chợ Đệm"
    ,"Station_Address":"9AT, đường Thế Lữ, Huyện B ình Chánh"
    ,"Lat":10.699169
    ,"Long":106.577446
    ,"Polyline":"[106.57545471,10.70036030] ; [106.57695770,10.69974327] ; [106.57711792,10.69965363] ; [106.57744598,10.69916916]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3728"
    ,"Station_Code":"HBC 450"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Trường Văn"
    ,"Station_Address":"Cột điện 2AT, đư ờng Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.69696
    ,"Long":106.578884
    ,"Polyline":"[106.57744598,10.69916916] ; [106.57814789,10.69806194] ; [106.57888031,10.69696045]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7035"
    ,"Station_Code":"HBC_6"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Chợ Đệm"
    ,"Station_Address":"D13 /3, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.6955
    ,"Long":106.580526
    ,"Polyline":"[106.57888031,10.69696045] ; [106.57968140,10.69580078] ; [106.57980347,10.69571114] ; [106.57995605,10.69575310.06.58010864] ; [10.69568443,106.58017731] ; [10.69554234,106.58034515] ; [10.69545841,106.58052826]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7036"
    ,"Station_Code":"HBC_7"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường Tân Ki ên"
    ,"Station_Address":"D10/16, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.697888
    ,"Long":106.586523
    ,"Polyline":"[106.58052826,10.69550037] ; [106.58213806,10.69599056] ; [106.58448792,10.69706535] ; [106.58652496,10.69788837]"
    ,"Distance":"709"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7037"
    ,"Station_Code":"HBC_8"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm y tế Tân Kiên"
    ,"Station_Address":"Trạm y tế Tân Kiên, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.700945
    ,"Long":106.591882
    ,"Polyline":"[106.58652496,10.69788837] ; [106.58815002,10.69859982] ; [106.58985138,10.69923782] ; [106.59043884,10.69957447] ; [106.59172821,10.70091343] ; [106.59188080,10.70094490]"
    ,"Distance":"691"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7038"
    ,"Station_Code":"HBC_9"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Thiên Hoàng Long"
    ,"Station_Address":"D3/1, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.702716
    ,"Long":106.59517
    ,"Polyline":"[106.59188080,10.70094490] ; [106.59313965,10.70148849] ; [106.59444427,10.70196819] ; [106.59516907,10.70271587]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7039"
    ,"Station_Code":"HBC_10"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Quốc lộ 1A"
    ,"Station_Address":"C6/13, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.705547
    ,"Long":106.597633
    ,"Polyline":"[106.59516907,10.70271587] ; [106.59640503,10.70441341] ; [106.59763336,10.70554733]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"705"
    ,"Station_Code":"HBC 390"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C14/17, đường Qu ốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.70658
    ,"Long":106.598266
    ,"Polyline":"[106.59763336,10.70554733] ; [106.59791565,10.70587921] ; [106.59812927,10.70596886] ; [106.59826660,10.70658016]"
    ,"Distance":"143"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"707"
    ,"Station_Code":"HBC 391"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu đi bộ Số 2"
    ,"Station_Address":"C12/3, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.713538
    ,"Long":106.599564
    ,"Polyline":"[106.59826660,10.70658016] ; [106.59890747,10.71024323] ; [106.59925842,10.71139240] ; [106.59956360,10.71353817]"
    ,"Distance":"789"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"706"
    ,"Station_Code":"HBC 392"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Ngã tư An  Lạc"
    ,"Station_Address":"591 cầu đi bộ, đường  Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.71359
    ,"Long":106.599564
    ,"Polyline":"[106.59956360,10.71353817] ; [106.59956360,10.71358967]"
    ,"Distance":"6"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7050"
    ,"Station_Code":"QBT 280"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Cầu Nước Lên"
    ,"Station_Address":"8, đường Võ Văn Kiệt, Quận Bình Tân"
    ,"Lat":10.719552
    ,"Long":106.606822
    ,"Polyline":"[106.59956360,10.71358967] ; [106.59962463,10.71399117] ; [106.59976196,10.71434402] ; [106.59993744,10.71473980] ; [106.60009003,10.71496105] ; [106.60028076,10.71516132] ; [106.60096741,10.71562481] ; [106.60118866,10.71585178] ; [106.60134125,10.71613598] ; [106.60176086,10.71680546] ; [106.60200500,10.71710587] ; [106.60223389,10.71731663] ; [106.60275269,10.71763897] ; [106.60681915,10.71955204]"
    ,"Distance":"1083"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1801"
    ,"Station_Code":"QBT 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Khu dân cư Hương lộ 5"
    ,"Station_Address":"297, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.72068
    ,"Long":106.611877
    ,"Polyline":"[106.60681915,10.71955204] ; [106.61129761,10.72184944] ; [106.61187744,10.72068024]"
    ,"Distance":"697"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1800"
    ,"Station_Code":"QBT 048"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhựa Long Thành"
    ,"Station_Address":"215, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.718161
    ,"Long":106.613464
    ,"Polyline":"[106.61187744,10.72068024] ; [106.61346436,10.71816063]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1803"
    ,"Station_Code":"Q8 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chùa Viên Giác"
    ,"Station_Address":"3, đường Hồ Học Lãm, Quận 8"
    ,"Lat":10.712624
    ,"Long":106.616989
    ,"Polyline":"[106.61346436,10.71816063] ; [106.61698914,10.71262360]"
    ,"Distance":"727"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"805"
    ,"Station_Code":"Q8 075"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Bến Phú Định"
    ,"Station_Address":"10, đường An Dương Vương, Quận 8"
    ,"Lat":10.71144
    ,"Long":106.618795
    ,"Polyline":"[106.61698914,10.71262360] ; [106.61725616,10.71234131] ; [106.61759186,10.71190357] ; [106.61803436,10.71115494] ; [106.61824036,10.71084404] ; [106.61834717,10.71073914] ; [106.61849213,10.71069145] ; [106.61871338,10.71068573] ; [106.61879730,10.71144009]"
    ,"Distance":"383"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"797"
    ,"Station_Code":"Q8 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"54A An Dương Vương"
    ,"Station_Address":"54A, đường An Dương Vương, Quận 8"
    ,"Lat":10.713332
    ,"Long":106.618956
    ,"Polyline":"[106.61879730,10.71144009] ; [106.61895752,10.71333218]"
    ,"Distance":"211"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"807"
    ,"Station_Code":"Q8 077"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"22/2 An Dương Vương"
    ,"Station_Address":"22/2, đường An Dương Vương, Quận 8"
    ,"Lat":10.715166
    ,"Long":106.619139
    ,"Polyline":"[106.61895752,10.71333218] ; [106.61914063,10.71516609]"
    ,"Distance":"205"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"799"
    ,"Station_Code":"Q8 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Chợ Kiến  Đức"
    ,"Station_Address":"174, đường An Dương  Vương, Quận 8"
    ,"Lat":10.716711
    ,"Long":106.619241
    ,"Polyline":"[106.61914063,10.71516609] ; [106.61923981,10.71671104]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"801"
    ,"Station_Code":"Q8 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trương Đình Hội"
    ,"Station_Address":"62, đường An Dương Vương, Quận 8"
    ,"Lat":10.719183
    ,"Long":106.619503
    ,"Polyline":"[106.61923981,10.71671104] ; [106.61949921,10.71918297]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"803"
    ,"Station_Code":"Q8 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chung cư Lê Thành"
    ,"Station_Address":"76, đường An Dương Vương, Quận 8"
    ,"Lat":10.723747
    ,"Long":106.619992
    ,"Polyline":"[106.61949921,10.71918297] ; [106.61999512,10.72374725]"
    ,"Distance":"511"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7044"
    ,"Station_Code":"Q6 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Đường 38"
    ,"Station_Address":"322, đường An Dương Vương, Quận 6"
    ,"Lat":10.73811
    ,"Long":106.622095
    ,"Polyline":"[106.61999512,10.72374725] ; [106.62130737,10.73494720] ; [106.62171173,10.73661804] ; [106.62209320,10.73810959]"
    ,"Distance":"1618"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"806"
    ,"Station_Code":"Q6 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Lý Chiêu Hoàng"
    ,"Station_Address":"369/F31, đường An Dương Vương, Quận 6"
    ,"Lat":10.740239
    ,"Long":106.623715
    ,"Polyline":"[106.62209320,10.73810959] ; [106.62213898,10.73846245] ; [106.62223053,10.73862076] ; [106.62239838,10.73872089] ; [106.62368011,10.73888493] ; [106.62371826,10.74023914]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"809"
    ,"Station_Code":"Q6 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đường số 23"
    ,"Station_Address":"199, đường Đường Số 26, Quận 6"
    ,"Lat":10.741862
    ,"Long":106.626129
    ,"Polyline":"[106.62371826,10.74023914] ; [106.62371826,10.74180984] ; [106.62612915,10.74186230]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"811"
    ,"Station_Code":"Q6 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Metro Bình  Phú"
    ,"Station_Address":"33, đường Đường Số 26, Quận 6"
    ,"Lat":10.741578
    ,"Long":106.63086
    ,"Polyline":"[106.62612915,10.74186230] ; [106.62818146,10.74198914] ; [106.63085938,10.74157810]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"4353"
    ,"Station_Code":"Q6 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Phạm Văn Chí"
    ,"Station_Address":"153, đường Nguyễn Văn Luông, Quận 6"
    ,"Lat":10.739275
    ,"Long":106.633413
    ,"Polyline":"[106.63085938,10.74157810.06.63150024] ; [10.74151421,106.63230896] ; [10.74139309,106.63358307] ; [10.74100876,106.63341522]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1595"
    ,"Station_Code":"Q6 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Phạm Văn Chí"
    ,"Station_Address":"713-715, đường Ph ạm Văn Chí, Quận 6"
    ,"Lat":10.738384
    ,"Long":106.635447
    ,"Polyline":"[106.63341522,10.73927498] ; [106.63354492,10.73836231] ; [106.63365173,10.73741913] ; [106.63544464,10.73838425]"
    ,"Distance":"432"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7043"
    ,"Station_Code":"Q6 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Văn Thân"
    ,"Station_Address":"118B , đường Văn Thân, Quận 6"
    ,"Lat":10.740202
    ,"Long":106.636246
    ,"Polyline":"[106.63544464,10.73838425] ; [106.63607025,10.73876286] ; [106.63542938,10.73974895] ; [106.63624573,10.74020195]"
    ,"Distance":"313"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7041"
    ,"Station_Code":"Q6 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bình Tiên"
    ,"Station_Address":"22-24, đường Văn Thân, Quận 6"
    ,"Lat":10.743607
    ,"Long":106.642415
    ,"Polyline":"[106.63624573,10.74020195] ; [106.64241791,10.74360657]"
    ,"Distance":"774"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"808"
    ,"Station_Code":"Q6 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Bữu Bình"
    ,"Station_Address":"243-244, đường Bãi Sậy, Quận 6"
    ,"Lat":10.747059
    ,"Long":106.644244
    ,"Polyline":"[106.64241791,10.74360657] ; [106.64320374,10.74412346] ; [106.64285278,10.74685383] ; [106.64424133,10.74705887]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"810"
    ,"Station_Code":"Q6 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Công viên Phạm Đình Hổ"
    ,"Station_Address":"120, đường Bãi Sậy, Quận 6"
    ,"Lat":10.747728
    ,"Long":106.648686
    ,"Polyline":"[106.64424133,10.74705887] ; [106.64868927,10.74772835]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"621"
    ,"Station_Code":"Q6 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường Võ Văn Tần"
    ,"Station_Address":"96-98, đường Phạm Đình Hổ, Quận 6"
    ,"Lat":10.752271
    ,"Long":106.64975
    ,"Polyline":"[106.64868927,10.74772835] ; [106.64948273,10.74786568] ; [106.64941406,10.74832344] ; [106.64939117,10.74860859] ; [106.64946747,10.74968338] ; [106.64957428,10.75071621] ; [106.64974976,10.75227070]"
    ,"Distance":"581"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA  HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.64974976,10.75227070] ; [106.64977264,10.75348377] ; [106.65077209,10.75334072] ; [106.65181732,10.75299835] ; [106.65178680,10.75145435] ; [106.65106964,10.75118542]"
    ,"Distance":"622"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"4418"
    ,"Station_Code":"Q6 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Phan Văn Khỏe"
    ,"Station_Address":"1D, đường Phạm Đình Hổ, Quận 6"
    ,"Lat":10.748803
    ,"Long":106.649303
    ,"Polyline":"[106.65106964,10.75118542] ; [106.65096283,10.75118542] ; [106.65078735,10.75101662] ; [106.65012360,10.75107479] ; [106.64952087,10.75074768] ; [106.64929962,10.74880314]"
    ,"Distance":"404"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"753"
    ,"Station_Code":"Q6 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Công viên Phạm Đình Hổ"
    ,"Station_Address":"164, đường Bãi Sậy, Quận 6"
    ,"Lat":10.747702
    ,"Long":106.647801
    ,"Polyline":"[106.64929962,10.74880314] ; [106.64933014,10.74830246] ; [106.64941406,10.74791241] ; [106.64780426,10.74770164]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"755"
    ,"Station_Code":"Q6 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Minh Phụng"
    ,"Station_Address":"306B-308B, đường Bãi Sậy, Quận 6"
    ,"Lat":10.747206
    ,"Long":106.644534
    ,"Polyline":"[106.64780426,10.74770164] ; [106.64453125,10.74720573]"
    ,"Distance":"362"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7040"
    ,"Station_Code":"Q6 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Văn Thân"
    ,"Station_Address":"17 , đường Văn Thân, Quận 6"
    ,"Lat":10.743718
    ,"Long":106.642393
    ,"Polyline":"[106.64453125,10.74720573] ; [106.64273834,10.74685860] ; [106.64287567,10.74602032] ; [106.64306641,10.74414444] ; [106.64265442,10.74383831] ; [106.64239502,10.74371815]"
    ,"Distance":"593"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7042"
    ,"Station_Code":"Q6 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bà Lài"
    ,"Station_Address":"115B, đường Văn Thân, Quận 6"
    ,"Lat":10.740371
    ,"Long":106.636321
    ,"Polyline":"[106.64239502,10.74371815] ; [106.63632202,10.74037075]"
    ,"Distance":"761"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"757"
    ,"Station_Code":"Q6 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Cầu Phạm Văn Chí"
    ,"Station_Address":"Đối diện 693, đường Phạm Văn Chí, Qu ận 6"
    ,"Lat":10.738521
    ,"Long":106.635484
    ,"Polyline":"[106.63632202,10.74037075] ; [106.63535309,10.73977566] ; [106.63597107,10.73877907] ; [106.63548279,10.73852062]"
    ,"Distance":"316"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"4354"
    ,"Station_Code":"Q6 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Phạm Văn Chí"
    ,"Station_Address":"Đối diện 127, đường Nguyễn V ăn Luông, Quận 6"
    ,"Lat":10.739016
    ,"Long":106.633564
    ,"Polyline":"[106.63548279,10.73852062] ; [106.63373566,10.73754025] ; [106.63356781,10.73901558]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"759"
    ,"Station_Code":"Q6 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Metro Bình Phú"
    ,"Station_Address":"Metro Bình Phú, đường Đường Số 26, Quận 6"
    ,"Lat":10.741673
    ,"Long":106.630994
    ,"Polyline":"[106.63356781,10.73901558] ; [106.63352966,10.73930645] ; [106.63366699,10.74105549] ; [106.63237762,10.74143505] ; [106.63207245,10.74150372] ; [106.63099670,10.74167347]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"762"
    ,"Station_Code":"Q6 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Đường số 23"
    ,"Station_Address":"102, đường Đường Số 26, Quận 6"
    ,"Lat":10.741972
    ,"Long":106.626015
    ,"Polyline":"[106.63099670,10.74167347] ; [106.62818146,10.74206257] ; [106.62601471,10.74197197]"
    ,"Distance":"548"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1589"
    ,"Station_Code":"Q6 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Lý Chiêu Hoàng"
    ,"Station_Address":"426, đường An Dương Vương, Quận 6"
    ,"Lat":10.740065
    ,"Long":106.623548
    ,"Polyline":"[106.62601471,10.74197197] ; [106.62364197,10.74185753] ; [106.62355042,10.74006462]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7045"
    ,"Station_Code":"QBT 275"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Đường 38"
    ,"Station_Address":"333, đường An Dương Vương, Quận Bình Tân"
    ,"Lat":10.738347
    ,"Long":106.622009
    ,"Polyline":"[106.62355042,10.74006462] ; [106.62358093,10.73899555] ; [106.62236023,10.73878956] ; [106.62225342,10.73874760] ; [106.62213898,10.73866272] ; [106.62200928,10.73834705]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7046"
    ,"Station_Code":"QBT 276"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Chung cư Lê Thành"
    ,"Station_Address":"Đối diện 76, đường An Dương Vương, Qu ận Bình Tân"
    ,"Lat":10.724148
    ,"Long":106.619874
    ,"Polyline":"[106.62200928,10.73834705] ; [106.62120056,10.73500538] ; [106.62078094,10.73139000] ; [106.61987305,10.72414780]"
    ,"Distance":"1600"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7047"
    ,"Station_Code":"QBT 277"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trương Đình Hội"
    ,"Station_Address":"Đối diện 62, đường An Dương Vương, Quận B ình Tân"
    ,"Lat":10.71952
    ,"Long":106.619289
    ,"Polyline":"[106.61987305,10.72414780] ; [106.61928558,10.71951962]"
    ,"Distance":"519"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7048"
    ,"Station_Code":"QBT 278"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chợ Kiến Đức"
    ,"Station_Address":"Đối diện 174, đường An Dương Vương, Quận Bình Tân"
    ,"Lat":10.716653
    ,"Long":106.619069
    ,"Polyline":"[106.61928558,10.71951962] ; [106.61907196,10.71665287]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7049"
    ,"Station_Code":"Q8 144"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đối diện 54"
    ,"Station_Address":"Đối diện 54, đường An Dương Vương, Quận 8"
    ,"Lat":10.713311
    ,"Long":106.618795
    ,"Polyline":"[106.61907196,10.71665287] ; [106.61879730,10.71331120]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"763"
    ,"Station_Code":"Q8 081"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bến Phú Định"
    ,"Station_Address":"5, đường An Dương Vương, Quận 8"
    ,"Lat":10.71135
    ,"Long":106.61864
    ,"Polyline":"[106.61879730,10.71331120] ; [106.61863708,10.71135044]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1847"
    ,"Station_Code":"Q8 134"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Chùa Viên Gi ác"
    ,"Station_Address":"Đối diện Chùa Giác Viên,  đường Hồ Học Lãm, Quận 8"
    ,"Lat":10.713359
    ,"Long":106.616848
    ,"Polyline":"[106.61863708,10.71135044] ; [106.61860657,10.71078682] ; [106.61842346,10.71081257] ; [106.61817932,10.71106529] ; [106.61761475,10.71204567] ; [106.61685181,10.71335888]"
    ,"Distance":"416"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1849"
    ,"Station_Code":"QBT 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Nhựa Long Thành"
    ,"Station_Address":"Đối diện 201, đường Hồ Học Lãm, Quận Bình  Tân"
    ,"Lat":10.718234
    ,"Long":106.613817
    ,"Polyline":"[106.61685181,10.71335888] ; [106.61381531,10.71823406]"
    ,"Distance":"636"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"1848"
    ,"Station_Code":"QBT 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Võ Văn Kiệt"
    ,"Station_Address":"109-258, đường Hồ Học Lãm, Quận Bình Tân"
    ,"Lat":10.72069
    ,"Long":106.612229
    ,"Polyline":"[106.61381531,10.71823406] ; [106.61222839,10.72068977]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"637"
    ,"Station_Code":"HBC 363"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Hưng Nhơn"
    ,"Station_Address":"B1/5, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.71328
    ,"Long":106.598904
    ,"Polyline":"[106.61222839,10.72068977] ; [106.61119843,10.72230339] ; [106.59965515,10.71652603] ; [106.59928894,10.71643162] ; [106.59910583,10.71647358] ; [106.59891510,10.71652603] ; [106.59872437,10.71668434] ; [106.59862518,10.71699047] ; [106.59873199,10.71727467] ; [106.59894562,10.71742249] ; [106.59922791,10.71741199] ; [106.59952545,10.71722221] ; [106.59964752,10.71682167] ; [106.59960175,10.71611500] ; [106.59890747,10.71327972]"
    ,"Distance":"2358"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"638"
    ,"Station_Code":"HBC 364"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C3/4, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.70706
    ,"Long":106.598089
    ,"Polyline":"[106.59890747,10.71327972] ; [106.59809113,10.70705986]"
    ,"Distance":"698"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7030"
    ,"Station_Code":"HBC_1"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Dương Đình Cúc"
    ,"Station_Address":"C9/15B, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.705468
    ,"Long":106.597397
    ,"Polyline":"[106.59809113,10.70705986] ; [106.59788513,10.70595264] ; [106.59739685,10.70546818]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7031"
    ,"Station_Code":"HBC_2"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Thiên Hoàng Long"
    ,"Station_Address":"D1/14, đường Dương Đình Cúc, Huyện Bình Ch ánh"
    ,"Lat":10.703001
    ,"Long":106.59516
    ,"Polyline":"[106.59739685,10.70546818] ; [106.59632111,10.70446110.06.59516144]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7032"
    ,"Station_Code":"HBC_3"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Y tế Tân Kiên"
    ,"Station_Address":"D6/24B, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.70075
    ,"Long":106.591431
    ,"Polyline":"[106.59516144,10.70300102] ; [106.59442139,10.70206261] ; [106.59308624,10.70154095] ; [106.59246063,10.70127201] ; [106.59166718,10.70097733] ; [106.59143066,10.70075035]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7033"
    ,"Station_Code":"HBC_4"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Cầu Chợ Đệm"
    ,"Station_Address":"D13/21D, đường Dương Đình  Cúc, Huyện Bình Chánh"
    ,"Lat":10.698231
    ,"Long":106.587038
    ,"Polyline":"[106.59143066,10.70075035] ; [106.59039307,10.69965935] ; [106.58979797,10.69931126] ; [106.58703613,10.69823074]"
    ,"Distance":"567"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"7034"
    ,"Station_Code":"HBC_5"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Cầu Chợ Đệm"
    ,"Station_Address":"D13 /21D, đường Dương Đình Cúc, Huyện Bình Chánh"
    ,"Lat":10.695732
    ,"Long":106.580933
    ,"Polyline":"[106.58703613,10.69823074] ; [106.58445740,10.69715023] ; [106.58182526,10.69600105] ; [106.58093262,10.69573212]"
    ,"Distance":"724"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3788"
    ,"Station_Code":"HBC 415"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Chùa Tường  Văn"
    ,"Station_Address":"Đối diện cột điện 2AT, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.696902
    ,"Long":106.579045
    ,"Polyline":"[106.58093262,10.69573212] ; [106.58038330,10.69554234] ; [106.58025360,10.69559002] ; [106.58013916,10.69572639] ; [106.57999420,10.69582653] ; [106.57982635,10.69577980] ; [106.57975006,10.69585896] ; [106.57904816,10.69690228]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3791"
    ,"Station_Code":"HBC 416"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Chợ Đệm"
    ,"Station_Address":"Đối diện cột điện 9AT, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.699164
    ,"Long":106.577581
    ,"Polyline":"[106.57904816,10.69690228] ; [106.57828522,10.69803524] ; [106.57758331,10.69916439]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3790"
    ,"Station_Code":"HBC 417"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Đình Phục Đức"
    ,"Station_Address":"Đình Phục Đức, đường Thế L ữ, Huyện Bình Chánh"
    ,"Lat":10.700497
    ,"Long":106.575397
    ,"Polyline":"[106.57758331,10.69916439] ; [106.57716370,10.69973850] ; [106.57625580,10.70010757] ; [106.57539368,10.70049667]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"3793"
    ,"Station_Code":"HBC 419"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Tân Tạo - Chợ Đệm"
    ,"Station_Address":"Đối diện cột điện 280T, đường Thế Lữ,  Huyện Bình Chánh"
    ,"Lat":10.702495
    ,"Long":106.571792
    ,"Polyline":"[106.57539368,10.70049667] ; [106.57424164,10.70120335] ; [106.57271576,10.70218372] ; [106.57254028,10.70226860] ; [106.57226563,10.70231533] ; [106.57179260,10.70249462]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"2158"
    ,"Station_Code":"HBC 420"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Ngã 3 Trường học"
    ,"Station_Address":"E9/139C, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.704187
    ,"Long":106.567769
    ,"Polyline":"[106.57179260,10.70249462] ; [106.57179260,10.70249462] ; [106.57089996,10.70281696] ; [106.56930542,10.70353317] ; [106.56777191,10.70418739] ; [106.56777191,10.70418739]"
    ,"Distance":"479"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"2161"
    ,"Station_Code":"HBC 421"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Tân Nhựt"
    ,"Station_Address":"B15/307A (Thành Phát), đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.706085
    ,"Long":106.563714
    ,"Polyline":"[106.56777191,10.70418739] ; [106.56679535,10.70460892] ; [106.56580353,10.70500946] ; [106.56443787,10.70561028] ; [106.56371307,10.70608521]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"12"
    ,"Station_Id":"4761"
    ,"Station_Code":"BX_100"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Tân Nhựt"
    ,"Station_Address":"B14/290, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.706232
    ,"Long":106.563231
    ,"Polyline":"[106.56371307,10.70608521] ; [106.56330109,10.70633221] ; [106.56323242,10.70623207]"
    ,"Distance":"66"
  }]