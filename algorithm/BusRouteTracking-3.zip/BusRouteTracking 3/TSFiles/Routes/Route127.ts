export const Route127 =[

  {
     "Route_Id":"127"
    ,"Station_Id":"3957"
    ,"Station_Code":"BX68"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"An Nhơn Tây"
    ,"Station_Address":"ĐẦU BẾN BẾN XE AN NHƠN TÂY, đường Tỉnh  lộ 15, Huyện Củ Chi"
    ,"Lat":11.088134
    ,"Long":106.511093
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3547"
    ,"Station_Code":"QCCT116"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã tư An Nhơn Tây"
    ,"Station_Address":"20-22, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.08946704864502
    ,"Long":106.51388549804688
    ,"Polyline":"[106.51101685,11.08821011] ; [106.51217651,11.08924961] ; [106.51293182,11.08965015] ; [106.51384735,11.08988953] ; [106.51416016,11.08872986] ; [106.51418304,11.08858967] ; [106.51403046,11.08839989] ; [106.51390839,11.08829021]"
    ,"Distance":"562"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3958"
    ,"Station_Code":"HCC 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trạm xăng số 4"
    ,"Station_Address":"Đối diện 1324, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.085017
    ,"Long":106.510246
    ,"Polyline":"[106.51390839,11.08829021] ; [106.51158142,11.08615017]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3960"
    ,"Station_Code":"HCC 125"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cây xăng số 4"
    ,"Station_Address":"1281, đường Ti ̉nh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.08255
    ,"Long":106.507469
    ,"Polyline":"[106.51158142,11.08615017] ; [106.51022339,11.08491039] ; [106.50942993,11.08415985] ; [106.50859070,11.08349991] ; [106.50820923,11.08316040]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3961"
    ,"Station_Code":"QCCT165"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngã 3 Dừa  Củi"
    ,"Station_Address":"1238 (238), đường Ti ̉nh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.080432891845703
    ,"Long":106.5051498413086
    ,"Polyline":"[106.50820923,11.08316040] ; [106.50515747,11.08038998]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3963"
    ,"Station_Code":"HCC 127"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Ngã 3 Ao Câu"
    ,"Station_Address":"Cây xăng Petrolimex, đường Tỉnh lộ 7  Củ Chi, Huyện Củ Chi"
    ,"Lat":11.075734
    ,"Long":106.499397
    ,"Polyline":"[106.50515747,11.08038998] ; [106.50451660,11.07977962] ; [106.50238800,11.07773972] ; [106.50203705,11.07746029] ; [106.50034332,11.07631969]"
    ,"Distance":"696"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3965"
    ,"Station_Code":"HCC 128"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Ngã tư Xóm Mới"
    ,"Station_Address":"Đối diện 1116A (116), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.071233
    ,"Long":106.493446
    ,"Polyline":"[106.50034332,11.07631969] ; [106.49745941,11.07437992] ; [106.49594116,11.07322979] ; [106.49481201,11.07225990]"
    ,"Distance":"755"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3966"
    ,"Station_Code":"HCC 129"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Gò Nổi"
    ,"Station_Address":"1049 (46), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.067133
    ,"Long":106.488052
    ,"Polyline":"[106.49481201,11.07225990] ; [106.48972321,11.06828976] ; [106.48912048,11.06785011]"
    ,"Distance":"792"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3968"
    ,"Station_Code":"HCC 130"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Chợ mới Trung Hòa"
    ,"Station_Address":"Đối diện 996  (40), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.064967
    ,"Long":106.48497
    ,"Polyline":"[106.48912048,11.06785011] ; [106.48738098,11.06659985] ; [106.48473358,11.06474018] ; [106.48297882,11.06363964]"
    ,"Distance":"818"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3977"
    ,"Station_Code":"HCC 131"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Chợ cũ  Trung Hòa"
    ,"Station_Address":"32 (Đối diện 165), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.061267
    ,"Long":106.479034
    ,"Polyline":"[106.48297882,11.06363964] ; [106.47843933,11.06085968] ; [106.47746277,11.06023979]"
    ,"Distance":"712"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3970"
    ,"Station_Code":"HCC 132"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Ấp Đồn"
    ,"Station_Address":"865 (Đối diện 79 ), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.059733
    ,"Long":106.476517
    ,"Polyline":"[106.47746277,11.06023979] ; [106.47586823,11.05924988] ; [106.47386169,11.05805969] ; [106.47209167,11.05700970] ; [106.47145844,11.05665970]"
    ,"Distance":"767"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3978"
    ,"Station_Code":"HCC 133"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"cafe Huy ền Thảo"
    ,"Station_Address":"621 (14), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.056183
    ,"Long":106.460983
    ,"Polyline":"[106.47145844,11.05665970] ; [106.46962738,11.05560970] ; [106.46923828,11.05545044] ; [106.46896362,11.05541992] ; [106.46868134,11.05541992] ; [106.46742249,11.05552006] ; [106.46485901,11.05572033] ; [106.46385956,11.05583000]"
    ,"Distance":"867"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3981"
    ,"Station_Code":"HCC 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Sài Gòn 2"
    ,"Station_Address":"507, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.048617
    ,"Long":106.45517
    ,"Polyline":"[106.46385956,11.05583000] ; [106.45976257,11.05626011] ; [106.45945740,11.05624962] ; [106.45870972,11.05613995] ; [106.45847321,11.05609035] ; [106.45819855,11.05599022] ; [106.45781708,11.05572033] ; [106.45720673,11.05515957] ; [106.45696259,11.05475998] ; [106.45677948,11.05445957] ; [106.45630646,11.05266953]"
    ,"Distance":"1063"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3972"
    ,"Station_Code":"HCC 169"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đập nước"
    ,"Station_Address":"Đập nước, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.042217
    ,"Long":106.454865
    ,"Polyline":"[106.45630646,11.05266953] ; [106.45594788,11.05132008] ; [106.45577240,11.05004978] ; [106.45561981,11.04950047] ; [106.45543671,11.04932976] ; [106.45529175,11.04897976] ; [106.45523071,11.04872036] ; [106.45523071,11.04850960] ; [106.45525360,11.04730034] ; [106.45520020,11.04636002] ; [106.45516205,11.04549026]"
    ,"Distance":"820"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3973"
    ,"Station_Code":"HCC 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Basa"
    ,"Station_Address":"311 (Đối diện 302), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.040167
    ,"Long":106.453835
    ,"Polyline":"[106.45516205,11.04549026] ; [106.45509338,11.04411983] ; [106.45504761,11.04308987] ; [106.45491791,11.04174995] ; [106.45484161,11.04123974] ; [106.45481110,11.04106998] ; [106.45468140,11.04084015] ; [106.45455170,11.04065037] ; [106.45429993,11.04047966] ; [106.45284271,11.03940010.06.45115662] ; [11.03820038,106.45053864] ; [11.03773975,106.44863892] ; [11.03598022,106.44815063]"
    ,"Distance":"1452"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3975"
    ,"Station_Code":"HCC 166"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Bưu điện Gia Bẹ"
    ,"Station_Address":"Bưu điện Gia Bẹ, đường Hương lộ 2, Huyện C ủ Chi"
    ,"Lat":11.031485
    ,"Long":106.448479
    ,"Polyline":"[106.44815063,11.03553009] ; [106.44721985,11.03466988] ; [106.44940186,11.03238010]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3983"
    ,"Station_Code":"QCCT230"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Dịch vụ cầm đồ Hoàng Trúc Phương"
    ,"Station_Address":"Dịch vụ cầm đồ Hoàng Trúc Phương, đư ờng Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.028156280517578
    ,"Long":106.45204162597656
    ,"Polyline":"[106.44943237,11.03234959] ; [106.45276642,11.02882004]"
    ,"Distance":"536"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3976"
    ,"Station_Code":"QCCT231"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ủy ban  xã Trung Lập Hạ"
    ,"Station_Address":"Cột đi ện 164, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.023185729980469
    ,"Long":106.45667266845703
    ,"Polyline":"[106.45276642,11.02882004] ; [106.45742035,11.02385998]"
    ,"Distance":"750"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3979"
    ,"Station_Code":"QCCT232"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Đại lý Ga Thanh Xuân"
    ,"Station_Address":"Đại lý Ga Thanh Xuân, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.018342018127441
    ,"Long":106.46101379394531
    ,"Polyline":"[106.45742035,11.02385998] ; [106.46188354,11.01914024]"
    ,"Distance":"716"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3985"
    ,"Station_Code":"QCCT233"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Trạm xăng Trung Lập Hạ"
    ,"Station_Address":"Kế 91, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.012739181518555
    ,"Long":106.46622467041016
    ,"Polyline":"[106.46188354,11.01914024] ; [106.46533966,11.01548958] ; [106.46714020,11.01356030]"
    ,"Distance":"846"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3980"
    ,"Station_Code":"QCCT234"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ấp văn hóa Trảng Lâm"
    ,"Station_Address":"59, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.009379386901855
    ,"Long":106.47073364257812
    ,"Polyline":"[106.46714020,11.01356030] ; [106.47026062,11.01023960] ; [106.47091675,11.00955009]"
    ,"Distance":"608"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3982"
    ,"Station_Code":"HCC 194"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường tiểu học Lê Văn Thế"
    ,"Station_Address":"Trường tiểu học Lê Văn Thế, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.004809
    ,"Long":106.474861
    ,"Polyline":"[106.47091675,11.00955009] ; [106.47409821,11.00617027] ; [106.47515869,11.00508976]"
    ,"Distance":"679"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3987"
    ,"Station_Code":"QCCT236"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Cây xăng Đạo Thành"
    ,"Station_Address":"Đối diện cột điện VH93, đường  Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.001665115356445
    ,"Long":106.47872161865234
    ,"Polyline":"[106.47524261,11.00500965] ; [106.47718048,11.00294971] ; [106.47746277,11.00271988] ; [106.47785187,11.00244999] ; [106.47882843,11.00181007]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3984"
    ,"Station_Code":"QCCT237"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường  mẫu giáo Bông Sen 6"
    ,"Station_Address":"Đối  diện 67, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":10.998936653137207
    ,"Long":106.4841537475586
    ,"Polyline":"[106.47882843,11.00181007] ; [106.48069763,11.00059032] ; [106.48148346,11.00010014] ; [106.48168945,11.00000000] ; [106.48288727,10.99952984] ; [106.48413849,10.99899960]"
    ,"Distance":"662"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3988"
    ,"Station_Code":"QCCT400"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Đối diện công ty Kim Đan"
    ,"Station_Address":"Đối diện công ty Kim Đan, đường Giáp Hải, Huyện Củ  Chi"
    ,"Lat":10.988932609558105
    ,"Long":106.48377990722656
    ,"Polyline":"[106.48413849,10.99899960] ; [106.48471069,10.99874973] ; [106.48432922,10.99742985] ; [106.48378754,10.99584961]"
    ,"Distance":"406"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3986"
    ,"Station_Code":"HCC 201"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Kiềm Ngọc Nghĩa"
    ,"Station_Address":"Kiềm Ngọc Nghĩa, đường Giáp Hải, Huyện Củ Chi"
    ,"Lat":10.985274
    ,"Long":106.483925
    ,"Polyline":"[106.48378754,10.99584961] ; [106.48371124,10.99561024] ; [106.48364258,10.99524021] ; [106.48374939,10.99330997] ; [106.48380280,10.99104023]"
    ,"Distance":"537"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3992"
    ,"Station_Code":"HCC 202"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Đối diện công ty HanSae"
    ,"Station_Address":"Đối diện công  ty HanSae, đường Giáp Hải, Huyện Củ Chi"
    ,"Lat":10.980363
    ,"Long":106.483932
    ,"Polyline":"[106.48380280,10.99104023] ; [106.48383331,10.99032974] ; [106.48387909,10.99011993] ; [106.48383331,10.99003983] ; [106.48391724,10.98738003] ; [106.48400116,10.98342991] ; [106.48397064,10.98316956] ; [106.48393250,10.98307037] ; [106.48397827,10.98295975] ; [106.48403168,10.98274040] ; [106.48403931,10.98239040] ; [106.48409271,10.97999954]"
    ,"Distance":"1234"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Bến xe C ủ Chi"
    ,"Station_Address":"B ến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":"[106.48409271,10.97999954] ; [106.48419189,10.97614002] ; [106.48415375,10.97574997] ; [106.48354340,10.97461033] ; [106.48291016,10.97350979] ; [106.48178101,10.97183990] ; [106.48172760,10.97165012] ; [106.48153687,10.97142982] ; [106.48169708,10.97130013] ; [106.48175049,10.97136021] ; [106.48188782,10.97140026] ; [106.48204803,10.97140980] ; [106.48210144,10.97142029] ; [106.48220062,10.97148037] ; [106.48226166,10.97154999]"
    ,"Distance":"1127"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe C ủ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4020"
    ,"Station_Code":"QCCT397"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Công ty HanSae"
    ,"Station_Address":"Công ty HanSae , đường Giáp Hải, Huyện Củ Chi"
    ,"Lat":10.978616714477539
    ,"Long":106.48428344726562
    ,"Polyline":"[106.48226166,10.97154999] ; [106.48220062,10.97148037] ; [106.48210144,10.97142029] ; [106.48197937,10.97140026] ; [106.48181152,10.97138977] ; [106.48175049,10.97136021] ; [106.48169708,10.97130013] ; [106.48153687,10.97142982] ; [106.48172760,10.97165012] ; [106.48188782,10.97175980] ; [106.48284149,10.97319031] ; [106.48355865,10.97437000] ; [106.48423767,10.97554970] ; [106.48432922,10.97591972] ; [106.48432922,10.97653961] ; [106.48428345,10.97807026] ; [106.48426819,10.97861958]"
    ,"Distance":"984"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4021"
    ,"Station_Code":"HCC 198"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nhà máy bia Sài Gòn"
    ,"Station_Address":"Nhà máy bia Sài Gòn, đường Giáp Hải, Huyện Củ Chi"
    ,"Lat":10.984696
    ,"Long":106.484131
    ,"Polyline":"[106.48426819,10.97861958] ; [106.48417664,10.98241997] ; [106.48416138,10.98293018] ; [106.48419189,10.98293972] ; [106.48422241,10.98297977] ; [106.48423767,10.98303032] ; [106.48423767,10.98309994] ; [106.48419189,10.98318005] ; [106.48413849,10.98320007] ; [106.48413086,10.98361015] ; [106.48410797,10.98470020]"
    ,"Distance":"686"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4022"
    ,"Station_Code":"QCCT399"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Công ty Kim Đan"
    ,"Station_Address":"Công ty Kim Đan, đường Giáp Hải, Huyện Củ Chi"
    ,"Lat":10.988275527954102
    ,"Long":106.48413848876953
    ,"Polyline":"[106.48410797,10.98470020] ; [106.48403168,10.98826981]"
    ,"Distance":"397"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4023"
    ,"Station_Code":"HCC 159"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Trường tiểu học Lê Văn Thế"
    ,"Station_Address":"Đối diện 52, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":10.999006
    ,"Long":106.48447
    ,"Polyline":"[106.48403168,10.98826981] ; [106.48394012,10.99003983] ; [106.48387909,10.99011993] ; [106.48383331,10.99032974] ; [106.48374939,10.99277973] ; [106.48372650,10.99347973] ; [106.48364258,10.99522018] ; [106.48371124,10.99559975] ; [106.48432922,10.99742985] ; [106.48471069,10.99874973] ; [106.48439789,10.99888039]"
    ,"Distance":"1224"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4024"
    ,"Station_Code":"HCC 160"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Cây dù Vàng"
    ,"Station_Address":"Đối diện 105, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":10.999717
    ,"Long":106.482597
    ,"Polyline":"[106.48439789,10.99888039] ; [106.48256683,10.99965000]"
    ,"Distance":"217"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4025"
    ,"Station_Code":"HCC 163"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Trường THCS Trung Lập Hạ"
    ,"Station_Address":"Tr ường THCS Trung Lập Hạ, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.006178
    ,"Long":106.47438
    ,"Polyline":"[106.48256683,10.99965000] ; [106.48168945,11.00000000] ; [106.48148346,11.00010014] ; [106.48069763,11.00059032] ; [106.47785187,11.00244999] ; [106.47746277,11.00271988] ; [106.47718048,11.00294971] ; [106.47524261,11.00500965] ; [106.47422791,11.00603962]"
    ,"Distance":"1167"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4026"
    ,"Station_Code":"QCCT223"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm y tế xã Trung Lập Hạ"
    ,"Station_Address":"Trạm y tế xã Trung Lập Hạ, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.010085105895996
    ,"Long":106.47053527832031
    ,"Polyline":"[106.47422791,11.00603962] ; [106.47190094,11.00852966] ; [106.47046661,11.01002026]"
    ,"Distance":"604"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4027"
    ,"Station_Code":"HCC 162"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm xăng Trung Lập Hạ"
    ,"Station_Address":"Đối diện 91, đường Hương lộ 2, Huyện C ủ Chi"
    ,"Lat":11.001207
    ,"Long":106.480029
    ,"Polyline":"[106.47046661,11.01002026] ; [106.46848297,11.01212025] ; [106.46633148,11.01443005]"
    ,"Distance":"667"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4028"
    ,"Station_Code":"QCCT225"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"đại lý Ga Thanh Xuân"
    ,"Station_Address":"Đối diện đại lý Ga  Thanh Xuân, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.020111083984375
    ,"Long":106.461181640625
    ,"Polyline":"[106.46633148,11.01443005] ; [106.46457672,11.01628971] ; [106.46105957,11.02000046]"
    ,"Distance":"846"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4030"
    ,"Station_Code":"HCC 164"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ủy ban xã Trung Lập Hạ"
    ,"Station_Address":"UBND xã Trung Lập Hạ, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.008074
    ,"Long":106.472583
    ,"Polyline":"[106.46105957,11.02000046] ; [106.45648956,11.02486038]"
    ,"Distance":"736"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4029"
    ,"Station_Code":"QCCT227"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"DV cầm đồ Hoàng Trúc Phương"
    ,"Station_Address":"Đối diện DV cầm đồ Hoàng Trúc Phương, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.028788566589355
    ,"Long":106.45298767089844
    ,"Polyline":"[106.45648956,11.02486038] ; [106.45288086,11.02869034]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4031"
    ,"Station_Code":"QCCT228"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Sài Gòn 2"
    ,"Station_Address":"Đối diện Sài Gòn 2, đường Hương lộ 2, Huyện Củ Chi"
    ,"Lat":11.032748222351074
    ,"Long":106.44916534423828
    ,"Polyline":"[106.45288086,11.02869034] ; [106.44909668,11.03269005]"
    ,"Distance":"607"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4033"
    ,"Station_Code":"QCCT149"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"cafe Huyền Thảo"
    ,"Station_Address":"348, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.043283462524414
    ,"Long":106.45511627197266
    ,"Polyline":"[106.44909668,11.03269005] ; [106.44721985,11.03466988] ; [106.44863892,11.03598022] ; [106.45053864,11.03773975] ; [106.45115662,11.03820038] ; [106.45284271,11.03940010.06.45429993] ; [11.04047966,106.45455170] ; [11.04065037,106.45468140] ; [11.04084015,106.45481110] ; [11.04106998,106.45484161] ; [11.04123974,106.45491791] ; [11.04174995,106.45504761] ; [11.04308987,106.45504761]"
    ,"Distance":"1648"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4034"
    ,"Station_Code":"HCC 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Sân bóng đá"
    ,"Station_Address":"502, đường Tỉnh lộ 7 Cu ̉ Chi, Huyện Củ Chi"
    ,"Lat":11.048271
    ,"Long":106.455292
    ,"Polyline":"[106.45506287,11.04331970] ; [106.45520020,11.04636002] ; [106.45525360,11.04730034] ; [106.45523834,11.04827023]"
    ,"Distance":"551"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4032"
    ,"Station_Code":"HCC 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Đập nước"
    ,"Station_Address":"Đối diện 623 (104), đường Tỉnh lộ 7 Cu ̉ Chi, Huyện Củ Chi"
    ,"Lat":11.056029
    ,"Long":106.46125
    ,"Polyline":"[106.45523834,11.04827023] ; [106.45523071,11.04872036] ; [106.45529175,11.04897976] ; [106.45536804,11.04918003] ; [106.45543671,11.04932976] ; [106.45561981,11.04950047] ; [106.45577240,11.05004978] ; [106.45594788,11.05132008] ; [106.45677948,11.05445957] ; [106.45696259,11.05475998] ; [106.45720673,11.05515957] ; [106.45781708,11.05572033] ; [106.45819855,11.05599022] ; [106.45847321,11.05609035] ; [106.45870972,11.05613995] ; [106.45945740,11.05624962] ; [106.45976257,11.05626011] ; [106.46125793,11.05609989]"
    ,"Distance":"1288"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4036"
    ,"Station_Code":"QCCT152"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Sài Gòn 2"
    ,"Station_Address":"Đối diện 8 (29 ), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.059399604797363
    ,"Long":106.47618865966797
    ,"Polyline":"[106.46125793,11.05609989] ; [106.46362305,11.05585003] ; [106.46485901,11.05572033] ; [106.46742249,11.05552006] ; [106.46868134,11.05541992] ; [106.46896362,11.05541992] ; [106.46923828,11.05545044] ; [106.46962738,11.05560970] ; [106.47209167,11.05700970] ; [106.47586823,11.05924988] ; [106.47617340,11.05943966]"
    ,"Distance":"1753"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4035"
    ,"Station_Code":"QCCT153"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cafe Huyền Thảo"
    ,"Station_Address":"928 (19 ), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.061497688293457
    ,"Long":106.47959899902344
    ,"Polyline":"[106.47617340,11.05943966] ; [106.47956848,11.06153965]"
    ,"Distance":"438"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4038"
    ,"Station_Code":"QCCT154"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Ấp Đồn"
    ,"Station_Address":"Kế  998 (73), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.065051078796387
    ,"Long":106.48523712158203
    ,"Polyline":"[106.47956848,11.06153965] ; [106.48123932,11.06256008] ; [106.48473358,11.06474018] ; [106.48522186,11.06507969]"
    ,"Distance":"732"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4037"
    ,"Station_Code":"QCCT155"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ cũ Trung Hòa"
    ,"Station_Address":"Đối diện 1031 (155-157), đường Tỉnh lộ 7 Củ Chi, Huyện Củ  Chi"
    ,"Lat":11.066787719726562
    ,"Long":106.48780059814453
    ,"Polyline":"[106.48522186,11.06507969] ; [106.48773956,11.06686020]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4039"
    ,"Station_Code":"HCC 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Chợ mới Trung Hòa"
    ,"Station_Address":"Đối diện 1107 (41), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.070918
    ,"Long":106.493179
    ,"Polyline":"[106.48773956,11.06686020] ; [106.48972321,11.06828976] ; [106.49051666,11.06892014] ; [106.49314117,11.07096004]"
    ,"Distance":"746"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4040"
    ,"Station_Code":"HCC 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Gò Nổi"
    ,"Station_Address":"47, đường Tỉnh l ộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.075483
    ,"Long":106.499168
    ,"Polyline":"[106.49314117,11.07096004] ; [106.49497986,11.07238960] ; [106.49594116,11.07322979] ; [106.49745941,11.07437992] ; [106.49915314,11.07551003]"
    ,"Distance":"830"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4041"
    ,"Station_Code":"HCC 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Chợ Lô 6"
    ,"Station_Address":"1240 (Đối diện 116), đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.080067
    ,"Long":106.504898
    ,"Polyline":"[106.49915314,11.07551003] ; [106.50203705,11.07746029] ; [106.50238800,11.07773972] ; [106.50485992,11.08010960]"
    ,"Distance":"809"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4045"
    ,"Station_Code":"HCC 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"An Nhơn Tây"
    ,"Station_Address":"1268, đường  Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.08224
    ,"Long":106.507256
    ,"Polyline":"[106.50485992,11.08010960] ; [106.50721741,11.08228016]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"4042"
    ,"Station_Code":"HCC 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm x ăng số 4"
    ,"Station_Address":"1308, đường Tỉnh lộ 7 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.084423
    ,"Long":106.509811
    ,"Polyline":"[106.50721741,11.08228016] ; [106.50859070,11.08349991] ; [106.50942993,11.08415985] ; [106.50975800,11.08448029]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3506"
    ,"Station_Code":"QCCT089"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Nhà văn hóa Cụm An Nhơn Tây"
    ,"Station_Address":"Đối diện 1029, đường Tỉnh lộ 15 Củ Chi, Huyện Củ Chi"
    ,"Lat":11.089067459106445
    ,"Long":106.51408386230469
    ,"Polyline":"[106.50975800,11.08448029] ; [106.51230621,11.08683014] ; [106.51403046,11.08839989] ; [106.51418304,11.08858967] ; [106.51416016,11.08872986] ; [106.51407623,11.08907032]"
    ,"Distance":"720"
  },
  {
     "Route_Id":"127"
    ,"Station_Id":"3957"
    ,"Station_Code":"BX68"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"An Nhơn Tây"
    ,"Station_Address":"ĐẦU BẾN BẾN XE AN NHƠN TÂY, đường Tỉnh lộ 15, Huyện Củ Chi"
    ,"Lat":11.088134
    ,"Long":106.511093
    ,"Polyline":"[106.51407623,11.08907032] ; [106.51384735,11.08988953] ; [106.51293182,11.08965015] ; [106.51217651,11.08924961] ; [106.51101685,11.08821011]"
    ,"Distance":"463"
  }]