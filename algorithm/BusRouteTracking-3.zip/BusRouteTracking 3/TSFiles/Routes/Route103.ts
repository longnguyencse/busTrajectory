export const Route103 =[

  {
     "Route_Id":"103"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"Bến xe An Sương, đường Quốc lộ 22 , Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"171"
    ,"Station_Code":"Q12 134"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"601, đường Trường Chinh, Quận 12"
    ,"Lat":10.841209
    ,"Long":106.615925
    ,"Polyline":"[106.61319733,10.84385967] ; [106.61312103,10.84407997] ; [106.61322784,10.84414005] ; [106.61338806,10.84424973] ; [106.61386108,10.84449005] ; [106.61405182,10.84459972] ; [106.61412048,10.84449005] ; [106.61486053,10.84325981] ; [106.61508179,10.84286976] ; [106.61504364,10.84278965] ; [106.61502075,10.84265041] ; [106.61504364,10.84255981] ; [106.61511993,10.84243011] ; [106.61530304,10.84235001] ; [106.61535645,10.84234047] ; [106.61546326,10.84218979] ; [106.61605835,10.84127045]"
    ,"Distance":"588"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"167"
    ,"Station_Code":"Q12 135"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"487, đường Trường Chinh, Quận 12"
    ,"Lat":10.837863
    ,"Long":106.618044
    ,"Polyline":"[106.61605835,10.84127045] ; [106.61820221,10.83794975]"
    ,"Distance":"437"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"172"
    ,"Station_Code":"Q12 136"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Chùa L ạc Quang"
    ,"Station_Address":"257, đường Trư ờng Chinh, Quận 12"
    ,"Lat":10.834623
    ,"Long":106.620163
    ,"Polyline":"[106.61820221,10.83794975] ; [106.62029266,10.83471012]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"168"
    ,"Station_Code":"Q12 137"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Chùa Vĩnh Phước"
    ,"Station_Address":"Chùa Vĩnh Phước, đường Trường Chinh , Quận 12"
    ,"Lat":10.831836
    ,"Long":106.621928
    ,"Polyline":"[106.62029266,10.83471012] ; [106.62207794,10.83191967]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"170"
    ,"Station_Code":"Q12 138"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"113, đường Trường Chinh, Quận 12"
    ,"Lat":10.82898
    ,"Long":106.623768
    ,"Polyline":"[106.62207794,10.83191967] ; [106.62387848,10.82913017]"
    ,"Distance":"367"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"169"
    ,"Station_Code":"Q12 139"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"Kế 2/6B, đư ờng Trường Chinh, Quận 12"
    ,"Lat":10.82624
    ,"Long":106.62586
    ,"Polyline":"[106.62387848,10.82913017] ; [106.62487793,10.82758999] ; [106.62512207,10.82730007] ; [106.62560272,10.82676029] ; [106.62599182,10.82637978]"
    ,"Distance":"384"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"174"
    ,"Station_Code":"QTP 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trạm Dệt Thành Công"
    ,"Station_Address":"8, đường Trư ờng Chinh, Quận Tân Phú"
    ,"Lat":10.82213
    ,"Long":106.630051
    ,"Polyline":"[106.62599182,10.82637978] ; [106.62699890,10.82542038] ; [106.62803650,10.82446957] ; [106.62949371,10.82310963] ; [106.62975311,10.82277012] ; [106.63001251,10.82229996] ; [106.63007355,10.82213974]"
    ,"Distance":"654"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"173"
    ,"Station_Code":"QTP 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trạm KCN Tân Bình"
    ,"Station_Address":"881, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.819386
    ,"Long":106.630615
    ,"Polyline":"[106.63007355,10.82213974] ; [106.63030243,10.82145977] ; [106.63040161,10.82110023] ; [106.63089752,10.81947041]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"176"
    ,"Station_Code":"QTP 012"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Trạm Coopmart Thắng Lợi"
    ,"Station_Address":"2, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.817046
    ,"Long":106.631386
    ,"Polyline":"[106.63089752,10.81947041] ; [106.63162231,10.81711006]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"175"
    ,"Station_Code":"QTP 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Chế Lan  Viên"
    ,"Station_Address":"28/7B, đường Trường  Chinh, Quận Tân Phú"
    ,"Lat":10.812915
    ,"Long":106.632584
    ,"Polyline":"[106.63162231,10.81711006] ; [106.63288116,10.81299973]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"177"
    ,"Station_Code":"QTP 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Trạm Đài Liệt Sỹ"
    ,"Station_Address":"1/3, đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.808209
    ,"Long":106.634262
    ,"Polyline":"[106.63288116,10.81299973] ; [106.63311768,10.81221962] ; [106.63381195,10.80986977] ; [106.63433838,10.80823040]"
    ,"Distance":"554"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2292"
    ,"Station_Code":"QTP 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Trạm Nhà Hàng Thượng Uyển"
    ,"Station_Address":"1/1, đường Trường Chinh, Qu ận Tân Phú"
    ,"Lat":10.806212
    ,"Long":106.634773
    ,"Polyline":"[106.63433838,10.80823040] ; [106.63440704,10.80799961] ; [106.63448334,10.80760002] ; [106.63481903,10.80665016] ; [106.63497925,10.80636978]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2291"
    ,"Station_Code":"QTP 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Tân Kỳ Tân Quý"
    ,"Station_Address":"33/24 (659-661 ), đường Trường Chinh, Quận Tân Phú"
    ,"Lat":10.8048
    ,"Long":106.635269
    ,"Polyline":"[106.63500977,10.80628967] ; [106.63530731,10.80535984] ; [106.63545990,10.80486012]"
    ,"Distance":"166"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2294"
    ,"Station_Code":"QTP 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm B à Quẹo"
    ,"Station_Address":"593A, đường Trường  Chinh, Quận Tân Phú"
    ,"Lat":10.80215
    ,"Long":106.63633
    ,"Polyline":"[106.63545990,10.80486012] ; [106.63601685,10.80313015] ; [106.63610840,10.80288029] ; [106.63636780,10.80230999] ; [106.63642883,10.80220985] ; [106.63632202,10.80216980]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2293"
    ,"Station_Code":"QTB 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Võ Thành Trang"
    ,"Station_Address":"541, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.801391
    ,"Long":106.637308
    ,"Polyline":"[106.63632202,10.80216980] ; [106.63642883,10.80220985] ; [106.63643646,10.80220032] ; [106.63672638,10.80177975] ; [106.63688660,10.80173016] ; [106.63787842,10.80119038] ; [106.63842773,10.80088997]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2296"
    ,"Station_Code":"QTB 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã ba Trương Công Định"
    ,"Station_Address":"403, đường Tr ường Chinh, Quận Tân Bình"
    ,"Lat":10.799115
    ,"Long":106.641557
    ,"Polyline":"[106.63842773,10.80088997] ; [106.64115906,10.79942036] ; [106.64158630,10.79918957]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2559"
    ,"Station_Code":"QTB 082"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Ngã ba Hồng Đào"
    ,"Station_Address":"351, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797666
    ,"Long":106.644266
    ,"Polyline":"[106.64158630,10.79918957] ; [106.64311218,10.79839039] ; [106.64376831,10.79806042] ; [106.64431763,10.79776001]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1392"
    ,"Station_Code":"QTB 083"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"233, đ ường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796426
    ,"Long":106.646553
    ,"Polyline":"[106.64431763,10.79776001] ; [106.64660645,10.79652023]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1826"
    ,"Station_Code":"QTB 084"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nhà th ờ Đắc Lộ"
    ,"Station_Address":"97 (đối diện 160B), đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794978
    ,"Long":106.64926
    ,"Polyline":"[106.64660645,10.79652023] ; [106.64810944,10.79570007] ; [106.64930725,10.79504967]"
    ,"Distance":"337"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1830"
    ,"Station_Code":"QTB 085"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"67, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.793856
    ,"Long":106.651368
    ,"Polyline":"[106.64930725,10.79504967] ; [106.65035248,10.79448032] ; [106.65145111,10.79391003] ; [106.65158081,10.79384995]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"605"
    ,"Station_Code":"QTB 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"733-739, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.792122
    ,"Long":106.6528
    ,"Polyline":"[106.65158081,10.79384995] ; [106.65337372,10.79290962] ; [106.65293884,10.79205990]"
    ,"Distance":"327"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"608"
    ,"Station_Code":"QTB 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Bệnh việnBệnh viện chỉnh hình và phục hồi chức năng"
    ,"Station_Address":"589 , đường L ý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.788718
    ,"Long":106.652806
    ,"Polyline":"[106.65293884,10.79205990] ; [106.65270996,10.79156017] ; [106.65261841,10.79131985] ; [106.65251160,10.79090977] ; [106.65248108,10.79076004] ; [106.65270996,10.78975964] ; [106.65292358,10.78899002]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"607"
    ,"Station_Code":"QTB 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Tân Bình"
    ,"Station_Address":"Chợ Tân Bình, đư ờng Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.786131
    ,"Long":106.653584
    ,"Polyline":"[106.65292358,10.78899002] ; [106.65357208,10.78676987] ; [106.65373230,10.78617954]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"610"
    ,"Station_Code":"QTB 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Siêu th ị Nguyễn Kim - CMC Tân Bình"
    ,"Station_Address":"79B (siêu thị CMC Tân Bình), đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.782695
    ,"Long":106.654571
    ,"Polyline":"[106.65373230,10.78617954] ; [106.65422821,10.78431988] ; [106.65469360,10.78273010]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"609"
    ,"Station_Code":"QTB 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Nguyễn Thái Bình"
    ,"Station_Address":"349 (74), đư ờng Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.779233
    ,"Long":106.655609
    ,"Polyline":"[106.65469360,10.78273010.06.65511322] ; [10.78122997,106.65537262] ; [10.78038025,106.65567780]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"612"
    ,"Station_Code":"Q11 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Bưu Đi ện Phú Thọ"
    ,"Station_Address":"285A, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.775314
    ,"Long":106.656693
    ,"Polyline":"[106.65567780,10.77925014] ; [106.65611267,10.77770996] ; [106.65643311,10.77651024] ; [106.65676117,10.77532959]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"611"
    ,"Station_Code":"Q11 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Đại Học Bách Khoa(cổng trước)"
    ,"Station_Address":"239, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.771331
    ,"Long":106.657829
    ,"Polyline":"[106.65676117,10.77532959] ; [106.65788269,10.77134037]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"613"
    ,"Station_Code":"Q11 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"BV Trưng Vương"
    ,"Station_Address":"Đối diện 266, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.769639
    ,"Long":106.658295
    ,"Polyline":"[106.65788269,10.77134037] ; [106.65815735,10.77038956] ; [106.65836334,10.76966953]"
    ,"Distance":"193"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"614"
    ,"Station_Code":"Q11 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Điện Lực Phú Thọ"
    ,"Station_Address":"215C, đường L ý Thường Kiệt, Quận 11"
    ,"Lat":10.765792
    ,"Long":106.659363
    ,"Polyline":"[106.65836334,10.76966953] ; [106.65862274,10.76869011] ; [106.65879059,10.76803017] ; [106.65881348,10.76801968] ; [106.65937042,10.76607990] ; [106.65943146,10.76581955]"
    ,"Distance":"445"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"615"
    ,"Station_Code":"Q11 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Chợ Nhật Tảo"
    ,"Station_Address":"151, đường Lý Th ường Kiệt, Quận 11"
    ,"Lat":10.761718
    ,"Long":106.660484
    ,"Polyline":"[106.65943146,10.76581955] ; [106.66024017,10.76292038] ; [106.66055298,10.76173973]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"393"
    ,"Station_Code":"Q11 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"BV Răng Hàm Mặt"
    ,"Station_Address":"598, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.758364
    ,"Long":106.660828
    ,"Polyline":"[106.66055298,10.76173973] ; [106.66104126,10.76021004] ; [106.66149139,10.75844955] ; [106.66084290,10.75831032]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1608"
    ,"Station_Code":"Q11 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Thiết"
    ,"Station_Address":"698, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.757636
    ,"Long":106.657387
    ,"Polyline":"[106.66084290,10.75831032] ; [106.65827942,10.75778961] ; [106.65738678,10.75759029]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1599"
    ,"Station_Code":"Q11 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"816, đường Nguyễn Chí Thanh, Quận 11"
    ,"Lat":10.756951
    ,"Long":106.65412
    ,"Polyline":"[106.65738678,10.75759029] ; [106.65561676,10.75720978] ; [106.65454865,10.75699043] ; [106.65416718,10.75693989]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1017"
    ,"Station_Code":"Q5 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"79, đường Tạ Uyên , Quận 5"
    ,"Lat":10.755201
    ,"Long":106.653696
    ,"Polyline":"[106.65416718,10.75693989] ; [106.65368652,10.75687027] ; [106.65368652,10.75669956] ; [106.65370178,10.75566006] ; [106.65374756,10.75520992]"
    ,"Distance":"238"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1010"
    ,"Station_Code":"Q5 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"266, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753657
    ,"Long":106.652559
    ,"Polyline":"[106.65374756,10.75520992] ; [106.65380859,10.75405025] ; [106.65377808,10.75376987] ; [106.65257263,10.75360012]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Bến xe Chợ L ớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường L ê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":"[106.65257263,10.75360012] ; [106.65178680,10.75351048] ; [106.65180206,10.75333023] ; [106.65180206,10.75300026] ; [106.65180206,10.75242996] ; [106.65180969,10.75181961] ; [106.65180969,10.75142956] ; [106.65186310,10.75115013] ; [106.65193939,10.75100040] ; [106.65107727,10.75096035]"
    ,"Distance":"462"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"278"
    ,"Station_Code":"BX84"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Ch ợ Lớn"
    ,"Station_Address":"GA HKXB CHỢ LỚN B, đường Lê Quang Sung, Quận 6"
    ,"Lat":10.751185417175293
    ,"Long":106.65106964111328
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"464"
    ,"Station_Code":"Q5 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"555, đường Hồng Bàng, Quận 5"
    ,"Lat":10.753331
    ,"Long":106.652334
    ,"Polyline":"[106.65107727,10.75096035] ; [106.65048218,10.75100994] ; [106.65058899,10.75197029] ; [106.65072632,10.75337029] ; [106.65086365,10.75333977] ; [106.65180206,10.75333023] ; [106.65232849,10.75339031]"
    ,"Distance":"505"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"897"
    ,"Station_Code":"Q5 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tạ Uyên"
    ,"Station_Address":"20-22, đường Tạ Uyên, Quận 5"
    ,"Lat":10.754606
    ,"Long":106.65383
    ,"Polyline":"[106.65232849,10.75339031] ; [106.65300751,10.75347042] ; [106.65377808,10.75360012] ; [106.65377808,10.75376987] ; [106.65380859,10.75393963] ; [106.65377045,10.75498962] ; [106.65373230,10.75535011]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1580"
    ,"Station_Code":"Q5 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn Hoàng Hậu"
    ,"Station_Address":"321-323, đường Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.757026
    ,"Long":106.655022
    ,"Polyline":"[106.65373230,10.75535011] ; [106.65370178,10.75566006] ; [106.65370178,10.75631046] ; [106.65368652,10.75687027] ; [106.65454865,10.75699043] ; [106.65500641,10.75708961]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1050"
    ,"Station_Code":"Q5 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Thiếc"
    ,"Station_Address":"235, đường Nguy ễn Chí Thanh, Quận 5"
    ,"Lat":10.757568
    ,"Long":106.657616
    ,"Polyline":"[106.65500641,10.75708961] ; [106.65760803,10.75763035]"
    ,"Distance":"290"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"281"
    ,"Station_Code":"Q5 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"201A, đường  Nguyễn Chí Thanh, Quận 5"
    ,"Lat":10.758079
    ,"Long":106.660128
    ,"Polyline":"[106.65760803,10.75763035] ; [106.65827942,10.75778961] ; [106.66010284,10.75815010]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"503"
    ,"Station_Code":"Q10 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Coop mart Lý Thường Kệt"
    ,"Station_Address":"Coop mart, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.759602
    ,"Long":106.661351
    ,"Polyline":"[106.66010284,10.75815010.06.66062164] ; [10.75825977,106.66149139] ; [10.75844955,106.66127014] ; [10.75930977,106.66120911]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"546"
    ,"Station_Code":"Q10 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Điện Lực Phú Thọ"
    ,"Station_Address":"192, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.76523
    ,"Long":106.659763
    ,"Polyline":"[106.66120911,10.75953007] ; [106.66104126,10.76021004] ; [106.66075897,10.76103973] ; [106.66045380,10.76208973] ; [106.66024017,10.76292038] ; [106.65960693,10.76517010]"
    ,"Distance":"651"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"504"
    ,"Station_Code":"Q10 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Nhà thi  đấu Phú Thọ"
    ,"Station_Address":"260, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.767367
    ,"Long":106.659065
    ,"Polyline":"[106.65960693,10.76517010.06.65937042] ; [10.76607990,106.65899658]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"505"
    ,"Station_Code":"Q10 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Bệnh vi ện Trưng Vương"
    ,"Station_Address":"BV Trưng Vương, đường Lý Thường Kiệt,  Quận 10"
    ,"Lat":10.769652
    ,"Long":106.658524
    ,"Polyline":"[106.65899658,10.76735020] ; [106.65881348,10.76801968] ; [106.65879059,10.76803017] ; [106.65853119,10.76898003] ; [106.65830994,10.76986980]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"506"
    ,"Station_Code":"Q10 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Đại Học Bách Khoa"
    ,"Station_Address":"268, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.772603
    ,"Long":106.657698
    ,"Polyline":"[106.65830994,10.76986980] ; [106.65815735,10.77038956] ; [106.65805054,10.77070999] ; [106.65780640,10.77161026] ; [106.65756989,10.77245045] ; [106.65756226,10.77248955]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"547"
    ,"Station_Code":"Q10 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bưu Điện Phú Thọ"
    ,"Station_Address":"270Bis, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.776487
    ,"Long":106.656625
    ,"Polyline":"[106.65756226,10.77248955] ; [106.65670013,10.77554989] ; [106.65637207,10.77674961]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"507"
    ,"Station_Code":"QTB 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã ba Thành Thái"
    ,"Station_Address":"270 , đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.778974
    ,"Long":106.655896
    ,"Polyline":"[106.65637207,10.77674961] ; [106.65611267,10.77770996] ; [106.65596008,10.77826023] ; [106.65576172,10.77898026]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"548"
    ,"Station_Code":"QTB 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Siêu th ị Nguyễn Kim - CMC Tân Bình"
    ,"Station_Address":"320 (Quận đoàn Tân Bình), đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.781072
    ,"Long":106.65529
    ,"Polyline":"[106.65576172,10.77898026] ; [106.65537262,10.78038025] ; [106.65514374,10.78112030]"
    ,"Distance":"247"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"551"
    ,"Station_Code":"QTB 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Trạm Cây xăng số 9"
    ,"Station_Address":"151A, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.784002
    ,"Long":106.654431
    ,"Polyline":"[106.65514374,10.78112030] ; [106.65432739,10.78398991]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"508"
    ,"Station_Code":"QTB 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Chợ Tân Bình"
    ,"Station_Address":"470, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.786222
    ,"Long":106.653786
    ,"Polyline":"[106.65432739,10.78398991] ; [106.65386963,10.78561974] ; [106.65371704,10.78621006]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"509"
    ,"Station_Code":"QTB 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Bệnh viện chỉnh hình và Phục hồi chức năng"
    ,"Station_Address":"1A (Trung tâm  phục hồi người tàn tật), đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.788689
    ,"Long":106.653076
    ,"Polyline":"[106.65371704,10.78621006] ; [106.65341949,10.78732014] ; [106.65309906,10.78835011] ; [106.65300751,10.78866959]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"553"
    ,"Station_Code":"QTB 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"B ệnh viện Thống Nhất, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.792101
    ,"Long":106.653074
    ,"Polyline":"[106.65300751,10.78866959] ; [106.65258026,10.79028988] ; [106.65248108,10.79076958] ; [106.65254211,10.79104042] ; [106.65270996,10.79156017] ; [106.65299225,10.79216003]"
    ,"Distance":"405"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65299225,10.79216003] ; [106.65318298,10.79253006] ; [106.65337372,10.79290962] ; [106.65367889,10.79327965] ; [106.65387726,10.79349995] ; [106.65458679,10.79424000] ; [106.65502167,10.79463959]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20  (B9), đường Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65502167,10.79463959] ; [106.65577698,10.79539013] ; [106.65576172,10.79541016] ; [106.65515900,10.79603958]"
    ,"Distance":"216"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trường  Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62), đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65515900,10.79603958] ; [106.65464783,10.79654980] ; [106.65390778,10.79584026]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường  Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65390778,10.79584026] ; [106.65238190,10.79434013]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1719"
    ,"Station_Code":"QTB 067"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã tư Bảy Hiền"
    ,"Station_Address":"106, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794182
    ,"Long":106.651191
    ,"Polyline":"[106.65238190,10.79434013] ; [106.65184021,10.79384041] ; [106.65178680,10.79374027] ; [106.65145111,10.79391003] ; [106.65113068,10.79407978]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1720"
    ,"Station_Code":"QTB 068"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nhà Thở Đắc Lộ"
    ,"Station_Address":"150, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.794973
    ,"Long":106.649743
    ,"Polyline":"[106.65113068,10.79407978] ; [106.64964294,10.79487038]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1301"
    ,"Station_Code":"QTB 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Hoàng Hoa Thám"
    ,"Station_Address":"162T,  đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.796137
    ,"Long":106.647565
    ,"Polyline":"[106.64964294,10.79487038] ; [106.64749146,10.79603004]"
    ,"Distance":"268"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2713"
    ,"Station_Code":"QTB 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Ngã ba  Bình Giã"
    ,"Station_Address":"298, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.797792
    ,"Long":106.644453
    ,"Polyline":"[106.64749146,10.79603004] ; [106.64584351,10.79693985] ; [106.64440155,10.79771042]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2200"
    ,"Station_Code":"QTB 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã ba Ấp Bắc"
    ,"Station_Address":"366A, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.799642
    ,"Long":106.641036
    ,"Polyline":"[106.64437866,10.79773045] ; [106.64402008,10.79792023] ; [106.64334106,10.79825974] ; [106.64115906,10.79942036] ; [106.64099121,10.79950047]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2205"
    ,"Station_Code":"QTB 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Chợ Võ Thành Trang"
    ,"Station_Address":"510 , đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.80147
    ,"Long":106.637608
    ,"Polyline":"[106.64099121,10.79950047] ; [106.64040375,10.79981995] ; [106.63889313,10.80064011] ; [106.63755035,10.80136013]"
    ,"Distance":"429"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1302"
    ,"Station_Code":"QTB 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Tân K ỳ Tân Quý"
    ,"Station_Address":"638, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.804626
    ,"Long":106.635656
    ,"Polyline":"[106.63755035,10.80136013] ; [106.63688660,10.80173016] ; [106.63672638,10.80177975] ; [106.63642883,10.80220985] ; [106.63610840,10.80288029] ; [106.63596344,10.80331993] ; [106.63553619,10.80459976]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"2202"
    ,"Station_Code":"QTB 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Thượng  Uyển"
    ,"Station_Address":"680, đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.806202
    ,"Long":106.635184
    ,"Polyline":"[106.63553619,10.80459976] ; [106.63504791,10.80618000]"
    ,"Distance":"183"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"268"
    ,"Station_Code":"QTB 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Mũi tàu Cộng Hòa"
    ,"Station_Address":"19B1, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.808078
    ,"Long":106.634696
    ,"Polyline":"[106.63504791,10.80618000] ; [106.63497925,10.80636978] ; [106.63493347,10.80665970] ; [106.63488007,10.80706978] ; [106.63481903,10.80762005] ; [106.63462067,10.80801010]"
    ,"Distance":"211"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"267"
    ,"Station_Code":"QTB 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Hoa Kiểng Thành Hưng"
    ,"Station_Address":"9B, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.811695
    ,"Long":106.633499
    ,"Polyline":"[106.63462067,10.80801010.06.63450623] ; [10.80827045,106.63417053] ; [10.80928993,106.63343811]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"269"
    ,"Station_Code":"QTB 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Tân S ơn"
    ,"Station_Address":"720, đường Trường Chinh , Quận Tân Bình"
    ,"Lat":10.814638
    ,"Long":106.632584
    ,"Polyline":"[106.63343811,10.81167984] ; [106.63253784,10.81462002]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"270"
    ,"Station_Code":"QTB 078"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Siêu thị Coop Mart Thắng Lợi"
    ,"Station_Address":"792 (25/19), đường Trường  Chinh, Quận Tân Bình"
    ,"Lat":10.817541
    ,"Long":106.631691
    ,"Polyline":"[106.63253784,10.81462002] ; [106.63163757,10.81752968]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"271"
    ,"Station_Code":"QTB 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Khu Công Nghiệp tân Bình"
    ,"Station_Address":"906, đường Trường Chinh, Quận Tân Bình"
    ,"Lat":10.821644
    ,"Long":106.630447
    ,"Polyline":"[106.63163757,10.81752968] ; [106.63038635,10.82162952]"
    ,"Distance":"476"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"272"
    ,"Station_Code":"Q12 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Thiên Hòa"
    ,"Station_Address":"1/17A , đường Trường Chinh, Quận 12"
    ,"Lat":10.82673
    ,"Long":106.626096
    ,"Polyline":"[106.63038635,10.82162952] ; [106.63025665,10.82201958] ; [106.63004303,10.82254028] ; [106.62976837,10.82297993] ; [106.62959290,10.82320023] ; [106.62840271,10.82431984] ; [106.62654877,10.82602024] ; [106.62595367,10.82662010]"
    ,"Distance":"747"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"273"
    ,"Station_Code":"Q12 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Siêu thị Chợ Lớn"
    ,"Station_Address":"189/4, đường Trường Chinh, Quận 12"
    ,"Lat":10.828843
    ,"Long":106.624482
    ,"Polyline":"[106.62595367,10.82662010.06.62528229] ; [10.82740974,106.62447357] ; [10.82857037,106.62435913]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"274"
    ,"Station_Code":"Q12 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa V ĩnh Phước"
    ,"Station_Address":"258, đường Tr ường Chinh, Quận 12"
    ,"Lat":10.832547
    ,"Long":106.622116
    ,"Polyline":"[106.62435913,10.82874012] ; [106.62193298,10.83242035]"
    ,"Distance":"488"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"275"
    ,"Station_Code":"Q12 132"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Chùa Lạc Quang"
    ,"Station_Address":"408, đường Trường Chinh, Quận 12"
    ,"Lat":10.83514
    ,"Long":106.620464
    ,"Polyline":"[106.62193298,10.83242035] ; [106.62024689,10.83504009]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"277"
    ,"Station_Code":"Q12 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Bitis"
    ,"Station_Address":"640, đường Trường Chinh, Quận 12"
    ,"Lat":10.83819
    ,"Long":106.618495
    ,"Polyline":"[106.62024689,10.83504009] ; [106.61829376,10.83808041]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"276"
    ,"Station_Code":"Q12 133"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Chiều"
    ,"Station_Address":"774A, đường  Trường Chinh, Quận 12"
    ,"Lat":10.841436
    ,"Long":106.616457
    ,"Polyline":"[106.61829376,10.83808041] ; [106.61621094,10.84130955]"
    ,"Distance":"425"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1115"
    ,"Station_Code":"Q12 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"116, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.844971
    ,"Long":106.614026
    ,"Polyline":"[106.61621094,10.84130955] ; [106.61564636,10.84220028] ; [106.61560059,10.84230995] ; [106.61559296,10.84243965] ; [106.61566162,10.84257984] ; [106.61566162,10.84274006] ; [106.61560822,10.84286022] ; [106.61556244,10.84292984] ; [106.61546326,10.84298992] ; [106.61534119,10.84300995] ; [106.61528015,10.84300041] ; [106.61518097,10.84311962] ; [106.61475372,10.84370995] ; [106.61396027,10.84490967]"
    ,"Distance":"493"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1117"
    ,"Station_Code":"Q12 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Cư xá Bà Điểm"
    ,"Station_Address":"7C, đường Quốc lộ 22, Quận 12"
    ,"Lat":10.845845
    ,"Long":106.613474
    ,"Polyline":"[106.61396027,10.84490967] ; [106.61338806,10.84578991]"
    ,"Distance":"116"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"1239"
    ,"Station_Code":"HHM 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến xe An Sương"
    ,"Station_Address":"1B, đường Quốc lộ 22, Huyện Hóc Môn"
    ,"Lat":10.84465
    ,"Long":106.613849
    ,"Polyline":"[106.61338806,10.84578991] ; [106.61289215,10.84657955] ; [106.61244202,10.84726048] ; [106.61237335,10.84720993] ; [106.61244202,10.84710026] ; [106.61327362,10.84582043] ; [106.61396027,10.84473038]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"103"
    ,"Station_Id":"166"
    ,"Station_Code":"BX41"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe An  Sương"
    ,"Station_Address":"Bến xe An Sương,  đường Quốc lộ 22, Quận 12"
    ,"Lat":10.843737602233887
    ,"Long":106.61337280273438
    ,"Polyline":"[106.61396030,10.84473038] ; [106.61405180,10.84459972] ; [106.61408930,10.84450118] ; [106.61406240,10.84441844] ; [106.61400330,10.84434624] ; [106.61393350,10.84428457] ; [106.61365630,10.84405216] ; [106.61343970,10.84385818] ; [106.61328200,10.84374541] ; [106.61298540,10.84354619]"
    ,"Distance":"160"
  }]