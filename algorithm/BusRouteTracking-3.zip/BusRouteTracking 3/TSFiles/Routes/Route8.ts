export const Route8 =[
  {
     "Route_Id":"8"
    ,"Station_Id":"538"
    ,"Station_Code":"BX87"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Đại học Quốc gia"
    ,"Station_Address":"Bến xe buýt Khu A Đô thị Quốc gia, đường  Đường nội bộ Đại học Quốc gia, Quận Thủ Đức"
    ,"Lat":10.873805046081543
    ,"Long":106.8020248413086
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"572"
    ,"Station_Code":"QTD 175"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"621-Ngã 3 Lâm Viên"
    ,"Station_Address":"Nhà máy Tiến Thành, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.871128
    ,"Long":106.806979
    ,"Polyline":"[106.80202484,10.87380505] ; [106.80168915,10.87372589] ; [106.80120850,10.87388897] ; [106.80061340,10.87418365] ; [106.80022430,10.87440491] ; [106.80001068,10.87479496] ; [106.79991913,10.87552738] ; [106.80005646,10.87563801] ; [106.80018616,10.87570095] ; [106.80043793,10.87577534] ; [106.80070496,10.87581158] ; [106.80146790,10.87584877] ; [106.80199432,10.87600136] ; [106.80262756,10.87613869] ; [106.80310059,10.87633324] ; [106.80319977,10.87647057] ; [106.80328369,10.87645435] ; [106.80334473,10.87640190] ; [106.80442810,10.87605953] ; [106.80480957,10.87578583] ; [106.80498505,10.87561703] ; [106.80510712,10.87542152] ; [106.80535126,10.87523746] ; [106.80563354,10.87492657] ; [106.80659485,10.87450504] ; [106.80759430,10.87391567] ; [106.80845642,10.87309361] ; [106.80697632,10.87112808]"
    ,"Distance":"1702"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"576"
    ,"Station_Code":"QTD 176"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường giáo dục Quốc phòng"
    ,"Station_Address":"Trường giáo dục Quốc phòng,  đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.868216
    ,"Long":106.804367
    ,"Polyline":"[106.80697632,10.87112808] ; [106.80583191,10.86964798] ; [106.80436707,10.86821556]"
    ,"Distance":"433"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"574"
    ,"Station_Code":"QTD 177"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Khu DL Suối Tiên"
    ,"Station_Address":"9/29, đường  Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.86605
    ,"Long":106.801116
    ,"Polyline":"[106.80436707,10.86821556] ; [106.80284119,10.86704540] ; [106.80111694,10.86604977]"
    ,"Distance":"430"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"4560"
    ,"Station_Code":"QTD 178"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"18/1, đường Quốc lộ 1, Quận Thủ Đức"
    ,"Lat":10.865613
    ,"Long":106.800381
    ,"Polyline":"[106.80111694,10.86604977] ; [106.80038452,10.86561298]"
    ,"Distance":"94"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"398"
    ,"Station_Code":"QTD 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Khu Công nghệ cao Q9"
    ,"Station_Address":"Đối diện Khu công nghệ cao, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.860545
    ,"Long":106.791723
    ,"Polyline":"[106.80038452,10.86561298] ; [106.79172516,10.86054516]"
    ,"Distance":"1102"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"401"
    ,"Station_Code":"QTD 076"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Công ty Cocacola"
    ,"Station_Address":"Công ty Cocacola, đường Xa Lộ Hà Nội, Quận Thủ Đức"
    ,"Lat":10.856483
    ,"Long":106.784964
    ,"Polyline":"[106.79172516,10.86054516] ; [106.78496552,10.85648346]"
    ,"Distance":"866"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"400"
    ,"Station_Code":"QTD 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường Đại học Sư phạm Kỹ thuật"
    ,"Station_Address":"1,  đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849823
    ,"Long":106.772089
    ,"Polyline":"[106.78496552,10.85648346] ; [106.77604675,10.85113525] ; [106.77451324,10.84994984] ; [106.77423096,10.84979725] ; [106.77400208,10.84972286] ; [106.77359772,10.84971237] ; [106.77231598,10.84976006] ; [106.77208710,10.84982300]"
    ,"Distance":"1627"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"402"
    ,"Station_Code":"QTD 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Siêu thị Nguy ễn Kim"
    ,"Station_Address":"312, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849805
    ,"Long":106.768837
    ,"Polyline":"[106.77208710,10.84982300] ; [106.77186584,10.84981251] ; [106.77159119,10.84974957] ; [106.76883698,10.84980488]"
    ,"Distance":"356"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"403"
    ,"Station_Code":"QTD 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nhà thiếu nhi Thủ Đức"
    ,"Station_Address":"Nhà thiếu nhi, đường Võ Văn Ngân, Quận  Thủ Đức"
    ,"Lat":10.850556
    ,"Long":106.766794
    ,"Polyline":"[106.76883698,10.84980488] ; [106.76820374,10.84979725] ; [106.76780701,10.84988117] ; [106.76757813,10.85010815] ; [106.76734924,10.85037613] ; [106.76725769,10.85045052] ; [106.76710510,10.85051918] ; [106.76679230,10.85055637]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"404"
    ,"Station_Code":"QTD 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"231, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850808
    ,"Long":106.764101
    ,"Polyline":"[106.76679230,10.85055637] ; [106.76409912,10.85080814]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"405"
    ,"Station_Code":"QTD 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"95, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850679
    ,"Long":106.75943
    ,"Polyline":"[106.76409912,10.85080814] ; [106.76284790,10.85091400] ; [106.76264954,10.85086155] ; [106.76235199,10.85068226] ; [106.76210022,10.85057163] ; [106.76186371,10.85053444] ; [106.76126099,10.85053444] ; [106.76064301,10.85057640] ; [106.75942993,10.85067940]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"3277"
    ,"Station_Code":"QTD 145"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Thủ  Đức"
    ,"Station_Address":"20-21, đường Lê Văn Ninh,  Quận Thủ Đức"
    ,"Lat":10.850327
    ,"Long":106.754005
    ,"Polyline":"[106.75942993,10.85067940] ; [106.75865936,10.85069752] ; [106.75813293,10.85099316] ; [106.75761414,10.85114574] ; [106.75720215,10.85129833] ; [106.75698090,10.85130882] ; [106.75605011,10.85119820] ; [106.75563812,10.85119343] ; [106.75525665,10.85122490] ; [106.75507355,10.85120392] ; [106.75497437,10.85120869] ; [106.75488281,10.85117245] ; [106.75468445,10.85105038] ; [106.75400543,10.85032654]"
    ,"Distance":"649"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"575"
    ,"Station_Code":"QTD 146"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trạm Cầu ngang"
    ,"Station_Address":"581, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.847199
    ,"Long":106.751587
    ,"Polyline":"[106.75400543,10.85032654] ; [106.75347137,10.84960747] ; [106.75365448,10.84942818] ; [106.75283813,10.84848022] ; [106.75206757,10.84762669] ; [106.75158691,10.84719944]"
    ,"Distance":"463"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"578"
    ,"Station_Code":"QTD 147"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Công an Phường Linh Đông"
    ,"Station_Address":"517, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.845116
    ,"Long":106.749763
    ,"Polyline":"[106.75158691,10.84719944] ; [106.75132751,10.84689903] ; [106.75088501,10.84648800] ; [106.75057983,10.84613037] ; [106.75012970,10.84549809] ; [106.74976349,10.84511566]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"577"
    ,"Station_Code":"QTD 148"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Công ty 27-7"
    ,"Station_Address":"Đối diện 624, đường Kha Vạn Cân, Quận  Thủ Đức"
    ,"Lat":10.841721
    ,"Long":106.74659
    ,"Polyline":"[106.74976349,10.84511566] ; [106.74825287,10.84343243] ; [106.74742126,10.84244728] ; [106.74658966,10.84172058]"
    ,"Distance":"514"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"579"
    ,"Station_Code":"QTD 149"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trường Cao đẳng Vinatex"
    ,"Station_Address":"403, đường Kha V ạn Cân, Quận Thủ Đức"
    ,"Lat":10.840851
    ,"Long":106.744548
    ,"Polyline":"[106.74658966,10.84172058] ; [106.74618530,10.84130383] ; [106.74573517,10.84086704] ; [106.74536896,10.84078217] ; [106.74516296,10.84076691] ; [106.74497223,10.84078217] ; [106.74454498,10.84085083]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"580"
    ,"Station_Code":"QTD 150"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Hòa Phát"
    ,"Station_Address":"Đối diện 546, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.840643
    ,"Long":106.741516
    ,"Polyline":"[106.74454498,10.84085083] ; [106.74353027,10.84095097] ; [106.74310303,10.84098244] ; [106.74210358,10.84079266] ; [106.74151611,10.84064293]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"581"
    ,"Station_Code":"QTD 151"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Phố Mơ"
    ,"Station_Address":"Đối diện 492, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.839357
    ,"Long":106.736404
    ,"Polyline":"[106.74151611,10.84064293] ; [106.74062347,10.84031868] ; [106.73973083,10.83997631] ; [106.73881531,10.83974934] ; [106.73830414,10.83962822] ; [106.73786926,10.83953857] ; [106.73718262,10.83947086] ; [106.73640442,10.83935738]"
    ,"Distance":"580"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"582"
    ,"Station_Code":"QTD 152"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chợ Hiệp Bình"
    ,"Station_Address":"Đối diện 80/4C,  đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.837489
    ,"Long":106.732269
    ,"Polyline":"[106.73640442,10.83935738] ; [106.73489380,10.83894348] ; [106.73348999,10.83830070] ; [106.73226929,10.83748913]"
    ,"Distance":"502"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"583"
    ,"Station_Code":"QTD 153"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Đường Sông  Đà"
    ,"Station_Address":"Đối diện 394, đường Kha  Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.835314
    ,"Long":106.729576
    ,"Polyline":"[106.73226929,10.83748913] ; [106.72957611,10.83531380]"
    ,"Distance":"381"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"585"
    ,"Station_Code":"QTD 154"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Trường Hiệp Bình Chánh"
    ,"Station_Address":"Đối diện 338, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.832879
    ,"Long":106.726608
    ,"Polyline":"[106.72957611,10.83531380] ; [106.72972870,10.83519268] ; [106.72824860,10.83395958] ; [106.72681427,10.83273697] ; [106.72660828,10.83287907]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"584"
    ,"Station_Code":"QTD 155"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Chùa Ưu Đàm"
    ,"Station_Address":"Đối diện 254-256, đường Kha  Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.829175
    ,"Long":106.721909
    ,"Polyline":"[106.72660828,10.83287907] ; [106.72676086,10.83269501] ; [106.72203827,10.82890129] ; [106.72190857,10.82917500]"
    ,"Distance":"727"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"587"
    ,"Station_Code":"QTD 156"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Trạm y tế P. Hiệp Bình Chánh"
    ,"Station_Address":"Đối diện 190, đường Kha Vạn Cân, Quận  Thủ Đức"
    ,"Lat":10.828172
    ,"Long":106.719185
    ,"Polyline":"[106.72190857,10.82917500] ; [106.72209167,10.82892799] ; [106.72083282,10.82810593] ; [106.71987915,10.82765293] ; [106.71941376,10.82749462] ; [106.71918488,10.82817173]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"586"
    ,"Station_Code":"QTD 157"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Ga Bình Triệu"
    ,"Station_Address":"Đối diện 114, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.827418
    ,"Long":106.716507
    ,"Polyline":"[106.71918488,10.82817173] ; [106.71939087,10.82748890] ; [106.71872711,10.82724190] ; [106.71762085,10.82698822] ; [106.71665955,10.82671452] ; [106.71650696,10.82741833]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"361"
    ,"Station_Code":"QBTH 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"78/3, đường Đinh Bộ Lĩnh, Quận Bình Th ạnh"
    ,"Lat":10.816661
    ,"Long":106.711257
    ,"Polyline":"[106.71650696,10.82741833] ; [106.71675873,10.82670975] ; [106.71455383,10.82618237] ; [106.71443176,10.82622433] ; [106.71427917,10.82625580] ; [106.71400452,10.82623482] ; [106.71386719,10.82609844] ; [106.71380615,10.82588768] ; [106.71384430,10.82567692] ; [106.71395111,10.82548714] ; [106.71340942,10.82298946] ; [106.71314240,10.82068157] ; [106.71276093,10.81784725] ; [106.71211243,10.81724644] ; [106.71125793,10.81666088]"
    ,"Distance":"1559"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"362"
    ,"Station_Code":"QBTH 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Ngã Tư Nguyễn Xí"
    ,"Station_Address":"291-293, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.812625
    ,"Long":106.709223
    ,"Polyline":"[106.71125793,10.81666088] ; [106.71115875,10.81656647] ; [106.71063232,10.81564426] ; [106.70983887,10.81410599] ; [106.70922089,10.81262493]"
    ,"Distance":"503"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"363"
    ,"Station_Code":"QBTH 040"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Ngã Tư Chu Văn An"
    ,"Station_Address":"183, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.809759
    ,"Long":106.709143
    ,"Polyline":"[106.70922089,10.81262493] ; [106.70911407,10.81207180] ; [106.70914459,10.80975914]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"364"
    ,"Station_Code":"QBTH 041"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Đinh Bộ Lĩnh"
    ,"Station_Address":"85, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.806908
    ,"Long":106.709341
    ,"Polyline":"[106.70914459,10.80975914] ; [106.70934296,10.80690765]"
    ,"Distance":"318"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"365"
    ,"Station_Code":"QBTH 042"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Trạm xăng dầu"
    ,"Station_Address":"17, đường Đinh Bộ Lĩnh, Quận Bình Thạnh"
    ,"Lat":10.804421
    ,"Long":106.709395
    ,"Polyline":"[106.70934296,10.80690765] ; [106.70948792,10.80553818] ; [106.70939636,10.80442142]"
    ,"Distance":"278"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"588"
    ,"Station_Code":"QBTH 002"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"96, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803177
    ,"Long":106.708032
    ,"Polyline":"[106.70939636,10.80442142] ; [106.70935822,10.80307198] ; [106.70803070,10.80317688]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"589"
    ,"Station_Code":"QBTH 003"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chùa Bồ Đề"
    ,"Station_Address":"246, đường  Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803483
    ,"Long":106.704015
    ,"Polyline":"[106.70803070,10.80317688] ; [106.70401764,10.80348301]"
    ,"Distance":"441"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"590"
    ,"Station_Code":"QBTH 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Tòa Án nhân dân Quận Bình Thạnh"
    ,"Station_Address":"288, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803757
    ,"Long":106.700968
    ,"Polyline":"[106.70401764,10.80348301] ; [106.70351410,10.80352020] ; [106.70281982,10.80363083] ; [106.70153046,10.80393600] ; [106.70096588,10.80375671]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"592"
    ,"Station_Code":"QBTH 005"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"368, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803125
    ,"Long":106.699374
    ,"Polyline":"[106.70096588,10.80375671] ; [106.69937134,10.80312538]"
    ,"Distance":"188"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"591"
    ,"Station_Code":"QBTH 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"UBND Quận Bình Thạnh"
    ,"Station_Address":"6-8, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802819
    ,"Long":106.695786
    ,"Polyline":"[106.69937134,10.80312538] ; [106.69800568,10.80253410.06.69578552]"
    ,"Distance":"408"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"594"
    ,"Station_Code":"QBTH 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bệnh Viện Gia Định"
    ,"Station_Address":"10, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803088
    ,"Long":106.693586
    ,"Polyline":"[106.69578552,10.80281925] ; [106.69358826,10.80308819]"
    ,"Distance":"242"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"593"
    ,"Station_Code":"QBTH 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Công an PCCC, Quận Bình Thạnh"
    ,"Station_Address":"14-16, đường Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803362
    ,"Long":106.691473
    ,"Polyline":"[106.69358826,10.80308819] ; [106.69147491,10.80336189]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"595"
    ,"Station_Code":"QPN 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Bệnh viện  Phước An"
    ,"Station_Address":"36A, đường Phan  Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803894
    ,"Long":106.687535
    ,"Polyline":"[106.69147491,10.80336189] ; [106.68753815,10.80389404]"
    ,"Distance":"435"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"596"
    ,"Station_Code":"QPN 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"68, đường Phan  Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.804063
    ,"Long":106.686269
    ,"Polyline":"[106.68753815,10.80389404] ; [106.68692780,10.80394173] ; [106.68627167,10.80406284]"
    ,"Distance":"140"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"597"
    ,"Station_Code":"QPN 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"124, đường Phan  Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.802629
    ,"Long":106.683689
    ,"Polyline":"[106.68627167,10.80406284] ; [106.68598175,10.80406284] ; [106.68556976,10.80405235] ; [106.68534851,10.80401039] ; [106.68513489,10.80392075] ; [106.68473816,10.80362034] ; [106.68368530,10.80262947]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"598"
    ,"Station_Code":"QPN 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"172, đường Phan  Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.800854
    ,"Long":106.681833
    ,"Polyline":"[106.68368530,10.80262947] ; [106.68289948,10.80179119] ; [106.68183136,10.80085373]"
    ,"Distance":"284"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"599"
    ,"Station_Code":"QPN 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"24, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.79931
    ,"Long":106.679354
    ,"Polyline":"[106.68183136,10.80085373] ; [106.68171692,10.80069065] ; [106.68044281,10.79944706] ; [106.68019867,10.79929352] ; [106.67926025,10.79936790]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"601"
    ,"Station_Code":"QPN 011"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"202, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.800153
    ,"Long":106.669559
    ,"Polyline":"[106.67926025,10.79936790] ; [106.66954041,10.80016899]"
    ,"Distance":"1067"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"256"
    ,"Station_Code":"QTB 099"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Cổng trước SVĐ Quân Khu 7"
    ,"Station_Address":"A2  (Sân vận động Quân khu 7), đường Phan Đình Giót, Quận Tân Bình"
    ,"Lat":10.800848
    ,"Long":106.66678
    ,"Polyline":"[106.66954041,10.80016899] ; [106.66925049,10.80016327] ; [106.66802979,10.80024719] ; [106.66762543,10.80032158] ; [106.66698456,10.80069065] ; [106.66662598,10.80095100]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"257"
    ,"Station_Code":"QTB 108"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Công viên Hoàng Văn Thụ"
    ,"Station_Address":"Công viên Hoàng Văn Thụ, đường Phan Thúc Duyện, Quận Tân Bình"
    ,"Lat":10.802403
    ,"Long":106.664221
    ,"Polyline":"[106.66662598,10.80095100] ; [106.66416931,10.80236053]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"258"
    ,"Station_Code":"QTB 107"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"20, đường Trần Quốc Hoàn, Quận Tân Bình"
    ,"Lat":10.801365
    ,"Long":106.662312
    ,"Polyline":"[106.66416931,10.80236053] ; [106.66357422,10.80268192] ; [106.66230011,10.80137253]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"600"
    ,"Station_Code":"QTB 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Lăng Cha Cả"
    ,"Station_Address":"216, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.799836
    ,"Long":106.660385
    ,"Polyline":"[106.66230011,10.80137253] ; [106.66171265,10.80082703] ; [106.66140747,10.80073738] ; [106.66107941,10.80070114] ; [106.66094208,10.80062675] ; [106.66085052,10.80052185] ; [106.66081238,10.80039501] ; [106.66080475,10.80022621] ; [106.66038513,10.79983616]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"602"
    ,"Station_Code":"QTB 039"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"Công an Quận Tân Bình"
    ,"Station_Address":"340H, đường Hoàng Văn Thụ , Quận Tân Bình"
    ,"Lat":10.796577
    ,"Long":106.656952
    ,"Polyline":"[106.66038513,10.79983616] ; [106.65862274,10.79824543] ; [106.65695190,10.79657745]"
    ,"Distance":"522"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"604"
    ,"Station_Code":"QTB 064"
    ,"Station_Direction":"0"
    ,"Station_Order":"48"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"20 (B9), đư ờng Xuân Diệu, Quận Tân Bình"
    ,"Lat":10.796081
    ,"Long":106.655197
    ,"Polyline":"[106.65695190,10.79657745] ; [106.65575409,10.79549503] ; [106.65519714,10.79608059]"
    ,"Distance":"267"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"603"
    ,"Station_Code":"QTB 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"49"
    ,"Station_Name":"Trường Phạm Ngũ Lão"
    ,"Station_Address":"149 (E62),  đường Xuân Hồng, Quận Tân Bình"
    ,"Lat":10.795853
    ,"Long":106.653879
    ,"Polyline":"[106.65519714,10.79608059] ; [106.65464783,10.79655933] ; [106.65386963,10.79587364]"
    ,"Distance":"194"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"606"
    ,"Station_Code":"QTB 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"50"
    ,"Station_Name":"Cây xăng dầu"
    ,"Station_Address":"23, đường Xuân Hồng, Qu ận Tân Bình"
    ,"Lat":10.794379
    ,"Long":106.652336
    ,"Polyline":"[106.65386963,10.79587364] ; [106.65233612,10.79437923]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"605"
    ,"Station_Code":"QTB 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"51"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"733-739, đường Lý Thường Kiệt, Quận T ân Bình"
    ,"Lat":10.792122
    ,"Long":106.6528
    ,"Polyline":"[106.65233612,10.79437923] ; [106.65177917,10.79384041] ; [106.65311432,10.79302883] ; [106.65316772,10.79279613] ; [106.65310669,10.79255390] ; [106.65287781,10.79208755]"
    ,"Distance":"370"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"608"
    ,"Station_Code":"QTB 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"52"
    ,"Station_Name":"Bệnh việnBệnh viện chỉnh hình và phục hồi ch ức năng"
    ,"Station_Address":"589 , đường Lý Th ường Kiệt, Quận Tân Bình"
    ,"Lat":10.788718
    ,"Long":106.652806
    ,"Polyline":"[106.65287781,10.79208755] ; [106.65249634,10.79103661] ; [106.65237427,10.79027748] ; [106.65238190,10.79017735] ; [106.65242767,10.79012489] ; [106.65249634,10.79007244] ; [106.65255737,10.79005623] ; [106.65267944,10.78979301] ; [106.65269470,10.78950310.06.65284729]"
    ,"Distance":"371"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"607"
    ,"Station_Code":"QTB 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"53"
    ,"Station_Name":"Chợ Tân Bình"
    ,"Station_Address":"Chợ Tân Bình, đường Lý Thường Kiệt, Quận T ân Bình"
    ,"Lat":10.786131
    ,"Long":106.653584
    ,"Polyline":"[106.65284729,10.78897381] ; [106.65364838,10.78616047]"
    ,"Distance":"325"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"610"
    ,"Station_Code":"QTB 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"54"
    ,"Station_Name":"Siêu thị Nguyễn Kim - CMC Tân Bình"
    ,"Station_Address":"79B (siêu thị CMC Tân Bình), đường L ý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.782695
    ,"Long":106.654571
    ,"Polyline":"[106.65364838,10.78616047] ; [106.65461731,10.78270817]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"609"
    ,"Station_Code":"QTB 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"55"
    ,"Station_Name":"Trường Nguyễn Thái Bình"
    ,"Station_Address":"349 (74), đường Lý Thường Kiệt, Quận  Tân Bình"
    ,"Lat":10.779233
    ,"Long":106.655609
    ,"Polyline":"[106.65461731,10.78270817] ; [106.65560913,10.77923298]"
    ,"Distance":"402"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"612"
    ,"Station_Code":"Q11 016"
    ,"Station_Direction":"0"
    ,"Station_Order":"56"
    ,"Station_Name":"Bưu Điện Phú Thọ"
    ,"Station_Address":"285A, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.775314
    ,"Long":106.656693
    ,"Polyline":"[106.65560913,10.77923298] ; [106.65669250,10.77531433]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"611"
    ,"Station_Code":"Q11 017"
    ,"Station_Direction":"0"
    ,"Station_Order":"57"
    ,"Station_Name":"Đại Học Bách Khoa(cổng trước)"
    ,"Station_Address":"239, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.771331
    ,"Long":106.657829
    ,"Polyline":"[106.65669250,10.77531433] ; [106.65782928,10.77133083]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"613"
    ,"Station_Code":"Q11 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"58"
    ,"Station_Name":"BV Trưng Vương"
    ,"Station_Address":"Đối diện 266, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.769639
    ,"Long":106.658295
    ,"Polyline":"[106.65782928,10.77133083] ; [106.65829468,10.76963902]"
    ,"Distance":"195"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"614"
    ,"Station_Code":"Q11 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"59"
    ,"Station_Name":"Điện Lực Phú Thọ"
    ,"Station_Address":"215C, đường Lý Thường Kiệt, Quận 11"
    ,"Lat":10.765792
    ,"Long":106.659363
    ,"Polyline":"[106.65829468,10.76963902] ; [106.65936279,10.76579189]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"615"
    ,"Station_Code":"Q11 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"60"
    ,"Station_Name":"Chợ Nhật  Tảo"
    ,"Station_Address":"151, đường Lý Thường  Kiệt, Quận 11"
    ,"Lat":10.761718
    ,"Long":106.660484
    ,"Polyline":"[106.65936279,10.76579189] ; [106.66048431,10.76171780]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"616"
    ,"Station_Code":"Q5 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"61"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"Hông Bệnh viện Hùng Vương, đường Lý Th ường Kiệt, Quận 5"
    ,"Lat":10.755702
    ,"Long":106.66221
    ,"Polyline":"[106.66048431,10.76171780] ; [106.66220856,10.75570202]"
    ,"Distance":"696"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"434"
    ,"Station_Code":"Q5 018"
    ,"Station_Direction":"0"
    ,"Station_Order":"62"
    ,"Station_Name":"Bệnh viện Hùng Vương"
    ,"Station_Address":"132, đường H ồng Bàng, Quận 5"
    ,"Lat":10.755196
    ,"Long":106.661072
    ,"Polyline":"[106.66220856,10.75570202] ; [106.66234589,10.75540733] ; [106.66107178,10.75519562]"
    ,"Distance":"177"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"436"
    ,"Station_Code":"Q5 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"63"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"172, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754875
    ,"Long":106.659501
    ,"Polyline":"[106.66107178,10.75519562] ; [106.65950012,10.75487518]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"397"
    ,"Station_Code":"Q5 013"
    ,"Station_Direction":"0"
    ,"Station_Order":"64"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"81 , đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752445
    ,"Long":106.658792
    ,"Polyline":"[106.65950012,10.75487518] ; [106.65823364,10.75456905] ; [106.65821075,10.75424194] ; [106.65859985,10.75310421] ; [106.65879059,10.75244522]"
    ,"Distance":"389"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"137"
    ,"Station_Code":"Q5 014"
    ,"Station_Direction":"0"
    ,"Station_Order":"65"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"13-15, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.751381
    ,"Long":106.658894
    ,"Polyline":"[106.65879059,10.75244522] ; [106.65889740,10.75138092]"
    ,"Distance":"119"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"617"
    ,"Station_Code":"Q8 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"66"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"388, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.74483
    ,"Long":106.656926
    ,"Polyline":"[106.65889740,10.75138092] ; [106.65905762,10.75088501] ; [106.65901947,10.75078487] ; [106.65907288,10.75065899] ; [106.65917206,10.75060558] ; [106.65929413,10.75060558] ; [106.65965271,10.75050068] ; [106.65982056,10.75041103] ; [106.65991974,10.75021553] ; [106.66042328,10.74874020] ; [106.66049957,10.74831867] ; [106.66050720,10.74790764] ; [106.66036224,10.74702168] ; [106.65978241,10.74688530] ; [106.65922546,10.74632645] ; [106.65883636,10.74577808] ; [106.65692902,10.74483013]"
    ,"Distance":"1024"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"618"
    ,"Station_Code":"Q8 069"
    ,"Station_Direction":"0"
    ,"Station_Order":"67"
    ,"Station_Name":"Chùa Pha ́p Quang"
    ,"Station_Address":"100, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738642
    ,"Long":106.656142
    ,"Polyline":"[106.65692902,10.74483013] ; [106.65617371,10.74440765] ; [106.65563965,10.74380684] ; [106.65553284,10.74354362] ; [106.65547943,10.74324799] ; [106.65550995,10.74296379] ; [106.65557098,10.74267960] ; [106.65628052,10.74075031] ; [106.65614319,10.73864174]"
    ,"Distance":"776"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"619"
    ,"Station_Code":"Q8 070"
    ,"Station_Direction":"0"
    ,"Station_Order":"68"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"224, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656126
    ,"Polyline":"[106.65614319,10.73864174] ; [106.65618896,10.73756695] ; [106.65612793,10.73645973]"
    ,"Distance":"243"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"0"
    ,"Station_Order":"69"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":"[106.65612793,10.73645973] ; [106.65608978,10.73351955] ; [106.65635681,10.73354530]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường Quốc lộ 50, Qu ận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"502"
    ,"Station_Code":"Q8 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"193, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656346
    ,"Polyline":"[106.65635681,10.73354530] ; [106.65621948,10.73355579] ; [106.65634918,10.73645973]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"499"
    ,"Station_Code":"Q8 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Cầu Nhị Thiên Đường"
    ,"Station_Address":"81 , đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738769
    ,"Long":106.656427
    ,"Polyline":"[106.65634918,10.73645973] ; [106.65633392,10.73764038] ; [106.65635681,10.73822021] ; [106.65642548,10.73876858]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"542"
    ,"Station_Code":"Q8 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"487, đường Tùng Thi ện Vương, Quận 8"
    ,"Lat":10.744513
    ,"Long":106.656802
    ,"Polyline":"[106.65642548,10.73876858] ; [106.65637970,10.73930645] ; [106.65648651,10.74062347] ; [106.65644073,10.74089813] ; [106.65567017,10.74299526] ; [106.65563965,10.74319553] ; [106.65564728,10.74340630] ; [106.65567780,10.74362755] ; [106.65579224,10.74388123] ; [106.65606689,10.74421787] ; [106.65679932,10.74451256]"
    ,"Distance":"723"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"501"
    ,"Station_Code":"Q8 112"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Chợ Xóm Củi"
    ,"Station_Address":"337, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.746073
    ,"Long":106.659763
    ,"Polyline":"[106.65679932,10.74451256] ; [106.65747070,10.74495125] ; [106.65880585,10.74568367] ; [106.65943146,10.74597359] ; [106.65975952,10.74607277]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"3"
    ,"Station_Code":"Q5 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Bưu điện Quận 5"
    ,"Station_Address":"14-16, đường  Châu Văn Liêm, Quận 5"
    ,"Lat":10.751368
    ,"Long":106.659203
    ,"Polyline":"[106.65975810,10.74608390] ; [106.66002630,10.74629472] ; [106.66040180,10.74651607] ; [106.66048770,10.74670580] ; [106.66064860,10.74793906] ; [106.66068080,10.74828690] ; [106.66054130,10.74886663] ; [106.66006920,10.75021582] ; [106.66015510,10.75035285] ; [106.66046620,10.75051096] ; [106.66085240,10.75078501] ; [106.66121720,10.75097474] ; [106.66148540,10.75102744] ; [106.66146930,10.75120136] ; [106.66140760,10.75119873] ; [106.66118500,10.75114339] ; [106.66070220,10.75087988] ; [106.66036960,10.75066907] ; [106.66017120,10.75053994] ; [106.66003840,10.75052677] ; [106.65991100,10.75054521] ; [106.65953010,10.75067434] ; [106.65929140,10.75077974] ; [106.65925650,10.75082717] ; [106.65922030,10.75083771] ; [106.65915730,10.75137528]"
    ,"Distance":"967"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"5"
    ,"Station_Code":"Q5 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Rạp Đại Quang"
    ,"Station_Address":"68, đường Châu Văn Liêm, Quận 5"
    ,"Lat":10.752566
    ,"Long":106.658937
    ,"Polyline":"[106.65920258,10.75136757] ; [106.65893555,10.75256634]"
    ,"Distance":"136"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"437"
    ,"Station_Code":"Q5 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bệnh viện Chợ Rẫy"
    ,"Station_Address":"357-359, đường Hồng Bàng, Quận 5"
    ,"Lat":10.754553
    ,"Long":106.659232
    ,"Polyline":"[106.65893555,10.75256634] ; [106.65885925,10.75306702] ; [106.65869904,10.75350952] ; [106.65851593,10.75423717] ; [106.65842438,10.75446892] ; [106.65923309,10.75455284]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"544"
    ,"Station_Code":"Q5 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Hùng Vương Plaza"
    ,"Station_Address":"4, đường Lý Thường Kiệt, Quận 5"
    ,"Lat":10.756013
    ,"Long":106.662333
    ,"Polyline":"[106.65923309,10.75455284] ; [106.66245270,10.75528049] ; [106.66233063,10.75601292]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"503"
    ,"Station_Code":"Q10 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Coop mart Lý Thường Kệt"
    ,"Station_Address":"Coop mart, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.759602
    ,"Long":106.661351
    ,"Polyline":"[106.66233063,10.75601292] ; [106.66125488,10.75953674]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"546"
    ,"Station_Code":"Q10 052"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Điện Lực Phú Thọ"
    ,"Station_Address":"192,  đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.76523
    ,"Long":106.659763
    ,"Polyline":"[106.66125488,10.75953674] ; [106.65962219,10.76517105]"
    ,"Distance":"652"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"504"
    ,"Station_Code":"Q10 053"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nhà thi đấu Phú Thọ"
    ,"Station_Address":"260, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.767367
    ,"Long":106.659065
    ,"Polyline":"[106.65962219,10.76517105] ; [106.65906525,10.76736736]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"505"
    ,"Station_Code":"Q10 054"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bệnh viện Trưng Vương"
    ,"Station_Address":"BV Trưng Vương, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.769652
    ,"Long":106.658524
    ,"Polyline":"[106.65906525,10.76736736] ; [106.65836334,10.76988888]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"506"
    ,"Station_Code":"Q10 055"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Đại Học Bách Khoa"
    ,"Station_Address":"268, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.772603
    ,"Long":106.657698
    ,"Polyline":"[106.65836334,10.76988888] ; [106.65758514,10.77249527]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"547"
    ,"Station_Code":"Q10 056"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Bưu Điện Phú Thọ"
    ,"Station_Address":"270Bis, đường Lý Thường Kiệt, Quận 10"
    ,"Lat":10.776487
    ,"Long":106.656625
    ,"Polyline":"[106.65758514,10.77249527] ; [106.65641785,10.77676105]"
    ,"Distance":"492"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"507"
    ,"Station_Code":"QTB 023"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Ngã ba Thành Thái"
    ,"Station_Address":"270 , đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.778974
    ,"Long":106.655896
    ,"Polyline":"[106.65641785,10.77676105] ; [106.65582275,10.77899265]"
    ,"Distance":"257"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"548"
    ,"Station_Code":"QTB 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Siêu thị  Nguyễn Kim - CMC Tân Bình"
    ,"Station_Address":"320 (Quận đoàn Tân Bình), đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.781072
    ,"Long":106.65529
    ,"Polyline":"[106.65582275,10.77899265] ; [106.65519714,10.78113461]"
    ,"Distance":"248"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"551"
    ,"Station_Code":"QTB 025"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Trạm Cây xăng số 9"
    ,"Station_Address":"151A , đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.784002
    ,"Long":106.654431
    ,"Polyline":"[106.65519714,10.78113461] ; [106.65439606,10.78401470]"
    ,"Distance":"332"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"508"
    ,"Station_Code":"QTB 026"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Tân B ình"
    ,"Station_Address":"470, đường Lý Thường  Kiệt, Quận Tân Bình"
    ,"Lat":10.786222
    ,"Long":106.653786
    ,"Polyline":"[106.65439606,10.78401470] ; [106.65378571,10.78622246]"
    ,"Distance":"255"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"509"
    ,"Station_Code":"QTB 027"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Bệnh viện chỉnh hình và Phục h ồi chức năng"
    ,"Station_Address":"1A (Trung t âm phục hồi người tàn tật), đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.788689
    ,"Long":106.653076
    ,"Polyline":"[106.65378571,10.78622246] ; [106.65307617,10.78868866]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"553"
    ,"Station_Code":"QTB 028"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Bệnh viện Thống Nhất"
    ,"Station_Address":"B ệnh viện Thống Nhất, đường Lý Thường Kiệt, Quận Tân Bình"
    ,"Lat":10.792101
    ,"Long":106.653074
    ,"Polyline":"[106.65307617,10.78868866] ; [106.65280914,10.78961372] ; [106.65269470,10.78979778] ; [106.65258789,10.79008770] ; [106.65261078,10.79019833] ; [106.65258789,10.79034138] ; [106.65255737,10.79063606] ; [106.65258789,10.79094696] ; [106.65277863,10.79156399] ; [106.65304565,10.79212761]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"510"
    ,"Station_Code":"QTB 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Hội Chợ Triển lãm Tân Bình"
    ,"Station_Address":"605 (Bệnh viện Tân Bình), đường Hoàng Văn Thụ, Quận  Tân Bình"
    ,"Lat":10.794587
    ,"Long":106.65506
    ,"Polyline":"[106.65304565,10.79212761] ; [106.65372467,10.79320717] ; [106.65435791,10.79393482] ; [106.65505981,10.79458714]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"555"
    ,"Station_Code":"QTB 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Nhà hàng Đông Phương"
    ,"Station_Address":"431, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.798622
    ,"Long":106.659286
    ,"Polyline":"[106.65505981,10.79458714] ; [106.65928650,10.79862213]"
    ,"Distance":"644"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"187"
    ,"Station_Code":"QTB 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Phạm Văn Hai"
    ,"Station_Address":"259, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800527
    ,"Long":106.663309
    ,"Polyline":"[106.65928650,10.79862213] ; [106.65958405,10.79899311] ; [106.65992737,10.79936218] ; [106.66082764,10.80021095] ; [106.66098785,10.80022144] ; [106.66110992,10.80030060] ; [106.66119385,10.80037975] ; [106.66128540,10.80045795] ; [106.66149902,10.80059052] ; [106.66166687,10.80063725] ; [106.66183472,10.80065823] ; [106.66266632,10.80061626] ; [106.66303253,10.80058002] ; [106.66330719,10.80050278]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"186"
    ,"Station_Code":"QTB 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Trạm Bảo Tàng Miền Đông"
    ,"Station_Address":"247, đường Hoàng Văn Thụ, Quận Tân Bình"
    ,"Lat":10.800242
    ,"Long":106.666356
    ,"Polyline":"[106.66330719,10.80050278] ; [106.66480255,10.80043221] ; [106.66635132,10.80023193]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"511"
    ,"Station_Code":"QPN 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Siêu Thị Big C"
    ,"Station_Address":"241, đường Hoàng Văn Thụ,  Quận Phú Nhuận"
    ,"Lat":10.799905
    ,"Long":106.6698
    ,"Polyline":"[106.66635132,10.80023193] ; [106.66703033,10.80025291] ; [106.66793060,10.80015850] ; [106.66875458,10.79998875]"
    ,"Distance":"265"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"556"
    ,"Station_Code":"QPN 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Khách Sạn Tân Sơn Nhất"
    ,"Station_Address":"217, đường Ho àng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799805
    ,"Long":106.670873
    ,"Polyline":"[106.66875458,10.79998875] ; [106.66928864,10.79997921] ; [106.67037201,10.79985237]"
    ,"Distance":"178"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"512"
    ,"Station_Code":"QPN 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Công an Phú Nhuận"
    ,"Station_Address":"189, đường Hoàng Văn Thụ, Quận Phú Nhu ận"
    ,"Lat":10.799552
    ,"Long":106.673684
    ,"Polyline":"[106.67037201,10.79985237] ; [106.67368317,10.79955196]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"232"
    ,"Station_Code":"QPN 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"59, đường Hoàng Văn Thụ, Quận Phú Nhuận"
    ,"Lat":10.799094
    ,"Long":106.679247
    ,"Polyline":"[106.67368317,10.79955196] ; [106.67924500,10.79913139]"
    ,"Distance":"610"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"558"
    ,"Station_Code":"QPN 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã tư Phan Xích Long"
    ,"Station_Address":"171, đường Phan  Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.800241
    ,"Long":106.681541
    ,"Polyline":"[106.67924500,10.79913139] ; [106.68005371,10.79914093] ; [106.68052673,10.79931450] ; [106.68154144,10.80024147]"
    ,"Distance":"295"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"513"
    ,"Station_Code":"QPN 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã Tư Thích Quảng Đức"
    ,"Station_Address":"141 - 143, đường Phan Đăng Lưu, Quận  Phú Nhuận"
    ,"Lat":10.802197
    ,"Long":106.683619
    ,"Polyline":"[106.68154144,10.80024147] ; [106.68361664,10.80219746]"
    ,"Distance":"315"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"514"
    ,"Station_Code":"QPN 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Đại học Văn Hiến"
    ,"Station_Address":"109, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.803841
    ,"Long":106.686156
    ,"Polyline":"[106.68361664,10.80219746] ; [106.68480682,10.80349922] ; [106.68496704,10.80365658] ; [106.68515778,10.80379391] ; [106.68536377,10.80388832] ; [106.68560028,10.80393124] ; [106.68590546,10.80392551] ; [106.68615723,10.80384064]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"515"
    ,"Station_Code":"QPN 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Bệnh Viện  Phước An"
    ,"Station_Address":"81 - 83, đường Phan Đăng Lưu, Quận Phú Nhuận"
    ,"Lat":10.80362
    ,"Long":106.687744
    ,"Polyline":"[106.68615723,10.80384064] ; [106.68733215,10.80369949] ; [106.68774414,10.80362034]"
    ,"Distance":"175"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"516"
    ,"Station_Code":"QBTH 113"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Công an PCCC"
    ,"Station_Address":"45, đường  Phan Đăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.803188
    ,"Long":106.691371
    ,"Polyline":"[106.68774414,10.80362034] ; [106.69136810,10.80318832]"
    ,"Distance":"400"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"517"
    ,"Station_Code":"QBTH 114"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Lăng Ông B à Chiểu"
    ,"Station_Address":"1, đường Phan Đ ăng Lưu, Quận Bình Thạnh"
    ,"Lat":10.802455
    ,"Long":106.696826
    ,"Polyline":"[106.69136810,10.80318832] ; [106.69682312,10.80245495]"
    ,"Distance":"602"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"518"
    ,"Station_Code":"QBTH 006"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Chợ Bà Chiểu"
    ,"Station_Address":"473C, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802961
    ,"Long":106.699557
    ,"Polyline":"[106.69682312,10.80245495] ; [106.69743347,10.80242348] ; [106.69809723,10.80238152] ; [106.69955444,10.80296135]"
    ,"Distance":"311"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"519"
    ,"Station_Code":"QBTH 007"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Tòa Án nh ân dân Quận Bình Thạnh"
    ,"Station_Address":"449 , đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803625
    ,"Long":106.701177
    ,"Polyline":"[106.69955444,10.80296135] ; [106.70117950,10.80362511]"
    ,"Distance":"192"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"520"
    ,"Station_Code":"QBTH 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Chùa Bồ  Đề"
    ,"Station_Address":"375, đường Bạch Đằng, Quận  Bình Thạnh"
    ,"Lat":10.803293
    ,"Long":106.703988
    ,"Polyline":"[106.70117950,10.80362511] ; [106.70146942,10.80379391] ; [106.70162964,10.80379963] ; [106.70268250,10.80352020] ; [106.70336914,10.80337715] ; [106.70398712,10.80329323]"
    ,"Distance":"319"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"521"
    ,"Station_Code":"QBTH 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Nhà thờ Hàng Xanh"
    ,"Station_Address":"235, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.803077
    ,"Long":106.706713
    ,"Polyline":"[106.70398712,10.80329323] ; [106.70671082,10.80307674]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"366"
    ,"Station_Code":"QBTH 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã Ba Xô Viết Nghệ Tĩnh"
    ,"Station_Address":"39, đường Bạch Đằng, Quận Bình Thạnh"
    ,"Lat":10.802793
    ,"Long":106.710511
    ,"Polyline":"[106.70671082,10.80307674] ; [106.71051025,10.80279255]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"299"
    ,"Station_Code":"QBTH 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cầu Sơn"
    ,"Station_Address":"338 , đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.804748
    ,"Long":106.711541
    ,"Polyline":"[106.71051025,10.80279255] ; [106.71122742,10.80278206] ; [106.71134949,10.80279827] ; [106.71144104,10.80287170] ; [106.71154022,10.80474758]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"302"
    ,"Station_Code":"QBTH 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đài Liệt  sĩ"
    ,"Station_Address":"504, đường Xô Viết Nghệ Tĩnh, Quận Bình Thạnh"
    ,"Lat":10.808831
    ,"Long":106.711965
    ,"Polyline":"[106.71154022,10.80474758] ; [106.71163940,10.80783558] ; [106.71174622,10.80835152] ; [106.71196747,10.80883121]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"301"
    ,"Station_Code":"QBTH 135"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Siêu thị Coop Mart"
    ,"Station_Address":"222/13A, đường  Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.810791
    ,"Long":106.71241
    ,"Polyline":"[106.71196747,10.80883121] ; [106.71212006,10.80930042] ; [106.71221161,10.80964851] ; [106.71233368,10.81025887] ; [106.71240997,10.81079102]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"522"
    ,"Station_Code":"QBTH 136"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"100-102, đường Quốc lộ 13, Quận Bình  Thạnh"
    ,"Lat":10.811666
    ,"Long":106.712532
    ,"Polyline":"[106.71240997,10.81079102] ; [106.71253204,10.81166553]"
    ,"Distance":"98"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"303"
    ,"Station_Code":"QBTH 137"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"126-128, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.81232
    ,"Long":106.712608
    ,"Polyline":"[106.71253204,10.81166553] ; [106.71260834,10.81231976]"
    ,"Distance":"73"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"305"
    ,"Station_Code":"QBTH 138"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Bến xe Miền Đông"
    ,"Station_Address":"152, đường Quốc lộ 13, Quận Bình Thạnh"
    ,"Lat":10.813853
    ,"Long":106.712791
    ,"Polyline":"[106.71260834,10.81231976] ; [106.71279144,10.81385326]"
    ,"Distance":"172"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"523"
    ,"Station_Code":"QTD 118"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Ga Bình Triệu"
    ,"Station_Address":"124, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.827371
    ,"Long":106.716782
    ,"Polyline":"[106.71279144,10.81385326] ; [106.71285248,10.81492805] ; [106.71295166,10.81596088] ; [106.71318054,10.81763649] ; [106.71339417,10.81931210.06.71377563] ; [10.82267380,106.71421814] ; [10.82504463,106.71498108] ; [10.82590294,106.71586609] ; [10.82621384,106.71702576] ; [10.82653046,106.71678162]"
    ,"Distance":"1715"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"524"
    ,"Station_Code":"QTD 119"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"Trạm y tế P. Hiệp Bình Chánh"
    ,"Station_Address":"202 , đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.828169
    ,"Long":106.719681
    ,"Polyline":"[106.71678162,10.82737064] ; [106.71702576,10.82654095] ; [106.71881104,10.82701015] ; [106.72003174,10.82745743] ; [106.71968079,10.82816887]"
    ,"Distance":"529"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"525"
    ,"Station_Code":"QTD 120"
    ,"Station_Direction":"1"
    ,"Station_Order":"48"
    ,"Station_Name":"Chùa Ưu  Đàm"
    ,"Station_Address":"270 , đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.829407
    ,"Long":106.722511
    ,"Polyline":"[106.71968079,10.82816887] ; [106.72002411,10.82742596] ; [106.72081757,10.82780552] ; [106.72142792,10.82817936] ; [106.72213745,10.82865334] ; [106.72280884,10.82914352] ; [106.72251129,10.82940674]"
    ,"Distance":"496"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"526"
    ,"Station_Code":"QTD 121"
    ,"Station_Direction":"1"
    ,"Station_Order":"49"
    ,"Station_Name":"Trường Hi ệp Bình Chánh"
    ,"Station_Address":"352, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.833377
    ,"Long":106.727455
    ,"Polyline":"[106.72251129,10.82940674] ; [106.72277069,10.82911205] ; [106.72459412,10.83058739] ; [106.72772217,10.83313751] ; [106.72745514,10.83337688]"
    ,"Distance":"786"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"527"
    ,"Station_Code":"QTD 122"
    ,"Station_Direction":"1"
    ,"Station_Order":"50"
    ,"Station_Name":"Đường Sông Đà"
    ,"Station_Address":"406-408 , đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.835629
    ,"Long":106.730186
    ,"Polyline":"[106.72745514,10.83337688] ; [106.72773743,10.83307457] ; [106.73043823,10.83531857] ; [106.73018646,10.83562946]"
    ,"Distance":"477"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"528"
    ,"Station_Code":"QTD 123"
    ,"Station_Direction":"1"
    ,"Station_Order":"51"
    ,"Station_Name":"Chợ Hiệp  Bình"
    ,"Station_Address":"440, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.837864
    ,"Long":106.732994
    ,"Polyline":"[106.73018646,10.83562946] ; [106.73046875,10.83535004] ; [106.73318481,10.83758450] ; [106.73299408,10.83786392]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"529"
    ,"Station_Code":"QTD 124"
    ,"Station_Direction":"1"
    ,"Station_Order":"52"
    ,"Station_Name":"Phố Mơ"
    ,"Station_Address":"500, đường Kha V ạn Cân, Quận Thủ Đức"
    ,"Lat":10.839334
    ,"Long":106.736923
    ,"Polyline":"[106.73299408,10.83786392] ; [106.73320007,10.83759499] ; [106.73463440,10.83837414] ; [106.73616028,10.83885956] ; [106.73699188,10.83899593] ; [106.73692322,10.83933353]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"530"
    ,"Station_Code":"QTD 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"53"
    ,"Station_Name":"Hòa Phát"
    ,"Station_Address":"564, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.84045
    ,"Long":106.741188
    ,"Polyline":"[106.73692322,10.83933353] ; [106.73696136,10.83897495] ; [106.73867035,10.83929157] ; [106.73997498,10.83971310.06.74131775] ; [10.84004974,106.74118805]"
    ,"Distance":"579"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"531"
    ,"Station_Code":"QTD 126"
    ,"Station_Direction":"1"
    ,"Station_Order":"54"
    ,"Station_Name":"Trường Cao đẳng Vinatex"
    ,"Station_Address":"580, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.840767
    ,"Long":106.744022
    ,"Polyline":"[106.74118805,10.84045029] ; [106.74132538,10.84001827] ; [106.74234009,10.84027672] ; [106.74330902,10.84057140] ; [106.74376678,10.84080315] ; [106.74401855,10.84076691]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"532"
    ,"Station_Code":"QTD 127"
    ,"Station_Direction":"1"
    ,"Station_Order":"55"
    ,"Station_Name":"Công ty 23-7"
    ,"Station_Address":"624, đường Kha  Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.84129
    ,"Long":106.746346
    ,"Polyline":"[106.74401855,10.84076691] ; [106.74487305,10.84070301] ; [106.74536133,10.84069252] ; [106.74578094,10.84079266] ; [106.74634552,10.84129047]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"533"
    ,"Station_Code":"QTD 128"
    ,"Station_Direction":"1"
    ,"Station_Order":"56"
    ,"Station_Name":"Công an phường Linh Đông"
    ,"Station_Address":"684, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.844781
    ,"Long":106.74966
    ,"Polyline":"[106.74634552,10.84129047] ; [106.74745178,10.84243107] ; [106.74826813,10.84337997] ; [106.74965668,10.84478092]"
    ,"Distance":"532"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"534"
    ,"Station_Code":"QTD 129"
    ,"Station_Direction":"1"
    ,"Station_Order":"57"
    ,"Station_Name":"Trạm Cầu  Ngang"
    ,"Station_Address":"742, đường Kha V ạn Cân, Quận Thủ Đức"
    ,"Lat":10.847416
    ,"Long":106.75209
    ,"Polyline":"[106.74965668,10.84478092] ; [106.75012207,10.84535599] ; [106.75064850,10.84611416] ; [106.75094604,10.84645653] ; [106.75161743,10.84708405] ; [106.75209045,10.84741592]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"535"
    ,"Station_Code":"QTD 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"58"
    ,"Station_Name":"Chợ Thủ Đức"
    ,"Station_Address":"996, đường Kha Vạn Cân, Quận Thủ Đức"
    ,"Lat":10.850158
    ,"Long":106.754372
    ,"Polyline":"[106.75209045,10.84741592] ; [106.75437164,10.85015774]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"493"
    ,"Station_Code":"QTD 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"59"
    ,"Station_Name":"Ngã ba Chương Dương"
    ,"Station_Address":"100, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.850503
    ,"Long":106.759998
    ,"Polyline":"[106.75437164,10.85015774] ; [106.75492096,10.85088730] ; [106.75497437,10.85105610.06.75503540] ; [10.85108757,106.75506592] ; [10.85116673,106.75597382] ; [10.85111904,106.75706482] ; [10.85125637,106.75758362] ; [10.85108280,106.75809479] ; [10.85093975,106.75861359] ; [10.85062981,106.75999451]"
    ,"Distance":"694"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"490"
    ,"Station_Code":"QTD 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"60"
    ,"Station_Name":"Cao đẳng xây dựng 2"
    ,"Station_Address":"190 , đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.85065
    ,"Long":106.764439
    ,"Polyline":"[106.75999451,10.85050297] ; [106.76194763,10.85044479] ; [106.76213074,10.85049248] ; [106.76226807,10.85057163] ; [106.76251221,10.85069275] ; [106.76271820,10.85082436] ; [106.76293182,10.85084534] ; [106.76444244,10.85064983]"
    ,"Distance":"498"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"492"
    ,"Station_Code":"QTD 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"61"
    ,"Station_Name":"Siêu thị Nguy ễn Kim"
    ,"Station_Address":"274-276, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849686
    ,"Long":106.769112
    ,"Polyline":"[106.76444244,10.85064983] ; [106.76703644,10.85043430] ; [106.76715088,10.85041904] ; [106.76725769,10.85036087] ; [106.76751709,10.85003376] ; [106.76774597,10.84981823] ; [106.76816559,10.84972858] ; [106.76911163,10.84968567]"
    ,"Distance":"542"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"497"
    ,"Station_Code":"QTD 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"62"
    ,"Station_Name":"Trường ĐHSP Kỹ Thuật"
    ,"Station_Address":"368, đường Võ Văn Ngân, Quận Thủ Đức"
    ,"Lat":10.849597
    ,"Long":106.771917
    ,"Polyline":"[106.76911163,10.84968567] ; [106.77120972,10.84969139] ; [106.77191925,10.84959698]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"494"
    ,"Station_Code":"Q9 218"
    ,"Station_Direction":"1"
    ,"Station_Order":"63"
    ,"Station_Name":"Công an Quận 9"
    ,"Station_Address":"Công an Quận 9, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.849966
    ,"Long":106.775066
    ,"Polyline":"[106.77191925,10.84959698] ; [106.77336884,10.84955502] ; [106.77359009,10.84945965] ; [106.77405548,10.84913826] ; [106.77478027,10.84978104] ; [106.77506256,10.84996605]"
    ,"Distance":"392"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"498"
    ,"Station_Code":"Q9 219"
    ,"Station_Direction":"1"
    ,"Station_Order":"64"
    ,"Station_Name":"Chợ chiều"
    ,"Station_Address":"Kế 830 (Chợ Chiều), đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.853511
    ,"Long":106.780474
    ,"Polyline":"[106.77506256,10.84996605] ; [106.77687073,10.85139847] ; [106.78047180,10.85351086]"
    ,"Distance":"712"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"495"
    ,"Station_Code":"Q9 220"
    ,"Station_Direction":"1"
    ,"Station_Order":"65"
    ,"Station_Name":"Khu Công nghệ cao quận 9"
    ,"Station_Address":"Khu công nghệ cao, đường Xa Lộ Hà Nội, Quận 9"
    ,"Lat":10.858511
    ,"Long":106.788869
    ,"Polyline":"[106.78047180,10.85351086] ; [106.78887177,10.85851097]"
    ,"Distance":"1073"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"536"
    ,"Station_Code":"Q9 221"
    ,"Station_Direction":"1"
    ,"Station_Order":"66"
    ,"Station_Name":"Cầu Vượt Trạm 2"
    ,"Station_Address":"Tiệm vàng Kim Lợi, đường Quốc lộ 1, Quận 9"
    ,"Lat":10.863595
    ,"Long":106.797538
    ,"Polyline":"[106.78887177,10.85851097] ; [106.79753876,10.86359501]"
    ,"Distance":"1104"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"537"
    ,"Station_Code":"Q9 223"
    ,"Station_Direction":"1"
    ,"Station_Order":"67"
    ,"Station_Name":"Suối Tiên"
    ,"Station_Address":"Suối Tiên,  đường Quốc lộ 1, Quận 9"
    ,"Lat":10.866498
    ,"Long":106.802377
    ,"Polyline":"[106.79753876,10.86359501] ; [106.80237579,10.86649799]"
    ,"Distance":"620"
  },
  {
     "Route_Id":"8"
    ,"Station_Id":"538"
    ,"Station_Code":"BX87"
    ,"Station_Direction":"1"
    ,"Station_Order":"68"
    ,"Station_Name":"Đại học Quốc gia"
    ,"Station_Address":"Bến xe buýt Khu A  Đô thị Quốc gia, đường Đường nội bộ Đại học Quốc gia, Quận Thủ Đức"
    ,"Lat":10.873805046081543
    ,"Long":106.8020248413086
    ,"Polyline":"[106.80237579,10.86649799] ; [106.80450439,10.86799431] ; [106.80545807,10.86890030] ; [106.80622864,10.86978531] ; [106.80867767,10.87297726] ; [106.80858612,10.87311459] ; [106.80818939,10.87347794] ; [106.80795288,10.87373638] ; [106.80767822,10.87399387] ; [106.80741119,10.87416267] ; [106.80671692,10.87453175] ; [106.80557251,10.87504292] ; [106.80513000,10.87565899] ; [106.80484009,10.87598038] ; [106.80444336,10.87621784] ; [106.80396271,10.87641716] ; [106.80335999,10.87658119] ; [106.80319977,10.87662792] ; [106.80313110,10.87655449] ; [106.80316162,10.87644386] ; [106.80305481,10.87634373] ; [106.80262756,10.87616444] ; [106.80199432,10.87603855] ; [106.80144501,10.87587452] ; [106.80071259,10.87584305] ; [106.80039978,10.87579632] ; [106.80021667,10.87574291] ; [106.80001831,10.87563801] ; [106.79984283,10.87549591] ; [106.79979706,10.87536907] ; [106.79981995,10.87521076] ; [106.79988861,10.87488461] ; [106.79996490,10.87459469] ; [106.80017090,10.87431526] ; [106.80059814,10.87403107] ; [106.80098724,10.87386227] ; [106.80169678,10.87363625] ; [106.80195618,10.87358379] ; [106.80202484,10.87380505]"
    ,"Distance":"2538"
  }]