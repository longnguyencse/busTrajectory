export const Route59 =[

  {
     "Route_Id":"59"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"BÃI XE BUÝT ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT ĐẦM SEN, đường Hòa  Bình, Quận 11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1043"
    ,"Station_Code":"Q11 047"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Ngã 4 Hòa Bình"
    ,"Station_Address":"3 (79), đường Hòa Bình, Quận 11"
    ,"Lat":10.76698
    ,"Long":106.641571
    ,"Polyline":"[106.64069366,10.76665020] ; [106.64067078,10.76688957] ; [106.64067078,10.76700974] ; [106.64080811,10.76702976] ; [106.64093018,10.76704979] ; [106.64103699,10.76710987] ; [106.64109802,10.76721954] ; [106.64127350,10.76714039] ; [106.64158630,10.76704025]"
    ,"Distance":"153"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1682"
    ,"Station_Code":"Q11 071"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"310, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.767508
    ,"Long":106.64296
    ,"Polyline":"[106.64157104,10.76698017] ; [106.64158630,10.76704025] ; [106.64209747,10.76690006] ; [106.64221191,10.76671124] ; [106.64236450,10.76665878] ; [106.64251709,10.76674271] ; [106.64249420,10.76689529] ; [106.64245605,10.76698017] ; [106.64286804,10.76747990] ; [106.64290619,10.76753998] ; [106.64295959,10.76750755]"
    ,"Distance":"240"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1681"
    ,"Station_Code":"Q11 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm Đăng Kiểm"
    ,"Station_Address":"432, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.770437
    ,"Long":106.645073
    ,"Polyline":"[106.64290619,10.76753998] ; [106.64383698,10.76889038] ; [106.64450836,10.76980019] ; [106.64498138,10.77050018]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1684"
    ,"Station_Code":"Q11 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"612, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.773831
    ,"Long":106.647461
    ,"Polyline":"[106.64498138,10.77050018] ; [106.64611816,10.77210045] ; [106.64739227,10.77388000]"
    ,"Distance":"459"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2401"
    ,"Station_Code":"Q11 079"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Trường Phạm Ngọc Thạch"
    ,"Station_Address":"185-189, đường Âu Cơ, Quận 11"
    ,"Lat":10.77333
    ,"Long":106.648863
    ,"Polyline":"[106.64739227,10.77388000] ; [106.64803314,10.77474022] ; [106.64888000,10.77350998] ; [106.64875793,10.77342033] ; [106.64855194,10.77320957]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2400"
    ,"Station_Code":"Q11 080"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Tân  Phú"
    ,"Station_Address":"105, đường Âu Cơ, Quận 11"
    ,"Lat":10.770953
    ,"Long":106.650436
    ,"Polyline":"[106.64855194,10.77320957] ; [106.64875793,10.77342033] ; [106.64888000,10.77350998] ; [106.65029144,10.77136040] ; [106.65052795,10.77101994]"
    ,"Distance":"380"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2404"
    ,"Station_Code":"Q11 081"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Bình Thới"
    ,"Station_Address":"27P, đường Âu Cơ, Quận 11"
    ,"Lat":10.769483
    ,"Long":106.651524
    ,"Polyline":"[106.65052795,10.77101994] ; [106.65160370,10.76951981]"
    ,"Distance":"203"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2833"
    ,"Station_Code":"Q11 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Đường Nguy ễn Thị Nhỏ"
    ,"Station_Address":"Đối Diện 47, đường Nguyễn Thị Nhỏ, Quận 11"
    ,"Lat":10.770221
    ,"Long":106.652672
    ,"Polyline":"[106.65149689,10.76944637] ; [106.65160370,10.76951981] ; [106.65185547,10.76916218] ; [106.65184784,10.76903057] ; [106.65191650,10.76889324] ; [106.65209961,10.76877689] ; [106.65237427,10.76875591] ; [106.65251923,10.76886654] ; [106.65249634,10.76902485] ; [106.65248871,10.76917744] ; [106.65261078,10.76984215] ; [106.65267181,10.77022076]"
    ,"Distance":"321"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2836"
    ,"Station_Code":"Q11 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Coopmark Phú Thọ"
    ,"Station_Address":"Đối Diện 64,  đường Lữ Gia, Quận 11"
    ,"Lat":10.771025
    ,"Long":106.653313
    ,"Polyline":"[106.65261078,10.77023029] ; [106.65267944,10.77091026] ; [106.65274048,10.77099037] ; [106.65294647,10.77116013] ; [106.65332031,10.77108955]"
    ,"Distance":"158"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2838"
    ,"Station_Code":"Q11 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà thi đấu Phú Thọ"
    ,"Station_Address":"Đối Diện 10B, đường Lữ Gia, Quận 11"
    ,"Lat":10.770303
    ,"Long":106.657303
    ,"Polyline":"[106.65332031,10.77108955] ; [106.65447235,10.77091026] ; [106.65519714,10.77081966] ; [106.65583038,10.77071953] ; [106.65733337,10.77050018]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"900"
    ,"Station_Code":"Q10 059"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"BV Trưng Vương"
    ,"Station_Address":"531, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.770922
    ,"Long":106.658913
    ,"Polyline":"[106.65733337,10.77050018] ; [106.65815735,10.77038956] ; [106.65834045,10.77048016] ; [106.65885925,10.77095985]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"898"
    ,"Station_Code":"Q10 058"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Đại Học Bách Khoa (cổng sau)"
    ,"Station_Address":"523, đường Tô Hiến Thành,  Quận 10"
    ,"Lat":10.773046
    ,"Long":106.661057
    ,"Polyline":"[106.65885925,10.77095985] ; [106.66065216,10.77260971] ; [106.66101074,10.77307987]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"902"
    ,"Station_Code":"Q10 057"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngân hàng quân đội"
    ,"Station_Address":"405, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775549
    ,"Long":106.663017
    ,"Polyline":"[106.66101074,10.77307987] ; [106.66143036,10.77359009] ; [106.66175842,10.77402973] ; [106.66233826,10.77476025] ; [106.66294098,10.77560043]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2835"
    ,"Station_Code":"Q10 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Quán Hoàng Ty"
    ,"Station_Address":"161, đường Thành Thái, Quận 10"
    ,"Lat":10.775075
    ,"Long":106.66407
    ,"Polyline":"[106.66294098,10.77560043] ; [106.66349030,10.77635956] ; [106.66355896,10.77641010.06.66384125] ; [10.77583027,106.66413116]"
    ,"Distance":"271"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2837"
    ,"Station_Code":"Q10 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"BV 115"
    ,"Station_Address":"69, đường Thành Thái, Quận  10"
    ,"Lat":10.773051
    ,"Long":106.664833
    ,"Polyline":"[106.66413116,10.77509975] ; [106.66445923,10.77418995] ; [106.66478729,10.77340984] ; [106.66490173,10.77307034]"
    ,"Distance":"241"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2840"
    ,"Station_Code":"Q10 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Nhà thờ Đồng Tiến"
    ,"Station_Address":"Đối diện 52, đường Thành Th ái, Quận 10"
    ,"Lat":10.770474
    ,"Long":106.665863
    ,"Polyline":"[106.66490173,10.77307034] ; [106.66536713,10.77180958] ; [106.66591644,10.77050018]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1397"
    ,"Station_Code":"Q10 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện nhi đồng 1"
    ,"Station_Address":"359, đường Lý Thái Tổ, Quận 10"
    ,"Lat":10.767765
    ,"Long":106.67038
    ,"Polyline":"[106.66591644,10.77050018] ; [106.66635132,10.76937962] ; [106.66712189,10.76770973] ; [106.66786194,10.76807022] ; [106.66787720,10.76805019] ; [106.66793823,10.76803970] ; [106.66797638,10.76809025] ; [106.66805267,10.76801968] ; [106.66812134,10.76799011] ; [106.66903687,10.76793003]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2842"
    ,"Station_Code":"Q10 036"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chùa An Quang"
    ,"Station_Address":"253 (333), đường  Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.766089
    ,"Long":106.671852
    ,"Polyline":"[106.66903687,10.76793003] ; [106.67002869,10.76786995] ; [106.67153931,10.76782036] ; [106.67191315,10.76609993]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2839"
    ,"Station_Code":"Q10 037"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Chung cư Ngô Gia Tự"
    ,"Station_Address":"012 lôF, đường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.763507
    ,"Long":106.672455
    ,"Polyline":"[106.67191315,10.76609993] ; [106.67207336,10.76539993] ; [106.67221069,10.76480007] ; [106.67228699,10.76469994] ; [106.67247772,10.76366997] ; [106.67250824,10.76352024]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2841"
    ,"Station_Code":"Q10 038"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Nguyễn Chí Thanh"
    ,"Station_Address":"31, đường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.761062
    ,"Long":106.672997
    ,"Polyline":"[106.67250824,10.76352024] ; [106.67297363,10.76156044] ; [106.67305756,10.76107025]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2844"
    ,"Station_Code":"Q5 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Bệnh viện 30/4"
    ,"Station_Address":"9, đường Sư Vạn Hạnh, Quận 5"
    ,"Lat":10.758147
    ,"Long":106.673652
    ,"Polyline":"[106.67305756,10.76107025] ; [106.67326355,10.76012039] ; [106.67371368,10.75817013]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"466"
    ,"Station_Code":"Q5 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"439, đường An Dư ơng Vương, Quận 5"
    ,"Lat":10.758374
    ,"Long":106.676576
    ,"Polyline":"[106.67371368,10.75817013] ; [106.67388153,10.75749016] ; [106.67398834,10.75751019] ; [106.67407990,10.75743961] ; [106.67411804,10.75743961] ; [106.67417145,10.75753021] ; [106.67575836,10.75811005] ; [106.67645264,10.75839996]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"472"
    ,"Station_Code":"Q5 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"373, đường An Dư ơng Vương, Quận 5"
    ,"Lat":10.759138
    ,"Long":106.678453
    ,"Polyline":"[106.67645264,10.75839996] ; [106.67813110,10.75911045] ; [106.67829895,10.75916958]"
    ,"Distance":"219"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"467"
    ,"Station_Code":"Q5 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Đại học Sài Gòn"
    ,"Station_Address":"273-275, đường An Dương Vương, Quận 5"
    ,"Lat":10.760735
    ,"Long":106.682289
    ,"Polyline":"[106.67829895,10.75916958] ; [106.67920685,10.75951004] ; [106.68013000,10.75986958] ; [106.68226624,10.76074982]"
    ,"Distance":"468"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"474"
    ,"Station_Code":"Q1 141"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"ĐH Khoa Học Tự Nhiên"
    ,"Station_Address":"Đối diện số 217, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.762292
    ,"Long":106.683052
    ,"Polyline":"[106.68226624,10.76074982] ; [106.68334961,10.76117039] ; [106.68292236,10.76220989]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"471"
    ,"Station_Code":"Q1 142"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường Lê Hồng Phong"
    ,"Station_Address":"Đối diện số 235, đường Nguyễn Văn Cừ, Quận 1"
    ,"Lat":10.764503
    ,"Long":106.68216
    ,"Polyline":"[106.68290710,10.76224041] ; [106.68218231,10.76410007]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"287"
    ,"Station_Code":"Q1 088"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Phạm Viết Chánh"
    ,"Station_Address":"Đối diện 492, đường Nguyễn Thị Minh Khai , Quận 1"
    ,"Lat":10.766214
    ,"Long":106.682533
    ,"Polyline":"[106.68218231,10.76410007] ; [106.68176270,10.76521015] ; [106.68180084,10.76523972] ; [106.68186951,10.76531029] ; [106.68190002,10.76539993] ; [106.68190002,10.76546001] ; [106.68187714,10.76552010.06.68186188] ; [10.76556015,106.68202972] ; [10.76572037,106.68229675] ; [10.76607990,106.68245697] ; [10.76624012,106.68247986]"
    ,"Distance":"281"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"290"
    ,"Station_Code":"Q1 089"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Bệnh viện Tù Dũ"
    ,"Station_Address":"Đối diện 446, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.768709
    ,"Long":106.685024
    ,"Polyline":"[106.68247986,10.76626015] ; [106.68479156,10.76875019]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"289"
    ,"Station_Code":"Q1 090"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"99, đường Nguyễn Thị Minh Khai, Quận 1"
    ,"Lat":10.77185
    ,"Long":106.687943
    ,"Polyline":"[106.68479156,10.76875019] ; [106.68753815,10.77167034]"
    ,"Distance":"442"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1396"
    ,"Station_Code":"Q1 004"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"85, đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.772392
    ,"Long":106.691371
    ,"Polyline":"[106.68753815,10.77167034] ; [106.68811035,10.77227020] ; [106.68943787,10.77363014] ; [106.69139862,10.77256012]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69134521,10.77245617] ; [106.69139862,10.77256012] ; [106.69281769,10.77180004] ; [106.69308472,10.77161217] ; [106.69312286,10.77143860] ; [106.69308472,10.77130699] ; [106.69321442,10.77119064] ; [106.69337463,10.77119064] ; [106.69346619,10.77126980] ; [106.69364929,10.77128029] ; [106.69516754,10.77120972] ; [106.69673157,10.77118969] ; [106.69673920,10.77118874]"
    ,"Distance":"669"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"202"
    ,"Station_Code":"Q1TC1C"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Bến Thành C"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770787
    ,"Long":106.698532
    ,"Polyline":"[106.69673157,10.77118969] ; [106.69756317,10.77151775] ; [106.69795227,10.77165985] ; [106.69808197,10.77159691] ; [106.69803619,10.77140713] ; [106.69808960,10.77127934] ; [106.69820404,10.77119350] ; [106.69842529,10.77117634] ; [106.69860077,10.77125359] ; [106.69899750,10.77095127] ; [106.69851685,10.77077007]"
    ,"Distance":"368"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"853"
    ,"Station_Code":"Q1 001"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Calmette"
    ,"Station_Address":"87, đường Calmette , Quận 1"
    ,"Lat":10.767768
    ,"Long":106.699219
    ,"Polyline":"[106.69851685,10.77077007] ; [106.69758606,10.77043152] ; [106.69718170,10.77006817] ; [106.69650269,10.76931572] ; [106.69688416,10.76887703] ; [106.69719696,10.76857948] ; [106.69802094,10.76766014] ; [106.69884491,10.76840591] ; [106.69928741,10.76782036]"
    ,"Distance":"732"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1195"
    ,"Station_Code":"Q4 008"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chùa Anh Linh"
    ,"Station_Address":"160-162, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.76308
    ,"Long":106.703183
    ,"Polyline":"[106.69928741,10.76782036] ; [106.69975281,10.76721001] ; [106.69989014,10.76714039] ; [106.70033264,10.76657963] ; [106.70088196,10.76589012] ; [106.70108795,10.76564980] ; [106.70159912,10.76513004] ; [106.70185852,10.76490974] ; [106.70362091,10.76362991] ; [106.70372772,10.76354027] ; [106.70378113,10.76340961] ; [106.70340729,10.76307964] ; [106.70330048,10.76299953]"
    ,"Distance":"771"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1193"
    ,"Station_Code":"Q4 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường THCS Vân Đồn"
    ,"Station_Address":"Đối diện 243, đường Hoàng Di ệu, Quận 4"
    ,"Lat":10.761879
    ,"Long":106.701488
    ,"Polyline":"[106.70330048,10.76299953] ; [106.70268250,10.76253033] ; [106.70188141,10.76193047] ; [106.70166016,10.76179028]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1196"
    ,"Station_Code":"Q4 010"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Cầu Ông Lãnh"
    ,"Station_Address":"K48-K50, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.760429
    ,"Long":106.699428
    ,"Polyline":"[106.70166016,10.76179028] ; [106.70146179,10.76167011] ; [106.70107269,10.76144028] ; [106.70041656,10.76099968] ; [106.69972992,10.76053047] ; [106.69950104,10.76035023]"
    ,"Distance":"285"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1194"
    ,"Station_Code":"Q4 019"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Chung cư Tân Vĩnh"
    ,"Station_Address":"Đối diện 220, đường Khánh Hội, Quận 4"
    ,"Lat":10.758864
    ,"Long":106.698972
    ,"Polyline":"[106.69950104,10.76035023] ; [106.69892883,10.75992012] ; [106.69851685,10.75963974] ; [106.69857025,10.75949001] ; [106.69902039,10.75889969]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1198"
    ,"Station_Code":"Q4 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trung tâm TDTT Quận 4"
    ,"Station_Address":"149, đường Khánh Hội, Quận 4"
    ,"Lat":10.756725
    ,"Long":106.700581
    ,"Polyline":"[106.69902039,10.75889969] ; [106.69972992,10.75798035] ; [106.70034790,10.75714016] ; [106.70060730,10.75679016]"
    ,"Distance":"292"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1197"
    ,"Station_Code":"Q7 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Cầu Kinh Tẻ"
    ,"Station_Address":"44/7, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.74845
    ,"Long":106.702196
    ,"Polyline":"[106.70060730,10.75679016] ; [106.70114899,10.75607967] ; [106.70162964,10.75549030] ; [106.70181274,10.75527000] ; [106.70191193,10.75510025] ; [106.70195770,10.75491047] ; [106.70204163,10.75397015] ; [106.70223236,10.75174046] ; [106.70237732,10.74991035] ; [106.70236969,10.74905968] ; [106.70230103,10.74845028]"
    ,"Distance":"979"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1346"
    ,"Station_Code":"Q7 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chung cư Minh Thành"
    ,"Station_Address":"222, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744576
    ,"Long":106.704216
    ,"Polyline":"[106.70216370,10.74847126] ; [106.70230103,10.74845028] ; [106.70207977,10.74702740] ; [106.70200348,10.74627018] ; [106.70185852,10.74576759] ; [106.70179749,10.74535656] ; [106.70220184,10.74529362] ; [106.70250702,10.74522972] ; [106.70433044,10.74499035] ; [106.70427704,10.74456978] ; [106.70421600,10.74457645]"
    ,"Distance":"698"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1348"
    ,"Station_Code":"Q7 110"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Nguyễn Thị Thập"
    ,"Station_Address":"593, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.739607
    ,"Long":106.704696
    ,"Polyline":"[106.70427704,10.74456978] ; [106.70401001,10.74250984] ; [106.70375061,10.74096966] ; [106.70355225,10.73991966] ; [106.70451355,10.73974991] ; [106.70462036,10.73972988]"
    ,"Distance":"642"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2547"
    ,"Station_Code":"BX 17"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Khu dân c ư Tân Quy Đông"
    ,"Station_Address":"ĐẦU BẾN KDC TÂN QUY, đường Nguyễn Thị Thập, Quận 7"
    ,"Lat":10.738441
    ,"Long":106.706589
    ,"Polyline":"[106.70462036,10.73972988] ; [106.70681763,10.73941040] ; [106.70667267,10.73843002]"
    ,"Distance":"353"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2547"
    ,"Station_Code":"BX 17"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Khu dân cư Tân Quy Đông"
    ,"Station_Address":"ĐẦU BẾN KDC TÂN QUY, đường Nguyễn Thị Thập, Qu ận 7"
    ,"Lat":10.738441
    ,"Long":106.706589
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1380"
    ,"Station_Code":"Q7 130"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Lotte Mark"
    ,"Station_Address":"359, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.740208
    ,"Long":106.70369
    ,"Polyline":"[106.70667267,10.73843002] ; [106.70681763,10.73941040] ; [106.70526886,10.73964024] ; [106.70451355,10.73974991] ; [106.70355225,10.73991966] ; [106.70361328,10.74022007]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1382"
    ,"Station_Code":"Q7 131"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Đường số 15"
    ,"Station_Address":"265, đường Lê Văn Lương, Quận 7"
    ,"Lat":10.744471
    ,"Long":106.70432
    ,"Polyline":"[106.70361328,10.74022007] ; [106.70401001,10.74250984] ; [106.70423126,10.74417973]"
    ,"Distance":"446"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1251"
    ,"Station_Code":"Q7 079"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Cầu Kinh Tẻ"
    ,"Station_Address":"Đối diện 44/9, đường Nguyễn Hữu Thọ, Quận 7"
    ,"Lat":10.748524
    ,"Long":106.702443
    ,"Polyline":"[106.70423126,10.74417973] ; [106.70433044,10.74499035] ; [106.70250702,10.74522972] ; [106.70230865,10.74538040] ; [106.70217896,10.74551010.06.70207214] ; [10.74571991,106.70201111] ; [10.74592972,106.70200348] ; [10.74627018,106.70211792] ; [10.74703026,106.70237732]"
    ,"Distance":"694"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1248"
    ,"Station_Code":"Q4T015"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Hồ Bơi Quận 4"
    ,"Station_Address":"120-122, đường Khánh Hội, Quận 4"
    ,"Lat":10.756855
    ,"Long":106.700691
    ,"Polyline":"[106.70237732,10.74864006] ; [106.70243073,10.74892998] ; [106.70245361,10.74981976] ; [106.70218658,10.75306034] ; [106.70204163,10.75475025] ; [106.70198822,10.75504971] ; [106.70184326,10.75531960] ; [106.70091248,10.75650978] ; [106.70066071,10.75683975]"
    ,"Distance":"963"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1250"
    ,"Station_Code":"Q4 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chung cư Tân Vĩnh"
    ,"Station_Address":"202-204, đường Khánh Hội, Quận 4"
    ,"Lat":10.758848
    ,"Long":106.699213
    ,"Polyline":"[106.70066071,10.75683975] ; [106.69914246,10.75887012]"
    ,"Distance":"280"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1253"
    ,"Station_Code":"Q4 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chung cư H3"
    ,"Station_Address":"303-305, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.760066
    ,"Long":106.699294
    ,"Polyline":"[106.69914246,10.75887012] ; [106.69864655,10.75953007] ; [106.69851685,10.75963974] ; [106.69918823,10.76012039]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1252"
    ,"Station_Code":"Q4 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Trường THCS Vân Đồn"
    ,"Station_Address":"243, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.761768
    ,"Long":106.701724
    ,"Polyline":"[106.69918823,10.76012039] ; [106.69972992,10.76053047] ; [106.70041656,10.76099968] ; [106.70107269,10.76144028] ; [106.70146179,10.76167011] ; [106.70171356,10.76181984]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1254"
    ,"Station_Code":"Q4 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chùa Anh Linh"
    ,"Station_Address":"177, đường Hoàng Diệu, Quận 4"
    ,"Lat":10.763006
    ,"Long":106.703414
    ,"Polyline":"[106.70171356,10.76181984] ; [106.70226288,10.76222038] ; [106.70294952,10.76274014] ; [106.70337677,10.76305962]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"854"
    ,"Station_Code":"Q1 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Lê Thị Hồng Gấm"
    ,"Station_Address":"134, đường Calmette, Quận 1"
    ,"Lat":10.769178
    ,"Long":106.698334
    ,"Polyline":"[106.70337677,10.76305962] ; [106.70369720,10.76334000] ; [106.70378113,10.76340961] ; [106.70364380,10.76346970] ; [106.70340729,10.76366997] ; [106.70300293,10.76397991] ; [106.70217133,10.76453972] ; [106.70166016,10.76494026] ; [106.70143127,10.76515961] ; [106.70089722,10.76574039] ; [106.70072174,10.76595974] ; [106.69980621,10.76708984] ; [106.69975281,10.76721001] ; [106.69828033,10.76912975]"
    ,"Distance":"942"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1090"
    ,"Station_Code":"Q1TC1F"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Bến Thành F"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770472
    ,"Long":106.698456
    ,"Polyline":"[106.69828033,10.76912975] ; [106.69774628,10.76984978] ; [106.69744873,10.77035046] ; [106.69774628,10.77033997] ; [106.69844055,10.77062035]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1944"
    ,"Station_Code":"Q1 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"40, đường Phạm Hồng Thái, Quận 1"
    ,"Lat":10.77129
    ,"Long":106.695824
    ,"Polyline":"[106.69845581,10.77047157] ; [106.69844055,10.77062035] ; [106.69895935,10.77081966] ; [106.69899750,10.77095032] ; [106.69892120,10.77104855] ; [106.69900513,10.77134895] ; [106.69882202,10.77160168] ; [106.69872284,10.77181244] ; [106.69860840,10.77189732] ; [106.69848633,10.77192879] ; [106.69833374,10.77192307] ; [106.69818878,10.77183342] ; [106.69805145,10.77164936] ; [106.69792175,10.77164936] ; [106.69754791,10.77153301] ; [106.69720459,10.77139664] ; [106.69673157,10.77118969] ; [106.69582367,10.77128983]"
    ,"Distance":"546"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1297"
    ,"Station_Code":"Q1 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Trống Đồng"
    ,"Station_Address":"Đối diện số 89 , đường Cách Mạng Tháng Tám, Quận 1"
    ,"Lat":10.773046
    ,"Long":106.690813
    ,"Polyline":"[106.69582367,10.77120972] ; [106.69516754,10.77120972] ; [106.69364929,10.77128029] ; [106.69342804,10.77132988] ; [106.69344330,10.77134991] ; [106.69342804,10.77138996] ; [106.69335938,10.77145004] ; [106.69328308,10.77147961] ; [106.69319916,10.77147961] ; [106.69315338,10.77161026] ; [106.69281769,10.77180004] ; [106.69113922,10.77270985] ; [106.69075012,10.77291965]"
    ,"Distance":"613"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"380"
    ,"Station_Code":"Q3 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cách Mạng  tháng 8"
    ,"Station_Address":"284, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.773112
    ,"Long":106.688812
    ,"Polyline":"[106.69075012,10.77291965] ; [106.68985748,10.77340031] ; [106.68943787,10.77363014] ; [106.68887329,10.77305984]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"383"
    ,"Station_Code":"Q3 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"414, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.77079
    ,"Long":106.686634
    ,"Polyline":"[106.68887329,10.77305984] ; [106.68713379,10.77124023] ; [106.68678284,10.77085972]"
    ,"Distance":"334"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"382"
    ,"Station_Code":"Q3 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Bệnh viện Từ Dũ"
    ,"Station_Address":"436, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.768946
    ,"Long":106.684883
    ,"Polyline":"[106.68675995,10.77083969] ; [106.68493652,10.76889992]"
    ,"Distance":"293"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"89"
    ,"Station_Code":"Q3 072"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Hội Chữ thập đỏ thành phố"
    ,"Station_Address":"464 - 466, đường Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.767691
    ,"Long":106.683693
    ,"Polyline":"[106.68493652,10.76889992] ; [106.68374634,10.76764011]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"90"
    ,"Station_Code":"Q3 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Nhà sa ́ch Minh Khai"
    ,"Station_Address":"488, đường  Nguyễn Thị Minh Khai, Quận 3"
    ,"Lat":10.766416
    ,"Long":106.682428
    ,"Polyline":"[106.68374634,10.76764011] ; [106.68248749,10.76628017]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"425"
    ,"Station_Code":"Q5 073"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Trường THPT Lê Hồng Phong"
    ,"Station_Address":"235, đường Nguyễn Văn Cừ, Quận 5"
    ,"Lat":10.764456
    ,"Long":106.681946
    ,"Polyline":"[106.68244934,10.76632404] ; [106.68222046,10.76609993] ; [106.68190002,10.76581573] ; [106.68159485,10.76570511] ; [106.68142700,10.76563644] ; [106.68132019,10.76549911] ; [106.68134308,10.76528358] ; [106.68155670,10.76518822] ; [106.68173981,10.76506710.06.68194580]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"424"
    ,"Station_Code":"Q5 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Đại học Khoa học Tự nhiên"
    ,"Station_Address":"227, đường Nguyễn Văn Cừ, Quận 5"
    ,"Lat":10.763354
    ,"Long":106.682388
    ,"Polyline":"[106.68203735,10.76449013] ; [106.68245697,10.76338005]"
    ,"Distance":"131"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"426"
    ,"Station_Code":"Q5 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Đại học Sư Phạm"
    ,"Station_Address":"280, đường An Dương Vương, Quận 5"
    ,"Lat":10.76103
    ,"Long":106.68267
    ,"Polyline":"[106.68245697,10.76338005] ; [106.68292236,10.76220989] ; [106.68334961,10.76117039] ; [106.68270111,10.76091003]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"429"
    ,"Station_Code":"Q5 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ Bầu Sen"
    ,"Station_Address":"370, đường An Dương Vương , Quận 5"
    ,"Lat":10.759407
    ,"Long":106.678764
    ,"Polyline":"[106.68270111,10.76091003] ; [106.68013000,10.75986958] ; [106.67920685,10.75951004] ; [106.67878723,10.75934029]"
    ,"Distance":"461"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"427"
    ,"Station_Code":"Q5 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Huỳnh Mẫn Đạt"
    ,"Station_Address":"526 , đường An Dương Vương, Quận 5"
    ,"Lat":10.757984
    ,"Long":106.675272
    ,"Polyline":"[106.67878723,10.75934029] ; [106.67813110,10.75911045] ; [106.67575836,10.75811005] ; [106.67529297,10.75794029]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2843"
    ,"Station_Code":"Q5 077"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Bệnh viện 30 /4"
    ,"Station_Address":"Đối diện 9, đường Sư Vạn Hạnh, Quận 5"
    ,"Lat":10.75801
    ,"Long":106.673797
    ,"Polyline":"[106.67529297,10.75794029] ; [106.67417145,10.75753021] ; [106.67413330,10.75757980] ; [106.67404175,10.75759029] ; [106.67398834,10.75751019] ; [106.67388153,10.75749016] ; [106.67375183,10.75800037]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2846"
    ,"Station_Code":"Q10 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Nguyễn  Chí Thanh"
    ,"Station_Address":"023 lô H, đường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.761402
    ,"Long":106.673058
    ,"Polyline":"[106.67375183,10.75800037] ; [106.67326355,10.76012039] ; [106.67299652,10.76138973]"
    ,"Distance":"386"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2845"
    ,"Station_Code":"Q10 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Chung cư Ngô Gia Tự"
    ,"Station_Address":"021 lôK, đường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.76379
    ,"Long":106.672516
    ,"Polyline":"[106.67299652,10.76138973] ; [106.67266846,10.76278973] ; [106.67246246,10.76377964]"
    ,"Distance":"272"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2848"
    ,"Station_Code":"Q10 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Chùa An Quang"
    ,"Station_Address":"420, đường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.766293
    ,"Long":106.671928
    ,"Polyline":"[106.67246246,10.76377964] ; [106.67228699,10.76469994] ; [106.67221069,10.76480007] ; [106.67207336,10.76539993] ; [106.67186737,10.76628017]"
    ,"Distance":"287"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2847"
    ,"Station_Code":"Q10 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Bệnh viện nhi đồng 1"
    ,"Station_Address":"574, đường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.768919
    ,"Long":106.671349
    ,"Polyline":"[106.67186737,10.76628017] ; [106.67128754,10.76891041]"
    ,"Distance":"299"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2849"
    ,"Station_Code":"Q10 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Phòng khám đa khoa quốc tê Exson"
    ,"Station_Address":"652, đường Sư Vạn  Hạnh, Quận 10"
    ,"Lat":10.770168
    ,"Long":106.670547
    ,"Polyline":"[106.67128754,10.76891041] ; [106.67106628,10.76982021] ; [106.67076111,10.76968002] ; [106.67051697,10.77015018]"
    ,"Distance":"199"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2851"
    ,"Station_Code":"Q10 044"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Kho Bạc Q10"
    ,"Station_Address":"724 (100), đường  Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.771978
    ,"Long":106.669563
    ,"Polyline":"[106.67051697,10.77015018] ; [106.66988373,10.77134037] ; [106.66953278,10.77196026]"
    ,"Distance":"228"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2850"
    ,"Station_Code":"Q10 045"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"BV 115"
    ,"Station_Address":"155  (trường Huflit), đường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.775866
    ,"Long":106.667244
    ,"Polyline":"[106.66953278,10.77196026] ; [106.66915894,10.77266026] ; [106.66895294,10.77303982] ; [106.66863251,10.77363014] ; [106.66842651,10.77392006] ; [106.66821289,10.77423954] ; [106.66744995,10.77552032] ; [106.66719818,10.77583027]"
    ,"Distance":"501"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2853"
    ,"Station_Code":"Q10 046"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Siêu th ị big C miền đông"
    ,"Station_Address":"87, đ ường Sư Vạn Hạnh, Quận 10"
    ,"Lat":10.77728
    ,"Long":106.666069
    ,"Polyline":"[106.66719818,10.77583027] ; [106.66602325,10.77725029]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1007"
    ,"Station_Code":"Q10 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngân hàng quân đội"
    ,"Station_Address":"136, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.775531
    ,"Long":106.662819
    ,"Polyline":"[106.66602325,10.77725029] ; [106.66590881,10.77740002] ; [106.66551971,10.77787018] ; [106.66519165,10.77762032] ; [106.66470337,10.77725029] ; [106.66416931,10.77686024] ; [106.66355896,10.77641010.06.66349030] ; [10.77635956,106.66287231]"
    ,"Distance":"483"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1013"
    ,"Station_Code":"Q10 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Đại Học Bách Khoa (cổng sau)"
    ,"Station_Address":"350  ( cũ 142), đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.773322
    ,"Long":106.661125
    ,"Polyline":"[106.66287231,10.77550030] ; [106.66233826,10.77476025] ; [106.66175842,10.77402973] ; [106.66143036,10.77359009] ; [106.66117096,10.77328014]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1008"
    ,"Station_Code":"Q10 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"BV Trưng  Vương"
    ,"Station_Address":"142 kios 37-38, đường Tô Hiến Thành, Quận 10"
    ,"Lat":10.771244
    ,"Long":106.659096
    ,"Polyline":"[106.66117096,10.77328014] ; [106.66065216,10.77260971] ; [106.66011047,10.77210999] ; [106.65912628,10.77120018]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2855"
    ,"Station_Code":"Q11 050"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Nhà thi đấu Phú Thọ"
    ,"Station_Address":"14,  đường Lữ Gia, Quận 11"
    ,"Lat":10.770645
    ,"Long":106.656738
    ,"Polyline":"[106.65912628,10.77120018] ; [106.65834045,10.77048016] ; [106.65815735,10.77038956] ; [106.65759277,10.77046967] ; [106.65673065,10.77058983]"
    ,"Distance":"297"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2852"
    ,"Station_Code":"Q11 051"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Coopmark Phú Thọ"
    ,"Station_Address":"70A, đường Lữ Gia, Quận 11"
    ,"Lat":10.771143
    ,"Long":106.653236
    ,"Polyline":"[106.65673065,10.77058983] ; [106.65551758,10.77077007] ; [106.65486145,10.77087021] ; [106.65409851,10.77097988] ; [106.65322876,10.77110958]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2414"
    ,"Station_Code":"QTB 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Vòng xoay Lê Đại Hành"
    ,"Station_Address":"52, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.769663
    ,"Long":106.651543
    ,"Polyline":"[106.65322876,10.77110958] ; [106.65294647,10.77116013] ; [106.65286255,10.77110958] ; [106.65267944,10.77091026] ; [106.65252686,10.76955986] ; [106.65245056,10.76914978] ; [106.65241241,10.76906013] ; [106.65235138,10.76908970] ; [106.65228271,10.76908970] ; [106.65216064,10.76910973] ; [106.65203094,10.76914978] ; [106.65193939,10.76914024] ; [106.65190125,10.76912022] ; [106.65151215,10.76963997]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2417"
    ,"Station_Code":"QTB 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Chợ Tân Phước"
    ,"Station_Address":"130, đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.77181
    ,"Long":106.650063
    ,"Polyline":"[106.65151215,10.76963997] ; [106.65100861,10.77035046] ; [106.65029144,10.77136040] ; [106.65000916,10.77178001]"
    ,"Distance":"289"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"2416"
    ,"Station_Code":"QTB 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Ngã tư Lạc Long Quân"
    ,"Station_Address":"274 (260), đường Âu Cơ, Quận Tân Bình"
    ,"Lat":10.77401
    ,"Long":106.648605
    ,"Polyline":"[106.65000916,10.77178001] ; [106.64909363,10.77320004] ; [106.64855957,10.77398014]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1644"
    ,"Station_Code":"Q11 074"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Âu Cơ"
    ,"Station_Address":"501, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.774116
    ,"Long":106.647484
    ,"Polyline":"[106.64855957,10.77398014] ; [106.64803314,10.77474022] ; [106.64761353,10.77416992]"
    ,"Distance":"180"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1646"
    ,"Station_Code":"Q11 075"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Trạm Đăng Kiểm"
    ,"Station_Address":"345F, đường Lạc Long  Quân, Quận 11"
    ,"Lat":10.770237
    ,"Long":106.644716
    ,"Polyline":"[106.64761353,10.77416992] ; [106.64675903,10.77299976] ; [106.64611816,10.77210045] ; [106.64479065,10.77023029]"
    ,"Distance":"536"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1645"
    ,"Station_Code":"Q11 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Trường Lê Quý Đôn"
    ,"Station_Address":"Trường Lạc Long Quân, đường Lạc Long Quân, Quận 11"
    ,"Lat":10.767818
    ,"Long":106.642989
    ,"Polyline":"[106.64476013,10.77019024] ; [106.64450836,10.76980019] ; [106.64414978,10.76933002] ; [106.64360809,10.76856995] ; [106.64308167,10.76778984]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1029"
    ,"Station_Code":"Q11 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Bãi xe buýt Đầm Sen"
    ,"Station_Address":"40A, đường H òa Bình, Quận 11"
    ,"Lat":10.767302
    ,"Long":106.641181
    ,"Polyline":"[106.64308167,10.76778984] ; [106.64244843,10.76692963] ; [106.64232635,10.76694012] ; [106.64227295,10.76692009] ; [106.64222717,10.76686001] ; [106.64170074,10.76700020] ; [106.64127350,10.76714039] ; [106.64109802,10.76721954]"
    ,"Distance":"276"
  },
  {
     "Route_Id":"59"
    ,"Station_Id":"1022"
    ,"Station_Code":"BX91"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"BÃI XE BUÝT ĐẦM SEN"
    ,"Station_Address":"BÃI XE BUÝT  ĐẦM SEN, đường Hòa Bình, Quận 11"
    ,"Lat":10.76786
    ,"Long":106.639668
    ,"Polyline":"[106.64109802,10.76721954] ; [106.64103699,10.76710987] ; [106.64093018,10.76704979] ; [106.64080811,10.76702976] ; [106.64067078,10.76700974] ; [106.64067078,10.76688957] ; [106.64069366,10.76665020]"
    ,"Distance":"96"
  }]