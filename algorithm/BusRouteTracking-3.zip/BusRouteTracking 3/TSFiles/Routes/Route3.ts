export const Route3 =[
  {
     "Route_Id":"3"
    ,"Station_Id":"75"
    ,"Station_Code":"BX38"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"THẠNH LỘC"
    ,"Station_Address":"4/38 Tổ 11 KP 1 Phường Thạnh Lộc Quận 12, đường  Hà Huy Giáp, Quận 12"
    ,"Lat":10.878941
    ,"Long":106.682335
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"3262"
    ,"Station_Code":"Q12 049"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Trường Điện Lực 2"
    ,"Station_Address":"65/4, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.880816
    ,"Long":106.679075
    ,"Polyline":"[106.68233490,10.87894058] ; [106.68247223,10.87867737] ; [106.68122864,10.87812424] ; [106.67962646,10.88135338] ; [106.67942810,10.88154316] ; [106.67898560,10.88072205]"
    ,"Distance":"716"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"3263"
    ,"Station_Code":"Q12 050"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Chợ Thạnh Xuân"
    ,"Station_Address":"59/2 (Chợ Thạnh Xuân), đường Hà Huy Giáp , Quận 12"
    ,"Lat":10.878983
    ,"Long":106.678265
    ,"Polyline":"[106.67898560,10.88072205] ; [106.67846680,10.87935734] ; [106.67771912,10.87786579]"
    ,"Distance":"347"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"204"
    ,"Station_Code":"Q12 051"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Ga ra Thanh Hậu"
    ,"Station_Address":"79C , đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.875074
    ,"Long":106.67672
    ,"Polyline":"[106.67771912,10.87786579] ; [106.67746735,10.87703896] ; [106.67724609,10.87656021] ; [106.67696381,10.87625408]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"205"
    ,"Station_Code":"Q12 052"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Vườn kiểng Quang Dũng"
    ,"Station_Address":"59/4, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.871977
    ,"Long":106.676785
    ,"Polyline":"[106.67696381,10.87625408] ; [106.67691040,10.87570095] ; [106.67683411,10.87514782] ; [106.67685699,10.87267208] ; [106.67679596,10.87128067]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"206"
    ,"Station_Code":"Q12 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Cây xăng Tài Lộc"
    ,"Station_Address":"331, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.868015
    ,"Long":106.678233
    ,"Polyline":"[106.67679596,10.87128067] ; [106.67693329,10.87083340] ; [106.67707062,10.87023258] ; [106.67727661,10.86972713] ; [106.67750549,10.86918449] ; [106.67762756,10.86898994] ; [106.67788696,10.86865807] ; [106.67923737,10.86715126] ; [106.67963409,10.86668205] ; [106.67986298,10.86631298] ; [106.68010712,10.86588097] ; [106.68022156,10.86553860] ; [106.68030548,10.86527061] ; [106.68029022,10.86455917]"
    ,"Distance":"864"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"211"
    ,"Station_Code":"Q12 056"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Nhà hàng B ến Xưa"
    ,"Station_Address":"205, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.853474
    ,"Long":106.679006
    ,"Polyline":"[106.68029022,10.86455917] ; [106.68035126,10.86403751] ; [106.68030548,10.86341572] ; [106.68014526,10.86233616]"
    ,"Distance":"249"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"207"
    ,"Station_Code":"Q12 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Đình thần Giao Khẩu"
    ,"Station_Address":"297, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.864886
    ,"Long":106.680341
    ,"Polyline":"[106.68014526,10.86233616] ; [106.68007660,10.86205101]"
    ,"Distance":"32"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"208"
    ,"Station_Code":"Q12 055"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Ngã tư Ga"
    ,"Station_Address":"187A (396), đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.857984
    ,"Long":106.679649
    ,"Polyline":"[106.68007660,10.86205101] ; [106.68004608,10.86121368] ; [106.67990875,10.86001778] ; [106.67980194,10.85888004] ; [106.67964935,10.85798359]"
    ,"Distance":"456"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"209"
    ,"Station_Code":"QGV 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Cầu An Lộc"
    ,"Station_Address":"521 , đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.84862
    ,"Long":106.678535
    ,"Polyline":"[106.67964935,10.85798359] ; [106.67935181,10.85532856] ; [106.67893982,10.85245228] ; [106.67861938,10.85014439] ; [106.67853546,10.84862041]"
    ,"Distance":"1050"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"210"
    ,"Station_Code":"QGV 113"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"451, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.847015
    ,"Long":106.67826
    ,"Polyline":"[106.67853546,10.84862041] ; [106.67853546,10.84837437] ; [106.67837524,10.84739971] ; [106.67833710,10.84722614] ; [106.67826080,10.84701538]"
    ,"Distance":"182"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"212"
    ,"Station_Code":"QGV 114"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Bưu điện An Nhơn"
    ,"Station_Address":"357, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.843833
    ,"Long":106.677139
    ,"Polyline":"[106.67826080,10.84701538] ; [106.67776489,10.84548187] ; [106.67713928,10.84383297]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"214"
    ,"Station_Code":"QGV 115"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Ngã Tư An Nhơn"
    ,"Station_Address":"257, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.84142
    ,"Long":106.67634
    ,"Polyline":"[106.67713928,10.84383297] ; [106.67676544,10.84266853] ; [106.67633820,10.84142017]"
    ,"Distance":"282"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"215"
    ,"Station_Code":"QGV 116"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"197, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.839502
    ,"Long":106.675723
    ,"Polyline":"[106.67633820,10.84142017] ; [106.67617035,10.84084034] ; [106.67572021,10.83950233]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"216"
    ,"Station_Code":"QGV 117"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường Vinhempic"
    ,"Station_Address":"189 (đối diện F5), đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.836852
    ,"Long":106.675461
    ,"Polyline":"[106.67572021,10.83950233] ; [106.67548370,10.83852196] ; [106.67546082,10.83685207]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"218"
    ,"Station_Code":"QGV 118"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Cư xá Lam Sơn"
    ,"Station_Address":"189 (đối diện A4), đường Nguy ễn Oanh, Quận Gò Vấp"
    ,"Lat":10.834787
    ,"Long":106.675631
    ,"Polyline":"[106.67546082,10.83685207] ; [106.67548370,10.83560276] ; [106.67556763,10.83512402] ; [106.67562866,10.83478737]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"217"
    ,"Station_Code":"QGV 119"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Ngã Tư Phan Văn Trị"
    ,"Station_Address":"93 (2A), đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.831594
    ,"Long":106.676895
    ,"Polyline":"[106.67562866,10.83478737] ; [106.67626190,10.83326340] ; [106.67661285,10.83242035] ; [106.67689514,10.83159447]"
    ,"Distance":"382"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"220"
    ,"Station_Code":"QGV 120"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"27, đường Nguyễn Oanh, Quận G ò Vấp"
    ,"Lat":10.827205
    ,"Long":106.679606
    ,"Polyline":"[106.67689514,10.83159447] ; [106.67796326,10.83012390] ; [106.67891693,10.82849598] ; [106.67941284,10.82764721] ; [106.67960358,10.82720470]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"219"
    ,"Station_Code":"QGV 121"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Siêu Thị Big C Gò Vấp"
    ,"Station_Address":"Đối diện Big C, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.825682
    ,"Long":106.679606
    ,"Polyline":"[106.67960358,10.82720470] ; [106.67984009,10.82693100] ; [106.67984009,10.82667255] ; [106.67978668,10.82663059] ; [106.67976379,10.82654095] ; [106.67975616,10.82643032] ; [106.67982483,10.82633495] ; [106.67985535,10.82623005] ; [106.67984009,10.82612991] ; [106.67960358,10.82568169]"
    ,"Distance":"191"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"222"
    ,"Station_Code":"QGV 122"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Xóm Cháy"
    ,"Station_Address":"629B, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.821751
    ,"Long":106.678764
    ,"Polyline":"[106.67960358,10.82568169] ; [106.67951202,10.82525539] ; [106.67922211,10.82452297] ; [106.67902374,10.82360077] ; [106.67890167,10.82292652] ; [106.67882538,10.82226753] ; [106.67876434,10.82175064]"
    ,"Distance":"449"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"221"
    ,"Station_Code":"QGV 123"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"151, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.818837
    ,"Long":106.678719
    ,"Polyline":"[106.67876434,10.82175064] ; [106.67871857,10.81883717]"
    ,"Distance":"324"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"223"
    ,"Station_Code":"QGV 124"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Chợ Tân Sơn Nhất"
    ,"Station_Address":"37 - 39, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.815118
    ,"Long":106.678619
    ,"Polyline":"[106.67871857,10.81883717] ; [106.67870331,10.81706142] ; [106.67868042,10.81587124] ; [106.67861938,10.81511784]"
    ,"Distance":"414"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"224"
    ,"Station_Code":"QPN 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Đầu công viên Gia Định"
    ,"Station_Address":"Đối diện cây xanh số 7, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.813568
    ,"Long":106.677868
    ,"Polyline":"[106.67861938,10.81511784] ; [106.67864990,10.81450653] ; [106.67855835,10.81439018] ; [106.67851257,10.81430054] ; [106.67846680,10.81420040] ; [106.67787170,10.81356812]"
    ,"Distance":"204"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"225"
    ,"Station_Code":"QPN 035"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Cuối công viên Gia Định"
    ,"Station_Address":"Đối diện số 5, đường Hoàng Minh Giám, Quận Phú Nhuận"
    ,"Lat":10.809764
    ,"Long":106.674591
    ,"Polyline":"[106.67787170,10.81356812] ; [106.67459106,10.80976391]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"226"
    ,"Station_Code":"QPN 053"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Đầu Đường Đào Duy Anh"
    ,"Station_Address":"155, đường Đào Duy Anh, Quận Phú Nhuận"
    ,"Lat":10.807978
    ,"Long":106.674057
    ,"Polyline":"[106.67459106,10.80976391] ; [106.67360687,10.80837250] ; [106.67405701,10.80797768]"
    ,"Distance":"254"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"228"
    ,"Station_Code":"QPN 054"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Cuối Đường Đào Duy Anh"
    ,"Station_Address":"7-9, đường Đào Duy Anh, Quận Phú Nhuận"
    ,"Lat":10.805891
    ,"Long":106.677177
    ,"Polyline":"[106.67405701,10.80797768] ; [106.67717743,10.80589104]"
    ,"Distance":"413"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"230"
    ,"Station_Code":"QPN 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Đầu đường Hồ Văn Huê"
    ,"Station_Address":"129, đường Hồ Văn Huê, Quận Phú Nhuận"
    ,"Lat":10.804737
    ,"Long":106.677689
    ,"Polyline":"[106.67717743,10.80589104] ; [106.67808533,10.80540657] ; [106.67768860,10.80473709]"
    ,"Distance":"200"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"227"
    ,"Station_Code":"QPN 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Tháp Nước"
    ,"Station_Address":"43B, đường Hồ Văn Huê, Quận Phú Nhuận"
    ,"Lat":10.802824
    ,"Long":106.676602
    ,"Polyline":"[106.67768860,10.80473709] ; [106.67660522,10.80282402]"
    ,"Distance":"244"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"229"
    ,"Station_Code":"QPN 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Trung tâm hội nghị tiệc cưới White Palace"
    ,"Station_Address":"1B, đường Hồ Văn Huê, Quận Phú Nhuận"
    ,"Lat":10.800174
    ,"Long":106.675068
    ,"Polyline":"[106.67660522,10.80282402] ; [106.67507172,10.80017376]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"232"
    ,"Station_Code":"QPN 009"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"59, đường Hoàng Văn Thụ, Quận Phú Nhu ận"
    ,"Lat":10.799094
    ,"Long":106.679247
    ,"Polyline":"[106.67507172,10.80017376] ; [106.67492676,10.79981041] ; [106.67483521,10.79951477] ; [106.67924500,10.79913139]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"231"
    ,"Station_Code":"Q3 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trần Quang Khải"
    ,"Station_Address":"423 A, đường Hai Bà Trưng, Quận 3"
    ,"Lat":10.790939
    ,"Long":106.68795
    ,"Polyline":"[106.67924500,10.79913139] ; [106.68002319,10.79913044] ; [106.68024445,10.79919338] ; [106.68025970,10.79907227] ; [106.68090820,10.79767609] ; [106.68134308,10.79666424] ; [106.68159485,10.79617405] ; [106.68216705,10.79558372] ; [106.68325806,10.79473019] ; [106.68476868,10.79355526] ; [106.68642426,10.79223251] ; [106.68746185,10.79144192] ; [106.68795013,10.79093933]"
    ,"Distance":"1387"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"234"
    ,"Station_Code":"Q3 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Tân Định"
    ,"Station_Address":"Đối diện 274, đường Hai Bà Trưng, Quận  3"
    ,"Lat":10.788972
    ,"Long":106.690445
    ,"Polyline":"[106.68795013,10.79093933] ; [106.68825531,10.79078388] ; [106.68955994,10.78974533] ; [106.68995667,10.78936100] ; [106.69044495,10.78897190]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"233"
    ,"Station_Code":"Q3 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Công viên Lê Văn Tám"
    ,"Station_Address":"243, đường Hai Bà Trưng, Qu ận 3"
    ,"Lat":10.787174
    ,"Long":106.692653
    ,"Polyline":"[106.69044495,10.78897190] ; [106.69123840,10.78835392] ; [106.69264984,10.78717422]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"235"
    ,"Station_Code":"Q3 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Trần Cao Vân"
    ,"Station_Address":"157, đường Hai Bà Trưng, Quận 3"
    ,"Lat":10.784023
    ,"Long":106.696625
    ,"Polyline":"[106.69264984,10.78717422] ; [106.69432831,10.78593063] ; [106.69662476,10.78402328]"
    ,"Distance":"558"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"236"
    ,"Station_Code":"Q1 065"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Lê Duẩn"
    ,"Station_Address":"Đối diện Lãnh sự quán Pháp, đường Hai Bà Trưng, Qu ận 1"
    ,"Lat":10.78191
    ,"Long":106.69902
    ,"Polyline":"[106.69662476,10.78402328] ; [106.69787598,10.78297424] ; [106.69902039,10.78190994]"
    ,"Distance":"352"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"237"
    ,"Station_Code":"Q1 066"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"115Bis, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.779385
    ,"Long":106.701744
    ,"Polyline":"[106.69902039,10.78190994] ; [106.70174408,10.77938461]"
    ,"Distance":"410"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"238"
    ,"Station_Code":"Q1 067"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nhà Hát Thành Phố"
    ,"Station_Address":"101, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.777873
    ,"Long":106.70351
    ,"Polyline":"[106.70174408,10.77938461] ; [106.70350647,10.77787304]"
    ,"Distance":"256"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"239"
    ,"Station_Code":"Q1 068"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"Đối diện 2, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.775807
    ,"Long":106.705734
    ,"Polyline":"[106.70350647,10.77787304] ; [106.70573425,10.77580738]"
    ,"Distance":"335"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"79"
    ,"Station_Code":"Q1 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"21, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773299
    ,"Long":106.706359
    ,"Polyline":"[106.70573425,10.77580738] ; [106.70603943,10.77565956] ; [106.70597076,10.77552795] ; [106.70593262,10.77537537] ; [106.70594025,10.77521706] ; [106.70601654,10.77505398] ; [106.70614624,10.77492142] ; [106.70629120,10.77483749] ; [106.70645905,10.77478504] ; [106.70652771,10.77466869] ; [106.70635986,10.77329922]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"76"
    ,"Station_Code":"Q1 020"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Cục Hải Quan  Thành Phố"
    ,"Station_Address":"2-4, đường H àm Nghi, Quận 1"
    ,"Lat":10.770885
    ,"Long":106.705549
    ,"Polyline":"[106.70635986,10.77329922] ; [106.70623779,10.77154922] ; [106.70623779,10.77100086] ; [106.70613098,10.77089024] ; [106.70597076,10.77084827] ; [106.70555115,10.77088547]"
    ,"Distance":"338"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"78"
    ,"Station_Code":"Q1 021"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"84, đường Hàm Nghi, Quận 1"
    ,"Lat":10.77098
    ,"Long":106.703027
    ,"Polyline":"[106.70555115,10.77088547] ; [106.70302582,10.77097988]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"80"
    ,"Station_Code":"Q1 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Trường Cao Thắng"
    ,"Station_Address":"122, đường Hàm Nghi, Quận 1"
    ,"Lat":10.771048
    ,"Long":106.70166
    ,"Polyline":"[106.70302582,10.77097988] ; [106.70166016,10.77104759]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"82"
    ,"Station_Code":"Q1 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"42"
    ,"Station_Name":"Công ty Đư ờng sắt"
    ,"Station_Address":"136, đường Hàm Nghi , Quận 1"
    ,"Lat":10.771163
    ,"Long":106.699356
    ,"Polyline":"[106.70166016,10.77104759] ; [106.69935608,10.77116299]"
    ,"Distance":"252"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"202"
    ,"Station_Code":"Q1TC1C"
    ,"Station_Direction":"0"
    ,"Station_Order":"43"
    ,"Station_Name":"Bến Thành C"
    ,"Station_Address":"Bến Thành, đường Phạm Ngũ L ão, Quận 1"
    ,"Lat":10.770787
    ,"Long":106.698532
    ,"Polyline":"[106.69935608,10.77116299] ; [106.69906616,10.77110672] ; [106.69853210,10.77078724]"
    ,"Distance":"101"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"83"
    ,"Station_Code":"Q1 044"
    ,"Station_Direction":"0"
    ,"Station_Order":"44"
    ,"Station_Name":"Trường Ernst Thalmann"
    ,"Station_Address":"Đối diện 103, đường Phạm Ngũ Lão, Qu ận 1"
    ,"Lat":10.76981
    ,"Long":106.695957
    ,"Polyline":"[106.69853210,10.77078724] ; [106.69595337,10.76980972]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"203"
    ,"Station_Code":"Q1 045"
    ,"Station_Direction":"0"
    ,"Station_Order":"45"
    ,"Station_Name":"Đề Thám"
    ,"Station_Address":"Đối diện 171, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.769035
    ,"Long":106.693983
    ,"Polyline":"[106.69595337,10.76980972] ; [106.69398499,10.76903534]"
    ,"Distance":"232"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"240"
    ,"Station_Code":"Q1 046"
    ,"Station_Direction":"0"
    ,"Station_Order":"46"
    ,"Station_Name":"Chợ Thái Bình"
    ,"Station_Address":"Đối diện 361, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.767365
    ,"Long":106.689831
    ,"Polyline":"[106.69398499,10.76903534] ; [106.68983459,10.76736546]"
    ,"Distance":"491"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"0"
    ,"Station_Order":"47"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đường Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":"[106.68983459,10.76736546] ; [106.68956757,10.76722813] ; [106.68936157,10.76767635]"
    ,"Distance":"87"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"35"
    ,"Station_Code":"BX 01"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"TĐH xe buýt Sài Gòn"
    ,"Station_Address":"TĐH xe buýt Sài Gòn- CV 23/9, đư ờng Lê Lai, Quận 1"
    ,"Lat":10.767676
    ,"Long":106.689362
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"37"
    ,"Station_Code":"Q1 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Tôn Thất Tùng"
    ,"Station_Address":"Đối diện 204, đư ờng Lê Lai, Quận 1"
    ,"Lat":10.768551
    ,"Long":106.690341
    ,"Polyline":"[106.68936157,10.76767635] ; [106.68920135,10.76810741] ; [106.69033813,10.76855087]"
    ,"Distance":"185"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"36"
    ,"Station_Code":"Q1 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Nguyễn Thị Nghĩa"
    ,"Station_Address":"Đối diện 96, đường  Lê Lai, Quận 1"
    ,"Lat":10.769778
    ,"Long":106.693436
    ,"Polyline":"[106.69033813,10.76855087] ; [106.69191742,10.76920414] ; [106.69343567,10.76977825]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"40"
    ,"Station_Code":"Q1 043"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Khách sạn New world"
    ,"Station_Address":"Đối diện 1A Phạm Hồng Thái, đường Lê  Lai, Quận 1"
    ,"Lat":10.771091
    ,"Long":106.696773
    ,"Polyline":"[106.69343567,10.76977825] ; [106.69676971,10.77109146]"
    ,"Distance":"393"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"38"
    ,"Station_Code":"Q1TC1D"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Bến Thành D"
    ,"Station_Address":"B ến Thành, đường Phạm Ngũ Lão, Quận 1"
    ,"Lat":10.770603
    ,"Long":106.698441
    ,"Polyline":"[106.69676971,10.77109146] ; [106.69783783,10.77156448] ; [106.69794464,10.77157021] ; [106.69804382,10.77152824] ; [106.69805145,10.77143860] ; [106.69809723,10.77135372] ; [106.69815063,10.77125931] ; [106.69823456,10.77121735] ; [106.69829559,10.77117538] ; [106.69835663,10.77114296] ; [106.69847870,10.77114296] ; [106.69854736,10.77114296] ; [106.69860840,10.77115917] ; [106.69873047,10.77118015] ; [106.69898224,10.77096462] ; [106.69934845,10.77042675] ; [106.69809723,10.76933575] ; [106.69743347,10.77015305] ; [106.69765472,10.77030563] ; [106.69844055,10.77060318]"
    ,"Distance":"781"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"30"
    ,"Station_Code":"Q1 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Hàm Nghi"
    ,"Station_Address":"163, đường H àm Nghi, Quận 1"
    ,"Lat":10.770943
    ,"Long":106.699562
    ,"Polyline":"[106.69844055,10.77060318] ; [106.69910431,10.77093792] ; [106.69956207,10.77094269]"
    ,"Distance":"132"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"28"
    ,"Station_Code":"Q1 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Chợ Củ"
    ,"Station_Address":"89A, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770822
    ,"Long":106.70196
    ,"Polyline":"[106.69956207,10.77094269] ; [106.70195770,10.77082157]"
    ,"Distance":"263"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"32"
    ,"Station_Code":"Q1 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hồ Tùng Mậu"
    ,"Station_Address":"67, đường Hàm Nghi, Quận 1"
    ,"Lat":10.770722
    ,"Long":106.704074
    ,"Polyline":"[106.70195770,10.77082157] ; [106.70407104,10.77072239]"
    ,"Distance":"231"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"31"
    ,"Station_Code":"Q1 024"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Bến Bạch Đằng"
    ,"Station_Address":"B ến thủy nội địa Thủ Thiêm, đường Tôn Đức Thắng, Quận 1"
    ,"Lat":10.773878
    ,"Long":106.706648
    ,"Polyline":"[106.70407104,10.77072239] ; [106.70449829,10.77069569] ; [106.70513916,10.76940918] ; [106.70540619,10.76943588] ; [106.70565033,10.76947308] ; [106.70578766,10.76952267] ; [106.70590973,10.76954651] ; [106.70610046,10.76964664] ; [106.70618439,10.76975250] ; [106.70622253,10.76988888] ; [106.70629120,10.77014160] ; [106.70635223,10.77037430] ; [106.70638275,10.77061653] ; [106.70646667,10.77228737] ; [106.70664978,10.77387810]"
    ,"Distance":"794"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"34"
    ,"Station_Code":"Q1 057"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Công Trường Mê Linh"
    ,"Station_Address":"2, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.776048
    ,"Long":106.705719
    ,"Polyline":"[106.70664978,10.77387810.06.70672607] ; [10.77569675,106.70666504] ; [10.77578640,106.70659637] ; [10.77584934,106.70645905] ; [10.77585983,106.70631409] ; [10.77583313,106.70619202] ; [10.77578831,106.70606995] ; [10.77574348,106.70571899]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"42"
    ,"Station_Code":"Q1 058"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Nhà Hát Thành Phố"
    ,"Station_Address":"74/A2-74/A4, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.778031
    ,"Long":106.703559
    ,"Polyline":"[106.70571899,10.77604771] ; [106.70355988,10.77803135]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"44"
    ,"Station_Code":"Q1 059"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Bệnh viện Nhi Đồng 2"
    ,"Station_Address":"Đối diện 115Ter, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.779881
    ,"Long":106.701536
    ,"Polyline":"[106.70355988,10.77803135] ; [106.70153809,10.77988052]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"39"
    ,"Station_Code":"Q1 060"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Bưu Điện Thành Phố"
    ,"Station_Address":"86, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.780645
    ,"Long":106.700673
    ,"Polyline":"[106.70153809,10.77988052] ; [106.70067596,10.78064537]"
    ,"Distance":"128"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"41"
    ,"Station_Code":"Q1 061"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Sở Công Th ương"
    ,"Station_Address":"142, đường Hai Bà Tr ưng, Quận 1"
    ,"Lat":10.784297
    ,"Long":106.696526
    ,"Polyline":"[106.70067596,10.78064537] ; [106.69652557,10.78429699]"
    ,"Distance":"609"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"43"
    ,"Station_Code":"Q1 062"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Công viên Lê Văn Tám"
    ,"Station_Address":"Đối diện 245, đường Hai Bà Trưng, Qu ận 1"
    ,"Lat":10.787427
    ,"Long":106.692599
    ,"Polyline":"[106.69652557,10.78429699] ; [106.69259644,10.78742695]"
    ,"Distance":"553"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"46"
    ,"Station_Code":"Q1 063"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Nhà thờ Tân Định"
    ,"Station_Address":"298, đường Hai Bà Trưng, Qu ận 1"
    ,"Lat":10.789215
    ,"Long":106.690399
    ,"Polyline":"[106.69259644,10.78742695] ; [106.69142914,10.78834343] ; [106.69039917,10.78921509]"
    ,"Distance":"312"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"47"
    ,"Station_Code":"Q1 064"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Tân Định"
    ,"Station_Address":"372-374, đường Hai Bà Trưng, Quận 1"
    ,"Lat":10.790456
    ,"Long":106.688843
    ,"Polyline":"[106.69039917,10.78921509] ; [106.69006348,10.78941917] ; [106.68884277,10.79045582]"
    ,"Distance":"220"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"45"
    ,"Station_Code":"QPN 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Cầu Kiệu"
    ,"Station_Address":"28 - 30, đường Phan Đình Ph ùng, Quận Phú Nhuận"
    ,"Lat":10.793429
    ,"Long":106.685105
    ,"Polyline":"[106.68884277,10.79045582] ; [106.68762970,10.79144764] ; [106.68585968,10.79278564] ; [106.68510437,10.79342937]"
    ,"Distance":"526"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"49"
    ,"Station_Code":"QPN 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chợ Phú Nhuận"
    ,"Station_Address":"158 - 160, đường Phan Đình Phùng, Quận Ph ú Nhuận"
    ,"Lat":10.794836
    ,"Long":106.683313
    ,"Polyline":"[106.68510437,10.79342937] ; [106.68331146,10.79483604]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"48"
    ,"Station_Code":"QPN 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trường Cao Đẳng Kinh tế Đối ngoại"
    ,"Station_Address":"312 - 314, đường Phan Đình Phùng, Quận Phú Nhuận"
    ,"Lat":10.79795
    ,"Long":106.680905
    ,"Polyline":"[106.68331146,10.79483604] ; [106.68219757,10.79568958] ; [106.68164825,10.79625320] ; [106.68091583,10.79799843]"
    ,"Distance":"452"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"50"
    ,"Station_Code":"QPN 001"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Ngã Tư Phú Nhuận"
    ,"Station_Address":"392, đường Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.799713
    ,"Long":106.680138
    ,"Polyline":"[106.68091583,10.79799843] ; [106.68051147,10.79880905] ; [106.68013763,10.79971313]"
    ,"Distance":"209"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"51"
    ,"Station_Code":"QPN 002"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Nhà Truyền Thông"
    ,"Station_Address":"466, đường Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.802232
    ,"Long":106.679245
    ,"Polyline":"[106.68013763,10.79971313] ; [106.67948914,10.80121231] ; [106.67927551,10.80197620] ; [106.67924500,10.80223179]"
    ,"Distance":"298"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"52"
    ,"Station_Code":"QPN 003"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Ngã Ba Hồ Văn Huê"
    ,"Station_Address":"582, đường Nguyễn Kiệm, Quận  Phú Nhuận"
    ,"Lat":10.805259
    ,"Long":106.678759
    ,"Polyline":"[106.67924500,10.80223179] ; [106.67915344,10.80255032] ; [106.67898560,10.80375671] ; [106.67875671,10.80525875]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"53"
    ,"Station_Code":"QPN 004"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Coop Mart Nguyễn Kiệm"
    ,"Station_Address":"668-670, đường Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.807156
    ,"Long":106.678555
    ,"Polyline":"[106.67875671,10.80525875] ; [106.67861176,10.80611229] ; [106.67853546,10.80671883] ; [106.67852783,10.80774593]"
    ,"Distance":"279"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"54"
    ,"Station_Code":"QPN 005"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chùa Vạn Hạnh"
    ,"Station_Address":"750, đư ờng Nguyễn Kiệm, Quận Phú Nhuận"
    ,"Lat":10.810723
    ,"Long":106.678609
    ,"Polyline":"[106.67852783,10.80774593] ; [106.67857361,10.81005859]"
    ,"Distance":"258"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"55"
    ,"Station_Code":"QGV 125"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Trường Cao đ ẳng Hải Quan"
    ,"Station_Address":"780A, đường Nguyễn Kiệm, Quận Gò Vấp"
    ,"Lat":10.812475
    ,"Long":106.678711
    ,"Polyline":"[106.67857361,10.81005859] ; [106.67856598,10.81077576] ; [106.67863464,10.81133461] ; [106.67866516,10.81191921] ; [106.67871094,10.81247520]"
    ,"Distance":"270"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"56"
    ,"Station_Code":"QGV 040"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm đầu Nguyễn Thái Sơn"
    ,"Station_Address":"36, đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.815178
    ,"Long":106.679596
    ,"Polyline":"[106.67871094,10.81247520] ; [106.67877197,10.81392670] ; [106.67890930,10.81394768] ; [106.67902374,10.81401062] ; [106.67911530,10.81407928] ; [106.67918396,10.81418514] ; [106.67919159,10.81435299] ; [106.67907715,10.81453800] ; [106.67959595,10.81517792]"
    ,"Distance":"351"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"59"
    ,"Station_Code":"QGV 041"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Bệnh Viện 175"
    ,"Station_Address":"90, đường  Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.81674
    ,"Long":106.680847
    ,"Polyline":"[106.67959595,10.81517792] ; [106.68084717,10.81674004]"
    ,"Distance":"221"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"57"
    ,"Station_Code":"QGV 042"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Ngã Ba Phạm Ngũ Lão"
    ,"Station_Address":"182 (148B),  đường Nguyễn Thái Sơn, Quận Gò Vấp"
    ,"Lat":10.819923
    ,"Long":106.683378
    ,"Polyline":"[106.68084717,10.81674004] ; [106.68217468,10.81848431] ; [106.68338013,10.81992340]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"60"
    ,"Station_Code":"QGV 187"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Nhà Tang  Lễ"
    ,"Station_Address":"220 (175), đường Phạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.822141
    ,"Long":106.682616
    ,"Polyline":"[106.68338013,10.81992340] ; [106.68357849,10.82030201] ; [106.68261719,10.82214069]"
    ,"Distance":"277"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"61"
    ,"Station_Code":"QGV 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Siêu Thị  Big C"
    ,"Station_Address":"72 (45), đường Ph ạm Ngũ Lão , Quận Gò Vấp"
    ,"Lat":10.825861
    ,"Long":106.680561
    ,"Polyline":"[106.68261719,10.82214069] ; [106.68055725,10.82586098]"
    ,"Distance":"471"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"58"
    ,"Station_Code":"QGV 104"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Siêu thị Văn Lang"
    ,"Station_Address":"36, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.827508
    ,"Long":106.679634
    ,"Polyline":"[106.68055725,10.82586098] ; [106.68015289,10.82637215] ; [106.68018341,10.82649326] ; [106.68014526,10.82661438] ; [106.68003845,10.82669926] ; [106.67990875,10.82671452] ; [106.67989349,10.82697773] ; [106.67963409,10.82750797]"
    ,"Distance":"224"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"65"
    ,"Station_Code":"QGV 105"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Ngã Tư Phan  Văn Trị"
    ,"Station_Address":"150, đường Nguy ễn Oanh, Quận Gò Vấp"
    ,"Lat":10.829979
    ,"Long":106.678246
    ,"Polyline":"[106.67963409,10.82750797] ; [106.67824554,10.82997894]"
    ,"Distance":"314"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"62"
    ,"Station_Code":"QGV 106"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Doanh trại Quân đội"
    ,"Station_Address":"152, đường Nguy ễn Oanh, Quận Gò Vấp"
    ,"Lat":10.832563
    ,"Long":106.676747
    ,"Polyline":"[106.67824554,10.82997894] ; [106.67697906,10.83190441] ; [106.67675018,10.83256340]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"67"
    ,"Station_Code":"QGV 107"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Cư xá Lam Sơn"
    ,"Station_Address":"214, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.836141
    ,"Long":106.675637
    ,"Polyline":"[106.67675018,10.83256340] ; [106.67651367,10.83299541] ; [106.67564392,10.83514500] ; [106.67559814,10.83555603] ; [106.67563629,10.83614063]"
    ,"Distance":"423"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"63"
    ,"Station_Code":"QGV 108"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Đài Liệt sĩ"
    ,"Station_Address":"Đối diện 197 (93), đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.839297
    ,"Long":106.67583
    ,"Polyline":"[106.67563629,10.83614063] ; [106.67562866,10.83854294] ; [106.67582703,10.83929729]"
    ,"Distance":"354"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"72"
    ,"Station_Code":"QGV 109"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Ngã tư An Nhơn"
    ,"Station_Address":"388, đường Nguy ễn Oanh, Quận Gò Vấp"
    ,"Lat":10.842342
    ,"Long":106.676903
    ,"Polyline":"[106.67582703,10.83929729] ; [106.67601776,10.83999729] ; [106.67658997,10.84173584] ; [106.67670441,10.84205246] ; [106.67690277,10.84234238]"
    ,"Distance":"360"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"64"
    ,"Station_Code":"QGV 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Bến Đò"
    ,"Station_Address":"530, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.846894
    ,"Long":106.678512
    ,"Polyline":"[106.67690277,10.84234238] ; [106.67851257,10.84689426]"
    ,"Distance":"536"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"4754"
    ,"Station_Code":"QGV 111"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Cầu An Lộc"
    ,"Station_Address":"604, đường Nguyễn Oanh, Quận Gò Vấp"
    ,"Lat":10.84887
    ,"Long":106.678796
    ,"Polyline":"[106.67851257,10.84689426] ; [106.67874146,10.84839058] ; [106.67885590,10.84965992]"
    ,"Distance":"310"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"73"
    ,"Station_Code":"Q12 032"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Nhà hàng Bến Xưa"
    ,"Station_Address":"42, đường Hà Huy  Giáp, Quận 12"
    ,"Lat":10.852642
    ,"Long":106.679285
    ,"Polyline":"[106.67885590,10.84965992] ; [106.67884827,10.85010815] ; [106.67902374,10.85145092] ; [106.67911530,10.85178280]"
    ,"Distance":"239"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"213"
    ,"Station_Code":"Q12 033"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Ngã tư Ga"
    ,"Station_Address":"154, đường Hà Huy Giáp, Qu ận 12"
    ,"Lat":10.857331
    ,"Long":106.679907
    ,"Polyline":"[106.67911530,10.85178280] ; [106.67922974,10.85273647] ; [106.67948151,10.85437012]"
    ,"Distance":"291"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"68"
    ,"Station_Code":"Q12 034"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Đình thần Giao Khẩu"
    ,"Station_Address":"332, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.865217
    ,"Long":106.680433
    ,"Polyline":"[106.67948151,10.85437012] ; [106.67969513,10.85647774] ; [106.67985535,10.85746765] ; [106.68006134,10.85959053] ; [106.68040466,10.86217785] ; [106.68054199,10.86351585] ; [106.68057251,10.86390591] ; [106.68052673,10.86423779] ; [106.68051147,10.86450100] ; [106.68051147,10.86482811]"
    ,"Distance":"1171"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"74"
    ,"Station_Code":"Q12 035"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Cây xăng Tài Lộc"
    ,"Station_Address":"408B, đường H à Huy Giáp, Quận 12"
    ,"Lat":10.86831
    ,"Long":106.678319
    ,"Polyline":"[106.68051147,10.86482811] ; [106.68041992,10.86527061] ; [106.68016815,10.86594963] ; [106.67985535,10.86650276] ; [106.67929840,10.86729813]"
    ,"Distance":"309"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"69"
    ,"Station_Code":"Q12 036"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"Vườn kiểng Quang Dũng"
    ,"Station_Address":"452, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.871371
    ,"Long":106.676978
    ,"Polyline":"[106.67929840,10.86729813] ; [106.67892456,10.86763573] ; [106.67819214,10.86848354] ; [106.67770386,10.86904240] ; [106.67758179,10.86941624]"
    ,"Distance":"306"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"70"
    ,"Station_Code":"Q12 037"
    ,"Station_Direction":"1"
    ,"Station_Order":"44"
    ,"Station_Name":"Ga ra Thanh Hậu"
    ,"Station_Address":"508 (63A), đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.875454
    ,"Long":106.677032
    ,"Polyline":"[106.67758179,10.86941624] ; [106.67716980,10.87024879] ; [106.67704010,10.87084389] ; [106.67703247,10.87313557]"
    ,"Distance":"426"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"71"
    ,"Station_Code":"Q12 038"
    ,"Station_Direction":"1"
    ,"Station_Order":"45"
    ,"Station_Name":"Chợ Thạnh Xuân"
    ,"Station_Address":"Nhà văn hóa P. Thạnh Lộc, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.878493
    ,"Long":106.678201
    ,"Polyline":"[106.67703247,10.87313557] ; [106.67694855,10.87395763] ; [106.67693329,10.87510586] ; [106.67701721,10.87565899] ; [106.67745972,10.87665462]"
    ,"Distance":"403"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"77"
    ,"Station_Code":"Q12 039"
    ,"Station_Direction":"1"
    ,"Station_Order":"46"
    ,"Station_Name":"Trường Cao đẳng điện lực 2"
    ,"Station_Address":"554 (Trường điện lực 2), đường Hà Huy Giáp, Quận  12"
    ,"Lat":10.880395
    ,"Long":106.679027
    ,"Polyline":"[106.67745972,10.87665462] ; [106.67807770,10.87824535] ; [106.67876434,10.87975216]"
    ,"Distance":"373"
  },
  {
     "Route_Id":"3"
    ,"Station_Id":"75"
    ,"Station_Code":"BX38"
    ,"Station_Direction":"1"
    ,"Station_Order":"47"
    ,"Station_Name":"THẠNH LỘC"
    ,"Station_Address":"4/38 Tổ 11 KP 1 Phường Thạnh Lộc Quận  12, đường Hà Huy Giáp, Quận 12"
    ,"Lat":10.878941
    ,"Long":106.682335
    ,"Polyline":"[106.67876434,10.87975216] ; [106.67946625,10.88142204] ; [106.67955780,10.88131714] ; [106.68050385,10.87940502] ; [106.68118286,10.87804031] ; [106.68249512,10.87857723] ; [106.68233490,10.87894058]"
    ,"Distance":"822"
  }]