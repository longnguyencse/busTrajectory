export const Route123 =[

  {
     "Route_Id":"123"
    ,"Station_Id":"3924"
    ,"Station_Code":"BX69"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Cầu Thầy Cai"
    ,"Station_Address":"ĐẦU BẾN CẦU THẦY CAI, đường Tỉnh lộ 8 , Củ Chi, Huyện Củ Chi"
    ,"Lat":10.94300365447998
    ,"Long":106.45408630371094
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3928"
    ,"Station_Code":"HCC 203"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Cầu Th ầy Cai"
    ,"Station_Address":"Đối diện Trươ ̀ng Nguyễn Văn Lịch, đường Tỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.943926
    ,"Long":106.455467
    ,"Polyline":"[106.45430756,10.94281006] ; [106.45536804,10.94400978]"
    ,"Distance":"176"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3930"
    ,"Station_Code":"HCC 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Công ty Kim Tường"
    ,"Station_Address":"Đối  diện 83, đường Tỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.94795
    ,"Long":106.459335
    ,"Polyline":"[106.45536804,10.94400978] ; [106.45675659,10.94554996] ; [106.45697784,10.94577026] ; [106.46016693,10.94880962] ; [106.46215057,10.95081043] ; [106.46222687,10.95090008]"
    ,"Distance":"1073"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3929"
    ,"Station_Code":"HCC 205"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"nhà th ờ Liêu Tộc"
    ,"Station_Address":"178, đường T ỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.95455
    ,"Long":106.46563
    ,"Polyline":"[106.46222687,10.95090008] ; [106.46321869,10.95186996] ; [106.46425629,10.95324039] ; [106.46479797,10.95386982] ; [106.46540070,10.95440006] ; [106.46605682,10.95497036]"
    ,"Distance":"619"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3925"
    ,"Station_Code":"HCC 206"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"cafe Giọt Đắng"
    ,"Station_Address":"260, đường T ỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.958117
    ,"Long":106.469048
    ,"Polyline":"[106.46605682,10.95497036] ; [106.46688843,10.95563984] ; [106.46733856,10.95602989] ; [106.46779633,10.95646954] ; [106.46855164,10.95748043] ; [106.46938324,10.95860958] ; [106.46945190,10.95870018]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3926"
    ,"Station_Code":"HCC 207"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"UBND xã Tân An Hội"
    ,"Station_Address":"336, đường Tỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.9615
    ,"Long":106.47245
    ,"Polyline":"[106.46945190,10.95870018] ; [106.46977234,10.95913982] ; [106.47026062,10.96014023] ; [106.47071075,10.96107960] ; [106.47093201,10.96133995] ; [106.47123718,10.96142006] ; [106.47305298,10.96158028] ; [106.47374725,10.96156979] ; [106.47458649,10.96142960] ; [106.47501373,10.96131992]"
    ,"Distance":"787"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3927"
    ,"Station_Code":"HCC 208"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Uốn tóc Thanh Loan"
    ,"Station_Address":"374, đường T ỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.961033
    ,"Long":106.475731
    ,"Polyline":"[106.47501373,10.96131992] ; [106.47576904,10.96105003] ; [106.47608185,10.96100044] ; [106.47860718,10.96090984] ; [106.47998047,10.96090984] ; [106.48021698,10.96094036] ; [106.48034668,10.96100044] ; [106.48104858,10.96144009]"
    ,"Distance":"682"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3932"
    ,"Station_Code":"HCC 209"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Quán Xuân Anh"
    ,"Station_Address":"79, đường Tỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.96215
    ,"Long":106.482231
    ,"Polyline":"[106.48104858,10.96144009] ; [106.48426819,10.96348953] ; [106.48445129,10.96368027] ; [106.48449707,10.96387005]"
    ,"Distance":"470"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3931"
    ,"Station_Code":"HCC 210"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Công an  huyện Củ Chi"
    ,"Station_Address":"532, đường Tỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.966017
    ,"Long":106.485229
    ,"Polyline":"[106.48449707,10.96387005] ; [106.48497772,10.96543980] ; [106.48533630,10.96652031]"
    ,"Distance":"308"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Bến xe C ủ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc  lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":"[106.48533630,10.96652031] ; [106.48564911,10.96747017] ; [106.48596191,10.96819019] ; [106.48581696,10.96829987] ; [106.48567200,10.96842957] ; [106.48429871,10.96924973] ; [106.48397064,10.96947956] ; [106.48377991,10.96965027] ; [106.48238373,10.97064018] ; [106.48179626,10.97111034] ; [106.48171234,10.97119999] ; [106.48169708,10.97130013] ; [106.48175049,10.97136021] ; [106.48181152,10.97138977] ; [106.48197937,10.97140026] ; [106.48210144,10.97142029] ; [106.48220062,10.97148037] ; [106.48226166,10.97154999]"
    ,"Distance":"854"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"732"
    ,"Station_Code":"BX 63"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Củ Chi"
    ,"Station_Address":"Bến xe Củ Chi, đường Quốc lộ 22, Huyện Củ Chi"
    ,"Lat":10.971617
    ,"Long":106.482099
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3917"
    ,"Station_Code":"QCCT381"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Cửa sắt Đồng Tâm"
    ,"Station_Address":"Đối diện 79, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.962066650390625
    ,"Long":106.48193359375
    ,"Polyline":"[106.48226166,10.97154999] ; [106.48220062,10.97148037] ; [106.48210144,10.97142029] ; [106.48197937,10.97140026] ; [106.48181152,10.97138977] ; [106.48175049,10.97136021] ; [106.48169708,10.97130013] ; [106.48171234,10.97119999] ; [106.48179626,10.97111034] ; [106.48238373,10.97064018] ; [106.48377991,10.96965027] ; [106.48397064,10.96947956] ; [106.48429871,10.96924973] ; [106.48493195,10.96887016] ; [106.48567200,10.96842957] ; [106.48581696,10.96829987] ; [106.48596191,10.96819019] ; [106.48564911,10.96747017] ; [106.48549652,10.96702003]"
    ,"Distance":"795"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3918"
    ,"Station_Code":"QCCT383"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Đại lý Tố Trinh"
    ,"Station_Address":"281, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.961182594299316
    ,"Long":106.47551727294922
    ,"Polyline":"[106.48549652,10.96702003] ; [106.48497772,10.96543980] ; [106.48445129,10.96368027] ; [106.48426819,10.96348953] ; [106.48400879,10.96333027] ; [106.48143005,10.96168041]"
    ,"Distance":"788"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3921"
    ,"Station_Code":"QCCT384"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"UBND xã Tân An Hội"
    ,"Station_Address":"Đối diện 332 , đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.961583137512207
    ,"Long":106.47229766845703
    ,"Polyline":"[106.48143005,10.96168041] ; [106.48034668,10.96100044] ; [106.48021698,10.96094036] ; [106.47998047,10.96090984] ; [106.47860718,10.96090984] ; [106.47608185,10.96100044] ; [106.47576904,10.96105003] ; [106.47557831,10.96111965]"
    ,"Distance":"665"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3919"
    ,"Station_Code":"QCCT385"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Vật liệu xây dựng Thu Hà"
    ,"Station_Address":"Đối diện 276, đường Tỉnh lộ 8, Củ Chi, Huyện C ủ Chi"
    ,"Lat":10.958582878112793
    ,"Long":106.46925354003906
    ,"Polyline":"[106.47557831,10.96111965] ; [106.47489929,10.96135998] ; [106.47403717,10.96152973] ; [106.47348785,10.96158028] ; [106.47305298,10.96158028] ; [106.47142792,10.96144009] ; [106.47123718,10.96142006] ; [106.47093201,10.96133995] ; [106.47071075,10.96107960] ; [106.47046661,10.96059036] ; [106.46977234,10.95913982] ; [106.46974182,10.95909977]"
    ,"Distance":"799"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3920"
    ,"Station_Code":"QCCT386"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"công ty Bảo vệ Thái Dương H ệ"
    ,"Station_Address":"137, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.954683303833008
    ,"Long":106.46558380126953
    ,"Polyline":"[106.46974182,10.95909977] ; [106.46830750,10.95716000] ; [106.46779633,10.95646954] ; [106.46733856,10.95602989] ; [106.46655273,10.95536995]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3922"
    ,"Station_Code":"QCCT387"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"công ty Kim Tường"
    ,"Station_Address":"111, đường Tỉnh lộ 8, Củ Chi, Huyện  Củ Chi"
    ,"Lat":10.949832916259766
    ,"Long":106.4610366821289
    ,"Polyline":"[106.46655273,10.95536995] ; [106.46540070,10.95440006] ; [106.46479797,10.95386982] ; [106.46425629,10.95324039] ; [106.46321869,10.95186996] ; [106.46286011,10.95151043]"
    ,"Distance":"591"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3923"
    ,"Station_Code":"QCCT388"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Cầu Thầy Cai"
    ,"Station_Address":"21B, đường Tỉnh lộ 8, Huyện Củ Chi"
    ,"Lat":10.943751335144043
    ,"Long":106.45500183105469
    ,"Polyline":"[106.46286011,10.95151043] ; [106.46016693,10.94880962] ; [106.45675659,10.94554996] ; [106.45442963,10.94293976]"
    ,"Distance":"1326"
  },
  {
     "Route_Id":"123"
    ,"Station_Id":"3924"
    ,"Station_Code":"BX69"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Cầu Thầy Cai"
    ,"Station_Address":"ĐẦU BẾN C ẦU THẦY CAI, đường Tỉnh lộ 8, Củ Chi, Huyện Củ Chi"
    ,"Lat":10.94300365447998
    ,"Long":106.45408630371094
    ,"Polyline":"[106.45442963,10.94293976] ; [106.45430756,10.94281006]"
    ,"Distance":"19"
  }]