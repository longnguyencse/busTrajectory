export const Route68 =[

  {
     "Route_Id":"68"
    ,"Station_Id":"3043"
    ,"Station_Code":"BX 58"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"Hưng Long"
    ,"Station_Address":"ĐẦU BẾN HƯNG LONG, đường Quốc lộ 50, Huyện  Bình Chánh"
    ,"Lat":10.637669
    ,"Long":106.647307
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3116"
    ,"Station_Code":"LA_4"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Nhà máy Kizunai"
    ,"Station_Address":"B8/33B6, đường Qu ốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.633061
    ,"Long":106.660509
    ,"Polyline":"[106.64697266,10.63774776] ; [106.66201019,10.62981892] ; [106.65876007,10.63666821]"
    ,"Distance":"2709"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3119"
    ,"Station_Code":"LA_1"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Hoàng Thái Mart"
    ,"Station_Address":"Hoàng Thái Mart, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.638318
    ,"Long":106.657993
    ,"Polyline":"[106.65885925,10.63670444] ; [106.65802002,10.63812828] ; [106.65748596,10.63996315] ; [106.65713501,10.64180660]"
    ,"Distance":"604"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3118"
    ,"Station_Code":"HBC 198"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Trạm xăng Hoàng Thái"
    ,"Station_Address":"Đối diện D8A/34, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.644481
    ,"Long":106.656861
    ,"Polyline":"[106.65713501,10.64180660] ; [106.65668488,10.64518356]"
    ,"Distance":"379"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3121"
    ,"Station_Code":"HBC 199"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Cầu Ông Thìn"
    ,"Station_Address":"A11/32, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.648282
    ,"Long":106.656024
    ,"Polyline":"[106.65668488,10.64518356] ; [106.65653229,10.64647865] ; [106.65632629,10.64733315] ; [106.65596008,10.64827061]"
    ,"Distance":"355"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3120"
    ,"Station_Code":"HBC 200"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"Chùa Phước Hội"
    ,"Station_Address":"B7/177, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.652305
    ,"Long":106.654791
    ,"Polyline":"[106.65596008,10.64827061] ; [106.65477753,10.65217018]"
    ,"Distance":"453"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3123"
    ,"Station_Code":"HBC 201"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Chùa Tam Bửu"
    ,"Station_Address":"B2/63/1, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.656296
    ,"Long":106.653214
    ,"Polyline":"[106.65477753,10.65217018] ; [106.65443420,10.65336418] ; [106.65396881,10.65458012]"
    ,"Distance":"283"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3122"
    ,"Station_Code":"HBC 202"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Chùa Linh Hòa"
    ,"Station_Address":"B2/35A, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.659902
    ,"Long":106.651905
    ,"Polyline":"[106.65396881,10.65458012] ; [106.65274048,10.65721321] ; [106.65212250,10.65858364] ; [106.65184021,10.66010094]"
    ,"Distance":"661"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3125"
    ,"Station_Code":"HBC 203"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Đường liên Ấp 1-2"
    ,"Station_Address":"A8/240A, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.663001
    ,"Long":106.651658
    ,"Polyline":"[106.65184021,10.66010094] ; [106.65160370,10.66299629]"
    ,"Distance":"323"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3124"
    ,"Station_Code":"HBC 204"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Nghĩa trang Đa Phước"
    ,"Station_Address":"Đối diện D14/407, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.666502
    ,"Long":106.651352
    ,"Polyline":"[106.65160370,10.66299629] ; [106.65135193,10.66594124]"
    ,"Distance":"329"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3127"
    ,"Station_Code":"HBC 205"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Trường THCS Đa Phước"
    ,"Station_Address":"E11 /323, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.66986
    ,"Long":106.651175
    ,"Polyline":"[106.65135193,10.66594124] ; [106.65113831,10.66886520]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3126"
    ,"Station_Code":"HBC 206"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Công ty H ồng Nhất"
    ,"Station_Address":"A1/6, đường Qu ốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.673508
    ,"Long":106.651003
    ,"Polyline":"[106.65113831,10.66886520] ; [106.65100098,10.67195511]"
    ,"Distance":"344"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3128"
    ,"Station_Code":"HBC 207"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Đình Chánh An Phú"
    ,"Station_Address":"A6/183, đường  Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.677899
    ,"Long":106.650681
    ,"Polyline":"[106.65100098,10.67195511] ; [106.65096283,10.67348194] ; [106.65081024,10.67502308]"
    ,"Distance":"342"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3129"
    ,"Station_Code":"HBC 208"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường chuy ên biệt Rạng Đông"
    ,"Station_Address":"A12/363 , đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.683149
    ,"Long":106.651261
    ,"Polyline":"[106.65081024,10.67502308] ; [106.65057373,10.67772579]"
    ,"Distance":"302"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3131"
    ,"Station_Code":"HBC 209"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Trường ti ểu học Phong Phú"
    ,"Station_Address":"Trường tiểu học Phong Phú, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.688516
    ,"Long":106.653691
    ,"Polyline":"[106.65057373,10.67772579] ; [106.65044403,10.67951202] ; [106.65039063,10.68051338] ; [106.65051270,10.68147564]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3130"
    ,"Station_Code":"HBC 210"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Trịnh Quang Nghị"
    ,"Station_Address":"D3/65, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.692622
    ,"Long":106.655096
    ,"Polyline":"[106.65051270,10.68147564] ; [106.65187836,10.68475437]"
    ,"Distance":"394"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3133"
    ,"Station_Code":"HBC 211"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trạm xăng Kim Quang"
    ,"Station_Address":"E8/212M, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.695548
    ,"Long":106.654978
    ,"Polyline":"[106.65187836,10.68475437] ; [106.65342712,10.68818188]"
    ,"Distance":"417"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3132"
    ,"Station_Code":"HBC 212"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Trung tâm tư vấn đào tạo Úc Mỹ"
    ,"Station_Address":"E8/214A, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.698136
    ,"Long":106.654501
    ,"Polyline":"[106.65342712,10.68818188] ; [106.65411377,10.68959141] ; [106.65478516,10.69115639]"
    ,"Distance":"363"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3136"
    ,"Station_Code":"HBC 213"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chùa Thiện Phước"
    ,"Station_Address":"E9 /251, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.701768
    ,"Long":106.654587
    ,"Polyline":"[106.65478516,10.69115639] ; [106.65497589,10.69195271] ; [106.65510559,10.69298553] ; [106.65512848,10.69405937]"
    ,"Distance":"326"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3134"
    ,"Station_Code":"HBC 214"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Xăng dầu  Phong Phú"
    ,"Station_Address":"E10/288, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.704709
    ,"Long":106.654957
    ,"Polyline":"[106.65512848,10.69405937] ; [106.65492249,10.69571590] ; [106.65457153,10.69737148]"
    ,"Distance":"374"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3137"
    ,"Station_Code":"HBC 215"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Mầm non Anh Việt"
    ,"Station_Address":"E11/304C, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.70823
    ,"Long":106.655493
    ,"Polyline":"[106.65457153,10.69737148] ; [106.65434265,10.69884777] ; [106.65422058,10.69957447] ; [106.65424347,10.70035934]"
    ,"Distance":"336"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3135"
    ,"Station_Code":"HBC 216"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"Chùa Ân Hòa"
    ,"Station_Address":"B10/7, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.712051
    ,"Long":106.655756
    ,"Polyline":"[106.65424347,10.70035934] ; [106.65473175,10.70378494]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3139"
    ,"Station_Code":"HBC 217"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Văn phòng Ấp 3"
    ,"Station_Address":"B13/118 , đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.71552
    ,"Long":106.655686
    ,"Polyline":"[106.65473175,10.70378494] ; [106.65536499,10.70793629]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3138"
    ,"Station_Code":"HBC 218"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chùa Thi ên Trì"
    ,"Station_Address":"B15/20, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.718598
    ,"Long":106.65574
    ,"Polyline":"[106.65536499,10.70793629] ; [106.65574646,10.71009541] ; [106.65579224,10.71203518] ; [106.65550995,10.71391201] ; [106.65558624,10.71589375]"
    ,"Distance":"892"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2247"
    ,"Station_Code":"HBC 219"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"B17/24, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.720848
    ,"Long":106.655837
    ,"Polyline":"[106.65558624,10.71589375] ; [106.65582275,10.72288799]"
    ,"Distance":"779"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2244"
    ,"Station_Code":"HBC 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Giáo xứ Bình Hưng"
    ,"Station_Address":"A18/16, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.724923
    ,"Long":106.655944
    ,"Polyline":"[106.65582275,10.72288799] ; [106.65595245,10.72743511]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2246"
    ,"Station_Code":"HBC 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm xăng SaiGon Petro"
    ,"Station_Address":"A24/20B, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.7277
    ,"Long":106.656089
    ,"Polyline":"[106.65595245,10.72743511] ; [106.65601349,10.72925282]"
    ,"Distance":"202"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2248"
    ,"Station_Code":"HBC 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Công an Bình Hưng"
    ,"Station_Address":"A27/13, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.730905
    ,"Long":106.656105
    ,"Polyline":"[106.65601349,10.72925282] ; [106.65603638,10.73007774] ; [106.65605927,10.73090267]"
    ,"Distance":"184"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2249"
    ,"Station_Code":"Q8 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"407, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733134
    ,"Long":106.656239
    ,"Polyline":"[106.65605927,10.73090267] ; [106.65612793,10.73193836] ; [106.65612030,10.73301029]"
    ,"Distance":"235"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"502"
    ,"Station_Code":"Q8 073"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"193, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656346
    ,"Polyline":"[106.65612030,10.73301029] ; [106.65609741,10.73313046] ; [106.65615082,10.73353958] ; [106.65628052,10.73409843] ; [106.65625763,10.73491096] ; [106.65619659,10.73571968] ; [106.65622711,10.73607063]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"499"
    ,"Station_Code":"Q8 074"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Cầu Nhị Thiên Đường"
    ,"Station_Address":"81 , đường Quốc lộ 50, Quận 8"
    ,"Lat":10.738769
    ,"Long":106.656427
    ,"Polyline":"[106.65622711,10.73607063] ; [106.65629578,10.73882675]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"542"
    ,"Station_Code":"Q8 111"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"487, đường Tùng Thi ện Vương, Quận 8"
    ,"Lat":10.744513
    ,"Long":106.656802
    ,"Polyline":"[106.65628815,10.73882961] ; [106.65628815,10.73923969] ; [106.65638733,10.74069023] ; [106.65635681,10.74090958] ; [106.65622711,10.74122047] ; [106.65585327,10.74217033] ; [106.65570831,10.74260998] ; [106.65558624,10.74295044] ; [106.65554810,10.74326038] ; [106.65557861,10.74351978] ; [106.65567780,10.74376965] ; [106.65579987,10.74396992] ; [106.65583801,10.74407005] ; [106.65602112,10.74423981] ; [106.65647888,10.74448013]"
    ,"Distance":"698"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"501"
    ,"Station_Code":"Q8 112"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Chợ Xóm Củi"
    ,"Station_Address":"337, đường Tùng Thiện Vương, Quận 8"
    ,"Lat":10.746073
    ,"Long":106.659763
    ,"Polyline":"[106.65650940,10.74442863] ; [106.65801239,10.74522972] ; [106.65876007,10.74564075] ; [106.65896606,10.74575710.06.65963745]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"138"
    ,"Station_Code":"Q5 015"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Hải Thượng Lãn Ông"
    ,"Station_Address":"210-212, đường Hải Thượng Lãn Ông, Quận 5"
    ,"Lat":10.750948
    ,"Long":106.658358
    ,"Polyline":"[106.65963745,10.74605274] ; [106.65960693,10.74612045] ; [106.66024780,10.74643993] ; [106.66036224,10.74650955] ; [106.66045380,10.74662971] ; [106.66059875,10.74779034] ; [106.66062927,10.74816036] ; [106.66062164,10.74829960] ; [106.66056824,10.74866009] ; [106.66046906,10.74897957] ; [106.66005707,10.75010967] ; [106.66007233,10.75022030] ; [106.66011810,10.75030994] ; [106.66021729,10.75037956] ; [106.66040039,10.75045967] ; [106.66056061,10.75055981] ; [106.66060638,10.75063992] ; [106.66110229,10.75092030] ; [106.66133881,10.75100994] ; [106.66150665,10.75104046] ; [106.66149902,10.75119972] ; [106.66127014,10.75113010.06.66092682] ; [10.75098038,106.66050720] ; [10.75072002,106.66026306] ; [10.75057030,106.66011810] ; [10.75053024,106.65998077] ; [10.75053024,106.65986633] ; [10.75055027,106.65966034] ; [10.75063038,106.65950775] ; [10.75069046,106.65927124] ; [10.75084019,106.65926361] ; [10.75086021,106.65924072] ; [10.75088978,106.65918732] ; [10.75092983,106.65912628] ; [10.75094032,106.65907288] ; [10.75092030,106.65904999] ; [10.75090981,106.65854645] ; [10.75091648,106.65835571]"
    ,"Distance":"1110"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"139"
    ,"Station_Code":"Q5 102"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"5, đường Trang Tử, Quận 5"
    ,"Lat":10.751128
    ,"Long":106.655086
    ,"Polyline":"[106.65835571,10.75094795] ; [106.65799713,10.75094795] ; [106.65733337,10.75099564] ; [106.65645599,10.75107002] ; [106.65594482,10.75106430] ; [106.65548706,10.75109100] ; [106.65524292,10.75111675] ; [106.65508270,10.75112820]"
    ,"Distance":"359"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận 5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":"[106.65508270,10.75112820] ; [106.65508270,10.75112820] ; [106.65461731,10.75112724] ; [106.65192413,10.75103760] ; [106.65119934,10.75101185] ; [106.65048981,10.75105953] ; [106.65056610,10.75153351] ; [106.65065765,10.75223446] ; [106.65071869,10.75280857] ; [106.65074921,10.75336170] ; [106.65149689,10.75313568] ; [106.65209961,10.75291920] ; [106.65287781,10.75275612] ; [106.65352631,10.75273991] ; [106.65339661,10.75208187] ; [106.65330505,10.75166512] ; [106.65316772,10.75150681] ; [106.65294647,10.75132275] ; [106.65256500,10.75125313]"
    ,"Distance":"1294"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"8"
    ,"Station_Code":"BX14"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Chợ Lớn"
    ,"Station_Address":"GA HKXB CHO LON, đường Lê Quang Sung, Quận  5"
    ,"Lat":10.751253128051758
    ,"Long":106.6525650024414
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"1"
    ,"Station_Code":"Q6 095"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Chu Văn An"
    ,"Station_Address":"27 , đường Tháp Mười, Quận 6"
    ,"Lat":10.750232
    ,"Long":106.652554
    ,"Polyline":"[106.65256500,10.75125313] ; [106.65230560,10.75124359] ; [106.65208435,10.75118065] ; [106.65192413,10.75100613] ; [106.65100098,10.75096416] ; [106.64952850,10.75117493] ; [106.64939880,10.74968910.06.65103149] ; [10.75000477,106.65222168] ; [10.75020981,106.65254211] ; [10.75026989,106.65255737] ; [10.75023174,106.65255737]"
    ,"Distance":"864"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2393"
    ,"Station_Code":"Q6 096"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Tháp Mười"
    ,"Station_Address":"13C-13D, đường Tháp Mười, Quận 6"
    ,"Lat":10.750326
    ,"Long":106.653036
    ,"Polyline":"[106.65255737,10.75023174] ; [106.65303802,10.75032616]"
    ,"Distance":"54"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2"
    ,"Station_Code":"Q5 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Chợ Kim Biên"
    ,"Station_Address":"11-12, đường Hải Thượng Lãn Ông, Quận  5"
    ,"Lat":10.750732
    ,"Long":106.655075
    ,"Polyline":"[106.65303802,10.75032616] ; [106.65445709,10.75070095] ; [106.65472412,10.75082207] ; [106.65507507,10.75073242]"
    ,"Distance":"233"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"617"
    ,"Station_Code":"Q8 110"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Tùng Thiện Vương"
    ,"Station_Address":"388, đường Tùng Thiện Vương , Quận 8"
    ,"Lat":10.74483
    ,"Long":106.656926
    ,"Polyline":"[106.65503693,10.75078964] ; [106.65529633,10.75076962] ; [106.65573120,10.75074291] ; [106.65592194,10.75074768] ; [106.65629578,10.75077438] ; [106.65677643,10.75078487] ; [106.65741730,10.75071144] ; [106.65824890,10.75065899] ; [106.65882111,10.75063705] ; [106.65904236,10.75065327] ; [106.65914154,10.75060844] ; [106.65924835,10.75062466] ; [106.65929413,10.75063705] ; [106.65966034,10.75048161] ; [106.65982056,10.75039482] ; [106.65991211,10.75026035] ; [106.66003418,10.74991035] ; [106.66014099,10.74958038] ; [106.66031647,10.74908829] ; [106.66043091,10.74869823] ; [106.66050720,10.74845314] ; [106.66051483,10.74807072] ; [106.66046906,10.74772549] ; [106.66043091,10.74734116] ; [106.66040802,10.74718285] ; [106.66035461,10.74702168] ; [106.66024780,10.74696159] ; [106.66017151,10.74695492] ; [106.66004944,10.74694920] ; [106.65994263,10.74692726] ; [106.65979767,10.74681377] ; [106.65959930,10.74662590] ; [106.65933990,10.74637413] ; [106.65914154,10.74616051] ; [106.65896606,10.74590969] ; [106.65888214,10.74578476] ; [106.65868378,10.74569798] ; [106.65853882,10.74563599] ; [106.65664673,10.74456978]"
    ,"Distance":"1436"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"618"
    ,"Station_Code":"Q8 069"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Chùa Pháp Quang"
    ,"Station_Address":"100, đường Quốc lộ 50, Qu ận 8"
    ,"Lat":10.738642
    ,"Long":106.656142
    ,"Polyline":"[106.65664673,10.74456978] ; [106.65602112,10.74423981] ; [106.65577698,10.74403954] ; [106.65567017,10.74392033] ; [106.65554047,10.74370003] ; [106.65541840,10.74337959] ; [106.65538788,10.74310017] ; [106.65545654,10.74271011] ; [106.65560150,10.74232006] ; [106.65605927,10.74118996] ; [106.65612030,10.74098015] ; [106.65618896,10.74079037] ; [106.65627289,10.74055958] ; [106.65628815,10.74038982] ; [106.65618896,10.73954010.06.65612793] ; [10.73927021,106.65612793] ; [10.73919010.06.65617371,10.73906040] ; [106.65619659,10.73863983]"
    ,"Distance":"751"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"619"
    ,"Station_Code":"Q8 070"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Bùi Minh Trực"
    ,"Station_Address":"224, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.73646
    ,"Long":106.656126
    ,"Polyline":"[106.65618896,10.73864460] ; [106.65618896,10.73864460] ; [106.65625000,10.73740864] ; [106.65620422,10.73618889] ; [106.65620422,10.73618889]"
    ,"Distance":"274"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2148"
    ,"Station_Code":"Q8 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"328-330 , đường Quốc lộ 50, Quận 8"
    ,"Lat":10.732776
    ,"Long":106.656051
    ,"Polyline":"[106.65620422,10.73618889] ; [106.65608978,10.73287392]"
    ,"Distance":"369"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2149"
    ,"Station_Code":"HBC 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Chùa Linh Sơn"
    ,"Station_Address":"A6/17, đường Quốc  lộ 50, Huyện Bình Chánh"
    ,"Lat":10.7308
    ,"Long":106.655971
    ,"Polyline":"[106.65608978,10.73287392] ; [106.65612030,10.73224926] ; [106.65605927,10.73153019]"
    ,"Distance":"150"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2151"
    ,"Station_Code":"HBC 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Mầm non Ánh Dương"
    ,"Station_Address":"A11/07, đường Quốc lộ 50, Huyện Bình  Chánh"
    ,"Lat":10.72789
    ,"Long":106.65589
    ,"Polyline":"[106.65606689,10.73147011] ; [106.65598297,10.72867012]"
    ,"Distance":"341"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2150"
    ,"Station_Code":"HBC 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Ngân hàng Nam Á"
    ,"Station_Address":"A13/1A, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.725292
    ,"Long":106.655831
    ,"Polyline":"[106.65598297,10.72886944] ; [106.65585327,10.72528648]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"2153"
    ,"Station_Code":"HBC 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"B2/21, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.72058
    ,"Long":106.655686
    ,"Polyline":"[106.65585327,10.72528648] ; [106.65581512,10.72303009]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3019"
    ,"Station_Code":"HBC 172"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"B4/13, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.718477
    ,"Long":106.655617
    ,"Polyline":"[106.65581512,10.72303009] ; [106.65557098,10.71602917]"
    ,"Distance":"780"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3020"
    ,"Station_Code":"HBC 173"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Trường tiều học Bình Hưng"
    ,"Station_Address":"B6/19, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.715762
    ,"Long":106.655531
    ,"Polyline":"[106.65557098,10.71602917] ; [106.65568542,10.71181965]"
    ,"Distance":"469"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3021"
    ,"Station_Code":"HBC 174"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Chùa An H òa"
    ,"Station_Address":"B8/31, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.71193
    ,"Long":106.655627
    ,"Polyline":"[106.65568542,10.71181965] ; [106.65576935,10.71093941] ; [106.65558624,10.70949459] ; [106.65537262,10.70808125]"
    ,"Distance":"419"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3023"
    ,"Station_Code":"HBC 176"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Mầm non Anh Việt"
    ,"Station_Address":"E11/307, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.708388
    ,"Long":106.655359
    ,"Polyline":"[106.65537262,10.70808125] ; [106.65425873,10.70061302]"
    ,"Distance":"840"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3022"
    ,"Station_Code":"HBC 175"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Mầm non Anh Việt"
    ,"Station_Address":"E2/46 , đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.711725
    ,"Long":106.65537
    ,"Polyline":"[106.65425873,10.70061302] ; [106.65486908,10.70475006]"
    ,"Distance":"465"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3025"
    ,"Station_Code":"HBC 177"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Xăng dầu  Phong Phú"
    ,"Station_Address":"E4/106, đường Quốc lộ 50, Huyện Bình Ch ánh"
    ,"Lat":10.704672
    ,"Long":106.654801
    ,"Polyline":"[106.65486908,10.70475006] ; [106.65463257,10.70290661] ; [106.65435028,10.70128250] ; [106.65422058,10.69987011] ; [106.65453339,10.69745159]"
    ,"Distance":"819"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3024"
    ,"Station_Code":"HBC 178"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Chùa Thiện Phước"
    ,"Station_Address":"E5/142, đường Quốc lộ 50,  Huyện Bình Chánh"
    ,"Lat":10.701515
    ,"Long":106.654308
    ,"Polyline":"[106.65453339,10.69745159] ; [106.65486908,10.69598007] ; [106.65508270,10.69444466]"
    ,"Distance":"340"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3026"
    ,"Station_Code":"HBC 179"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Trung tâm tư vấn đào tạo Úc Mỹ"
    ,"Station_Address":"Đối diện E8/215, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.698194
    ,"Long":106.654356
    ,"Polyline":"[106.65508270,10.69444466] ; [106.65514374,10.69352341] ; [106.65501404,10.69246960] ; [106.65483856,10.69149685]"
    ,"Distance":"331"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3027"
    ,"Station_Code":"HBC 180"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Trạm xăng Kim Quang"
    ,"Station_Address":"D7/203, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.695416
    ,"Long":106.654876
    ,"Polyline":"[106.65483856,10.69149685] ; [106.65435791,10.69013977] ; [106.65373993,10.68884182]"
    ,"Distance":"320"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3028"
    ,"Station_Code":"HBC 181"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Trịnh Quang Nghị"
    ,"Station_Address":"D10/281, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.692511
    ,"Long":106.654946
    ,"Polyline":"[106.65373993,10.68884182] ; [106.65199280,10.68508244]"
    ,"Distance":"460"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3029"
    ,"Station_Code":"HBC 182"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Trường Tiểu học Phong Phú"
    ,"Station_Address":"B5/126, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.688431
    ,"Long":106.653471
    ,"Polyline":"[106.65199280,10.68508244] ; [106.65061188,10.68196678]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3030"
    ,"Station_Code":"HBC 183"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Trường chuyên biệt Rạng Đông"
    ,"Station_Address":"A2/33, đường Quốc lộ 50, Huy ện Bình Chánh"
    ,"Lat":10.683086
    ,"Long":106.651068
    ,"Polyline":"[106.65061188,10.68196678] ; [106.65042114,10.68097782] ; [106.65039063,10.67988110.06.65047455]"
    ,"Distance":"365"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3031"
    ,"Station_Code":"HBC 184"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Đình Chánh An Phú"
    ,"Station_Address":"A4/94, đường  Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.677989
    ,"Long":106.650488
    ,"Polyline":"[106.65047455,10.67870712] ; [106.65061951,10.67776203] ; [106.65076447,10.67533207]"
    ,"Distance":"377"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3032"
    ,"Station_Code":"HBC 185"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Công ty Hồng  Nhất"
    ,"Station_Address":"E7/194, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.673592
    ,"Long":106.650853
    ,"Polyline":"[106.65076447,10.67533207] ; [106.65092468,10.67375565] ; [106.65097046,10.67225647]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3033"
    ,"Station_Code":"HBC 186"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trường THCS  Đa Phước"
    ,"Station_Address":"E11/323, đường  Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.669765
    ,"Long":106.651052
    ,"Polyline":"[106.65097046,10.67225647] ; [106.65110779,10.66929722]"
    ,"Distance":"330"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3034"
    ,"Station_Code":"HBC 187"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Nghĩa trang  Đa Phước"
    ,"Station_Address":"D16/460A2, đư ờng Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.66667
    ,"Long":106.651229
    ,"Polyline":"[106.65110779,10.66929722] ; [106.65126801,10.66665840]"
    ,"Distance":"303"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3035"
    ,"Station_Code":"HBC 188"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Đường liên  Ấp 1-2"
    ,"Station_Address":"A14/396, đường Qu ốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.662801
    ,"Long":106.65154
    ,"Polyline":"[106.65126801,10.66665840] ; [106.65155029,10.66345215]"
    ,"Distance":"358"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3036"
    ,"Station_Code":"HBC 189"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Chùa Linh Hòa"
    ,"Station_Address":"D9/261/1A, đường Quốc lộ 50, Huyện Bình Ch ánh"
    ,"Lat":10.659954
    ,"Long":106.651776
    ,"Polyline":"[106.65155029,10.66345215] ; [106.65179443,10.66037750]"
    ,"Distance":"343"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3037"
    ,"Station_Code":"HBC 190"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Linh Hòa Tự"
    ,"Station_Address":"D9/264A , đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.656369
    ,"Long":106.652355
    ,"Polyline":"[106.65179443,10.66037750] ; [106.65197754,10.65907955] ; [106.65242004,10.65787697] ; [106.65294647,10.65670776]"
    ,"Distance":"431"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3038"
    ,"Station_Code":"HBC 191"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chùa Tam  Bửu"
    ,"Station_Address":"D8/238/8, đường Qu ốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.656164
    ,"Long":106.653138
    ,"Polyline":"[106.65294647,10.65670776] ; [106.65411377,10.65420246]"
    ,"Distance":"307"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3039"
    ,"Station_Code":"HBC 192"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"Chùa Phước Hội"
    ,"Station_Address":"D7/221A, đường Qu ốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.652463
    ,"Long":106.654608
    ,"Polyline":"[106.65411377,10.65420246] ; [106.65460968,10.65276337] ; [106.65501404,10.65134430]"
    ,"Distance":"333"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3040"
    ,"Station_Code":"HBC 193"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Cầu Ông Thìn"
    ,"Station_Address":"A8/22A, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.648087
    ,"Long":106.655982
    ,"Polyline":"[106.65501404,10.65134430] ; [106.65599060,10.64808846]"
    ,"Distance":"378"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3041"
    ,"Station_Code":"HBC 194"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Trạm xăng Hoàng Thái"
    ,"Station_Address":"D7 /23A, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.644338
    ,"Long":106.656776
    ,"Polyline":"[106.65599060,10.64808846] ; [106.65634918,10.64705944] ; [106.65664673,10.64567757] ; [106.65677643,10.64433765]"
    ,"Distance":"428"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3042"
    ,"Station_Code":"LA_2"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Hoàng Thái  Mart"
    ,"Station_Address":"Đối diện B8/33B6,  đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.637843
    ,"Long":106.658036
    ,"Polyline":"[106.65677643,10.64433765] ; [106.65718842,10.64123917]"
    ,"Distance":"348"
  },
  {
     "Route_Id":"68"
    ,"Station_Id":"3043"
    ,"Station_Code":"BX 58"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Hưng Long"
    ,"Station_Address":"ĐẦU BẾN HƯNG LONG, đường Quốc lộ 50, Huyện Bình Ch ánh"
    ,"Lat":10.637669
    ,"Long":106.647307
    ,"Polyline":"[106.65718842,10.64123917] ; [106.65754700,10.63926697] ; [106.65782928,10.63852882] ; [106.66201019,10.62986088] ; [106.64697266,10.63774776]"
    ,"Distance":"3244"
  }]