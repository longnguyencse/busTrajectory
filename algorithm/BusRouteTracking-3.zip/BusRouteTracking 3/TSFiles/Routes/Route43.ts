export const Route43 =[

  {
     "Route_Id":"43"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"0"
    ,"Station_Order":"0"
    ,"Station_Name":"KCN LÊ MINH XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường Trần  Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2226"
    ,"Station_Code":"HBC 433"
    ,"Station_Direction":"0"
    ,"Station_Order":"1"
    ,"Station_Name":"Láng Le Bàu Cò"
    ,"Station_Address":"Đối diện cột điện 73T, đường Láng Le bàu C ò, Huyện Bình Chánh"
    ,"Lat":10.743227
    ,"Long":106.538361
    ,"Polyline":"[106.53951263,10.74421024] ; [106.53910065,10.74446011] ; [106.53845978,10.74477005] ; [106.53791046,10.74503994] ; [106.53781128,10.74483013] ; [106.53780365,10.74466038] ; [106.53784943,10.74454021] ; [106.53825378,10.74431038] ; [106.53829193,10.74423981] ; [106.53742218,10.74221992]"
    ,"Distance":"561"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2231"
    ,"Station_Code":"HBC 434"
    ,"Station_Direction":"0"
    ,"Station_Order":"2"
    ,"Station_Name":"Cổng số 8"
    ,"Station_Address":"Đối diện A5/140B (Hữu Thành ), đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.738357
    ,"Long":106.536173
    ,"Polyline":"[106.53742218,10.74221992] ; [106.53653717,10.74018955] ; [106.53578186,10.73851013]"
    ,"Distance":"450"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2228"
    ,"Station_Code":"HBC 435"
    ,"Station_Direction":"0"
    ,"Station_Order":"3"
    ,"Station_Name":"Cổng số 9"
    ,"Station_Address":"Đối diện A5/147, đường Láng Le bàu Cò, Huyện Bình Ch ánh"
    ,"Lat":10.733493
    ,"Long":106.534864
    ,"Polyline":"[106.53578186,10.73851013] ; [106.53494263,10.73665047] ; [106.53469849,10.73600960] ; [106.53468323,10.73595047] ; [106.53479767,10.73332977]"
    ,"Distance":"601"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2232"
    ,"Station_Code":"HBC 436"
    ,"Station_Direction":"0"
    ,"Station_Order":"4"
    ,"Station_Name":"Trạm cấp nước"
    ,"Station_Address":"Đối diện A5/115B, đường L áng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.727806
    ,"Long":106.535089
    ,"Polyline":"[106.53479767,10.73332977] ; [106.53485870,10.73151016] ; [106.53504181,10.72801018]"
    ,"Distance":"592"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2229"
    ,"Station_Code":"HBC 437"
    ,"Station_Direction":"0"
    ,"Station_Order":"5"
    ,"Station_Name":"nhựa Bình Minh"
    ,"Station_Address":"A4/110 (nhựa Bình Minh),  đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.72166
    ,"Long":106.536157
    ,"Polyline":"[106.53504181,10.72801018] ; [106.53505707,10.72714996] ; [106.53518677,10.72527981] ; [106.53514862,10.72521019] ; [106.53463745,10.72480011] ; [106.53453064,10.72467995] ; [106.53430176,10.72432041] ; [106.53398895,10.72375011] ; [106.53359222,10.72319031] ; [106.53546906,10.72214031]"
    ,"Distance":"835"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2233"
    ,"Station_Code":"HBC 438"
    ,"Station_Direction":"0"
    ,"Station_Order":"6"
    ,"Station_Name":"Trạm cầu"
    ,"Station_Address":"A3/68, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.719531
    ,"Long":106.539735
    ,"Polyline":"[106.53546906,10.72214031] ; [106.53961945,10.71980000]"
    ,"Distance":"523"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2230"
    ,"Station_Code":"HBC 439"
    ,"Station_Direction":"0"
    ,"Station_Order":"7"
    ,"Station_Name":"Xây dựng Mạnh Dũng"
    ,"Station_Address":"A1/32, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.717812
    ,"Long":106.542803
    ,"Polyline":"[106.53961945,10.71980000] ; [106.54279327,10.71800995]"
    ,"Distance":"399"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2235"
    ,"Station_Code":"HBC 440"
    ,"Station_Direction":"0"
    ,"Station_Order":"8"
    ,"Station_Name":"Trường mẫu giáo Tân nhựt"
    ,"Station_Address":"A1/7, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.716136
    ,"Long":106.545775
    ,"Polyline":"[106.54279327,10.71800995] ; [106.54583740,10.71627998]"
    ,"Distance":"385"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2234"
    ,"Station_Code":"HBC 441"
    ,"Station_Direction":"0"
    ,"Station_Order":"9"
    ,"Station_Name":"Ủy ban nhân dân xã Tân Nhật"
    ,"Station_Address":"Kế Ủy ban nhân dân xã Tân Nhật, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.713664
    ,"Long":106.550158
    ,"Polyline":"[106.54583740,10.71627998] ; [106.54792023,10.71506977] ; [106.55023193,10.71368027]"
    ,"Distance":"560"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2237"
    ,"Station_Code":"HBC 442"
    ,"Station_Direction":"0"
    ,"Station_Order":"10"
    ,"Station_Name":"Bưu điện Tân Nhựt"
    ,"Station_Address":"B14/272B, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.711171
    ,"Long":106.554723
    ,"Polyline":"[106.55023193,10.71368027] ; [106.55368805,10.71160984]"
    ,"Distance":"443"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2236"
    ,"Station_Code":"HBC 444"
    ,"Station_Direction":"0"
    ,"Station_Order":"11"
    ,"Station_Name":"Cầu Bảy Tải"
    ,"Station_Address":"B14/285A, đường Thế Lữ, Huyện Bình Ch ánh"
    ,"Lat":10.707887
    ,"Long":106.560313
    ,"Polyline":"[106.55368805,10.71160984] ; [106.55425262,10.71127033] ; [106.55490875,10.71090031] ; [106.56027985,10.70810986]"
    ,"Distance":"819"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2238"
    ,"Station_Code":"HBC 445"
    ,"Station_Direction":"0"
    ,"Station_Order":"12"
    ,"Station_Name":"Chợ Tân Nhựt"
    ,"Station_Address":"Đối diện B15/307A, đường Thế  Lữ, Huyện Bình Chánh"
    ,"Lat":10.706048
    ,"Long":106.563563
    ,"Polyline":"[106.56027985,10.70810986] ; [106.56085205,10.70777988] ; [106.56163025,10.70734978] ; [106.56179810,10.70722008] ; [106.56192780,10.70711040] ; [106.56381226,10.70598984] ; [106.56427002,10.70569038]"
    ,"Distance":"513"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2239"
    ,"Station_Code":"HBC 446"
    ,"Station_Direction":"0"
    ,"Station_Order":"13"
    ,"Station_Name":"Ngã 3 Trường học"
    ,"Station_Address":"Đối diện E9/193C, đường Thế Lữ, Huyện  Bình Chánh"
    ,"Lat":10.703923
    ,"Long":106.568112
    ,"Polyline":"[106.56427002,10.70569038] ; [106.56464386,10.70547867] ; [106.56553650,10.70517254] ; [106.56597900,10.70545769] ; [106.56645203,10.70577335] ; [106.56672668,10.70588970] ; [106.56687927,10.70585823] ; [106.56749725,10.70480347] ; [106.56801605,10.70405483] ; [106.56835938,10.70388031]"
    ,"Distance":"599"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2240"
    ,"Station_Code":"HBC 078"
    ,"Station_Direction":"0"
    ,"Station_Order":"14"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"C1/4, đường Bùi Thanh Khiết, Huyện B ình Chánh"
    ,"Lat":10.689976
    ,"Long":106.574684
    ,"Polyline":"[106.56845856,10.70382977] ; [106.56925201,10.70347500] ; [106.57028198,10.70307446] ; [106.57115936,10.70271683] ; [106.57021332,10.69860458] ; [106.56822205,10.69021320] ; [106.56695557,10.68445683] ; [106.57041168,10.68500519] ; [106.57604980,10.68605900] ; [106.57460785,10.68994045]"
    ,"Distance":"3875"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2241"
    ,"Station_Code":"HBC 397"
    ,"Station_Direction":"0"
    ,"Station_Order":"15"
    ,"Station_Name":"Thiên Giang"
    ,"Station_Address":"14 /2, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.692506
    ,"Long":106.578412
    ,"Polyline":"[106.57460785,10.68994045] ; [106.57399750,10.69165039] ; [106.57807922,10.69250011] ; [106.57842255,10.69256973]"
    ,"Distance":"695"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2243"
    ,"Station_Code":"HBC 396"
    ,"Station_Direction":"0"
    ,"Station_Order":"16"
    ,"Station_Name":"Trung t âm TDTT Bình Chánh"
    ,"Station_Address":"Trung tâm TDTT Bình Chánh, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.695274
    ,"Long":106.588202
    ,"Polyline":"[106.57842255,10.69256973] ; [106.58090973,10.69307995] ; [106.58203888,10.69338989] ; [106.58261871,10.69357014] ; [106.58341980,10.69379997] ; [106.58422089,10.69406986] ; [106.58450317,10.69416046]"
    ,"Distance":"689"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2242"
    ,"Station_Code":"HBC 395"
    ,"Station_Direction":"0"
    ,"Station_Order":"17"
    ,"Station_Name":"Bệnh viện huyện Bình Chánh"
    ,"Station_Address":"Đd BV huyện Bình Chánh, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.69618
    ,"Long":106.59303
    ,"Polyline":"[106.58450317,10.69416046] ; [106.58876038,10.69552994]"
    ,"Distance":"490"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2245"
    ,"Station_Code":"HBC 394"
    ,"Station_Direction":"0"
    ,"Station_Order":"18"
    ,"Station_Name":"Chùa Tam Bửu"
    ,"Station_Address":"E9/21A, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.696591
    ,"Long":106.596099
    ,"Polyline":"[106.58876038,10.69552994] ; [106.58950043,10.69577026] ; [106.58998871,10.69589043] ; [106.59120941,10.69606018] ; [106.59211731,10.69616985] ; [106.59332275,10.69633961]"
    ,"Distance":"508"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"639"
    ,"Station_Code":"HBC 365"
    ,"Station_Direction":"0"
    ,"Station_Order":"19"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"Kế E9/21, đường Quốc lộ 1A, Huyện Bình  Chánh"
    ,"Lat":10.696064
    ,"Long":106.596496
    ,"Polyline":"[106.59332275,10.69633961] ; [106.59442902,10.69645977] ; [106.59600830,10.69668007] ; [106.59671021,10.69676018] ; [106.59665680,10.69653988] ; [106.59616852,10.69499016] ; [106.59577942,10.69373035] ; [106.59541321,10.69266987]"
    ,"Distance":"850"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"813"
    ,"Station_Code":"HBC 022"
    ,"Station_Direction":"0"
    ,"Station_Order":"20"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"Cột điện 358, đường Nguyễn  Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.689686
    ,"Long":106.595943
    ,"Polyline":"[106.59539795,10.69262981] ; [106.59526062,10.69239044] ; [106.59516907,10.69213009] ; [106.59490967,10.69136047] ; [106.59461975,10.69048977] ; [106.59446716,10.69019985] ; [106.59439850,10.69017029] ; [106.59427643,10.69005966] ; [106.59422302,10.68988991] ; [106.59422302,10.68978977] ; [106.59425354,10.68970013] ; [106.59429932,10.68962002] ; [106.59438324,10.68955040] ; [106.59449005,10.68949986] ; [106.59461212,10.68949032] ; [106.59477234,10.68953991] ; [106.59485626,10.68962002] ; [106.59488678,10.68966961] ; [106.59583282,10.68990993]"
    ,"Distance":"550"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"812"
    ,"Station_Code":"HBC 023"
    ,"Station_Direction":"0"
    ,"Station_Order":"21"
    ,"Station_Name":"đường Ấp 2"
    ,"Station_Address":"Cột điện 332, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69152
    ,"Long":106.602321
    ,"Polyline":"[106.59583282,10.68990993] ; [106.59626007,10.69001007] ; [106.60160828,10.69147968] ; [106.60276031,10.69180965]"
    ,"Distance":"787"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"815"
    ,"Station_Code":"HBC 024"
    ,"Station_Direction":"0"
    ,"Station_Order":"22"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Cột điện 307, đường Nguyễn Văn Linh, Huy ện Bình Chánh"
    ,"Lat":10.693745
    ,"Long":106.610159
    ,"Polyline":"[106.60276031,10.69180965] ; [106.60858154,10.69342041] ; [106.60938263,10.69365025] ; [106.60942841,10.69353008] ; [106.60945129,10.69351006]"
    ,"Distance":"770"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"889"
    ,"Station_Code":"HBC 452"
    ,"Station_Direction":"0"
    ,"Station_Order":"23"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Đối diện công ty bất động sản, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698468
    ,"Long":106.609279
    ,"Polyline":"[106.60945129,10.69351006] ; [106.60938263,10.69365025] ; [106.61045074,10.69394016] ; [106.61045074,10.69396019] ; [106.61032867,10.69449997] ; [106.61032104,10.69480991] ; [106.61000824,10.69594002] ; [106.60929871,10.69845963]"
    ,"Distance":"658"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"891"
    ,"Station_Code":"HBC 453"
    ,"Station_Direction":"0"
    ,"Station_Order":"24"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Quán ăn Chợ Bình Điền, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình  Chánh"
    ,"Lat":10.702274
    ,"Long":106.608195
    ,"Polyline":"[106.60929871,10.69845963] ; [106.60823822,10.70228004]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"893"
    ,"Station_Code":"HBC 451"
    ,"Station_Direction":"0"
    ,"Station_Order":"25"
    ,"Station_Name":"Công ty bất động sản"
    ,"Station_Address":"Công ty bất động sản, đường Đường vào Chợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698684
    ,"Long":106.609113
    ,"Polyline":"[106.60823822,10.70228004] ; [106.60803223,10.70302963] ; [106.60791779,10.70298958] ; [106.60826874,10.70178986] ; [106.60910797,10.69869041]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"817"
    ,"Station_Code":"HBC 025"
    ,"Station_Direction":"0"
    ,"Station_Order":"26"
    ,"Station_Name":"Trạm thu phí"
    ,"Station_Address":"C ột điện 291, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.694493
    ,"Long":106.613388
    ,"Polyline":"[106.60910797,10.69869041] ; [106.60958862,10.69699001] ; [106.60984802,10.69610023] ; [106.60990906,10.69583988] ; [106.61019135,10.69478989] ; [106.61032867,10.69449997] ; [106.61045074,10.69396019] ; [106.61045074,10.69394016] ; [106.61370850,10.69484043]"
    ,"Distance":"919"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"814"
    ,"Station_Code":"HBC 026"
    ,"Station_Direction":"0"
    ,"Station_Order":"27"
    ,"Station_Name":"Cầu Cần Giuộc"
    ,"Station_Address":"Cột điện  277, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.696591
    ,"Long":106.620603
    ,"Polyline":"[106.61370850,10.69484043] ; [106.61791229,10.69598007]"
    ,"Distance":"476"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"818"
    ,"Station_Code":"HBC 027"
    ,"Station_Direction":"0"
    ,"Station_Order":"28"
    ,"Station_Name":"Cầu Sập"
    ,"Station_Address":"Cột điện 258, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.698183
    ,"Long":106.626692
    ,"Polyline":"[106.61791229,10.69598007] ; [106.62406158,10.69764042] ; [106.62661743,10.69834042]"
    ,"Distance":"988"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"816"
    ,"Station_Code":"HBC 028"
    ,"Station_Direction":"0"
    ,"Station_Order":"29"
    ,"Station_Name":"Kim Hằng"
    ,"Station_Address":"Cột điện 240 , đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.700144
    ,"Long":106.631413
    ,"Polyline":"[106.62661743,10.69834042] ; [106.62741852,10.69857025] ; [106.62834930,10.69884968] ; [106.62963867,10.69937038] ; [106.63060760,10.69983006] ; [106.63127899,10.70026016]"
    ,"Distance":"555"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"820"
    ,"Station_Code":"HBC 029"
    ,"Station_Direction":"0"
    ,"Station_Order":"30"
    ,"Station_Name":"Trịnh Quang  Nghị"
    ,"Station_Address":"Cột điện 230, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.702237
    ,"Long":106.634218
    ,"Polyline":"[106.63127899,10.70026016] ; [106.63160706,10.70046043] ; [106.63272095,10.70129013] ; [106.63362885,10.70199966]"
    ,"Distance":"322"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"819"
    ,"Station_Code":"HBC 030"
    ,"Station_Direction":"0"
    ,"Station_Order":"31"
    ,"Station_Name":"Qua Trịnh Quang Nghị"
    ,"Station_Address":"Cột điện 213, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.705494
    ,"Long":106.638354
    ,"Polyline":"[106.63362885,10.70199966] ; [106.63742828,10.70497990]"
    ,"Distance":"531"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"822"
    ,"Station_Code":"HBC 031"
    ,"Station_Direction":"0"
    ,"Station_Order":"32"
    ,"Station_Name":"Khu dân cư 13A"
    ,"Station_Address":"Cột điện 189, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.709337
    ,"Long":106.643343
    ,"Polyline":"[106.63742828,10.70497990] ; [106.64321136,10.70948982]"
    ,"Distance":"807"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"821"
    ,"Station_Code":"HBC 032"
    ,"Station_Direction":"0"
    ,"Station_Order":"33"
    ,"Station_Name":"Cầu Bà Lớn"
    ,"Station_Address":"Cột điện 175, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.711382
    ,"Long":106.645961
    ,"Polyline":"[106.64321136,10.70948982] ; [106.64585114,10.71152020]"
    ,"Distance":"366"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"824"
    ,"Station_Code":"HBC 033"
    ,"Station_Direction":"0"
    ,"Station_Order":"34"
    ,"Station_Name":"KĐT Hạnh Phúc"
    ,"Station_Address":"Cột điện  158, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.713791
    ,"Long":106.648997
    ,"Polyline":"[106.64585114,10.71152020] ; [106.64990234,10.71467972]"
    ,"Distance":"565"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"823"
    ,"Station_Code":"HBC 034"
    ,"Station_Direction":"0"
    ,"Station_Order":"35"
    ,"Station_Name":"Quốc lộ  50"
    ,"Station_Address":"Cột điện 137, đường  Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.717971
    ,"Long":106.654356
    ,"Polyline":"[106.64990234,10.71467972] ; [106.65451813,10.71829987]"
    ,"Distance":"646"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2247"
    ,"Station_Code":"HBC 219"
    ,"Station_Direction":"0"
    ,"Station_Order":"36"
    ,"Station_Name":"Nguyễn V ăn Linh"
    ,"Station_Address":"B17/24, đường Qu ốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.720848
    ,"Long":106.655837
    ,"Polyline":"[106.65451813,10.71829987] ; [106.65570068,10.71922016] ; [106.65570831,10.71980000] ; [106.65573120,10.72074986] ; [106.65579987,10.72247028] ; [106.65582275,10.72288990]"
    ,"Distance":"573"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2244"
    ,"Station_Code":"HBC 220"
    ,"Station_Direction":"0"
    ,"Station_Order":"37"
    ,"Station_Name":"Giáo xứ Bình Hưng"
    ,"Station_Address":"A18/16, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.724923
    ,"Long":106.655944
    ,"Polyline":"[106.65582275,10.72288990] ; [106.65583038,10.72443008] ; [106.65590668,10.72694969] ; [106.65593719,10.72743988]"
    ,"Distance":"506"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2246"
    ,"Station_Code":"HBC 221"
    ,"Station_Direction":"0"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm xăng SaiGon Petro"
    ,"Station_Address":"A24/20B, đường Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.7277
    ,"Long":106.656089
    ,"Polyline":"[106.65593719,10.72743988] ; [106.65599823,10.72924995]"
    ,"Distance":"201"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2249"
    ,"Station_Code":"Q8 072"
    ,"Station_Direction":"0"
    ,"Station_Order":"39"
    ,"Station_Name":"Bến xe Qu ận 8"
    ,"Station_Address":"407, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733134
    ,"Long":106.656239
    ,"Polyline":"[106.65599823,10.72924995] ; [106.65608978,10.73266029] ; [106.65611267,10.73301029]"
    ,"Distance":"418"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2248"
    ,"Station_Code":"HBC 222"
    ,"Station_Direction":"0"
    ,"Station_Order":"40"
    ,"Station_Name":"Công an Bình  Hưng"
    ,"Station_Address":"A27/13, đường Quốc  lộ 50, Huyện Bình Chánh"
    ,"Lat":10.730905
    ,"Long":106.656105
    ,"Polyline":"[106.65611267,10.73301029] ; [106.65605164,10.73089981]"
    ,"Distance":"234"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"0"
    ,"Station_Order":"41"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"GA HKXB QUẬN 8,  đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":"[106.65605164,10.73089981] ; [106.65609741,10.73313046] ; [106.65615082,10.73353958]"
    ,"Distance":"294"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"496"
    ,"Station_Code":"BX 20"
    ,"Station_Direction":"1"
    ,"Station_Order":"0"
    ,"Station_Name":"Bến xe Quận 8"
    ,"Station_Address":"GA HKXB QUẬN 8, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.733545
    ,"Long":106.656357
    ,"Polyline":""
    ,"Distance":""
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2148"
    ,"Station_Code":"Q8 071"
    ,"Station_Direction":"1"
    ,"Station_Order":"1"
    ,"Station_Name":"Bến xe Qu ận 8"
    ,"Station_Address":"328-330, đường Quốc lộ 50, Quận 8"
    ,"Lat":10.732776
    ,"Long":106.656051
    ,"Polyline":"[106.65615082,10.73353958] ; [106.65611267,10.73305035] ; [106.65609741,10.73287010]"
    ,"Distance":"74"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2149"
    ,"Station_Code":"HBC 168"
    ,"Station_Direction":"1"
    ,"Station_Order":"2"
    ,"Station_Name":"Chùa Linh  Sơn"
    ,"Station_Address":"A6/17, đường Quốc l ộ 50, Huyện Bình Chánh"
    ,"Lat":10.7308
    ,"Long":106.655971
    ,"Polyline":"[106.65609741,10.73287010.06.65606689]"
    ,"Distance":"149"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2151"
    ,"Station_Code":"HBC 169"
    ,"Station_Direction":"1"
    ,"Station_Order":"3"
    ,"Station_Name":"Mầm non Ánh Dương"
    ,"Station_Address":"A11/07, đường Quốc lộ 50, Huyện Bình  Chánh"
    ,"Lat":10.72789
    ,"Long":106.65589
    ,"Polyline":"[106.65606689,10.73153019] ; [106.65599060,10.72887039]"
    ,"Distance":"296"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2150"
    ,"Station_Code":"HBC 170"
    ,"Station_Direction":"1"
    ,"Station_Order":"4"
    ,"Station_Name":"Ngân hàng Nam Á"
    ,"Station_Address":"A13/1A, đường Quốc lộ 50,  Huyện Bình Chánh"
    ,"Lat":10.725292
    ,"Long":106.655831
    ,"Polyline":"[106.65599060,10.72887039] ; [106.65590668,10.72694969] ; [106.65586853,10.72529030]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2153"
    ,"Station_Code":"HBC 171"
    ,"Station_Direction":"1"
    ,"Station_Order":"5"
    ,"Station_Name":"Nguyễn Văn Linh"
    ,"Station_Address":"B2/21, đường  Quốc lộ 50, Huyện Bình Chánh"
    ,"Lat":10.72058
    ,"Long":106.655686
    ,"Polyline":"[106.65586853,10.72529030] ; [106.65583038,10.72443008] ; [106.65582275,10.72303009]"
    ,"Distance":"251"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"879"
    ,"Station_Code":"HBC 008"
    ,"Station_Direction":"1"
    ,"Station_Order":"6"
    ,"Station_Name":"Sau Quốc lộ 50"
    ,"Station_Address":"Cột đèn 144, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.718972
    ,"Long":106.654415
    ,"Polyline":"[106.65582275,10.72303009] ; [106.65573120,10.72074986] ; [106.65570831,10.71980000] ; [106.65453339,10.71887016]"
    ,"Distance":"525"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"881"
    ,"Station_Code":"HBC 009"
    ,"Station_Direction":"1"
    ,"Station_Order":"7"
    ,"Station_Name":"Hoa Kiểng Phú Vinh"
    ,"Station_Address":"Cột  đèn 156, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.714903
    ,"Long":106.649158
    ,"Polyline":"[106.65453339,10.71887016] ; [106.65112305,10.71619987]"
    ,"Distance":"476"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"884"
    ,"Station_Code":"HBC 010"
    ,"Station_Direction":"1"
    ,"Station_Order":"8"
    ,"Station_Name":"Xây dựng Tân Bình"
    ,"Station_Address":"Cột đèn 172, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.71174
    ,"Long":106.645103
    ,"Polyline":"[106.65112305,10.71619987] ; [106.64601898,10.71224976] ; [106.64523315,10.71164036]"
    ,"Distance":"820"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"878"
    ,"Station_Code":"HBC 011"
    ,"Station_Direction":"1"
    ,"Station_Order":"9"
    ,"Station_Name":"Chung cư Conic"
    ,"Station_Address":"Cột đèn 184, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.709506
    ,"Long":106.64227
    ,"Polyline":"[106.64523315,10.71164036] ; [106.64237976,10.70940971]"
    ,"Distance":"398"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"880"
    ,"Station_Code":"HBC 012"
    ,"Station_Direction":"1"
    ,"Station_Order":"10"
    ,"Station_Name":"Khu dân cư 13A"
    ,"Station_Address":"Cột đèn  192, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.707397
    ,"Long":106.639502
    ,"Polyline":"[106.64237976,10.70940971] ; [106.63968658,10.70730972]"
    ,"Distance":"375"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"882"
    ,"Station_Code":"HBC 013"
    ,"Station_Direction":"1"
    ,"Station_Order":"11"
    ,"Station_Name":"Trịnh Quang  Nghị"
    ,"Station_Address":"Cột đèn 210, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.703602
    ,"Long":106.634567
    ,"Polyline":"[106.63968658,10.70730972] ; [106.63645935,10.70487976] ; [106.63468170,10.70349026]"
    ,"Distance":"693"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"886"
    ,"Station_Code":"HBC 014"
    ,"Station_Direction":"1"
    ,"Station_Order":"12"
    ,"Station_Name":"Nhôm Kim Hằng"
    ,"Station_Address":"Cột đèn  216, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.701414
    ,"Long":106.631713
    ,"Polyline":"[106.63468170,10.70349026] ; [106.63297272,10.70219040]"
    ,"Distance":"236"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"887"
    ,"Station_Code":"HBC 015"
    ,"Station_Direction":"1"
    ,"Station_Order":"13"
    ,"Station_Name":"Cầu sập"
    ,"Station_Address":"Cột đèn 232, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69925
    ,"Long":106.627235
    ,"Polyline":"[106.63297272,10.70219040] ; [106.63110352,10.70079994] ; [106.63066864,10.70051003] ; [106.62970734,10.69997978] ; [106.62728119,10.69913006]"
    ,"Distance":"716"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"883"
    ,"Station_Code":"HBC 016"
    ,"Station_Direction":"1"
    ,"Station_Order":"14"
    ,"Station_Name":"Ba Tơ"
    ,"Station_Address":"Cột đèn 249, đường Nguyễn Văn Linh, Huy ện Bình Chánh"
    ,"Lat":10.696855
    ,"Long":106.61828
    ,"Polyline":"[106.62728119,10.69913006] ; [106.62017059,10.69721985] ; [106.61717987,10.69639969]"
    ,"Distance":"1145"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"885"
    ,"Station_Code":"HBC 017"
    ,"Station_Direction":"1"
    ,"Station_Order":"15"
    ,"Station_Name":"Cầu Cần Giuộc"
    ,"Station_Address":"Cột đèn 258, đường Nguyễn Văn Linh, Huyện  Bình Chánh"
    ,"Lat":10.695133
    ,"Long":106.612183
    ,"Polyline":"[106.61717987,10.69639969] ; [106.61221313,10.69501972]"
    ,"Distance":"564"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"889"
    ,"Station_Code":"HBC 452"
    ,"Station_Direction":"1"
    ,"Station_Order":"16"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Đối diện công ty bất động sản, đường Đường vào Chợ ĐM Bình Điền, Huy ện Bình Chánh"
    ,"Lat":10.698468
    ,"Long":106.609279
    ,"Polyline":"[106.61221313,10.69501972] ; [106.61032867,10.69449997] ; [106.61032104,10.69480991] ; [106.61000824,10.69594002] ; [106.60929871,10.69845963]"
    ,"Distance":"669"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"891"
    ,"Station_Code":"HBC 453"
    ,"Station_Direction":"1"
    ,"Station_Order":"17"
    ,"Station_Name":"Chợ Bình Điền"
    ,"Station_Address":"Quán ăn Chợ Bình Điền, đường Đường vào Ch ợ ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.702274
    ,"Long":106.608195
    ,"Polyline":"[106.60929871,10.69845963] ; [106.60823822,10.70228004]"
    ,"Distance":"440"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"893"
    ,"Station_Code":"HBC 451"
    ,"Station_Direction":"1"
    ,"Station_Order":"18"
    ,"Station_Name":"Công ty bất  động sản"
    ,"Station_Address":"Công ty bất động sản, đường Đường vào Chợ  ĐM Bình Điền, Huyện Bình Chánh"
    ,"Lat":10.698684
    ,"Long":106.609113
    ,"Polyline":"[106.60823822,10.70228004] ; [106.60803223,10.70302963] ; [106.60791779,10.70298958] ; [106.60826874,10.70178986] ; [106.60910797,10.69869041]"
    ,"Distance":"595"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"888"
    ,"Station_Code":"HBC 018"
    ,"Station_Direction":"1"
    ,"Station_Order":"19"
    ,"Station_Name":"Khu dân cư  Nguyễn Minh"
    ,"Station_Address":"Cột đèn 265, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.6944
    ,"Long":106.60952
    ,"Polyline":"[106.60910797,10.69869041] ; [106.60958862,10.69699001] ; [106.60984802,10.69610023] ; [106.60990906,10.69583988] ; [106.61019135,10.69478989] ; [106.61032867,10.69449997] ; [106.60955048,10.69429016]"
    ,"Distance":"574"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"892"
    ,"Station_Code":"HBC 019"
    ,"Station_Direction":"1"
    ,"Station_Order":"20"
    ,"Station_Name":"Căn hộ Hoàng Quân"
    ,"Station_Address":"Cột  đèn 276, đường Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69335
    ,"Long":106.605682
    ,"Polyline":"[106.60955048,10.69429016] ; [106.60572052,10.69324017]"
    ,"Distance":"434"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"894"
    ,"Station_Code":"HBC 020"
    ,"Station_Direction":"1"
    ,"Station_Order":"21"
    ,"Station_Name":"Ấp 2"
    ,"Station_Address":"Cột đèn 291, đường  Nguyễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.692048
    ,"Long":106.600937
    ,"Polyline":"[106.60572052,10.69324017] ; [106.60012054,10.69169044]"
    ,"Distance":"636"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"895"
    ,"Station_Code":"HBC 021"
    ,"Station_Direction":"1"
    ,"Station_Order":"22"
    ,"Station_Name":"Quốc lộ  1A"
    ,"Station_Address":"Cột đèn 302, đường Nguy ễn Văn Linh, Huyện Bình Chánh"
    ,"Lat":10.69075
    ,"Long":106.596169
    ,"Polyline":"[106.60012054,10.69169044] ; [106.59619904,10.69064045]"
    ,"Distance":"444"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"704"
    ,"Station_Code":"HBC 389"
    ,"Station_Direction":"1"
    ,"Station_Order":"23"
    ,"Station_Name":"Nguyễn Hữu Trí"
    ,"Station_Address":"45/2A, đường Quốc lộ 1A, Huyện Bình Chánh"
    ,"Lat":10.697161
    ,"Long":106.597059
    ,"Polyline":"[106.59619904,10.69064045] ; [106.59554291,10.69046974] ; [106.59516907,10.69032001] ; [106.59481812,10.69013977] ; [106.59546661,10.69213009] ; [106.59552765,10.69237995] ; [106.59554291,10.69258022] ; [106.59558868,10.69277000]"
    ,"Distance":"467"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2155"
    ,"Station_Code":"HBC 414"
    ,"Station_Direction":"1"
    ,"Station_Order":"24"
    ,"Station_Name":"Chùa Tam  Bửu"
    ,"Station_Address":"D/d 9/16, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.696713
    ,"Long":106.596297
    ,"Polyline":"[106.59558868,10.69277000] ; [106.59602356,10.69419003] ; [106.59683228,10.69678020] ; [106.59580994,10.69664955]"
    ,"Distance":"579"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2152"
    ,"Station_Code":"HBC 413"
    ,"Station_Direction":"1"
    ,"Station_Order":"25"
    ,"Station_Name":"Bệnh viện Bình Chánh"
    ,"Station_Address":"Bệnh viện Bình Chánh, đường Nguy ễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.696259
    ,"Long":106.592746
    ,"Polyline":"[106.59580994,10.69664955] ; [106.59442902,10.69645977] ; [106.59313202,10.69631004] ; [106.59272766,10.69626045]"
    ,"Distance":"339"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2154"
    ,"Station_Code":"HBC 412"
    ,"Station_Direction":"1"
    ,"Station_Order":"26"
    ,"Station_Name":"Trung tâm văn hóa huyện Bình Ch ánh"
    ,"Station_Address":"Đối diện Trung tâm văn hóa huyện Bình Chánh, đường  Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.695411
    ,"Long":106.588261
    ,"Polyline":"[106.59272766,10.69626045] ; [106.59120941,10.69606018] ; [106.58998871,10.69589043] ; [106.58950043,10.69577026] ; [106.58827209,10.69536972]"
    ,"Distance":"499"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2157"
    ,"Station_Code":"HBC 411"
    ,"Station_Direction":"1"
    ,"Station_Order":"27"
    ,"Station_Name":"Công ty  Vĩnh Tiến"
    ,"Station_Address":"Công ty Vĩnh  Tiến, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.693961
    ,"Long":106.583487
    ,"Polyline":"[106.58827209,10.69536972] ; [106.58352661,10.69384003]"
    ,"Distance":"545"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2156"
    ,"Station_Code":"HBC 410"
    ,"Station_Direction":"1"
    ,"Station_Order":"28"
    ,"Station_Name":"Thiên Giang"
    ,"Station_Address":"A14 /7, đường Nguyễn Hữu Trí, Huyện Bình Chánh"
    ,"Lat":10.692385
    ,"Long":106.577436
    ,"Polyline":"[106.58352661,10.69384003] ; [106.58261871,10.69357014] ; [106.58203888,10.69338989] ; [106.58090973,10.69307995] ; [106.57987976,10.69287014] ; [106.57807922,10.69250011] ; [106.57743073,10.69235992]"
    ,"Distance":"687"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2159"
    ,"Station_Code":"HBC 076"
    ,"Station_Direction":"1"
    ,"Station_Order":"29"
    ,"Station_Name":"Bùi Thanh  Khiết"
    ,"Station_Address":"B2/15E, đường Bùi Thanh Khiết, Huyện Bình Chánh"
    ,"Lat":10.689628
    ,"Long":106.574721
    ,"Polyline":"[106.57743073,10.69235992] ; [106.57399750,10.69165039] ; [106.57472992,10.68962002]"
    ,"Distance":"623"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2158"
    ,"Station_Code":"HBC 420"
    ,"Station_Direction":"1"
    ,"Station_Order":"30"
    ,"Station_Name":"Ngã 3 Trường học"
    ,"Station_Address":"E9/139C, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.704187
    ,"Long":106.567769
    ,"Polyline":"[106.57472992,10.68962002] ; [106.57595825,10.68622017] ; [106.57234955,10.68554020] ; [106.56871033,10.68486977] ; [106.56826782,10.68490028] ; [106.56796265,10.68500042] ; [106.56784058,10.68507004] ; [106.56771851,10.68519020] ; [106.56755829,10.68542004] ; [106.56748962,10.68572998] ; [106.56757355,10.68653011] ; [106.56835938,10.69019032] ; [106.57115936,10.70242023] ; [106.57122040,10.70265961] ; [106.57115173,10.70269966] ; [106.56983185,10.70326042] ; [106.56835938,10.70388031] ; [106.56813812,10.70398045] ; [106.56800079,10.70407009] ; [106.56777954,10.70438957]"
    ,"Distance":"3751"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2161"
    ,"Station_Code":"HBC 421"
    ,"Station_Direction":"1"
    ,"Station_Order":"31"
    ,"Station_Name":"Chợ Tân Nhựt"
    ,"Station_Address":"B15/307A (Th ành Phát), đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.706085
    ,"Long":106.563714
    ,"Polyline":"[106.56777954,10.70438957] ; [106.56691742,10.70573044] ; [106.56684875,10.70586014] ; [106.56671906,10.70586014] ; [106.56658936,10.70584011] ; [106.56575775,10.70532036] ; [106.56553650,10.70510006] ; [106.56503296,10.70528984] ; [106.56442261,10.70559025]"
    ,"Distance":"497"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2160"
    ,"Station_Code":"HBC 422"
    ,"Station_Direction":"1"
    ,"Station_Order":"32"
    ,"Station_Name":"cầu Bảy  Tải"
    ,"Station_Address":"Đối diện B14/258A, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.707829
    ,"Long":106.560602
    ,"Polyline":"[106.56442261,10.70559025] ; [106.56381226,10.70598984] ; [106.56192780,10.70711040] ; [106.56163025,10.70734978] ; [106.56066895,10.70788956]"
    ,"Distance":"484"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2163"
    ,"Station_Code":"HBC 423"
    ,"Station_Direction":"1"
    ,"Station_Order":"33"
    ,"Station_Name":"Bưu điện Tân Nhựt"
    ,"Station_Address":"Đối diện cột điện  2AT, đường Thế Lữ, Huyện Bình Ch ánh"
    ,"Lat":10.710781
    ,"Long":106.555624
    ,"Polyline":"[106.56066895,10.70788956] ; [106.55555725,10.71057987]"
    ,"Distance":"634"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2162"
    ,"Station_Code":"HBC 424"
    ,"Station_Direction":"1"
    ,"Station_Order":"34"
    ,"Station_Name":"Ủy Ban xã Tân nHựt"
    ,"Station_Address":"Đối diện Ủy ban nhân dân xã Tân Nhựt, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.714044
    ,"Long":106.549702
    ,"Polyline":"[106.55555725,10.71057987] ; [106.55490875,10.71090031] ; [106.55425262,10.71127033] ; [106.54972076,10.71399021]"
    ,"Distance":"743"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2165"
    ,"Station_Code":"HBC 425"
    ,"Station_Direction":"1"
    ,"Station_Order":"35"
    ,"Station_Name":"Trường mẫu giáo Tân Nhựt"
    ,"Station_Address":"Đối diện A1/7, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.716395
    ,"Long":106.545523
    ,"Polyline":"[106.54972076,10.71399021] ; [106.54792023,10.71506977] ; [106.54563904,10.71638966]"
    ,"Distance":"520"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2164"
    ,"Station_Code":"HBC 426"
    ,"Station_Direction":"1"
    ,"Station_Order":"36"
    ,"Station_Name":"Xây dựng Mạnh Dũng"
    ,"Station_Address":"Đối diện A1/32, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.718002
    ,"Long":106.542685
    ,"Polyline":"[106.54563904,10.71638966] ; [106.54280853,10.71800041]"
    ,"Distance":"357"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2166"
    ,"Station_Code":"HBC 427"
    ,"Station_Direction":"1"
    ,"Station_Order":"37"
    ,"Station_Name":"Trạm cầu"
    ,"Station_Address":"Đối diện A3/68A, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.719742
    ,"Long":106.53966
    ,"Polyline":"[106.54280853,10.71800041] ; [106.53974152,10.71973038]"
    ,"Distance":"387"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2168"
    ,"Station_Code":"HBC 428"
    ,"Station_Direction":"1"
    ,"Station_Order":"38"
    ,"Station_Name":"Trạm cấp nước"
    ,"Station_Address":"Đối diện A4/110, đường Thế Lữ, Huyện Bình Chánh"
    ,"Lat":10.721618
    ,"Long":106.53643
    ,"Polyline":"[106.53974152,10.71973038] ; [106.53650665,10.72155952]"
    ,"Distance":"407"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2169"
    ,"Station_Code":"HBC 429"
    ,"Station_Direction":"1"
    ,"Station_Order":"39"
    ,"Station_Name":"Khu di tích Láng Le Bàu Cò"
    ,"Station_Address":"A4/115B, đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.727516
    ,"Long":106.535212
    ,"Polyline":"[106.53650665,10.72155952] ; [106.53359222,10.72319984] ; [106.53398895,10.72375011] ; [106.53430176,10.72432041] ; [106.53453064,10.72467995] ; [106.53463745,10.72480011] ; [106.53514862,10.72521019] ; [106.53518677,10.72527981] ; [106.53505707,10.72714996] ; [106.53507233,10.72733021] ; [106.53504944,10.72774029]"
    ,"Distance":"935"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2167"
    ,"Station_Code":"HBC 430"
    ,"Station_Direction":"1"
    ,"Station_Order":"40"
    ,"Station_Name":"Cổng số 9"
    ,"Station_Address":"A5/147 (Hoàn Hảo), đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.733735
    ,"Long":106.534955
    ,"Polyline":"[106.53504944,10.72774029] ; [106.53486633,10.73176956] ; [106.53468323,10.73595047] ; [106.53469849,10.73600960] ; [106.53494263,10.73665047] ; [106.53653717,10.74018955] ; [106.53829193,10.74423981] ; [106.53825378,10.74431038] ; [106.53784943,10.74454021] ; [106.53780365,10.74466038] ; [106.53781128,10.74483013] ; [106.53791046,10.74503994] ; [106.53885651,10.74456978] ; [106.53910065,10.74446011] ; [106.53942108,10.74427032] ; [106.53923035,10.74398994] ; [106.53910065,10.74388027] ; [106.53896332,10.74392033] ; [106.53858948,10.74409962] ; [106.53684998,10.74020958] ; [106.53613281,10.73853016] ; [106.53530121,10.73661041] ; [106.53524780,10.73614979] ; [106.53517151,10.73585033] ; [106.53504944,10.73561954] ; [106.53511810,10.73443031] ; [106.53515625,10.73357964]"
    ,"Distance":"3591"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2171"
    ,"Station_Code":"HBC 431"
    ,"Station_Direction":"1"
    ,"Station_Order":"41"
    ,"Station_Name":"Cổng số 8"
    ,"Station_Address":"A5/140B (Hữu Thành), đường Láng Le bàu Cò, Huyện B ình Chánh"
    ,"Lat":10.738115
    ,"Long":106.536217
    ,"Polyline":"[106.53515625,10.73357964] ; [106.53504944,10.73561954] ; [106.53517151,10.73585033] ; [106.53524780,10.73614979] ; [106.53530121,10.73661041] ; [106.53537750,10.73682022] ; [106.53598785,10.73820972]"
    ,"Distance":"535"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2170"
    ,"Station_Code":"HBC 432"
    ,"Station_Direction":"1"
    ,"Station_Order":"42"
    ,"Station_Name":"Bưu điện Láng Le Bàu Cò"
    ,"Station_Address":"Cột điện 73T , đường Láng Le bàu Cò, Huyện Bình Chánh"
    ,"Lat":10.742827
    ,"Long":106.538281
    ,"Polyline":"[106.53598785,10.73820972] ; [106.53613281,10.73855972] ; [106.53787994,10.74250984]"
    ,"Distance":"521"
  },
  {
     "Route_Id":"43"
    ,"Station_Id":"2172"
    ,"Station_Code":"BX 55"
    ,"Station_Direction":"1"
    ,"Station_Order":"43"
    ,"Station_Name":"KCN LÊ MINH  XUÂN"
    ,"Station_Address":"ĐẦU BẾN KCN LÊ MINH XUÂN, đường Trần Đại Nghĩa, Huyện Bình Chánh"
    ,"Lat":10.744208
    ,"Long":106.539513
    ,"Polyline":"[106.53787994,10.74250984] ; [106.53858948,10.74409962] ; [106.53896332,10.74392033] ; [106.53910065,10.74388027] ; [106.53923035,10.74398994] ; [106.53942108,10.74427032] ; [106.53951263,10.74421024]"
    ,"Distance":"322"
  }]