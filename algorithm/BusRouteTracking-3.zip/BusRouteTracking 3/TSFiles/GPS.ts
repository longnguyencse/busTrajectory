export default class GPS {
    constructor(readonly Lat: number, readonly Long: number, readonly ReceivingTime: number) {}
}