import Point from "./Point";

export default class RPoint {
    constructor(readonly point: Point, public length: number) {
    }
}