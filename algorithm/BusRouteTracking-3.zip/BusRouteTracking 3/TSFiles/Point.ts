export default class Point {
    constructor(readonly Lat: number, readonly Long: number) {}
    toString() {
        return this.Lat + "-" + this.Long; // City is not a part of the key.
    }
}